﻿using System;

namespace SymbolTool.Internal
{
    /// <summary>
    /// Defines the available commands.
    /// </summary>
    [Flags]
    public enum Command
    {
        /// <summary>
        /// No command.
        /// </summary>
        None            = 0x0,

        /// <summary>
        /// Print the help.
        /// </summary>
        PrintHelp       = 0x1,

        /// <summary>
        /// Execute the index sources command.
        /// </summary>
        IndexSources    = 0x2,

        /// <summary>
        /// Execute the publish symbols command.
        /// </summary>
        PublishSymbols  = 0x4,

        /// <summary>
        /// Execute the clean symbols command.
        /// </summary>
        CleanSymbols    = 0x8,
    }
}
