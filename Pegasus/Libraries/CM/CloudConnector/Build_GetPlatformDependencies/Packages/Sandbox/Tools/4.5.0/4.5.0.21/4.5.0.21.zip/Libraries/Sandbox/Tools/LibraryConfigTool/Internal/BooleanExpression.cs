﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Reflection;
using System.IO;
using System.ServiceProcess;

namespace LibraryConfigTool.Internal
{
    internal sealed class BooleanExpression
    {
        public static BooleanExpression Parse(String expressionAsString, String configFile)
        {
            BooleanExpression result = new BooleanExpression();

            result._conditions.Clear();
            String[] conditions = Regex.Split(expressionAsString, @"\s(and|or)\s", RegexOptions.IgnoreCase);
            int i = 0;
            while (i < conditions.Length)
            {
                String condition = conditions[i];
                Boolean moreConditions = i + 1 < conditions.Length;
                IfCondition.Connector e = IfCondition.Connector.None;
                if (moreConditions)
                {
                    try
                    {
                        e = (IfCondition.Connector)Enum.Parse(typeof(IfCondition.Connector), conditions[i + 1], true);
                    }
                    catch (System.ArgumentException ex)
                    {
                        String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.UnsupportedIfConnectorFormat, condition[i + 1]);
                        throw new LibraryConfigSchemaException(configFile, errorMessage, ex);
                    }
                }
                IfCondition cond = new IfCondition(condition, e);
                result._conditions.Add(cond);
                i += 2;     // move past current condition and connector(if any)
            }

            foreach (IfCondition ifc in result._conditions)
            {
                if (Regex.IsMatch(ifc.Condition, @".*==.*", RegexOptions.CultureInvariant))
                {
                    ifc.Operation = Operation.Equals;
                }
                else if (Regex.IsMatch(ifc.Condition, @".*!=.*", RegexOptions.CultureInvariant))
                {
                    ifc.Operation = Operation.NotEquals;
                }
                else if (FunctionEvaluator.IsFunction(ifc.Condition))
                {
                    ifc.Operation = Operation.Function;
                }
                else
                {
                    // assume it either is a literal boolean ... or an expression that can ultimately be boiled down to one
                    ifc.Operation = Operation.BooleanExpression;
                }
            }

            return result;
        }

        public Boolean LastResult
        { get { return _lastResult; } }

        public Boolean Evaluate(ConfigInfo rootConfigInfo)
        {
            _rootConfigInfo = rootConfigInfo;

            Boolean resultSoFar = false;
            IfCondition.Connector previousConnector = IfCondition.Connector.None;
            foreach (IfCondition ifc in _conditions)
            {
                String test = rootConfigInfo.ReplaceAllVariables(ifc.Condition);

                ifc.ConditionResult = false;
                switch (ifc.Operation)
                {
                    case Operation.Equals:
                        {
                            String[] substrings = test.Split(new String[] { "==" }, StringSplitOptions.None);
                            if (substrings == null || substrings.Length != 2)
                            {
                                using (BatchedOutput output = new BatchedOutput(false))
                                {
                                    output.BeginWriteError(0, "Evaluation of if test failed;  invalid format of '==' operation.");
                                    output.AddErrorDetail("Test", test);
                                    output.EndWriteError();
                                }
                            }
                            else
                            {
                                if (String.Compare(rootConfigInfo.ReplaceAllVariables(substrings[0].Trim()), rootConfigInfo.ReplaceAllVariables(substrings[1].Trim()), true, CultureInfo.InvariantCulture) == 0)
                                {
                                    ifc.ConditionResult = true;
                                }
                            }
                        }
                        break;

                    case Operation.NotEquals:
                        {
                            String[] substrings = test.Split(new String[] { "!=" }, StringSplitOptions.None);
                            if (substrings == null || substrings.Length != 2)
                            {
                                using (BatchedOutput output = new BatchedOutput(false))
                                {
                                    output.BeginWriteError(0, "Evaluation of if test failed;  invalid format of '!=' operation.");
                                    output.AddErrorDetail("Test", test);
                                    output.EndWriteError();
                                }
                            }
                            else
                            {
                                if (String.Compare(rootConfigInfo.ReplaceAllVariables(substrings[0].Trim()), rootConfigInfo.ReplaceAllVariables(substrings[1].Trim()), true, CultureInfo.InvariantCulture) != 0)
                                {
                                    ifc.ConditionResult = true;
                                }
                            }
                        }
                        break;

                    case Operation.Function:
                        {
                            Boolean tryParseResult = false;
                            if (Boolean.TryParse(test, out tryParseResult))
                            {
                                ifc.ConditionResult = tryParseResult;
                            }
                            else
                            {
                                ifc.ConditionResult = Boolean.Parse(FunctionEvaluator.Evaluate(_rootConfigInfo, test));
                            }
                        }
                        break;

                    case Operation.BooleanExpression:
                        {
                            Boolean tryParseResult = false;
                            if (Boolean.TryParse(test, out tryParseResult))
                            {
                                ifc.ConditionResult = tryParseResult;
                            }
                            else
                            {
                                ifc.ConditionResult = BooleanExpression.Parse(ifc.Condition, _rootConfigInfo.ConfigFile).Evaluate(_rootConfigInfo);
                            }
                        }
                        break;
                }

                // Evaluate result of condition based on connector
                //
                // Be careful ... this just performs simple left to right operator evaluation.  There is no notion of AND having
                // a higher precedence than OR.  Therefore:  "A OR B AND C" will actually evaluate to FALSE when A=1, B=0, C=0
                // rather then processing it like "A OR (B AND C)" which would result in TRUE.
                if (previousConnector == IfCondition.Connector.None)
                {
                    resultSoFar = ifc.ConditionResult;
                }
                else
                {
                    switch (previousConnector)
                    {
                        case IfCondition.Connector.And:
                            resultSoFar &= ifc.ConditionResult;
                            break;

                        case IfCondition.Connector.Or:
                            resultSoFar |= ifc.ConditionResult;
                            break;

                        default:
                        case IfCondition.Connector.None:
                            using (BatchedOutput output = new BatchedOutput(false))
                            {
                                output.BeginWriteError(0, "Evaluation of if test failed;  unepected case while evaluating condition.");
                                output.AddErrorDetail("Condition", ifc.Condition);
                                output.EndWriteError();
                            }
                            break;
                    }
                }

                // short-circuit evaluation of AND condition
                if (ifc.CondConnector == IfCondition.Connector.And && resultSoFar == false)
                {
                    break;
                }

                previousConnector = ifc.CondConnector;
            }

            _lastResult = resultSoFar;

            return resultSoFar;
        }

        private enum Operation
        {
            None = 0,
            Equals,
            NotEquals,
            Function,
            BooleanExpression
        }

        private class IfCondition
        {
            public enum Connector
            {
                None = 0,
                And,
                Or
            };

            public IfCondition(String cond, Connector connector)
            {
                Condition = cond;
                CondConnector = connector;
            }

            // the condition string
            public String Condition { get; set; }

            // connector between conditions; null if no further conditions
            public Connector CondConnector { get; set; }

            // the comparison operation (eg., EQ, NEQ or Function)
            public Operation Operation { get; set; }

            // the result of the evaluated condition
            public Boolean ConditionResult { get; set; }
        }

        private List<IfCondition> _conditions = new List<IfCondition>();
        private ConfigInfo _rootConfigInfo;
        private Boolean _lastResult;
    }
}
