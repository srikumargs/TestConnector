﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSProjCleaner.Internal
{
    internal sealed class ConsoleEngineEventsSubscriber : IEngineEventsSubscriber
    {
        #region IEngineEventsSubscriber Members

        public void OnWorkProgress(object sender, WorkProgressEventArgs args)
        {
            Program.WriteLine(args.Description, args.Code == WorkProgressCode.Error);
        }

        public void OnStop()
        {
        }

        #endregion
    }
}
