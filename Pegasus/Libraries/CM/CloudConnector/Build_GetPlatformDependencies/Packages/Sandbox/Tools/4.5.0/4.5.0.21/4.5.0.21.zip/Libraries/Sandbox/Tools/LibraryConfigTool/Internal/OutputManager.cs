using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Runtime.Remoting.Messaging;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal enum IndentAction
    {
        None = 0,
        Increment,
        Decrement,
        IndentOnce,
        NoIndent,
        Clear
    }

    internal sealed class OutputManager : MarshalByRefObject, IMessageSink
    {
        public OutputManager()
        {
            _outputType = OutputType.Banner | OutputType.Error | OutputType.Info | OutputType.Status;
        }

        public override object InitializeLifetimeService()
        {
            return null; // prevent leased-based lifetime management
        }

        #region IResultEventsSubscriber Members

        public Int32 ErrorCount
        {
            get
            {
                return _errorCount;
            }
        }

        public Int32 ChangeIndent(IndentAction indentAction)
        {
            Int32 result = 0;

            switch (indentAction)
            {
                case IndentAction.Decrement:
                    Debug.Assert(_indentLevel > 0);
                    result = (_indentLevel--);
                    break;

                case IndentAction.Increment:
                    result = (_indentLevel++);
                    break;

                case IndentAction.Clear:
                    result = (_indentLevel = 0);
                    break;

                case IndentAction.IndentOnce:
                    result = _indentLevel + 1;
                    break;

                case IndentAction.NoIndent:
                    result = 0;
                    break;

                case IndentAction.None:
                    result = _indentLevel;
                    break;
            }

            return result;
        }

        public OutputType OutputType
        {
            get
            {
                return _outputType;
            }

            set
            {
                _outputType = value;
            }
        }

        public void Write(OutputType outputType, String description)
        {
            Write(null, new ResultEventArgs(outputType, IndentAction.None, description));
        }

        public void Write(OutputType outputType, IndentAction indentAction, String description)
        {
            Write(null, new ResultEventArgs(outputType, indentAction, description));
        }

        public void Write(Object sender, ResultEventArgs args)
        {
            if (args.OutputType == OutputType.Error)
            {
                _errorCount++;
            }

            Int32 indentLevel = ChangeIndent(args.IndentAction);
            String message = String.Format(CultureInfo.CurrentCulture, "{0}{1}", new String(' ', indentLevel * 3), args.Description);
            if ((args.OutputType & _outputType) != OutputType.None)
            {
                Console.WriteLine(message);
            }
            if ((_outputType & OutputType.Verbose) != OutputType.None || (args.OutputType & OutputType.Status) != OutputType.None)
            {
                System.Diagnostics.Trace.WriteLine(message);
            }
        }

        public Int32 PushIndentLevel(Int32 indentLevel)
        {
            Int32 result = _indentLevel;
            _indentLevelStack.Push(_indentLevel);
            _indentLevel = indentLevel;
            return result;
        }

        public Int32 PopIndentLevel()
        {
            _indentLevel = _indentLevelStack.Pop();
            return _indentLevel;
        }

        #endregion

        private Int32 _indentLevel;     //= 0; (automatically initialized by runtime)
        private OutputType _outputType; //= OutputType.None; (automatically initialized by runtime)
        private Int32 _errorCount;      //= 0; (automatically initialized by runtime)
        private Stack<Int32> _indentLevelStack = new Stack<Int32>();

        #region IMessageSink Members

        public IMessageCtrl AsyncProcessMessage(IMessage msg, IMessageSink replySink)
        {
            throw new NotImplementedException(Strings.TheMethodOrOperationIsNotImplemented);
        }

        public IMessageSink NextSink
        {
            get
            {
                throw new NotImplementedException(Strings.TheMethodOrOperationIsNotImplemented);
            }
        }

        /// <summary>
        /// Weak-typed method wrapper to facilitate calling from subordinate app-domain which was created in the LoadFrom context
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public IMessage SyncProcessMessage(IMessage msg)
        {
            Write((OutputType)Enum.Parse(typeof(OutputType), (String)msg.Properties["OutputType"]), (IndentAction)Enum.Parse(typeof(IndentAction), (String)msg.Properties["IndentAction"]), (String)msg.Properties["Message"]);

            return null;
        }

        #endregion
    }
}
