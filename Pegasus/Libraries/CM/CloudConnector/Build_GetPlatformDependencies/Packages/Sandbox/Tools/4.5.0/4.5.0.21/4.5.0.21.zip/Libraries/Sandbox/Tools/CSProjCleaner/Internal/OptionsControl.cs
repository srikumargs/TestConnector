﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CSProjCleaner.Internal
{
    internal partial class OptionsControl : UserControl
	{
		public OptionsControl()
		{
			InitializeComponent();
		}

		private void OptionsControl_Load(object sender, EventArgs e)
		{
			_tableLayoutPanel.CellPaint += new TableLayoutCellPaintEventHandler(_tableLayoutPanel_CellPaint);
			foreach (Control control in _tableLayoutPanel.Controls)
			{
				control.MouseClick += new MouseEventHandler(control_MouseClick);
				control.Enter += new EventHandler(control_Enter);
				control.Click += new EventHandler(control_Click);
				if (control is ComboBox)
				{
					(control as ComboBox).SelectedIndex = 0;
				}
			}
		}

		private void control_Click(object sender, EventArgs e)
		{
			SelectRow(_tableLayoutPanel.GetPositionFromControl(sender as Control).Row);
		}

		private void control_Enter(object sender, EventArgs e)
		{
			SelectRow(_tableLayoutPanel.GetPositionFromControl(sender as Control).Row);
		}

		private void control_MouseClick(object sender, MouseEventArgs e)
		{
			SelectRow(_tableLayoutPanel.GetPositionFromControl(sender as Control).Row);
		}

		private void SelectRow(Int32 row)
		{
			if (_row != row)
			{
				_row = row;
				_tableLayoutPanel.Invalidate();
			}
		}

		private void _tableLayoutPanel_CellPaint(object sender, TableLayoutCellPaintEventArgs e)
		{
			if (e.Row == _row)
			{
				e.Graphics.FillRectangle(SystemBrushes.Highlight, e.CellBounds);
				if (e.Column == 0)
				{
					if ((_tableLayoutPanel.GetControlFromPosition(0, _row) as Label).ForeColor != SystemColors.HighlightText)
					{
						(_tableLayoutPanel.GetControlFromPosition(0, _row) as Label).ForeColor = SystemColors.HighlightText;
					}
				}
			}
			else
			{
				if (e.Column == 0)
				{
					if ((_tableLayoutPanel.GetControlFromPosition(0, e.Row) as Label).ForeColor != SystemColors.ControlText)
					{
						(_tableLayoutPanel.GetControlFromPosition(0, e.Row) as Label).ForeColor = SystemColors.ControlText;
					}
				}
			}

			_helpTextLabel.Text = toolTip1.GetToolTip(_tableLayoutPanel.GetControlFromPosition(1, _row));
		}

		internal CSProjFileProcessorOptions PopulateOptions()
		{
			CSProjFileProcessorOptions result = new CSProjFileProcessorOptions();

			result.SourceControlServer = _sourceControlServerTextBox.Text;
			result.PreBuildAction = ComboBoxToAction(_preBuildEventComboBox);
			result.PostBuildAction = ComboBoxToAction(_postBuildEventComboBox);
			result.FrameworkVersion = (_dotNetFrameworkVersionComboBox.SelectedIndex != 0) ? (String)_dotNetFrameworkVersionComboBox.SelectedItem : null;
            result.WarningsAsErrorsAction = ComboBoxToAction(_warningsAsErrorsComboBox);
            result.ChangeCodeAnalysisAction("Debug|Any CPU", ComboBoxToAction(_runCodeAnalysisComboBox));
            result.ChangeCodeAnalysisAction("Release|Any CPU", ComboBoxToAction(_runCodeAnalysisComboBox));
			result.FixAssemblyReferences = (_normalizeAssemblyReferencesComboBox.SelectedIndex == 1);
			result.FixOutputPaths = (_normalizeOutputPathsComboBox.SelectedIndex == 1);
			result.PlatformTarget = (_platformTargetComboBox.SelectedIndex != 0) ? (String)_platformTargetComboBox.SelectedItem : null;
            result.SignAssemblyAction = ComboBoxToAction(_assemblySigningComboBox);
            result.SetCommonPrivateKey = ComboBoxToAction(_assemblySigningComboBox) == Action.Set;

			return result;
		}

		private Action ComboBoxToAction(ComboBox comboBox)
		{
			Action result = Action.None;

			if (comboBox.SelectedIndex == 1)
			{
				result = Action.Set;
			}
			else if (comboBox.SelectedIndex == 2)
			{
				result = Action.Unset;
			}

			return result;
		}

		private Int32 _row;
	}
}
