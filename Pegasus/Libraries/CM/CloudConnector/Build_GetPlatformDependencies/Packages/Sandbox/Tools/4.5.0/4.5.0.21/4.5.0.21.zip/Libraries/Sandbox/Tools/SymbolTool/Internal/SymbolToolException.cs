﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.Serialization;
using System.Security.Permissions;

namespace SymbolTool.Internal
{
    /// <summary>
    /// The exception thrown when a failure occurs within any of the symbol tools.
    /// </summary>
    [Serializable]
    public class SymbolToolException : Exception
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="SymbolToolException"/> class.
        /// </summary>
        /// <param name="errorMessage">Specify the error message.</param>
        public SymbolToolException(string errorMessage)
            : base(errorMessage)
        {
            Debug.Assert(!string.IsNullOrEmpty(errorMessage));
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SymbolToolException"/> class.
        /// </summary>
        /// <param name="errorMessage">Specify the error message.</param>
        /// <param name="innerException">An inner exception</param>
        public SymbolToolException(string errorMessage, Exception innerException)
            : base(errorMessage, innerException)
        {
            Debug.Assert(!string.IsNullOrEmpty(errorMessage));
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SymbolToolException"/> class.
        /// </summary>
        /// <param name="si">Serialization Info</param>
        /// <param name="sc">Streaming Context</param>
        private SymbolToolException(SerializationInfo si, StreamingContext sc)
            : base(si, sc)
        { }

        #endregion

        #region Overrides

        /// <summary>
        /// Serialize the private fields
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
        }

        public override string ToString()
        {
            string message = string.Format(CultureInfo.CurrentCulture, "SymbolToolException encountered. Message: {0}", this.Message);

            if (InnerException != null)
            {
                message += string.Format(CultureInfo.CurrentCulture, "\n[BEGIN Inner Exception]\n{0}\n[END Inner Exception]", this.InnerException.ToString());
            }
            if (StackTrace != null)
            {

                message += "\n" + this.StackTrace.ToString();
            }

            return message;
        }

        #endregion
    }
}
