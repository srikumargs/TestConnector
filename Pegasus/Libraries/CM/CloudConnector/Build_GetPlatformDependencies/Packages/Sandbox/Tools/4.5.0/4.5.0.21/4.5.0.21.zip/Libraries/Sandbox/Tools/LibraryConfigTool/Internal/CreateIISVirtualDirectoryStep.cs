﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.DirectoryServices;
using System.Xml.XPath;
using System.Diagnostics;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class CreateIISVirtualDirectoryStep : IStep
    {
        internal CreateIISVirtualDirectoryStep(ConfigInfo configInfo, XPathNavigator navigator)
		{
			_path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, Constants.CreateVirtualDirectoryElement, configInfo.ConfigFile);
            _virtualFolderName = Utils.GetRequiredAttribute(navigator, Constants.VirtualFolderNameAttribute, Constants.CreateVirtualDirectoryElement, configInfo.ConfigFile);
		}

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String path = rootConfigInfo.ReplaceAllVariables(_path);

            try
            {
                if (!Directory.Exists(path))
                {
                    using (BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, Strings.CreateVirtualDirectoryFailedFolderDoesNotExist);
                        output.AddErrorDetail(Strings.Path, path);
                        output.EndWriteError();
                    }
                }
                else
                {
                    if (DirectoryEntry.Exists(Constants.ActiveDirectoryPathToIISRoot + "/" + _virtualFolderName))
                    {
                        DirectoryEntry existingEntry = new DirectoryEntry(Constants.ActiveDirectoryPathToIISRoot + "/" + _virtualFolderName);
                        existingEntry.Properties["Path"][0] = path;
                        existingEntry.CommitChanges();

                        Program.Output.Write(OutputType.Info, Strings.VirtualDirectoryAlreadyExists);
                    }
                    else
                    {
                        DirectoryEntry webRootEntry = new DirectoryEntry(Constants.ActiveDirectoryPathToIISRoot);
                        DirectoryEntry newVirtualDirectoryEntry = webRootEntry.Children.Add(_virtualFolderName, "IIsWebVirtualDir");
                        newVirtualDirectoryEntry.CommitChanges();
                        newVirtualDirectoryEntry.Properties["Path"][0] = path;
                        newVirtualDirectoryEntry.Properties["AuthFlags"][0] = 4;
                        newVirtualDirectoryEntry.Properties["EnableDefaultDoc"][0] = true;
                        newVirtualDirectoryEntry.Properties["DirBrowseFlags"][0] = 0x4000003e;
                        newVirtualDirectoryEntry.Properties["AccessFlags"][0] = 0x201;
                        newVirtualDirectoryEntry.CommitChanges();
                        const Int32 POOLED_PROCESS = 2;
                        newVirtualDirectoryEntry.Invoke("AppCreate2", new object[] { POOLED_PROCESS });
                        Program.Output.Write(OutputType.Info, Strings.VitualDirectoryCreated);
                    }
                    Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Virtual directory name:      '{0}'", _virtualFolderName));
                    Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path                  :      '{0}'", path));
                }
            }
            catch (Exception ex)
            {
                using (BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, Strings.CreateVirtualDirectoryFailed);
                    output.AddErrorDetail(Strings.Path, path);
                    output.AddErrorDetail(Strings.VirtualDirectory, _virtualFolderName);
                    output.AddErrorDetail(Strings.Error, ex.ToString());
                    output.EndWriteError();
                }
            }
        }

        #endregion

        private String _path;
        private String _virtualFolderName;
    }
}
