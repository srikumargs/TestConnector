﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alias.Internal
{
    internal interface IEngineEventsSubscriber
    {
        void OnWorkProgress(Object sender, WorkProgressEventArgs args);
        void OnStop();
    }
}
