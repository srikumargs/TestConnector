using System;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.Win32;

namespace LibraryConfigTool.Internal
{
    internal enum VerbosityOverrideSetting
    {
        Silent,
        Normal,
        Verbose
    }

    internal partial class MainForm : Form
    {
        public static Boolean OverrideVerbosity
        {
            get
            {
                Boolean result;

                using(RegistryKey regKey = Registry.CurrentUser.CreateSubKey(RegistryKey))
                {
                    result = Boolean.Parse((String) regKey.GetValue("OverrideVerbosity", "false"));
                }

                return result;
            }
        }

        public static VerbosityOverrideSetting VerbosityOverrideSetting
        {
            get
            {
                VerbosityOverrideSetting result;

                using(RegistryKey regKey = Registry.CurrentUser.CreateSubKey(RegistryKey))
                {
                    result = (VerbosityOverrideSetting) Enum.Parse(typeof(VerbosityOverrideSetting), (String) regKey.GetValue("VerbosityOverrideSetting", "Normal"));
                }

                return result;
            }
        }

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.Text += " v" + FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion;

            if(OverrideVerbosity)
            {
                _overrideRadioButton.Checked = true;
            }
            else
            {
                _defaultRadioButton.Checked = true;
            }
            _overrideComboBox.SelectedIndex = (Int32) VerbosityOverrideSetting;
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            using(RegistryKey regKey = Registry.CurrentUser.CreateSubKey(RegistryKey))
            {
                regKey.SetValue("OverrideVerbosity", _overrideRadioButton.Checked.ToString());
                regKey.SetValue("VerbosityOverrideSetting", _overrideComboBox.Text);
            }
        }

        private static String RegistryKey
        {
            get
            {
                String[] splitVersion = Application.ProductVersion.Split('.');
                return String.Format(CultureInfo.InvariantCulture, @"SOFTWARE\Sage\Sandbox\{0}.{1}\LibaryConfigTool", splitVersion[0], splitVersion[1]);
            }
        }

        private void _closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        /// <remarks>
        /// .NET provides no explicit exposure of the WS_GROUP windows style.  Instead,
        /// for RadioButton group-handling, the .NET framework relies on the radio buttons
        /// being child controls of a common parent control (e.g., GroupBox or Panel).
        /// This introduces difficulties when creating a UI which has other controls tightly
        /// associated (e.g., enabled/disabled) with a radio button.  Difficulties include
        /// preventing the keyboard navigation arrows from automatically moving the focus
        /// from the radio buttons to those, tightly associated, non-radio button controls.
        /// 
        /// Additionally, this reliance upon the "common parent control" to do the radio
        /// button grouping has an additional undesirable consequence:  it means that we
        /// cannot use separate panels to do our control layout for each radio button.
        /// 
        /// Our workaround is to not use the .NET framework's automatic radio button group
        /// handling.  Instead we handle the keyboard navigation and auto-deselection
        /// of associated radio buttons ourselves.
        /// </remarks>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            // defined in WinUser.h
            const int WM_KEYDOWN = 0x100;
            const int WM_SYSKEYDOWN = 0x104;


            if((WM_KEYDOWN == msg.Msg) || (WM_SYSKEYDOWN == msg.Msg))
            {
                switch(keyData)
                {
                    case Keys.Down:
                    case Keys.Right:
                    case Keys.Up:
                    case Keys.Left:
                        if(_overrideRadioButton.Focused)
                        {
                            _defaultRadioButton.Focus();
                            return true;
                        }
                        else if(_defaultRadioButton.Focused)
                        {
                            _overrideRadioButton.Focus();
                            return true;
                        }
                        break;
                }
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void _overrideRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            _overrideComboBox.Enabled = _overrideRadioButton.Checked;
        }
    }
}