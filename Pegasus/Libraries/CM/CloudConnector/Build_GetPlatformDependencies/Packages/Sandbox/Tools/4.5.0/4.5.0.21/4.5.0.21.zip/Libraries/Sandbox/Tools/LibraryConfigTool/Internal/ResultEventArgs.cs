using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryConfigTool.Internal
{
    internal sealed class ResultEventArgs : EventArgs
    {
        public ResultEventArgs(OutputType outputType, IndentAction indentAction, String description)
            : this(outputType, indentAction, description, null)
        {
        }

        public ResultEventArgs(OutputType outputType, IndentAction indentAction, String description, String details)
        {
            _outputType = outputType;
            _indentAction = indentAction;
            _description = description;
            _details = details;
        }

        public OutputType OutputType
        {
            get
            {
                return _outputType;
            }
        }

        public IndentAction IndentAction
        {
            get
            {
                return _indentAction;
            }
        }

        public String Description
        {
            get
            {
                return _description;
            }
        }

        public String Details
        {
            get
            {
                return _details;
            }
        }

        private OutputType _outputType;
        private IndentAction _indentAction;
        private String _description;
        private String _details;
    }
}
