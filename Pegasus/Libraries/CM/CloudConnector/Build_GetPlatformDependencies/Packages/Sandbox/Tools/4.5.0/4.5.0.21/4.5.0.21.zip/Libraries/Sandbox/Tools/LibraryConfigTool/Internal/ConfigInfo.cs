using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Diagnostics;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using System.Linq;
using System.Collections;

namespace LibraryConfigTool.Internal
{
    internal sealed class ConfigInfo
    {
        #region Constructor

        /// <summary>
        /// Construct an instance of the ConfigInfo class
        /// </summary>
        /// <param name="configFile"></param>
        public ConfigInfo(String configFile)
            : this(configFile, new List<KeyValuePair<String, String>>().AsReadOnly())
        {
        }

        /// <summary>
        /// Construct an instance of the ConfigInfo class
        /// </summary>
        /// <param name="configFile"></param>
        /// <param name="variables"></param>
        public ConfigInfo(String configFile, ReadOnlyCollection<KeyValuePair<String, String>> variables)
        {
            Debug.Assert(!String.IsNullOrEmpty(configFile));
            Debug.Assert(variables != null);

            if (!File.Exists(configFile))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.FileNotFoundFormat, configFile);
                throw new FileNotFoundException(errorMessage, configFile);
            }

            foreach (KeyValuePair<String, String> keyValuePair in variables)
            {
                DefineSystemVariable(keyValuePair.Key, keyValuePair.Value);
            }

            _configFile = Path.GetFullPath(configFile);
            LoadFromConfigFile();
        }

        #endregion

        #region Public properties
        /// <summary>
        /// Return the name and path of the library config file used to populate this object
        /// </summary>
        public String ConfigFile
        { get { return _configFile; } }

        //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
        public ReadOnlyCollection<LibraryReference> LibraryReferences
        {
            get
            {
                List<LibraryReference> result = new List<LibraryReference>();

                foreach (ConfigInfo configInfo in _configInfo)
                {
                    result.AddRange(configInfo.LibraryReferences);
                }

                result.AddRange(_libraryReferences);

                return result.AsReadOnly();
            }
        }

        public ReadOnlyCollection<Reference> References
        {
            get
            {
                List<Reference> result = new List<Reference>();

                foreach (ConfigInfo configInfo in _configInfo)
                {
                    result.AddRange(configInfo.References);
                }

                result.AddRange(_references);

                return result.AsReadOnly();
            }
        }

        public FileGroup FileGroup
        {
            get { return _fileGroup; }
            set { _fileGroup = value; }
        }

        public String ActionId
        { get { return _actionId; } }

        #endregion

        #region Public methods
        public String DoQuery(String query)
        {
            ExpandVariables();
            return ReplaceAllVariables(query);
        }

        public void DoAction(String id)
        {
            ActionStep actionStep = FindAction(id);
            if (actionStep == null)
            {
                using (BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, "Action failed; no action matching specified id was found.");
                    output.AddErrorDetail("Id", id);
                    output.EndWriteError();
                }
            }
            else
            {
                ExpandVariables();
                if (actionStep.RequiresTarget)
                {
                    ExpandTargetInfo(this, GetSystemVariableValue(Utils.GetVariableNameKeyForVariableName("TargetName")));
                }
                else
                {
                    ExpandTargetInfo(this);
                }
                VerifyAllTargetsAreUnique();
                if (actionStep.RequiresTarget)
                {
                    VerifyTargetDeclared();
                }
                DefineTargetNamesSystemVariable();
                DefineLibraryReferencesSystemVariable();
                DefineFileGroupsSystemVariables();
                DefineJitEvalCollectionVariable("System::LibraryUniqueNamesForReferences");
                DefineJitEvalCollectionVariable("System::LibraryConfigFilesForReferences");
                DefineJitEvalCollectionVariable("System::LibraryUniqueNamesForImplicitReferences");
                DefineJitEvalCollectionVariable("System::LibraryConfigFilesForImplicitReferences");
                DefineJitEvalCollectionVariable("System::BuildPassVariableNames");

                String saveActionId = _actionId;
                try
                {
                    _actionId = id;
                    DoAction(this, id);
                }
                finally
                {
                    _actionId = saveActionId;
                }
            }
        }

        public void DoAction(ConfigInfo rootConfigInfo, String id)
        {
            Program.Output.Write(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "Processing action '{0}' in '{1}'...", id, _configFile));

            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                foreach (ConfigInfo configInfo in _configInfo)
                {
                    configInfo.DoAction(rootConfigInfo, id);
                }

                if (_actionStepsById.ContainsKey(id))
                {
                    _actionStepsById[id].Execute(rootConfigInfo);
                }
            }
        }

        private void ClearActionSteps(Boolean recursive)
        {
            if (recursive)
            {
                foreach (ConfigInfo configInfo in _configInfo)
                {
                    configInfo.ClearActionSteps(recursive);
                }
            }

            _actionStepsById.Clear();
        }

        private ActionStep FindAction(String id)
        {
            ActionStep result = null;

            foreach (ConfigInfo configInfo in _configInfo)
            {
                result = configInfo.FindAction(id);
                if (result != null)
                {
                    break;
                }
            }

            if (result == null)
            {
                _actionStepsById.TryGetValue(id, out result);   // returns null if not found
            }

            return result;
        }

        //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
        private ReadOnlyCollection<BuildInfoItem> BuildInfoItems
        {
            get
            {
                List<BuildInfoItem> result = new List<BuildInfoItem>();

                foreach (ConfigInfo configInfo in _configInfo)
                {
                    result.AddRange(configInfo.BuildInfoItems);
                }

                result.AddRange(_buildInfoItems);

                return result.AsReadOnly();
            }
        }

        public Boolean IsTargetGroupDefined(String id)
        {
            Boolean result = false;

            foreach (ConfigInfo configInfo in _configInfo)
            {
                if (configInfo.IsTargetGroupDefined(id))
                {
                    result = true;
                    break;
                }
            }

            if (!result)
            {
                result = _targetGroups.ContainsKey(id);
            }

            return result;
        }

        public ReadOnlyCollection<String> TargetGroupIds
        {
            get
            {
                List<String> result = new List<String>();

                foreach (ConfigInfo configInfo in _configInfo)
                {
                    result.AddRange(configInfo.TargetGroupIds);
                }

                result.AddRange(_targetGroups.Keys);

                return result.AsReadOnly();
            }
        }

        public TargetGroup GetTargetGroupForId(String id)
        {
            TargetGroup result = null;

            foreach (ConfigInfo configInfo in _configInfo)
            {
                if (configInfo.IsTargetGroupDefined(id))
                {
                    result = configInfo.GetTargetGroupForId(id);
                    break;
                }
            }

            if (result == null && _targetGroups.ContainsKey(id))
            {
                result = _targetGroups[id];
            }

            return result;
        }

        public ReadOnlyCollection<String> VariableNameKeys
        {
            get
            {
                List<String> result = new List<String>();

                foreach (ConfigInfo configInfo in _configInfo)
                {
                    result.AddRange(configInfo.VariableNameKeys);
                }

                result.AddRange(_variables.Keys);

                return result.AsReadOnly();
            }
        }

        public ReadOnlyCollection<KeyValuePair<String, String>> Variables
        {
            get
            {
                List<KeyValuePair<String, String>> result = new List<KeyValuePair<String, String>>();

                ReadOnlyCollection<String> internalVariableNames = VariableNameKeys;

                // remove duplicates
                StringCollection uniqueInternalVariableNames = new StringCollection();
                foreach (String internalVariableName in internalVariableNames)
                {
                    if (!uniqueInternalVariableNames.Contains(internalVariableName))
                    {
                        uniqueInternalVariableNames.Add(internalVariableName);
                    }
                }

                foreach (String internalVariableName in uniqueInternalVariableNames)
                {
                    result.Add(new KeyValuePair<String, String>(internalVariableName, GetSystemVariableValue(internalVariableName)));
                }

                return result.AsReadOnly();
            }
        }

        public Boolean IsVariableDefined(String variableName)
        {
            Debug.Assert(!variableName.StartsWith("$(") && !variableName.EndsWith(")"));

            return IsSystemVariableDefined(Utils.GetVariableNameKeyForVariableName(variableName));
        }

        public Boolean IsSystemVariableDefined(String variableNameKey)
        {
            Debug.Assert(variableNameKey.StartsWith("$(") && variableNameKey.EndsWith(")"));
            Boolean result = false;

            foreach (ConfigInfo configInfo in _configInfo)
            {
                if (configInfo.IsSystemVariableDefined(variableNameKey))
                {
                    result = true;
                    break;
                }
            }

            if (!result)
            {
                result = _variables.ContainsKey(variableNameKey);
            }

            return result;
        }

        public String GetSystemVariableValue(String variableNameKey)
        {
            String result = null;

            foreach (ConfigInfo configInfo in _configInfo)
            {
                if (configInfo.IsSystemVariableDefined(variableNameKey))
                {
                    result = configInfo.GetSystemVariableValue(variableNameKey);
                    break;
                }
            }

            if (result == null && _variables.ContainsKey(variableNameKey))
            {
                result = _variables[variableNameKey];
            }

            return result;
        }

        public Boolean IsCollectionVariableDefined(String variableNameKey)
        {
            Boolean result = false;

            foreach (ConfigInfo configInfo in _configInfo)
            {
                if (configInfo.IsCollectionVariableDefined(variableNameKey))
                {
                    result = true;
                    break;
                }
            }

            if (!result)
            {
                result = _collectionVariables.ContainsKey(variableNameKey);
            }

            return result;
        }

        public Boolean IsFileGroupDefined(String id)
        {
            Boolean result = false;

            foreach (ConfigInfo configInfo in _configInfo)
            {
                if (configInfo.IsFileGroupDefined(id))
                {
                    result = true;
                    break;
                }
            }

            if (!result)
            {
                result = _fileGroups.ContainsKey(id);
            }

            return result;
        }

        public ReadOnlyCollection<String> FileGroupIds
        {
            get
            {
                List<String> result = new List<String>();

                foreach (ConfigInfo configInfo in _configInfo)
                {
                    result.AddRange(configInfo.FileGroupIds);
                }

                result.AddRange(_fileGroups.Keys);

                return result.AsReadOnly();
            }
        }

        public FileGroup GetFileGroupForId(String id)
        {
            FileGroup result = null;

            foreach (ConfigInfo configInfo in _configInfo)
            {
                if (configInfo.IsFileGroupDefined(id))
                {
                    result = configInfo.GetFileGroupForId(id);
                    break;
                }
            }

            if (result == null && _fileGroups.ContainsKey(id))
            {
                result = _fileGroups[id];
            }

            return result;
        }

        public ReadOnlyCollection<String> CollectionVariableNameKeys
        {
            get
            {
                List<String> result = new List<String>();

                foreach (ConfigInfo configInfo in _configInfo)
                {
                    result.AddRange(configInfo.CollectionVariableNameKeys);
                }

                result.AddRange(_collectionVariables.Keys);

                return result.AsReadOnly();
            }
        }

        public ReadOnlyCollection<String> GetCollectionVariableValue(String variableName)
        {
            ReadOnlyCollection<String> result = null;

            foreach (ConfigInfo configInfo in _configInfo)
            {
                if (configInfo.IsCollectionVariableDefined(variableName))
                {
                    result = configInfo.GetCollectionVariableValue(variableName);
                    break;
                }
            }

            if (result == null && _collectionVariables.ContainsKey(variableName))
            {
                if (_collectionVariables[variableName] == null)
                {
                    Match match = Regex.Match(variableName, @"(.*)(\$\(System::FileGroups::[^\$\(\):]+\))(.*)", RegexOptions.CultureInvariant);
                    if (match.Success)
                    {
                        String prefix = "$(System::FileGroups::";
                        String fileGroupName = match.Groups[2].Value.Substring(prefix.Length).TrimEnd(')');
                        _collectionVariables[variableName] = new List<String>(GetFileGroupForId(fileGroupName).GetMatchingFiles(this));
                    }
                    else
                    {
                        match = Regex.Match(variableName, @"(.*)(\$\(System::TargetGroups::[^\$\(\):]+\))(.*)", RegexOptions.CultureInvariant);
                        if (match.Success)
                        {
                            String prefix = "$(System::TargetGroups::";
                            String targetGroupName = match.Groups[2].Value.Substring(prefix.Length).TrimEnd(')');

                            List<String> targetNames = new List<String>();
                            ReadOnlyCollection<TargetInfo> targetInfoItems = GetTargetGroupForId(targetGroupName).TargetInfoItems;
                            foreach (TargetInfo targetInfo in targetInfoItems)
                            {
                                targetNames.AddRange(targetInfo.Names);
                            }

                            _collectionVariables[variableName] = targetNames;
                        }
                        else
                        {
                            // Performance optimization:  don't evaluate the following collections unless necessary because it is expensive:
                            //      $(System::LibraryConfigFilesForImplicitReferences)
                            //      $(System::LibraryUniqueNamesForReferences)
                            //      $(System::LibraryConfigFilesForReferences)
                            //      $(System::BuildPassVariableNames)
                            if (Regex.Match(variableName, @"(.*)(\$\(System::LibraryUniqueNamesForImplicitReferences\))(.*)", RegexOptions.CultureInvariant).Success ||
                                Regex.Match(variableName, @"(.*)(\$\(System::LibraryConfigFilesForImplicitReferences\))(.*)", RegexOptions.CultureInvariant).Success ||
                                Regex.Match(variableName, @"(.*)(\$\(System::LibraryUniqueNamesForReferences\))(.*)", RegexOptions.CultureInvariant).Success ||
                                Regex.Match(variableName, @"(.*)(\$\(System::LibraryConfigFilesForReferences\))(.*)", RegexOptions.CultureInvariant).Success ||
                                Regex.Match(variableName, @"(.*)(\$\(System::BuildPassVariableNames\))(.*)", RegexOptions.CultureInvariant).Success)
                            {
                                EvaluateReferences();
                            }
                        }
                    }
                }

                result = _collectionVariables[variableName].AsReadOnly();
            }

            return result;
        }

        public static void ValidateVariableName(String name)
        {
            if (name.Contains("::") || name.IndexOfAny(new char[] { '$', '(', ')' }) != -1)
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.InvalidVariableNameFormat, name);
                throw new Exception(errorMessage);
            }
        }

        public void DefineVariable(String variableName, String variableValue)
        {
            ValidateVariableName(variableName);

            if (IsVariableDefined(variableName))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.DuplicateVariableDefinitionFormat, variableName);
                throw new LibraryConfigSchemaException(_configFile, errorMessage);
            }

            DefineSystemVariable(Utils.GetVariableNameKeyForVariableName(variableName), variableValue);
        }

        public void DefineSystemVariable(String variableNameKey, String variableValue)
        {
            Debug.Assert(variableNameKey.StartsWith("$(") && variableNameKey.EndsWith(")"));
            Debug.Assert(!IsSystemVariableDefined(variableNameKey));

            // normalize null to empty
            if (variableValue == null)
            {
                variableValue = String.Empty;
            }

            Program.Output.Write(OutputType.Verbose, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Define '{0}' = '{1}'", variableNameKey, variableValue));
            _variables.Add(variableNameKey, variableValue);
        }

        public void UndefineVariable(String variableName)
        {
            Debug.Assert(IsVariableDefined(variableName));

            ValidateVariableName(variableName);

            UndefineSystemVariable(Utils.GetVariableNameKeyForVariableName(variableName), true);
        }

        public void UndefineSystemVariable(String variableNameKey, Boolean recursive)
        {
            Debug.Assert(variableNameKey.StartsWith("$(") && variableNameKey.EndsWith(")"));
            Debug.Assert(IsSystemVariableDefined(variableNameKey));

            if (recursive)
            {
                foreach (ConfigInfo configInfo in _configInfo)
                {
                    if (configInfo.IsSystemVariableDefined(variableNameKey))
                    {
                        configInfo.UndefineSystemVariable(variableNameKey, recursive);
                    }
                }
            }

            Program.Output.Write(OutputType.Verbose, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Undefine '{0}'", variableNameKey));
            _variables.Remove(variableNameKey);
        }

        public String ReplaceAllVariables(String input)
        {
            String result = input;
            ReadOnlyCollection<String> targetNames = GetCollectionVariableValue("$(System::TargetNames)");

            Boolean somethingReplaced = false;
            do
            {
                somethingReplaced = false;

                // Performance optimization:  rather than reading the entire registry up front and storing
                // all values as LibraryConfigTool variables, we read/replace registry values just-in-time.
                // Supported syntax for registry variables is:
                //
                //   $(Environment::Registry::<KeyName>\<ValueName>)
                //
                // E.g.,  $(Environment::Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft SDKs\Windows\CurrentInstallFolder)
                // evaluates to the value of CurrentInstallFolder in the "SOFTWARE\Microsoft\Microsoft SDKs\Windows" key
                // under the HKLM hive.
                String newResult = ReplaceRegistryVariable(result);
                if (newResult != result)
                {
                    result = newResult;
                    somethingReplaced = true;
                }

                if (!somethingReplaced)
                {
                    newResult = ReplaceFunctionCall(result);
                    if (newResult != result)
                    {
                        result = newResult;
                        somethingReplaced = true;
                    }
                }

                if (!somethingReplaced)
                {
                    // Performance optimization:  each Target supports the notion of overriding the global variables via
                    // the a Setting specified for a given Target.  Rather than defining target-specific variables
                    // for each and every global Variable X Target combination, we first check to see if a Target
                    // has explicitly specified a Setting override ... if it hasn't, then we default its value
                    // to be the global setting.
                    newResult = ReplaceTargetSettingVariable(targetNames, result);
                    if (newResult != result)
                    {
                        result = newResult;
                        somethingReplaced = true;
                    }
                }

                if (!somethingReplaced)
                {
                    foreach (String internalVariableName in VariableNameKeys)
                    {
                        if (result.Contains(internalVariableName))
                        {
                            result = result.Replace(internalVariableName, GetSystemVariableValue(internalVariableName));
                            somethingReplaced = true;
                        }
                    }
                }
            }
            while (somethingReplaced);

            VerifyAllVariablesReplaced(result);

            return result;
        }

        public void OpenEmitWriter(EmitType emitType, String id, String filePath, String zipRoot, Boolean openExisting)
        {
            if (emitType == EmitType.Xml)
            {
                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.CloseOutput = true;
                xmlWriterSettings.ConformanceLevel = ConformanceLevel.Document;
                xmlWriterSettings.Encoding = Encoding.UTF8;
                xmlWriterSettings.NewLineHandling = NewLineHandling.Entitize;
                xmlWriterSettings.OmitXmlDeclaration = false;

                XmlWriter xmlWriter = XmlWriter.Create(filePath, xmlWriterSettings);

                _emitWriters.Add(id, xmlWriter);
            }
            else if (emitType == EmitType.Txt)
            {
                StreamWriter streamWriter = new StreamWriter(filePath, openExisting);
                _emitWriters.Add(id, streamWriter);
            }
            else if (emitType == EmitType.Zip)
            {
                ZipEmitWriter zipEmitWriter = new ZipEmitWriter(filePath, zipRoot);
                _emitWriters.Add(id, zipEmitWriter);
            }
        }

        public void EmitData(String id, String data)
        {
            Object writer = _emitWriters[id];
            if (writer is XmlWriter)
            {
                (writer as XmlWriter).WriteRaw(data);
            }
            else if (writer is StreamWriter)
            {
                (writer as StreamWriter).Write(data);
            }
            else if (writer is ZipEmitWriter)
            {
                (writer as ZipEmitWriter).Write(data);
            }
        }

        public void CloseEmitWriter(String id)
        {
            Object writer = _emitWriters[id];
            if (writer is XmlWriter)
            {
                XmlWriter xmlWriter = (writer as XmlWriter);

                xmlWriter.Flush();
                xmlWriter.Close();
                (xmlWriter as IDisposable).Dispose();
            }
            else if (writer is StreamWriter)
            {
                StreamWriter streamWriter = (writer as StreamWriter);

                streamWriter.Flush();
                streamWriter.Close();
                (streamWriter as IDisposable).Dispose();
            }
            else if (writer is ZipEmitWriter)
            {
                ZipEmitWriter zipEmitWriter = (writer as ZipEmitWriter);

                zipEmitWriter.Flush();
                zipEmitWriter.Close();
                (zipEmitWriter as IDisposable).Dispose();
            }
            _emitWriters.Remove(id);
        }
        #endregion

        #region Private Methods

        private void LoadFromConfigFile()
        {
            Program.Output.Write(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "Parsing '{0}'...", _configFile));
            try
            {
                using (IndentedOutput indentedOutput = new IndentedOutput())
                {
                    XPathNavigator documentNavigator = null;
                    try
                    {
                        documentNavigator = new XPathDocument(_configFile, XmlSpace.Default).CreateNavigator();
                    }
                    catch (XmlException ex)
                    {
                        throw new LibraryConfigSchemaException(_configFile, Strings.ErrorInLibrayConfigSchema, ex);
                    }

                    ProcessIncludes(documentNavigator);
                    ProcessReferences(documentNavigator);
                    ProcessVariables(documentNavigator);
                    ProcessLibraryReferences(documentNavigator);
                    ProcessBuildInfo(documentNavigator);
                    ProcessTargetGroups(documentNavigator);
                    ProcessFileGroups(documentNavigator);
                    ProcessActions(documentNavigator);
                }
            }
            finally
            {
                Program.Output.Write(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "Finished parsing '{0}'...", _configFile));
            }
        }

        private void ProcessIncludes(XPathNavigator documentNavigator)
        {
            Program.Output.Write(OutputType.Verbose, "Parsing includes...");
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = documentNavigator.Select(Constants.IncludesExpression);
                while (iterator.MoveNext())
                {
                    String includePath = Utils.GetRequiredAttribute(iterator.Current, Constants.PathAttribute, Constants.IncludesExpression, _configFile);

                    includePath = includePath.Replace(Utils.GetVariableNameKeyForVariableName("System::SandboxDir"), Utils.SandboxLocation);
                    VerifyAllVariablesReplaced(includePath);

                    // special handling because the variables have not been read and expanded yet;  the only variable safe to use in an Include element is $(System::SandboxDir)
                    ConfigInfo configInfo = new ConfigInfo(includePath);


                    // Multiple shared libraries may have the same library references 
                    // so make sure we only process an encountered library one time.
                    ConfigInfoFinder finder = new ConfigInfoFinder(configInfo.ConfigFile);
                    ConfigInfo previousConfigInfo = _configInfo.Find(new Predicate<ConfigInfo>(finder.HasSameName));
                    if (previousConfigInfo == null)
                    {
                        _configInfo.Add(configInfo);
                    }
                    else
                    {
                        // Only one version of a library is allowed per AppDomain
                        if (Convert.ToBase64String(Utils.GetMD5HashForFileContent(previousConfigInfo.ConfigFile)) != Convert.ToBase64String(Utils.GetMD5HashForFileContent(configInfo.ConfigFile)))
                        {
                            String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.TwoVersionsOfSameConfigErrorFormat, configInfo.ConfigFile);
                            throw new MultipleConfigVersionsException(configInfo.ConfigFile, errorMessage);
                        }
                    }
                }
            }
        }

        private void ProcessReferences(XPathNavigator documentNavigator)
        {
            Program.Output.Write(OutputType.Verbose, "Parsing References...");
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = documentNavigator.Select(Constants.ReferencesExpression);
                while (iterator.MoveNext())
                {
                    _references.Add(new Reference(this, iterator.Current));
                }
            }
        }

        private void ProcessVariables(XPathNavigator documentNavigator)
        {
            Program.Output.Write(OutputType.Verbose, "Parsing variables...");
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = documentNavigator.Select(Constants.VariablesExpression);
                while (iterator.MoveNext())
                {
                    Program.Output.Write(OutputType.Verbose, "Adding variable:");
                    String name = Utils.GetRequiredAttribute(iterator.Current, Constants.NameAttribute, Constants.VariablesExpression, _configFile);
                    String value = Utils.GetOptionalAttribute(iterator.Current, Constants.ValueAttribute);
                    String overrideInclude = Utils.GetOptionalAttribute(iterator.Current, Constants.OverrideAttribute);
                    if (!String.IsNullOrEmpty(overrideInclude) && Boolean.Parse(overrideInclude))
                    {
                        Program.Output.Write(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "Overriding Variable elements with Name '{0}' inherited through inclusion.", name));
                        foreach (ConfigInfo configInfo in _configInfo)
                        {
                            if (configInfo.IsVariableDefined(name))
                            {
                                Program.Output.Write(OutputType.Verbose, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Overriding Variable element included through '{0}'.", configInfo.ConfigFile));
                                configInfo.UndefineVariable(name);
                            }
                        }
                    }

                    DefineVariable(name, value);
                }

                iterator = documentNavigator.Select(Constants.CollectionVariablesExpression);
                while (iterator.MoveNext())
                {
                    Program.Output.Write(OutputType.Verbose, "Adding collection variable:");
                    String name = Utils.GetRequiredAttribute(iterator.Current, Constants.NameAttribute, Constants.CollectionVariablesExpression, _configFile);

                    String variableName = Utils.GetVariableNameKeyForVariableName(name);
                    if (IsCollectionVariableDefined(variableName))
                    {
                        String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.DuplicateCollectionVariableDefinitionFormat, name);
                        throw new LibraryConfigSchemaException(_configFile, errorMessage);
                    }

                    using (IndentedOutput indentedOutputForCollectionVariable = new IndentedOutput())
                    {
                        Program.Output.Write(OutputType.Verbose, "Adding elements:");
                        List<String> collectionVariable = new List<String>();
                        XPathNodeIterator itemIterator = iterator.Current.Select(Constants.ElementExpression);
                        while (itemIterator.MoveNext())
                        {
                            String value = Utils.GetOptionalAttribute(itemIterator.Current, Constants.ValueAttribute);

                            // normalize null to empty
                            if (value == null)
                            {
                                value = String.Empty;
                            }

                            collectionVariable.Add(value);
                        }

                        _collectionVariables.Add(variableName, collectionVariable);
                    }
                }
            }
        }

        //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
        private void ProcessLibraryReferences(XPathNavigator documentNavigator)
        {
            Program.Output.Write(OutputType.Verbose, "Parsing LibraryReferences...");
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = documentNavigator.Select(Constants.LibraryReferencesExpression);
                while (iterator.MoveNext())
                {
                    _libraryReferences.Add(new LibraryReference(this, iterator.Current));
                }
            }
        }

        //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
        private void ProcessBuildInfo(XPathNavigator documentNavigator)
        {
            Program.Output.Write(OutputType.Verbose, "Parsing BuildInfo...");
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = documentNavigator.Select(Constants.BuildInfoExpression);
                while (iterator.MoveNext())
                {
                    _buildInfoItems.Add(BuildInfoItem.Create(this, iterator.Current));
                }
            }
        }

        private void ProcessTargetGroups(XPathNavigator documentNavigator)
        {
            Program.Output.Write(OutputType.Verbose, "Parsing TargetGroups...");
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = documentNavigator.Select(Constants.TargetGroupsExpression);
                while (iterator.MoveNext())
                {
                    TargetGroup targetGroup = new TargetGroup(this, iterator.Current);
                    _targetGroups.Add(targetGroup.Id, targetGroup);

                    // also create BuildInfoItems for everything in the Target Group
                    _buildInfoItems.Add(new BuildInfoItem(targetGroup));
                }
            }
        }

        private void ProcessFileGroups(XPathNavigator documentNavigator)
        {
            Program.Output.Write(OutputType.Verbose, "Parsing FileGroups...");
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = documentNavigator.Select(Constants.FileGroupsExpression);
                while (iterator.MoveNext())
                {
                    FileGroup fileGroup = new FileGroup(this, iterator.Current);
                    _fileGroups.Add(fileGroup.Id, fileGroup);
                }
            }
        }

        private void ProcessActions(XPathNavigator documentNavigator)
        {
            if (Program.Action)
            {
                Program.Output.Write(OutputType.Verbose, "Parsing Actions...");

                XPathNavigator navigator = documentNavigator.SelectSingleNode(Constants.ActionsExpression);
                if (navigator != null)
                {
                    String overrideInclude = Utils.GetOptionalAttribute(navigator, Constants.OverrideAttribute);
                    if (!String.IsNullOrEmpty(overrideInclude) && Boolean.Parse(overrideInclude))
                    {
                        Program.Output.Write(OutputType.Verbose, "Overriding Actions elements inherited through inclusion.");
                        foreach (ConfigInfo configInfo in _configInfo)
                        {
                            configInfo.ClearActionSteps(true);
                        }
                    }

                    using (IndentedOutput indentedOutput = new IndentedOutput())
                    {
                        XPathNodeIterator iterator = navigator.SelectChildren(XPathNodeType.Element);
                        while (iterator.MoveNext())
                        {
                            ActionStep actionStep = (StepFactory.Create(this, iterator.Current) as ActionStep);
                            _actionStepsById.Add(actionStep.Id, actionStep);
                        }
                    }
                }
            }
        }

        private void ExpandVariables()
        {
            Program.Output.Write(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "Expanding variables '{0}'...", _configFile));

            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                foreach (ConfigInfo configInfo in _configInfo)
                {
                    configInfo.ExpandVariables();
                }

                ReadOnlyCollection<String> internalVariableNames = VariableNameKeys;
                if (!internalVariableNames.Contains(Utils.GetVariableNameKeyForVariableName("System::SandboxDir")))
                {
                    DefineSystemVariable(Utils.GetVariableNameKeyForVariableName("System::SandboxDir"), Utils.SandboxLocation);
                    internalVariableNames = VariableNameKeys;
                }

                Boolean somethingReplaced = false;
                List<String> keysToUpdate = new List<String>();
                do
                {
                    somethingReplaced = false;

                    foreach (String key in internalVariableNames)
                    {
                        keysToUpdate.Clear();

                        foreach (KeyValuePair<String, String> keyValuePair in _variables)
                        {
                            if (keyValuePair.Value.Contains(key))
                            {
                                keysToUpdate.Add(keyValuePair.Key);
                                somethingReplaced = true;
                            }
                        }

                        foreach (String keyToUpdate in keysToUpdate)
                        {
                            _variables[keyToUpdate] = _variables[keyToUpdate].Replace(key, GetSystemVariableValue(key));
                        }
                    }
                }
                while (somethingReplaced);

            }
        }

        private void ExpandTargetInfo(ConfigInfo rootConfigInfo)
        {
            ExpandTargetInfo(rootConfigInfo, String.Empty);
        }

        private void ExpandTargetInfo(ConfigInfo rootConfigInfo, String targetName)
        {
            Program.Output.Write(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "Expanding target info '{0}'...", _configFile));

            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                foreach (ConfigInfo configInfo in _configInfo)
                {
                    configInfo.ExpandTargetInfo(rootConfigInfo, targetName);
                }

                foreach (BuildInfoItem buildInfoItem in _buildInfoItems)
                {
                    foreach (TargetInfo targetInfoItem in buildInfoItem.TargetInfoItems)
                    {
                        targetInfoItem.Expand(rootConfigInfo, targetName);
                    }
                }
            }
        }

        private void VerifyAllVariablesReplaced(String input)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(@"\$\(.*\)");
            if (regex.IsMatch(input))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.UnresolvedVariableDefinitionFormat, regex.Match(input).ToString(), input);
                throw new LibraryConfigSchemaException(_configFile, errorMessage);
            }
        }

        private void VerifyAllTargetsAreUnique()
        {
            ReadOnlyCollection<BuildInfoItem> buildInfoItems = BuildInfoItems;

            StringCollection targetNames = new StringCollection();
            foreach (BuildInfoItem buildInfoItem in buildInfoItems)
            {
                foreach (TargetInfo targetInfo in buildInfoItem.TargetInfoItems)
                {
                    foreach (String name in targetInfo.Names)
                    {
                        if (targetNames.Contains(name))
                        {
                            String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.DuplicateTargetErrorFormat, name);
                            throw new LibraryConfigSchemaException(ConfigFile, errorMessage);
                        }
                        else
                        {
                            targetNames.Add(name);
                        }
                    }
                }
            }
        }

        private void VerifyTargetDeclared()
        {
            ReadOnlyCollection<BuildInfoItem> buildInfoItems = BuildInfoItems;
            Boolean foundTarget = false;
            String targetName = GetSystemVariableValue(Utils.GetVariableNameKeyForVariableName("TargetName"));
            foreach (BuildInfoItem buildInfoItem in buildInfoItems)
            {
                foreach (TargetInfo targetInfo in buildInfoItem.TargetInfoItems)
                {
                    foreach (String name in targetInfo.Names)
                    {
                        if (String.Compare(name, targetName, false, CultureInfo.InvariantCulture) == 0)
                        {
                            foundTarget = true;
                        }
                    }
                }
            }

            if (!foundTarget)
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.TargetNotDeclaredErrorFormat, targetName);
                throw new LibraryConfigSchemaException(ConfigFile, errorMessage);
            }
        }

        private void DefineTargetNamesSystemVariable()
        {
            String variableName = Utils.GetVariableNameKeyForVariableName("System::TargetNames");
            if (IsCollectionVariableDefined(variableName))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.DuplicateCollectionVariableDefinitionFormat, _configFile, variableName);
                throw new LibraryConfigSchemaException(_configFile, errorMessage);
            }

            ReadOnlyCollection<BuildInfoItem> buildInfoItems = BuildInfoItems;
            List<String> collectionVariable = new List<String>();
            foreach (BuildInfoItem buildInfoItem in buildInfoItems)
            {
                foreach (TargetInfo targetInfo in buildInfoItem.TargetInfoItems)
                {
                    foreach (String targetName in targetInfo.Names)
                    {
                        collectionVariable.Add(targetName);
                    }
                }
            }

            foreach (String targetGroupId in TargetGroupIds)
            {
                String targetGroupVariableName = Utils.GetVariableNameKeyForVariableName(String.Format("System::TargetGroups::{0}", targetGroupId));
                if (IsCollectionVariableDefined(targetGroupVariableName))
                {
                    String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.DuplicateCollectionVariableDefinitionFormat, _configFile, targetGroupVariableName);
                    throw new LibraryConfigSchemaException(_configFile, errorMessage);
                }

                // declare the collection variable now;  but lazy-init it so as to avoid a performance hit just parsing the file
                _collectionVariables.Add(targetGroupVariableName, null);
            }

            _collectionVariables.Add(variableName, collectionVariable);
        }

        private void DefineLibraryReferencesSystemVariable()
        {
            String variableName = Utils.GetVariableNameKeyForVariableName("System::LibraryReferenceManifests");
            if (IsCollectionVariableDefined(variableName))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.DuplicateCollectionVariableDefinitionFormat, _configFile, variableName);
                throw new LibraryConfigSchemaException(_configFile, errorMessage);
            }

            ReadOnlyCollection<LibraryReference> libraryReferences = LibraryReferences;
            List<String> collectionVariable = new List<String>();
            foreach (LibraryReference libraryReference in libraryReferences)
            {
                collectionVariable.Add(Utils.GetLibraryManfiestFileName(libraryReference.LibrarySetId, libraryReference.LibraryName));
            }

            _collectionVariables.Add(variableName, collectionVariable);
        }


        private void DefineFileGroupsSystemVariables()
        {
            foreach (String fileGroupId in FileGroupIds)
            {
                String variableName = Utils.GetVariableNameKeyForVariableName(String.Format("System::FileGroups::{0}", fileGroupId));
                if (IsCollectionVariableDefined(variableName))
                {
                    String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.DuplicateCollectionVariableDefinitionFormat, _configFile, variableName);
                    throw new LibraryConfigSchemaException(_configFile, errorMessage);
                }

                // declare the collection variable now;  but lazy-init it so as to avoid a performance hit just parsing the file
                _collectionVariables.Add(variableName, null);
            }
        }

        private void DefineJitEvalCollectionVariable(String name)
        {
            String variableName = Utils.GetVariableNameKeyForVariableName(name);
            if (IsCollectionVariableDefined(variableName))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.DuplicateCollectionVariableDefinitionFormat, _configFile, variableName);
                throw new LibraryConfigSchemaException(_configFile, errorMessage);
            }

            // declare the collection variable now;  but lazy-init it so as to avoid a performance hit just parsing the file
            _collectionVariables.Add(variableName, null);
        }

        private void DefineBuildPassSystemVariable(String name, IEnumerable<String> values)
        {
            String variableName = Utils.GetVariableNameKeyForVariableName(name);
            if (IsCollectionVariableDefined(variableName))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.DuplicateCollectionVariableDefinitionFormat, _configFile, variableName);
                throw new LibraryConfigSchemaException(_configFile, errorMessage);
            }

            _collectionVariables.Add(variableName, values.ToList());
        }

        private String ReplaceFunctionCall(String input)
        {
            String result = input;

            if (FunctionEvaluator.IsFunction(input))
            {
                result = FunctionEvaluator.Evaluate(this, input);
            }

            return result;
        }

        private String ReplaceRegistryVariable(String input)
        {
            String result = input;

            Match match = Regex.Match(result, @"(.*)(\$\(Environment::Registry::[^\$\(\):]+\))(.*)", RegexOptions.CultureInvariant);
            if (match.Success)
            {
                String prefix = "$(Environment::Registry::";
                String valuePath = match.Groups[2].Value.Substring(prefix.Length).TrimEnd(')');
                String keyName = valuePath.Substring(0, valuePath.LastIndexOf('\\'));
                String valueName = valuePath.Substring(keyName.Length + 1);
                String value = (String)Microsoft.Win32.Registry.GetValue(keyName, valueName, String.Empty);
                result = result.Replace(match.Groups[2].Value, value);
            }

            return result;
        }


        private void EvaluateReferences()
        {
            List<String> result = new List<String>();

            Program.Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "Locating all LibraryConfig-Library.xml files in '{0}'...", Utils.SandboxLocation));

            // load all LibraryConfig in the sandbox; read all explicit dependencies mentioned in each config
            String[] allLibraryConfigFileNames = Directory.GetFiles(Utils.SandboxLocation, Constants.LibraryConfigFileName, SearchOption.AllDirectories);
            Program.Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "{0} files found.", allLibraryConfigFileNames.Length));
            Dictionary<String, String> libraryConfigFilesByLibraryUniqueName = new Dictionary<String, String>();
            Dictionary<String, List<String>> explicitReferencesByLibraryUniqueName = new Dictionary<String, List<String>>();
            foreach (String libraryConfigFileName in allLibraryConfigFileNames)
            {
                Program.Output.Write(OutputType.Info, String.Format(CultureInfo.CurrentCulture, "Reading explicit references in '{0}'...", libraryConfigFileName));
                ConfigInfo configInfo = new ConfigInfo(libraryConfigFileName);
                String uniqueName = Reference.FormatUniqueName(configInfo.DoQuery("$(LibrarySetId)"), configInfo.DoQuery("$(LibraryName)"));
                libraryConfigFilesByLibraryUniqueName.Add(uniqueName, libraryConfigFileName);
                explicitReferencesByLibraryUniqueName.Add(uniqueName, configInfo.References.Select(x => x.UniqueName).ToList());
            }


            // return results by looking up the library in the explicitReferencesByLibraryUniqueName container that
            // is the same as the root config file we are processing
            List<String> myExplicitReferencesLibraryConfigFiles = new List<String>();
            String myUniqueName = Reference.FormatUniqueName(DoQuery("$(LibrarySetId)"), DoQuery("$(LibraryName)"));
            List<String> myExplicitReferences = explicitReferencesByLibraryUniqueName[myUniqueName];
            foreach (String libraryUniqueName in explicitReferencesByLibraryUniqueName.Keys)
            {
                if (myExplicitReferences.Contains(libraryUniqueName))
                {
                    myExplicitReferencesLibraryConfigFiles.Add(libraryConfigFilesByLibraryUniqueName[libraryUniqueName]);
                }
            }
            _collectionVariables[Utils.GetVariableNameKeyForVariableName("System::LibraryUniqueNamesForReferences")] = myExplicitReferences;
            _collectionVariables[Utils.GetVariableNameKeyForVariableName("System::LibraryConfigFilesForReferences")] = myExplicitReferencesLibraryConfigFiles;



            // infer all effective dependencies by starting at the bottom of the dependency graph (those libraries dependent on nothing) and
            // working upward to those that are effectively dependent on the most stuff
            Program.Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "Analyzing libraries in dependency order..."));
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                Dictionary<String, List<String>> allDependenciesByLibraryUniqueName = new Dictionary<String, List<String>>();
                List<IEnumerable<String>> buildPasses = new List<IEnumerable<String>>();
                Int32 pass = 0;
                while (explicitReferencesByLibraryUniqueName.Count > 0)
                {
                    // a library is considered "fully analyzed" once all of its dependencies are found in the allDependenciesByLibraryUniqueName container
                    List<String> fullyAnalyzedLibraries = explicitReferencesByLibraryUniqueName.Where(x => (x.Value.Intersect(allDependenciesByLibraryUniqueName.Keys).Count() == x.Value.Count())).Select(x => x.Key).ToList();
                    Program.Output.Write(OutputType.Info, String.Format(CultureInfo.CurrentCulture, "Pass {0}:", pass++));
                    using (IndentedOutput indentedOutput2 = new IndentedOutput())
                    {
                        fullyAnalyzedLibraries.ForEach(x => Program.Output.Write(OutputType.Info, x));
                    }
                    buildPasses.Add(fullyAnalyzedLibraries);

                    if (fullyAnalyzedLibraries.Count() == 0)
                    {
                        // no new fully-analyzed libraries; this means the problem is unsolvable ... incorrect LibraryDependencies are a likely culprit


                        using (BatchedOutput output = new BatchedOutput(false))
                        {
                            output.BeginWriteError(0, "Unable to evaluate end-to-end library dependencies for sandbox; verify that all LibaryConfig-Library.xml References are accurate and that no circular references exist.");
                            output.Write(OutputType.Error, IndentAction.Increment, " Following are the details of the remaining analysis unable to be completed:");
                            foreach (String key in explicitReferencesByLibraryUniqueName.Keys)
                            {
                                output.Write(OutputType.Error, IndentAction.None, key);
                                foreach (String reference in explicitReferencesByLibraryUniqueName[key].Where(x => !allDependenciesByLibraryUniqueName.ContainsKey(x)))
                                {
                                    if (!libraryConfigFilesByLibraryUniqueName.ContainsKey(reference))
                                    {
                                        output.Write(OutputType.Error, IndentAction.IndentOnce, String.Format("{0} (ERROR! reference to unknown library)", reference));
                                    }
                                    else
                                    {
                                        output.Write(OutputType.Error, IndentAction.IndentOnce, reference);
                                    }
                                }
                            }
                            output.EndWriteError();
                        }
                        return;
                    }
                    else
                    {
                        // for all of the new libraries now in the "fully analyzed" state, move the new libraries to the
                        // allDependenciesByLibraryUniqueName container; also fully expand out all dependencies by using the
                        // "finished" dependencies that are found in that allDependenciesByLibraryUniqueName container
                        foreach (String fullyAnalyzedLibrary in fullyAnalyzedLibraries)
                        {
                            // read every explicit dependency of the fully-analyzed library
                            List<String> dependencies = new List<String>();
                            foreach (String libraryUniqueName in explicitReferencesByLibraryUniqueName[fullyAnalyzedLibrary])
                            {
                                // for each explicit dependency; build up a list of effective dependencies by consulting the allDependenciesByLibraryUniqueName container
                                dependencies = allDependenciesByLibraryUniqueName[libraryUniqueName].Union(dependencies).ToList();

                                // don't forget to add the explicit dependency too!
                                if (!dependencies.Contains(libraryUniqueName))
                                {
                                    dependencies.Add(libraryUniqueName);
                                }
                            }

                            // now that all effective dependencies for this library have been computed; add its results to the allDependenciesByLibraryUniqueName container
                            allDependenciesByLibraryUniqueName.Add(fullyAnalyzedLibrary, dependencies);

                            // remove this library from the explicitReferencesByLibraryUniqueName container; its information is now in the "fully analyzed" container 
                            explicitReferencesByLibraryUniqueName.Remove(fullyAnalyzedLibrary);
                        }
                    }
                }

                // return results by looking up the library in the allDependenciesByLibraryUniqueName container that
                // is the same as the root config file we are processing; the allDependenciesByLibraryUniqueName keys
                // should be in appropriate build order since we added them that way;  sort myDependencies such that 
                // they are in the same order as the analysis
                List<String> myDependencies = allDependenciesByLibraryUniqueName[myUniqueName];
                foreach (String libraryUniqueName in allDependenciesByLibraryUniqueName.Keys)
                {
                    if (myDependencies.Contains(libraryUniqueName))
                    {
                        result.Add(libraryConfigFilesByLibraryUniqueName[libraryUniqueName]);
                    }
                }

                _collectionVariables[Utils.GetVariableNameKeyForVariableName("System::LibraryUniqueNamesForImplicitReferences")] = myDependencies;
                _collectionVariables[Utils.GetVariableNameKeyForVariableName("System::LibraryConfigFilesForImplicitReferences")] = result;


                pass = 0;
                List<String> variableNames = new List<String>();
                foreach (IEnumerable<String> buildPass in buildPasses)
                {
                    IEnumerable<String> myDependenciesThisPass = buildPass.Where(x => myDependencies.Contains(x));
                    if (myDependenciesThisPass.Count() > 0)
                    {
                        DefineBuildPassSystemVariable(String.Format("System::BuildPass{0}-LibraryUniqueNames", pass), myDependenciesThisPass);
                        DefineBuildPassSystemVariable(String.Format("System::BuildPass{0}-LibraryConfigFiles", pass), myDependenciesThisPass.Select(x => libraryConfigFilesByLibraryUniqueName[x]));
                        variableNames.Add(String.Format("System::BuildPass{0}", pass));
                        pass++;
                    }
                }

                // add self into the list of build passes (as the last one)
                DefineBuildPassSystemVariable(String.Format("System::BuildPass{0}-LibraryUniqueNames", pass), new String[] { myUniqueName });
                DefineBuildPassSystemVariable(String.Format("System::BuildPass{0}-LibraryConfigFiles", pass), new String[] { libraryConfigFilesByLibraryUniqueName[myUniqueName] });
                variableNames.Add(String.Format("System::BuildPass{0}", pass));


                _collectionVariables[Utils.GetVariableNameKeyForVariableName("System::BuildPassVariableNames")] = variableNames.ToList();
            }
        }

        private String ReplaceTargetSettingVariable(ReadOnlyCollection<String> targetNames, String input)
        {
            String result = input;

            Match match = Regex.Match(result, @"(.*)(\$\([^\$\(\):]+::[^\$\(\):]+\))(.*)", RegexOptions.CultureInvariant);
            if (match.Success)
            {
                String prefix = "$(";
                String targetNameCandidate = match.Groups[2].Value.Substring(prefix.Length);
                targetNameCandidate = targetNameCandidate.Substring(0, targetNameCandidate.IndexOf(':'));
                String settingNameCandidate = match.Groups[2].Value.Substring(match.Groups[2].Value.LastIndexOf(':') + 1);
                settingNameCandidate = settingNameCandidate.TrimEnd(')');
                if (!IsSystemVariableDefined(match.Groups[2].Value) &&
                    targetNames.Contains(targetNameCandidate) &&
                    IsSystemVariableDefined(Utils.GetVariableNameKeyForVariableName(settingNameCandidate)))
                {
                    result = result.Replace(match.Groups[2].Value, GetSystemVariableValue(Utils.GetVariableNameKeyForVariableName(settingNameCandidate)));
                }
            }

            return result;
        }

        #endregion

        #region Private fields
        private readonly String _configFile; // = null; (automatically initialized by runtime)
        private readonly Dictionary<String, String> _variables = new Dictionary<String, String>();
        private readonly Dictionary<String, List<String>> _collectionVariables = new Dictionary<String, List<String>>();
        private readonly List<ConfigInfo> _configInfo = new List<ConfigInfo>();
        private readonly List<BuildInfoItem> _buildInfoItems = new List<BuildInfoItem>();
        private readonly Dictionary<String, TargetGroup> _targetGroups = new Dictionary<String, TargetGroup>();
        private readonly Dictionary<String, FileGroup> _fileGroups = new Dictionary<String, FileGroup>();
        //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
        private readonly List<LibraryReference> _libraryReferences = new List<LibraryReference>();
        private readonly Dictionary<String, ActionStep> _actionStepsById = new Dictionary<String, ActionStep>();
        private readonly Dictionary<String, Object> _emitWriters = new Dictionary<String, Object>();
        private readonly List<Reference> _references = new List<Reference>();
        private FileGroup _fileGroup;
        private String _actionId;
        #endregion
    }
}
