using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;
using Spark.Internal;

namespace Spark
{
    internal sealed class Program
    {
        static void Main(String[] args)
        {
            Program program = new Program();
            program.Run(args);
        }

        private Int32 Run(String[] args)
        {
            StringCollection extensionList = new StringCollection();
            try
            {
                // parse the command line
                this.ParseCommandLine(args);

                if (this._showLogo)
                {
                    Assembly assembly = Assembly.GetExecutingAssembly();

                    Console.WriteLine("Sage Spark Tool (derivative of WiX 3.0 Heat).  Version " + Assembly.GetExecutingAssembly().GetName().Version);
                    Console.WriteLine();
                }

                if (this._showHelp)
                {
                    Console.WriteLine("Syntax: Spark <file to process> -out sourceFile.wxs [Options]");
                    Console.WriteLine();
                    Console.WriteLine("   -nologo  skip printing spark logo information");
                    Console.WriteLine("   -out     specify output file (default: write to current directory)");
                    Console.WriteLine("   -?       this help information");

                    return 0;
                }

                ReadOnlyCollection<Wix.RegistryValue> harvest = RegistryExtract(this._fileToProcess);

                XmlWriter writer = null;
                try
                {
                    FileStream fileStream = new FileStream(this._outputFile, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
                    XmlWriterSettings settings = new XmlWriterSettings();
                    settings.OmitXmlDeclaration = true;
                    settings.Indent = true;
                    settings.IndentChars = "  ";
                    settings.CloseOutput = true;
                    settings.ConformanceLevel = ConformanceLevel.Document;
                    settings.Encoding = Encoding.UTF8;
                    writer = XmlWriter.Create(fileStream, settings);


                    writer.WriteStartDocument();


                    writer.WriteStartElement("Wix", "http://schemas.microsoft.com/wix/2006/wi");
                    writer.WriteStartElement("Fragment");
                    writer.WriteStartElement("DirectoryRef");
                    writer.WriteStartAttribute("Id");
                    writer.WriteValue("TARGETDIR");
                    writer.WriteEndAttribute();

                    writer.WriteStartElement("Component");

                    writer.WriteStartAttribute("Id");
                    writer.WriteValue("component0");
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("DiskId");
                    writer.WriteValue("1");
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("Guid");
                    writer.WriteValue("PUT-GUID-HERE");
                    writer.WriteEndAttribute();

                    writer.WriteStartElement("File");

                    writer.WriteStartAttribute("Id");
                    writer.WriteValue("file0");
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("Name");
                    writer.WriteValue(Path.GetFileName(this._fileToProcess));
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("Source");
                    writer.WriteValue(Path.GetFullPath(this._fileToProcess));
                    writer.WriteEndAttribute();

                    writer.WriteEndElement();


                    foreach (Wix.RegistryValue registryValue in harvest)
                    {
                        OutputRegistryValueAsXml(registryValue, writer);
                    }

                    writer.WriteEndElement();

                    writer.WriteEndElement();
                    writer.WriteEndElement();
                    writer.WriteEndElement();


                    writer.WriteEndDocument();
                }
                finally
                {
                    if (null != writer)
                    {
                        writer.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                if (ex is NullReferenceException || ex is SEHException)
                {
                    throw;
                }
            }

            return 0;
        }

        /// <summary>
        /// Parse the commandline arguments.
        /// </summary>
        /// <param name="args">Commandline arguments.</param>
        private void ParseCommandLine(String[] args)
        {
            for (Int32 i = 0; i < args.Length; ++i)
            {
                String arg = args[i];
                if (null == arg || 0 == arg.Length) // skip blank arguments
                {
                    continue;
                }

                if ('-' == arg[0] || '/' == arg[0])
                {
                    String parameter = arg.Substring(1);
                    if ("nologo" == parameter)
                    {
                        this._showLogo = false;
                    }
                    else if ("o" == parameter || "out" == parameter)
                    {
                        if (args.Length < ++i || '/' == args[i][0] || '-' == args[i][0])
                        {
                            //ASH:this.messageHandler.Display(this, WixErrors.FileOrDirectoryPathRequired(String.Concat("-", parameter)));
                            return;
                        }

                        if (0 <= args[i].IndexOf('\"'))
                        {
                            //ASH:this.messageHandler.Display(this, WixErrors.PathCannotContainQuote(args[i]));
                            return;
                        }
                        else
                        {
                            this._outputFile = Path.GetFullPath(args[i]);
                        }
                    }
                    else if ("r" == parameter || "reg" == parameter)
                    {
                        this._registryExtract = true;
                    }
                    else if ("?" == parameter || "help" == parameter)
                    {
                        this._showHelp = true;
                    }
                }
                else if (null == this._fileToProcess)
                {
                    this._fileToProcess = arg;
                }
                else
                {
                    this._showHelp = true;
                }
            }

            if (null == this._outputFile)
            {
                this._showHelp = true;
            }

            return;
        }

        private ReadOnlyCollection<Wix.RegistryValue> RegistryExtract(String file)
        {
            ReadOnlyCollection<Wix.RegistryValue> result = Array.AsReadOnly(new Wix.RegistryValue[0]);
            if (_registryExtract)
            {
                String fileExtension = Path.GetExtension(file);

                if (0 == String.Compare(".ax", fileExtension, true) || // DirectShow filter
                    0 == String.Compare(".dll", fileExtension, true) ||
                    0 == String.Compare(".exe", fileExtension, true) ||
                    0 == String.Compare(".ocx", fileExtension, true))
                {
                    // try the assembly harvester
                    try
                    {
                        AssemblyHarvester assemblyHarvester = new AssemblyHarvester();

                        Wix.RegistryValue[] registryValues = assemblyHarvester.HarvestRegistryValues(file);

                        result = Array.AsReadOnly(registryValues);
                    }
                    catch
                    {
                        // try the self-reg harvester
                        try
                        {
                            DllHarvester dllHarvester = new DllHarvester();

                            Wix.RegistryValue[] registryValues = dllHarvester.HarvestRegistryValues(file);

                            result = Array.AsReadOnly(registryValues);
                        }
                        catch
                        {
                            // try the unmanaged COM EXE server harvester
                            try
                            {
                                UnmanagedComExeServerHarvester exeHarvester = new UnmanagedComExeServerHarvester();

                                Wix.RegistryValue[] registryValues = exeHarvester.HarvestRegistryValues(file);

                                result = Array.AsReadOnly(registryValues);
                            }
                            catch (Exception ex)
                            {
                                System.Diagnostics.Trace.WriteLine(ex.ToString());

                                // ignore all exceptions
                            }
                        }
                    }
                }
                else if (0 == String.Compare(".olb", fileExtension, true) || // type library
                        0 == String.Compare(".tlb", fileExtension, true)) // type library
                {
                    Boolean calledPerUserTLibReg = false;

                    // try the type library harvester
                    try
                    {
                        try
                        {
                            // http://support.microsoft.com/kb/935200
                            // http://msdn.microsoft.com/en-us/library/356af9a9-77f9-4699-abc3-ab3ff1db2915(VS.85)
                            // Without OaEnablePerUserTLibRegistration, calls to RegisterTypeLib may fail on Vista and newer machines when remapping the registry
                            OaEnablePerUserTLibRegistration();
                            calledPerUserTLibReg = true;
                        }
                        catch (EntryPointNotFoundException)
                        { 
                            // might be running on a pre-VistaSP1 OS
                        }

                        TypeLibraryHarvester typeLibHarvester = new TypeLibraryHarvester();

                        Wix.RegistryValue[] registryValues = typeLibHarvester.HarvestRegistryValues(file);

                        result = Array.AsReadOnly(registryValues);
                    }
                    catch (COMException ce)
                    {
                        //  0x8002801C (TYPE_E_REGISTRYACCESS)
                        // If we don't have permission to harvest typelibs, it's likely because we're on
                        // Vista or higher and aren't an Admin, or don't have the appropriate QFE installed.
                        if (!calledPerUserTLibReg && (0x8002801c == unchecked((uint)ce.ErrorCode)))
                        {
                            Environment.ExitCode = 1;
                            throw new Exception(String.Format("RegisterTypeLib({0}) failed: not enough permissions to harvest typelib. On Vista, you must either run heat elevated, or install Vista SP1.", file), ce);
                        }
                        else if (0x80029C4A == unchecked((uint)ce.ErrorCode)) // generic can't load type library
                        {
                            Environment.ExitCode = 1;
                            throw new Exception(String.Format("RegisterTypeLib({0}) failed: could not load file that was expected to be a type library based off of file extension.", file), ce);
                        }
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Trace.WriteLine(ex.ToString());

                        // ignore all exceptions
                    }
                }
            }

            return result;
        }

        private void OutputRegistryValueAsXml(Wix.RegistryValue registryValue, XmlWriter writer)
        {
            writer.WriteStartElement("Registry");

            writer.WriteStartAttribute("Root");
            writer.WriteValue(registryValue.Root.ToString());
            writer.WriteEndAttribute();

            writer.WriteStartAttribute("Key");
            writer.WriteValue(registryValue.Key);
            writer.WriteEndAttribute();

            if (!String.IsNullOrEmpty(registryValue.Name))
            {
                writer.WriteStartAttribute("Name");
                writer.WriteValue(registryValue.Name);
                writer.WriteEndAttribute();
            }

            if (!String.IsNullOrEmpty(registryValue.Value))
            {
                writer.WriteStartAttribute("Value");
                writer.WriteValue(registryValue.Value);
                writer.WriteEndAttribute();

                writer.WriteStartAttribute("Type");
                writer.WriteValue(registryValue.Type.ToString());
                writer.WriteEndAttribute();
            }

            writer.WriteEndElement();
        }

        private String _fileToProcess;
        private String _outputFile;
        private Boolean _showLogo;
        private Boolean _showHelp;
        private Boolean _registryExtract;

        /// <summary>
        /// enable the RegisterTypeLib API to use the appropriate override mapping for non-admin users on Vista
        /// </summary>
        [DllImport("oleaut32.dll", PreserveSig = false)]
        private static extern void OaEnablePerUserTLibRegistration();
    }
}
