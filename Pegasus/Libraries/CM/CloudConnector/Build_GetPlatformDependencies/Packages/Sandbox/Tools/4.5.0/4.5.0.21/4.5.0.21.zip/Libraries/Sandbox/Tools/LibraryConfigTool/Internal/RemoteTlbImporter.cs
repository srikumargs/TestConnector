using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Permissions;
using System.Runtime.Remoting.Messaging;
using System.Reflection.Emit;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1812:AvoidUninstantiatedInternalClasses", Justification = "This class is called in a late-bound manner through a subordinate AppDomain.")]
    internal sealed class RemoteTlbImporter : MarshalByRefObject
    {
        public override object InitializeLifetimeService()
        {
            return null; // prevent leased-based lifetime management
        }

        public void ImportTypeLibrary(IMessageSink outputMessageSink, String path, String interopPath, String keyFile, String asmVersion, Boolean preventClassMembers)
        {
            _outputMessageSink = outputMessageSink;

            //Assembly libraryManagementAssembly = Assembly.LoadFrom(Path.Combine(Utils.SandboxLocation, @"Assemblies\Sage.LS1.LibraryManagement.dll"));
            //if(libraryManagementAssembly != null)
            //{
            //    Type libraryManagerType = libraryManagementAssembly.GetType("Sage.Configuration.LibraryManager");
            //    String libraryManifestLocation = (String) libraryManagerType.InvokeMember("LibraryManifestLocationForBinary", BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static, null, null, new Object[] { path });
            //    libraryManagerType.InvokeMember("InitializeLibraries", BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static, null, null, new Object[] { libraryManifestLocation });
            //}

            DoImportTypeLibrary(path, interopPath, keyFile, asmVersion, preventClassMembers);
        }

        private void DoImportTypeLibrary(String path, String interopPath, String keyFile, String asmVersion, Boolean preventClassMembers)
        {
            IntPtr typeLibPtr = IntPtr.Zero;
            ITypeLib typeLib = null;
            try
            {
                if (Utils.NativeMethods.LoadTypeLib(path, ref typeLibPtr) != 0 ||
                    typeLibPtr == IntPtr.Zero ||
                    ((typeLib = (ITypeLib)Marshal.GetTypedObjectForIUnknown(typeLibPtr, typeof(ITypeLib))) == null))
                {
                    throw new Exception(Strings.LoadTypeLibFailed);
                }
                else
                {
                    TypeLibConverter typeLibConverter = new TypeLibConverter();

                    // Note: Added the PreventClassMembers flag due to failures in legacy Win32 server EXE's. Although highly
                    // undocumented, the failure message instructs you to specify this command line parameter.
                    TypeLibImporterNotifySink typeLibImporterNotifySink = new TypeLibImporterNotifySink(_outputMessageSink);
                    TypeLibImporterFlags importerFlags = TypeLibImporterFlags.None;

                    if (preventClassMembers)
                        importerFlags = TypeLibImporterFlags.PreventClassMembers;

                    AssemblyBuilder assemblyBuilder = typeLibConverter.ConvertTypeLibToAssembly(typeLib, interopPath, importerFlags, typeLibImporterNotifySink, null, new StrongNameKeyPair(new FileStream(keyFile, FileMode.Open, FileAccess.Read)), null, new Version(asmVersion));
                    assemblyBuilder.Save(Path.GetFileName(interopPath));

                    Output(OutputType.Info, Strings.ConvertTypeLibToAssemblySucceeded);
                    Output(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:        '{0}'", path));
                    Output(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "InteropPath: '{0}'", interopPath));
                    Output(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "KeyFile:     '{0}'", keyFile));
                    Output(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "AsmVersion:  '{0}'", asmVersion));
                }
            }
            finally
            {
                if (typeLib != null)
                {
                    Marshal.ReleaseComObject(typeLib);
                    typeLib = null;
                }
                if (typeLibPtr != IntPtr.Zero)
                {
                    Marshal.Release(typeLibPtr);
                    typeLibPtr = IntPtr.Zero;
                }
            }
        }

        private void Output(OutputType outputType, String message)
        {
            Output(outputType, IndentAction.None, message);
        }

        private void Output(OutputType outputType, IndentAction indentAction, String message)
        {
            _outputMessageSink.SyncProcessMessage(new OutputMessage(outputType, indentAction, message));
        }

        private IMessageSink _outputMessageSink;
    }
}
