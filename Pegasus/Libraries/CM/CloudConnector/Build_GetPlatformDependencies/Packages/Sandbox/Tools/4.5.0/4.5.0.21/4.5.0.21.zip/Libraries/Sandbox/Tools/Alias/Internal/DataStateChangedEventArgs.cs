using System;
using System.Collections.Generic;
using System.Text;

namespace Alias.Internal
{
    internal sealed class DataStateChangedEventArgs : EventArgs
    {
        #region Constructors
        public DataStateChangedEventArgs(Boolean dirty, String fileName)
        {
            _dirty = dirty;
            _fileName = fileName;
        }
        #endregion

        #region Public properties
        public Boolean Dirty
        { get { return _dirty; } }

        public String FileName
        { get { return _fileName; } }
        #endregion

        #region Private fields
        private Boolean _dirty;
        private String _fileName;
        #endregion
    }
}
