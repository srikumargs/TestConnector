﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;

using Alias.Properties;
using System.Drawing;

namespace Alias.Internal
{
    internal partial class MainForm : Form, IEngineEventsSubscriber, IPromptUser
    {
        #region private consts
        private const string ALIAS_MAPPINGS = "AliasMappings";
        private const string MAPPING = "Mapping";
        private const string NAME_A = "NameA";
        private const string NAME_B = "NameB";
        #endregion

        public MainForm()
        {
            InitializeComponent();
            this.DataStateChanged += new EventHandler(MainForm_DataStateChanged);
        }

        #region IEngineEventsSubscriber Members

        public void OnWorkProgress(Object sender, WorkProgressEventArgs args)
        {
            if (this.InvokeRequired)
            {
                Invoke(new EventHandler<WorkProgressEventArgs>(OnWorkProgress), sender, args);
            }
            else
            {
                DataGridViewRow row = new DataGridViewRow();
                switch (args.Code)
                {
                    case WorkProgressCode.None:
                        row.Visible = (_showingToolStripComboBox.SelectedIndex == 0);
                        row.CreateCells(_resultsDataGridView, _imageList.Images[0], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        row.Cells[2] = new DataGridViewTextBoxCell();
                        break;
                    case WorkProgressCode.Fail:
                        row.Visible = true;
                        row.CreateCells(_resultsDataGridView, _imageList.Images[1], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        break;
                    case WorkProgressCode.Success:
                        row.Visible = (_showingToolStripComboBox.SelectedIndex == 0);
                        row.CreateCells(_resultsDataGridView, _imageList.Images[2], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        row.Cells[2] = new DataGridViewTextBoxCell();
                        break;
                    case WorkProgressCode.Info:
                        row.Visible = true;
                        row.CreateCells(_resultsDataGridView, _imageList.Images[3], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        row.Cells[2] = new DataGridViewTextBoxCell();
                        switch (args.FileCode)
                        {
                            case FileCode.CSProj:
                                _csprojFileCount++;
                                break;

                            case FileCode.LibraryConfig:
                                _libraryConfigFileCount++;
                                break;

                            case FileCode.Solution:
                                _solutionFileCount++;
                                break;

                            case FileCode.FinalBuilder:
                                _finalBuilderFileCount++;
                                break;
                        }
                        break;
                }

                _processingInfoToolStripLabel.Text = String.Format("Processing [{0} .csproj's, {1} LibraryConfig's, {2} .sln's, {3} .fbp7's]", _csprojFileCount, _libraryConfigFileCount, _solutionFileCount, _finalBuilderFileCount);
            }
        }

        public void OnStop()
        {
            if (this.InvokeRequired)
            {
                Invoke(new MethodInvoker(OnStop));
            }
            else
            {
                _processToolStripButton.Text = "Process";
                _processToolStripButton.Image = Resources.Run;
                _processToolStripButton.ToolTipText = _processToolTip;
                _mappingsDataGridView.Enabled = true;

                FLASHWINFO fInfo = new FLASHWINFO();

                fInfo.cbSize = (ushort)Marshal.SizeOf(fInfo);
                fInfo.hwnd = this.Handle;
                fInfo.dwFlags = FLASHW_ALL | FLASHW_TIMERNOFG;
                fInfo.uCount = UInt16.MaxValue;
                fInfo.dwTimeout = 0;

                FlashWindowEx(ref fInfo);

                OnWorkProgress(this, new WorkProgressEventArgs(WorkProgressCode.Info, String.Format(CultureInfo.CurrentUICulture, "Finished.  Number of failures: {0}.  Elapsed time:  {1}.", _engine.FailureCount, _engine.RunTime)));
                _processingInfoToolStripLabel.Text = String.Format(CultureInfo.CurrentUICulture, "Finished.  Number of failures: {0}.", _engine.FailureCount);

                if (_resultsDataGridView.Rows.Count > 0)
                {
                    // set FirstDisplayedScrollingRowIndex to last visible row
                    for (Int32 i = _resultsDataGridView.Rows.Count - 1; i >= 0; i--)
                    {
                        if (_resultsDataGridView.Rows[i].Visible)
                        {
                            _resultsDataGridView.FirstDisplayedScrollingRowIndex = i;
                            break;
                        }
                    }
                }
            }
        }

        #endregion

        #region Private methods
        private AliasProcessorOptions GetProcessorOptions()
        {
            AliasProcessorOptions result = new AliasProcessorOptions();
            result.TestOnly = _testOnlyCheckBox.Checked;

            foreach (DataGridViewRow row in _mappingsDataGridView.Rows)
            {
                String oldValue = row.Cells[_directionComboBox.SelectedIndex == 0 ? 0 : 1].Value as String;
                String newValue = row.Cells[_directionComboBox.SelectedIndex == 0 ? 1 : 0].Value as String;
                if (!String.IsNullOrEmpty(oldValue) && !String.IsNullOrEmpty(newValue))
                {
                    result.AddAssemblyNameMapping(oldValue, newValue);
                }
            }

            return result;
        }

        void MainForm_DataStateChanged(Object sender, EventArgs e)
        {
            DataStateChangedEventArgs dataStateChangedEventArgs = (e as DataStateChangedEventArgs);

            if (!string.IsNullOrEmpty(dataStateChangedEventArgs.FileName))
            {
                this.Text = string.Format("{0}{1} - Alias", dataStateChangedEventArgs.FileName, dataStateChangedEventArgs.Dirty ? "*" : "");
            }
            else
            {
                this.Text = string.Format("Untitled{0} - Alias", dataStateChangedEventArgs.Dirty ? "*" : "");
            }
        }

        private void MainForm_Load(Object sender, EventArgs e)
        {
            _directionComboBox.SelectedIndex = 0;
            _rootFolderTextBox.Text = System.Environment.CurrentDirectory;
            _showingToolStripComboBox.SelectedIndex = 1;
        }

        private void MainForm_FormClosing(Object sender, FormClosingEventArgs e)
        {
            if (_engine.IsRunning)
            {
                if (DialogResult.Yes != MessageBox.Show("Rename process is currently running.  Stop process and close the application?", "Stop Rename Process", MessageBoxButtons.YesNo))
                {
                    e.Cancel = true;
                }
            }
        }

        private void _processToolStripButton_Click(Object sender, EventArgs e)
        {
            if (!_engine.IsRunning)
            {
                if (ValidateMappings())
                {
                    if (!_testOnlyCheckBox.Checked &&
                        DialogResult.No == MessageBox.Show("Proceed with the rename process?\n\nWarning:  this will make changes to your local machine!", "Confirm Rename", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                    {
                        return;
                    }

                    _processToolStripButton.Text = "&Pause";
                    _processToolStripButton.Image = Resources.Pause;
                    _processToolTip = _processToolStripButton.ToolTipText;
                    _mappingsDataGridView.Enabled = false;

                    _resultsDataGridView.Rows.Clear();

                    OnWorkProgress(this, new WorkProgressEventArgs(WorkProgressCode.Info, _testOnlyCheckBox.Checked ? "Started (test-only)..." : "Started..."));
                    _processingInfoToolStripLabel.Text = "Started...";

                    String fileSpecification = _rootFolderTextBox.Text;
                    _engine.Start(this, this, new EngineOptions(false, new ReadOnlyCollection<String>(new String[] { fileSpecification }), _recursiveCheckBox.Checked, GetProcessorOptions()));
                }
            }
            else
            {
                if (!_engine.IsSuspended)
                {
                    _engine.Suspend();
                    _processToolStripButton.Text = "&Resume";
                    _processToolStripButton.Image = Resources.Run;
                    _processToolStripButton.ToolTipText = "Resumes the rename process which is currently paused.  You can terminate the in-progress Process by closing the application.";
                    _processingInfoToolStripLabel.Text = "Paused.";
                }
                else
                {
                    _engine.Resume();
                    _processToolStripButton.Text = "&Pause";
                    _processToolStripButton.Image = Resources.Pause;
                    _processToolStripButton.ToolTipText = "Pauses the rename process which is currently running.  Can be resumed.  You can terminate the in-progress Process by closing the application.";
                    _processingInfoToolStripLabel.Text = "Resumed...";
                }
            }
        }

        private void _rootFolderBrowseButton_Click(Object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.ShowNewFolderButton = false;
            dialog.Description = "Select the parent folder continaing C# project file(s):";
            dialog.RootFolder = Environment.SpecialFolder.MyComputer;
            dialog.SelectedPath = _rootFolderTextBox.Text;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                _rootFolderTextBox.Text = dialog.SelectedPath;
            }
        }

        private void _closeButton_Click(Object sender, EventArgs e)
        {
            Close();
        }

        private void _mappingsScanNameAToolStripButton_Click(Object sender, EventArgs e)
        {
            FileScan(NAME_A);
        }

        private void _mappingsScanNameBToolStripButton_Click(Object sender, EventArgs e)
        {
            FileScan(NAME_B);
        }

        private void _mappingsNewToolStripButton_Click(Object sender, EventArgs e)
        {
            FileNew();
        }
       
        private void _mappingsOpenToolStripButton_Click(Object sender, EventArgs e)
        {
            FileOpen();
        }

        private void _mappingsSaveToolStripButton_Click(Object sender, EventArgs e)
        {
            FileSave();
        }

        private void _mappingsSaveAsToolStripButton_Click(Object sender, EventArgs e)
        {
            FileSaveAs();
        }

        private void _resultsSaveAsToolStripButton_Click(Object sender, EventArgs e)
        {
            SaveFileDialog saveAsFileDialog = new SaveFileDialog();
            saveAsFileDialog.AddExtension = true;
            saveAsFileDialog.CheckFileExists = false;
            saveAsFileDialog.CheckPathExists = true;
            saveAsFileDialog.CreatePrompt = false;
            saveAsFileDialog.DefaultExt = ".htm";
            saveAsFileDialog.Filter = "HTML Files (*.html;*.htm)|*.html;*.htm|All files (*.*)|*.*";
            saveAsFileDialog.FileName = String.Format("Alias-Results-{0}.htm", DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss"));
            saveAsFileDialog.OverwritePrompt = true;
            saveAsFileDialog.SupportMultiDottedExtensions = true;
            saveAsFileDialog.Title = "Save Results File As";
            DialogResult dialogResult = saveAsFileDialog.ShowDialog(this.ParentForm);
            if (dialogResult == DialogResult.OK)
            {
                String fileName = saveAsFileDialog.FileName;
                if (File.Exists(fileName))
                {
                    FileAttributes fileAttributes = File.GetAttributes(fileName);
                    if ((fileAttributes & FileAttributes.ReadOnly) > 0)
                    {
                        if (MessageBox.Show(this.ParentForm, "File is marked as read-only.  Overwrite?", "Alias", MessageBoxButtons.YesNo) == DialogResult.No)
                        {
                            return;
                        }

                        File.SetAttributes(fileName, fileAttributes & ~FileAttributes.ReadOnly);
                    }
                }

                XmlDocument document = new XmlDocument();
                document.LoadXml(GenerateResultsHtmlToSave());
                document.Save(fileName);
            }
        }

        private Boolean PromptForSaveIfDataChanged()
        {
            Boolean result = true;

            if (DataChanged)
            {
                DialogResult dialogResult = MessageBox.Show(this.ParentForm, "Save changes?", "Alias", MessageBoxButtons.YesNoCancel);
                switch (dialogResult)
                {
                    case DialogResult.Yes:
                        if (!string.IsNullOrEmpty(FileName))
                        {
                            if (FileSave() == DialogResult.OK)
                            {
                                result = true;
                            }
                        }
                        else
                        {
                            if (FileSaveAs() == DialogResult.OK)
                            {
                                result = true;
                            }
                        }
                        break;

                    case DialogResult.No:
                        result = true;
                        break;

                    case DialogResult.Cancel:
                        result = false;
                        break;
                }
            }

            return result;
        }

        private void FileScan(String columnName)
        {
            String path = Path.GetFullPath(_rootFolderTextBox.Text);
            List<String> assembliesToAddToGrid = new List<String>();
            if (Directory.Exists(path))
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(xmlDoc.NameTable);
                namespaceManager.AddNamespace("CSPROJ", "http://schemas.microsoft.com/developer/msbuild/2003");

                String[] fileNames = Directory.GetFiles(path, "*.csproj", _recursiveCheckBox.Checked ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
                foreach (String fileName in fileNames)
                {
                    // Retrieve the assembly name from csproj file
                    xmlDoc.Load(fileName);
                    XmlNodeList propertyGroupNodes = xmlDoc.SelectNodes(@"//CSPROJ:Project/CSPROJ:PropertyGroup", namespaceManager);

                    String assemblyName = string.Empty;
                    foreach (XmlNode propertyGroupNode in propertyGroupNodes)
                    {
                        XmlNode assemblyNameNode = propertyGroupNode.SelectSingleNode(@"CSPROJ:AssemblyName", namespaceManager);
                        if (assemblyNameNode != null)
                        {
                            assemblyName = assemblyNameNode.InnerText;
                            break;
                        }
                    }

                    if (!string.IsNullOrEmpty(assemblyName))
                    {
                        if (!AssemblyExistsInGrid(columnName, assemblyName) && !assembliesToAddToGrid.Contains(assemblyName))
                        {
                            assembliesToAddToGrid.Add(assemblyName);
                        }
                    }
                }
            }

            if (assembliesToAddToGrid.Count > 0)
            {
                Cursor = Cursors.WaitCursor;
                try
                {
                    assembliesToAddToGrid.Sort();
                    foreach (String assemblyName in assembliesToAddToGrid)
                    {
                        AddAssemblyToGrid(columnName, assemblyName);
                    }
                    FireDataStateChanged(new DataStateChangedEventArgs(true, FileName));
                    MessageBox.Show(this, String.Format("{0} assemblies added to '{1}' column.", assembliesToAddToGrid.Count, (columnName == NAME_A) ? _mappingsDataGridView.Columns[0].HeaderText : _mappingsDataGridView.Columns[1].HeaderText), "Alias - Scan for Assemblies");
                }
                finally
                {
                    Cursor = Cursors.Default;
                }
            }
            else
            {
                MessageBox.Show(this, String.Format("No necessary assembly names found to add to '{0}' column.", (columnName == NAME_A) ? _mappingsDataGridView.Columns[0].HeaderText : _mappingsDataGridView.Columns[1].HeaderText), "Alias - Scan for Assemblies");
            }
        }

        private Boolean AssemblyExistsInGrid(String columnName, String assemblyName)
        {
            Boolean assemblyExistsInGrid = false;
            foreach (DataGridViewRow row in _mappingsDataGridView.Rows)
            {
                if (NAME_A == columnName)
                {
                    if (row.Cells[0].Value != null)
                    {
                        if (row.Cells[0].Value.ToString() == assemblyName)
                        {
                            assemblyExistsInGrid = true;
                            break;
                        }
                    }
                }
                else
                {
                    if (row.Cells[1].Value != null)
                    {
                        if (row.Cells[1].Value.ToString() == assemblyName)
                        {
                            assemblyExistsInGrid = true;
                            break;
                        }
                    }
                }
            }
            return assemblyExistsInGrid;
        }

        private void AddAssemblyToGrid(String columnName, String assemblyName)
        {
            String nameA = string.Empty;
            String nameB = string.Empty;
            if (NAME_A == columnName)
            {
                nameA = assemblyName;
            }
            else
            {
                nameB = assemblyName;
            }
            String[] row = { nameA, nameB };
            _mappingsDataGridView.Rows.Add(row);
        }
        
        private void FileNew()
        {
            if (PromptForSaveIfDataChanged())
            {
                _dataChanged = false;
                _fileName = String.Empty;
                _mappingsDataGridView.Rows.Clear();

                FireDataStateChanged(new DataStateChangedEventArgs(false, String.Empty));
            }
        }

        private void FileOpen()
        {
            if (PromptForSaveIfDataChanged())
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Mappings Files (*.xml)|*.xml|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 0;
                openFileDialog.Title = "Open Mappings File";
                openFileDialog.AddExtension = true;
                openFileDialog.CheckFileExists = true;
                openFileDialog.CheckPathExists = true;
                openFileDialog.Multiselect = false;
                openFileDialog.ShowReadOnly = false;
                openFileDialog.ValidateNames = true;
                if (openFileDialog.ShowDialog(this.ParentForm) == DialogResult.OK)
                {
                    _fileName = openFileDialog.FileName;

                    XmlDocument document = new XmlDocument();
                    document.Load(_fileName);

                    _mappingsDataGridView.Rows.Clear();

                    XmlNodeList mappingNodes = document.SelectNodes(string.Format(@"{0}/{1}", ALIAS_MAPPINGS, MAPPING));
                    foreach (XmlNode mappingNode in mappingNodes)
                    {
                        string[] row = { mappingNode.SelectSingleNode(NAME_A).InnerText, 
                                         mappingNode.SelectSingleNode(NAME_B).InnerText };
                        _mappingsDataGridView.Rows.Add(row);
                    }

                    FireDataStateChanged(new DataStateChangedEventArgs(false, Path.GetFileName(openFileDialog.FileName)));
                }
            }
        }

        public DialogResult FileSave()
        {
            DialogResult result = DialogResult.Cancel;

            if (ValidateMappings())
            {
                if (!String.IsNullOrEmpty(FileName))
                {
                    SaveMappingsFile();
                    result = DialogResult.OK;
                }
                else
                {
                    result = FileSaveAs();
                }
            }

            return result;
        }

        public DialogResult FileSaveAs()
        {
            DialogResult result = DialogResult.Cancel;

            if (ValidateMappings())
            {
                SaveFileDialog saveAsFileDialog = new SaveFileDialog();
                saveAsFileDialog.AddExtension = true;
                saveAsFileDialog.CheckFileExists = false;
                saveAsFileDialog.CheckPathExists = true;
                saveAsFileDialog.CreatePrompt = false;
                saveAsFileDialog.DefaultExt = ".exe.config";
                saveAsFileDialog.Filter = "Mappings Files (*.xml)|*.xml|All files (*.*)|*.*";
                saveAsFileDialog.OverwritePrompt = true;
                saveAsFileDialog.SupportMultiDottedExtensions = true;
                saveAsFileDialog.Title = "Save Mappings File As";
                DialogResult dialogResult = saveAsFileDialog.ShowDialog(this.ParentForm);
                if (dialogResult == DialogResult.OK)
                {
                    _fileName = saveAsFileDialog.FileName;
                    SaveMappingsFile();
                }
            }

            return result;
        }

        private String GenerateXmlToSave()
        {
            Stream stream = new MemoryStream();
            stream.Position = 0;
            XmlTextWriter xmlTextWriter = new XmlTextWriter(stream, Encoding.UTF8);

            xmlTextWriter.Formatting = Formatting.Indented;
            xmlTextWriter.WriteStartDocument(true);
            {
                xmlTextWriter.WriteStartElement(ALIAS_MAPPINGS);
                {
                    foreach (DataGridViewRow row in _mappingsDataGridView.Rows)
                    {
                        String nameA = row.Cells[0].Value as String;
                        String nameB = row.Cells[1].Value as String;
                        if (!String.IsNullOrEmpty(nameA) && !String.IsNullOrEmpty(nameB))
                        {
                            xmlTextWriter.WriteStartElement(MAPPING);
                            {
                                xmlTextWriter.WriteStartElement(NAME_A);
                                xmlTextWriter.WriteValue(nameA);
                                xmlTextWriter.WriteEndElement();

                                xmlTextWriter.WriteStartElement(NAME_B);
                                xmlTextWriter.WriteValue(nameB);
                                xmlTextWriter.WriteEndElement();
                            }
                            xmlTextWriter.WriteEndElement();
                        }
                    }
                }
                xmlTextWriter.WriteEndElement(); // AliasMappings
            }
            xmlTextWriter.WriteEndDocument();
            xmlTextWriter.Flush();

            stream.Position = 0;
            StreamReader streamReader = new StreamReader(stream, true);
            String result = streamReader.ReadToEnd();

            xmlTextWriter.Close();

            return result;
        }

        private String GenerateResultsHtmlToSave()
        {
            Stream stream = new MemoryStream();
            stream.Position = 0;
            XmlTextWriter xmlTextWriter = new XmlTextWriter(stream, Encoding.UTF8);

            xmlTextWriter.Formatting = Formatting.Indented;
            xmlTextWriter.WriteStartDocument(true);
            {
                xmlTextWriter.WriteStartElement("html");
                {
                    xmlTextWriter.WriteStartElement("head");
                    {
                        //xmlTextWriter.WriteStartElement("style");
                        //xmlTextWriter.WriteEndElement(); // style
                    }
                    xmlTextWriter.WriteEndElement(); // head

                    xmlTextWriter.WriteStartElement("body");
                    xmlTextWriter.WriteAttributeString("scroll", "auto");
                    {
                        xmlTextWriter.WriteStartElement("h2");
                        {
                            xmlTextWriter.WriteValue("Processing");
                        }
                        xmlTextWriter.WriteEndElement(); // h2

                        xmlTextWriter.WriteStartElement("table");
                        {
                            xmlTextWriter.WriteAttributeString("border", "1");
                            xmlTextWriter.WriteAttributeString("cellpadding", "10");
                            xmlTextWriter.WriteAttributeString("cellspacing", "0");

                            WriteHtmlTableRow(xmlTextWriter, "Direction:", _directionComboBox.Text);
                            WriteHtmlTableRow(xmlTextWriter, "Root folder:", _rootFolderTextBox.Text);
                            WriteHtmlTableRow(xmlTextWriter, "Recursive:", _recursiveCheckBox.Checked.ToString());
                            WriteHtmlTableRow(xmlTextWriter, "Test-only:", _testOnlyCheckBox.Checked.ToString());
                        }
                        xmlTextWriter.WriteEndElement(); // table

                        xmlTextWriter.WriteStartElement("h2");
                        {
                            xmlTextWriter.WriteValue("Mappings");
                        }
                        xmlTextWriter.WriteEndElement(); // h2

                        xmlTextWriter.WriteStartElement("table");
                        {
                            xmlTextWriter.WriteAttributeString("border", "1");
                            xmlTextWriter.WriteAttributeString("cellpadding", "10");
                            xmlTextWriter.WriteAttributeString("cellspacing", "0");

                            xmlTextWriter.WriteStartElement("tr");
                            {
                                xmlTextWriter.WriteStartElement("td");
                                {
                                    xmlTextWriter.WriteStartElement("b");
                                    {
                                        xmlTextWriter.WriteValue("Name A");
                                    }
                                    xmlTextWriter.WriteEndElement(); // b
                                }
                                xmlTextWriter.WriteEndElement(); // td

                                xmlTextWriter.WriteStartElement("td");
                                {
                                    xmlTextWriter.WriteStartElement("b");
                                    {
                                        xmlTextWriter.WriteValue("Name B");
                                    }
                                    xmlTextWriter.WriteEndElement(); // b
                                }
                                xmlTextWriter.WriteEndElement(); // td
                            }
                            xmlTextWriter.WriteEndElement(); // tr

                            foreach (DataGridViewRow row in _mappingsDataGridView.Rows)
                            {
                                if (!row.IsNewRow)
                                {
                                    WriteHtmlTableRow(xmlTextWriter, row.Cells[0].Value as String, row.Cells[1].Value as String);
                                }
                            }
                        }
                        xmlTextWriter.WriteEndElement(); // table

                        xmlTextWriter.WriteStartElement("h2");
                        {
                            xmlTextWriter.WriteValue("Results");
                        }
                        xmlTextWriter.WriteEndElement(); // h2

                        xmlTextWriter.WriteStartElement("table");
                        {
                            xmlTextWriter.WriteAttributeString("border", "1");
                            xmlTextWriter.WriteAttributeString("cellpadding", "10");
                            xmlTextWriter.WriteAttributeString("cellspacing", "0");

                            foreach (DataGridViewRow row in _resultsDataGridView.Rows)
                            {
                                WriteHtmlTableRow(xmlTextWriter, (row.Cells[3].Value as WorkProgressEventArgs).Code.ToString(), row.Cells[1].Value as String);
                            }
                        }
                        xmlTextWriter.WriteEndElement(); // table
                    }
                    xmlTextWriter.WriteEndElement(); // body
                }
                xmlTextWriter.WriteEndElement(); // html
            }
            xmlTextWriter.WriteEndDocument();
            xmlTextWriter.Flush();

            stream.Position = 0;
            StreamReader streamReader = new StreamReader(stream, true);
            String result = streamReader.ReadToEnd();

            xmlTextWriter.Close();

            return result;
        }

        private void WriteHtmlTableRow(XmlTextWriter xmlTextWriter, String name, String value)
        {
            xmlTextWriter.WriteStartElement("tr");
            {
                xmlTextWriter.WriteStartElement("td");
                {
                    xmlTextWriter.WriteValue(name);
                }
                xmlTextWriter.WriteEndElement(); // td

                xmlTextWriter.WriteStartElement("td");
                {
                    xmlTextWriter.WriteValue(value);
                }
                xmlTextWriter.WriteEndElement(); // td
            }
            xmlTextWriter.WriteEndElement(); // tr
        }

        private void SaveMappingsFile()
        {
            if (File.Exists(FileName))
            {
                FileAttributes fileAttributes = File.GetAttributes(FileName);
                if ((fileAttributes & FileAttributes.ReadOnly) > 0)
                {
                    if (MessageBox.Show(this.ParentForm, "File is marked as read-only.  Overwrite?", "Alias", MessageBoxButtons.YesNo) == DialogResult.No)
                    {
                        return;
                    }

                    File.SetAttributes(FileName, fileAttributes & ~FileAttributes.ReadOnly);
                }
            }

            XmlDocument document = new XmlDocument();
            document.LoadXml(GenerateXmlToSave());
            document.Save(FileName);

            FireDataStateChanged(new DataStateChangedEventArgs(false, Path.GetFileName(FileName)));
        }

        private void FireDataStateChanged(DataStateChangedEventArgs dataStateChangedEventArgs)
        {
            _dataChanged = dataStateChangedEventArgs.Dirty;

            if (DataStateChanged != null)
            {
                DataStateChanged(this, dataStateChangedEventArgs);
            }
        }

        private void _resultsDataGridView_CellContentClick(Object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2)
            {
                ThreadPool.QueueUserWorkItem(new WaitCallback(DisplayErrorDetailsThreadFunction), _resultsDataGridView.Rows[e.RowIndex].Cells[1].Value + "\r\n\r\n" + (_resultsDataGridView.Rows[e.RowIndex].Cells[3].Value as WorkProgressEventArgs).Details);
            }
        }

        private void DisplayErrorDetailsThreadFunction(Object args)
        {
            String tempFileName = Path.GetTempFileName();
            using (StreamWriter streamWriter = new StreamWriter(tempFileName, false))
            {
                streamWriter.Write((String)args);
            }

            try
            {
                String notepadPath = Path.Combine(Environment.GetEnvironmentVariable("WINDIR"), @"notepad");

                Process notepadProcess;
                using (notepadProcess = new Process())
                {
                    notepadProcess.StartInfo.FileName = notepadPath;

                    notepadProcess.StartInfo.Arguments = tempFileName;
                    notepadProcess.StartInfo.CreateNoWindow = true;
                    notepadProcess.StartInfo.UseShellExecute = false;
                    notepadProcess.StartInfo.RedirectStandardInput = true;
                    notepadProcess.StartInfo.RedirectStandardOutput = true;
                    notepadProcess.StartInfo.RedirectStandardError = true;
                    notepadProcess.Start();
                    String output = notepadProcess.StandardOutput.ReadToEnd();
                    notepadProcess.WaitForExit();
                }
            }
            finally
            {
                File.Delete(tempFileName);
            }
        }

        private Boolean ValidateMappings()
        {
            _mappingsDataGridView.EndEdit();

            Boolean result = true;
            List<String> columnAValues = new List<String>();
            List<String> columnBValues = new List<String>();
            List<DataGridViewRow> rowsToRemove = new List<DataGridViewRow>();

            // check for rows that should be removed and rows with missing cell values
            foreach (DataGridViewRow row in _mappingsDataGridView.Rows)
            {
                if (!row.IsNewRow && String.IsNullOrEmpty(row.Cells[0].Value as String) && String.IsNullOrEmpty(row.Cells[1].Value as String))
                {
                    rowsToRemove.Add(row);
                }
                else
                {
                    if (String.IsNullOrEmpty(row.Cells[0].Value as String) && !String.IsNullOrEmpty(row.Cells[1].Value as String))
                    {
                        row.Cells[0].ErrorText = "A value should be specified for this cell.";
                        result = false;
                    }
                    else
                    {
                        row.Cells[0].ErrorText = String.Empty;
                    }

                    if (String.IsNullOrEmpty(row.Cells[1].Value as String) && !String.IsNullOrEmpty(row.Cells[0].Value as String))
                    {
                        row.Cells[1].ErrorText = "A value should be specified for this cell.";
                        result = false;
                    }
                    else
                    {
                        row.Cells[1].ErrorText = String.Empty;
                    }
                }
            }

            // remove rows which have only blank cells
            foreach (DataGridViewRow row in rowsToRemove)
            {
                _mappingsDataGridView.Rows.Remove(row);
            }

            if (!result)
            {
                MessageBox.Show(this, String.Format("One or more missing values found."), "Alias", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // check for duplicates inside a column
            if (result)
            {
                foreach (DataGridViewRow row in _mappingsDataGridView.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        if (!columnAValues.Contains(row.Cells[0].Value as String))
                        {
                            columnAValues.Add(row.Cells[0].Value as String);
                            row.Cells[0].ErrorText = String.Empty;
                        }
                        else
                        {
                            result = false;
                            row.Cells[0].ErrorText = "This value is a duplicate of another in this column.";
                        }

                        if (!columnBValues.Contains(row.Cells[1].Value as String))
                        {
                            columnBValues.Add(row.Cells[1].Value as String);
                            row.Cells[1].ErrorText = String.Empty;
                        }
                        else
                        {
                            result = false;
                            row.Cells[1].ErrorText = "This value is a duplicate of another in this column.";
                        }
                    }
                }

                if (!result)
                {
                    MessageBox.Show(this, String.Format("One or more duplicates found."), "Alias", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            // check for duplicates between columns
            if (result)
            {
                foreach(String columnAValue in columnAValues)
                {
                    if (columnBValues.Contains(columnAValue))
                    {
                        result = false;
                        _mappingsDataGridView.Rows[columnBValues.IndexOf(columnAValue)].Cells[1].ErrorText = "This is a duplicate of a cell in the 'Name A' column";
                        _mappingsDataGridView.Rows[columnAValues.IndexOf(columnAValue)].Cells[0].ErrorText = "This is a duplicate of a cell in the 'Name B' column";
                    }
                }

                if (!result)
                {
                    MessageBox.Show(this, String.Format("One or more duplicates between columns found."), "Alias", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            if (result)
            {
                if (columnBValues.Count == 0)
                {
                    result = false;
                    MessageBox.Show(this, String.Format("No mappings specified."), "Alias", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            if (!result)
            {
                _mappingsDataGridView.Refresh();
            }

            return result;
        }

        private void _mappingsDataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            _mappingsDataGridView.CurrentCell.ErrorText = String.Empty;
            _mappingsDataGridView.CurrentCell.Value = (_mappingsDataGridView.CurrentCell.Value as String).Trim();

            FireDataStateChanged(new DataStateChangedEventArgs(true, Path.GetFileName(FileName)));
        }

        private delegate DialogResult PromptUserDelegate(String text, String caption);
        public DialogResult RetryCancel(String text, String caption)
        {
            DialogResult result = DialogResult.None;

            if (this.InvokeRequired)
            {
                result = (DialogResult)Invoke(new PromptUserDelegate(RetryCancel), text, caption);
            }
            else
            {
                result = MessageBox.Show(text, caption, MessageBoxButtons.RetryCancel);
            }

            return result;
        }

        private void _showingToolStripComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                WorkProgressEventArgs args;
                foreach (DataGridViewRow row in _resultsDataGridView.Rows)
                {
                    if (_showingToolStripComboBox.SelectedIndex == 0)
                    {
                        row.Visible = true;
                    }
                    else
                    {
                        args = (row.Cells[3].Value as WorkProgressEventArgs);
                        row.Visible = (args.Code == WorkProgressCode.Info || args.Code == WorkProgressCode.Fail);
                    }
                }
            }
            finally
            {
                this.Cursor = Cursors.Default;
                if (_resultsDataGridView.Rows.Count > 0)
                {
                    // set FirstDisplayedScrollingRowIndex to first visible row
                    for (Int32 i = 0; i < _resultsDataGridView.Rows.Count; i++)
                    {
                        if (_resultsDataGridView.Rows[i].Visible)
                        {
                            _resultsDataGridView.FirstDisplayedScrollingRowIndex = i;
                            break;
                        }
                    }
                }
            }
        }

        #endregion

        public event EventHandler DataStateChanged;

        private Boolean DataChanged
        { get { return _dataChanged; } }

        private String FileName
        { get { return _fileName; } }

        [DllImport("user32.dll")]
        private static extern Int16 FlashWindowEx(ref FLASHWINFO pwfi);

        [StructLayout(LayoutKind.Sequential)]
        private struct FLASHWINFO
        {
            public UInt16 cbSize;
            public IntPtr hwnd;
            public UInt32 dwFlags;
            public UInt16 uCount;
            public UInt32 dwTimeout;
        }

        //Stop flashing. The system restores the window to its original state. 
        private const UInt32 FLASHW_STOP = 0;
        //Flash the window caption. 
        private const UInt32 FLASHW_CAPTION = 1;
        //Flash the taskbar button. 
        private const UInt32 FLASHW_TRAY = 2;
        //Flash both the window caption and taskbar button.
        //This is equivalent to setting the FLASHW_CAPTION | FLASHW_TRAY flags. 
        private const UInt32 FLASHW_ALL = 3;
        //Flash continuously, until the FLASHW_STOP flag is set. 
        private const UInt32 FLASHW_TIMER = 4;
        //Flash continuously until the window comes to the foreground. 
        private const UInt32 FLASHW_TIMERNOFG = 12;

        #region Private fields
        private Engine _engine = new Engine();
        private String _processToolTip;
        private Boolean _dataChanged;
        private String _fileName = String.Empty;
        private UInt32 _csprojFileCount;
        private UInt32 _libraryConfigFileCount;
        private UInt32 _solutionFileCount;
        private UInt32 _finalBuilderFileCount;
        #endregion
    }
}
