﻿using System;
using System.Collections.Specialized;
using System.Collections.ObjectModel;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class WXSReplaceDirectoryIdTokensStep : IStep
    {
        public WXSReplaceDirectoryIdTokensStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourceFile = Utils.GetRequiredAttribute(navigator, Constants.SourceFileAttribute, Constants.WXSReplaceDirectoryIdTokensElement, configInfo.ConfigFile);
            _token = Utils.GetRequiredAttribute(navigator, "Token", Constants.WXSReplaceDirectoryIdTokensElement, configInfo.ConfigFile);
        }


        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_sourceFile), rootConfigInfo);
            String token = rootConfigInfo.ReplaceAllVariables(_token);

            XmlDocument document = new XmlDocument();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(document.NameTable);
            namespaceManager.AddNamespace(String.Empty, "http://schemas.microsoft.com/wix/2006/wi");
            namespaceManager.AddNamespace("ns", "http://schemas.microsoft.com/wix/2006/wi");
            document.Load(sourceFile);

            XmlNodeList directoryNodesWithNoChildren = document.SelectNodes("//processing-instruction()", namespaceManager);
            if (directoryNodesWithNoChildren.Count > 0)
            {
                foreach (XmlNode node in directoryNodesWithNoChildren)
                {
                    if (node.Name == "include")
                    {
                        ProcessIncludedFile(token, GetParentDirectoryId(node), node.Value, Path.GetDirectoryName(sourceFile));
                    }
                }
            }
        }

        private void ProcessIncludedFile(String token, String parentDirectoryId, String fileName, String directory)
        {
            if (!Path.IsPathRooted(fileName))
            {
                fileName = Path.Combine(directory, fileName);
            }


            String fileContents = File.ReadAllText(fileName);
            String newFileContents = Regex.Replace(fileContents, token, parentDirectoryId, RegexOptions.None);
            try
            {
                if (fileContents != newFileContents)
                {
                    File.SetAttributes(fileName, File.GetAttributes(fileName) & ~FileAttributes.ReadOnly);
                    File.WriteAllText(fileName, newFileContents);
                }
            }
            catch (Exception ex)
            {
                using (BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, String.Format(CultureInfo.CurrentCulture, "Regular expression file replacement failed;  failed to replace expression in '{0}'.", fileName));
                    output.AddErrorDetail("SearchExpression", token);
                    output.AddErrorDetail("ReplaceExpression", parentDirectoryId);
                    output.AddErrorDetail("FileSpec", fileName);
                    output.AddErrorDetail(Strings.Error, ex.ToString());
                    output.EndWriteError();
                }
            }

            XmlDocument document = new XmlDocument();
            document.Load(fileName);

            XmlNodeList directoryNodesWithNoChildren = document.SelectNodes("//processing-instruction()");
            if (directoryNodesWithNoChildren.Count > 0)
            {
                foreach (XmlNode node in directoryNodesWithNoChildren)
                {
                    if (node.Name == "include")
                    {
                        ProcessIncludedFile(token, parentDirectoryId, node.Value, Path.GetDirectoryName(fileName));
                    }
                }
            }
        }

        private String GetParentDirectoryId(XmlNode node)
        {
            String result= String.Empty;

            XmlNode currentNode = node.ParentNode;
            do
            {
                if (currentNode != null && (currentNode.Name == "Directory" || currentNode.Name == "DirectoryRef"))
                {
                    result = currentNode.Attributes["Id"].Value;
                }
                currentNode = currentNode.ParentNode;
            } while (String.IsNullOrEmpty(result) && currentNode != null);

            return result;
        }

        #endregion

        private String _sourceFile;
        private String _token;
    }
}
