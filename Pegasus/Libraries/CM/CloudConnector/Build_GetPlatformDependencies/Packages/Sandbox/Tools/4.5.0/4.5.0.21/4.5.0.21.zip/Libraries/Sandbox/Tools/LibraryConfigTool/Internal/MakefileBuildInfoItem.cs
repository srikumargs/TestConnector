using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;

namespace LibraryConfigTool.Internal
{
    //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
    internal sealed class MakefileBuildInfoItem : BuildInfoItem
    {
        public MakefileBuildInfoItem(ConfigInfo configInfo, XPathNavigator navigator)
            : base(Constants.MakefileBuildInfoElement, configInfo, navigator)
        {
        }
    }
}
