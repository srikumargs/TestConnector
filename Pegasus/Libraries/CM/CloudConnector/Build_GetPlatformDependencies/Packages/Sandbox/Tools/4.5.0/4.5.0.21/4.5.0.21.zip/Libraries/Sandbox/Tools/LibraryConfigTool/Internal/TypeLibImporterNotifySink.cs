using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class TypeLibImporterNotifySink : ITypeLibImporterNotifySink
    {
        public TypeLibImporterNotifySink(IMessageSink outputMessageSink)
        {
            _outputMessageSink = outputMessageSink;
        }

        public void ReportEvent(ImporterEventKind eventKind, Int32 eventCode, String eventMsg)
        {
            Output(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "eventKind='{0}' eventCode='{1}' eventMsg='{2}'", eventKind, eventCode, eventMsg));
        }

        public Assembly ResolveRef(Object typeLibAsObject)
        {
            // Resolve the reference here and return the correct asembly for the type library.

            ITypeLib typeLib = typeLibAsObject as ITypeLib;
            String name;
            String docString;
            Int32 helpContext;
            String helpFile;
            typeLib.GetDocumentation(-1, out name, out docString, out helpContext, out helpFile);
            Output(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "name='{0}' docString='{1}' helpContext='{2}' helpFile='{3}'", name, docString, helpContext, helpFile));
            String assemblyName = String.Format(CultureInfo.InvariantCulture, "Interop.{0}", name);
            Output(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "Attempting to load '{0}'...", assemblyName));
            Assembly result = Assembly.Load(assemblyName);
            if(result == null)
            {
                Output(OutputType.Error, String.Format(CultureInfo.CurrentCulture, "Failed to load '{0}'...", assemblyName));
            }
            return result;
        }

        private void Output(OutputType outputType, String message)
        {
            Output(outputType, IndentAction.None, message);
        }

        private void Output(OutputType outputType, IndentAction indentAction, String message)
        {
            _outputMessageSink.SyncProcessMessage(new OutputMessage(outputType, indentAction, message));
        }

        private IMessageSink _outputMessageSink;
    }
}
