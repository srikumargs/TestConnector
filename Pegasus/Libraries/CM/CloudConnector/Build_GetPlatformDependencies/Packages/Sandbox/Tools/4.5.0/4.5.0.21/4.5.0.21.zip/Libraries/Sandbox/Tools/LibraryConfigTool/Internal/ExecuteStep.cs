using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Diagnostics;

namespace LibraryConfigTool.Internal
{
    internal sealed class ExecuteStep : IStep
    {
        public ExecuteStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _fileName = Utils.GetRequiredAttribute(navigator, Constants.FileNameAttribute, Constants.ExecuteElement, configInfo.ConfigFile);
            _arguments = Utils.GetOptionalAttribute(navigator, Constants.ArgumentsAttribute);
            _workingDirectory = Utils.GetRequiredAttribute(navigator, Constants.WorkingDirectoryAttribute, Constants.ExecuteElement, configInfo.ConfigFile);
            _stdOutFile = Utils.GetOptionalAttribute(navigator, Constants.StdOutFileAttribute);
            _ignoreExitCode = Utils.GetOptionalAttribute(navigator, "IgnoreExitCode");
            _retryCount = 0;
            String retryCount = Utils.GetOptionalAttribute(navigator, Constants.RetryCountAttribute);
            if (!String.IsNullOrEmpty(retryCount))
            {
                try
                {
                    _retryCount = Convert.ToInt32(retryCount);
                    if (_retryCount < 0)
                    {
                        Trace.WriteLine("Invalid RetryCount, setting retry count to 0.");
                        _retryCount = 0;
                    }
                    else if (_retryCount > 10)
                    {
                        // this is an arbitrary ceiling, but people are probably misusing the retry count if greater than 10
                        _retryCount = 10;
                        Trace.WriteLine("Invalid RetryCount, setting retry count to a maximum of 10.");
                    }
                }
                catch
                {
                    /* ignore */
                    Trace.WriteLine("Invalid RetryCount, setting retry count to 0.");
                }
            }
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String fileName = rootConfigInfo.ReplaceAllVariables(_fileName);
            String arguments = rootConfigInfo.ReplaceAllVariables(_arguments);
            String workingDirectory = rootConfigInfo.ReplaceAllVariables(_workingDirectory);
            String stdOutFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_stdOutFile), rootConfigInfo);
            Boolean ignoreExitCode = false;
            if (!String.IsNullOrEmpty(_ignoreExitCode))
            {
                ignoreExitCode = Boolean.Parse(rootConfigInfo.ReplaceAllVariables(_ignoreExitCode));
            }

            if (!File.Exists(fileName))
            {
                using (BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, Strings.ExternalCommandFiledFileNotFound);
                    output.AddErrorDetail(Strings.FileName, fileName);
                    output.AddErrorDetail(Strings.Arguments, arguments);
                    output.AddErrorDetail("WorkingDirectory", workingDirectory);
                    output.AddErrorDetail("StdOutFile", stdOutFile);
                    output.AddErrorDetail("RetryCount", _retryCount.ToString());
                    output.EndWriteError();
                }
            }
            else
            {
                _allStdErrOutput = new StringBuilder();

                try
                {
                    int remainingAttempts = _retryCount + 1;
                    bool bSuccess = false;
                    while (remainingAttempts > 0 && !bSuccess)
                    {
                        --remainingAttempts;
                        _stdErrOutput = new StringBuilder();

                        Process process;
                        using (process = new Process())
                        {
                            process.StartInfo.FileName = fileName;
                            process.StartInfo.Arguments = arguments;
                            process.StartInfo.WorkingDirectory = workingDirectory;
                            process.StartInfo.CreateNoWindow = true;
                            process.StartInfo.UseShellExecute = false;
                            process.StartInfo.RedirectStandardInput = true;
                            process.StartInfo.RedirectStandardOutput = true;
                            process.StartInfo.RedirectStandardError = true;
                            process.ErrorDataReceived += new DataReceivedEventHandler(process_ErrorDataReceived);
                            process.Start();
                            process.BeginErrorReadLine();
                            String standardOutput = process.StandardOutput.ReadToEnd();
                            process.WaitForExit();
                            if (ignoreExitCode || 0 == process.ExitCode)
                            {
                                bSuccess = true;
                                Program.Output.Write(OutputType.Info, Strings.SuccessfullyExecutedExternalCommand);
                                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "FileName:         '{0}'", fileName));
                                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Arguments:        '{0}'", arguments));
                                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "WorkingDirectory: '{0}'", workingDirectory));
                                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "StdOutFile:       '{0}'", stdOutFile));
                                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "RetryCount:       '{0}'", _retryCount.ToString()));
                            }
                            else
                            {
                                if (remainingAttempts > 0)
                                {
                                    Program.Output.Write(OutputType.Status, Strings.ExternalCommandFailedCommandReturnedNonZeroExitCode);
                                    Program.Output.Write(OutputType.Status, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "ExitCode:         '{0}'", process.ExitCode.ToString(CultureInfo.InvariantCulture)));
                                    Program.Output.Write(OutputType.Status, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "FileName:         '{0}'", fileName));
                                    Program.Output.Write(OutputType.Status, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Arguments:        '{0}'", arguments));
                                    Program.Output.Write(OutputType.Status, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "WorkingDirectory: '{0}'", workingDirectory));
                                    Program.Output.Write(OutputType.Status, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "StdOutFile:       '{0}'", stdOutFile));
                                    Program.Output.Write(OutputType.Status, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "RetryCount:       '{0}'", _retryCount.ToString()));
                                }
                                else
                                {
                                    if (_allStdErrOutput.Length > 0)
                                    {
                                        Program.Output.Write(OutputType.Status, IndentAction.NoIndent, _allStdErrOutput.ToString());
                                    }

                                    using (BatchedOutput output = new BatchedOutput(false))
                                    {
                                        output.BeginWriteError(0, Strings.ExternalCommandFailedCommandReturnedNonZeroExitCodeNoRetries);
                                        output.AddErrorDetail("ExitCode", process.ExitCode.ToString(CultureInfo.InvariantCulture));
                                        output.AddErrorDetail(Strings.FileName, fileName);
                                        output.AddErrorDetail(Strings.Arguments, arguments);
                                        output.AddErrorDetail("WorkingDirectory", workingDirectory);
                                        output.AddErrorDetail("StdOutFile", stdOutFile);
                                        output.AddErrorDetail("RetryCount", _retryCount.ToString());
                                        output.EndWriteError();
                                    }
                                }
                            }

                            if (!String.IsNullOrEmpty(standardOutput))
                            {
                                if (String.IsNullOrEmpty(stdOutFile))
                                {
                                    Program.Output.Write(OutputType.Status, IndentAction.NoIndent, String.Format(CultureInfo.CurrentCulture, "(Begin StdOut from '{0}')", Path.GetFileName(fileName)));
                                    Program.Output.Write(OutputType.Status, IndentAction.NoIndent, standardOutput);
                                    Program.Output.Write(OutputType.Status, IndentAction.NoIndent, String.Format(CultureInfo.CurrentCulture, "(End StdOut from '{0}')", Path.GetFileName(fileName)));
                                }
                                else
                                {
                                    using (IndentedOutput indentedOutput = new IndentedOutput())
                                    {
                                        try
                                        {
                                            Utils.EnsureDirectoryExists(Path.GetDirectoryName(stdOutFile), "TargetDir");

                                            using (StreamWriter streamWriter = new StreamWriter(stdOutFile))
                                            {
                                                streamWriter.Write(standardOutput);
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            using (BatchedOutput output = new BatchedOutput(false))
                                            {
                                                output.BeginWriteError(0, "Failed to emit data.");
                                                output.AddErrorDetail(Strings.Error, ex.ToString());
                                                output.EndWriteError();
                                            }
                                        }
                                    }
                                }
                            }

                            if (!String.IsNullOrEmpty(_stdErrOutput.ToString()))
                            {
                                // MADNESS! If we actually echo verbatim specially-formmated stderr output, MSBUILD may think we have failed even if we return ExitCode = 0.
                                // A prime example of this kind of thing is when signtool is having a problem and prints
                                //     "EXEC : SignTool error : The specified timestamp server could not be reached." 
                                // to its stderr.  In this workaround we avoid outputting any stderr until we determine that the retries are also going to fail

                                _allStdErrOutput.AppendFormat(CultureInfo.CurrentCulture, "(Begin StdErr from '{0}')", Path.GetFileName(fileName));
                                _allStdErrOutput.AppendLine();
                                _allStdErrOutput.AppendFormat(CultureInfo.CurrentCulture, _stdErrOutput.ToString().Substring(0, _stdErrOutput.ToString().Length - Environment.NewLine.Length));
                                _allStdErrOutput.AppendLine();
                                _allStdErrOutput.AppendFormat(CultureInfo.CurrentCulture, "(End StdErr from '{0}')", Path.GetFileName(fileName));
                                _allStdErrOutput.AppendLine();
                            }

                            if (remainingAttempts > 0 && !bSuccess)
                            {
                                Program.Output.Write(OutputType.Status, IndentAction.NoIndent, "Retrying last step in 5 seconds");
                                System.Threading.Thread.Sleep(5000);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    using (BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, Strings.ExternalCommandFailed);
                        output.AddErrorDetail(Strings.FileName, fileName);
                        output.AddErrorDetail(Strings.Arguments, arguments);
                        output.AddErrorDetail("WorkingDirectory", workingDirectory);
                        output.AddErrorDetail("StdOutFile", stdOutFile);
                        output.AddErrorDetail("RetryCount", _retryCount.ToString());
                        output.AddErrorDetail(Strings.Error, ex.ToString());
                        output.EndWriteError();
                    }
                }
            }
        }

        void process_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (!String.IsNullOrEmpty(e.Data))
            {
                _stdErrOutput.Append(e.Data + Environment.NewLine);
            }
        }

        #endregion

        private String _fileName;
        private String _arguments;
        private String _workingDirectory;
        private String _stdOutFile;
        private String _ignoreExitCode;
        private Int32 _retryCount;
        private StringBuilder _stdErrOutput;
        private StringBuilder _allStdErrOutput;
    }
}
