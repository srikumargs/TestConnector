using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class BatchedOutput : IDisposable
    {
        public BatchedOutput():this(true)
        {
        }

        public BatchedOutput(Boolean respectIndentation)
        {
            _respectIndentation = respectIndentation;
        }

        ~BatchedOutput()
        {
            Dispose(false);
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            if(false == _disposed)
            {
                Dispose(true);
                _disposed = true;

                // Take yourself off the Finalization queue to prevent
                // finalization code for this Object from executing a second time.
                GC.SuppressFinalize(this);
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        /// <param name="disposing"></param>
        private void Dispose(Boolean disposing)
        {
            if(disposing)
            {
                // Dispose managed code here.
                if(_writingError)
                {
                    EndWriteError();
                }

                if(_respectIndentation)
                {
                    Program.Output.ChangeIndent(IndentAction.Increment);
                }
                else
                {
                    Program.Output.PushIndentLevel(0);
                }

                foreach(ResultEventArgs resultEventArg in _batchedOutput)
                {
                    Program.Output.Write(null, resultEventArg);
                }

                if(_respectIndentation)
                {
                    Program.Output.ChangeIndent(IndentAction.Decrement);
                }
                else
                {
                    Program.Output.PopIndentLevel();
                }
            }

            // Dispose unmanaged resources here. (This Objectdoesn't currently have any.)
        }

        public void Write(OutputType outputType, String description)
        {
            Write(null, new ResultEventArgs(outputType, IndentAction.None, description));
        }

        public void Write(OutputType outputType, IndentAction indentAction, String description)
        {
            Write(null, new ResultEventArgs(outputType, indentAction, description));
        }

        public void Write(Object sender, ResultEventArgs args)
        {
            _batchedOutput.Add(args);
        }

        public void BeginWriteError(Int32 code, String message)
        {
            System.Diagnostics.Debug.Assert(!_writingError, "Invalid state;  _writingError is already true.");

            _writingError = true;

            // "Formatting the Output of a Custom Build Step or Build Event"
            // http://msdn2.microsoft.com/en-us/library/yxkt8b26(VS.80).aspx
            Write(OutputType.Error, String.Format(CultureInfo.CurrentCulture, "LibraryConfigTool : error : {0} LCT{1,-4:0000} : {2}", Program.CurrentCommand, code, message));
            Write(OutputType.Error, "[");
        }

        public void WriteError(String message)
        {
            Write(OutputType.Error, IndentAction.IndentOnce, message);
        }

        public void EndWriteError()
        {
            System.Diagnostics.Debug.Assert(_writingError, "Invalid state;  _writingError is not true.");
            Write(OutputType.Error, "]");
            _writingError = false;
        }

        public void AddErrorDetail(String name, String value)
        {
            ResultEventArgs args = _batchedOutput[0];
            String message = String.Format(CultureInfo.CurrentCulture, "{0}: '{1}'.", name, value);
            _batchedOutput[0] = new ResultEventArgs(args.OutputType, args.IndentAction, args.Description + "  " + message);
            WriteError(message);
        }

        #region Private fields
        private Boolean _disposed; //= false; (automatically initialized by runtime)
        private Boolean _respectIndentation; //= false; (automatically initialized by runtime)
        private List<ResultEventArgs> _batchedOutput = new List<ResultEventArgs>();
        private Boolean _writingError;//= false; (automatically initialized by runtime)
        #endregion
    }
}
