using System;
using System.Collections.Generic;

namespace DevBoxCleaner.Internal
{
    internal sealed class EngineOptions
    {
        #region Fields

        private List<string> _exemptPaths = new List<string>();

        #endregion

        public Boolean TestOnly
        {
            get;
            set;
        }

        public Boolean Gac
        {
            get;
            set;
        }

        public Boolean Registry
        {
            get;
            set;
        }

        public Boolean Sandbox
        {
            get;
            set;
        }

        public String SandboxLocation
        {
            get;
            set;
        }

        public String RegBase
        {
            get;
            set;
        }

        /// <summary>
        /// Gets a list of files or directories that are exempt from cleaning.
        /// </summary>
        public IList<String> ExemptPaths
        {
            get { return this._exemptPaths; }
        }
    }
}
