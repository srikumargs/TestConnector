﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace Alias.Internal
{
    internal struct EngineOptions
    {
        public EngineOptions(Boolean testOnly, ReadOnlyCollection<String> fileFolderSpecifications, Boolean recursive, AliasProcessorOptions processorOptions)
        {
            _testOnly = testOnly;
            _fileFolderSpecifications = fileFolderSpecifications;
            _recursive = recursive;
            _processorOptions = processorOptions;
        }

        public Boolean TestOnly
        { get { return _testOnly; } }

        public ReadOnlyCollection<String> RootFolder
        { get { return _fileFolderSpecifications; } }

        public Boolean Recursive
        { get { return _recursive; } }

        public AliasProcessorOptions ProcessorOptions
        { get { return _processorOptions; } }

        private Boolean _testOnly;
        private ReadOnlyCollection<String> _fileFolderSpecifications;
        private Boolean _recursive;
        private AliasProcessorOptions _processorOptions;
    }
}
