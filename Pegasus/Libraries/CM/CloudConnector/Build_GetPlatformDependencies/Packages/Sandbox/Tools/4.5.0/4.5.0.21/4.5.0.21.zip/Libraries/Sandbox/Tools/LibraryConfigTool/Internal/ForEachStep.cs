using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Xml.XPath;

namespace LibraryConfigTool.Internal
{
    internal sealed class ForEachStep : IStep
    {
        public ForEachStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _iterationVariableName = Utils.GetRequiredAttribute(navigator, Constants.IterationVariableNameAttribute, Constants.ForEachElement, configInfo.ConfigFile);
            _collection = Utils.GetOptionalAttribute(navigator, Constants.CollectionAttribute);
            _collectionName = Utils.GetOptionalAttribute(navigator, "CollectionName");

            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = navigator.SelectChildren(XPathNodeType.Element);
                while (iterator.MoveNext())
                {
                    _steps.Add(StepFactory.Create(configInfo, iterator.Current));
                }
            }
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            ReadOnlyCollection<String> collectionVariableValues = null;

            if ((String.IsNullOrEmpty(_collection) && String.IsNullOrEmpty(_collectionName)) ||
               (!String.IsNullOrEmpty(_collection) && !String.IsNullOrEmpty(_collectionName)))
            {
                throw new LibraryConfigSchemaException(rootConfigInfo.ConfigFile, Strings.CollectionOrCollectionNameRequired);
            }



            String collectionName = rootConfigInfo.ReplaceAllVariables(_collectionName);
            if (!String.IsNullOrEmpty(_collection))
            {
                collectionVariableValues = rootConfigInfo.GetCollectionVariableValue(_collection);
            }
            else if (!String.IsNullOrEmpty(collectionName))
            {
                collectionVariableValues = rootConfigInfo.GetCollectionVariableValue(Utils.GetVariableNameKeyForVariableName(collectionName));
            }

            if (collectionVariableValues != null)
            {
                foreach (String collectionVariableValue in collectionVariableValues)
                {
                    rootConfigInfo.DefineVariable(_iterationVariableName, rootConfigInfo.ReplaceAllVariables(collectionVariableValue));

                    foreach (IStep step in _steps)
                    {
                        step.Execute(rootConfigInfo);
                    }

                    rootConfigInfo.UndefineVariable(_iterationVariableName);
                }
            }
        }

        #endregion

        private String _iterationVariableName;
        private String _collection;
        private String _collectionName;
        private readonly List<IStep> _steps = new List<IStep>();
    }
}
