﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal class TargetGroup
    {
        public TargetGroup(ConfigInfo configInfo, XPathNavigator navigator)
        {
            Program.Output.Write(OutputType.Verbose, "Adding target group:");
            _id = Utils.GetRequiredAttribute(navigator, Constants.IdAttribute, Constants.TargetGroupsExpression, configInfo.ConfigFile);

            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = navigator.SelectChildren(XPathNodeType.Element);
                while (iterator.MoveNext())
                {
                    _targetInfo.Add(new TargetInfo(configInfo, iterator.Current));
                }
            }
        }

        public String Id
        { get { return _id; } }


        public ReadOnlyCollection<TargetInfo> TargetInfoItems
        {
            get
            {
                return _targetInfo.AsReadOnly();
            }
        }

        private String _id;
        private readonly List<TargetInfo> _targetInfo = new List<TargetInfo>();
    }
}
