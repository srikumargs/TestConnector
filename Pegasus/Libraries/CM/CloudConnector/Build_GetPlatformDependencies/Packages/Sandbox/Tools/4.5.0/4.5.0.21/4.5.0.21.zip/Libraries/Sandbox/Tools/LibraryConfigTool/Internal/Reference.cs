﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Linq;
using System.IO;

namespace LibraryConfigTool.Internal
{
    internal sealed class Reference
    {
        public Reference(ConfigInfo configInfo, XPathNavigator navigator)
        {
            Program.Output.Write(OutputType.Verbose, "Adding reference:");
            _librarySetId = Utils.GetRequiredAttribute(navigator, Constants.LibrarySetIdAttribute, Constants.ReferencesExpression, configInfo.ConfigFile);
            _libraryName = Utils.GetRequiredAttribute(navigator, Constants.LibraryNameAttribute, Constants.ReferencesExpression, configInfo.ConfigFile);
        }

        public String LibrarySetId
        { get { return _librarySetId; } }

        public String LibraryName
        { get { return _libraryName; } }

        public string UniqueName
        { get { return this.ToString(); } }

        public override string ToString()
        { return FormatUniqueName(this.LibrarySetId, this.LibraryName); }

        public static String FormatUniqueName(String librarySetId, String libraryName)
        { return string.Format("{0}_{1}", librarySetId, libraryName);         }

        private String _librarySetId;
        private String _libraryName;
    }
}
