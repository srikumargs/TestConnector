using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Globalization;
using System.Reflection;

namespace RegexRunner
{
    class Program
    {
        enum Command
        {
            Find,
            Replace
        }

        static void Main(string[] args)
        {
            Environment.ExitCode = -1;

            try
            {
                if(args.GetLength(0) == 0 || string.Compare(args[0], "/help", true, CultureInfo.InvariantCulture) == 0 || string.Compare(args[0], "/?", true, CultureInfo.InvariantCulture) == 0)
                {
                    PrintHelp();
                    Environment.ExitCode = 1;
                }
                else if(string.Compare(args[0], "/find", true, CultureInfo.InvariantCulture) == 0 || string.Compare(args[0], "/f", true, CultureInfo.InvariantCulture) == 0)
                {
                    ParseArgs(Command.Find, args, 2);

                    PrintBanner();

                    int matchedFiles = 0;
                    string[] fileNames = Directory.GetFiles(_searchPathSpecification, _searchFileSpecification, SearchOption);
                    foreach(string fileName in fileNames)
                    {
                        string fileContents = File.ReadAllText(fileName);
                        MatchCollection matchCollection = Regex.Matches(fileContents, _searchExpression, RegexOptions);
                        if(matchCollection.Count > 0)
                        {
                            matchedFiles++;
                            Console.WriteLine(fileName);
                        }
                    }

                    Console.WriteLine();
                    Console.WriteLine("Found expression in {0} files.", matchedFiles);
                    Environment.ExitCode = 0;
                }
                else if(string.Compare(args[0], "/replace", true, CultureInfo.InvariantCulture) == 0 || string.Compare(args[0], "/r", true, CultureInfo.InvariantCulture) == 0)
                {
                    ParseArgs(Command.Replace, args, 3);

                    PrintBanner();

                    int matchedFiles = 0;
                    int failedFiles = 0;
                    string[] fileNames = Directory.GetFiles(_searchPathSpecification, _searchFileSpecification, SearchOption);
                    foreach(string fileName in fileNames)
                    {
                        string fileContents = File.ReadAllText(fileName);
                        if(Regex.IsMatch(fileContents, _searchExpression, RegexOptions))
                        {
                            matchedFiles++;
                            Console.WriteLine(fileName);
                            string newFileContents = Regex.Replace(fileContents, _searchExpression, _replaceExpression, RegexOptions);
                            try
                            {
                                if(fileContents != newFileContents)
                                {
                                    File.SetAttributes(fileName, File.GetAttributes(fileName) & ~FileAttributes.ReadOnly);
                                    File.WriteAllText(fileName, newFileContents);
                                }
                            }
                            catch(Exception ex)
                            {
                                failedFiles++;
                                Console.WriteLine(ex.Message);
                            }
                        }
                    }

                    Console.WriteLine();
                    Console.WriteLine("Replaced expression in {0} files.", matchedFiles);
                    if(failedFiles > 0)
                    {
                        Console.WriteLine("Failed to replace expression in {0} files.", failedFiles);
                    }
                    Environment.ExitCode = 0;
                }
                else
                {
                    PrintHelp();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void PrintBanner()
        {
            if(!_suppressBanner)
            {
                Console.WriteLine("Sage Regular Expression Tool.  Version " + Assembly.GetExecutingAssembly().GetName().Version);
                Console.WriteLine();
            }
        }

        private static void PrintHelp()
        {
            PrintBanner();

            Console.WriteLine("Syntax: RegexRunner <Command> <file specification> [Options]");
            Console.WriteLine("Commands:");
            Console.WriteLine("  /find, /f <search expression>");
            Console.WriteLine("    Finds all instances of a given expression");
            Console.WriteLine("");
            Console.WriteLine("  /replace, /r <search expression> <replace expression>");
            Console.WriteLine("    Replaces all found instances with a given expression");
            Console.WriteLine("");
            Console.WriteLine("Options:");
            Console.WriteLine("  /ignorecase");
            Console.WriteLine("    Specifies case-insensitive matching");
            Console.WriteLine("");
            Console.WriteLine("  /recursive");
            Console.WriteLine("    Includes the specified directory and all the subdirectories");
            Console.WriteLine("    in a search operation");
            Console.WriteLine("");
            Console.WriteLine("  /nologo");
            Console.WriteLine("    Suppress display of the logo banner");
            Console.WriteLine("");
            Console.WriteLine("  /?, /help");
            Console.WriteLine("  Displays this usage mesage");
        }

        private static void ParseArgs(Command command, string[] args, int startIndex)
        {
            if(command == Command.Find)
            {
                _searchExpression = args[1];
                _searchPathSpecification = Path.GetFullPath(Path.GetDirectoryName(args[2]));
                _searchFileSpecification = Path.GetFileName(args[2]);
            }
            else if(command == Command.Replace)
            {
                _searchExpression = args[1];
                _replaceExpression = args[2];
                _searchPathSpecification = Path.GetFullPath(Path.GetDirectoryName(args[3]));
                _searchFileSpecification = Path.GetFileName(args[3]);
            }

            for(int i = startIndex ; i < args.GetLength(0) ; i++)
            {
                if(string.Compare(args[i], "/ignorecase", true, CultureInfo.InvariantCulture) == 0)
                {
                    _ignoreCase = true;
                }
                else if(string.Compare(args[i], "/recursive", true, CultureInfo.InvariantCulture) == 0)
                {
                    _recursive = true;
                }
                else if(string.Compare(args[i], "/nologo", true, CultureInfo.InvariantCulture) == 0)
                {
                    _suppressBanner = true;
                }
            }
        }

        private static RegexOptions RegexOptions
        {
            get
            {
                RegexOptions result = RegexOptions.None;
                
                if(_ignoreCase)
                {
                    result |= RegexOptions.IgnoreCase;
                }

                return result;
            }
        }

        private static SearchOption SearchOption
        {
            get
            {
                SearchOption result = SearchOption.TopDirectoryOnly;

                if(_recursive)
                {
                    result = SearchOption.AllDirectories;
                }

                return result;
            }
        }

        static string _searchExpression;        //= null; (automatically initialized by runtime)
        static string _replaceExpression;       //= null; (automatically initialized by runtime)
        static string _searchPathSpecification; //= null; (automatically initialized by runtime)
        static string _searchFileSpecification; //= null; (automatically initialized by runtime)
        static bool _suppressBanner;            //= false; (automatically initialized by runtime)
        static bool _ignoreCase;                //= false; (automatically initialized by runtime)
        static bool _recursive;                 //= false; (automatically initialized by runtime)
    }
}
