using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Text;

namespace LibraryConfigTool.Internal
{
    /// <summary>
    /// Exception thrown when two or more versions of the same library are specified
    /// </summary>
    [Serializable]
    [SuppressMessage("Microsoft.Design", "CA1032:ImplementStandardExceptionConstructors", Justification = "The thrower should alwys include the relevent exception information and therefore the default standard constructors should never be used")]
    public sealed class MultipleConfigVersionsException : Exception
    {
        #region Construction

        /// <summary>
        /// Construct an instance of the MultipleLibraryVersionsException class
        /// </summary>
        /// <param name="configFile">The full name of the library the has two or more versions specified</param>
        /// <param name="errorMessage">Error Message</param>
        public MultipleConfigVersionsException(String configFile, String errorMessage)
            : base(errorMessage)
        {
            Debug.Assert(!String.IsNullOrEmpty(configFile));
            Debug.Assert(!String.IsNullOrEmpty(errorMessage));

            _configFile = configFile;
        }

        /// <summary>
        /// Construct an instance of the MultipleLibraryVersionsException class
        /// </summary>
        /// <param name="configFile">The full name of the library the has two or more versions specified</param>
        /// <param name="errorMessage">ErrorMessage</param>
        /// <param name="innerException">An inner exception</param>
        public MultipleConfigVersionsException(String configFile, String errorMessage, Exception innerException)
            : base(errorMessage, innerException)
        {
            Debug.Assert(!String.IsNullOrEmpty(configFile));
            Debug.Assert(!String.IsNullOrEmpty(errorMessage));
            Debug.Assert(innerException != null);

            _configFile = configFile;
        }

        /// <summary>
        /// Serialization Constructor
        /// </summary>
        /// <param name="si">Serialization Info</param>
        /// <param name="sc">Streaming Context</param>
        private MultipleConfigVersionsException(SerializationInfo si, StreamingContext sc)
            : base(si, sc)
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Return the name of the library that has one or more versions specified
        /// </summary>
        public String LibraryName
        {
            get
            {
                return _configFile;
            }
        }

        #endregion

        #region Overrides

        /// <summary>
        /// Serialize the private fields
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            if(info != null)
            {
                info.AddValue(Constants.LibraryConfigFileField, _configFile);
            }
        }

        #endregion

        #region Private fields

        // The name of the library the has two or more versions specified
        private readonly String _configFile; //= null; (automatically initialized by runtime)

        #endregion
    }
}
