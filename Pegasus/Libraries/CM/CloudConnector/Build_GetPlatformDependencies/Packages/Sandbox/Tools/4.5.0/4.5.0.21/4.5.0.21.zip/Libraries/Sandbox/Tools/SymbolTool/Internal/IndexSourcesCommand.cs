﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.Build.Framework;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.VersionControl.Client;

namespace SymbolTool.Internal
{
    /// <summary>
    /// Defines a command to add meta-data to all PDB files stored in the specified directory.
    /// </summary>
    public class IndexSourcesCommand
    {
        #region Fields

        private string _sourceFilesDir = "";
        private string _targetDir = "";

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="IndexSourcesCommand"/> class.
        /// </summary>
        public IndexSourcesCommand()
        { }

        #endregion

        #region Properties

        /// <summary>
        /// The TFS server URL.
        /// </summary>
        public String TeamFoundationServerUrl
        { get; set; }

        /// <summary>
        /// Gets or sets the starting directory where the source files are located.
        /// </summary>
        public string SourceFilesDir
        {
            get { return _sourceFilesDir; }
            set { _sourceFilesDir = value; }
        }

        /// <summary>
        /// Gets or sets the target directory where the PDB files are located.
        /// </summary>
        public string TargetDir
        {
            get { return _targetDir; }
            set { _targetDir = value; }
        }

        #endregion

        #region Execute

        /// <summary>
        /// Executes the index sourcing process.
        /// </summary>
        /// <exception cref="SymbolToolException">The exception thrown if a failure occurs.</exception>
        public void Execute()
        {
            Program.Output.Write(OutputType.Status, string.Format(CultureInfo.CurrentCulture, "Preparing to perform index sourcing starting with directory '{0}'", this._sourceFilesDir));

            try
            {
                this.WriteFiles();
            }
            catch (Exception e)
            {
                throw new SymbolToolException("Source indexing could not be completed.", e);
            }
        }

        #endregion

        #region WriteFiles

        private void WriteFiles()
        {
            // Use TargetDir to locate all PDB files.
            IEnumerable<FileInfo> pdbFileCandidates = Utils.GetTopLevelFiles(this.TargetDir, new string[] { ".pdb" });

            foreach (System.IO.FileInfo pdbFilename in pdbFileCandidates)
            {
                Program.Output.Write(OutputType.Status, IndentAction.IndentOnce, string.Format(CultureInfo.CurrentCulture, "Processing file: '{0}'", pdbFilename));
                PdbFile pdb = new PdbFile(pdbFilename);
                IList<string> sourceFiles = PdbUtil.ReadSourceFiles(pdb);
                string tmpFile = Path.GetFullPath(Path.GetTempFileName());

                try
                {
                    using (StreamWriter sw = new StreamWriter(tmpFile))
                    {
                        sw.WriteLine("SRCSRV: ini ------------------------------------------------");
                        sw.WriteLine("VERSION=3");
                        sw.WriteLine("INDEXVERSION=2");
                        sw.WriteLine("VERCTRL=Team Foundation Server");
                        sw.WriteLine("DATETIME=" + DateTime.Now.ToString("ddd MMM dd h:mm:ss yyyy"));
                        sw.WriteLine("INDEXER=TFSTB");
                        sw.WriteLine("SRCSRV: variables ------------------------------------------");
                        sw.WriteLine("TFS_EXTRACT_CMD=tf.exe view /version:%var4% /noprompt \"$%var3%\" /server:\"%fnvar%(%var2%)\" /console >%srcsrvtrg%");
                        sw.WriteLine("TFS_EXTRACT_TARGET=%targ%\\%var2%%fnbksl%(%var3%)\\%fnfile%(%var5%)");
                        sw.WriteLine("SRCSRVVERCTRL=tfs");
                        sw.WriteLine("SRCSRVERRDESC=access");
                        sw.WriteLine("SRCSRVERRVAR=var2");
                        sw.WriteLine("VSTFSSERVER={0}", this.TeamFoundationServerUrl);
                        sw.WriteLine("SRCSRVTRG=%TFS_extract_target%");
                        sw.WriteLine("SRCSRVCMD=%TFS_extract_cmd%");
                        sw.WriteLine("SRCSRV: source files ---------------------------------------");
                        StringBuilder sb = new StringBuilder();
                        string programFiles1 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
                        string programFiles2 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);

                        foreach (string sourceFile in sourceFiles)
                        {
                            // Try to exclude as many source files from ProgramFiles as possible (IE header files in native libraries).
                            if (sourceFile.StartsWith(programFiles1) || 
                                sourceFile.StartsWith(programFiles2) ||
                                sourceFile.StartsWith("*"))
                            {
                                continue;
                            }

                            try
                            {
                                // Query TFS to get info about this source file.
                                TfsFileInfo tfsSourceFileInfo = GetTfsFileInfo(sourceFile);

                                // Exclude any files that are not source controlled.
                                if (tfsSourceFileInfo.LatestChangesetId != 0)
                                {
                                    if (sb.Length > 0)
                                    {
                                        sb.AppendLine();
                                    }

                                    // The expected format is as follows (all on a single line delimited with an asterisk).
                                    // 1. Local source file
                                    // 2. VSTFSSERVER
                                    // 3, TFS source location
                                    // 4. Latest changeset Id.
                                    // 5. Temp file name.

                                    // This is an actual example...
                                    // c:\TFS\Sage Estimating\Development\Oxbow\Libraries\ESTCRE\Tools\Sage.LMViewerInternalOnlyUtil\Resources\Strings.Designer.cs*MYSERVER*/Sage Estimating/Development/Oxbow/Libraries/ESTCRE/Tools/Sage.LMViewerInternalOnlyUtil/Resources/Strings.Designer.cs*185384
                                    sb.Append(sourceFile);
                                    sb.Append("*");
                                    sb.Append("VSTFSSERVER");
                                    sb.Append("*");

                                    // The script expects the dollar to have been removed.
                                    string tfsSourceLocationNoDollar = tfsSourceFileInfo.TfsSourceLocation;

                                    if (tfsSourceLocationNoDollar.StartsWith("$"))
                                    {
                                        tfsSourceLocationNoDollar = tfsSourceLocationNoDollar.Substring(1);
                                    }

                                    sb.Append(tfsSourceLocationNoDollar);
                                    sb.Append("*");
                                    sb.Append(tfsSourceFileInfo.LatestChangesetId);
                                    sb.Append("*");
                                    string filenameNoExt = Path.GetFileNameWithoutExtension(sourceFile);
                                    string extension = Path.GetExtension(sourceFile);

                                    string temp = string.Format(CultureInfo.InvariantCulture, "{0};C{1}{2}",
                                        filenameNoExt, tfsSourceFileInfo.LatestChangesetId, extension);

                                    sb.Append(temp);
                                }
                            }
                            catch (ItemNotMappedException)
                            {
                                // This is OK and common when working with native code PDB's because it contains all kinds of header files.
                            }
                            // Commenting this out for now because I don't think Microsoft exposes it.
                            /*
                            catch (Microsoft.TeamFoundation.InvalidPathException)
                            {

                            }
                            */ 
                        }

                        sw.WriteLine(sb.ToString());
                        sw.Write("SRCSRV: end ------------------------------------------------");
                    }

                    Program.Output.Write(OutputType.Verbose, IndentAction.IndentOnce, string.Format(CultureInfo.CurrentCulture, "Generated stream: '{0}'", File.ReadAllText(tmpFile)));

                    // Write the stream to the pdb file
                    PdbUtil.WriteSourceFileStream(pdb, new FileInfo(tmpFile));
                    Program.Output.Write(OutputType.Status, IndentAction.IndentOnce, string.Format(CultureInfo.CurrentCulture, "Successfully written stream to pdb: '{0}'", pdbFilename.FullName));
                }
                finally
                {
                    if (File.Exists(tmpFile))
                    {
                        File.Delete(tmpFile);
                    }
                }
            }
        }

        #endregion

        #region GetTfsFileInfo

        private TfsFileInfo GetTfsFileInfo(string path)
        {
            using (TfsTeamProjectCollection server = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(new Uri(this.TeamFoundationServerUrl)))
            {
                TfsFileInfo tfsFileInfo = new TfsFileInfo();
                tfsFileInfo.LocalPath = path;

                VersionControlServer vcs = (VersionControlServer)server.GetService(typeof(VersionControlServer));
                Workspace workspace = vcs.GetWorkspace(path);

                WorkingFolder folder = workspace.GetWorkingFolderForLocalItem(path);

                if (folder != null)
                {
                    ExtendedItem[] itemsArr = vcs.GetExtendedItems(path, DeletedState.NonDeleted, ItemType.File);

                    if (itemsArr != null && itemsArr.Length > 0)
                    {
                        ExtendedItem item1 = itemsArr[0];
                        tfsFileInfo.LatestChangesetId = item1.VersionLatest;
                    }

                    tfsFileInfo.TfsSourceLocation = folder.ServerItem;
                }

                return tfsFileInfo;
            }
        }

        #endregion

        #region TfsFileInfo Structure

        /// <summary>
        /// Contains information about a Tfs file.
        /// </summary>
        private struct TfsFileInfo
        {
            /// <summary>
            /// Gets or sets the local path.
            /// </summary>
            public string LocalPath;

            /// <summary>
            /// Gets or sets the corresponding TFS workspace location.
            /// </summary>
            public string TfsSourceLocation;

            /// <summary>
            /// Gets or sets the latest changeset Id.
            /// </summary>
            public int LatestChangesetId;
        }

        #endregion
    }
}
