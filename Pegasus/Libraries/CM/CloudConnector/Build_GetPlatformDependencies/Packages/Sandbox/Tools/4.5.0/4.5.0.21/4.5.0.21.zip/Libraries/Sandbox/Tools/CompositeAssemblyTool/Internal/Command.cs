using System;
using System.Collections.Generic;
using System.Text;

namespace CompositeAssemblyTool.Internal
{
    [Flags]
    enum Command
    {
        None = 0x00,
        PrintHelp = 0x01,
        Create = 0x02
    }
}
