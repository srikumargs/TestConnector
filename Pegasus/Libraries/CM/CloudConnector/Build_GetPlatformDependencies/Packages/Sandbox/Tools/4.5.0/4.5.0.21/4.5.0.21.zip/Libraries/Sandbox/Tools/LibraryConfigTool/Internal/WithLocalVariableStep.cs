using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Collections.ObjectModel;

namespace LibraryConfigTool.Internal
{
    internal sealed class WithLocalVariableStep : IStep
    {
        public WithLocalVariableStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _variableName = Utils.GetRequiredAttribute(navigator, Constants.NameAttribute, Constants.WithLocalVariableElement, configInfo.ConfigFile);
            _variableValue = Utils.GetOptionalAttribute(navigator, Constants.ValueAttribute);

            using(IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = navigator.SelectChildren(XPathNodeType.Element);
                while(iterator.MoveNext())
                {
                    _childSteps.Add(StepFactory.Create(configInfo, iterator.Current));
                }
            }
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            rootConfigInfo.DefineVariable(_variableName, rootConfigInfo.ReplaceAllVariables(_variableValue));

            foreach(IStep step in _childSteps)
            {
                step.Execute(rootConfigInfo);
            }

            rootConfigInfo.UndefineVariable(_variableName);
        }

        #endregion

        private String _variableName;
        private String _variableValue;
        private readonly List<IStep> _childSteps = new List<IStep>();
    }
}
