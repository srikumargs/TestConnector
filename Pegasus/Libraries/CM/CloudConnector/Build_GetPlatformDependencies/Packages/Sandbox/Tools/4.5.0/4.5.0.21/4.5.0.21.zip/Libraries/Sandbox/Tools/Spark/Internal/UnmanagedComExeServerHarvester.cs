﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;

namespace Spark.Internal
{
    internal sealed class UnmanagedComExeServerHarvester
    {
        /// <summary>
        /// Harvest the registry values written by calling /RegServer on the specified file.
        /// </summary>
        /// <param name="file">The file to harvest registry values from.</param>
        /// <returns>The harvested registry values.</returns>
        public Wix.RegistryValue[] HarvestRegistryValues(String file)
        {
            using (RegistryHarvester registryHarvester = new RegistryHarvester(true))
            {
                Process process;
                using (process = new Process())
                {
                    Environment.SetEnvironmentVariable("SPARK_REG_REMAP_ROOT", registryHarvester.RemappedPath);
 
                    process.StartInfo.FileName = Environment.ExpandEnvironmentVariables(@"%SAGE_SANDBOX%\Tools\Bin\Injector.exe");
                    process.StartInfo.Arguments = "ComRegRemap.dll \"" + file + "\" /RegServer";
                    process.StartInfo.WorkingDirectory = Path.GetDirectoryName(process.StartInfo.FileName);
                    process.StartInfo.CreateNoWindow = true;
                    
                    // Note: must set this to true in order for EXE servers to register properly. This fixed an issue
                    // with E10's MFC EXE server throwing an abort during the harvest process.
                    process.StartInfo.UseShellExecute = true;
                    process.Start();
                    process.WaitForExit();

                    if (0 != process.ExitCode)
                    {
                        throw new Exception(String.Format("'{0} {1}' return {2}", process.StartInfo.FileName, process.StartInfo.Arguments, process.ExitCode));
                    }
                }

                return registryHarvester.HarvestRegistry();
            }
        }
    }
}
