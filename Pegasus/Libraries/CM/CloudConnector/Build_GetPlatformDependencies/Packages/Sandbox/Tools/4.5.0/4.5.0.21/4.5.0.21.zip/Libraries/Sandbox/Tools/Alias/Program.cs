﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Alias.Internal;
using System.Windows.Forms;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Reflection;

namespace Alias
{
    public sealed class Program
    {
        [STAThread]
        private static void Main(String[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
