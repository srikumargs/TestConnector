using System;
using System.Collections.Generic;
using System.Xml.XPath;

namespace LibraryConfigTool.Internal
{
    internal sealed class IfStep : IStep
    {
        public IfStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            String test = Utils.GetRequiredAttribute(navigator, Constants.TestAttribute, Constants.IfElement, configInfo.ConfigFile);

            _booleanExpression = BooleanExpression.Parse(test, configInfo.ConfigFile);

            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = navigator.SelectChildren(XPathNodeType.Element);
                while (iterator.MoveNext())
                {
                    _steps.Add(StepFactory.Create(configInfo, iterator.Current));
                }
            }
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            _rootConfigInfo = rootConfigInfo;

            if (_booleanExpression.Evaluate(rootConfigInfo))
            {
                foreach (IStep step in _steps)
                {
                    step.Execute(rootConfigInfo);
                }
            }
        }

        #endregion

        private readonly List<IStep> _steps = new List<IStep>();
        private ConfigInfo _rootConfigInfo;
        private BooleanExpression _booleanExpression;
    }
}
