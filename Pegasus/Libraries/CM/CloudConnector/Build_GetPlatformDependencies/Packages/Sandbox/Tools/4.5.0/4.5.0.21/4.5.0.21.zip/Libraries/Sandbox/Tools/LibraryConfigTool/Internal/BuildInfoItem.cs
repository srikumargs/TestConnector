using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal class BuildInfoItem
    {
        public BuildInfoItem(TargetGroup targetGroup)
        {
            _targetInfo.AddRange(targetGroup.TargetInfoItems);
        }

        //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
        public static BuildInfoItem Create(ConfigInfo configInfo, XPathNavigator navigator)
        {
            BuildInfoItem result = null;

            if(navigator.Name == Constants.SolutionBuildInfoElement)
            {
                Program.Output.Write(OutputType.Verbose, "Adding 'Solution':");
                result = new SolutionBuildInfoItem(configInfo, navigator);
            }
            else if(navigator.Name == Constants.MakefileBuildInfoElement)
            {
                Program.Output.Write(OutputType.Verbose, "Adding 'Makefile':");
                result = new MakefileBuildInfoItem(configInfo, navigator);
            }
            else
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.UnsupportedElement, navigator.Name);
                throw new LibraryConfigSchemaException(configInfo.ConfigFile, errorMessage);
            }

            return result;
        }

        public BuildInfoItem(String context, ConfigInfo configInfo, XPathNavigator navigator)
        {
            _path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, context, configInfo.ConfigFile);

            using(IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = navigator.SelectChildren(XPathNodeType.Element);
                while(iterator.MoveNext())
                {
                    _targetInfo.Add(new TargetInfo(configInfo, iterator.Current));
                }
            }
        }

        public String Path
        {
            get
            {
                return _path;
            }
        }

        public ReadOnlyCollection<TargetInfo> TargetInfoItems
        {
            get
            {
                return _targetInfo.AsReadOnly();
            }
        }

        private String _path;
        private readonly List<TargetInfo> _targetInfo = new List<TargetInfo>();
    }
}
