﻿using System;
using System.Collections.Specialized;
using System.Collections.ObjectModel;
using System.Xml;
using System.Xml.XPath;
using System.IO;

namespace LibraryConfigTool.Internal
{
    internal sealed class WXSRemoveUnusedDirectoryElementsStep : IStep
    {
        public WXSRemoveUnusedDirectoryElementsStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourceFile = Utils.GetRequiredAttribute(navigator, Constants.SourceFileAttribute, Constants.WXSRemoveUnusedDirectoryElementsElement, configInfo.ConfigFile);
            _destinationFile = Utils.GetRequiredAttribute(navigator, Constants.DestinationFileAttribute, Constants.WXSRemoveUnusedDirectoryElementsElement, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_sourceFile), rootConfigInfo);
            String destinationFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_destinationFile), rootConfigInfo);

            XmlDocument document = new XmlDocument();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(document.NameTable);
            namespaceManager.AddNamespace(String.Empty, "http://schemas.microsoft.com/wix/2006/wi");
            namespaceManager.AddNamespace("ns", "http://schemas.microsoft.com/wix/2006/wi");
            document.Load(sourceFile);

            Boolean somethingRemoved;
            do
            {
                somethingRemoved = false;

                XmlNodeList directoryNodesWithNoChildren = document.SelectNodes("//ns:Directory[count(* | processing-instruction())=0]", namespaceManager);
                if (directoryNodesWithNoChildren.Count > 0)
                {
                    somethingRemoved = true;

                    foreach (XmlNode node in directoryNodesWithNoChildren)
                    {
                        node.ParentNode.RemoveChild(node);
                    }
                }
            } while (somethingRemoved);

            Utils.EnsureDirectoryExists(Path.GetDirectoryName(destinationFile));
            document.Save(destinationFile);
        }

        #endregion

        private String _sourceFile;
        private String _destinationFile;
    }
}
