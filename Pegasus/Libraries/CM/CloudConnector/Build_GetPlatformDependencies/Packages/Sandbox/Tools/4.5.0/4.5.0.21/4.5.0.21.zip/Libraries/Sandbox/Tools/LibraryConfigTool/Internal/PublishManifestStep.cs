using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Threading;

namespace LibraryConfigTool.Internal
{
    internal sealed class PublishManifestStep : IStep
    {
        public PublishManifestStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _librarySet = Utils.GetRequiredAttribute(navigator, Constants.LibrarySetAttribute, Constants.PublishManifestElement, configInfo.ConfigFile);
            _name = Utils.GetRequiredAttribute(navigator, Constants.NameAttribute, Constants.PublishManifestElement, configInfo.ConfigFile);
            _version = Utils.GetRequiredAttribute(navigator, Constants.VersionAttribute, Constants.PublishManifestElement, configInfo.ConfigFile);
            _destinationDir = Utils.GetRequiredAttribute(navigator, Constants.DestinationDirAttribute, Constants.PublishManifestElement, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String librarySet = rootConfigInfo.ReplaceAllVariables(_librarySet);
            String name = rootConfigInfo.ReplaceAllVariables(_name);
            String version = rootConfigInfo.ReplaceAllVariables(_version);
            String targetDir = rootConfigInfo.ReplaceAllVariables(_destinationDir);
            String fileName = Path.Combine(targetDir, Utils.GetLibraryManfiestFileName(librarySet, name));

            Program.Output.Write(OutputType.Info, "Publishing manifest...");
            using(IndentedOutput indentedOutput = new IndentedOutput())
            {
                try
                {
                    Utils.EnsureDirectoryExists(targetDir, "TargetDir");

                    String tempFileName = Path.GetTempFileName();
                    try
                    {
                        XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                        xmlWriterSettings.CloseOutput = true;
                        xmlWriterSettings.ConformanceLevel = ConformanceLevel.Document;
                        xmlWriterSettings.Encoding = Encoding.UTF8;
                        xmlWriterSettings.NewLineHandling = NewLineHandling.Entitize;
                        xmlWriterSettings.OmitXmlDeclaration = false;

                        using(XmlWriter xmlWriter = XmlWriter.Create(tempFileName, xmlWriterSettings))
                        {
                            xmlWriter.WriteStartDocument(true);
                            xmlWriter.WriteWhitespace("\n");
                            xmlWriter.WriteStartElement("ComponentLibrary");
                            xmlWriter.WriteAttributeString("LibrarySet", librarySet);
                            xmlWriter.WriteAttributeString("Name", name);
                            xmlWriter.WriteAttributeString("Version", version);
                            xmlWriter.WriteEndElement();
                            xmlWriter.WriteEndDocument();
                            xmlWriter.Flush();
                            xmlWriter.Close();
                        }

                        Utils.CopyFile(tempFileName, fileName, true);
                    }
                    finally
                    {
                        File.Delete(tempFileName);
                    }
                }
                catch(Exception ex)
                {
                    using(BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, Strings.FailedToPublishManifest);
                        output.AddErrorDetail(Strings.Error, ex.ToString());
                        output.EndWriteError();
                    }
                }
            }
        }

        #endregion

        private String _librarySet;
        private String _name;
        private String _version;
        private String _destinationDir;
    }
}
