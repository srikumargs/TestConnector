using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using Microsoft.Win32;
using System.IO;
using System.Diagnostics;

namespace DevBoxCleaner.Internal
{
    internal sealed class RegistryCleaner : Cleaner
    {
        public RegistryCleaner(String baseLocation)
        {
            _baseLocation = baseLocation.TrimEnd('\\');
        }

        protected override void DoExecute()
        {
            FireAppendResult(ResultCode.Info, "Cleaning registry...");

            _registryBackupFileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), string.Format("DevBoxCleaner-RegistryBackup-{0}.reg", DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss")));
            try
            {
                StringCollection deletedGuids = new StringCollection();

                CleanRegistryKeys(Registry.ClassesRoot, "TypeLib", deletedGuids);
                CleanRegistryKeys(Registry.ClassesRoot, "CLSID", deletedGuids);
                CleanRegistryKeys(Registry.LocalMachine, "SOFTWARE\\Classes\\Record", deletedGuids);
                CleanRegistryKeys(Registry.LocalMachine, "SOFTWARE\\Classes\\Wow6432Node\\Record", deletedGuids);
                CleanRegistryKeys(Registry.LocalMachine, "SOFTWARE\\Wow6432Node\\Classes\\Record", deletedGuids);

                CleanRelatedKeys(Registry.ClassesRoot, String.Empty, deletedGuids);
                CleanRelatedKeys(Registry.LocalMachine, "SOFTWARE\\Classes\\Wow6432Node", deletedGuids);
                CleanRelatedKeys(Registry.LocalMachine, "SOFTWARE\\Classes", deletedGuids);
                CleanRelatedKeys(Registry.LocalMachine, "SOFTWARE\\Wow6432Node\\Classes", deletedGuids);
            }
            finally
            {
                if (_streamWriter != null)
                {
                    _streamWriter.Flush();
                    _streamWriter.Close();
                    _streamWriter.Dispose();
                }

                FireAppendResult(ResultCode.Info, "Finished cleaning registry.  Deleted keys backed up at " + _registryBackupFileName);
            }
        }

        #region Private methods
        private void CleanRegistryKeys(RegistryKey hiveKey, String keyToExport, StringCollection deletedGuids)
        {
            Trace.WriteLine(String.Format("CleanRegistryKeys {0} {1}", hiveKey.Name, keyToExport));

            FireAppendResult(ResultCode.Info, @"Scanning " + hiveKey.Name + "\\" + keyToExport + " registry...");

            String baseLocationAsLower = _baseLocation.ToLower();
            String baseLocationDoubleSlashAsLower = baseLocationAsLower.Replace("\\", "\\\\");
            String tempFileName = Path.GetTempFileName();
            StringCollection deletedKeys = new StringCollection();
            try
            {
                if (!ExportRegistryToFile(hiveKey.Name + "\\" + keyToExport, tempFileName, true))
                {
                    return;
                }

                using (StreamReader streamReader = new StreamReader(tempFileName))
                {
                    StringCollection stringCollection = new StringCollection();
                    do
                    {
                        do
                        {
                            stringCollection.Add(streamReader.ReadLine());
                        } while (stringCollection[stringCollection.Count - 1] != String.Empty);

                        foreach (string s in stringCollection)
                        {
                            try
                            {
                                // TODO: extract this logic out into configuration
                                string asLower = s.ToLower();
                                if (asLower.Contains(@"sage common desktop") ||
                                    asLower.Contains(@"timberline office") ||
                                    asLower.Contains(@"tsoffice") ||
                                    asLower.Contains(@"publickeytoken=3e78b2cabf12f868") ||
                                    asLower.Contains(baseLocationAsLower) ||
                                    asLower.Contains(baseLocationDoubleSlashAsLower))
                                {
                                    string key = stringCollection[0];
                                    if (key.IndexOf('}') - key.IndexOf('{') == 37)
                                    {
                                        string guid = key.Substring(key.IndexOf('{'), key.IndexOf('}') - key.IndexOf('{') + 1);
                                        string keyToDelete = keyToExport + @"\" + guid;

                                        if (!deletedGuids.Contains(guid))
                                        {
                                            deletedGuids.Add(guid);
                                        }

                                        DeleteSubKeyTree(hiveKey, keyToDelete, deletedKeys);

                                        break;
                                    }
                                }
                            }
                            catch (Exception)
                            { }
                        }

                        stringCollection.Clear();
                    }
                    while (!streamReader.EndOfStream);
                }
            }
            finally
            {
                FireAppendResult(ResultCode.Info, @"Deleted " + deletedKeys.Count + @" keys from " + hiveKey.Name + "\\" + keyToExport + " registry.");

                File.Delete(tempFileName);
            }
        }

        private void CleanRelatedKeys(RegistryKey hiveKey, String keyParam, StringCollection guids)
        {
            Trace.WriteLine(String.Format("CleanRelatedKeys {0} {1}", hiveKey.Name, keyParam));

            String keyToClean = hiveKey.Name;
            if (!String.IsNullOrEmpty(keyParam))
            {
                keyToClean += "\\" + keyParam;
            }


            FireAppendResult(ResultCode.Info, @"Scanning " + keyToClean + " registry for related keys...");

            String tempFileName = Path.GetTempFileName();
            StringCollection deletedKeys = new StringCollection();
            try
            {
                if (guids.Count > 0)
                {
                    if (!ExportRegistryToFile(keyToClean, tempFileName, true))
                    {
                        return;
                    }

                    using (StreamReader streamReader = new StreamReader(tempFileName))
                    {
                        StringCollection stringCollection = new StringCollection();
                        do
                        {
                            do
                            {
                                stringCollection.Add(streamReader.ReadLine());
                            } while (stringCollection[stringCollection.Count - 1] != String.Empty);

                            foreach (string s in stringCollection)
                            {
                                foreach (string candidateKey in guids)
                                {
                                    if (s.Contains(candidateKey))
                                    {
                                        string key = stringCollection[0];
                                        string keyToDelete = String.Empty;
                                        if (key.StartsWith(keyToClean + @"\AppID") ||
                                            key.StartsWith(keyToClean + @"\PROTOCOLS\Handler"))
                                        {
                                            keyToDelete = key.Substring(key.IndexOf('\\') + 1);
                                        }
                                        else if (key.StartsWith(keyToClean + @"\CLSID") ||
                                            key.StartsWith(keyToClean + @"\Interface") ||
                                            key.StartsWith(keyToClean + @"\Record") ||
                                            key.StartsWith(keyToClean + @"\TypeLib") ||
                                            key.StartsWith(keyToClean + @"\Wow6432Node"))
                                        {
                                            string prefix = key.Substring(key.IndexOf('\\') + 1);
                                            prefix = prefix.Substring(0, prefix.IndexOf('{') - 1);

                                            string guid = key.Substring(key.IndexOf('{'), key.IndexOf('}') - key.IndexOf('{') + 1);
                                            keyToDelete = prefix + @"\" + guid;
                                        }
                                        else
                                        {
                                            String[] splitKeyToClean = keyToClean.Split('\\');
                                            String[] splitKey = key.Split('\\');
                                            for (Int32 i = 1; i < splitKeyToClean.Length + 1; i++)
                                            {
                                                keyToDelete += splitKey[i] + '\\';
                                            }
                                            keyToDelete = keyToDelete.TrimEnd('\\');
                                        }

                                        DeleteSubKeyTree(hiveKey, keyToDelete, deletedKeys);
                                        break;
                                    }
                                }
                            }

                            stringCollection.Clear();
                        }
                        while (!streamReader.EndOfStream);
                    }
                }
            }
            finally
            {
                FireAppendResult(ResultCode.Info, @"Deleted " + deletedKeys.Count + @" related keys from " + keyToClean + " registry.");

                File.Delete(tempFileName);
            }
        }

        private String AbbreviatedHiveKeyName(String hiveKeyName)
        {
            string result = string.Empty;

            switch (hiveKeyName)
            {
                case "HKEY_LOCAL_MACHINE":
                    result = "HKLM";
                    break;
                case "HKEY_CLASSES_ROOT":
                    result = "HKCR";
                    break;
                case "HKEY_CURRENT_USER":
                    result = "HKCU";
                    break;
                case "HKEY_USERS":
                    result = "HKU";
                    break;
                case "HKEY_CURRENT_CONFIG":
                    result = "HKCC";
                    break;
            }

            return result;
        }
        private Boolean ExportRegistryToFile(String keyToExport, String fileName, Boolean fireEvents)
        {
            Trace.WriteLine(String.Format("ExportRegistryToFile {0} {1}", keyToExport, fileName));

            Boolean result = true;

            Process regeditProcess;
            using (regeditProcess = new Process())
            {
                String[] splitKeyToExport = keyToExport.Split('\\');
                keyToExport = AbbreviatedHiveKeyName(splitKeyToExport[0]) + keyToExport.Substring(splitKeyToExport[0].Length);
                regeditProcess.StartInfo.FileName = Path.Combine(Environment.GetEnvironmentVariable("WINDIR"), "System32\\reg.exe");
                regeditProcess.StartInfo.Arguments = "QUERY \"" + keyToExport + "\" /S";
                if (keyToExport.Contains("Wow6432Node"))
                {
                    regeditProcess.StartInfo.Arguments += " /reg:32";
                }
                regeditProcess.StartInfo.CreateNoWindow = true;
                regeditProcess.StartInfo.UseShellExecute = false;
                regeditProcess.StartInfo.RedirectStandardInput = true;
                regeditProcess.StartInfo.RedirectStandardOutput = true;
                regeditProcess.StartInfo.RedirectStandardError = true;
                regeditProcess.Start();
                String output = regeditProcess.StandardOutput.ReadToEnd();
                File.WriteAllText(fileName, output);
                regeditProcess.WaitForExit();
                if (0 == regeditProcess.ExitCode)
                {
                    if (fireEvents)
                    {
                        FireAppendResult(ResultCode.Success, "reg.exe " + regeditProcess.StartInfo.Arguments, output);
                    }
                }
                else
                {
                    if (fireEvents)
                    {
                        FireAppendResult(ResultCode.Fail, "reg.exe " + regeditProcess.StartInfo.Arguments, output);
                    }
                    result = false;
                }
            }

            Trace.WriteLine(String.Format("ExportRegistryToFile {0} {1} complete", keyToExport, fileName));

            return result;
        }

        private void DeleteSubKeyTree(RegistryKey hiveKey, String keyToDelete, StringCollection deletedKeys)
        {
            Trace.WriteLine(String.Format("DeleteSubKeyTree {0} {1}", hiveKey.Name, keyToDelete));

            if (!deletedKeys.Contains(hiveKey.Name + "\\" + keyToDelete))
            {
                String tempFileName = Path.GetTempFileName();
                try
                {
                    if (ExportRegistryToFile(hiveKey.Name + "\\" + keyToDelete, tempFileName, false))
                    {
                        AppendContentsToRegistryBackup(tempFileName);
                    }

                    if (!TestOnly)
                    {
                        RegistryKey tempRegKey = hiveKey.OpenSubKey(keyToDelete, false);
                        if (tempRegKey != null)
                        {
                            tempRegKey.Close();
                            hiveKey.DeleteSubKeyTree(keyToDelete);
                        }
                        else
                        {
                            FireAppendResult(ResultCode.Info, "DeleteSubKeyTree('" + hiveKey.Name + "\\" + keyToDelete + "') skipped because key no longer exists.");
                        }
                    }
                    deletedKeys.Add(hiveKey.Name + "\\" + keyToDelete);
                    FireAppendResult(ResultCode.Success, "DeleteSubKeyTree('" + hiveKey.Name + "\\" + keyToDelete + "')");
                }
                catch (Exception ex)
                {
                    FireAppendResult(ResultCode.Fail, "DeleteSubKeyTree('" + hiveKey.Name + "\\" + keyToDelete + "')", ex.ToString());
                }
                finally
                {
                    File.Delete(tempFileName);
                }
            }
        }

        private void AppendContentsToRegistryBackup(String fileName)
        {
            Trace.WriteLine(String.Format("AppendContentsToRegistryBackup {0}", fileName));

            if (_streamWriter == null)
            {
                _streamWriter = new StreamWriter(_registryBackupFileName, false);
            }

            using (StreamReader streamReader = new StreamReader(fileName))
            {
                do
                {
                    String line = streamReader.ReadLine();

                    if (line != null)
                    {
                        _streamWriter.WriteLine(line);
                    }
                } while (!streamReader.EndOfStream);
            }

            Trace.WriteLine(String.Format("AppendContentsToRegistryBackup {0} complete", fileName));

        }
        #endregion

        #region Private fields
        private String _baseLocation;
        private String _registryBackupFileName;
        private StreamWriter _streamWriter;
        #endregion
    }
}
