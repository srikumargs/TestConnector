namespace LibraryConfigTool.Internal
{
    internal partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this._overrideComboBox = new System.Windows.Forms.ComboBox();
            this._overrideRadioButton = new System.Windows.Forms.RadioButton();
            this._defaultRadioButton = new System.Windows.Forms.RadioButton();
            this._closeButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this._overrideComboBox);
            this.groupBox1.Controls.Add(this._overrideRadioButton);
            this.groupBox1.Controls.Add(this._defaultRadioButton);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // _overrideComboBox
            // 
            this._overrideComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._overrideComboBox.FormattingEnabled = true;
            this._overrideComboBox.Items.AddRange(new object[] {
            resources.GetString("_overrideComboBox.Items"),
            resources.GetString("_overrideComboBox.Items1"),
            resources.GetString("_overrideComboBox.Items2")});
            resources.ApplyResources(this._overrideComboBox, "_overrideComboBox");
            this._overrideComboBox.Name = "_overrideComboBox";
            // 
            // _overrideRadioButton
            // 
            resources.ApplyResources(this._overrideRadioButton, "_overrideRadioButton");
            this._overrideRadioButton.Name = "_overrideRadioButton";
            this._overrideRadioButton.TabStop = true;
            this._overrideRadioButton.UseVisualStyleBackColor = true;
            this._overrideRadioButton.CheckedChanged += new System.EventHandler(this._overrideRadioButton_CheckedChanged);
            // 
            // _defaultRadioButton
            // 
            resources.ApplyResources(this._defaultRadioButton, "_defaultRadioButton");
            this._defaultRadioButton.Name = "_defaultRadioButton";
            this._defaultRadioButton.TabStop = true;
            this._defaultRadioButton.UseVisualStyleBackColor = true;
            // 
            // _closeButton
            // 
            resources.ApplyResources(this._closeButton, "_closeButton");
            this._closeButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._closeButton.Name = "_closeButton";
            this._closeButton.UseVisualStyleBackColor = true;
            this._closeButton.Click += new System.EventHandler(this._closeButton_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // MainForm
            // 
            this.AcceptButton = this._closeButton;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this._closeButton;
            this.Controls.Add(this.label1);
            this.Controls.Add(this._closeButton);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button _closeButton;
        private System.Windows.Forms.ComboBox _overrideComboBox;
        private System.Windows.Forms.RadioButton _overrideRadioButton;
        private System.Windows.Forms.RadioButton _defaultRadioButton;
        private System.Windows.Forms.Label label1;
    }
}