using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;


namespace LibraryConfigTool.Internal
{
    internal sealed class CopyDirectoryStep : IStep
    {
        public CopyDirectoryStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourceDir = Utils.GetRequiredAttribute(navigator, Constants.SourceDirAttribute, Constants.CopyFilesElement, configInfo.ConfigFile);
            _destinationDir = Utils.GetRequiredAttribute(navigator, Constants.DestinationDirAttribute, Constants.CopyFilesElement, configInfo.ConfigFile);
            _recursive = Utils.GetOptionalAttribute(navigator, Constants.RecursiveAttribute);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceDir = rootConfigInfo.ReplaceAllVariables(_sourceDir);
            String destinationDir = rootConfigInfo.ReplaceAllVariables(_destinationDir);
            String recursiveAsString = rootConfigInfo.ReplaceAllVariables(_recursive);
            Boolean recursive = false;
            if (!String.IsNullOrEmpty(recursiveAsString) && Boolean.Parse(recursiveAsString))
            {
                recursive = true;
            }

            CopyDirectory(new DirectoryInfo(sourceDir), new DirectoryInfo(destinationDir), recursive);
        }

        #endregion

        private static void CopyDirectory(DirectoryInfo sourceDirectoryInfo, DirectoryInfo destinationDirectoryInfo, bool recursive)
        {
            if (!destinationDirectoryInfo.Exists)
            {
                Program.Output.Write(OutputType.Info, "Destination directory does not exist;  creating.");
                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "DestinationDir:   '{0}'", destinationDirectoryInfo.FullName));
                destinationDirectoryInfo.Create();
            }

            // copy files 
            foreach (FileInfo fileInfo in sourceDirectoryInfo.GetFiles())
            {
                Utils.CopyFileToTargetDir(fileInfo.FullName, destinationDirectoryInfo.FullName, false);
            }

            // copy directories 
            if (recursive)
            {
                foreach (DirectoryInfo directoryInfo in sourceDirectoryInfo.GetDirectories())
                {
                    CopyDirectory(directoryInfo, new DirectoryInfo(Path.Combine(destinationDirectoryInfo.FullName, directoryInfo.Name)), recursive);
                }
            }
        }

        private String _sourceDir;
        private String _destinationDir;
        private String _recursive;
    }
}
