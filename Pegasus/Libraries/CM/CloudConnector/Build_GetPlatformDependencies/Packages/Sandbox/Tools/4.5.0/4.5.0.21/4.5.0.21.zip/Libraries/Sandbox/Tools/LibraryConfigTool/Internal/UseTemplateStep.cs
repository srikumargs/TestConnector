using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

using LibraryConfigTool;
using System.Collections.Specialized;

namespace LibraryConfigTool.Internal
{
    //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded; use CallAction instead.")]
    internal sealed class UseTemplateStep : IStep
    {
        public UseTemplateStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, Constants.UseTemplateElement, configInfo.ConfigFile);
            _actionId = Utils.GetOptionalAttribute(navigator, Constants.ActionIdAttribute);

            // Read any associated WithParam elements
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                Program.Output.Write(OutputType.Verbose, "Adding WithParam expressions:");
                XPathNodeIterator paramIterator = navigator.Select(Constants.WithParamElement);
                while (paramIterator.MoveNext())
                {
                    String name = Utils.GetRequiredAttribute(paramIterator.Current, Constants.NameAttribute, Constants.WithParamElement, configInfo.ConfigFile);
                    String value = Utils.GetOptionalAttribute(paramIterator.Current, Constants.ValueAttribute);
                    _withParamVariables.Add(new KeyValuePair<String, String>(name, value));

                    String test = Utils.GetOptionalAttribute(paramIterator.Current, Constants.TestAttribute);
                    if (!String.IsNullOrEmpty(test))
                    {
                        _withParamVariablesBooleanExpressions.Add(name, BooleanExpression.Parse(test, configInfo.ConfigFile));
                    }
                }
            }
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            // Define WithParam variables
            foreach (KeyValuePair<String, String> variable in _withParamVariables)
            {
                Boolean defineVariable = true;
                if(_withParamVariablesBooleanExpressions.ContainsKey(variable.Key))
                {
                    defineVariable  = _withParamVariablesBooleanExpressions[variable.Key].Evaluate(rootConfigInfo);
                }

                if(defineVariable)
                {
                    rootConfigInfo.DefineVariable(variable.Key, rootConfigInfo.ReplaceAllVariables(variable.Value));
                }
            }

            ConfigInfo templateConfigInfo = new ConfigInfo(rootConfigInfo.ReplaceAllVariables(_path), rootConfigInfo.Variables);
            String actionId = rootConfigInfo.ReplaceAllVariables(_actionId);

            switch(Program.CurrentCommand)
            {
                case Command.Action:
                    if (String.IsNullOrEmpty(actionId))
                    {
                        actionId = rootConfigInfo.ActionId;
                    }
                    templateConfigInfo.DoAction(rootConfigInfo, actionId);
                    break;

                default:
                    break;
            }

            // Undefine WithParam variables
            foreach (KeyValuePair<String, String> variable in _withParamVariables)
            {
                Boolean undefineVariable = true;
                if (_withParamVariablesBooleanExpressions.ContainsKey(variable.Key))
                {
                    undefineVariable = _withParamVariablesBooleanExpressions[variable.Key].LastResult;
                }

                if (undefineVariable)
                {
                    rootConfigInfo.UndefineVariable(variable.Key);
                }
            }
        }

        #endregion

        private String _path;
        private String _actionId;
        private List<KeyValuePair<String, String>> _withParamVariables = new List<KeyValuePair<String, String>>();
        private Dictionary<String, BooleanExpression> _withParamVariablesBooleanExpressions = new Dictionary<String, BooleanExpression>();
    }
}
