using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Text.RegularExpressions;

namespace LibraryConfigTool.Internal
{
    internal sealed class RegexReplaceInFileStep : IStep
    {
        public RegexReplaceInFileStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _searchExpression = Utils.GetRequiredAttribute(navigator, Constants.SearchExpressionAttribute, Constants.RegexReplaceInFileElement, configInfo.ConfigFile);
            _replaceExpression = Utils.GetRequiredAttribute(navigator, Constants.ReplaceExpressionAttribute, Constants.RegexReplaceInFileElement, configInfo.ConfigFile);
            _fileSpec = Utils.GetRequiredAttribute(navigator, Constants.FileSpecAttribute, Constants.RegexReplaceInFileElement, configInfo.ConfigFile);
            _multiplePasses = Utils.GetOptionalAttribute(navigator, "MultiplePasses");
            _useDefaultEncoding = Utils.GetOptionalAttribute(navigator, "UseDefaultEncoding");
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String searchExpression = rootConfigInfo.ReplaceAllVariables(_searchExpression);
            String replaceExpression = rootConfigInfo.ReplaceAllVariables(_replaceExpression);
            String fileSpec = rootConfigInfo.ReplaceAllVariables(_fileSpec);
            String multiplePassesAsString = rootConfigInfo.ReplaceAllVariables(_multiplePasses);
            Boolean multiplePasses = false;
            if (!String.IsNullOrEmpty(multiplePassesAsString) && Boolean.Parse(multiplePassesAsString))
            {
                multiplePasses = true;
            }

            String useDefaultEncodingAsString = rootConfigInfo.ReplaceAllVariables(_useDefaultEncoding);
            Boolean useDefaultEncoding = false;
            if (!String.IsNullOrEmpty(useDefaultEncodingAsString) && Boolean.Parse(useDefaultEncodingAsString))
            {
                useDefaultEncoding = true;
            }

            try
            {
                Int32 matchedFiles = 0;
                Int32 failedFiles = 0;
                String[] fileNames = Directory.GetFiles(Path.GetDirectoryName(fileSpec), Path.GetFileName(fileSpec), SearchOption.TopDirectoryOnly);
                foreach(String fileName in fileNames)
                {
                    if(Utils.FileSpecEndsInConcrete3LetterExtension(Path.GetFileName(fileSpec)))
                    {
                        // The file spec looks like something with exactly a 3 character extension.
                        // We must work around the goofy .NET behavior which will match any file that has an
                        // extension that starts with those three character ... but may have more.
                        if(!fileName.ToLower(CultureInfo.InvariantCulture).EndsWith(Path.GetFileName(fileSpec).ToLower(CultureInfo.InvariantCulture)))
                        {
                            // skip the file, it is not a true match
                            continue;
                        }
                    }

                    String originalFileContent;
                    if (useDefaultEncoding)
                    {
                        originalFileContent = File.ReadAllText(fileName, Encoding.Default);
                    }
                    else 
                    {
                        originalFileContent = File.ReadAllText(fileName);
                    }

                    if(Regex.IsMatch(originalFileContent, searchExpression, RegexOptions.None))
                    {
                        matchedFiles++;
                        Console.WriteLine(fileName);
                        String newFileContent = String.Empty;
                        if (!multiplePasses)
                        {
                            newFileContent = Regex.Replace(originalFileContent, searchExpression, replaceExpression, RegexOptions.None);
                        }
                        else
                        {
                            String previousFileContent = null;
                            Boolean firstIteration = true;
                            do
                            {
                                if (firstIteration)
                                {
                                    previousFileContent = originalFileContent;
                                    firstIteration = false;
                                }
                                else
                                {
                                    previousFileContent = newFileContent;
                                }
                                newFileContent = Regex.Replace(previousFileContent, searchExpression, replaceExpression, RegexOptions.None);
                            } while (newFileContent != previousFileContent);
                        }

                        try
                        {
                            if(originalFileContent != newFileContent)
                            {
                                File.SetAttributes(fileName, File.GetAttributes(fileName) & ~FileAttributes.ReadOnly);
                                if (useDefaultEncoding)
                                {
                                    File.WriteAllText(fileName, newFileContent, Encoding.Default);
                                }
                                else
                                {
                                    File.WriteAllText(fileName, newFileContent);
                                }
                            }
                        }
                        catch(Exception ex)
                        {
                            failedFiles++;
                            using(BatchedOutput output = new BatchedOutput(false))
                            {
                                output.BeginWriteError(0, String.Format(CultureInfo.CurrentCulture, "Regular expression file replacement failed;  failed to replace expression in '{0}'.", fileName));
                                output.AddErrorDetail("SearchExpression", searchExpression);
                                output.AddErrorDetail("ReplaceExpression", replaceExpression);
                                output.AddErrorDetail("FileSpec", fileSpec);
                                output.AddErrorDetail(Strings.Error, ex.ToString());
                                output.EndWriteError();
                            }
                        }
                    }
                }

                Program.Output.Write(OutputType.Info, String.Format(CultureInfo.CurrentCulture, "Regular expression file replacement succeeded;  replaced {0} file(s).", matchedFiles));
                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "SearchExpression:   '{0}'", searchExpression));
                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "ReplaceExpression:  '{0}'", replaceExpression));
                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "FileSpec:           '{0}'", fileSpec));

                if(failedFiles > 0)
                {
                    Program.Output.Write(OutputType.Info, String.Format(CultureInfo.CurrentCulture, "Failed to replace expression in {0} file(s).", failedFiles));
                }
            }
            catch(Exception ex)
            {
                using(BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, Strings.RegularExpressionFileReplacementFailed);
                    output.AddErrorDetail("SearchExpression", searchExpression);
                    output.AddErrorDetail("ReplaceExpression", replaceExpression);
                    output.AddErrorDetail("FileSpec", fileSpec);
                    output.AddErrorDetail(Strings.Error, ex.ToString());
                    output.EndWriteError();
                }
            }
        }

        #endregion

        private String _searchExpression;
        private String _replaceExpression;
        private String _fileSpec;
        private String _multiplePasses;
        private String _useDefaultEncoding;
    }
}
