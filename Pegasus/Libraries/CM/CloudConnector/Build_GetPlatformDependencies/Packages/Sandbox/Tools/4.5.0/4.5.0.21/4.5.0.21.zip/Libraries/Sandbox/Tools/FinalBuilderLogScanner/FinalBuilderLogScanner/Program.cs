﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Text;
using System.Xml;

namespace FinalBuilderLogScanner
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args != null && args.Length == 2)
            {
                string inputFilename = args[0];
                string outputFilename = args[1];

                if (File.Exists(inputFilename))
                {
                    Program p = new Program(inputFilename, outputFilename);
                    p.Run();
                }
                else
                {
                    Console.Error.WriteLine("{0} does not exist.", inputFilename);
                    Environment.ExitCode = 1;
                }
            }
            else
            {
                ShowHelp();
            }
        }

        private static void ShowHelp()
        {
            Console.WriteLine("Extracts warnings generated from MSBuild process");
            Console.WriteLine();
            Console.WriteLine("FinalBuilderWarningExtractor inputFile outputFile");
            Console.WriteLine();
        }

        private string _inputFilename;
        private string _outputFilename;
        private HashSet<string> _interestingWarnings;
        private HashSet<string> _interestingErrors;

        public Program(string inputFilename, string outputFilename)
        {
            _inputFilename = inputFilename;
            _outputFilename = outputFilename;
            _interestingWarnings = new HashSet<string>();
            _interestingErrors = new HashSet<string>();

            //load warning and error codes
            string codeList = System.Configuration.ConfigurationManager.AppSettings["warnings"];
            if (!string.IsNullOrEmpty(codeList))
            {
                string[] codeArray = codeList.Split(',');
                foreach (string warningCode in codeArray)
                {
                    _interestingWarnings.Add(warningCode.ToUpper());
                }
            }

            codeList = System.Configuration.ConfigurationManager.AppSettings["errors"];
            if (!string.IsNullOrEmpty(codeList))
            {
                string[] codeArray = codeList.Split(',');
                foreach (string errorCode in codeArray)
                {
                    _interestingErrors.Add(errorCode.ToUpper());
                }
            }
        }

        public void Run()
        {

            //prep output file
            XmlDocument warningDoc = new XmlDocument();
            XmlElement warningDocumentElement = warningDoc.CreateElement("msbuild");
            warningDoc.AppendChild(warningDocumentElement);


            //outer pass: identify "MS Build" action nodes
            XmlDocument document = new XmlDocument();
            document.Load(_inputFilename);

            XmlElement documentElement = document.DocumentElement;

            XmlNodeList actionNodes = documentElement.GetElementsByTagName("action");
            if (actionNodes != null)
            {
                foreach (XmlNode actionNode in actionNodes)
                {
                    XmlElement actionElement = actionNode as XmlElement;
                    if (actionElement != null)
                    {
                        if (actionElement.HasAttribute("actionname") && string.Compare(actionElement.GetAttribute("actionname"), "MSBuild Project", true) == 0)
                        {

                            XmlElement warningProjectElement = warningDoc.CreateElement("project");
                            if (actionElement.HasAttribute("name"))
                            {
                                warningProjectElement.SetAttribute("name", actionElement.GetAttribute("name"));
                            }
                            warningDocumentElement.AppendChild(warningProjectElement);

                            XmlElement messageElement = actionElement["message"];
                            if (messageElement != null)
                            {
                                string message = messageElement.InnerText;
                                ParseMSBuildOutput(message, warningProjectElement);
                            }
                        }
                    }
                }
            }

            warningDoc.Save(_outputFilename);
        }

        private void ParseMSBuildOutput(string message, XmlElement parentElement)
        {
            using (StringReader reader = new StringReader(message))
            {
                string line = null;
                while ((line = reader.ReadLine()) != null)
                {

                    bool processLine = false;
                    int endOfErrorCode = -1;
                    string errorCode = null;
                    string lineType = null;

                    //WARNING CS0672 in MaintainAccountingPeriodsForm.cs(79,27) : Member 'Sage.MMS.SystemManager.MaintainAccountingPeriodsForm.HelpHandler(string, string, bool)' overrides obsolete member 'Sage.MMS.BaseForm.HelpHandler(string, string, bool)'. Add the Obsolete attribute to 'Sage.MMS.SystemManager.MaintainAccountingPeriodsForm.HelpHandler(string, string, bool)'.
                    if (line.StartsWith("WARNING"))
                    {
                        endOfErrorCode = line.IndexOf(' ', 8);
                        if (endOfErrorCode > 0)
                        {
                            errorCode = line.Substring(8, endOfErrorCode - 8).ToUpper();
                            if (_interestingWarnings.Contains(errorCode) || _interestingWarnings.Contains("*"))
                            {
                                processLine=true;
                                lineType = "warning";
                            }
                        }
                    }
                    //ERROR CS1061 in PurchaseLedger\PurchaseLedger_WarningMessageSetting.cs(188,49) : 'Sage.Accounting.PersistentPLSetting_WarningMessageSetting' does not contain a definition for 'NotToExceedAmount' and no extension method 'NotToExceedAmount' accepting a first argument of type 'Sage.Accounting.PersistentPLSetting_WarningMessageSetting' could be found (are you missing a using directive or an assembly reference?)
                    else if (line.StartsWith("ERROR"))
                    {
                        endOfErrorCode = line.IndexOf(' ', 7);
                        if (endOfErrorCode > 0)
                        {
                            errorCode = line.Substring(7, endOfErrorCode - 7).ToUpper();
                            if (_interestingErrors.Contains(errorCode) || _interestingErrors.Contains("*"))
                            {
                                processLine = true;
                                lineType = "error";
                            }
                        }
                    }

                    if (processLine)
                    {
                        string filename = "Unknown";
                        int endOfFilename = line.IndexOf('(', endOfErrorCode);
                        if (endOfFilename > 0)
                        {
                            filename = line.Substring(endOfErrorCode + 4, endOfFilename - (endOfErrorCode + 4));
                        }

                        XmlElement lineElement = parentElement.OwnerDocument.CreateElement(lineType);
                        parentElement.AppendChild(lineElement);
                        lineElement.SetAttribute("code", errorCode);
                        lineElement.SetAttribute("file", filename);
                        XmlCDataSection warningText = parentElement.OwnerDocument.CreateCDataSection(line);
                        lineElement.AppendChild(warningText);
                    }
                }
            }
        }
    }
}
