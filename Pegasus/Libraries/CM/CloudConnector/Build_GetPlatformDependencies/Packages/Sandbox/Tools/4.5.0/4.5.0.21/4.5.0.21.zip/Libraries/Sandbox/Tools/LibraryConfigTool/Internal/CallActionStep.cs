﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

using LibraryConfigTool;
using System.Collections.Specialized;

namespace LibraryConfigTool.Internal
{
    internal sealed class CallActionStep : IStep
    {
        public CallActionStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _actionId = Utils.GetRequiredAttribute(navigator, Constants.ActionIdAttribute, Constants.CallActionElement, configInfo.ConfigFile);
            _path = Utils.GetOptionalAttribute(navigator, Constants.PathAttribute);

            // Read any associated WithParam elements
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                Program.Output.Write(OutputType.Verbose, "Adding WithParam expressions:");
                XPathNodeIterator paramIterator = navigator.Select(Constants.WithParamElement);
                while (paramIterator.MoveNext())
                {
                    String name = Utils.GetRequiredAttribute(paramIterator.Current, Constants.NameAttribute, Constants.WithParamElement, configInfo.ConfigFile);
                    String value = Utils.GetOptionalAttribute(paramIterator.Current, Constants.ValueAttribute);
                    _withParamVariables.Add(new KeyValuePair<String, String>(name, value));

                    String test = Utils.GetOptionalAttribute(paramIterator.Current, Constants.TestAttribute);
                    if (!String.IsNullOrEmpty(test))
                    {
                        _withParamVariablesBooleanExpressions.Add(name, BooleanExpression.Parse(test, configInfo.ConfigFile));
                    }
                }
            }
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String actionId = rootConfigInfo.ReplaceAllVariables(_actionId);
            String path = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_path), rootConfigInfo);

            // Define WithParam variables
            foreach (KeyValuePair<String, String> variable in _withParamVariables)
            {
                Boolean defineVariable = true;
                if (_withParamVariablesBooleanExpressions.ContainsKey(variable.Key))
                {
                    defineVariable = _withParamVariablesBooleanExpressions[variable.Key].Evaluate(rootConfigInfo);
                }

                if (defineVariable)
                {
                    rootConfigInfo.DefineVariable(variable.Key, rootConfigInfo.ReplaceAllVariables(variable.Value));
                }
            }


            if (!String.IsNullOrEmpty(path))
            {
                ConfigInfo templateConfigInfo = new ConfigInfo(path, rootConfigInfo.Variables);
                templateConfigInfo.DoAction(rootConfigInfo, actionId);
            }
            else
            {
                rootConfigInfo.DoAction(rootConfigInfo, actionId);
            }


            // Undefine WithParam variables
            foreach (KeyValuePair<String, String> variable in _withParamVariables)
            {
                Boolean undefineVariable = true;
                if (_withParamVariablesBooleanExpressions.ContainsKey(variable.Key))
                {
                    undefineVariable = _withParamVariablesBooleanExpressions[variable.Key].LastResult;
                }

                if (undefineVariable)
                {
                    rootConfigInfo.UndefineVariable(variable.Key);
                }
            }
        }

        #endregion

        private String _path;
        private String _actionId;
        private List<KeyValuePair<String, String>> _withParamVariables = new List<KeyValuePair<String, String>>();
        private Dictionary<String, BooleanExpression> _withParamVariablesBooleanExpressions = new Dictionary<String, BooleanExpression>();
    }
}
