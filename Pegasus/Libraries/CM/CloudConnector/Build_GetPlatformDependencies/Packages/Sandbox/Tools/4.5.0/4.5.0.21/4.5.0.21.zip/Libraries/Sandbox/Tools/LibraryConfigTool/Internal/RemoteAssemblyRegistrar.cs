using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Permissions;
using System.Runtime.Remoting.Messaging;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1812:AvoidUninstantiatedInternalClasses", Justification="This class is called in a late-bound manner through a subordinate AppDomain.")]
    internal sealed class RemoteAssemblyRegistrar : MarshalByRefObject
    {
        public override object InitializeLifetimeService()
        {
            return null; // prevent leased-based lifetime management
        }

        public void RegisterAssembly(IMessageSink outputMessageSink, String path, String typeLibPath)
        {
            _outputMessageSink = outputMessageSink;

            IntializeLibraryManager(path);

            Assembly assembly = Assembly.LoadFrom(path);

            DoRegisterAssembly(assembly);

            DoExportTypeLibrary(assembly, typeLibPath);
        }

        public void ExportTypeLibrary(IMessageSink outputMessageSink, String path, String typeLibPath)
        {
            _outputMessageSink = outputMessageSink;

            IntializeLibraryManager(path);

            Assembly assembly = Assembly.LoadFrom(path);

            DoExportTypeLibrary(assembly, typeLibPath);
        }

        private static void IntializeLibraryManager(String path)
        {
            //Assembly libraryManagementAssembly = Assembly.LoadFrom(Path.Combine(Utils.SandboxLocation, Constants.AssembliesSageLS1LibraryManagementDll));
            //if (libraryManagementAssembly != null)
            //{
            //    Type libraryManagerType = libraryManagementAssembly.GetType(Constants.SageConfigurationLibraryManager);
            //    String libraryManifestLocation = (String)libraryManagerType.InvokeMember(Constants.LibraryManifestLocationForBinary, BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static, null, null, new Object[] { path }, CultureInfo.InvariantCulture);
            //    libraryManagerType.InvokeMember(Constants.InitializeLibraries, BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static, null, null, new Object[] { libraryManifestLocation }, CultureInfo.InvariantCulture);
            //}
        }

        private void DoRegisterAssembly(Assembly assembly)
        {
            RegistryPermission registryPermission = new RegistryPermission(PermissionState.Unrestricted);
            registryPermission.Demand();
            registryPermission.Assert();

            if(new RegistrationServices().RegisterAssembly(assembly, AssemblyRegistrationFlags.SetCodeBase))
            {
                Output(OutputType.Info, Strings.RegisterAssemblyReturnedTrueTypesSuccessfullyRegistered);
            }
            else
            {
                Output(OutputType.Info, Strings.RegisterAssemblyReturnedFalseNoEligibleTypesFoundToRegister);
            }
        }

        private void DoExportTypeLibrary(Assembly assembly, String typeLibPath)
        {
            // Wrap TypeLibExporterNotifySink in a using block so that Dispose gets called. This appears to be needed because
            // TypeLibExporterNotifySink calls the LoadTypeLib p/invoke method ... which appears to potentially hold
            // a file reference to the tlb file.
            using (TypeLibExporterNotifySink typeLibExporterNotifySink = new TypeLibExporterNotifySink(assembly.FullName, _outputMessageSink))
            {
                ITypeLibConverter typeLibConverter = new TypeLibConverter();
                ITypeLib typeLib = (ITypeLib)typeLibConverter.ConvertAssemblyToTypeLib(assembly, typeLibPath, TypeLibExporterFlags.OnlyReferenceRegistered, typeLibExporterNotifySink);
                if (typeLib != null)
                {
                    Output(OutputType.Info, Strings.ConvertAssemblyToTypeLibCompletedSuccessfully);

                    ((UCOMICreateITypeLib)typeLib).SaveAllChanges();

                    if (Utils.NativeMethods.RegisterTypeLib(typeLib, typeLibPath, null) != 0)
                    {
                        throw new Exception(Strings.RegisterTypeLibFailed);
                    }
                    else
                    {
                        Output(OutputType.Info, Strings.RegisterTypeLibSucceeded);
                    }
                }
                else
                {
                    throw new Exception(Strings.ConvertAssemblyToTypeLibFailed);
                }
            }
        }

        private void Output(OutputType outputType, String message)
        {
            Output(outputType, IndentAction.None, message);
        }

        private void Output(OutputType outputType, IndentAction indentAction, String message)
        {
            _outputMessageSink.SyncProcessMessage(new OutputMessage(outputType, indentAction, message));
        }

        private IMessageSink _outputMessageSink;
    }
}
