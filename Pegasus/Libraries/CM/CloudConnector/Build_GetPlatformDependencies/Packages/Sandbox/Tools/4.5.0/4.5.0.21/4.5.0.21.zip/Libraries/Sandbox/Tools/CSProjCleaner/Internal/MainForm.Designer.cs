﻿namespace CSProjCleaner.Internal
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this._closeButton = new System.Windows.Forms.Button();
            this._rootFolderTextBox = new System.Windows.Forms.TextBox();
            this._rootFolderBrowseButton = new System.Windows.Forms.Button();
            this._fileTextBox = new System.Windows.Forms.TextBox();
            this._recursiveCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this._fileRadioButton = new System.Windows.Forms.RadioButton();
            this._rootFolderRadioButton = new System.Windows.Forms.RadioButton();
            this._fileBrowseButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.optionsControl1 = new CSProjCleaner.Internal.OptionsControl();
            this.label4 = new System.Windows.Forms.Label();
            this._cleanButton = new System.Windows.Forms.Button();
            this._imageList = new System.Windows.Forms.ImageList(this.components);
            this._toolTip = new System.Windows.Forms.ToolTip(this.components);
            this._splitContainer = new System.Windows.Forms.SplitContainer();
            this._resultsDataGridView = new System.Windows.Forms.DataGridView();
            this._imageColumne = new System.Windows.Forms.DataGridViewImageColumn();
            this._descriptionColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ErrorData = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this._splitContainer.Panel1.SuspendLayout();
            this._splitContainer.Panel2.SuspendLayout();
            this._splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._resultsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // _closeButton
            // 
            resources.ApplyResources(this._closeButton, "_closeButton");
            this._closeButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._closeButton.Name = "_closeButton";
            this._closeButton.UseVisualStyleBackColor = true;
            this._closeButton.Click += new System.EventHandler(this._closeButton_Click);
            // 
            // _rootFolderTextBox
            // 
            resources.ApplyResources(this._rootFolderTextBox, "_rootFolderTextBox");
            this._rootFolderTextBox.Name = "_rootFolderTextBox";
            // 
            // _rootFolderBrowseButton
            // 
            resources.ApplyResources(this._rootFolderBrowseButton, "_rootFolderBrowseButton");
            this._rootFolderBrowseButton.Name = "_rootFolderBrowseButton";
            this._rootFolderBrowseButton.UseVisualStyleBackColor = true;
            this._rootFolderBrowseButton.Click += new System.EventHandler(this._rootFolderBrowseButton_Click);
            // 
            // _fileTextBox
            // 
            resources.ApplyResources(this._fileTextBox, "_fileTextBox");
            this._fileTextBox.Name = "_fileTextBox";
            // 
            // _recursiveCheckBox
            // 
            resources.ApplyResources(this._recursiveCheckBox, "_recursiveCheckBox");
            this._recursiveCheckBox.Name = "_recursiveCheckBox";
            this._recursiveCheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this._fileBrowseButton);
            this.groupBox1.Controls.Add(this._recursiveCheckBox);
            this.groupBox1.Controls.Add(this._rootFolderTextBox);
            this.groupBox1.Controls.Add(this._fileTextBox);
            this.groupBox1.Controls.Add(this._rootFolderBrowseButton);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this._fileRadioButton);
            this.panel1.Controls.Add(this._rootFolderRadioButton);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // _fileRadioButton
            // 
            resources.ApplyResources(this._fileRadioButton, "_fileRadioButton");
            this._fileRadioButton.Name = "_fileRadioButton";
            this._fileRadioButton.UseVisualStyleBackColor = true;
            this._fileRadioButton.CheckedChanged += new System.EventHandler(this._fileRadioButton_CheckedChanged);
            // 
            // _rootFolderRadioButton
            // 
            resources.ApplyResources(this._rootFolderRadioButton, "_rootFolderRadioButton");
            this._rootFolderRadioButton.Checked = true;
            this._rootFolderRadioButton.Name = "_rootFolderRadioButton";
            this._rootFolderRadioButton.TabStop = true;
            this._rootFolderRadioButton.UseVisualStyleBackColor = true;
            this._rootFolderRadioButton.CheckedChanged += new System.EventHandler(this._rootFolderRadioButton_CheckedChanged);
            // 
            // _fileBrowseButton
            // 
            resources.ApplyResources(this._fileBrowseButton, "_fileBrowseButton");
            this._fileBrowseButton.Name = "_fileBrowseButton";
            this._fileBrowseButton.UseVisualStyleBackColor = true;
            this._fileBrowseButton.Click += new System.EventHandler(this._fileBrowseButton_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.optionsControl1);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // optionsControl1
            // 
            resources.ApplyResources(this.optionsControl1, "optionsControl1");
            this.optionsControl1.Name = "optionsControl1";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // _cleanButton
            // 
            resources.ApplyResources(this._cleanButton, "_cleanButton");
            this._cleanButton.Name = "_cleanButton";
            this._toolTip.SetToolTip(this._cleanButton, resources.GetString("_cleanButton.ToolTip"));
            this._cleanButton.UseVisualStyleBackColor = true;
            this._cleanButton.Click += new System.EventHandler(this._cleanButton_Click);
            // 
            // _imageList
            // 
            this._imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("_imageList.ImageStream")));
            this._imageList.TransparentColor = System.Drawing.Color.Magenta;
            this._imageList.Images.SetKeyName(0, "Blank.bmp");
            this._imageList.Images.SetKeyName(1, "Critical.bmp");
            this._imageList.Images.SetKeyName(2, "OK.bmp");
            this._imageList.Images.SetKeyName(3, "Information.bmp");
            this._imageList.Images.SetKeyName(4, "CSProjFile.bmp");
            this._imageList.Images.SetKeyName(5, "Edit.bmp");
            // 
            // _splitContainer
            // 
            resources.ApplyResources(this._splitContainer, "_splitContainer");
            this._splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this._splitContainer.Name = "_splitContainer";
            // 
            // _splitContainer.Panel1
            // 
            this._splitContainer.Panel1.Controls.Add(this.groupBox2);
            // 
            // _splitContainer.Panel2
            // 
            this._splitContainer.Panel2.Controls.Add(this._resultsDataGridView);
            this._splitContainer.Panel2.Controls.Add(this.label4);
            // 
            // _resultsDataGridView
            // 
            this._resultsDataGridView.AllowUserToAddRows = false;
            this._resultsDataGridView.AllowUserToDeleteRows = false;
            this._resultsDataGridView.AllowUserToResizeColumns = false;
            this._resultsDataGridView.AllowUserToResizeRows = false;
            this._resultsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._resultsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this._imageColumne,
            this._descriptionColumn,
            this.Column1,
            this.ErrorData});
            resources.ApplyResources(this._resultsDataGridView, "_resultsDataGridView");
            this._resultsDataGridView.Name = "_resultsDataGridView";
            this._resultsDataGridView.RowHeadersVisible = false;
            this._resultsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // _imageColumne
            // 
            this._imageColumne.Frozen = true;
            resources.ApplyResources(this._imageColumne, "_imageColumne");
            this._imageColumne.Name = "_imageColumne";
            // 
            // _descriptionColumn
            // 
            this._descriptionColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._descriptionColumn.DefaultCellStyle = dataGridViewCellStyle1;
            resources.ApplyResources(this._descriptionColumn, "_descriptionColumn");
            this._descriptionColumn.Name = "_descriptionColumn";
            // 
            // Column1
            // 
            resources.ApplyResources(this.Column1, "Column1");
            this.Column1.Name = "Column1";
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column1.Text = "Click";
            this.Column1.UseColumnTextForButtonValue = true;
            // 
            // ErrorData
            // 
            resources.ApplyResources(this.ErrorData, "ErrorData");
            this.ErrorData.Name = "ErrorData";
            // 
            // MainForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._splitContainer);
            this.Controls.Add(this._cleanButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this._closeButton);
            this.Controls.Add(this.label1);
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this._splitContainer.Panel1.ResumeLayout(false);
            this._splitContainer.Panel2.ResumeLayout(false);
            this._splitContainer.Panel2.PerformLayout();
            this._splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._resultsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button _closeButton;
        private System.Windows.Forms.TextBox _rootFolderTextBox;
        private System.Windows.Forms.Button _rootFolderBrowseButton;
        private System.Windows.Forms.TextBox _fileTextBox;
        private System.Windows.Forms.CheckBox _recursiveCheckBox;
        private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private OptionsControl optionsControl1;
        private System.Windows.Forms.Button _cleanButton;
        private System.Windows.Forms.Button _fileBrowseButton;
        private System.Windows.Forms.RadioButton _rootFolderRadioButton;
        private System.Windows.Forms.RadioButton _fileRadioButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ImageList _imageList;
        private System.Windows.Forms.ToolTip _toolTip;
		private System.Windows.Forms.SplitContainer _splitContainer;
		private System.Windows.Forms.DataGridView _resultsDataGridView;
		private System.Windows.Forms.DataGridViewImageColumn _imageColumne;
		private System.Windows.Forms.DataGridViewTextBoxColumn _descriptionColumn;
		private System.Windows.Forms.DataGridViewButtonColumn Column1;
		private System.Windows.Forms.DataGridViewTextBoxColumn ErrorData;
    }
}