using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
    internal sealed class LibraryReference
    {
        public LibraryReference(ConfigInfo configInfo, XPathNavigator navigator)
        {
            Program.Output.Write(OutputType.Verbose, "Adding library reference:");
            _librarySetId = Utils.GetRequiredAttribute(navigator, Constants.LibrarySetAttribute, Constants.LibraryReferencesExpression, configInfo.ConfigFile);
            _libraryName = Utils.GetRequiredAttribute(navigator, Constants.NameAttribute, Constants.LibraryReferencesExpression, configInfo.ConfigFile);
            _libraryVersion = Utils.GetRequiredAttribute(navigator, Constants.VersionAttribute, Constants.LibraryReferencesExpression, configInfo.ConfigFile);
        }

        public String LibrarySetId
        {
            get
            {
                return _librarySetId;
            }
        }

        public String LibraryName
        {
            get
            {
                return _libraryName;
            }
        }

        public String LibraryVersion
        {
            get
            {
                return _libraryVersion;
            }
        }

        private String _librarySetId;
        private String _libraryName;
        private String _libraryVersion;
    }
}
