﻿namespace CSProjCleaner.Internal
{
    internal enum ExitCode
    {
        OneOrMoreProjectsUpdatedSuccessfully = 0,
        NoChangesNecessary = 1,
        UnexpectedErrorsOccurred = 2
    }
}
