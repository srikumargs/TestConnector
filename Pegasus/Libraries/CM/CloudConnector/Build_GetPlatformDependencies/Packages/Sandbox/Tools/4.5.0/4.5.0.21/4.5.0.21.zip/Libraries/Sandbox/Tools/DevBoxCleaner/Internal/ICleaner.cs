using System;
using System.Collections.Generic;
using System.Text;

namespace DevBoxCleaner.Internal
{
    interface ICleaner
    {
        void Execute(IPromptUser promptUser, Boolean testOnly);

        event EventHandler<ResultEventArgs> AppendResult;
    }
}
