using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Text;
using System.Globalization;

namespace LibraryConfigTool.Internal
{

    /// <summary>
    /// Exception thrown when a schema error is found with library config file
    /// </summary>
    [Serializable]
    [SuppressMessage("Microsoft.Design", "CA1032:ImplementStandardExceptionConstructors", Justification = "The thrower should alwys include the relevent exception information and therefore the default standard constructors should never be used")]
    internal sealed class LibraryConfigSchemaException : Exception
    {
        #region Construction

        /// <summary>
        /// Construct an instance of the LibraryConfigSchemaException class
        /// </summary>
        /// <param name="configFile">The name of the config file that has the schema error</param>
        /// <param name="errorMessage">Error Message</param>
        public LibraryConfigSchemaException(String configFile, String errorMessage)
            : base(errorMessage)
        {
            Debug.Assert(!String.IsNullOrEmpty(configFile));
            Debug.Assert(!String.IsNullOrEmpty(errorMessage));

            _configFile = configFile;
        }

        /// <summary>
        /// Construct an instance of the LibraryConfigSchemaException class
        /// </summary>
        /// <param name="configFile">The name of the config file that has the schema error</param>
        /// <param name="errorMessage">ErrorMessage</param>
        /// <param name="innerException">An inner exception</param>
        public LibraryConfigSchemaException(String configFile, String errorMessage, Exception innerException)
            : base(errorMessage, innerException)
        {
            Debug.Assert(!String.IsNullOrEmpty(configFile));
            Debug.Assert(!String.IsNullOrEmpty(errorMessage));
            Debug.Assert(innerException != null);

            _configFile = configFile;
        }

        /// <summary>
        /// Serialization Constructor
        /// </summary>
        /// <param name="si">Serialization Info</param>
        /// <param name="sc">Streaming Context</param>
        private LibraryConfigSchemaException(SerializationInfo si, StreamingContext sc)
            : base(si, sc)
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Returns the name of the config file that has the schema error
        /// </summary>
        public String ConfigFile
        {
            get
            {
                return _configFile;
            }
        }

        #endregion

        #region Overrides

        /// <summary>
        /// Serialize the private fields
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            if(info != null)
            {
                info.AddValue(Constants.LibraryConfigFileField, _configFile);
            }
        }

        public override String ToString()
        {
            String message = String.Format(CultureInfo.CurrentCulture, "LibraryConfigSchemaException encountered in '{0}'.  {1}", _configFile, Message);
            if(InnerException != null)
            {
                message += String.Format(CultureInfo.CurrentCulture, "\n[BEGIN Inner Exception]\n{0}\n[END Inner Exception]", InnerException.ToString());
            }
            if(StackTrace != null)
            {

                message += "\n" + StackTrace.ToString();
            }

            return message;
        }

        #endregion

        #region Private fields

        // The name of the config file with the schema problem
        private readonly String _configFile; //= null; (automatically initialized by runtime)

        #endregion
    }
}
