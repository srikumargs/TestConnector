using System;
using System.Diagnostics;
using System.Drawing;

namespace CompositeAssemblyTool.Internal
{
    /// <summary>
    /// The Library class allows you to load unmanaged libraries, such as 
    /// executables and dynamic-link libraries.
    /// </summary>
    internal sealed class Library : IDisposable
    {
        #region Construction/destruction

        /// <summary>
        /// Maps the specified module into the address space of the calling 
        /// process. The module will be freed when the Library object is 
        /// disposed.
        /// </summary>
        public Library(String fileName, UInt32 flags)
        {
            _own = true;

            _handle = NativeMethods.LoadLibraryEx(fileName, IntPtr.Zero, flags);
            if (IntPtr.Zero == _handle)
            {
                NativeMethods.ThrowLastWin32Error();
            }
        }

        /// <summary>
        /// Creates a Library object attached to the given module. If 
        /// bTakeOwnership is true the module will be freed when the Library 
        /// object is disposed.
        /// </summary>
        public Library(IntPtr module, Boolean takeOwnership)
        {
            Debug.Assert(IntPtr.Zero != module);

            _handle = module;
            _own = takeOwnership;
        }

        /// <summary>
        /// Frees the underlying module.
        /// </summary>
        ~Library()
        {
            Free();
        }

        /// <summary>
        /// Frees the underlying module.
        /// </summary>
        public void Dispose()
        {
            Free();
            GC.SuppressFinalize(this);
        }

        #endregion

        #region Public properties
        /// <summary>
        /// Gets a handle to the underlying module.
        /// </summary>
        public IntPtr Handle
        {
            get
            {
                return _handle;
            }
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Decrements the reference count of the loaded module if the Library 
        /// object owns it.
        /// </summary>
        public void Free()
        {
            if (_own && IntPtr.Zero != _handle)
            {
                NativeMethods.FreeLibrary(_handle);
                _handle = IntPtr.Zero;
            }
        }

        /// <summary>
        /// Searches the library for each resource of the specified type and 
        /// passes either the name or the ID of each resource it locates to the
        /// delegate.
        /// </summary>
        public int EnumResourceNames(IntPtr type, NativeMethods.EnumResNameProc enumResNameProc, IntPtr param)
        {
            Debug.Assert(IntPtr.Zero != _handle);

            return NativeMethods.EnumResourceNames(_handle, type, enumResNameProc, param);
        }

        /// <summary>
        /// Determines the location of a resource with the specified type and 
        /// name.
        /// </summary>
        public IntPtr FindResource(IntPtr name, IntPtr type)
        {
            Debug.Assert(IntPtr.Zero != _handle);

            IntPtr resource = NativeMethods.FindResource(_handle, name, type);
            if (IntPtr.Zero == resource)
            {
                NativeMethods.ThrowLastWin32Error();
            }

            return resource;
        }

        /// <summary>
        /// Loads the specified resource into memory.
        /// </summary>
        public IntPtr LoadResource(IntPtr resource)
        {
            Debug.Assert(IntPtr.Zero != _handle);

            IntPtr global = NativeMethods.LoadResource(_handle, resource);
            if (IntPtr.Zero == global)
            {
                NativeMethods.ThrowLastWin32Error();
            }

            return global;
        }

        /// <summary>
        /// Gets the size, in bytes, of the specified resource.
        /// </summary>
        public UInt32 SizeofResource(IntPtr resource)
        {
            Debug.Assert(IntPtr.Zero != _handle);

            UInt32 byteCount = NativeMethods.SizeofResource(_handle, resource);
            if (0 == byteCount)
            {
                NativeMethods.ThrowLastWin32Error();
            }

            return byteCount;
        }

        /// <summary>
        /// Locks the specified resource in memory.
        /// </summary>
        public static IntPtr LockResource(IntPtr global)
        {
            IntPtr resource = NativeMethods.LockResource(global);
            if (IntPtr.Zero == resource)
            {
                NativeMethods.ThrowLastWin32Error();
            }

            return resource;
        }

        /// <summary>
        /// Loads the specified icon resource from the library.
        /// </summary>
        public Icon LoadIcon(IntPtr name)
        {
            IntPtr icon = NativeMethods.LoadIcon(_handle, name);
            if (IntPtr.Zero == icon)
            {
                NativeMethods.ThrowLastWin32Error();
            }

            return Icon.FromHandle(icon);
        }
        #endregion

        #region Private fields
        private IntPtr _handle;
        private Boolean _own;
        #endregion
    }
}
