namespace DevBoxCleaner.Internal
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this._cleanRegistryCheckBox = new System.Windows.Forms.CheckBox();
            this._cleanGacCheckBox = new System.Windows.Forms.CheckBox();
            this._cleanSandboxCheckBox = new System.Windows.Forms.CheckBox();
            this._sandboxLocationTextBox = new System.Windows.Forms.TextBox();
            this._cleanButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this._closeButton = new System.Windows.Forms.Button();
            this._resultsDataGridView = new System.Windows.Forms.DataGridView();
            this._imageColumne = new System.Windows.Forms.DataGridViewImageColumn();
            this._descriptionColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ErrorData = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._imageList = new System.Windows.Forms.ImageList(this.components);
            this._testOnlyCheckBox = new System.Windows.Forms.CheckBox();
            this._toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this._resultsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // _cleanRegistryCheckBox
            // 
            this._cleanRegistryCheckBox.AutoSize = true;
            this._cleanRegistryCheckBox.Checked = true;
            this._cleanRegistryCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this._cleanRegistryCheckBox.Location = new System.Drawing.Point(6, 65);
            this._cleanRegistryCheckBox.Name = "_cleanRegistryCheckBox";
            this._cleanRegistryCheckBox.Size = new System.Drawing.Size(64, 17);
            this._cleanRegistryCheckBox.TabIndex = 1;
            this._cleanRegistryCheckBox.Text = "Registry";
            this._toolTip.SetToolTip(this._cleanRegistryCheckBox, "Removes all HKCR\\CLSID and HKCR\\TypeLib registry keys which have any values which" +
                    " mention either \"tsoffice\", the specified sandbox location, or have the Timberli" +
                    "ne public key token.");
            this._cleanRegistryCheckBox.UseVisualStyleBackColor = true;
            // 
            // _cleanGacCheckBox
            // 
            this._cleanGacCheckBox.AutoSize = true;
            this._cleanGacCheckBox.Checked = true;
            this._cleanGacCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this._cleanGacCheckBox.Location = new System.Drawing.Point(6, 42);
            this._cleanGacCheckBox.Name = "_cleanGacCheckBox";
            this._cleanGacCheckBox.Size = new System.Drawing.Size(48, 17);
            this._cleanGacCheckBox.TabIndex = 2;
            this._cleanGacCheckBox.Text = "GAC";
            this._toolTip.SetToolTip(this._cleanGacCheckBox, "Removes all files from the GAC which have the Timberline public key token.");
            this._cleanGacCheckBox.UseVisualStyleBackColor = true;
            // 
            // _cleanSandboxCheckBox
            // 
            this._cleanSandboxCheckBox.AutoSize = true;
            this._cleanSandboxCheckBox.Checked = true;
            this._cleanSandboxCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this._cleanSandboxCheckBox.Location = new System.Drawing.Point(6, 19);
            this._cleanSandboxCheckBox.Name = "_cleanSandboxCheckBox";
            this._cleanSandboxCheckBox.Size = new System.Drawing.Size(71, 17);
            this._cleanSandboxCheckBox.TabIndex = 3;
            this._cleanSandboxCheckBox.Text = "Sandbox:";
            this._toolTip.SetToolTip(this._cleanSandboxCheckBox, resources.GetString("_cleanSandboxCheckBox.ToolTip"));
            this._cleanSandboxCheckBox.UseVisualStyleBackColor = true;
            // 
            // _sandboxLocationTextBox
            // 
            this._sandboxLocationTextBox.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._sandboxLocationTextBox.Location = new System.Drawing.Point(83, 17);
            this._sandboxLocationTextBox.Name = "_sandboxLocationTextBox";
            this._sandboxLocationTextBox.Size = new System.Drawing.Size(410, 20);
            this._sandboxLocationTextBox.TabIndex = 4;
            this._toolTip.SetToolTip(this._sandboxLocationTextBox, "The root location of the sandbox to be cleaned.  Defaults to the current value of" +
                    " SAGE_SANDBOX.");
            // 
            // _cleanButton
            // 
            this._cleanButton.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._cleanButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._cleanButton.Location = new System.Drawing.Point(519, 12);
            this._cleanButton.Name = "_cleanButton";
            this._cleanButton.Size = new System.Drawing.Size(101, 22);
            this._cleanButton.TabIndex = 6;
            this._cleanButton.Text = "C&lean";
            this._toolTip.SetToolTip(this._cleanButton, "Begins the Clean operation using the specified options.");
            this._cleanButton.UseVisualStyleBackColor = true;
            this._cleanButton.Click += new System.EventHandler(this._cleanButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this._cleanSandboxCheckBox);
            this.groupBox1.Controls.Add(this._cleanRegistryCheckBox);
            this.groupBox1.Controls.Add(this._cleanGacCheckBox);
            this.groupBox1.Controls.Add(this._sandboxLocationTextBox);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(501, 90);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cleaning Options";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Results";
            // 
            // _closeButton
            // 
            this._closeButton.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this._closeButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._closeButton.Location = new System.Drawing.Point(519, 412);
            this._closeButton.Name = "_closeButton";
            this._closeButton.Size = new System.Drawing.Size(101, 22);
            this._closeButton.TabIndex = 9;
            this._closeButton.Text = "&Close";
            this._closeButton.UseVisualStyleBackColor = true;
            this._closeButton.Click += new System.EventHandler(this._closeButton_Click);
            // 
            // _resultsDataGridView
            // 
            this._resultsDataGridView.AllowUserToAddRows = false;
            this._resultsDataGridView.AllowUserToDeleteRows = false;
            this._resultsDataGridView.AllowUserToResizeColumns = false;
            this._resultsDataGridView.AllowUserToResizeRows = false;
            this._resultsDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles) ((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._resultsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._resultsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this._imageColumne,
            this._descriptionColumn,
            this.Column1,
            this.ErrorData});
            this._resultsDataGridView.Location = new System.Drawing.Point(12, 145);
            this._resultsDataGridView.Name = "_resultsDataGridView";
            this._resultsDataGridView.RowHeadersVisible = false;
            this._resultsDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this._resultsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this._resultsDataGridView.Size = new System.Drawing.Size(608, 261);
            this._resultsDataGridView.TabIndex = 10;
            // 
            // _imageColumne
            // 
            this._imageColumne.Frozen = true;
            this._imageColumne.HeaderText = "";
            this._imageColumne.Name = "_imageColumne";
            this._imageColumne.Width = 20;
            // 
            // _descriptionColumn
            // 
            this._descriptionColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this._descriptionColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this._descriptionColumn.HeaderText = "Description";
            this._descriptionColumn.Name = "_descriptionColumn";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Error";
            this.Column1.Name = "Column1";
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column1.Text = "Click";
            this.Column1.UseColumnTextForButtonValue = true;
            this.Column1.Width = 70;
            // 
            // ErrorData
            // 
            this.ErrorData.HeaderText = "ErrorData";
            this.ErrorData.Name = "ErrorData";
            this.ErrorData.Visible = false;
            // 
            // _imageList
            // 
            this._imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer) (resources.GetObject("_imageList.ImageStream")));
            this._imageList.TransparentColor = System.Drawing.Color.Magenta;
            this._imageList.Images.SetKeyName(0, "Blank.bmp");
            this._imageList.Images.SetKeyName(1, "Critical.bmp");
            this._imageList.Images.SetKeyName(2, "OK.bmp");
            this._imageList.Images.SetKeyName(3, "Information.bmp");
            // 
            // _testOnlyCheckBox
            // 
            this._testOnlyCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._testOnlyCheckBox.AutoSize = true;
            this._testOnlyCheckBox.Location = new System.Drawing.Point(519, 40);
            this._testOnlyCheckBox.Name = "_testOnlyCheckBox";
            this._testOnlyCheckBox.Size = new System.Drawing.Size(69, 17);
            this._testOnlyCheckBox.TabIndex = 11;
            this._testOnlyCheckBox.Text = "Test-only";
            this._toolTip.SetToolTip(this._testOnlyCheckBox, "When checked, causes the tool to display what actions would be taken during a non" +
                    "-Test Clean operation.");
            this._testOnlyCheckBox.UseVisualStyleBackColor = true;
            // 
            // _toolTip
            // 
            this._toolTip.AutoPopDelay = 30000;
            this._toolTip.InitialDelay = 500;
            this._toolTip.ReshowDelay = 100;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(462, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Showing:";
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "All",
            "Info & failure"});
            this.comboBox1.Location = new System.Drawing.Point(519, 118);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(101, 21);
            this.comboBox1.TabIndex = 13;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 446);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this._testOnlyCheckBox);
            this.Controls.Add(this._resultsDataGridView);
            this.Controls.Add(this._closeButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this._cleanButton);
            this.Icon = ((System.Drawing.Icon) (resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "DevBoxCleaner";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize) (this._resultsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox _cleanRegistryCheckBox;
        private System.Windows.Forms.CheckBox _cleanGacCheckBox;
        private System.Windows.Forms.CheckBox _cleanSandboxCheckBox;
        private System.Windows.Forms.TextBox _sandboxLocationTextBox;
        private System.Windows.Forms.Button _cleanButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button _closeButton;
        private System.Windows.Forms.DataGridView _resultsDataGridView;
        private System.Windows.Forms.ImageList _imageList;
        private System.Windows.Forms.CheckBox _testOnlyCheckBox;
        private System.Windows.Forms.ToolTip _toolTip;
        private System.Windows.Forms.DataGridViewImageColumn _imageColumne;
        private System.Windows.Forms.DataGridViewTextBoxColumn _descriptionColumn;
        private System.Windows.Forms.DataGridViewButtonColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ErrorData;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}

