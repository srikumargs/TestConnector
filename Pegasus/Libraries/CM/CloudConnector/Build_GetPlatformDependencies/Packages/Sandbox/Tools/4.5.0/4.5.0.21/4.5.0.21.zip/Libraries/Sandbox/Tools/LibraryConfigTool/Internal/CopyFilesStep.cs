using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class CopyFilesStep : IStep
    {
        public CopyFilesStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _recursive = Utils.GetOptionalAttribute(navigator, Constants.RecursiveAttribute);
            _sourceFileSpec = Utils.GetRequiredAttribute(navigator, Constants.SourceFileSpecAttribute, Constants.CopyFilesElement, configInfo.ConfigFile);
            _destinationDir = Utils.GetRequiredAttribute(navigator, Constants.DestinationDirAttribute, Constants.CopyFilesElement, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String recursive = rootConfigInfo.ReplaceAllVariables(_recursive);
            String sourceFileSpec = rootConfigInfo.ReplaceAllVariables(_sourceFileSpec);
            String targetDir = rootConfigInfo.ReplaceAllVariables(_destinationDir);

            SearchOption searchOption = SearchOption.TopDirectoryOnly;
            if(!String.IsNullOrEmpty(recursive) && Boolean.Parse(recursive))
            {
                searchOption = SearchOption.AllDirectories;
            }

            String[] fileNames = null;
            String fileSpec = String.Empty;
            if(sourceFileSpec.Contains("*") || sourceFileSpec.Contains("?"))
            {
                fileSpec = sourceFileSpec.Substring(sourceFileSpec.LastIndexOf('\\') + 1);
                fileNames = Directory.GetFiles(sourceFileSpec.Substring(0, sourceFileSpec.LastIndexOf('\\')), fileSpec, searchOption);
            }
            else
            {
                fileNames = new String[]{sourceFileSpec};
            }

            foreach(String fileName in fileNames)
            {
                if(!String.IsNullOrEmpty(fileSpec) && Utils.FileSpecEndsInConcrete3LetterExtension(fileSpec))
                {
                    // The file spec looks like something with exactly a 3 character extension.
                    // We must work around the goofy .NET behavior which will match any file that has an
                    // extension that starts with those three character ... but may have more.
                    if (!fileName.ToLower(CultureInfo.InvariantCulture).EndsWith(fileSpec.ToLower(CultureInfo.InvariantCulture).Substring(fileSpec.LastIndexOf('.')).ToLower(CultureInfo.InvariantCulture)))
                    {
                        // skip the file, it is not a true match
                        continue;
                    }
                }

                Utils.EnsureDirectoryExists(targetDir, "TargetDir");
                Utils.CopyFileToTargetDir(fileName, targetDir, false);
            }
        }

        #endregion

        private String _recursive;
        private String _sourceFileSpec;
        private String _destinationDir;
    }
}
