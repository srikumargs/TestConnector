﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CSProjCleaner.Internal
{
    interface IPromptUser
    {
        DialogResult RetryCancel(String text, String caption);
    }
}
