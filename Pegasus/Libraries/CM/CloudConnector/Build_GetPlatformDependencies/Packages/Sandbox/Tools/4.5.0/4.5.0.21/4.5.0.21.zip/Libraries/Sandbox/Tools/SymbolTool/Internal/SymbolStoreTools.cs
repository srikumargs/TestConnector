﻿using System;

namespace SymbolTool.Internal
{
    /// <summary>
    /// Defines the command line tools used to work with symbol servers.
    /// </summary>
    public static class SymbolStoreTools
    {
        /// <summary>
        /// Gets the full path to the tools directory. This will attempt to use 1 of the 3 possible paths based on configuration.
        /// </summary>
        private static string FullPathToolsDir
        {
            get { return @"C:\Program Files\Microsoft Team Foundation Server 2010\Tools"; }
        }

        /// <summary>
        /// Gets the full path to the alternate tools directory.
        /// </summary>
        private static string FullPathToolsDirAlt32
        {
            get { return @"C:\Program Files\Debugging Tools for Windows (x86)\srcsrv"; }
        }

        /// <summary>
        /// Gets the full path to the alternate tools directory.
        /// </summary>
        private static string FullPathToolsDirAlt64
        {
            get { return @"C:\Program Files\Debugging Tools for Windows (x64)\srcsrv"; }
        }

        /// <summary>
        /// The source tool filename.
        /// </summary>
        private const string SrcToolExe = "srctool.exe";

        /// <summary>
        /// The PDB string tool filename.
        /// </summary>
        private const string PdbStrExe = "pdbstr.exe";

        /// <summary>
        /// The SymStore tool filename,
        /// </summary>
        private const string SymStoreExe = "symstore.exe";

        /// <summary>
        /// Gets the full path to the srctool.exe symbol store tool.
        /// </summary>
        public static string FullPathSrcTool
        {
            get
            {
                string path = System.IO.Path.Combine(FullPathToolsDir, SrcToolExe);

                if (!System.IO.File.Exists(path))
                {
                    path = System.IO.Path.Combine(FullPathToolsDirAlt64, SrcToolExe);

                    if (!System.IO.File.Exists(path))
                    {
                        path = System.IO.Path.Combine(FullPathToolsDirAlt32, SrcToolExe);
                    }
                }

                return path;
            }
        }

        /// <summary>
        /// Gets the full path to the pdbstr.exe symbol store tool.
        /// </summary>
        public static string FullPathPdbStr
        {
            get
            {
                string path = System.IO.Path.Combine(FullPathToolsDir, PdbStrExe);

                if (!System.IO.File.Exists(path))
                {
                    path = System.IO.Path.Combine(FullPathToolsDirAlt64, PdbStrExe);

                    if (!System.IO.File.Exists(path))
                    {
                        path = System.IO.Path.Combine(FullPathToolsDirAlt32, PdbStrExe);
                    }
                }

                return path;
            }
        }

        /// <summary>
        /// Gets the full path to the symstore.exe symbol store tool.
        /// </summary>
        public static string FullPathSymStore
        {
            get
            {
                string path = System.IO.Path.Combine(FullPathToolsDir, SymStoreExe);

                if (!System.IO.File.Exists(path))
                {
                    path = System.IO.Path.Combine(System.IO.Path.Combine(FullPathToolsDirAlt64, ".."), SymStoreExe);

                    if (!System.IO.File.Exists(path))
                    {
                        path = System.IO.Path.Combine(System.IO.Path.Combine(FullPathToolsDirAlt32, ".."), SymStoreExe);
                    }
                }

                return path;
            }
        }

        /// <summary>
        /// Verify that all command line tools exist and throw an exception if any is not found.
        /// </summary>
        /// <exception cref="SymbolToolException">The exception thrown if any of the tools does not exist.</exception>
        public static void VerifyAllToolsExist()
        {
            if (!System.IO.File.Exists(FullPathSrcTool))
            {
                throw new SymbolToolException(string.Format(Strings.SymbolToolNotInstalledMsg, SrcToolExe));
            }

            if (!System.IO.File.Exists(FullPathPdbStr))
            {
                throw new SymbolToolException(string.Format(Strings.SymbolToolNotInstalledMsg, PdbStrExe));
            }

            if (!System.IO.File.Exists(FullPathSymStore))
            {
                throw new SymbolToolException(string.Format(Strings.SymbolToolNotInstalledMsg, SymStoreExe));
            }
        }
    }
}
