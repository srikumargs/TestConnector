﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Xml.XPath;

namespace LibraryConfigTool.Internal
{
    internal sealed class AddFilesStep : IStep
    {
        public AddFilesStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourcedir = Utils.GetRequiredAttribute(navigator, Constants.SourceDirAttribute, Constants.AddFilesElement, configInfo.ConfigFile);
            _fileSpec = Utils.GetRequiredAttribute(navigator, Constants.FileSpecAttribute, Constants.AddFilesElement, configInfo.ConfigFile);
            _recursive = Utils.GetOptionalAttribute(navigator, Constants.RecursiveAttribute);
            _failIfMissing = Utils.GetOptionalAttribute(navigator, "FailIfMissing");

            if (String.IsNullOrEmpty(_failIfMissing))
            {
                _failIfMissing = Boolean.TrueString;
            }

            // Read any associated Exclude elements
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                Program.Output.Write(OutputType.Verbose, "Adding exclude expressions:");
                XPathNodeIterator excludeItemIterator = navigator.Select(Constants.ExcludeExpression);
                while (excludeItemIterator.MoveNext())
                {
                    String expression = Utils.GetRequiredAttribute(excludeItemIterator.Current, Constants.ExpressionAttribute, Constants.ExcludeExpression, configInfo.ConfigFile);
                    _excludeExpressions.Add(expression);
                }
            }

            _configInfo = configInfo;
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceDir = rootConfigInfo.ReplaceAllVariables(_sourcedir);
            String fileSpec = rootConfigInfo.ReplaceAllVariables(_fileSpec);
            String recursive = rootConfigInfo.ReplaceAllVariables(_recursive);
            String failIfMissing = rootConfigInfo.ReplaceAllVariables(_failIfMissing);

            List<String> result = new List<String>();

            if (!Directory.Exists(sourceDir))
            {
                if (Boolean.Parse(failIfMissing))
                {
                    using (BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, "AddFiles processing failed; source directory missing and 'FailIfMissing' is true.");
                        output.AddErrorDetail("SourceDir", sourceDir);
                        output.AddErrorDetail("FileSpec", fileSpec);
                        output.EndWriteError();
                    }
                    return;
                }
                else
                {
                    Program.Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "Skipping missing source directory '{0}'", sourceDir));
                    return;
                }
            }
            String[] directories = Directory.GetDirectories(sourceDir, "*", SearchOption.AllDirectories);

            // the FileSpec attribute cannot contain '**' or '\' or ';';  these are reserved for use in exclusion expressions only
            if (fileSpec.Contains("**") || fileSpec.Contains("\\") || fileSpec.Contains(";"))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.UnsupportedFileSpecFormat, fileSpec);
                throw new LibraryConfigSchemaException(_configInfo.ConfigFile, errorMessage);
            }

            // determine whether to do a recursive search or not
            SearchOption searchOption = SearchOption.TopDirectoryOnly;
            if (!String.IsNullOrEmpty(recursive) && Boolean.Parse(recursive))
            {
                searchOption = SearchOption.AllDirectories;
            }

            // expand the Exclude expressions;  they might have variables in them
            StringCollection expandedExcludeExpressions = new StringCollection();
            foreach (String excludeExpression in _excludeExpressions)
            {
                String expandedExcludeExpression = rootConfigInfo.ReplaceAllVariables(excludeExpression);
                if (!String.IsNullOrEmpty(expandedExcludeExpression))
                {
                    // split out the elements of the (potentially) ;-delimited list
                    String[] specs = expandedExcludeExpression.Split(';');
                    expandedExcludeExpressions.AddRange(specs);
                }
            }

            // create a collection of file names which match the Exclude expressions
            StringCollection excludedFileNames = new StringCollection();
            foreach (String excludeExpression in expandedExcludeExpressions)
            {
                if (excludeExpression.Contains("\\"))
                {
                    // it is a directory exclusion;  it can start with **\ .. but it cannot appear in the middle or end
                    if (excludeExpression.StartsWith("**\\"))
                    {
                        String folderPart = excludeExpression.Substring(3); // skip over the leading "**\"

                        if (folderPart.Contains("**") || !folderPart.Contains("\\"))
                        {
                            String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.UnsupportedExcludeExpressionFormat, excludeExpression);
                            throw new LibraryConfigSchemaException(_configInfo.ConfigFile, errorMessage);
                        }

                        // find all file names which end with the Exclude expression
                        folderPart = folderPart.Substring(0, folderPart.LastIndexOf('\\')).ToLower(CultureInfo.InvariantCulture);
                        String filePart = excludeExpression.Substring(excludeExpression.LastIndexOf('\\') + 1).ToLower(CultureInfo.InvariantCulture);
                        foreach (String directory in directories)
                        {
                            String directoryAsLower = directory.ToLower(CultureInfo.InvariantCulture);
                            if (directoryAsLower.Substring(sourceDir.Length).Contains("\\" + folderPart + "\\") ||
                                directoryAsLower.EndsWith("\\" + folderPart))
                            {
                                String[] fileNamesMatchingExcludeExpression = Directory.GetFiles(directory, filePart, SearchOption.AllDirectories);
                                foreach (String fileNameMatchingExcludeExpression in fileNamesMatchingExcludeExpression)
                                {
                                    String fileNameMatchingExcludeExpressionAsLower = fileNameMatchingExcludeExpression.ToLower(CultureInfo.InvariantCulture);
                                    if (Utils.FileSpecEndsInConcrete3LetterExtension(filePart))
                                    {
                                        // The exclude expression looks like something with exactly a 3 character extension.
                                        // We must work around the goofy .NET behavior which will match any file that has an
                                        // extension that starts with those three character ... but may have more.
                                        if (fileNameMatchingExcludeExpressionAsLower.EndsWith(filePart.Substring(filePart.LastIndexOf('.'))))
                                        {
                                            excludedFileNames.Add(fileNameMatchingExcludeExpressionAsLower);
                                        }
                                    }
                                    else
                                    {
                                        excludedFileNames.Add(fileNameMatchingExcludeExpressionAsLower);
                                    }
                                }
                            }
                        }
                    }
                    else if (excludeExpression.Contains("**"))
                    {
                        // ** cannot appear in the middle or end
                        String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.UnsupportedExcludeExpressionFormat, excludeExpression);
                        throw new LibraryConfigSchemaException(_configInfo.ConfigFile, errorMessage);
                    }
                    else
                    {
                        // no directory wildcard is used ... treated as a relative path off of the source directory
                        String folderPart = excludeExpression.Substring(0, excludeExpression.LastIndexOf('\\')).ToLower(CultureInfo.InvariantCulture);
                        String filePart = excludeExpression.Substring(excludeExpression.LastIndexOf('\\') + 1).ToLower(CultureInfo.InvariantCulture);
                        String[] fileNamesMatchingExcludeExpression = Directory.GetFiles(Path.Combine(sourceDir, folderPart), filePart, SearchOption.AllDirectories);
                        foreach (String fileNameMatchingExcludeExpression in fileNamesMatchingExcludeExpression)
                        {
                            String fileNameMatchingExcludeExpressionAsLower = fileNameMatchingExcludeExpression.ToLower(CultureInfo.InvariantCulture);
                            if (Utils.FileSpecEndsInConcrete3LetterExtension(filePart))
                            {
                                // The exclude expression looks like something with exactly a 3 character extension.
                                // We must work around the goofy .NET behavior which will match any file that has an
                                // extension that starts with those three character ... but may have more.
                                if (fileNameMatchingExcludeExpressionAsLower.EndsWith(filePart.Substring(filePart.LastIndexOf('.'))))
                                {
                                    excludedFileNames.Add(fileNameMatchingExcludeExpressionAsLower);
                                }
                            }
                            else
                            {
                                excludedFileNames.Add(fileNameMatchingExcludeExpressionAsLower);
                            }
                        }
                    }
                }
                else
                {
                    // it is a simple file exclusion
                    String[] fileNamesMatchingExcludeExpression = Directory.GetFiles(sourceDir, excludeExpression, searchOption);
                    foreach (String fileNameMatchingExcludeExpression in fileNamesMatchingExcludeExpression)
                    {
                        String fileNameMatchingExcludeExpressionAsLower = fileNameMatchingExcludeExpression.ToLower(CultureInfo.InvariantCulture);
                        if (Utils.FileSpecEndsInConcrete3LetterExtension(excludeExpression))
                        {
                            // The exclude expression looks like something with exactly a 3 character extension.
                            // We must work around the goofy .NET behavior which will match any file that has an
                            // extension that starts with those three character ... but may have more.
                            if (fileNameMatchingExcludeExpressionAsLower.EndsWith(excludeExpression.Substring(excludeExpression.LastIndexOf('.')).ToLower(CultureInfo.InvariantCulture)))
                            {
                                excludedFileNames.Add(fileNameMatchingExcludeExpressionAsLower);
                            }
                        }
                        else
                        {
                            excludedFileNames.Add(fileNameMatchingExcludeExpressionAsLower);
                        }
                    }
                }
            }

            // all exclusions have been determined;  now start adding files
            Program.Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "Processing AddFiles '{0}\\{1}' ({2})", sourceDir, fileSpec, searchOption));
            String sandboxDir = rootConfigInfo.GetSystemVariableValue(Utils.GetVariableNameKeyForVariableName("System::SandboxDir"));
            Int32 excludedFilesCount = 0;
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                String[] fileNames = Directory.GetFiles(sourceDir, fileSpec, searchOption);
                foreach (String fileName in fileNames)
                {
                    String fileNameAsLower = fileName.ToLower(CultureInfo.InvariantCulture);
                    if (Utils.FileSpecEndsInConcrete3LetterExtension(fileSpec))
                    {
                        // The file spec looks like something with exactly a 3 character extension.
                        // We must work around the goofy .NET behavior which will match any file that has an
                        // extension that starts with those three character ... but may have more.
                        if (!fileNameAsLower.EndsWith(fileSpec.Substring(fileSpec.LastIndexOf('.')).ToLower(CultureInfo.InvariantCulture)))
                        {
                            // skip the file, it is not a true match
                            continue;
                        }
                    }

                    // only add the file if it doesn't match the exlusions;  however if the file was explicitly specified
                    // (i.e., no use of wildcards at all) then always add it regardless of the exclusions
                    Boolean isExplicitlySpecified = (Path.Combine(sourceDir, fileSpec).IndexOfAny(new Char[] { '*', '?' }) == -1);
                    if (isExplicitlySpecified ||
                        !excludedFileNames.Contains(fileNameAsLower))
                    {
                        if (isExplicitlySpecified && !File.Exists(Path.Combine(sourceDir, fileSpec)))
                        {
                            using (BatchedOutput output = new BatchedOutput(false))
                            {
                                output.BeginWriteError(0, Strings.AddFilesProcessingFailedExplicitlySpecifiedFileNotFound);
                                output.AddErrorDetail("SourceDir", sourceDir);
                                output.AddErrorDetail("FileSpec", fileSpec);
                                output.EndWriteError();
                            }
                            return;
                        }

                        Program.Output.Write(OutputType.Info, String.Format("Matched file: '{0}'", fileName));

                        result.Add(Path.GetFullPath(fileName));
                    }
                    else
                    {
                        excludedFilesCount++;
                    }
                }
            }

            Program.Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "Finishing AddFiles processing.  {0} files matched;  {1} files excluded.", result.Count, excludedFilesCount));

            rootConfigInfo.FileGroup.AddFiles(result.AsReadOnly());
        }

        #endregion

        private ConfigInfo _configInfo;
        private String _sourcedir;
        private String _fileSpec;
        private String _recursive;
        private String _failIfMissing;
        private StringCollection _excludeExpressions = new StringCollection();
    }
}
