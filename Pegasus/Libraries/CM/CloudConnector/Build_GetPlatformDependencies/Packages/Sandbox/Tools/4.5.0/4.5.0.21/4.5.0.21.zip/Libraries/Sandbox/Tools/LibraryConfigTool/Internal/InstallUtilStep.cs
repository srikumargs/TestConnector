using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Reflection;

namespace LibraryConfigTool.Internal
{
    internal sealed class InstallUtilStep : IStep
    {
        public InstallUtilStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, Constants.InstallUtilElement, configInfo.ConfigFile);
            _arguments = Utils.GetOptionalAttribute(navigator, Constants.ArgumentsAttribute);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            Program.Output.Write(OutputType.Info, "Performing execution of custom installer classes...");
            Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:        '{0}'", _path));
            Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Arguments:   '{0}'", _arguments));

            using(IndentedOutput indentedOutput = new IndentedOutput())
            {
                String path = rootConfigInfo.ReplaceAllVariables(_path);
                String arguments = rootConfigInfo.ReplaceAllVariables(_arguments);

                try
                {
                    if(!File.Exists(path))
                    {
                        using(BatchedOutput output = new BatchedOutput(false))
                        {
                            output.BeginWriteError(0, Strings.CustomInstallerExecutionFailedFileNotFound);
                            output.AddErrorDetail(Strings.Path, path);
                            output.AddErrorDetail(Strings.Arguments, arguments);
                            output.EndWriteError();
                        }
                    }
                    else
                    {
                        using(IndentedOutput remoteIndentedOutput = new IndentedOutput())
                        {
                            AppDomainSetup appDomainSetup = new AppDomainSetup();
                            appDomainSetup.ApplicationBase = Directory.GetParent(path).FullName;
                            AppDomain appDomain = AppDomain.CreateDomain("RemoteInstallerClassRunner", null, appDomainSetup);
                            try
                            {
                                RemoteInstallerClassRunner executer = (RemoteInstallerClassRunner) appDomain.CreateInstanceFromAndUnwrap(Assembly.GetExecutingAssembly().CodeBase, "LibraryConfigTool.Internal.RemoteInstallerClassRunner");
                                executer.RunInstallerClasses(Program.Output, path, arguments);
                            }
                            finally
                            {
                                AppDomain.Unload(appDomain);
                            }
                        }

                        Program.Output.Write(OutputType.Info, "Custom installer execution succeeded.");
                    }
                }
                catch(Exception ex)
                {
                    using(BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, Strings.CustomInstallerExecutionFailed);
                        output.AddErrorDetail(Strings.Path, path);
                        output.AddErrorDetail(Strings.Arguments, arguments);
                        output.AddErrorDetail(Strings.Error, ex.ToString());
                        output.EndWriteError();
                    }
                }
            }
        }

        #endregion

        private String _path;
        private String _arguments;
    }
}
