using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Runtime.Remoting.Messaging;

namespace LibraryConfigTool.Internal
{
    internal sealed class OutputMessage : MarshalByRefObject, IMessage
    {
        public override object InitializeLifetimeService()
        {
            return null; // prevent leased-based lifetime management
        }

        public OutputMessage(OutputType outputType, IndentAction indentAction, String message)
        {
            _properties.Add("OutputType", outputType.ToString());
            _properties.Add("IndentAction", indentAction.ToString());
            _properties.Add("Message", message);
        }

        #region IMessage Members

        public System.Collections.IDictionary Properties
        {
            get
            {
                return _properties;
            }
        }

        #endregion

        private Dictionary<String, String> _properties = new Dictionary<String, String>();
    }
}