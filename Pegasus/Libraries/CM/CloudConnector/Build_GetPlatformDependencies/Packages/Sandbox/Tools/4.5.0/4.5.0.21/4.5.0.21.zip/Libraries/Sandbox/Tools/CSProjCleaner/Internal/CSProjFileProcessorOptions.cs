﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;

namespace CSProjCleaner.Internal
{
	internal sealed class CSProjFileProcessorOptions
	{
		public ReadOnlyCollection<Int32> WarningsToEnableForConfiguration(String configuration)
		{
			List<Int32> result = new List<Int32>();
			if (_enabledWarningsPerConfiguration.ContainsKey(configuration))
			{
				result.AddRange(_enabledWarningsPerConfiguration[configuration].ToArray());
			}
			if (_enabledWarningsPerConfiguration.ContainsKey(String.Empty))
			{
				result.AddRange(_enabledWarningsPerConfiguration[String.Empty].ToArray());
			}
			return result.AsReadOnly();
		}

		public ReadOnlyCollection<Int32> WarningsToSuppressForConfiguration(String configuration)
		{
			List<Int32> result = new List<Int32>();
			if (_suppressedWarningsPerConfiguration.ContainsKey(configuration))
			{
				result.AddRange(_suppressedWarningsPerConfiguration[configuration].ToArray());
			}
			if (_suppressedWarningsPerConfiguration.ContainsKey(String.Empty))
			{
				result.AddRange(_suppressedWarningsPerConfiguration[String.Empty].ToArray());
			}
			return result.AsReadOnly();
		}

		public void EnableWarning(Int32 warningNumber)
		{
			EnableWarning(String.Empty, warningNumber);
		}

		public void EnableWarning(String configuration, Int32 warningNumber)
		{
			if (!_enabledWarningsPerConfiguration.ContainsKey(configuration))
			{
				_enabledWarningsPerConfiguration.Add(configuration, new List<Int32>());
			}
			_enabledWarningsPerConfiguration[configuration].Add(warningNumber);
		}

		public void SuppressWarning(Int32 warningNumber)
		{
			SuppressWarning(String.Empty, warningNumber);
		}

		public void SuppressWarning(String configuration, Int32 warningNumber)
		{
			if (!_suppressedWarningsPerConfiguration.ContainsKey(configuration))
			{
				_suppressedWarningsPerConfiguration.Add(configuration, new List<Int32>());
			}
			_suppressedWarningsPerConfiguration[configuration].Add(warningNumber);
		}

		public Action PreBuildAction
		{
			get { return _preBuildAction; }
			set { _preBuildAction = value; }
		}

		public Action PostBuildAction
		{
			get { return _postBuildAction; }
			set { _postBuildAction = value; }
		}

		public Action SignAssemblyAction
		{
			get { return _signAssembly; }
			set { _signAssembly = value; }
		}

		public String FrameworkVersion
		{
			get { return _framework; }
			set { _framework = value; }
		}

		public String PlatformTarget
		{
			get { return _platformTarget; }
			set { _platformTarget = value; }
		}

		public Boolean SetCommonPrivateKey
		{
			get { return _setPrivate; }
			set { _setPrivate = value; }
		}

		public Action WarningsAsErrorsAction
		{
			get { return _disableWarningsAsErrors; }
			set { _disableWarningsAsErrors = value; }
		}

		public Boolean FixOutputPaths
		{
			get { return _fixOutputPaths; }
			set { _fixOutputPaths = value; }
		}

		public Boolean FixAssemblyReferences
		{
			get { return _fixAssemblyReferences; }
			set { _fixAssemblyReferences = value; }
		}

		public Boolean NoBackup
		{
			get { return _noBackup; }
			set { _noBackup = value; }
		}

		public void ChangeCodeAnalysisAction(Action action)
		{
			ChangeCodeAnalysisAction(String.Empty, action);
		}

		public void ChangeCodeAnalysisAction(String configuration, Action action)
		{
			if (!_codeAnalysisActionPerConfiguration.ContainsKey(configuration))
			{
				_codeAnalysisActionPerConfiguration.Add(configuration, action);
			}
			_codeAnalysisActionPerConfiguration[configuration] = action;
		}

		public Action CodeAnalysisActionForConfiguration(String configuration)
		{
			Action result = Action.None;
			if (_codeAnalysisActionPerConfiguration.ContainsKey(configuration))
			{
				result = _codeAnalysisActionPerConfiguration[configuration];
			}
			else if (_codeAnalysisActionPerConfiguration.ContainsKey(String.Empty))
			{
				result = _codeAnalysisActionPerConfiguration[String.Empty];
			}
			return result;
		}

		public Boolean AllCodeAnalysisRulesEnabledForConfiguration(String configuration)
		{
			Boolean result = false;
			if (_enableAllCodeAnalysisRulesPerConfiguration.ContainsKey(configuration))
			{
				result = _enableAllCodeAnalysisRulesPerConfiguration[configuration];
			}
			else if (_enableAllCodeAnalysisRulesPerConfiguration.ContainsKey(String.Empty))
			{
				result = _enableAllCodeAnalysisRulesPerConfiguration[String.Empty];
			}
			return result;
		}

		public void EnableAllCodeAnalysisRules(Boolean enable)
		{
			EnableAllCodeAnalysisRules(String.Empty, enable);
		}

		public void EnableAllCodeAnalysisRules(String configuration, Boolean enable)
		{
			if (!_enableAllCodeAnalysisRulesPerConfiguration.ContainsKey(configuration))
			{
				_enableAllCodeAnalysisRulesPerConfiguration.Add(configuration, enable);
			}
			_enableAllCodeAnalysisRulesPerConfiguration[configuration] = enable;
		}

		public ReadOnlyCollection<String> CodeAnalysisRulesToEnableForConfiguration(String configuration)
		{
			List<String> result = new List<String>();
			if (_enabledCodeAnalysisRulesPerConfiguration.ContainsKey(configuration))
			{
				result.AddRange(_enabledCodeAnalysisRulesPerConfiguration[configuration].ToArray());
			}
			if (_enabledCodeAnalysisRulesPerConfiguration.ContainsKey(String.Empty))
			{
				result.AddRange(_enabledCodeAnalysisRulesPerConfiguration[String.Empty].ToArray());
			}
			return result.AsReadOnly();
		}

		public ReadOnlyCollection<String> CodeAnalysisRulesToSuppressForConfiguration(String configuration)
		{
			List<String> result = new List<String>();
			if (_suppressedCodeAnalysisRulesPerConfiguration.ContainsKey(configuration))
			{
				result.AddRange(_suppressedCodeAnalysisRulesPerConfiguration[configuration].ToArray());
			}
			if (_suppressedCodeAnalysisRulesPerConfiguration.ContainsKey(String.Empty))
			{
				result.AddRange(_suppressedCodeAnalysisRulesPerConfiguration[String.Empty].ToArray());
			}
			return result.AsReadOnly();
		}

		public void EnableCodeAnalysisRule(String rule)
		{
			EnableCodeAnalysisRule(String.Empty, rule);
		}

		public void EnableCodeAnalysisRule(String configuration, String rule)
		{
			if (!_enabledCodeAnalysisRulesPerConfiguration.ContainsKey(configuration))
			{
				_enabledCodeAnalysisRulesPerConfiguration.Add(configuration, new List<String>());
			}
			_enabledCodeAnalysisRulesPerConfiguration[configuration].Add(rule);
		}

		public void SuppressCodeAnalysisRule(String rule)
		{
			SuppressCodeAnalysisRule(String.Empty, rule);
		}

		public void SuppressCodeAnalysisRule(String configuration, String rule)
		{
			if (!_suppressedCodeAnalysisRulesPerConfiguration.ContainsKey(configuration))
			{
				_suppressedCodeAnalysisRulesPerConfiguration.Add(configuration, new List<String>());
			}
			_suppressedCodeAnalysisRulesPerConfiguration[configuration].Add(rule);
		}

		public Boolean Debug
		{
			get { return _debug; }
			set { _debug = value; }
		}

		private void DebugDictionary(Dictionary<String, List<String>> dictionary, String prefix)
		{
			foreach (KeyValuePair<String, List<String>> key in dictionary)
			{
				System.Diagnostics.Debug.WriteLine(String.Format(CultureInfo.InvariantCulture, "Key: {0}", key.Key));
				foreach (String value in key.Value)
				{
					System.Diagnostics.Debug.WriteLine(String.Format(CultureInfo.InvariantCulture, "  {0}{1}", prefix, value));
				}
			}
		}

		public void DebugCodeAnalysisValues()
		{
			if (Debug)
			{
				DebugDictionary(_enabledCodeAnalysisRulesPerConfiguration, "");
				DebugDictionary(_suppressedCodeAnalysisRulesPerConfiguration, "");
			}
		}

		public String SourceControlServer
		{
			get { return _sourceControlServer; }
			set { _sourceControlServer = value; }
		}

		private Dictionary<String, List<Int32>> _enabledWarningsPerConfiguration = new Dictionary<String, List<Int32>>();
		private Dictionary<String, List<Int32>> _suppressedWarningsPerConfiguration = new Dictionary<String, List<Int32>>();
		private Dictionary<String, Action> _codeAnalysisActionPerConfiguration = new Dictionary<String, Action>();
		private Dictionary<String, Boolean> _enableAllCodeAnalysisRulesPerConfiguration = new Dictionary<String, Boolean>();
		private Dictionary<String, List<String>> _enabledCodeAnalysisRulesPerConfiguration = new Dictionary<String, List<String>>();
		private Dictionary<String, List<String>> _suppressedCodeAnalysisRulesPerConfiguration = new Dictionary<String, List<String>>();
		private Dictionary<String, List<String>> _errorsCodeAnalysisRulesPerConfiguration = new Dictionary<String, List<String>>();
		private Action _preBuildAction;
		private Action _postBuildAction;
		private Action _signAssembly;
		private Action _disableWarningsAsErrors;
		private Boolean _setPrivate;
		private Boolean _fixOutputPaths;
		private String _framework;
		private String _platformTarget;
		private Boolean _fixAssemblyReferences;
		private Boolean _debug;
		private Boolean _noBackup;
		private String _sourceControlServer;
	}
}
