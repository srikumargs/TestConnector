using System;
using System.Collections.Generic;
using System.Text;

namespace DevBoxCleaner.Internal
{
    internal sealed class ResultEventArgs : EventArgs
    {
        public ResultEventArgs(ResultCode code, String description)
            : this(code, description, null)
        {
        }

        public ResultEventArgs(ResultCode code, String description, String details)
        {
            _code = code;
            _description = description;
            _details = details;
        }

        public ResultCode Code
        {
            get
            {
                return _code;
            }
        }

        public String Description
        {
            get
            {
                return _description;
            }
        }

        public String Details
        {
            get
            {
                return _details;
            }
        }

        private ResultCode _code;
        private String _description;
        private String _details;
    }
}
