﻿namespace CSProjCleaner.Internal
{
    internal enum Action
    {
        None = 0,
        Set,
        Unset
    }
}
