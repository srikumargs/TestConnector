﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSProjCleaner.Internal
{
    internal sealed class DataGridViewRowInfo
    {
        public DataGridViewRowInfo(String helpText)
        {
            _helpText = helpText;
        }

        public String HelpText
        { get { return _helpText; } }

        private String _helpText;
    }
}
