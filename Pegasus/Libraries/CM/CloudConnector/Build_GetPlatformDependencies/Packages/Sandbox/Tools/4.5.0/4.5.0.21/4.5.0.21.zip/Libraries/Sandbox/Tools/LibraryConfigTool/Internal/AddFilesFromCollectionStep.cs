﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Xml.XPath;

namespace LibraryConfigTool.Internal
{
    internal sealed class AddFilesFromCollectionStep : IStep
    {
        public AddFilesFromCollectionStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _collectionName = Utils.GetRequiredAttribute(navigator, "CollectionName", Constants.AddFilesFromCollectionElement, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String collectionName = rootConfigInfo.ReplaceAllVariables(_collectionName);

            ReadOnlyCollection<String> result = rootConfigInfo.GetCollectionVariableValue(Utils.GetVariableNameKeyForVariableName(collectionName));

            rootConfigInfo.FileGroup.AddFiles(result);

            Program.Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "Finishing AddFilesFromCollection processing.  {0} files added.", result.Count));
        }

        #endregion

        private String _collectionName;
    }
}
