﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using CompressionBase64Encoder.Internal;

namespace CompressionBase64Encoder
{
    public static class Program
    {
        static void Main(String[] args)
        {
            System.Environment.ExitCode = (Int32)ExitCode.UnexpectedErrorsOccurred;

            try
            {
                Options options = new Options();
                ParseOptions(options, args);

                if (_printHelp || !options.IsValid)
                {
                    PrintHelp();
                    Environment.ExitCode = 1;
                }
                else
                {
                    PrintBanner();

                    FileStream fileStream = new FileStream(options.InputFileName, FileMode.Open, FileAccess.Read);
                    Byte[] bytes = new Byte[fileStream.Length];
                    String compressedBase64 = String.Empty;
                    if (fileStream.Read(bytes, 0, bytes.Length) == fileStream.Length)
                    {
                        using (MemoryStream memoryStream = new MemoryStream())
                        {
                            using (GZipStream gzipStream = new GZipStream(memoryStream, CompressionMode.Compress, true))
                            {
                                gzipStream.Write(bytes, 0, bytes.Length);
                                gzipStream.Close();

                                memoryStream.Position = 0;
                                Byte[] compressedBytes = new Byte[memoryStream.Length];
                                memoryStream.Read(compressedBytes, 0, compressedBytes.Length);
                                compressedBase64 = Convert.ToBase64String(compressedBytes);
                            }
                        }

                        if (options.DoTemplateReplace)
                        {
                            String fileContents = File.ReadAllText(options.TemplateFileName);
                            String newFileContents = fileContents.Replace(options.ReplaceTag, compressedBase64);
                            if (fileContents != newFileContents)
                            {
                                if (options.DoOutputToFile)
                                {
                                    if (File.Exists(options.OutputFileName))
                                    {
                                        File.SetAttributes(options.OutputFileName, File.GetAttributes(options.OutputFileName) & ~FileAttributes.ReadOnly);
                                    }
                                    File.WriteAllText(options.OutputFileName, newFileContents);
                                    WriteLine(String.Format("'{0}' written.", options.OutputFileName));
                                }
                                else
                                {
                                    WriteLine(newFileContents);
                                }
                                System.Environment.ExitCode = (Int32)ExitCode.Success;
                            }
                            else
                            {
                                WriteLine(String.Format("Nothing done. Performing replace of '{0}' tag in '{1}' results in no change.", options.ReplaceTag, options.TemplateFileName));
                                System.Environment.ExitCode = (Int32)ExitCode.NoActionTaken;
                            }
                        }
                        else
                        {
                            if (options.DoOutputToFile)
                            {
                                File.SetAttributes(options.OutputFileName, File.GetAttributes(options.OutputFileName) & ~FileAttributes.ReadOnly);
                                File.WriteAllText(options.OutputFileName, compressedBase64);
                                WriteLine(String.Format("'{0}' written.", options.OutputFileName));
                            }
                            else
                            {
                                WriteLine(compressedBase64);
                            }
                            System.Environment.ExitCode = (Int32)ExitCode.Success;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLine("!!! " + ex.ToString(), true);
            }
        }

        private static void ParseOptions(Options options, String[] args)
        {
            Dictionary<String, OptionHandler> optionHandlers = new Dictionary<String, OptionHandler>();
            optionHandlers["/debug"] = new OptionHandler(DebugOptionHandler);
            optionHandlers["/help"] = new OptionHandler(HelpOptionHandler);
            optionHandlers["/?"] = new OptionHandler(HelpOptionHandler);
            optionHandlers["/nologo"] = new OptionHandler(NoLogoOptionHandler);
            optionHandlers["/silent"] = new OptionHandler(SilentOptionHandler);
            optionHandlers["/s"] = new OptionHandler(SilentOptionHandler);
            optionHandlers["/input:"] = new OptionHandler(InputFileNameHandler);
            optionHandlers["/i:"] = new OptionHandler(InputFileNameHandler);
            optionHandlers["/template:"] = new OptionHandler(TemplateFileNameHandler);
            optionHandlers["/t:"] = new OptionHandler(TemplateFileNameHandler);
            optionHandlers["/replaceTag:"] = new OptionHandler(ReplaceTagHandler);
            optionHandlers["/r:"] = new OptionHandler(ReplaceTagHandler);
            optionHandlers["/output:"] = new OptionHandler(OutputFileNameHandler);
            optionHandlers["/o:"] = new OptionHandler(OutputFileNameHandler);

            foreach (String arg in args)
            {
                Int32 nPos = arg.IndexOf(':');
                String param = arg.Substring(nPos + 1);
                String option = (nPos == -1 ? arg : arg.Substring(0, nPos + 1));

                if (optionHandlers.ContainsKey(option))
                {
                    optionHandlers[option](options, param);
                }
            }
        }

        private static void DebugOptionHandler(Options options, String param)
        { options.Debug = true; }

        private static void HelpOptionHandler(Options options, String param)
        { _printHelp = true; }

        private static void NoLogoOptionHandler(Options options, String param)
        { _noLogo = true; }

        private static void SilentOptionHandler(Options options, String param)
        { _silent = true; }

        private static void InputFileNameHandler(Options options, String param)
        { options.InputFileName = param; }

        private static void TemplateFileNameHandler(Options options, String param)
        { options.TemplateFileName = param; }

        private static void ReplaceTagHandler(Options options, String param)
        { options.ReplaceTag = param;  }

        private static void OutputFileNameHandler(Options options, String param)
        { options.OutputFileName = param; }

        private static void PrintBanner()
        {
            if (!_noLogo)
            {
                WriteLine("Sage Compression Base64 Encoding Tool.  Version " + Assembly.GetExecutingAssembly().GetName().Version);
                WriteLine(String.Empty);
            }
        }

        private static void PrintHelp()
        {
            PrintBanner();

            WriteLine("Syntax: CompressionBase64Encoder /input:<file> [Options]");
            WriteLine("");
            WriteLine("Options:");
            // /debug option purposefully not printed
            //WriteLine("  /debug");
            //WriteLine("    Writes details to debug output");
            //WriteLine("");
            WriteLine("  /input:<file>, /i:<file>");
            WriteLine("    Loads the bytes from <file> for compression encoding");
            WriteLine("");
            WriteLine("  /template:<file>, /t:<file>");
            WriteLine("    Contents of <file> will be used as an output template; usage of this option");
            WriteLine("    requires specification of /replaceTag:<tag>");
            WriteLine("");
            WriteLine("  /replaceTag:<tag>, /r:<tag>");
            WriteLine("    Contents of template file will be selectively replaced with the compression");
            WriteLine("    encoding result using the <tag> as a replacement marker; usage of this");
            WriteLine("    option requires specification of /template:<file>");
            WriteLine("");
            WriteLine("  /output:<file>, /o:<file>");
            WriteLine("    Writes the resulting output to <file>");
            WriteLine("");
            WriteLine("  /silent");
            WriteLine("    Turns off the progress output to the console");
            WriteLine("");
            WriteLine("  /nologo");
            WriteLine("    Suppress display of the logo banner");
            WriteLine("");
            WriteLine("  /?, /help");
            WriteLine("    Displays this usage mesage");
        }

        private delegate void OptionHandler(Options options, String param);

        internal static void WriteLine(String line, Boolean writeAlways)
        {
            if (writeAlways || !_silent)
            {
                Console.WriteLine(line);
            }
        }

        internal static void WriteLine(String line)
        {
            WriteLine(line, false);
        }

        #region Private fields
        private static Boolean _silent;
        private static Boolean _printHelp;
        private static Boolean _noLogo;
        #endregion


    }


}
