﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.XPath;
using System.IO;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class AppendTextFileStep : IStep
    {
        public AppendTextFileStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourceFileName = Utils.GetRequiredAttribute(navigator, Constants.SourceFileAttribute, Constants.AppendTextFileElement, configInfo.ConfigFile);
            _destFileName = Utils.GetRequiredAttribute(navigator, Constants.DestinationFileAttribute, Constants.AppendTextFileElement, configInfo.ConfigFile);
        }

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceFileName = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_sourceFileName), rootConfigInfo);
            String destFileName = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_destFileName), rootConfigInfo);

            if (!File.Exists(sourceFileName))
            {
                using (BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, "AppendTextFile processing failed; source file not found");
                    output.AddErrorDetail("SourceFile", sourceFileName);
                    output.AddErrorDetail("DestinationFile", destFileName);
                    output.EndWriteError();
                }
                return;
            }
            else
            {
                if (!File.Exists(destFileName))
                {
                    using (StreamWriter sw = File.CreateText(destFileName))
                    { }
                }

                using (StreamWriter sw = File.AppendText(destFileName))
                {
                    using (StreamReader sr = File.OpenText(sourceFileName))
                    {
                        String s = String.Empty;
                        while ((s = sr.ReadLine()) != null)
                        {
                            sw.WriteLine(s);
                        }
                    }
                }
            }
        }

        private String _sourceFileName;
        private String _destFileName;
    }
}
