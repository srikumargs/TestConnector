using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class CopyFileStep : IStep
    {
        public CopyFileStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourceFile = Utils.GetRequiredAttribute(navigator, Constants.SourceFileAttribute, Constants.CopyFilesElement, configInfo.ConfigFile);
            _destinationFile = Utils.GetRequiredAttribute(navigator, Constants.DestinationFileAttribute, Constants.CopyFilesElement, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceFile = rootConfigInfo.ReplaceAllVariables(_sourceFile);
            String destinationFile = rootConfigInfo.ReplaceAllVariables(_destinationFile);

            if(sourceFile.Contains("*") || sourceFile.Contains("?"))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.UnsupportedSourceFileFormat, sourceFile);
                throw new LibraryConfigSchemaException(rootConfigInfo.ConfigFile, errorMessage);
            }

            if(destinationFile.Contains("*") || destinationFile.Contains("?"))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.UnsupportedDestinationFileFormat, sourceFile);
                throw new LibraryConfigSchemaException(rootConfigInfo.ConfigFile, errorMessage);
            }

            if(!File.Exists(sourceFile))
            {
                using(BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, Strings.SourceFileDoesNotExist);
                    output.AddErrorDetail("SourceFile", sourceFile);
                    output.EndWriteError();
                }
            }
            else
            {

                Utils.EnsureDirectoryExists(Directory.GetParent(destinationFile).FullName, "TargetDir");
                Utils.CopyFile(sourceFile, destinationFile, false);
            }
        }

        #endregion

        private String _sourceFile;
        private String _destinationFile;
    }
}
