namespace __CompositeAssemblyTool_Namespace
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Resources;
    using System.IO;
    using System.Reflection;
    using System.Reflection.Emit;
    using System.Diagnostics;
    using System.Threading;

    public sealed class Program
    {
        [STAThread]
        static void Main(String[] args)
        {
            Environment.ExitCode = -1;

            // Figure out a "safe" name to use for a temp file;  then delete it and create a directory based on that name instead
            // This gyration is necessary because it seems there is no Path.GetTempSubdirectory API 
            String tempName = Path.GetTempFileName();
            File.Delete(tempName);
            Directory.CreateDirectory(tempName);

            try
            {
                foreach (String resourceName in Assembly.GetExecutingAssembly().GetManifestResourceNames())
                {
                    WriteResourceToTempDirectory(resourceName, tempName);
                }

                StringBuilder commandLine = new StringBuilder();

                commandLine.Append("__CompositeAssemblyTool_EmbeddedCommandLine");

                if (args.GetLength(0) > 0)
                {
                    for (Int32 i = 0; i < args.GetLength(0); i++)
                    {
                        commandLine.Append("\"" + args[i] + "\" ");
                    }
                }
                ProcessStartInfo psi = new ProcessStartInfo(Path.Combine(tempName, "__CompositeAssemblyTool_PrimaryAssemblyName"), commandLine.ToString());
                psi.UseShellExecute = false;
                psi.WorkingDirectory = tempName;
                Process process = Process.Start(psi);
                process.WaitForExit();
                Environment.ExitCode = process.ExitCode;
            }
            finally
            {
                // attempt to delete the temporary folder in a retry loop ... in case the OS hangs onto a file handle briefly after
                // the process ends
                Boolean folderDeleted = false;
                UInt16 retryCount = 0;
                const UInt16 maxNumberOfRetries = 10;
                do
                {
                    try
                    {
                        Directory.Delete(tempName, true);
                        folderDeleted = true;
                    }
                    catch (Exception)
                    {
                        Thread.Sleep(500);
                        retryCount++;
                    }
                } while (!folderDeleted && retryCount < maxNumberOfRetries);
            }
        }

        private static void WriteResourceToTempDirectory(String resourceName, String tempDirectory)
        {
            using (Stream resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
            using (BinaryReader binaryReader = new BinaryReader(resourceStream))
            {
                Byte[] resourceBytes = new Byte[resourceStream.Length];
                binaryReader.Read(resourceBytes, 0, Convert.ToInt32(resourceStream.Length));
                binaryReader.Close();

                String tempFileName = Path.Combine(tempDirectory, resourceName);
                using(FileStream fileStream = new FileStream(tempFileName, FileMode.Create))
                using(BinaryWriter binaryWriter = new BinaryWriter(fileStream))
                {
                    binaryWriter.Write(resourceBytes);
                    binaryWriter.Flush();
                }
            }
        }
    }
}
