using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Permissions;
using System.Runtime.Remoting.Messaging;
using System.Configuration.Install;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1812:AvoidUninstantiatedInternalClasses", Justification = "This class is called in a late-bound manner through a subordinate AppDomain.")]
    internal sealed class RemoteInstallerClassRunner : MarshalByRefObject
    {
        public override object InitializeLifetimeService()
        {
            return null; // prevent leased-based lifetime management
        }

        public void RunInstallerClasses(IMessageSink outputMessageSink, String path, String arguments)
        {
            _outputMessageSink = outputMessageSink;

            //Assembly libraryManagementAssembly = Assembly.LoadFrom(Path.Combine(Utils.SandboxLocation, Constants.AssembliesSageLS1LibraryManagementDll));
            //if(libraryManagementAssembly != null)
            //{
            //    Type libraryManagerType = libraryManagementAssembly.GetType(Constants.SageConfigurationLibraryManager);
            //    String libraryManifestLocation = (String) libraryManagerType.InvokeMember(Constants.LibraryManifestLocationForBinary, BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static, null, null, new Object[] { path }, CultureInfo.InvariantCulture);
            //    libraryManagerType.InvokeMember(Constants.InitializeLibraries, BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static, null, null, new Object[] { libraryManifestLocation }, CultureInfo.InvariantCulture);
            //}

            DoRunInstallerClasses(path, arguments);
        }

        private static void DoRunInstallerClasses(String assemblyPath, String argumentsAsString)
        {
            String[] args = new String[] { };
            if(!String.IsNullOrEmpty(argumentsAsString))
            {
                args = argumentsAsString.Split('/');
            }

            String[] arguments = new String[args.GetLength(0) + 1];
            arguments[0] = assemblyPath;
            for(Int32 i = 0 ; i < args.GetLength(0) ; i++)
            {
                arguments[i + 1] = "/" + args[i].Trim();
            }

            ManagedInstallerClass.InstallHelper(arguments);
        }

        private void Output(OutputType outputType, String message)
        {
            Output(outputType, IndentAction.None, message);
        }

        private void Output(OutputType outputType, IndentAction indentAction, String message)
        {
            _outputMessageSink.SyncProcessMessage(new OutputMessage(outputType, indentAction, message));
        }

        private IMessageSink _outputMessageSink;
    }
}
