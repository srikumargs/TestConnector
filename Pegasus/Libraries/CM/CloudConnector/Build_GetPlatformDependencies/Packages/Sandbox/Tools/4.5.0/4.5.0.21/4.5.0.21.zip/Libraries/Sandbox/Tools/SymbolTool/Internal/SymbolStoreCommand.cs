﻿using System;
using System.Diagnostics;
using System.Globalization;
using Microsoft.Build.Utilities;

namespace SymbolTool.Internal
{
    #region Enums

    /// <summary>
    /// Commands for the SymStore tasks.
    /// </summary>
    public enum SymStoreCommands
    {
        /// <summary>
        /// Add to the symbol server store.
        /// </summary>
        Add,

        /// <summary>
        /// Query the symbol server store.
        /// </summary>
        Query,

        /// <summary>
        /// Delete from the symbol serer store.
        /// </summary>
        Delete
    }

    #endregion Enums

    /// <summary>
    /// Defines a command that can add/remove symbols to and from a symbol server.
    /// </summary>
    /// <remarks>
    /// This source file is a slightly modified version of SymStore.cs from MSBuild.Community.Tasks.
    /// </remarks>
    public class SymbolStoreCommand
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="SymbolStoreCommand"/> class.
        /// </summary>
        public SymbolStoreCommand()
        {
            this.Command = SymStoreCommands.Add;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the command.
        /// </summary>
        /// <value>The command.</value>
        /// <enum cref="MSBuild.Community.Tasks.SymbolServer.SymStoreCommands"/>
        public SymStoreCommands Command { get; set; }

        /// <summary>
        /// Gets or sets a value indicating SymStore will append new indexing information to an existing index file.
        /// </summary>
        /// <value><c>true</c> if append; otherwise, <c>false</c>.</value>
        public bool Append { get; set; }

        /// <summary>
        /// Gets or sets the comment for the transaction.
        /// </summary>
        /// <value>The comment for the transaction.</value>
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets a value indicating SymStore will create a compressed version of each file copied to the symbol store instead of using an uncompressed copy of the file.
        /// </summary>
        /// <value><c>true</c> if compress; otherwise, <c>false</c>.</value>
        public bool Compress { get; set; }

        /// <summary>
        /// Gets or sets a log file to be used for command output. If this is not included, transaction information and other output is sent to stdout.
        /// </summary>
        /// <value>The log file to be used for command output.</value>
        public string LogFile { get; set; }

        /// <summary>
        /// Gets or sets the network path of files or directories to add.
        /// </summary>
        /// <value>The network path of files or directories to add.</value>
        public string Files { get; set; }

        /// <summary>
        /// Gets or sets the server and share where the symbol files were originally stored.
        /// </summary>
        /// <value>The server and share where the symbol files were originally stored.</value>
        public string Share { get; set; }

        /// <summary>
        /// Gets or sets the transaction ID string.
        /// </summary>
        /// <value>The transaction ID string.</value>
        public string TransactionId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the file will be in a local directory rather than a network path.
        /// </summary>
        /// <value><c>true</c> if local; otherwise, <c>false</c>.</value>
        public bool Local { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether SymStore will display verbose output.
        /// </summary>
        /// <value><c>true</c> if verbose; otherwise, <c>false</c>.</value>
        public bool Verbose { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether SymStore will store a pointer to the file, rather than the file itself.
        /// </summary>
        /// <value><c>true</c> if pointer; otherwise, <c>false</c>.</value>
        public bool Pointer { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether SymStore will add files or directories recursively.
        /// </summary>
        /// <value><c>true</c> if recursive; otherwise, <c>false</c>.</value>
        public bool Recursive { get; set; }

        /// <summary>
        /// Gets or sets the root directory for the symbol store.
        /// </summary>
        /// <value>The root directory for the symbol store.</value>
        public string Store { get; set; }

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>The name of the product.</value>
        public string Product { get; set; }

        /// <summary>
        /// Gets or sets the version of the product.
        /// </summary>
        /// <value>The version of the product.</value>
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets the message to be added to each file.
        /// </summary>
        /// <value>The message to be added to each file.</value>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the paths in the file pointers will be relative.
        /// </summary>
        /// <value><c>true</c> if relative; otherwise, <c>false</c>.</value>
        public bool Relative { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to omit the creation of reference pointer files for the files and pointers being stored.
        /// </summary>
        /// <value><c>true</c> to omit the creation of reference pointer; otherwise, <c>false</c>.</value>
        public bool NoReference { get; set; }

        /// <summary>
        /// Gets or sets the index file. Causes SymStore not to store the actual symbol files. Instead, SymStore records information in the IndexFile that will enable SymStore to access the symbol files at a later time.
        /// </summary>
        /// <value>The write index file.</value>
        public string WriteIndex { get; set; }

        /// <summary>
        /// Gets or sets the index file. Causes SymStore to read the data from a file created with WriteIndexFile.
        /// </summary>
        /// <value>The read index file.</value>
        public string ReadIndex { get; set; }

        #endregion

        #region Execute

        /// <summary>
        /// Execute the symstore command.
        /// </summary>
        /// <exception cref="SymbolToolException">The exception thrown if a failure occurs.</exception>
        public void Execute()
        {
            Program.Output.Write(OutputType.Status, string.Format(CultureInfo.CurrentCulture, "Preparing to perform symbol store command '{0}' for symbol store '{1}'", this.Command.ToString(), this.Store));
            CommandLineBuilder builder = new CommandLineBuilder();

            if (this.Command == SymStoreCommands.Query)
                builder.AppendSwitch("query");
            else if (this.Command == SymStoreCommands.Delete)
                builder.AppendSwitch("del");
            else if (this.Command == SymStoreCommands.Add)
                builder.AppendSwitch("add");
            else
            {
                System.Diagnostics.Debug.Assert(false, "Unknown symbol store publish command '" + this.Command + "'.");
            }

            if (this.Append)
                builder.AppendSwitch("/a");
            builder.AppendSwitchIfNotNull("/c ", this.Comment);
            if (this.Compress)
                builder.AppendSwitch("/compress");
            builder.AppendSwitchIfNotNull("/d ", this.LogFile);
            builder.AppendSwitchIfNotNull("/g ", this.Share);
            builder.AppendSwitchIfNotNull("/i ", this.TransactionId);
            if (this.Local)
                builder.AppendSwitch("/l");
            if (this.Verbose)
                builder.AppendSwitch("/o");
            if (this.Pointer)
                builder.AppendSwitch("/p");
            if (this.Recursive)
                builder.AppendSwitch("/r");
            builder.AppendSwitchIfNotNull("/s ", this.Store);
            builder.AppendSwitchIfNotNull("/t ", this.Product);
            builder.AppendSwitchIfNotNull("/v ", this.Version);

            builder.AppendSwitchIfNotNull("/x ", this.WriteIndex);
            builder.AppendSwitchIfNotNull("/y ", this.ReadIndex);

            builder.AppendSwitchIfNotNull("-:MSG ", this.Message);
            if (this.Relative)
                builder.AppendSwitch("-:REL");
            if (this.NoReference)
                builder.AppendSwitch("-:NOREFS");

            builder.AppendSwitchIfNotNull("/f ", this.Files);
            ProcessStartInfo info = new ProcessStartInfo(SymbolStoreTools.FullPathSymStore);
            info.UseShellExecute = false;
            info.RedirectStandardError = true;
            info.RedirectStandardOutput = true;
            info.Arguments = builder.ToString();

            string output;
            string errors;

            using (Process p = Process.Start(info))
            {
                output = p.StandardOutput.ReadToEnd();
                errors = p.StandardError.ReadToEnd();
                p.WaitForExit();
            }

            Program.Output.Write(OutputType.Verbose, IndentAction.IndentOnce, string.Format(CultureInfo.CurrentCulture, "Symbol store command result: {0}", output));

            if (!string.IsNullOrEmpty(errors))
            {
                throw new SymbolToolException(string.Format("Error executing the symstore.exe command. {0}", errors));
            }
        }

        #endregion
    }
}
