using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.IO;
using System.Reflection;

namespace LibraryConfigTool.Internal
{
    [Serializable]
    internal sealed class RegSvr32Step : IStep
    {
        public RegSvr32Step(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, Constants.RegSvr32Element, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            Program.Output.Write(OutputType.Info, "Performing DLL COM server registration....");
            Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:        '{0}'", _path));

            using(IndentedOutput indentedOutput = new IndentedOutput())
            {
                String path = rootConfigInfo.ReplaceAllVariables(_path);

                try
                {
                    if(!File.Exists(path))
                    {
                        using(BatchedOutput output = new BatchedOutput(false))
                        {
                            output.BeginWriteError(0, Strings.DLLCOMServerRegistrationFailedFileNotFound);
                            output.AddErrorDetail(Strings.Path, path);
                            output.EndWriteError();
                        }
                    }
                    else
                    {
                        using(IndentedOutput remoteIndentedOutput = new IndentedOutput())
                        {
                            AppDomainSetup appDomainSetup = new AppDomainSetup();
                            appDomainSetup.ApplicationBase = Path.GetDirectoryName(path);
                            AppDomain appDomain = AppDomain.CreateDomain("RemoteDllComServerRegistrar", null, appDomainSetup);
                            try
                            {
                                RemoteDllComServerRegistrar registrar = (RemoteDllComServerRegistrar) appDomain.CreateInstanceFromAndUnwrap(Assembly.GetExecutingAssembly().CodeBase, "LibraryConfigTool.Internal.RemoteDllComServerRegistrar");
                                registrar.RegisterDllComServer(Program.Output, path);
                            }
                            finally
                            {
                                AppDomain.Unload(appDomain);
                            }
                        }

                        Program.Output.Write(OutputType.Info, Strings.DLLCOMServerRegistrationSucceeded);
                        Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:        '{0}'", path));
                    }
                }
                catch(Exception ex)
                {
                    using(BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, Strings.DLLCOMServerRegistrationFailed);
                        output.AddErrorDetail(Strings.Path, path);
                        output.AddErrorDetail(Strings.Error, ex.ToString());
                        output.EndWriteError();
                    }
                }
            }
        }

        #endregion

        private String _path;
    }
}
