﻿using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Linq;

namespace LibraryConfigTool.Internal
{
    internal sealed class WXSTransformInstalledFilesToDirectoryStructureStep : IStep
    {
        public WXSTransformInstalledFilesToDirectoryStructureStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourceFile = Utils.GetRequiredAttribute(navigator, Constants.SourceFileAttribute, Constants.WXSTransformInstalledFilesToDirectoryStructureElement, configInfo.ConfigFile);
            _destinationFile = Utils.GetRequiredAttribute(navigator, Constants.DestinationFileAttribute, Constants.WXSTransformInstalledFilesToDirectoryStructureElement, configInfo.ConfigFile);
            _idFragment = Utils.GetRequiredAttribute(navigator, "IdFragment", Constants.WXSTransformInstalledFilesToDirectoryStructureElement, configInfo.ConfigFile);
            _rootDirectory = Utils.GetRequiredAttribute(navigator, "RootDirectory", Constants.WXSTransformInstalledFilesToDirectoryStructureElement, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_sourceFile), rootConfigInfo);
            String destinationFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_destinationFile), rootConfigInfo);
            String idFragment = rootConfigInfo.ReplaceAllVariables(_idFragment);
            String rootDirectory = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_rootDirectory), rootConfigInfo);

            _directoriesToProcess = new StringCollection();

            _componentsByDirectory = new SortedDictionary<String, List<ComponentFileInfo>>(new FilePathDepthComparer());
            List<ComponentFileInfo> targetDirComponentInfo = new List<ComponentFileInfo>();

            XmlDocument document = new XmlDocument();
            document.Load(sourceFile);

            XmlNodeList componentNodes = document.SelectNodes("//Component");
            foreach (XmlNode node in componentNodes)
            {
                String key = Path.GetDirectoryName(node.Attributes["SourceFile"].Value);
                Boolean placeInRootTargetDir = Boolean.Parse(node.Attributes["PlaceInRootTargetDir"].Value);
                if (!placeInRootTargetDir)
                {
                    if (!_componentsByDirectory.ContainsKey(key))
                    {
                        _componentsByDirectory.Add(key, new List<ComponentFileInfo>());
                    }

                    _componentsByDirectory[key].Add(new ComponentFileInfo(node.Attributes["SourceFile"].Value, node.Attributes["WxsFile"].Value));
                }
                else
                {
                    targetDirComponentInfo.Add(new ComponentFileInfo(node.Attributes["SourceFile"].Value, node.Attributes["WxsFile"].Value));
                }
            }

            XmlNodeList fileNodes = document.SelectNodes("//File");
            foreach (XmlNode node in fileNodes)
            {
                String key = Path.GetDirectoryName(node.Attributes["Path"].Value);
                if (!_componentsByDirectory.ContainsKey(key))
                {
                    _componentsByDirectory.Add(key, new List<ComponentFileInfo>());
                }

                _componentsByDirectory[key].Add(new ComponentFileInfo(node.Attributes["Path"].Value));
            }

            foreach (String directory in GetDirectoriesFullNames(rootDirectory))
            {
                _directoriesToProcess.Add(directory);
            }

            Utils.EnsureDirectoryExists(Path.GetDirectoryName(destinationFile));
            XmlTextWriter writer = new XmlTextWriter(destinationFile, Encoding.UTF8);
            writer.Formatting = Formatting.Indented;
            try
            {
                writer.WriteStartElement("Wix");
                writer.WriteAttributeString("xmlns", "http://schemas.microsoft.com/wix/2006/wi");
                writer.WriteStartElement("Fragment");

                writer.WriteStartElement("DirectoryRef");
                writer.WriteAttributeString("Id", "TARGETDIR");

                foreach (ComponentFileInfo componentFileInfo in targetDirComponentInfo)
                {
                    WriteIncludeElement(writer, componentFileInfo.WxsFilePath);
                }

                if (0 < _directoriesToProcess.Count)
                {
                    // process each directory
                    if (0 < _directoriesToProcess.Count)
                    {
                        foreach (string directory in _directoriesToProcess)
                        {
                            WriteDirectoryElement(writer, directory, true, idFragment);
                        }
                    }
                }

                // close up and go home
                writer.WriteEndElement(); // </DirectoryRef>
                writer.WriteEndElement(); // </Fragment>
                writer.WriteEndElement(); // </Wix>
            }
            finally
            {
                writer.Flush();
                writer.Close();
            }
        }


        #endregion



        /// <summary>
        /// Writes a Directory element to the writer.
        /// </summary>
        /// <param name="writer">Writer to output to.</param>
        /// <param name="path">Path to directory to write to XML</param>
        /// <param name="recurse">Recurse into sub directories</param>
        /// <param name="idFragment"></param>
        private void WriteDirectoryElement(XmlWriter writer, String path, Boolean recurse, String idFragment)
        {
            DirectoryInfo directory = new DirectoryInfo(path);
            if (!directory.Exists)
            {
                throw new Exception();//throw new WixFileNotFoundException(path, "Directory");
            }

            String directoryId = "PUT-DIRECTORY-ID-HERE";
            writer.WriteStartElement("Directory");
            writer.WriteAttributeString("Id", directoryId);
            writer.WriteAttributeString("Name", directory.Name);

            List<String> filePaths = new List<String>();
            if (_componentsByDirectory.ContainsKey(directory.FullName))
            {
                foreach(ComponentFileInfo componentInfo in _componentsByDirectory[directory.FullName])
                {
                    if (componentInfo.ComponentFileType == ComponentFileType.Component)
                    {
                        WriteIncludeElement(writer, componentInfo.WxsFilePath);
                    }

                    if (componentInfo.ComponentFileType == ComponentFileType.File)
                    {
                        filePaths.Add(componentInfo.SourceFilePath);
                    }
                }
            }

            // dump any files into a Component
            if (0 < filePaths.Count)
            {
                foreach (String filePath in filePaths)
                {
                    String idFragmentForFileName = Path.GetFileName(filePath);
                    StartComponentElement(writer, "PUT-COMPONENT-ID-HERE");
                    WriteFileElement(writer, filePath, "PUT-FILE-ID-HERE");
                    EndComponentElement(writer);
                }
            }

            if (recurse)
            {
                ReadOnlyCollection<String> directoryFullNames = GetDirectoriesFullNames(path);
                foreach (String directoryFullName in directoryFullNames)
                {
                    WriteDirectoryElement(writer, directoryFullName, recurse, idFragment);
                }
            }
            writer.WriteEndElement(); // </Directory>
        }

        /// <summary>
        /// Writes the beginning of a Component element to the writer.
        /// </summary>
        /// <param name="writer">Writer to output to.</param>
        /// <param name="id"></param>
        private void StartComponentElement(XmlWriter writer, String id)
        {
            writer.WriteStartElement("Component");
            writer.WriteAttributeString("Id", id);
            writer.WriteAttributeString("DiskId", "1");
            writer.WriteAttributeString("Guid", "PUT-GUID-HERE");
        }

        /// <summary>
        /// Writes a File element to the writer.
        /// </summary>
        /// <param name="writer">Writer to output to.</param>
        /// <param name="path">Path to file to write to XML.</param>
        /// <param name="id"></param>
        private void WriteFileElement(XmlWriter writer, String path, String id)
        {
            if (!File.Exists(path))
            {
                throw new Exception();// WixFileNotFoundException(path, "File");
            }

            String fileName = Path.GetFileName(path);
            writer.WriteStartElement("File");
            writer.WriteAttributeString("Id", id);
            writer.WriteAttributeString("Name", fileName);
            writer.WriteAttributeString("Source", Path.GetFullPath(path));
            writer.WriteEndElement(); // </File>
        }

        /// <summary>
        /// Writes the end of a Component element to the writer.
        /// </summary>
        /// <param name="writer">Writer to output to.</param>
        private void EndComponentElement(XmlWriter writer)
        {
            writer.WriteEndElement();
        }

        private void WriteIncludeElement(XmlWriter writer, String path)
        {
            writer.WriteProcessingInstruction("include", path);
        }

        private ReadOnlyCollection<String> GetDirectoriesFullNames(String directory)
        {
            List<String> result = new List<String>();

            String directoryToFind = directory + Path.DirectorySeparatorChar;
            foreach (String candidateDirectory in _componentsByDirectory.Keys)
            {
                if (candidateDirectory.StartsWith(directoryToFind))
                {
                    String directoryName = candidateDirectory.Substring(directoryToFind.Length);
                    if (directoryName.IndexOf(Path.DirectorySeparatorChar) != -1)
                    {
                        directoryName = directoryName.Substring(0, directoryName.IndexOf(Path.DirectorySeparatorChar));
                    }

                    String directoryFullNameToAdd = Path.Combine(directory, directoryName);
                    if (!result.Contains(directoryFullNameToAdd))
                    {
                        result.Add(directoryFullNameToAdd);
                    }
                }
            }

            result.Sort();
            return result.AsReadOnly();
        }

        private enum ComponentFileType
        {
            None = 0,
            Component,
            File
        }

        private class ComponentFileInfo
        {
            public ComponentFileInfo(String path)
            {
                _componentFileType = ComponentFileType.File;
                _sourceFilePath = path;
            }

            public ComponentFileInfo(String sourceFilePath, String wxsFilePath)
            {
                _componentFileType = ComponentFileType.Component;
                _sourceFilePath = sourceFilePath;
                _wxsFilePath = wxsFilePath;
            }

            public ComponentFileType ComponentFileType
            { get { return _componentFileType; } }

            public String SourceFilePath
            { get { return _sourceFilePath; } }

            public String WxsFilePath
            { get { return _wxsFilePath; } }

            private ComponentFileType _componentFileType;
            private String _sourceFilePath;
            private String _wxsFilePath;
        }

        private class FilePathDepthComparer : IComparer<String>
        {
            #region IComparer<string> Members

            public int Compare(string x, string y)
            {
                Int32 result = 0;

                Int32 xDepth = x.Split('\\').GetLength(0);
                Int32 yDepth = y.Split('\\').GetLength(0);

                if (xDepth != yDepth)
                {
                    result = (yDepth < xDepth) ? -1 : 1;
                }
                else
                {
                    result = String.Compare(x, y);
                }

                return result;
            }

            #endregion
        }

            /// <summary>
            /// Private class to do interop.
            /// </summary>
        private class NativeMethods
        {
            /// <summary>
            /// Gets the short name for a file.
            /// </summary>
            /// <param name="fullPath">Fullpath to file on disk.</param>
            /// <returns>Short name for file.</returns>
            internal static string GetShortPathName(string fullPath)
            {
                StringBuilder shortPath = new StringBuilder(MaxPath, MaxPath);

                // get the short file name
                GetShortPathName(fullPath, shortPath, MaxPath);

                // remove the tildes
                shortPath.Replace('~', '_');

                return shortPath.ToString();
            }

            /// <summary>
            /// Gets the short name for a file.
            /// </summary>
            /// <param name="longPath">Long path to convert to short path.</param>
            /// <param name="shortPath">Short path from long path.</param>
            /// <param name="buffer">Size of short path.</param>
            /// <returns>zero if success.</returns>
            [DllImport("kernel32.dll", EntryPoint = "GetShortPathNameW", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
            internal static extern uint GetShortPathName(string longPath, StringBuilder shortPath, [MarshalAs(UnmanagedType.U4)]int buffer);
        }
        
        private String _sourceFile;
        private String _destinationFile;
        private StringCollection _directoriesToProcess;
        private const Int32 MaxPath = 255;
        SortedDictionary<String, List<ComponentFileInfo>> _componentsByDirectory;
        private String _rootDirectory;
        private String _idFragment;
    }
}
