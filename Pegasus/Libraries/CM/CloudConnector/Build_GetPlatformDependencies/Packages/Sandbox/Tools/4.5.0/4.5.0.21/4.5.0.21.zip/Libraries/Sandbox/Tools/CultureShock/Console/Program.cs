using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Resources;
using System.Collections;
using System.IO;
using System.Xml.Linq;
using System.Globalization;

namespace CultureShock
{
    class Program
    {
        static private readonly string extResx = StringsNoTran.ResxExtensionDefault;
        static private readonly string extTranslated = StringsNoTran.ResxExtensionTranslated;
        static private readonly string extLocalized = StringsNoTran.ResxExtensionCultureSpecific;

        const bool ignoreKeySuffices = true;
        static private Dictionary<string, bool> keySuffices = new Dictionary<string, bool>();
        static private readonly string sageNamespacePrefix = StringsNoTran.SageMMSNamespace;

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1810:InitializeReferenceTypeStaticFieldsInline")]
        static Program()
        {
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_TabIndex.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Font.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Size.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Location.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Multiline.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_AutoScaleBaseSize.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ClientSize.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Type.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Parent.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ZOrder.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Dock.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_MinimumSize.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Anchor.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_AutoSize.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_TextAlign.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Padding.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_FlatStyle.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Image.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Visible.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_MaxLength.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_RightToLeft.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_OcxState.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ItemHeight.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Enabled.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ImageStream.ToLower(CultureInfo.CurrentUICulture), false);

            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ScrollBars.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_AutoScaleDimensions.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_CheckAlign.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_StartPosition.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_SizeMode.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Margin.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ImageAlign.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ImageScaling.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_BackgroundImageLayout.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Modifiers.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_DrawGrid.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_SnapToGrid.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ButtonImage.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Icon.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_AutoSizeMode.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_WordWrap.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ImeMode.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ColumnCount.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_LayoutSettings.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_RowCount.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ItemSize.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_SplitterDistance.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ImageDistance.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_TextImageResolution.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_SelectedImageIndex.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_MaximumSize.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ImageIndex.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_TextImageRelation.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Localizable.ToLower(CultureInfo.CurrentUICulture), false);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_TrayLocation.ToLower(CultureInfo.CurrentUICulture), false);

            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Text.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Name.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_PasswordChar.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Caption.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_TotalText.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ToolTip.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_ToolTipText.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items1.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items2.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items3.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items4.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items5.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items6.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items7.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items8.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items9.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items10.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_Items11.ToLower(CultureInfo.CurrentUICulture), true);

            keySuffices.Add(StringsNoTran.KeySuffixToSkip_MaxDropDownItems.ToLower(CultureInfo.CurrentUICulture), true);
            keySuffices.Add(StringsNoTran.KeySuffixToSkip_EmptyText.ToLower(CultureInfo.CurrentUICulture), true);
        }

        [STAThread]
        static int Main(string[] args)
        {
            if(args.Length < 1 || args[0].Length < 1)
            {
                Console.WriteLine(StringsCustomerFacing.Console_UsageCultureShockConsoleUsage_MessageInstruction);
                return -1;
            }

            LocalizeResxFiles(args[0]);
            AddToProjects(args[0]);
            Console.WriteLine(StringsCustomerFacing.Console_PressEnterToExit_MessageInstruction);
            Console.ReadLine();
            return 0;
        }

        static void LocalizeResxFiles(string folder)
        {
           foreach (FileInfo file in new DirectoryInfo(folder).GetFiles(StringsNoTran.Asterisk + extTranslated, SearchOption.AllDirectories))
           {
               string baseFileName = file.Directory + StringsNoTran.DirectoryDelimiter + file.Name.Substring(0, file.Name.Length - extTranslated.Length);
               string fileNameResx = baseFileName + extResx;
               string fileNameTranslated = baseFileName + extTranslated;
               string fileNameLocalized = baseFileName + extLocalized;
               if (File.Exists(fileNameResx))
               {
                   if (!File.Exists(fileNameLocalized))
                   {
                       bool localized = LocalizeResx(fileNameResx, fileNameTranslated, fileNameLocalized);
                       if (localized)
                       {
                           Console.WriteLine(StringsCustomerFacing.Console_ProcessedFile_Label, fileNameTranslated);
                       }
                   }
                   else
                   {
                       Console.WriteLine(String.Format(CultureInfo.CurrentUICulture, StringsCustomerFacing.Console_LocalizedFileExists_MessageInstruction, fileNameLocalized, fileNameTranslated));
                   }
               }
               else
               {
                   Console.WriteLine(String.Format(CultureInfo.CurrentUICulture, StringsCustomerFacing.Console_ResxFileDoesntExist_MessageInstruction, fileNameResx, fileNameTranslated));
               }
           }
        }

        static bool SkipKey(string key)
        {
            bool localizable = true;
            string keySuffix;
            if (ignoreKeySuffices)
            {
                int pos = key.LastIndexOf('.');
                if (pos >= 1)
                {
                    keySuffix = key.Substring(pos);
                    bool found = keySuffices.TryGetValue(keySuffix.ToLower(CultureInfo.CurrentUICulture), out localizable);
                    if (!found)
                    {
                        if (key.StartsWith(sageNamespacePrefix, StringComparison.Ordinal))
                        {
                            localizable = false;
                        }
                        else
                        {
                            localizable = true;
                            keySuffices.Add(keySuffix.ToLower(CultureInfo.CurrentUICulture), localizable);
                        }
                    }
                }
            }

            return !localizable;
        }

        static bool LocalizeResx(string sourceFileOrig, string sourceFileTranslated, string sourceFileLocalized)
        {
            ResXResourceReader readerOrig = new ResXResourceReader(sourceFileOrig);
            readerOrig.BasePath = Directory.GetParent(sourceFileOrig).FullName;
            Dictionary<string, string> stringsOrig = new Dictionary<string, string>();
            foreach (DictionaryEntry entry in readerOrig)
            {
                string key = (string) entry.Key;
                object value = entry.Value;
                if (key == StringsNoTran.LocalizeableFlagKeyName)
                {
                    if (value is bool && ((bool)value) == false)
                    {
                        Console.WriteLine(StringsCustomerFacing.Console_LocalizableFlagSetToFalse_MessageInstruction, sourceFileOrig);
                        return false;
                    }
                }
                else
                {
                    string stringValue = value as string;
                    if (stringValue != null)
                    {
                        if (!SkipKey(key))
                        {
                            stringsOrig.Add(key, stringValue);
                        }
                    }
                }
            }
            readerOrig.Close();

            ResXResourceReader readerTranslated = new ResXResourceReader(sourceFileTranslated);
            ResXResourceWriter writerLocalized = new ResXResourceWriter(sourceFileLocalized);
            foreach (DictionaryEntry entry in readerTranslated)
            {
                string key = (string) entry.Key;
                object value = entry.Value;
                string stringValue = value as string;
                if (stringValue != null)
                {
                    if (!SkipKey(key))
                    {
                        // Add anything that is not the same as the original, includig keys
                        // that aren't found in the original.            
                        if (!stringsOrig.ContainsKey(key) || stringsOrig[key] != stringValue)
                        {
                            writerLocalized.AddResource(key, (stringValue));
                        }
                    }
                }
            }
            readerTranslated.Close();
            writerLocalized.Generate();
            writerLocalized.Close();

            return true;
        }

        static void AddToProjects(string folder)
        {
            //Find all project files in this subdirectory
            string[] varPrjFiles = Directory.GetFiles(folder, StringsNoTran.Asterisk + StringsNoTran.ProjectFileExtension, SearchOption.AllDirectories);
            foreach (string strFile in varPrjFiles)
            {
                bool fSave = false;
                string prjFolder = strFile.Substring(0, strFile.LastIndexOf(StringsNoTran.DirectoryDelimiter, StringComparison.CurrentCulture)+1);
                //Find embedded resources in the project
                XDocument doc = XDocument.Load(strFile);
                IEnumerable<XElement> elems =
                    from elem in doc.Descendants()
                    where elem.Name.LocalName == StringsNoTran.EmbeddedResource
                    && elem.Attribute(StringsNoTran.Include).Value.EndsWith(StringsNoTran.ResxExtensionDefault, StringComparison.CurrentCulture)
                    //&& elem.Attribute(StringsNoTran.Include).Value.IndexOf(StringsNoTran.Dot, StringComparison.CurrentCulture) == (elem.Attribute(StringsNoTran.Include).Value.Length - StringsNoTran.ResxExtensionDefault.Length)  
                    select elem;

                foreach (XElement elem in elems) {
                    //Check if culture specific resource file is already embedded in the project file
                     string fileNameLocalized = elem.Attribute(StringsNoTran.Include).Value.Replace(StringsNoTran.ResxExtensionDefault, StringsNoTran.ResxExtensionCultureSpecific);
                     IEnumerable<XElement> cultureElems =
                        from cultureElem in doc.Descendants()
                        where cultureElem.Name.LocalName == StringsNoTran.EmbeddedResource
                        && cultureElem.Attribute(StringsNoTran.Include).Value == fileNameLocalized
                        select cultureElem;

                     if (File.Exists(prjFolder + StringsNoTran.DirectoryDelimiter + fileNameLocalized))
                     {
                         if (cultureElems.Count() == 0) 
                         {
                             //Add the culture specific resource file to the project
                             XElement newelem = new XElement(elem);
                             if
                             (
                                newelem.Attribute(StringsNoTran.Include).Value == StringsNoTran.StringsCustomerFacingResx + StringsNoTran.ResxExtensionDefault
                                || newelem.Attribute(StringsNoTran.Include).Value == StringsNoTran.StringsDiagnosticResx + StringsNoTran.ResxExtensionDefault
                                || newelem.Attribute(StringsNoTran.Include).Value == StringsNoTran.StringsNoTranResx + StringsNoTran.ResxExtensionDefault     
                             )
                             {
                                    //Clean these nodes to prevent visual studio from corrupting
                                    //the project file when the localized resource file is opened
                                    //in the designer
                                    newelem.RemoveNodes();
                             }
                             newelem.Attribute(StringsNoTran.Include).Value = fileNameLocalized;
                             elem.AddAfterSelf(newelem);
                             fSave = true;
                             Console.WriteLine(StringsCustomerFacing.Console_AddedFileToProject_Label, fileNameLocalized, prjFolder);
                         }
                         else if (cultureElems.Count() == 1)
                         {
                             XElement cultureElem = cultureElems.First();
                             if
                             (
                                (cultureElem.Nodes().Count() > 0) &&
                                (
                                cultureElem.Attribute(StringsNoTran.Include).Value == StringsNoTran.StringsCustomerFacingResx + StringsNoTran.ResxExtensionCultureSpecific
                                || cultureElem.Attribute(StringsNoTran.Include).Value == StringsNoTran.StringsDiagnosticResx + StringsNoTran.ResxExtensionCultureSpecific
                                || cultureElem.Attribute(StringsNoTran.Include).Value == StringsNoTran.StringsNoTranResx + StringsNoTran.ResxExtensionCultureSpecific                    
                                )
                             )
                             {
                                    //Repair nodes that may cause vs to corrupt the project file
                                    //These repairs should only happen if an older version of
                                    //CultureShock was run on the project
                                    cultureElem.RemoveNodes();
                                    fSave = true;
                                    Console.WriteLine(StringsCustomerFacing.AlteredEmbeddedResource, elem.Attribute(StringsNoTran.Include).Value, strFile);
                             }
                         }
                     }

                }

                if (fSave) {
                    doc.Save(strFile, SaveOptions.None);
                }
            }
        }
    
    }
}
