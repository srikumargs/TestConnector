﻿using System;
using System.IO;
using System.Threading;
using System.Text.RegularExpressions;

namespace CSProjCleaner.Internal
{
	internal enum EngineStopCondition
	{
		None = 0,
		CompletedNormally,
		UnexpectedErrorOccurred,
		Aborted,
		InvalidOperation
	}

	internal sealed class Engine
	{
		public Boolean IsRunning
		{
			get
			{
				Boolean result;

				lock (_syncRoot)
				{ result = _isRunning; }

				return result;
			}
		}

		public Boolean IsSuspended
		{
			get
			{
				Boolean result;

				lock (_syncRoot)
				{ result = _isSuspended; }

				return result;
			}
		}

		public UInt32 FailureCount
		{
			get
			{
				UInt32 result;

				lock (_syncRoot)
				{ result = _failureCount; }

				return result;
			}
		}

		public DateTime StartTime
		{
			get
			{
				DateTime result;

				lock (_syncRoot)
				{ result = _startTime; }

				return result;
			}
		}

		public DateTime EndTime
		{
			get
			{
				DateTime result;

				lock (_syncRoot)
				{ result = _endTime; }

				return result;
			}
		}

		public TimeSpan RunTime
		{
			get
			{
				TimeSpan result;

				lock (_syncRoot)
				{
					VerifyIsNotRunning();

					result = EndTime.Subtract(StartTime);
				}

				return result;
			}
		}

		public void Suspend()
		{
			lock (_syncRoot)
			{
				VerifyIsRunning();

				if (!IsSuspended)
				{
					_workerThreadNotSuspended.Reset();
					_isSuspended = true;
				}
			}
		}

		public void Resume()
		{
			lock (_syncRoot)
			{
				VerifyIsRunning();

				if (IsSuspended)
				{
					_workerThreadNotSuspended.Set();
					_isSuspended = false;
				}
			}
		}

		public void WaitUntilStopped()
		{
			VerifyIsRunning();

			_engineStoppedEvent.WaitOne();
		}

		public Exception LastException
		{
			get
			{
				Exception result;

				lock (_syncRoot)
				{ result = _lastException; }

				return result;
			}
		}

		public EngineStopCondition EngineStopCondition
		{
			get
			{
				EngineStopCondition result;

				lock (_syncRoot)
				{ result = _engineStopCondition; }

				return result;
			}
		}

		private ManualResetEvent WorkerThreadNotSuspendedEvent
		{
			get
			{
				ManualResetEvent result;

				lock (_syncRoot)
				{
					result = _workerThreadNotSuspended;
				}

				return result;
			}
		}

        private void IncrementFailureCount()
		{
			lock (_syncRoot)
			{
				_failureCount++;
			}
		}

		private void VerifyIsRunning()
		{
			if (!IsRunning)
			{
				throw new InvalidOperationException("Cannot call while engine is not running.");
			}
		}

		private void VerifyIsNotRunning()
		{
			if (IsRunning)
			{
				throw new InvalidOperationException("Cannot call while engine is running.");
			}
		}

		public void Start(IPromptUser promptUser, IEngineEventsSubscriber engineEventsSubscriber, EngineOptions engineOptions)
		{
			VerifyIsNotRunning();

			if (!_isRunning)
			{
				_promptUser = promptUser;
				_engineEventsSubscriber = engineEventsSubscriber;

				_engineStoppedEvent.Reset();
				_isRunning = true;
				_isSuspended = false;
				_workerThreadNotSuspended.Set();
				_failureCount = 0;
				_startTime = DateTime.Now;
				_endTime = DateTime.MinValue;
				_engineStopCondition = EngineStopCondition.None;

				if (_thread == null)
				{
					_thread = new Thread(ThreadFunction);
					_thread.IsBackground = true;
					_thread.Name = this.GetType().FullName;
					_thread.Start(engineOptions);
				}
			}
		}

		private void ThreadFunction(Object state)
		{
			lock (_syncRoot)
			{ _lastException = null; }

			try
			{
				EngineOptions options = (EngineOptions)state;

				foreach (String fileFolderSpecification in options.FileFolderSpecifications)
				{
					String path = Path.GetFullPath(fileFolderSpecification);
					if (File.Exists(path))
					{
						_filesProcessed++;
						try
						{
							CSProjFileProcessor processor = new CSProjFileProcessor(_engineEventsSubscriber, options.ProcessorOptions);
							UpdateCounts(processor.ProcessFile(path));
						}
						catch (Exception e)
						{
							// eat any exceptions occurring in the sub processing
							if (_engineEventsSubscriber != null)
							{
								_engineEventsSubscriber.OnWorkProgress(this, new WorkProgressEventArgs(WorkProgressCode.Error, String.Format("An error occurred while processing file: {0} ({1})", path, e.ToString())));
							}
						}
					}
					else if (Directory.Exists(path))
					{
						String[] fileNames = Directory.GetFiles(path, "*.csproj", options.Recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
						foreach (String fileName in fileNames)
						{
							if (Regex.IsMatch(fileName, @".*-Backup-[0-9]+-[0-9]+-[0-9]+-[0-9]+\.[0-9]+\.[0-9]+\.csproj"))
							{
								continue;
							}
							_filesProcessed++;
							try
							{
								CSProjFileProcessor processor = new CSProjFileProcessor(_engineEventsSubscriber, options.ProcessorOptions);
								UpdateCounts(processor.ProcessFile(fileName));
							}
							catch (Exception e)
							{
								// eat any exceptions occurring in the sub processing
								if (_engineEventsSubscriber != null)
								{
									_engineEventsSubscriber.OnWorkProgress(this, new WorkProgressEventArgs(WorkProgressCode.Error, String.Format("An error occurred while processing file: {0} ({1})", path, e.ToString())));
								}
							}
						}
					}
				}

				lock (_syncRoot)
				{ _engineStopCondition = EngineStopCondition.CompletedNormally; }
			}
			catch (ThreadAbortException)
			{
				lock (_syncRoot)
				{ _engineStopCondition = EngineStopCondition.Aborted; }
			}
			//catch (ArgumentNotProvidedException ex)
			//{
			//    lock (_syncRoot)
			//    {
			//        _engineStopCondition = EngineStopCondition.InvalidNonGuiModeOperation;
			//        _lastException = ex;
			//    }
			//}
			catch (Exception ex)
			{
				lock (_syncRoot)
				{
					_engineStopCondition = EngineStopCondition.UnexpectedErrorOccurred;
					_lastException = ex;
				}
			}
			finally
			{
				lock (_syncRoot)
				{
					_isRunning = false;
					_isSuspended = false;
					_endTime = DateTime.Now;
					_thread = null;
				}

				if (_engineEventsSubscriber != null)
				{
					_engineEventsSubscriber.OnStop();
				}
			}

			_engineStoppedEvent.Set();
		}

		//private void cleaner_AppendResult(object sender, WorkProgressEventArgs e)
		//{
		//    _workerThreadNotSuspended.WaitOne();

		//    if (e.Code == ResultCode.Fail)
		//    {
		//        _failureCount++;
		//    }
		//    _engineEventsSubscriber.OnWorkProgress(sender, e);
		//}


		private void UpdateCounts(ProcessResult processResult)
		{
			switch (processResult)
			{
				case ProcessResult.NoChangesNecessary:
					break;

				case ProcessResult.ChangesApplied:
					_filesUpdated++;
					break;

				case ProcessResult.Error:
					_filesWithErrors++;
					break;
			}
		}

		public UInt32 FilesProcessed
		{ get { return _filesProcessed; } }

		public UInt32 FilesUpdated
		{ get { return _filesUpdated; } }

		public UInt32 FilesWithErrors
		{ get { return _filesWithErrors; } }

		#region Private fields
		private readonly Object _syncRoot = new Object();
		private readonly ManualResetEvent _workerThreadNotSuspended = new ManualResetEvent(false);
		private readonly ManualResetEvent _engineStoppedEvent = new ManualResetEvent(false);
		private UInt32 _failureCount;
		private DateTime _startTime;
		private DateTime _endTime;
		private Boolean _isRunning;
		private Boolean _isSuspended;
		private Exception _lastException;
		private EngineStopCondition _engineStopCondition;
		private Thread _thread;
		private IPromptUser _promptUser;
		private IEngineEventsSubscriber _engineEventsSubscriber;
		private UInt32 _filesProcessed;
		private UInt32 _filesUpdated;
		private UInt32 _filesWithErrors;
		#endregion
	}
}