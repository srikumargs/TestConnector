﻿namespace UpdateBuildDefinition
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.label1 = new System.Windows.Forms.Label();
            this._tfsServerTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this._sourceDefinitioncomboBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this._workspaceReplaceRootTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this._tfsProjectComboBox = new System.Windows.Forms.ComboBox();
            this._UpdateBuildDefinitionButton = new System.Windows.Forms.Button();
            this._workspaceSearchRootComboBox = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // _tfsServerTextBox
            // 
            resources.ApplyResources(this._tfsServerTextBox, "_tfsServerTextBox");
            this._tfsServerTextBox.Name = "_tfsServerTextBox";
            this._tfsServerTextBox.Leave += new System.EventHandler(this._tfsServerTextBox_Leave);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // _sourceDefinitioncomboBox
            // 
            this._sourceDefinitioncomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._sourceDefinitioncomboBox.FormattingEnabled = true;
            resources.ApplyResources(this._sourceDefinitioncomboBox, "_sourceDefinitioncomboBox");
            this._sourceDefinitioncomboBox.Name = "_sourceDefinitioncomboBox";
            this._sourceDefinitioncomboBox.Sorted = true;
            this._sourceDefinitioncomboBox.Leave += new System.EventHandler(this._sourceDefinitioncomboBox_Leave);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // _workspaceReplaceRootTextBox
            // 
            resources.ApplyResources(this._workspaceReplaceRootTextBox, "_workspaceReplaceRootTextBox");
            this._workspaceReplaceRootTextBox.Name = "_workspaceReplaceRootTextBox";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // _tfsProjectComboBox
            // 
            this._tfsProjectComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._tfsProjectComboBox.FormattingEnabled = true;
            resources.ApplyResources(this._tfsProjectComboBox, "_tfsProjectComboBox");
            this._tfsProjectComboBox.Name = "_tfsProjectComboBox";
            this._tfsProjectComboBox.Sorted = true;
            this._tfsProjectComboBox.Leave += new System.EventHandler(this._tfsProjectComboBox_Leave);
            // 
            // _UpdateBuildDefinitionButton
            // 
            resources.ApplyResources(this._UpdateBuildDefinitionButton, "_UpdateBuildDefinitionButton");
            this._UpdateBuildDefinitionButton.Name = "_UpdateBuildDefinitionButton";
            this._UpdateBuildDefinitionButton.UseVisualStyleBackColor = true;
            this._UpdateBuildDefinitionButton.Click += new System.EventHandler(this._UpdateBuildDefinitionButton_Click);
            // 
            // _workspaceSearchRootComboBox
            // 
            this._workspaceSearchRootComboBox.FormattingEnabled = true;
            resources.ApplyResources(this._workspaceSearchRootComboBox, "_workspaceSearchRootComboBox");
            this._workspaceSearchRootComboBox.Name = "_workspaceSearchRootComboBox";
            this._workspaceSearchRootComboBox.Sorted = true;
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this._tfsProjectComboBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this._tfsServerTextBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this._sourceDefinitioncomboBox);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this._workspaceSearchRootComboBox);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this._workspaceReplaceRootTextBox);
            this.groupBox3.Controls.Add(this.label5);
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // MainForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this._UpdateBuildDefinitionButton);
            this.Name = "MainForm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox _tfsServerTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox _sourceDefinitioncomboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox _workspaceReplaceRootTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox _tfsProjectComboBox;
        private System.Windows.Forms.Button _UpdateBuildDefinitionButton;
        private System.Windows.Forms.ComboBox _workspaceSearchRootComboBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

