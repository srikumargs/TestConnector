#include "stdafx.h"
#include "resource.h"

#pragma pack(push)
#pragma pack(1)

struct LoadLibraryCode
{
	WCHAR m_szLibPath[_MAX_PATH + 1];

	//Save registers
	BYTE m_pushEAX;
	BYTE m_pushECX;
	BYTE m_pushEDX;

	//push m_szLibPath
	BYTE m_push;
	DWORD m_dwAddrLibPath; //Address of lib path in the target process

	//call LoadLibraryW
	BYTE m_call;
	DWORD m_dwRelAddrLoadLibraryW;
	BYTE m_popEDX;
	BYTE m_popECX;
	BYTE m_popEAX;
	BYTE m_jmp;
	DWORD_PTR m_dwRelAddr; //jump back to original address

	LoadLibraryCode(DWORD dwAddrToJump, DWORD dwRemoteAddrOfThis, LPCWSTR szDll)
	{
		::GetModuleFileNameW(NULL, m_szLibPath, _MAX_PATH + 1);
		lstrcpyW(::PathFindFileNameW(m_szLibPath), szDll);


		// save the registers
		m_pushEAX = 0x50; //               push        eax  
		m_pushECX = 0x51; //               push        ecx  
		m_pushEDX = 0x52; //               push        edx  
		m_push = 0x68;
		m_dwAddrLibPath = dwRemoteAddrOfThis;
		m_call = 0xE8;	  //			   call

		DWORD dwAddrLoadLibraryW = PtrToUlong(GetProcAddress(GetModuleHandle(L"kernel32.dll"), "LoadLibraryW"));
		m_dwRelAddrLoadLibraryW = dwAddrLoadLibraryW - (dwRemoteAddrOfThis + ((BYTE*)&m_dwRelAddrLoadLibraryW - (BYTE*)this) + sizeof(DWORD));

		m_popEDX = 0x5A;  //               pop         edx  
		m_popECX = 0x59;  //               pop         ecx  
		m_popEAX = 0x58;  //               pop         eax  
		m_jmp = 0xE9;     //			   jmp
		m_dwRelAddr = dwAddrToJump - (dwRemoteAddrOfThis + sizeof(LoadLibraryCode)) ;
	}

	DWORD GetRemoteCodeAddr(DWORD dwRemoteAddr)
	{
		return dwRemoteAddr + ((BYTE*)&m_pushEAX - (BYTE*)this);
	}
};

#pragma pack(pop)

bool ShowUsage();
void ShowErrorMessage(HRESULT hr);
HRESULT CreateProcessWithInject(LPCWSTR szDll, LPCWSTR szExe, LPCWSTR szArgs);

int wmain(int argc, WCHAR* argv[])
{
	if ((argc == 1) || ((argc == 2) && (lstrcmpi(argv[1], L"/?") == 0)))
	{
		ShowUsage();
		return E_INVALIDARG;
	}

	LPCWSTR szDllPath = argv[1];
	LPCWSTR szExePath = argv[2];
	LPCWSTR szArgs = NULL;

	if(argc == 4)
	{
		szArgs = argv[3];
	}

	HRESULT hr = CreateProcessWithInject(szDllPath, szExePath, szArgs);
	if (FAILED(hr))
	{
		ShowErrorMessage(hr);
	}

	return hr;
}

bool ShowUsage()
{
	bool bRet = false;

	HMODULE hMod = ::GetModuleHandle(NULL);

	//Load the usage text form the resource and show
	HRSRC hrsrc = ::FindResource(hMod, MAKEINTRESOURCE(IDR_USAGE), TEXT("Custom"));

	if (hrsrc)
	{
		HGLOBAL hglbl = ::LoadResource(hMod, hrsrc);

		if (hglbl)
		{
			LPVOID lpv = ::LockResource(hglbl);
			DWORD dwSize = SizeofResource(hMod, hrsrc);

			bRet = ::WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), lpv, dwSize, &dwSize, NULL) ? true : false;
		}
	}

	return bRet;
}

void ShowErrorMessage(HRESULT hr)
{
	DWORD dwSize;

	CHAR szErrorMessagePrefix[64];
	int nChars = LoadStringA(NULL, IDS_ERRORMESSAGE, szErrorMessagePrefix, sizeof(szErrorMessagePrefix)/sizeof(CHAR));

	HANDLE hStdErr = GetStdHandle(STD_OUTPUT_HANDLE);

	dwSize = nChars;
	::WriteFile(hStdErr, szErrorMessagePrefix, nChars, &dwSize, NULL);

	//Write the dll name
	DWORD dwFlags = FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS;
	LPSTR szMessage = NULL;

	dwSize = ::FormatMessageA(dwFlags, NULL, hr, 0, reinterpret_cast<LPSTR>(&szMessage), 0, NULL);

	if ((szMessage == NULL) || (dwSize == 0))
	{
		wsprintfA(szErrorMessagePrefix, "%hu ", hr);
		szMessage = szErrorMessagePrefix;
		::WriteFile(hStdErr, szMessage, dwSize, &dwSize, NULL);
	}
	else
	{
		::WriteFile(hStdErr, szMessage, dwSize, &dwSize, NULL);
		LocalFree(reinterpret_cast<HLOCAL>(szMessage));
	}
}

HRESULT CreateProcessWithInject(LPCWSTR szDll, LPCWSTR szExe, LPCWSTR szArgs)
{
	STARTUPINFO si = {0};
	si.cb = sizeof(STARTUPINFO);
	si.wShowWindow = SW_SHOWDEFAULT;

	PROCESS_INFORMATION pi = {0};

	HRESULT hr = S_OK;

	BOOL b = CreateProcess(szExe, const_cast<LPWSTR>(szArgs), NULL, NULL, FALSE, CREATE_SUSPENDED, NULL, NULL, &si, &pi);
	if (b)
	{
		//If the registration is required for the current user inject code to override the keys
		//if (bCurrentUser)
		//{
		CONTEXT ctxt = {0};
		ctxt.ContextFlags = CONTEXT_FULL;
		GetThreadContext(pi.hThread, &ctxt);

		LPVOID pvDestAddr = VirtualAllocEx(pi.hProcess, NULL, sizeof(LoadLibraryCode), MEM_COMMIT, PAGE_EXECUTE_READWRITE);

		DWORD dwDestAddr = PtrToUlong(pvDestAddr);
		LoadLibraryCode code(ctxt.Eip, dwDestAddr, szDll);

		WriteProcessMemory(pi.hProcess, pvDestAddr, &code, sizeof(LoadLibraryCode), NULL);

		ctxt.Eip = code.GetRemoteCodeAddr(dwDestAddr);
		SetThreadContext(pi.hThread, &ctxt);
		//}

		ResumeThread(pi.hThread);
		CloseHandle(pi.hThread);

		WaitForSingleObject(pi.hProcess, INFINITE);

		DWORD dwResult = 0;
		GetExitCodeProcess(pi.hProcess, &dwResult);

		hr = HRESULT_FROM_WIN32(dwResult);

		CloseHandle(pi.hProcess);
	}
	else
	{
		hr = HRESULT_FROM_WIN32(GetLastError());
	}

	return hr;
}