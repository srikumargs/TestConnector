﻿namespace Alias.Internal
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this._closeButton = new System.Windows.Forms.Button();
            this._rootFolderTextBox = new System.Windows.Forms.TextBox();
            this._imageList = new System.Windows.Forms.ImageList(this.components);
            this._toolTip = new System.Windows.Forms.ToolTip(this.components);
            this._mappingsPanel = new System.Windows.Forms.Panel();
            this._mappingsDataGridView = new System.Windows.Forms.DataGridView();
            this._nameAColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._nameBColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._mappingsToolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this._mappingsClearToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._mappingsScanToolStripSplitButton = new System.Windows.Forms.ToolStripSplitButton();
            this._scanForAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._scanForBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this._mappingsSaveAsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._mappingsSaveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._mappingsOpenToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._resultsPanel = new System.Windows.Forms.Panel();
            this._resultsDataGridView = new System.Windows.Forms.DataGridView();
            this._imageColumne = new System.Windows.Forms.DataGridViewImageColumn();
            this._descriptionColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ErrorData = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._resultsToolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this._resultsSaveAsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this._showingToolStripComboBox = new System.Windows.Forms.ToolStripComboBox();
            this._processingPanel = new System.Windows.Forms.Panel();
            this._testOnlyCheckBox = new System.Windows.Forms.CheckBox();
            this._directionComboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this._recursiveCheckBox = new System.Windows.Forms.CheckBox();
            this._rootFolderBrowseButton = new System.Windows.Forms.Button();
            this._processingToolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this._processToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this._processingInfoToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this._splitContainer = new System.Windows.Forms.SplitContainer();
            this._mappingsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._mappingsDataGridView)).BeginInit();
            this._mappingsToolStrip.SuspendLayout();
            this._resultsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._resultsDataGridView)).BeginInit();
            this._resultsToolStrip.SuspendLayout();
            this._processingPanel.SuspendLayout();
            this._processingToolStrip.SuspendLayout();
            this._splitContainer.Panel1.SuspendLayout();
            this._splitContainer.Panel2.SuspendLayout();
            this._splitContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // _closeButton
            // 
            resources.ApplyResources(this._closeButton, "_closeButton");
            this._closeButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._closeButton.Name = "_closeButton";
            this._closeButton.UseVisualStyleBackColor = true;
            this._closeButton.Click += new System.EventHandler(this._closeButton_Click);
            // 
            // _rootFolderTextBox
            // 
            resources.ApplyResources(this._rootFolderTextBox, "_rootFolderTextBox");
            this._rootFolderTextBox.Name = "_rootFolderTextBox";
            // 
            // _imageList
            // 
            this._imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("_imageList.ImageStream")));
            this._imageList.TransparentColor = System.Drawing.Color.Magenta;
            this._imageList.Images.SetKeyName(0, "Blank.bmp");
            this._imageList.Images.SetKeyName(1, "Critical.bmp");
            this._imageList.Images.SetKeyName(2, "OK.bmp");
            this._imageList.Images.SetKeyName(3, "Information.bmp");
            this._imageList.Images.SetKeyName(4, "CSProjFile.bmp");
            this._imageList.Images.SetKeyName(5, "Edit.bmp");
            // 
            // _mappingsPanel
            // 
            this._mappingsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._mappingsPanel.Controls.Add(this._mappingsDataGridView);
            this._mappingsPanel.Controls.Add(this._mappingsToolStrip);
            resources.ApplyResources(this._mappingsPanel, "_mappingsPanel");
            this._mappingsPanel.Name = "_mappingsPanel";
            // 
            // _mappingsDataGridView
            // 
            this._mappingsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this._mappingsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._mappingsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this._nameAColumn,
            this._nameBColumn});
            resources.ApplyResources(this._mappingsDataGridView, "_mappingsDataGridView");
            this._mappingsDataGridView.Name = "_mappingsDataGridView";
            this._mappingsDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this._mappingsDataGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this._mappingsDataGridView_CellEndEdit);
            // 
            // _nameAColumn
            // 
            this._nameAColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this._nameAColumn.FillWeight = 50F;
            resources.ApplyResources(this._nameAColumn, "_nameAColumn");
            this._nameAColumn.Name = "_nameAColumn";
            // 
            // _nameBColumn
            // 
            this._nameBColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this._nameBColumn.FillWeight = 50F;
            resources.ApplyResources(this._nameBColumn, "_nameBColumn");
            this._nameBColumn.Name = "_nameBColumn";
            // 
            // _mappingsToolStrip
            // 
            this._mappingsToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this._mappingsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel2,
            this._mappingsClearToolStripButton,
            this._mappingsScanToolStripSplitButton,
            this.toolStripSeparator1,
            this._mappingsSaveAsToolStripButton,
            this._mappingsSaveToolStripButton,
            this._mappingsOpenToolStripButton});
            resources.ApplyResources(this._mappingsToolStrip, "_mappingsToolStrip");
            this._mappingsToolStrip.Name = "_mappingsToolStrip";
            // 
            // toolStripLabel2
            // 
            resources.ApplyResources(this.toolStripLabel2, "toolStripLabel2");
            this.toolStripLabel2.Name = "toolStripLabel2";
            // 
            // _mappingsClearToolStripButton
            // 
            this._mappingsClearToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            resources.ApplyResources(this._mappingsClearToolStripButton, "_mappingsClearToolStripButton");
            this._mappingsClearToolStripButton.Name = "_mappingsClearToolStripButton";
            this._mappingsClearToolStripButton.Click += new System.EventHandler(this._mappingsNewToolStripButton_Click);
            // 
            // _mappingsScanToolStripSplitButton
            // 
            this._mappingsScanToolStripSplitButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this._mappingsScanToolStripSplitButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._mappingsScanToolStripSplitButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._scanForAToolStripMenuItem,
            this._scanForBToolStripMenuItem});
            resources.ApplyResources(this._mappingsScanToolStripSplitButton, "_mappingsScanToolStripSplitButton");
            this._mappingsScanToolStripSplitButton.Name = "_mappingsScanToolStripSplitButton";
            this._mappingsScanToolStripSplitButton.ButtonClick += new System.EventHandler(this._mappingsScanNameAToolStripButton_Click);
            // 
            // _scanForAToolStripMenuItem
            // 
            this._scanForAToolStripMenuItem.Name = "_scanForAToolStripMenuItem";
            resources.ApplyResources(this._scanForAToolStripMenuItem, "_scanForAToolStripMenuItem");
            this._scanForAToolStripMenuItem.Click += new System.EventHandler(this._mappingsScanNameAToolStripButton_Click);
            // 
            // _scanForBToolStripMenuItem
            // 
            this._scanForBToolStripMenuItem.Name = "_scanForBToolStripMenuItem";
            resources.ApplyResources(this._scanForBToolStripMenuItem, "_scanForBToolStripMenuItem");
            this._scanForBToolStripMenuItem.Click += new System.EventHandler(this._mappingsScanNameBToolStripButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            // 
            // _mappingsSaveAsToolStripButton
            // 
            this._mappingsSaveAsToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this._mappingsSaveAsToolStripButton.Image = global::Alias.Properties.Resources.Save;
            resources.ApplyResources(this._mappingsSaveAsToolStripButton, "_mappingsSaveAsToolStripButton");
            this._mappingsSaveAsToolStripButton.Name = "_mappingsSaveAsToolStripButton";
            this._mappingsSaveAsToolStripButton.Click += new System.EventHandler(this._mappingsSaveAsToolStripButton_Click);
            // 
            // _mappingsSaveToolStripButton
            // 
            this._mappingsSaveToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this._mappingsSaveToolStripButton.Image = global::Alias.Properties.Resources.Save;
            resources.ApplyResources(this._mappingsSaveToolStripButton, "_mappingsSaveToolStripButton");
            this._mappingsSaveToolStripButton.Name = "_mappingsSaveToolStripButton";
            this._mappingsSaveToolStripButton.Click += new System.EventHandler(this._mappingsSaveToolStripButton_Click);
            // 
            // _mappingsOpenToolStripButton
            // 
            this._mappingsOpenToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this._mappingsOpenToolStripButton.Image = global::Alias.Properties.Resources.Open;
            resources.ApplyResources(this._mappingsOpenToolStripButton, "_mappingsOpenToolStripButton");
            this._mappingsOpenToolStripButton.Name = "_mappingsOpenToolStripButton";
            this._mappingsOpenToolStripButton.Click += new System.EventHandler(this._mappingsOpenToolStripButton_Click);
            // 
            // _resultsPanel
            // 
            this._resultsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._resultsPanel.Controls.Add(this._resultsDataGridView);
            this._resultsPanel.Controls.Add(this._resultsToolStrip);
            resources.ApplyResources(this._resultsPanel, "_resultsPanel");
            this._resultsPanel.Name = "_resultsPanel";
            // 
            // _resultsDataGridView
            // 
            this._resultsDataGridView.AllowUserToAddRows = false;
            this._resultsDataGridView.AllowUserToDeleteRows = false;
            this._resultsDataGridView.AllowUserToResizeColumns = false;
            this._resultsDataGridView.AllowUserToResizeRows = false;
            this._resultsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this._resultsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._resultsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this._imageColumne,
            this._descriptionColumn,
            this.Column1,
            this.ErrorData});
            resources.ApplyResources(this._resultsDataGridView, "_resultsDataGridView");
            this._resultsDataGridView.Name = "_resultsDataGridView";
            this._resultsDataGridView.RowHeadersVisible = false;
            this._resultsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this._resultsDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this._resultsDataGridView_CellContentClick);
            // 
            // _imageColumne
            // 
            this._imageColumne.Frozen = true;
            resources.ApplyResources(this._imageColumne, "_imageColumne");
            this._imageColumne.Name = "_imageColumne";
            // 
            // _descriptionColumn
            // 
            this._descriptionColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._descriptionColumn.DefaultCellStyle = dataGridViewCellStyle2;
            resources.ApplyResources(this._descriptionColumn, "_descriptionColumn");
            this._descriptionColumn.Name = "_descriptionColumn";
            // 
            // Column1
            // 
            resources.ApplyResources(this.Column1, "Column1");
            this.Column1.Name = "Column1";
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column1.Text = "Click";
            this.Column1.UseColumnTextForButtonValue = true;
            // 
            // ErrorData
            // 
            resources.ApplyResources(this.ErrorData, "ErrorData");
            this.ErrorData.Name = "ErrorData";
            // 
            // _resultsToolStrip
            // 
            this._resultsToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this._resultsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this._resultsSaveAsToolStripButton,
            this.toolStripSeparator2,
            this.toolStripLabel4,
            this._showingToolStripComboBox});
            resources.ApplyResources(this._resultsToolStrip, "_resultsToolStrip");
            this._resultsToolStrip.Name = "_resultsToolStrip";
            // 
            // toolStripLabel1
            // 
            resources.ApplyResources(this.toolStripLabel1, "toolStripLabel1");
            this.toolStripLabel1.Name = "toolStripLabel1";
            // 
            // _resultsSaveAsToolStripButton
            // 
            this._resultsSaveAsToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this._resultsSaveAsToolStripButton.Image = global::Alias.Properties.Resources.Save;
            resources.ApplyResources(this._resultsSaveAsToolStripButton, "_resultsSaveAsToolStripButton");
            this._resultsSaveAsToolStripButton.Name = "_resultsSaveAsToolStripButton";
            this._resultsSaveAsToolStripButton.Click += new System.EventHandler(this._resultsSaveAsToolStripButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            resources.ApplyResources(this.toolStripSeparator2, "toolStripSeparator2");
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            resources.ApplyResources(this.toolStripLabel4, "toolStripLabel4");
            // 
            // _showingToolStripComboBox
            // 
            this._showingToolStripComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._showingToolStripComboBox.Items.AddRange(new object[] {
            resources.GetString("_showingToolStripComboBox.Items"),
            resources.GetString("_showingToolStripComboBox.Items1")});
            this._showingToolStripComboBox.Name = "_showingToolStripComboBox";
            resources.ApplyResources(this._showingToolStripComboBox, "_showingToolStripComboBox");
            this._showingToolStripComboBox.SelectedIndexChanged += new System.EventHandler(this._showingToolStripComboBox_SelectedIndexChanged);
            // 
            // _processingPanel
            // 
            resources.ApplyResources(this._processingPanel, "_processingPanel");
            this._processingPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._processingPanel.Controls.Add(this._testOnlyCheckBox);
            this._processingPanel.Controls.Add(this._directionComboBox);
            this._processingPanel.Controls.Add(this.label3);
            this._processingPanel.Controls.Add(this.label2);
            this._processingPanel.Controls.Add(this._recursiveCheckBox);
            this._processingPanel.Controls.Add(this._rootFolderBrowseButton);
            this._processingPanel.Controls.Add(this._processingToolStrip);
            this._processingPanel.Controls.Add(this._rootFolderTextBox);
            this._processingPanel.Name = "_processingPanel";
            // 
            // _testOnlyCheckBox
            // 
            resources.ApplyResources(this._testOnlyCheckBox, "_testOnlyCheckBox");
            this._testOnlyCheckBox.Name = "_testOnlyCheckBox";
            this._testOnlyCheckBox.UseVisualStyleBackColor = true;
            // 
            // _directionComboBox
            // 
            this._directionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._directionComboBox.FormattingEnabled = true;
            this._directionComboBox.Items.AddRange(new object[] {
            resources.GetString("_directionComboBox.Items"),
            resources.GetString("_directionComboBox.Items1")});
            resources.ApplyResources(this._directionComboBox, "_directionComboBox");
            this._directionComboBox.Name = "_directionComboBox";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // _recursiveCheckBox
            // 
            resources.ApplyResources(this._recursiveCheckBox, "_recursiveCheckBox");
            this._recursiveCheckBox.Checked = true;
            this._recursiveCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this._recursiveCheckBox.Name = "_recursiveCheckBox";
            this._recursiveCheckBox.UseVisualStyleBackColor = true;
            // 
            // _rootFolderBrowseButton
            // 
            resources.ApplyResources(this._rootFolderBrowseButton, "_rootFolderBrowseButton");
            this._rootFolderBrowseButton.Name = "_rootFolderBrowseButton";
            this._rootFolderBrowseButton.UseVisualStyleBackColor = true;
            this._rootFolderBrowseButton.Click += new System.EventHandler(this._rootFolderBrowseButton_Click);
            // 
            // _processingToolStrip
            // 
            this._processingToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this._processingToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel3,
            this._processToolStripButton,
            this.toolStripSeparator3,
            this._processingInfoToolStripLabel});
            resources.ApplyResources(this._processingToolStrip, "_processingToolStrip");
            this._processingToolStrip.Name = "_processingToolStrip";
            // 
            // toolStripLabel3
            // 
            resources.ApplyResources(this.toolStripLabel3, "toolStripLabel3");
            this.toolStripLabel3.Name = "toolStripLabel3";
            // 
            // _processToolStripButton
            // 
            this._processToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this._processToolStripButton.Image = global::Alias.Properties.Resources.Run;
            resources.ApplyResources(this._processToolStripButton, "_processToolStripButton");
            this._processToolStripButton.Name = "_processToolStripButton";
            this._processToolStripButton.Click += new System.EventHandler(this._processToolStripButton_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            resources.ApplyResources(this.toolStripSeparator3, "toolStripSeparator3");
            // 
            // _processingInfoToolStripLabel
            // 
            this._processingInfoToolStripLabel.Name = "_processingInfoToolStripLabel";
            resources.ApplyResources(this._processingInfoToolStripLabel, "_processingInfoToolStripLabel");
            // 
            // _splitContainer
            // 
            resources.ApplyResources(this._splitContainer, "_splitContainer");
            this._splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this._splitContainer.Name = "_splitContainer";
            // 
            // _splitContainer.Panel1
            // 
            this._splitContainer.Panel1.Controls.Add(this._mappingsPanel);
            // 
            // _splitContainer.Panel2
            // 
            this._splitContainer.Panel2.Controls.Add(this._resultsPanel);
            // 
            // MainForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._splitContainer);
            this.Controls.Add(this._processingPanel);
            this.Controls.Add(this._closeButton);
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this._mappingsPanel.ResumeLayout(false);
            this._mappingsPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this._mappingsDataGridView)).EndInit();
            this._mappingsToolStrip.ResumeLayout(false);
            this._mappingsToolStrip.PerformLayout();
            this._resultsPanel.ResumeLayout(false);
            this._resultsPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this._resultsDataGridView)).EndInit();
            this._resultsToolStrip.ResumeLayout(false);
            this._resultsToolStrip.PerformLayout();
            this._processingPanel.ResumeLayout(false);
            this._processingPanel.PerformLayout();
            this._processingToolStrip.ResumeLayout(false);
            this._processingToolStrip.PerformLayout();
            this._splitContainer.Panel1.ResumeLayout(false);
            this._splitContainer.Panel2.ResumeLayout(false);
            this._splitContainer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button _closeButton;
        private System.Windows.Forms.TextBox _rootFolderTextBox;
        private System.Windows.Forms.ImageList _imageList;
        private System.Windows.Forms.ToolTip _toolTip;
        private System.Windows.Forms.Panel _mappingsPanel;
        private System.Windows.Forms.DataGridView _mappingsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn _nameAColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn _nameBColumn;
        private System.Windows.Forms.ToolStrip _mappingsToolStrip;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripButton _mappingsSaveAsToolStripButton;
        private System.Windows.Forms.ToolStripButton _mappingsSaveToolStripButton;
        private System.Windows.Forms.ToolStripButton _mappingsOpenToolStripButton;
        private System.Windows.Forms.ToolStripButton _mappingsClearToolStripButton;
        private System.Windows.Forms.Panel _resultsPanel;
        private System.Windows.Forms.ToolStrip _resultsToolStrip;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton _resultsSaveAsToolStripButton;
        private System.Windows.Forms.DataGridView _resultsDataGridView;
        private System.Windows.Forms.DataGridViewImageColumn _imageColumne;
        private System.Windows.Forms.DataGridViewTextBoxColumn _descriptionColumn;
        private System.Windows.Forms.DataGridViewButtonColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ErrorData;
        private System.Windows.Forms.Panel _processingPanel;
        private System.Windows.Forms.CheckBox _recursiveCheckBox;
        private System.Windows.Forms.Button _rootFolderBrowseButton;
        private System.Windows.Forms.ToolStrip _processingToolStrip;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripButton _processToolStripButton;
        private System.Windows.Forms.CheckBox _testOnlyCheckBox;
        private System.Windows.Forms.ComboBox _directionComboBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripSplitButton _mappingsScanToolStripSplitButton;
        private System.Windows.Forms.ToolStripMenuItem _scanForAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _scanForBToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.SplitContainer _splitContainer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripComboBox _showingToolStripComboBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripLabel _processingInfoToolStripLabel;
    }
}