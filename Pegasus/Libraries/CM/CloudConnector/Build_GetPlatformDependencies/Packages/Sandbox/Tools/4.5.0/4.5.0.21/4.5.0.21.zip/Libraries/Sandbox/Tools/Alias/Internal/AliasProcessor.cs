using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Globalization;
using Microsoft.Build.BuildEngine;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Alias.Internal
{
    internal sealed class AliasProcessor
    {
        public AliasProcessor(AliasProcessorOptions options)
        {
            _options = options;
        }

        public event EventHandler<WorkProgressEventArgs> WorkProgress;

        public ProcessResult ProcessCSProjFile(IPromptUser promptUser, String filePath)
        {
            ProcessResult result = ProcessResult.Error;
            String newProjectFilePath = filePath;

            try
            {
                OnWorkProgress(WorkProgressCode.Info, String.Format("Processing '{0}' ...", filePath), FileCode.CSProj);

                String fileContents;
                RetryCancelFileReadAllText(promptUser, filePath, out fileContents);
                String newFileContents = fileContents;
                String oldAssemblyNameForThisFile = String.Empty;
                String newAssemblyNameForThisFile = String.Empty;
                foreach (String oldAssemblyName in _options.AssemblyNameMappings.Keys)
                {
                    String newAssemblyName = _options.AssemblyNameMappings[oldAssemblyName];
                    
                    // <AssemblyName>OldAssemblyName</AssemblyName>
                    if (RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*AssemblyName\\s*>\\s*){0}(\\s*</\\s*AssemblyName\\s*>)", oldAssemblyName), String.Format("$1{0}$2", newAssemblyName)))
                    {
                        // <DocumentationFile>OldAssemblyName.xml</DocumentationFile>
                        RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*DocumentationFile\\s*>\\s*){0}(.xml\\s*</\\s*DocumentationFile\\s*>)", oldAssemblyName), String.Format("$1{0}$2", newAssemblyName));

                        oldAssemblyNameForThisFile = oldAssemblyName;
                        newAssemblyNameForThisFile = newAssemblyName;
                    }
                    else
                    {
                        // <Reference Include="OldAssemblyName"/>
                        RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*Reference\\s+Include\\s*=\\s*\"){0}(\"\\s*/\\s*>)", oldAssemblyName), String.Format("$1{0}$2", newAssemblyName));

                        // <Reference Include="OldAssemblyName, Version=1.0.0.0, Culture=neutral, PublicKeyToken=3e78b2cabf12f868, processorArchitecture=MSIL" />
                        RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*Reference\\s+Include\\s*=\\s*\"){0}(,[^\"]+\"\\s*/\\s*>)", oldAssemblyName), String.Format("$1{0}$2", newAssemblyName));
                        
                        // <Reference Include="OldAssemblyName, Version=1.0.0.0, Culture=neutral, PublicKeyToken=3e78b2cabf12f868, processorArchitecture=MSIL">
                        // ...
                        // </Reference>
                        RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*Reference\\s+Include\\s*=\\s*\"){0}(,[^\"]+\"\\s*>)", oldAssemblyName), String.Format("$1{0}$2", newAssemblyName));

                        //<ProjectReference Include="..\OldAssemblyName\OldAssemblyName.csproj">
                        //  <Project>{A083D927-0575-4BEE-96C0-EBB8F618FC3A}</Project>
                        //  <Package>{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}</Package>
                        //  <Name>OldAssemblyName</Name>
                        //</ProjectReference>
                        RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*Name\\s*>[^<]*){1}(</\\s*Name>(<\\s*Package\\s*>{0}</\\s*Package\\s*>|<\\s*Project\\s*>{0}</\\s*Project\\s*>|\\s*)*</\\s*ProjectReference>)", AnyValidElementContents, oldAssemblyName), String.Format("$1{0}$2", newAssemblyName));
                        RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*ProjectReference\\s+Include\\s*=\\s*\"[^\"]*){0}\\\\{0}(\\.csproj\"\\s*>)", oldAssemblyName), String.Format("$1{0}\\{0}$2", newAssemblyName));

                        //<Reference Include="OldAssemblyName">
                        //  <Name>OldAssemblyName</Name>
                        //  <HintPath>$(SAGE_SANDBOX)\Assemblies\OldAssemblyName.dll</HintPath>
                        //  <Private>False</Private>
                        //  <SpecificVersion>False</SpecificVersion>
                        //</Reference>
                        RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*HintPath\\s*>[^<]*)\\\\{1}(\\.dll</\\s*HintPath>(<\\s*Name\\s*>{0}</\\s*Name\\s*>|<\\s*Private\\s*>{0}</\\s*Private\\s*>|<\\s*SpecificVersion\\s*>{0}</\\s*SpecificVersion\\s*>|\\s*)*</\\s*Reference>)", AnyValidElementContents, oldAssemblyName), String.Format("$1\\{0}$2", newAssemblyName));
                        RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*Name\\s*>[^<]*){1}(</\\s*Name>(<\\s*HintPath\\s*>{0}/\\s*HintPath\\s*>|<\\s*Private\\s*>{0}</\\s*Private\\s*>|<\\s*SpecificVersion\\s*>{0}</\\s*SpecificVersion\\s*>|\\s*)*</\\s*Reference>)", AnyValidElementContents, oldAssemblyName), String.Format("$1{0}$2", newAssemblyName));
                        RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*Reference\\s+Include\\s*=\\s*\"){0}(\"\\s*>)", oldAssemblyName), String.Format("$1{0}$2", newAssemblyName));
                    }
                }

                if (fileContents != newFileContents)
                {
                    String backupFileName = String.Format("{0}{1}", filePath.Substring(0, filePath.LastIndexOf('.')), String.Format("-AliasBackup-{0}.csproj", DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss")));
                    if (!_options.TestOnly)
                    {
                        RetryCancelFileMove(promptUser, filePath, backupFileName);
                    }
                    OnWorkProgress(WorkProgressCode.Success, String.Format("File backup saved to '{0}'", backupFileName));

                    if (!String.IsNullOrEmpty(newAssemblyNameForThisFile))
                    {
                        newProjectFilePath = Path.Combine(Path.GetDirectoryName(filePath), String.Format("{0}.csproj", newAssemblyNameForThisFile));
                    }
                    if (File.Exists(newProjectFilePath))
                    {
                        if (!_options.TestOnly)
                        {
                            RetryCancelFileSetAttributesReadWrite(promptUser, newProjectFilePath);
                        }
                    }
                    if (!_options.TestOnly)
                    {
                        RetryCancelFileWriteAllText(promptUser, newProjectFilePath, newFileContents);
                    }

                    if (filePath != newProjectFilePath)
                    {
                        OnWorkProgress(WorkProgressCode.Success, String.Format("Renamed file '{0}' to '{1}'", filePath, newProjectFilePath));
                        _options.UpdateFileName(filePath, newProjectFilePath);
                    }

                    OnWorkProgress(WorkProgressCode.Success, String.Format("Saved '{0}'", newProjectFilePath));

                    if (!String.IsNullOrEmpty(newAssemblyNameForThisFile))
                    {
                        // do not rename the parent folder if there is more than one CSPROJ file in it ... because they will likely both try
                        // to rename it when they get renamed
                        String[] siblingProjectFileNames = Directory.GetFiles(Directory.GetParent(filePath).FullName, "*.csproj", SearchOption.TopDirectoryOnly);
                        List<String> nonBackupSiblingProjectFileNames = new List<string>();
                        foreach (String fileName in siblingProjectFileNames)
                        {
                            if (!fileName.Contains("AliasBackup"))
                            {
                                nonBackupSiblingProjectFileNames.Add(fileName);
                            }
                        }

                        String newFolderPath = Path.Combine(Directory.GetParent(Directory.GetParent(filePath).FullName).FullName, newAssemblyNameForThisFile);
                        if (nonBackupSiblingProjectFileNames.Count == 1)
                        {
                            newProjectFilePath = Path.Combine(newFolderPath, Path.GetFileName(newProjectFilePath));
                            if (!Directory.Exists(newFolderPath))
                            {
                                try
                                {
                                    if (!_options.TestOnly)
                                    {
                                        RetryCancelDirectoryMove(promptUser, Path.GetDirectoryName(filePath), newFolderPath);
                                    }

                                    OnWorkProgress(WorkProgressCode.Success, String.Format("Renamed folder '{0}' to '{1}'", Path.GetDirectoryName(filePath), newFolderPath));
                                }
                                catch (System.IO.IOException ex)
                                {
                                    // If Star Team is open Directory.Move will throw an IOException... catch the exception and report the error.
                                    OnWorkProgress(WorkProgressCode.Fail, String.Format("Unable to rename '{0}' to '{1}'", Path.GetDirectoryName(filePath), newFolderPath));
                                    throw;
                                }
                            }
                            else
                            {
                                OnWorkProgress(WorkProgressCode.Fail, String.Format("Unable to rename '{0}' to '{1}' because the destination folder already exists.", Path.GetDirectoryName(filePath), newFolderPath));
                            }
                        }
                        else
                        {
                            OnWorkProgress(WorkProgressCode.Fail, String.Format("Unable to rename '{0}' to '{1}' because source folder contains more than one .csproj file.", Path.GetDirectoryName(filePath), newFolderPath));
                        }
                    }

                    if (!String.IsNullOrEmpty(oldAssemblyNameForThisFile))
                    {
                        _options.AssociateAssemblyNameToOriginalProjectFileName(oldAssemblyNameForThisFile, filePath);
                    }

                    result = ProcessResult.ChangesApplied;
                }
                else
                {
                    result = ProcessResult.NoChangesNecessary;
                }
            }
            catch (System.IO.IOException)
            {
                result = ProcessResult.Error;
            }

            return result;
        }

        private String AnyValidElementContents
        {
            get { return "[\\w\\s.$\\(\\)-_\\\\}{]*"; }
        }

        public ProcessResult ProcessLibraryConfigFile(IPromptUser promptUser, String filePath)
        {
            ProcessResult result = ProcessResult.Error;

            try
            {
                OnWorkProgress(WorkProgressCode.Info, String.Format("Processing '{0}' ...", filePath), FileCode.LibraryConfig);

                String fileContents;
                RetryCancelFileReadAllText(promptUser, filePath, out fileContents);

                String newFileContents = fileContents;
                String newAssemblyNameForThisFile = String.Empty;
                foreach (String oldAssemblyName in _options.AssemblyNameMappings.Keys)
                {
                    String newAssemblyName = _options.AssemblyNameMappings[oldAssemblyName];

                    // <Target Name="OldAssemblyName">
                    //   ...
                    // </Target>
                    RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*Target\\s+Name\\s*=\\s*\"){0}(\"\\s*>)", oldAssemblyName), String.Format("$1{0}$2", newAssemblyName));

                    // <Target Name="OldAssemblyName"/>
                    RegexReplace(ref newFileContents, String.Format("(\\s*<\\s*Target\\s+Name\\s*=\\s*\"){0}(\"\\s*/\\s*>)", oldAssemblyName), String.Format("$1{0}$2", newAssemblyName));

                    // "<stuff>\OldAssemblyName[.dll | .exe | .dll.config | .exe.config | .resources.dll | .XmlSerializers.dll]"
                    RegexReplace(ref newFileContents, String.Format("([^\"]*\"[^\"]*\\\\){0}(\\.((dll)|(exe)|(dll.config)|(exe.config)|(resources.dll)|(XmlSerializers.dll))\")", oldAssemblyName), String.Format("$1{0}$2", newAssemblyName));
                }

                if (fileContents != newFileContents)
                {
                    String backupFileName = String.Format("{0}{1}", filePath.Substring(0, filePath.LastIndexOf('.')), String.Format("-AliasBackup-{0}.xml", DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss")));
                    if (!_options.TestOnly)
                    {
                        RetryCancelFileCopy(promptUser, filePath, backupFileName);
                    }
                    OnWorkProgress(WorkProgressCode.Success, String.Format("File backup saved to '{0}'", backupFileName));

                    if (!_options.TestOnly)
                    {
                        RetryCancelFileSetAttributesReadWrite(promptUser, filePath);
                        RetryCancelFileWriteAllText(promptUser, filePath, newFileContents);
                    }
                    OnWorkProgress(WorkProgressCode.Success, String.Format("Saved '{0}'", filePath));

                    result = ProcessResult.ChangesApplied;
                }
                else
                {
                    result = ProcessResult.NoChangesNecessary;
                }
            }
            catch (System.IO.IOException)
            {
                result = ProcessResult.Error;
            }

            return result;
        }

        public ProcessResult ProcessSolutionFile(IPromptUser promptUser, String filePath)
        {
            ProcessResult result = ProcessResult.Error;

            try
            {
                OnWorkProgress(WorkProgressCode.Info, String.Format("Processing '{0}' ...", filePath), FileCode.Solution);

                String fileContents;
                RetryCancelFileReadAllText(promptUser, filePath, out fileContents);

                String newFileContents = fileContents;
                String newAssemblyNameForThisFile = String.Empty;
                foreach (String oldAssemblyName in _options.AssemblyNameMappings.Keys)
                {
                    String newAssemblyName = _options.AssemblyNameMappings[oldAssemblyName];

                    Match match = Regex.Match(newFileContents, String.Format("(Project\\([^\\s]*\\)[^\"]*\"){0}(\"\\s*,\\s*\")([^\"]*)(\".*)", oldAssemblyName), RegexOptions.IgnoreCase);
                    if (match.Success)
                    {
                        ReadOnlyCollection<String> originalCSProjectFileNames = _options.GetOriginalProjectFileNamesForAssemblyName(oldAssemblyName);
                        if (originalCSProjectFileNames != null && originalCSProjectFileNames.Count > 0)
                        {
                            if (originalCSProjectFileNames.Count == 1)
                            {
                                String oldFileName = originalCSProjectFileNames[0];
                                String newFileName = _options.FileNameMappings[oldFileName];

                                String oldProjectPath = match.Groups[3].Value;
                                String[] splitOldProjectPath = oldProjectPath.Split('\\');
                                String newProjectPath = String.Empty;
                                String[] splitOldFileName = oldFileName.Split('\\');
                                String[] splitNewFileName = newFileName.Split('\\');
                                for (Int32 i = 0; i < splitOldProjectPath.GetLength(0); i++)
                                {
                                    if (0 == String.Compare(splitOldProjectPath[splitOldProjectPath.GetLength(0) - i - 1], splitOldFileName[splitOldFileName.GetLength(0) - i - 1], true))
                                    {
                                        newProjectPath = String.Format("{0}\\{1}", splitNewFileName[splitNewFileName.GetLength(0) - i - 1], newProjectPath);
                                    }
                                    else
                                    {
                                        String remainder = String.Empty;
                                        for (Int32 j = i; j < splitOldProjectPath.GetLength(0); j++)
                                        {
                                            remainder = String.Format("{0}\\{1}", splitOldProjectPath[splitOldProjectPath.GetLength(0) - i - 1], remainder);
                                        }
                                        newProjectPath = String.Format("{0}\\{1}", remainder, newProjectPath);
                                    }
                                }

                                newProjectPath = newProjectPath.TrimEnd('\\');

                                RegexReplace(ref newFileContents, String.Format("(Project\\([^\\s]*\\)[^\"]*\"){0}(\"\\s*,\\s*\")([^\"]*)(\".*)", oldAssemblyName), String.Format("$1{0}$2{1}$4", newAssemblyName, newProjectPath));
                            }
                            else
                            {
                                // TODO:  we may have more than one entry ... find most appropriate one
                                OnWorkProgress(WorkProgressCode.Fail, String.Format("Unable to update reference to '{0}' project in '{1}' because original assembly name has more than one project file associated with it.", oldAssemblyName, filePath));
                            }
                        }
                        else
                        {
                            RegexReplace(ref newFileContents, String.Format("(Project\\([^\\s]*\\)[^\"]*\"){0}(\"\\s*,\\s*\")([^\"]*)(\".*)", oldAssemblyName), String.Format("$1{0}$2$3$4", newAssemblyName));
                        }
                    }
                }

                if (fileContents != newFileContents)
                {
                    String backupFileName = String.Format("{0}{1}", filePath.Substring(0, filePath.LastIndexOf('.')), String.Format("-AliasBackup-{0}.sln", DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss")));
                    if (!_options.TestOnly)
                    {
                        RetryCancelFileCopy(promptUser, filePath, backupFileName);
                    }
                    OnWorkProgress(WorkProgressCode.Success, String.Format("File backup saved to '{0}'", backupFileName));

                    if (!_options.TestOnly)
                    {
                        RetryCancelFileSetAttributesReadWrite(promptUser, filePath);
                        RetryCancelFileWriteAllText(promptUser, filePath, newFileContents);
                    }
                    OnWorkProgress(WorkProgressCode.Success, String.Format("Saved '{0}'", filePath));

                    result = ProcessResult.ChangesApplied;
                }
                else
                {
                    result = ProcessResult.NoChangesNecessary;
                }
            }
            catch (System.IO.IOException)
            {
                result = ProcessResult.Error;
            }

            return result;
        }

        public ProcessResult ProcessFinalBuilderFile(IPromptUser promptUser, String filePath)
        {
            ProcessResult result = ProcessResult.Error;

            try
            {
                OnWorkProgress(WorkProgressCode.Info, String.Format("Processing '{0}' ...", filePath), FileCode.FinalBuilder);

                String fileContents;
                RetryCancelFileReadAllText(promptUser, filePath, out fileContents);

                String newFileContents = fileContents;
                String newAssemblyNameForThisFile = String.Empty;
                foreach (KeyValuePair<String, String> pair in _options.FileNameMappings)
                {
                    String originalFileName = pair.Key;
                    String newFileName = pair.Value;

                    if (String.Compare(originalFileName, newFileName, true) != 0)
                    {
                        String regex = originalFileName;
                        regex = regex.Replace(@"\", @"\\");
                        regex = regex.Replace(@".", @"\.");
                        regex = regex.Replace(@"(", @"\(");
                        regex = regex.Replace(@")", @"\)");
                        regex = regex.Replace(@"$", @"\$");
                        RegexReplace(ref newFileContents, regex, newFileName);

                        if (originalFileName.StartsWith(SandboxDir))
                        {
                            regex = "$(SAGE_SANDBOX)" + originalFileName.Substring(SandboxDir.Length);
                            regex = regex.Replace(@"\", @"\\");
                            regex = regex.Replace(@".", @"\.");
                            regex = regex.Replace(@"(", @"\(");
                            regex = regex.Replace(@")", @"\)");
                            regex = regex.Replace(@"$", @"\$");
                            RegexReplace(ref newFileContents, regex, String.Format("$(SAGE_SANDBOX){0}", newFileName.Substring(SandboxDir.Length)));

                            regex = "%SAGE_SANDBOX%" + originalFileName.Substring(SandboxDir.Length);
                            regex = regex.Replace(@"\", @"\\");
                            regex = regex.Replace(@".", @"\.");
                            regex = regex.Replace(@"(", @"\(");
                            regex = regex.Replace(@")", @"\)");
                            regex = regex.Replace(@"$", @"\$");
                            RegexReplace(ref newFileContents, regex, String.Format("%SAGE_SANDBOX%{0}", newFileName.Substring(SandboxDir.Length)));
                        }
                    }
                }

                if (fileContents != newFileContents)
                {
                    String backupFileName = String.Format("{0}{1}", filePath.Substring(0, filePath.LastIndexOf('.')), String.Format("-AliasBackup-{0}.fbp7", DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss")));
                    if (!_options.TestOnly)
                    {
                        RetryCancelFileCopy(promptUser, filePath, backupFileName);
                    }
                    OnWorkProgress(WorkProgressCode.Success, String.Format("File backup saved to '{0}'", backupFileName));

                    if (!_options.TestOnly)
                    {
                        RetryCancelFileSetAttributesReadWrite(promptUser, filePath);
                        RetryCancelFileWriteAllText(promptUser, filePath, newFileContents);
                    }
                    OnWorkProgress(WorkProgressCode.Success, String.Format("Saved '{0}'", filePath));

                    result = ProcessResult.ChangesApplied;
                }
                else
                {
                    result = ProcessResult.NoChangesNecessary;
                }
            }
            catch (System.IO.IOException)
            {
                result = ProcessResult.Error;
            }

            return result;
        }
        
        private Boolean RegexReplace(ref String value, String searchExpression, String replaceExpression)
        {
            Boolean result = false;
            Match match = Regex.Match(value, searchExpression, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                value = Regex.Replace(value, searchExpression, replaceExpression, RegexOptions.IgnoreCase);
                String replaceResult = replaceExpression;
                for (Int32 i = 0; i < match.Groups.Count; i++)
                {
                    replaceResult = replaceResult.Replace(String.Format("${0}", i), match.Groups[i].Value);
                }
                OnWorkProgress(WorkProgressCode.Success, String.Format("Replaced '{0}' with '{1}'", match.Value.Trim(), replaceResult.Trim()));
                result = true;
            }

            return result;
        }

        private String SandboxDir
        { get { return Environment.GetEnvironmentVariable("SAGE_SANDBOX"); } }

        private String GetMSBuildAssemblyDirPath(String fileName)
        { return String.Format(CultureInfo.InvariantCulture, @"$(SAGE_SANDBOX)\Assemblies\{0}", fileName); }

        private String GetAssemblyDirPath(String fileName)
        { return String.Format(CultureInfo.InvariantCulture, @"{0}\Assemblies\{1}", SandboxDir, fileName); }

        private String GetMSBuildBuildFilesDirPath(String fileName)
        { return String.Format(CultureInfo.InvariantCulture, @"$(SAGE_SANDBOX)\Build Files\{0}", fileName); }

        private void DebugWriteLine(String value)
        {
            if (_options.Debug)
            {
                Debug.WriteLine(value);
            }
        }

        private void OnWorkProgress(WorkProgressCode resultCode, String description)
        {
            if (WorkProgress != null)
            {
                WorkProgress(this, new WorkProgressEventArgs(resultCode, String.Format("{0}{1}", _options.TestOnly ? "[TEST] " : String.Empty, description)));
            }
        }

        private void OnWorkProgress(WorkProgressCode resultCode, String description, FileCode fileCode)
        {
            if (WorkProgress != null)
            {
                WorkProgress(this, new WorkProgressEventArgs(resultCode, String.Format("{0}{1}", _options.TestOnly ? "[TEST] " : String.Empty, description), fileCode));
            }
        }

        private void OnWorkProgress(WorkProgressCode resultCode, String description, String details)
        {
            if (WorkProgress != null)
            {
                WorkProgress(this, new WorkProgressEventArgs(resultCode, String.Format("{0}{1}", _options.TestOnly ? "[TEST] " : String.Empty, description), details));
            }
        }

        private DialogResult RetryCancelFileMove(IPromptUser promptUser, String oldPath, String newPath)
        {
            DialogResult result = DialogResult.None;
            do
            {
                try
                {
                    File.Move(oldPath, newPath);
                    result = DialogResult.OK;
                }
                catch (Exception ex)
                {
                    result = promptUser.RetryCancel(String.Format("An error was encounterred attempting to move '{0}' to '{1}'.\n\nMessage: {2}", oldPath, newPath, ex.Message), "Error During File Move");
                    if (result != DialogResult.Retry)
                    {
                        throw;
                    }
                }
            } while (result == DialogResult.Retry);

            return result;
        }

        private DialogResult RetryCancelDirectoryMove(IPromptUser promptUser, String oldPath, String newPath)
        {
            DialogResult result = DialogResult.None;
            do
            {
                try
                {
                    Directory.Move(oldPath, newPath);
                    _options.UpdateFolderLocation(oldPath, newPath);
                    result = DialogResult.OK;
                }
                catch (Exception ex)
                {
                    result = promptUser.RetryCancel(String.Format("An error was encounterred attempting to move '{0}' to '{1}'.\n\nMessage: {2}", oldPath, newPath, ex.Message), "Error During Directory Move");
                    if (result != DialogResult.Retry)
                    {
                        throw;
                    }
                }
            } while (result == DialogResult.Retry);

            return result;
        }

        private DialogResult RetryCancelFileWriteAllText(IPromptUser promptUser, String path, String contents)
        {
            DialogResult result = DialogResult.None;
            do
            {
                try
                {
                    File.WriteAllText(path, contents);
                    result = DialogResult.OK;
                }
                catch (Exception ex)
                {
                    result = promptUser.RetryCancel(String.Format("An error was encounterred attempting to write '{0}'.\n\nMessage: {1}", path, ex.Message), "Error During File Write");
                    if (result != DialogResult.Retry)
                    {
                        throw;
                    }
                }
            } while (result == DialogResult.Retry);

            return result;
        }

        private DialogResult RetryCancelFileReadAllText(IPromptUser promptUser, String path, out String contents)
        {
            DialogResult result = DialogResult.None;
            contents = String.Empty;
            do
            {
                try
                {
                    contents = File.ReadAllText(path);
                    result = DialogResult.OK;
                }
                catch (Exception ex)
                {
                    result = promptUser.RetryCancel(String.Format("An error was encounterred attempting to read '{0}'.\n\nMessage: {1}", path, ex.Message), "Error During File Read");
                    if (result != DialogResult.Retry)
                    {
                        throw;
                    }
                }
            } while (result == DialogResult.Retry);

            return result;
        }

        private DialogResult RetryCancelFileCopy(IPromptUser promptUser, String oldPath, String newPath)
        {
            DialogResult result = DialogResult.None;
            do
            {
                try
                {
                    File.Copy(oldPath, newPath);
                    result = DialogResult.OK;
                }
                catch (Exception ex)
                {
                    result = promptUser.RetryCancel(String.Format("An error was encounterred attempting to copy '{0}' to '{1}'.\n\nMessage: {2}", oldPath, newPath, ex.Message), "Error During File Copy");
                    if (result != DialogResult.Retry)
                    {
                        throw;
                    }
                }
            } while (result == DialogResult.Retry);

            return result;
        }

        private DialogResult RetryCancelFileSetAttributesReadWrite(IPromptUser promptUser, String path)
        {
            DialogResult result = DialogResult.None;
            do
            {
                try
                {
                    File.SetAttributes(path, (File.GetAttributes(path) & ~FileAttributes.ReadOnly));
                    result = DialogResult.OK;
                }
                catch (Exception ex)
                {
                    result = promptUser.RetryCancel(String.Format("An error was encounterred attempting to set '{0}' to read/write.\n\nMessage: {1}", path, ex.Message), "Error During Set File Read/Write");
                    if (result != DialogResult.Retry)
                    {
                        throw;
                    }
                }
            } while (result == DialogResult.Retry);

            return result;
        }

        private AliasProcessorOptions _options;
    }
}
