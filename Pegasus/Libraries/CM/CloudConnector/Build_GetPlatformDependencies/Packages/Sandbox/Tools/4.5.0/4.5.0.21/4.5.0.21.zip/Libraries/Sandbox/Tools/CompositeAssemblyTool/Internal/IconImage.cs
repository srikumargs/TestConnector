using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace CompositeAssemblyTool.Internal
{
    /// <summary>
    /// The IconImage class represents a single image in an IconResource.
    /// </summary>
    internal sealed class IconImage
    {
        #region Constructors
        /// <summary>
        /// Creates a new IconImage object to represent a RT_ICON resource.
        /// </summary>
        /// <param name="library">The library that contains the resource.</param>
        /// <param name="resourceName">The name of the resource.</param>
        unsafe public IconImage(Library library, IntPtr resourceName)
        {
            // Find the resource with the given name.
            IntPtr iconInfo = library.FindResource(resourceName, NativeMethods.RT_ICON);

            // Load the resource and get the resource bits.
            IntPtr iconResource = library.LoadResource(iconInfo);
            IntPtr dibBits = Library.LockResource(iconResource);

            // We make a local copy of the DIB bits as pDibBits may be 
            // freed when the module is unloaded.
            _dibBits = new Byte[library.SizeofResource(iconInfo)];
            Marshal.Copy(dibBits, _dibBits, 0, _dibBits.Length);

            fixed (Byte* bytes = &_dibBits[0])
            {
                NativeMethods.BITMAPINFO* bitmapInfo = (NativeMethods.BITMAPINFO*)bytes;

                // The header height value is the combined height of XOR and AND masks.
                // So we simply divide by two to get the image height.
                _height = bitmapInfo->bmiHeader.biHeight / 2;

                _width = bitmapInfo->bmiHeader.biWidth;
                _colors = bitmapInfo->bmiHeader.biPlanes * bitmapInfo->bmiHeader.biBitCount;
            }
        }
        #endregion

        #region Public properties
        /// <summary>
        /// Gets the size of the icon image.
        /// </summary>
        public int Size
        {
            get
            {
                return _dibBits.Length;
            }
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Writes the directory entry to the stream.
        /// </summary>
        unsafe public void WriteDirectoryEntry(BinaryWriter writer, UInt32 imageOffset)
        {
            NativeMethods.FILEICONDIRENTRY data = new NativeMethods.FILEICONDIRENTRY();
            data.dwImageOffset = imageOffset;

            data.bWidth = (Byte)_width;
            data.bHeight = (Byte)_height;

            fixed (Byte* bytes = &_dibBits[0])
            {
                NativeMethods.BITMAPINFO* bitmapInfo = (NativeMethods.BITMAPINFO*)bytes;

                data.wPlanes = bitmapInfo->bmiHeader.biPlanes;
                data.wBitCount = bitmapInfo->bmiHeader.biBitCount;
            }

            Byte bColorCount = (Byte)(data.wPlanes * data.wBitCount);

            if (8 <= bColorCount)
            {
                data.bColorCount = 0;
            }
            else
            {
                data.bColorCount = (Byte)(1 << bColorCount);
            }

            data.dwBytesInRes = (UInt32)Size;

            writer.Write(data.bWidth);
            writer.Write(data.bHeight);
            writer.Write(data.bColorCount);
            writer.Write(data.bReserved);
            writer.Write(data.wPlanes);
            writer.Write(data.wBitCount);
            writer.Write(data.dwBytesInRes);
            writer.Write(data.dwImageOffset);
        }

        /// <summary>
        /// Writes the image data to the stream.
        /// </summary>
        unsafe public void WriteImage(BinaryWriter writer)
        {
            fixed (Byte* bytes = &_dibBits[0])
            {
                // When we write the BITMAPINFO the image size must be set to zero.
                // So we cache it here and restore it after we're done writing.

                NativeMethods.BITMAPINFO* bitmapInfo = (NativeMethods.BITMAPINFO*)bytes;
                UInt32 sizeImage = bitmapInfo->bmiHeader.biSizeImage;
                bitmapInfo->bmiHeader.biSizeImage = 0;

                writer.Write(_dibBits);

                bitmapInfo->bmiHeader.biSizeImage = sizeImage;
            }
        }
        #endregion

        #region Private fields
        private Byte[] _dibBits;
        private Int32 _height;
        private Int32 _width;
        private Int32 _colors;
        #endregion
    }
}
