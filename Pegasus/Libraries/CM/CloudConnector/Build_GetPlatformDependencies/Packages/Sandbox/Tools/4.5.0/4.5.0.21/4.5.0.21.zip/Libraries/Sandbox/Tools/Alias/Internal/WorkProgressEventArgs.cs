﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alias.Internal
{
    internal enum WorkProgressCode
    {
        None = 0,
        Fail,
        Success,
        Info
    }

    internal enum FileCode
    {
        None = 0,
        CSProj,
        LibraryConfig,
        Solution,
        FinalBuilder
    }

    internal sealed class WorkProgressEventArgs : EventArgs
    {
        public WorkProgressEventArgs(WorkProgressCode code, String description)
            : this(code, description, null, FileCode.None)
        { }

        public WorkProgressEventArgs(WorkProgressCode code, String description, String details)
            : this(code, description, details, FileCode.None)
        { }

        public WorkProgressEventArgs(WorkProgressCode code, String description, FileCode fileCode)
            : this(code, description, null, fileCode)
        { }

        public WorkProgressEventArgs(WorkProgressCode code, String description, String details, FileCode fileCode)
        {
            _code = code;
            _description = description;
            _details = details;
            _fileCode = fileCode;
        }

        #region Public properties
        public WorkProgressCode Code
        { get { return _code; } }

        public String Description
        { get { return _description; } }

        public String Details
        { get { return _details; } }

        public FileCode FileCode
        { get { return _fileCode; } }
        #endregion

        #region Private fields
        private WorkProgressCode _code;
        private String _description;
        private String _details;
        private FileCode _fileCode;
        #endregion
    }
}
