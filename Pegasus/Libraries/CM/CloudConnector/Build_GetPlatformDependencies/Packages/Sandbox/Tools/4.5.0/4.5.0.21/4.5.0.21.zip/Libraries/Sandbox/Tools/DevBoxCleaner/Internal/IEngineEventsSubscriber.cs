using System;

namespace DevBoxCleaner.Internal
{
    internal interface IEngineEventsSubscriber
    {
        void OnAppendResult(Object sender, ResultEventArgs args);
        void OnStop();
    }
}
