using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryConfigTool.Internal
{
    internal sealed class IndentedOutput : IDisposable
    {
        public IndentedOutput()
        {
            Program.Output.ChangeIndent(IndentAction.Increment);
        }

        ~IndentedOutput()
        {
            Dispose(false);
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            if(false == _disposed)
            {
                Dispose(true);
                _disposed = true;

                // Take yourself off the Finalization queue to prevent
                // finalization code for this Object from executing a second time.
                GC.SuppressFinalize(this);
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        /// <param name="disposing"></param>
        private void Dispose(Boolean disposing)
        {
            if(disposing)
            {
                // Dispose managed code here.
                Program.Output.ChangeIndent(IndentAction.Decrement);
            }

            // Dispose unmanaged resources here. (This Objectdoesn't currently have any.)
        }

        #region Private fields
        private Boolean _disposed; //= false; (automatically initialized by runtime)
        #endregion
    }
}
