﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;
using DevBoxCleaner.Internal;
using DevBoxCleanerConsole.Internal;
using System.IO;

namespace DevBoxCleanerConsole
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class Program
    {
        #region Internal methods
        internal static void WriteLine(String line, Boolean writeAlways)
        {
            if (writeAlways || !_silent)
            {
                Console.WriteLine(line);
            }
        }

        internal static void WriteLine(String line)
        {
            WriteLine(line, false);
        }
        #endregion

        #region Private Methods
        [STAThread]
        private static void Main(String[] args)
        {
            System.Environment.ExitCode = (Int32)ExitCode.OneOrMoreFailuresOccurred;

            try
            {
                EngineOptions engineOptions = new EngineOptions();
                // parse options out of the arguments
                ParseOptions(engineOptions, args);

                if (_printHelp)
                {
                    PrintHelp();
                    Environment.ExitCode = 1;
                }
                else if (!_validActionSpecified)
                {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new DevBoxCleaner.Internal.MainForm());
                }
                else
                {
                    PrintBanner();

                    ConsoleEngineEventsSubscriber consoleEngineEventsSubscriber = new ConsoleEngineEventsSubscriber();
                    Engine engine = new Engine();

                    if (engineOptions.Sandbox && String.IsNullOrEmpty(engineOptions.SandboxLocation))
                    {
                        System.Environment.ExitCode = (Int32)ExitCode.OneOrMoreFailuresOccurred;
                        WriteLine("Sandbox location is required for cleaning sandbox.");
                        return;
                    }

                    if (engineOptions.Registry && String.IsNullOrEmpty(engineOptions.RegBase) && String.IsNullOrEmpty(engineOptions.SandboxLocation))
                    {
                        System.Environment.ExitCode = (Int32)ExitCode.OneOrMoreFailuresOccurred;
                        WriteLine("RegBase or sandbox location is required for cleaning registry.");
                        return;
                    }

                    engine.Start(null, consoleEngineEventsSubscriber, engineOptions);
                    engine.WaitUntilStopped();

                    if (engine.FailureCount > 0)
                    {
                        System.Environment.ExitCode = (Int32)ExitCode.OneOrMoreFailuresOccurred;
                        WriteLine(String.Format("Clean operation completed; {0} failures encountered; elapsed time {1}", engine.FailureCount, engine.EndTime - engine.StartTime));
                    }
                    else
                    {
                        System.Environment.ExitCode = (Int32)ExitCode.Success;
                        WriteLine(String.Format("Clean operation completed; elapsed time {0}", engine.EndTime - engine.StartTime));
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLine("!!! " + ex.ToString(), true);
            }
        }

        private static void ParseOptions(EngineOptions engineOptions, String[] args)
        {
            Dictionary<String, OptionHandler> optionHandlers = new Dictionary<String, OptionHandler>();
            optionHandlers["/debug"] = new OptionHandler(DebugOptionHandler);
            optionHandlers["/help"] = new OptionHandler(HelpOptionHandler);
            optionHandlers["/?"] = new OptionHandler(HelpOptionHandler);
            optionHandlers["/nologo"] = new OptionHandler(NoLogoOptionHandler);
            optionHandlers["/silent"] = new OptionHandler(SilentOptionHandler);
            optionHandlers["/s"] = new OptionHandler(SilentOptionHandler);
            optionHandlers["/sandbox:"] = new OptionHandler(SandboxOptionHandler);
            optionHandlers["/s:"] = new OptionHandler(SandboxOptionHandler);
            optionHandlers["/registry"] = new OptionHandler(RegistryOptionHandler);
            optionHandlers["/r"] = new OptionHandler(RegistryOptionHandler);
            optionHandlers["/regbase:"] = new OptionHandler(RegBaseOptionHandler);
            optionHandlers["/rb:"] = new OptionHandler(RegBaseOptionHandler);
            optionHandlers["/gac"] = new OptionHandler(GacOptionHandler);
            optionHandlers["/g"] = new OptionHandler(GacOptionHandler);
            optionHandlers["/test"] = new OptionHandler(TestOptionHandler);
            optionHandlers["/t"] = new OptionHandler(TestOptionHandler);
            optionHandlers["/exempt:"] = new OptionHandler(ExemptOptionHandler);
            optionHandlers["/e:"] = new OptionHandler(ExemptOptionHandler);

            foreach (String arg in args)
            {
                Int32 nPos = arg.IndexOf(':');
                String param = arg.Substring(nPos + 1);
                String option = (nPos == -1 ? arg : arg.Substring(0, nPos + 1));

                if (optionHandlers.ContainsKey(option))
                {
                    optionHandlers[option](engineOptions, param);
                }
            }
        }

        private delegate void OptionHandler(EngineOptions engineOptions, String param);

        private static void DebugOptionHandler(EngineOptions engineOptions, String param)
        {
            //engineOptions.Debug = true; 
        }

        private static void HelpOptionHandler(EngineOptions engineOptions, String param)
        {
            _validActionSpecified = true;
            _printHelp = true;
        }

        private static void NoLogoOptionHandler(EngineOptions engineOptions, String param)
        { _noLogo = true; }

        private static void SilentOptionHandler(EngineOptions engineOptions, String param)
        { _silent = true; }

        private static void SandboxOptionHandler(EngineOptions engineOptions, String param)
        {
            _validActionSpecified = true;
            engineOptions.Sandbox = true;
            engineOptions.SandboxLocation = Path.GetFullPath(Environment.ExpandEnvironmentVariables(param));
        }

        private static void RegBaseOptionHandler(EngineOptions engineOptions, String param)
        {
            engineOptions.RegBase = Path.GetFullPath(Environment.ExpandEnvironmentVariables(param));
        }

        private static void RegistryOptionHandler(EngineOptions engineOptions, String param)
        {
            _validActionSpecified = true;
            engineOptions.Registry = true;
        }

        private static void GacOptionHandler(EngineOptions engineOptions, String param)
        {
            _validActionSpecified = true;
            engineOptions.Gac = true;
        }

        private static void TestOptionHandler(EngineOptions engineOptions, String param)
        {
            engineOptions.TestOnly = true;
        }

        private static void ExemptOptionHandler(EngineOptions engineOptions, String param)
        {
            if (!string.IsNullOrEmpty(param))
            {
                string[] splitPathArr = param.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

                if (splitPathArr != null)
                {
                    foreach (string excludlePath in splitPathArr)
                    {
                        string expandedPath = Environment.ExpandEnvironmentVariables(excludlePath);
                        engineOptions.ExemptPaths.Add(expandedPath);
                    }
                }
            }
        }

        private static void PrintBanner()
        {
            if (!_noLogo)
            {
                WriteLine("Sage Development Box Cleaner Tool (Console).  Version " + Assembly.GetExecutingAssembly().GetName().Version);
                WriteLine(String.Empty);
            }
        }

        private static void PrintHelp()
        {
            PrintBanner();

            WriteLine("Syntax: DevBoxCleaner-Console [Options]");
            WriteLine("");
            WriteLine("Options:");
            // /debug option purposefully not printed
            //WriteLine("  /debug");
            //WriteLine("    Writes details to debug output");
            //WriteLine("");
            WriteLine("  /sandbox:<path>, /s:<path>");
            WriteLine("    Recursively deletes 'Build Product Files' from locations inside the specified");
            WriteLine("    sandbox.");
            WriteLine("");
            WriteLine("  /registry, /r");
            WriteLine("    Removes all HKCR\\CLSID and HKCR\\TypeLib registry keys which have any values");
            WriteLine("    which mention either \"tsoffice\", the specified sandbox location, or have");
            WriteLine("    the Sage CRE public key token.");
            WriteLine("");
            WriteLine("  /regbase:<path>, /rb:<path>");
            WriteLine("    Specifies the base directory that should be used in conjunction with the /registry");
            WriteLine("    delete operation.  Any COM entries registered to a subdirectory of the base <path>");
            WriteLine("    will be cleaned.");
            WriteLine("");
            WriteLine("  /gac, /g");
            WriteLine("    Removes all files from the GAC that have the Sage CRE public key token");
            WriteLine("");
            WriteLine("  /exempt:<paths>, /e:<paths>");
            WriteLine("    Add semi-colon delimited list of paths to exempt from the /sandbox delete operation");
            WriteLine("");
            WriteLine("  /test");
            WriteLine("    Causes the tool to display what actions would be taken during a non-Test Clean operation.");
            WriteLine("");
            WriteLine("  /silent");
            WriteLine("    Turns off the progress output to the console");
            WriteLine("");
            WriteLine("  /nologo");
            WriteLine("    Suppress display of the logo banner");
            WriteLine("");
            WriteLine("  /?, /help");
            WriteLine("  Displays this usage mesage");
        }
        #endregion

        #region Private fields
        private static Boolean _silent;
        private static Boolean _printHelp;
        private static Boolean _noLogo;
        private static Boolean _validActionSpecified;
        #endregion
    }
}
