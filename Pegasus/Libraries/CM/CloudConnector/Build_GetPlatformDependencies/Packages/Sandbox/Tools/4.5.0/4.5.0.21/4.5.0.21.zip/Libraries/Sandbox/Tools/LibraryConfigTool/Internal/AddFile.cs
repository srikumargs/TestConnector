﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Xml.XPath;
using System.IO;

namespace LibraryConfigTool.Internal
{
    internal sealed class AddFileStep : IStep
    {
        public AddFileStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _fileName = Utils.GetRequiredAttribute(navigator, Constants.FileNameAttribute, Constants.AddFileElement, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String fileName = rootConfigInfo.ReplaceAllVariables(_fileName);

            rootConfigInfo.FileGroup.AddFiles(new ReadOnlyCollection<String>(new String[] { Path.GetFullPath(fileName) }));

            Program.Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "Adding file: '{0}'", fileName));
        }

        #endregion

        private String _fileName;
    }
}
