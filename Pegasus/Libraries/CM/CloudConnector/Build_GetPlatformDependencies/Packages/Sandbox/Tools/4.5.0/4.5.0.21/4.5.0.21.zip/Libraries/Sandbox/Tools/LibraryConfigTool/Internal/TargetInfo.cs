using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class TargetInfo
    {
        public TargetInfo(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _name = Utils.GetRequiredAttribute(navigator, Constants.NameAttribute, Constants.TargetElement, configInfo.ConfigFile);
            _suffixes = Utils.GetOptionalAttribute(navigator, Constants.SuffixesAttribute);

            // Read any associated Exclude elements
            using(IndentedOutput indentedOutput = new IndentedOutput())
            {
                Program.Output.Write(OutputType.Verbose, "Adding settings:");
                XPathNodeIterator settingsIterator = navigator.Select(Constants.SettingElement);
                while(settingsIterator.MoveNext())
                {
                    String name = Utils.GetRequiredAttribute(settingsIterator.Current, Constants.NameAttribute, Constants.SettingElement, configInfo.ConfigFile);
                    String value = Utils.GetOptionalAttribute(settingsIterator.Current, Constants.ValueAttribute);
                    _settings.Add(name, value);
                }
            }
        }

        public void Expand(ConfigInfo rootConfigInfo, String specifiedTargetName)
        {
            String baseTargetName = rootConfigInfo.ReplaceAllVariables(_name);
            String suffixes = rootConfigInfo.ReplaceAllVariables(_suffixes);

            List<String> candidateTargetNames = new List<String>();
            candidateTargetNames.Add(baseTargetName);
            if(!String.IsNullOrEmpty(suffixes))
            {
                // split out the elements of the (potentially) ;-delimited list
                String[] splitSuffixes = suffixes.Split(';');
                foreach(String suffix in splitSuffixes)
                {
                    candidateTargetNames.Add(baseTargetName + suffix);
                }
            }

            // if a specific target name was supplied, then only expand the target if we have a match
            if(!String.IsNullOrEmpty(specifiedTargetName))
            {
                if(!candidateTargetNames.Contains(specifiedTargetName))
                {
                    return;
                }
                else
                {
                    // remove all the candidate target names and populate only the one we care about
                    candidateTargetNames.Clear();
                    candidateTargetNames.Add(specifiedTargetName);
                }
            }

            _targetNames = candidateTargetNames;

            ReadOnlyCollection<String> internalVariableNames = rootConfigInfo.VariableNameKeys;
            foreach(String targetName in _targetNames)
            {
                foreach(String settingKey in _settings.Keys)
                {
                    String targetSettingInternalVariableName = GetTargetSettingInternalVariableName(settingKey, targetName);
                    if(rootConfigInfo.IsSystemVariableDefined(targetSettingInternalVariableName))
                    {
                        String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.DuplicateVariableDefinitionFormat, settingKey);
                        throw new LibraryConfigSchemaException(rootConfigInfo.ConfigFile, errorMessage);
                    }

                    rootConfigInfo.DefineSystemVariable(targetSettingInternalVariableName, _settings[settingKey]);
                }
                rootConfigInfo.DefineSystemVariable(GetTargetSettingInternalVariableName("BaseTargetName", targetName), baseTargetName);
            }
        }

        public static String GetTargetSettingInternalVariableName(String settingName, String targetName)
        {
            return Utils.GetVariableNameKeyForVariableName(String.Format(CultureInfo.InvariantCulture, "{0}::{1}", targetName, settingName));
        }

        public ReadOnlyCollection<String> Names
        {
            get
            {
                return _targetNames.AsReadOnly();
            }
        }

        private String _name;
        private String _suffixes;
        private readonly Dictionary<String, String> _settings = new Dictionary<String, String>();
        private List<String> _targetNames = new List<String>();

    }
}
