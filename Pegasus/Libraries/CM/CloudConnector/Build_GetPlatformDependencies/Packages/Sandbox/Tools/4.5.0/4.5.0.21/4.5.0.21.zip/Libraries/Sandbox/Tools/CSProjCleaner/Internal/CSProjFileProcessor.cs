using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Globalization;
using Microsoft.Build.BuildEngine;
using System.Reflection;

namespace CSProjCleaner.Internal
{
	internal sealed class CSProjFileProcessor
	{
		public CSProjFileProcessor(IEngineEventsSubscriber engineEventsSubscriber, CSProjFileProcessorOptions options)
		{
			_options = options;
			_engineEventsSubscriber = engineEventsSubscriber;
		}

		public ProcessResult ProcessFile(String projectFilePath)
		{
			ProcessResult result = ProcessResult.Error;

			try
			{
				OnWorkProgress(WorkProgressCode.File, Path.GetFileName(projectFilePath));

				// Create a new empty project
				Project project = new Project();

				// Load a project
				project.Load(projectFilePath);

				// Iterate through the various property groups and subsequently 
				// through the various properties
				foreach (BuildPropertyGroup buildPropertyGroup in project.PropertyGroups)
				{
					if (!String.IsNullOrEmpty(buildPropertyGroup.Condition))
					{
						DebugWriteLine(String.Format(CultureInfo.CurrentCulture, "<PropertyGroup Condition=\"{0}\">", buildPropertyGroup.Condition));
					}
					else
					{
						DebugWriteLine("<PropertyGroup>");
					}

					WellKnownBuildPropertyGroup wellKnownBuildPropertyGroup = IdentifyBuildPropertyGroup(buildPropertyGroup);
					foreach (BuildProperty buildProperty in buildPropertyGroup)
					{
						if (!String.IsNullOrEmpty(buildProperty.Condition))
						{
							DebugWriteLine(String.Format(CultureInfo.CurrentCulture, "  <{0} Condition=\"{1}\">{2}</{0}>", buildProperty.Name, buildProperty.Condition, buildProperty.Value));
						}
						else
						{
							DebugWriteLine(String.Format(CultureInfo.CurrentCulture, "  <{0}>{1}</{0}>", buildProperty.Name, buildProperty.Value));
						}
						ProcessBuildProperty(buildProperty, buildPropertyGroup);
					}

					ProcessWellKnownBuildPropertyGroup(buildPropertyGroup, wellKnownBuildPropertyGroup, projectFilePath);

					DebugWriteLine("</PropertyGroup>");
				}


				// Iterate through the various itemgroups
				// and subsequently through the items
				foreach (BuildItemGroup itemGroup in project.ItemGroups)
				{
					if (!String.IsNullOrEmpty(itemGroup.Condition))
					{
						DebugWriteLine(String.Format(CultureInfo.CurrentCulture, "<ItemGroup Condition=\"{0}\">", itemGroup.Condition));
					}
					else
					{
						DebugWriteLine("<ItemGroup>");
					}

					foreach (BuildItem buildItem in itemGroup)
					{
						DebugWriteLine(String.Format(CultureInfo.CurrentCulture, "  <{0} Include=\"{1}\" />", buildItem.Name, buildItem.Include));
						ProcessBuildItem(buildItem);
					}

					DebugWriteLine("</ItemGroup>");
				}

				if (_options.PreBuildAction != Action.None || _options.PostBuildAction != Action.None)
				{
					if (!_wellKnownBuildPropertyGroups.ContainsKey(WellKnownBuildPropertyGroup.BuildEvent))
					{
						BuildPropertyGroup buildEventPropertyGroup = project.AddNewPropertyGroup(true);
						OnWorkProgress(WorkProgressCode.Edit, "Added new property group for build events");
						if (_options.PreBuildAction == Action.Set)
						{
							EnsureBuildPropertyValue(buildEventPropertyGroup, "PreBuildEvent", PreBuildEvent);
						}
						else if (_options.PreBuildAction == Action.Unset)
						{
							EnsureBuildPropertyValue(buildEventPropertyGroup, "PreBuildEvent", String.Empty);
						}

						if (_options.PostBuildAction == Action.Set)
						{
							EnsureBuildPropertyValue(buildEventPropertyGroup, "PostBuildEvent", PostBuildEvent);
						}
						else if (_options.PostBuildAction == Action.Unset)
						{
							EnsureBuildPropertyValue(buildEventPropertyGroup, "PostBuildEvent", String.Empty);
						}
					}
				}

				if (project.IsDirty)
				{
					if (!_options.NoBackup)
					{
						String backupFileName = String.Format("{0}{1}", projectFilePath.Substring(0, projectFilePath.LastIndexOf('.')), string.Format("-Backup-{0}.csproj", DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss")));
						File.Copy(projectFilePath, backupFileName);
						OnWorkProgress(WorkProgressCode.File, String.Format("Original file backed up to '{0}'", backupFileName));
					}

					if (!String.IsNullOrEmpty(_options.SourceControlServer))
					{
						CheckOutForEdit(projectFilePath);
					}

                    File.SetAttributes(projectFilePath, (File.GetAttributes(projectFilePath) & ~FileAttributes.ReadOnly));
					project.Save(projectFilePath);
					result = ProcessResult.ChangesApplied;
				}
				else
				{
					result = ProcessResult.NoChangesNecessary;
				}
			}
			catch (InvalidProjectFileException ex)
			{
				result = ProcessResult.Error;
				OnWorkProgress(WorkProgressCode.Error, ex.Message);
			}

			return result;
		}

		private void CheckOutForEdit(String projectFilePath)
		{
			// late-binding to TFS so that clients aren't required to have the VisualStudio SDK
			try
			{
				Assembly clientAssembly = Assembly.Load("Microsoft.TeamFoundation.Client, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a");
                Type tfsTeamProjectCollectionFactoryType = clientAssembly.GetType("Microsoft.TeamFoundation.Client.TfsTeamProjectCollectionFactory");
                using (IDisposable teamProjectCollectionAsObject = (IDisposable)tfsTeamProjectCollectionFactoryType.InvokeMember("GetTeamProjectCollection", BindingFlags.Public | BindingFlags.Static | BindingFlags.InvokeMethod, null, null, new object[] { new Uri(_options.SourceControlServer) }))
				{
					Assembly versionControlClientAssembly = Assembly.Load("Microsoft.TeamFoundation.VersionControl.Client, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a");
					Type versionControlServerType = versionControlClientAssembly.GetType("Microsoft.TeamFoundation.VersionControl.Client.VersionControlServer");
					Object versionControlServerAsObject = teamProjectCollectionAsObject.GetType().InvokeMember("GetService", BindingFlags.Public | BindingFlags.Instance | BindingFlags.InvokeMethod, null, teamProjectCollectionAsObject, new object[] { versionControlServerType });
					Object sccWorkspceAsObject = versionControlServerAsObject.GetType().InvokeMember("GetWorkspace", BindingFlags.Public | BindingFlags.Instance | BindingFlags.InvokeMethod, null, versionControlServerAsObject, new object[] { projectFilePath });
					sccWorkspceAsObject.GetType().InvokeMember("PendEdit", BindingFlags.Public | BindingFlags.Instance | BindingFlags.InvokeMethod, null, sccWorkspceAsObject, new object[] { projectFilePath });
				}
			}
			catch (Exception ex)
			{
				OnWorkProgress(WorkProgressCode.Error, String.Format(CultureInfo.CurrentCulture, "Unable to check out '{0}': {1}", projectFilePath, ex.Message));
			}
		}

		private ReadOnlyCollection<String> GetBuildPropertyNamesForGroup(BuildPropertyGroup buildPropertyGroup)
		{
			List<String> result = new List<String>();

			foreach (BuildProperty buildProperty in buildPropertyGroup)
			{
				result.Add(buildProperty.Name);
			}

			return result.AsReadOnly();
		}

		private WellKnownBuildPropertyGroup IdentifyBuildPropertyGroup(BuildPropertyGroup buildPropertyGroup)
		{
			WellKnownBuildPropertyGroup result = WellKnownBuildPropertyGroup.None;

			ReadOnlyCollection<String> buildPropertyNames = GetBuildPropertyNamesForGroup(buildPropertyGroup);
			if (!_wellKnownBuildPropertyGroups.ContainsKey(WellKnownBuildPropertyGroup.AllConfig))
			{
				if (String.IsNullOrEmpty(buildPropertyGroup.Condition))
				{
					if (buildPropertyNames.Contains("OutputType") && buildPropertyNames.Contains("RootNamespace") && buildPropertyNames.Contains("AssemblyName"))
					{
						result = WellKnownBuildPropertyGroup.AllConfig;
						_wellKnownBuildPropertyGroups.Add(result, buildPropertyGroup);
					}
				}
			}

			if (!_wellKnownBuildPropertyGroups.ContainsKey(WellKnownBuildPropertyGroup.DebugAnyCPU))
			{
				if (!String.IsNullOrEmpty(buildPropertyGroup.Condition) && buildPropertyGroup.Condition == DebugAnyCPUCondition)
				{
					if (buildPropertyNames.Contains("DebugType") && buildPropertyNames.Contains("OutputPath") && buildPropertyNames.Contains("DefineConstants"))
					{
						result = WellKnownBuildPropertyGroup.DebugAnyCPU;
						_wellKnownBuildPropertyGroups.Add(result, buildPropertyGroup);
					}
				}
			}

			if (!_wellKnownBuildPropertyGroups.ContainsKey(WellKnownBuildPropertyGroup.ReleaseAnyCPU))
			{
				if (!String.IsNullOrEmpty(buildPropertyGroup.Condition) && buildPropertyGroup.Condition == ReleaseAnyCPUCondition)
				{
					if (buildPropertyNames.Contains("DebugType") && buildPropertyNames.Contains("OutputPath") && buildPropertyNames.Contains("DefineConstants"))
					{
						result = WellKnownBuildPropertyGroup.ReleaseAnyCPU;
						_wellKnownBuildPropertyGroups.Add(result, buildPropertyGroup);
					}
				}
			}

			if (!_wellKnownBuildPropertyGroups.ContainsKey(WellKnownBuildPropertyGroup.BuildEvent))
			{
				if (String.IsNullOrEmpty(buildPropertyGroup.Condition))
				{
					if (buildPropertyNames.Contains("PreBuildEvent") || buildPropertyNames.Contains("PostBuildEvent"))
					{
						result = WellKnownBuildPropertyGroup.BuildEvent;
						_wellKnownBuildPropertyGroups.Add(result, buildPropertyGroup);
					}
				}
			}

			return result;
		}

		private void ProcessBuildProperty(BuildProperty buildProperty, BuildPropertyGroup buildPropertyGroup)
		{
			if (_options.SetCommonPrivateKey)
			{
				String newValue = GetMSBuildBuildFilesDirPath("PlatformKeyfile.snk");
				if (buildProperty.Name == "AssemblyOriginatorKeyFile" && buildProperty.Value != newValue)
				{
					buildProperty.Value = newValue;
					OnWorkProgress(WorkProgressCode.Edit, String.Format(CultureInfo.CurrentCulture, "Updated AssemblyOriginatorKeyFile to '{0}'", buildProperty.Value));
				}
			}
		}

		private void ProcessWellKnownBuildPropertyGroup(BuildPropertyGroup buildPropertyGroup, WellKnownBuildPropertyGroup wellKnownBuildPropertyGroup, string projectFilePath)
		{
			ReadOnlyCollection<String> buildPropertyNames = GetBuildPropertyNamesForGroup(buildPropertyGroup);
            switch (wellKnownBuildPropertyGroup)
			{
				case WellKnownBuildPropertyGroup.AllConfig:
					if (_options.FrameworkVersion != null)
					{
						EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "TargetFrameworkVersion", _options.FrameworkVersion);
					}
					switch (_options.SignAssemblyAction)
					{
						case Action.Set:
							EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "SignAssembly", "true");
							break;
						case Action.Unset:
							EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "SignAssembly", "false");
							break;
					}
					if (_options.SetCommonPrivateKey)
					{
						EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "AssemblyOriginatorKeyFile", GetMSBuildBuildFilesDirPath("PlatformKeyfile.snk"));
					}
					if (_options.PostBuildAction == Action.Set)
					{
						EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "RunPostBuildEvent", "OnOutputUpdated");
					}
					break;

                case WellKnownBuildPropertyGroup.DebugAnyCPU:
					if (!String.IsNullOrEmpty(_options.PlatformTarget))
					{
						EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "PlatformTarget", _options.PlatformTarget);
					}
					if (_options.FixOutputPaths)
                    {
                        EnsureBuildPropertyRemoved(buildPropertyGroup, buildPropertyNames, "BaseIntermediateOutputPath");
                        EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "OutputPath", @"bin\Debug\");
                        EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "DocumentationFile", GetBuildPropertyValue(_wellKnownBuildPropertyGroups[WellKnownBuildPropertyGroup.AllConfig], "AssemblyName") + ".xml");
                        EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "DebugType", "full");
                    }
                    switch (_options.WarningsAsErrorsAction)
                    {
                        case Action.Set:
                            EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "TreatWarningsAsErrors", "true");
                            break;
                        case Action.Unset:
                            EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "TreatWarningsAsErrors", "false");
                            break;
                    }

                    UpdateCodeAnalysisProperty(buildPropertyGroup, buildPropertyNames, "Debug|Any CPU");
                    UpdateNoWarnProperty(buildPropertyGroup, buildPropertyNames, "Debug|Any CPU");
                    break;

                case WellKnownBuildPropertyGroup.ReleaseAnyCPU:
					if (!String.IsNullOrEmpty(_options.PlatformTarget))
					{
						EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "PlatformTarget", _options.PlatformTarget);
					}
					if (_options.FixOutputPaths)
                    {
                        EnsureBuildPropertyRemoved(buildPropertyGroup, buildPropertyNames, "BaseIntermediateOutputPath");
                        EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "OutputPath", @"bin\Release\");
                        EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "DocumentationFile", GetBuildPropertyValue(_wellKnownBuildPropertyGroups[WellKnownBuildPropertyGroup.AllConfig], "AssemblyName") + ".xml");
                        EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "DebugType", "full");
                    }
                    switch (_options.WarningsAsErrorsAction)
                    {
                        case Action.Set:
                            EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "TreatWarningsAsErrors", "true");
                            break;
                        case Action.Unset:
                            EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "TreatWarningsAsErrors", "false");
                            break;
                    }
                    UpdateCodeAnalysisProperty(buildPropertyGroup, buildPropertyNames, "Release|Any CPU");
                    UpdateNoWarnProperty(buildPropertyGroup, buildPropertyNames, "Release|Any CPU");
					break;

                case WellKnownBuildPropertyGroup.BuildEvent:
					if (_options.PreBuildAction == Action.Set)
					{
						EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "PreBuildEvent", PreBuildEvent);
					}
					else if (_options.PreBuildAction == Action.Unset)
					{
						EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "PreBuildEvent", String.Empty);
					}

					if (_options.PostBuildAction == Action.Set)
					{
						EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "PostBuildEvent", PostBuildEvent);
					}
					else if (_options.PostBuildAction == Action.Unset)
					{
						EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "PostBuildEvent", String.Empty);
					}
					break;
			}
		}

		private void UpdateCodeAnalysisProperty(BuildPropertyGroup buildPropertyGroup, ReadOnlyCollection<String> buildPropertyNames, String configuration)
		{
			Action codeAnalysisAction = _options.CodeAnalysisActionForConfiguration(configuration);
			if (codeAnalysisAction != Action.None)
			{
				EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "RunCodeAnalysis", codeAnalysisAction == Action.Set ? "true" : "false");
				EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "CodeAnalysisIgnoreGeneratedCode", "true");
			}
			if (_options.AllCodeAnalysisRulesEnabledForConfiguration(configuration))
			{
				EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "CodeAnalysisRules", "");
			}
			UpdateCodeAnalysisRulesProperty(buildPropertyGroup, buildPropertyNames, configuration);
		}

		private void UpdateNoWarnProperty(BuildPropertyGroup buildPropertyGroup, ReadOnlyCollection<String> buildPropertyNames, String configuration)
		{
			ReadOnlyCollection<Int32> warningsToEnableForConfiguration = _options.WarningsToEnableForConfiguration(configuration);
			ReadOnlyCollection<Int32> warningsToSuppressForConfiguration = _options.WarningsToSuppressForConfiguration(configuration);
			String currentNoWarn = GetBuildPropertyValue(buildPropertyGroup, "NoWarn");
			List<Int32> newNoWarn = new List<Int32>();
			if (!String.IsNullOrEmpty(currentNoWarn))
			{
				String[] splitNoWarn = currentNoWarn.Split(',');
				foreach (String currentNoWarnAsString in splitNoWarn)
				{
					Int32 warning = Convert.ToInt32(currentNoWarnAsString);
					if (!warningsToEnableForConfiguration.Contains(warning))
					{
						newNoWarn.Add(warning);
					}
				}
			}
			foreach (Int32 warningToSuppress in warningsToSuppressForConfiguration)
			{
				if (!newNoWarn.Contains(warningToSuppress))
				{
					newNoWarn.Add(warningToSuppress);
				}
			}
			StringBuilder newNoWarnStringBuilder = new StringBuilder();
			foreach (Int32 warning in newNoWarn)
			{
				newNoWarnStringBuilder.AppendFormat("{0},", warning);
			}
			EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "NoWarn", newNoWarnStringBuilder.ToString().TrimEnd(','));
		}

		private void UpdateCodeAnalysisRulesProperty(BuildPropertyGroup buildPropertyGroup, ReadOnlyCollection<String> buildPropertyNames, String configuration)
		{
			ReadOnlyCollection<String> rulesToEnableForConfiguration = _options.CodeAnalysisRulesToEnableForConfiguration(configuration);
			ReadOnlyCollection<String> rulesToSuppressForConfiguration = _options.CodeAnalysisRulesToSuppressForConfiguration(configuration);
			String currentCodeAnalysisRules = GetBuildPropertyValue(buildPropertyGroup, "CodeAnalysisRules");
			List<String> newCodeAnalysisRules = new List<String>();
			// do we have existing rules?
			Boolean resetToDefault = rulesToEnableForConfiguration.Contains("default");
			Boolean enableAll = rulesToEnableForConfiguration.Contains("all");

			if (!String.IsNullOrEmpty(currentCodeAnalysisRules) && !resetToDefault)
			{
				// we have existing rules, iterate through them and only copy them to the new rules to be
				// applied if we do not have a rule for them in our current suppression/enabled list
				String[] splitCodeAnalysisRules = currentCodeAnalysisRules.Split(';');
				foreach (String codeAnalysisRule in splitCodeAnalysisRules)
				{
					String basicRuleString = codeAnalysisRule.TrimStart('-');
					basicRuleString = basicRuleString.TrimStart('+');
					Boolean warnAsError = false;
					if (basicRuleString.StartsWith("!"))
					{
						warnAsError = true;
						basicRuleString = basicRuleString.TrimStart('!');
					}
					// must check the enabled list for +! rules as well
					if (!rulesToSuppressForConfiguration.Contains(String.Format("-!{0}", basicRuleString)) &&
						!rulesToSuppressForConfiguration.Contains(String.Format("-{0}", basicRuleString)) &&
						!rulesToEnableForConfiguration.Contains(String.Format("+!{0}", basicRuleString)))
					{
						// either enableAll must be false or warnAsError must be true for us to insert
						// an existing rule
						if (!enableAll || warnAsError)
						{
							newCodeAnalysisRules.Add(codeAnalysisRule);
						}
					}
				}
			}

			// iterate through the supplied list of rules to suppress and add them to the new rule list
			foreach (String ruleToSuppress in rulesToSuppressForConfiguration)
			{
				newCodeAnalysisRules.Add(ruleToSuppress);
			}

			// iterate through the supplied list of rules to enable and remove any matching rules from
			// the new rule list ( thus causing them to be enabled )
			foreach (String ruleToEnable in rulesToEnableForConfiguration)
			{
				if (ruleToEnable.Equals("default") || ruleToEnable.Equals("all"))
				{
					continue;
				}
				String basicRuleString = ruleToEnable.TrimStart('+');
				Boolean warnAsError = false;
				if (basicRuleString.StartsWith("!"))
				{
					warnAsError = true;
					basicRuleString = basicRuleString.TrimStart('!');
				}

				String ruleSearchString = String.Format("+!{0}", basicRuleString);
				if (newCodeAnalysisRules.Contains(String.Format(ruleSearchString)))
				{
					newCodeAnalysisRules.Remove(ruleSearchString);
				}

				ruleSearchString = String.Format("-{0}", basicRuleString);
				if (newCodeAnalysisRules.Contains(String.Format(ruleSearchString)))
				{
					newCodeAnalysisRules.Remove(ruleSearchString);
				}

				if (warnAsError)
				{
					newCodeAnalysisRules.Add(ruleToEnable);
				}
			}

			StringBuilder newCodeAnalysisRulesStringBuilder = new StringBuilder();
			foreach (String codeAnalysisRule in newCodeAnalysisRules)
			{
				newCodeAnalysisRulesStringBuilder.AppendFormat("{0};", codeAnalysisRule);
			}
			EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, "CodeAnalysisRules", newCodeAnalysisRulesStringBuilder.ToString().TrimEnd(';'));
		}

		private void EnsureBuildPropertyValue(BuildPropertyGroup buildPropertyGroup, String name, String value)
		{
			ReadOnlyCollection<String> buildPropertyNames = GetBuildPropertyNamesForGroup(buildPropertyGroup);
			EnsureBuildPropertyValue(buildPropertyGroup, buildPropertyNames, name, value);
		}

		private void EnsureBuildPropertyValue(BuildPropertyGroup buildPropertyGroup, ReadOnlyCollection<String> buildPropertyNames, String name, String value)
		{
			if (!buildPropertyNames.Contains(name))
			{
				buildPropertyGroup.AddNewProperty(name, value);
				OnWorkProgress(WorkProgressCode.Edit, String.Format(CultureInfo.CurrentCulture, "Added '{0}' build propery value of '{1}'", name, value));
			}
			else if (GetBuildPropertyValue(buildPropertyGroup, name) != value)
			{
				buildPropertyGroup.RemoveProperty(name);
				buildPropertyGroup.AddNewProperty(name, value);
				OnWorkProgress(WorkProgressCode.Edit, String.Format(CultureInfo.CurrentCulture, "Updated '{0}' build propery value to '{1}'", name, value));
			}
		}

        private void EnsureBuildPropertyRemoved(BuildPropertyGroup buildPropertyGroup, ReadOnlyCollection<String> buildPropertyNames, String name)
        {
            if (buildPropertyNames.Contains(name))
            {
                buildPropertyGroup.RemoveProperty(name);
                OnWorkProgress(WorkProgressCode.Edit, String.Format(CultureInfo.CurrentCulture, "Removed '{0}' build propery value", name));
            }
        }

		private String GetBuildPropertyValue(BuildPropertyGroup buildProperyGroup, String name)
		{
			String result = null;

			foreach (BuildProperty buildProperty in buildProperyGroup)
			{
				if (buildProperty.Name == name)
				{
					result = buildProperty.Value;
				}
			}

			return result;
		}

		private void ProcessBuildItem(BuildItem buildItem)
		{
			if (_options.FixAssemblyReferences && buildItem.Name == "Reference" && !String.IsNullOrEmpty(buildItem.Include))
			{
				String[] splitBuildItemInclude = buildItem.Include.Split(',');
				String fileName = splitBuildItemInclude[0];
				String fileNameAndExtension = fileName + ".dll";
				String referencedAssemblyMSBuildPath = GetMSBuildAssemblyDirPath(fileNameAndExtension);
				String referencedAssemblyFilePath = GetAssemblyDirPath(fileNameAndExtension);
				if (File.Exists(referencedAssemblyFilePath))
				{
					// use Directory.GetFiles to get the correct casing for the file (as exists in the file system)
					String[] files = Directory.GetFiles(Path.GetDirectoryName(referencedAssemblyFilePath), Path.GetFileName(referencedAssemblyFilePath));
					fileName = Path.GetFileNameWithoutExtension(files[0]);
					fileNameAndExtension = Path.GetFileName(files[0]);
                    referencedAssemblyMSBuildPath = GetMSBuildAssemblyDirPath(fileNameAndExtension);
					referencedAssemblyFilePath = Path.Combine(Path.GetDirectoryName(referencedAssemblyFilePath), fileNameAndExtension);

					Boolean updated = false;
					if (buildItem.Include != fileName)
					{
						buildItem.Include = fileName;
						updated = true;
					}

					if (!buildItem.HasMetadata("Name") || buildItem.GetMetadata("Name") != fileName)
					{
						buildItem.SetMetadata("Name", fileName);
						updated = true;
					}

					if (!buildItem.HasMetadata("HintPath") || buildItem.GetMetadata("HintPath") != referencedAssemblyMSBuildPath)
					{
						buildItem.SetMetadata("HintPath", referencedAssemblyMSBuildPath);
						updated = true;
					}

					if (!buildItem.HasMetadata("Private") || buildItem.GetMetadata("Private") != "False")
					{
						buildItem.SetMetadata("Private", "False");
						updated = true;
					}

					if (!buildItem.HasMetadata("SpecificVersion") || buildItem.GetMetadata("SpecificVersion") != "False")
					{
						buildItem.SetMetadata("SpecificVersion", "False");
						updated = true;
					}

					if (updated)
					{
						OnWorkProgress(WorkProgressCode.Edit, String.Format(CultureInfo.CurrentCulture, "Updated reference to '{0}'", fileName));
					}
				}
			}

			if (_options.SetCommonPrivateKey)
			{
				if (buildItem.Name == "None" && !String.IsNullOrEmpty(buildItem.Include))
				{
					if (buildItem.Include.ToLowerInvariant().Contains("platformkeyfile.snk"))
					{
						const String fileName = "PlatformKeyfile.snk";
						String referencedFileMSBuildPath = GetMSBuildBuildFilesDirPath(fileName);

						Boolean updated = false;
						if (buildItem.Include != referencedFileMSBuildPath)
						{
							buildItem.Include = referencedFileMSBuildPath;
							updated = true;
						}

						if (!buildItem.HasMetadata("Link") || buildItem.GetMetadata("Link") != fileName)
						{
							buildItem.SetMetadata("Link", fileName);
							updated = true;
						}

						if (updated)
						{
							OnWorkProgress(WorkProgressCode.Edit, String.Format(CultureInfo.CurrentCulture, "Updated usage of '{0}'", fileName));
						}
					}
				}
			}
		}

		private String SandboxDir
		{ get { return Environment.GetEnvironmentVariable("SAGE_SANDBOX"); } }

		private String GetMSBuildAssemblyDirPath(String fileName)
		{ return String.Format(CultureInfo.InvariantCulture, @"$(SAGE_SANDBOX)\Assemblies\{0}", fileName); }

		private String GetAssemblyDirPath(String fileName)
		{ return String.Format(CultureInfo.InvariantCulture, @"{0}\Assemblies\{1}", SandboxDir, fileName); }

		private String GetMSBuildBuildFilesDirPath(String fileName)
		{ return String.Format(CultureInfo.InvariantCulture, @"$(SAGE_SANDBOX)\Build\{0}", fileName); }

		private String PreBuildEvent
		{ get { return "\"$(SAGE_SANDBOX)\\Tools\\Bin\\LibraryConfigTool.exe\" /silent /a:PreBuild /d:ProjectName=$(ProjectName) /d:TargetDir=\"$(TargetDir).\" /d:TargetName=$(TargetName) /d:TargetExt=$(TargetExt) /d:ConfigurationName=$(ConfigurationName)"; } }

		private String PostBuildEvent
        { get { return "\"$(SAGE_SANDBOX)\\Tools\\Bin\\LibraryConfigTool.exe\" /silent /a:PostBuild /d:ProjectName=$(ProjectName) /d:TargetDir=\"$(TargetDir).\" /d:TargetName=$(TargetName) /d:TargetExt=$(TargetExt) /d:ConfigurationName=$(ConfigurationName)"; } }

		private String DebugAnyCPUCondition
		{ get { return " '$(Configuration)|$(Platform)' == 'Debug|AnyCPU' "; } }

		private String ReleaseAnyCPUCondition
		{ get { return " '$(Configuration)|$(Platform)' == 'Release|AnyCPU' "; } }

		private void DebugWriteLine(String value)
		{
			if (_options.Debug)
			{
				Debug.WriteLine(value);
			}
		}

		private enum WellKnownBuildPropertyGroup
		{
			None = 0,
			AllConfig,
			DebugAnyCPU,
			ReleaseAnyCPU,
			BuildEvent
		}

		private void OnWorkProgress(WorkProgressCode resultCode, String description)
		{
			if (_engineEventsSubscriber != null)
			{
				_engineEventsSubscriber.OnWorkProgress(this, new WorkProgressEventArgs(resultCode, description));
			}
		}

		private Dictionary<WellKnownBuildPropertyGroup, BuildPropertyGroup> _wellKnownBuildPropertyGroups = new Dictionary<WellKnownBuildPropertyGroup, BuildPropertyGroup>();
		private CSProjFileProcessorOptions _options;
		private IEngineEventsSubscriber _engineEventsSubscriber;
	}
}
