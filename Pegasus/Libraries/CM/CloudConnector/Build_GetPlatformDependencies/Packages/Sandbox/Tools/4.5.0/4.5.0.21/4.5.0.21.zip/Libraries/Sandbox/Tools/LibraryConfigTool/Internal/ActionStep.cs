using System;
using System.Collections.Generic;
using System.Xml.XPath;

namespace LibraryConfigTool.Internal
{
    internal sealed class ActionStep : IStep
    {
        public ActionStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _id = Utils.GetRequiredAttribute(navigator, Constants.IdAttribute, Constants.ActionElement, configInfo.ConfigFile);
            String requiresTargetAsString = Utils.GetOptionalAttribute(navigator, "RequiresTarget");
            if (!String.IsNullOrEmpty(requiresTargetAsString))
            {
                _requiresTarget = Boolean.Parse(requiresTargetAsString);
            }
            _onFailureAction = Utils.GetOptionalAttribute(navigator, "OnFailureAction");

            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = navigator.SelectChildren(XPathNodeType.Element);
                while (iterator.MoveNext())
                {
                    _steps.Add(StepFactory.Create(configInfo, iterator.Current));
                }
            }
        }

        public String Id
        { get { return _id; } }

        public Boolean RequiresTarget
        { get { return _requiresTarget; } }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            Int32 saveErrorCount = Program.Output.ErrorCount;
            String exceptionAsString = String.Empty;
            Boolean failureActionExecuted = false;
            try
            {
                foreach (IStep step in _steps)
                {
                    step.Execute(rootConfigInfo);
                }
            }
            catch (Exception ex)
            {
                if (String.IsNullOrEmpty(_onFailureAction))
                {
                    throw;
                }
                else
                {
                    exceptionAsString = ex.ToString();
                    failureActionExecuted = true;
                    rootConfigInfo.DoAction(rootConfigInfo, _onFailureAction);
                }
            }
            finally
            {
                if (!String.IsNullOrEmpty(_onFailureAction) && !failureActionExecuted && Program.Output.ErrorCount > saveErrorCount)
                {
                    failureActionExecuted = true;
                    rootConfigInfo.DoAction(rootConfigInfo, _onFailureAction);
                }
            }

            if (failureActionExecuted)
            {
                using (BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, "Normal action failed; associated FailureAction invoked.");
                    output.AddErrorDetail("ID of failed action", _id);
                    output.AddErrorDetail("OnFailureAction", _onFailureAction);
                    output.AddErrorDetail("Exception", exceptionAsString);
                    output.EndWriteError();
                }
            }
        }

        #endregion

        private String _id;
        private Boolean _requiresTarget;
        private String _onFailureAction;
        private readonly List<IStep> _steps = new List<IStep>();
    }
}
