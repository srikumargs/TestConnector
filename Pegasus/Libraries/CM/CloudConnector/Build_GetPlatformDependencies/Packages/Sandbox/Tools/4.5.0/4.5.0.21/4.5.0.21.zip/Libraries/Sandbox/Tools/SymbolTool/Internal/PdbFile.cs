﻿using System;
using System.IO;

namespace SymbolTool.Internal
{
    /// <summary>
    /// Defines a wrapper around a PDF file.
    /// </summary>
    public class PdbFile
    {
        #region Fields

        private FileInfo _pdbFile;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="PdbFile"/> class.
        /// </summary>
        /// <param name="pdbFile">The existing PDB file.</param>
        public PdbFile(FileInfo pdbFile)
        {
            if (pdbFile == null)
            {
                throw new ArgumentNullException("pdbFile");
            }

            if (!pdbFile.Exists)
            {
                throw new ArgumentException(string.Format("Pdb file specified \"{0}\" does not exist.", pdbFile.FullName), "pdbFile");
            }

            _pdbFile = pdbFile;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the PDB file.
        /// </summary>
        public FileInfo File
        {
            get { return _pdbFile; }
        }

        #endregion
    }
}
