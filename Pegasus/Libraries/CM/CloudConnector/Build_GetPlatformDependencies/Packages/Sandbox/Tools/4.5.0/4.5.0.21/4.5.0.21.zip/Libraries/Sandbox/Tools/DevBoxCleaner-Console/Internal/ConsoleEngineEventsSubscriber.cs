﻿using System;
using DevBoxCleaner.Internal;

namespace DevBoxCleanerConsole.Internal
{
    internal sealed class ConsoleEngineEventsSubscriber : IEngineEventsSubscriber
    {
        #region ICleanerEngineEventsSubscriber Members

        public void OnAppendResult(Object sender, ResultEventArgs args)
        {
            Program.WriteLine(args.Description);
            if (args.Code == ResultCode.Fail)
            {
                Program.WriteLine(String.Format("FAILED: {0}", args.Details));
            }
        }

        public void OnStop()
        {
        }

        #endregion
    }
}
