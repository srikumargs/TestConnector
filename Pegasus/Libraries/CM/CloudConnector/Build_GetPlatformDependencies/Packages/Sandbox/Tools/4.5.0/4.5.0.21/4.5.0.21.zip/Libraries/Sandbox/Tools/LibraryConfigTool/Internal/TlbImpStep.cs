using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;

namespace LibraryConfigTool.Internal
{
    internal sealed class TlbImpStep : IStep
    {
        public TlbImpStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, Constants.TlbImpElement, configInfo.ConfigFile);
            _interopPath = Utils.GetRequiredAttribute(navigator, Constants.InteropPathAttribute, Constants.TlbImpElement, configInfo.ConfigFile);
            _keyFile = Utils.GetRequiredAttribute(navigator, Constants.KeyFileAttribute, Constants.TlbImpElement, configInfo.ConfigFile);
            _asmVersion = Utils.GetRequiredAttribute(navigator, Constants.AsmVersionAttribute, Constants.TlbImpElement, configInfo.ConfigFile);
            _preventClassMembers = Utils.GetOptionalAttribute(navigator, Constants.PreventClassMembersAttribute);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            Program.Output.Write(OutputType.Info, "Performing type library import....");
            Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:        '{0}'", _path));
            Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "InteropPath: '{0}'", _interopPath));
            Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "KeyFile:     '{0}'", _keyFile));
            Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "AsmVersion:  '{0}'", _asmVersion));

            using(IndentedOutput indentedOutput = new IndentedOutput())
            {
                String path = rootConfigInfo.ReplaceAllVariables(_path);
                String interopPath = rootConfigInfo.ReplaceAllVariables(_interopPath);
                String keyFile = rootConfigInfo.ReplaceAllVariables(_keyFile);
                String asmVersion = rootConfigInfo.ReplaceAllVariables(_asmVersion);
                Boolean preventClassMembers = Boolean.Parse(rootConfigInfo.ReplaceAllVariables(_preventClassMembers));

                try
                {
                    if(!File.Exists(path))
                    {
                        using(BatchedOutput output = new BatchedOutput(false))
                        {
                            output.BeginWriteError(0, Strings.TypeLibraryImportFailedFileNotFound);
                            output.AddErrorDetail(Strings.Path, path);
                            output.AddErrorDetail("InteropPath", interopPath);
                            output.AddErrorDetail("KeyFile", keyFile);
                            output.AddErrorDetail("AsmVersion", asmVersion);
                            output.EndWriteError();
                        }
                    }
                    else
                    {
                        Utils.EnsureDirectoryExists(Path.GetDirectoryName(interopPath), "InteropPathDir");

                        using(IndentedOutput remoteIndentedOutput = new IndentedOutput())
                        {
                            AppDomainSetup appDomainSetup = new AppDomainSetup();
                            appDomainSetup.ApplicationBase = Directory.GetParent(interopPath).FullName;
                            AppDomain appDomain = AppDomain.CreateDomain("RemoteTlbImporter", null, appDomainSetup);
                            try
                            {
                                RemoteTlbImporter registrar = (RemoteTlbImporter) appDomain.CreateInstanceFromAndUnwrap(Assembly.GetExecutingAssembly().CodeBase, "LibraryConfigTool.Internal.RemoteTlbImporter");
                                registrar.ImportTypeLibrary(Program.Output, path, interopPath, keyFile, asmVersion, preventClassMembers);
                            }
                            finally
                            {
                                AppDomain.Unload(appDomain);
                            }
                        }

                        Program.Output.Write(OutputType.Info, Strings.TypeLibraryImportSucceeded);
                    }
                }
                catch(Exception ex)
                {
                    using(BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, Strings.TypeLibraryImportFailed);
                        output.AddErrorDetail(Strings.Path, path);
                        output.AddErrorDetail("InteropPath", interopPath);
                        output.AddErrorDetail("KeyFile", keyFile);
                        output.AddErrorDetail("AsmVersion", asmVersion);
                        output.AddErrorDetail(Strings.Error, ex.ToString());
                        output.EndWriteError();
                    }
                }
            }
        }

        #endregion

        private String _path;
        private String _interopPath;
        private String _keyFile;
        private String _asmVersion;
        private String _preventClassMembers;
    }
}
