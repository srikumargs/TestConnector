using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Diagnostics;
using System.Threading;
using System.Security.Cryptography;

namespace LibraryConfigTool.Internal
{
    internal static class Utils
    {
        public static String SandboxLocation
        {
            get
            {
                if (String.IsNullOrEmpty(_sandboxLocation))
                {
                    _sandboxLocation = Environment.GetEnvironmentVariable("SAGE_SANDBOX");
                }

                return _sandboxLocation;
            }
            set
            {
                _sandboxLocation = value;
            }
        }

        public static bool FileSpecEndsInConcrete3LetterExtension(String fileSpec)
        {
            bool result = false;

            if(fileSpec.Length >= 4 &&
                fileSpec.LastIndexOf('.') == (fileSpec.Length - 4) &&
                !fileSpec.Substring(fileSpec.LastIndexOf('.')).Contains("*") &&
                !fileSpec.Substring(fileSpec.LastIndexOf('.')).Contains("?"))
            {
                result = true;
            }

            return result;
        }

        public static void CopyFileToTargetDir(String fileName, String targetDir, Boolean useMutex)
        {
            CopyFile(fileName, Path.Combine(targetDir, Path.GetFileName(fileName)), useMutex);
        }

        public static void CopyFile(String sourceFileName, String targetFileName, Boolean useMutex)
        {
            try
            {
                if(File.Exists(targetFileName))
                {
                    File.SetAttributes(targetFileName, FileAttributes.Normal);
                }

                if(useMutex)
                {
                    // constructure the mutex name from the name of the file we are going to copy (note:  max length is 260)
                    String mutexNameTargetFileNamePart = targetFileName.Substring(2); // remove potential drive letter
                    if(mutexNameTargetFileNamePart.Length > 200)
                    {
                        mutexNameTargetFileNamePart = mutexNameTargetFileNamePart.Substring(mutexNameTargetFileNamePart.Length - 200);
                    }
                    String mutexName = String.Format(CultureInfo.InvariantCulture, "LibraryConfigTool_CopyTo_{0}", mutexNameTargetFileNamePart.Replace('\\', '_'));
                    Debug.Assert(mutexName.Length < 260);


                    // Multiple projects may attempt to copy the same file at the same time.  This is especially
                    // prevalent for the publishing and distribution of the manifest files.  Use a mutex to prevent
                    // this.  This can happen because Visual Studio's build process can spawn
                    // multiple simultaneous threads which will cause multiple instances of the LibraryConfigTool
                    // to be invoked at the same time.
                    using(Mutex mutex = new Mutex(false, mutexName))
                    {
                        if(mutex.WaitOne(30000, false))
                        {
                            File.Copy(sourceFileName, targetFileName, true);
                        }
                        else
                        {
                            using(BatchedOutput output = new BatchedOutput(false))
                            {
                                output.BeginWriteError(0, Strings.FileCopyFailedUnableToAcquireLibraryConfigToolCopyToMutex);
                                output.AddErrorDetail(Strings.Source, sourceFileName);
                                output.AddErrorDetail(Strings.Destination, targetFileName);
                                output.EndWriteError();
                            }
                        }
                    }
                }
                else
                {
                    File.Copy(sourceFileName, targetFileName, true);
                }

                Program.Output.Write(OutputType.Info, Strings.FileCopySucceeded);
                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Source:      '{0}'", sourceFileName));
                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Destination: '{0}'", targetFileName));
            }
            catch(Exception ex)
            {
                using(BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, Strings.FileCopyFailed);
                    output.AddErrorDetail(Strings.Source, sourceFileName);
                    output.AddErrorDetail(Strings.Destination, targetFileName);
                    output.AddErrorDetail(Strings.Error, ex.ToString());
                    output.EndWriteError();
                }
            }
        }

        //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
        public static String GetLibraryManfiestFileName(String librarySetId, String libraryName)
        {
            return String.Format(CultureInfo.InvariantCulture, "{0}.{1}.{2}.xml", "Sage", librarySetId, libraryName);
        }

        //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
        public static String GetReferencedLibraryManfiestFilePath(LibraryReference libraryReference)
        {
            return Path.Combine(Path.Combine(Path.Combine(libraryReference.LibrarySetId, libraryReference.LibraryName), libraryReference.LibraryVersion), GetLibraryManfiestFileName(libraryReference.LibrarySetId, libraryReference.LibraryName));
        }
        
        public static String GetRequiredAttribute(XPathNavigator navigator, String attributeName, String parentContext, String configFile)
        {
            Debug.Assert(attributeName.Length < 25, "Formatting alignment issue.  Format string will exceed allocated field width for attributeName.");

            String result = navigator.GetAttribute(attributeName, String.Empty);
            
            if(String.IsNullOrEmpty(result))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.MissingOrEmptyAttributeOfElementFormat, attributeName, parentContext);
                throw new LibraryConfigSchemaException(configFile, errorMessage);
            }
            Program.Output.Write(OutputType.Verbose, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "{0,-25} '{1}'", attributeName + ":", result));
            
            return result;
        }

        public static String GetOptionalAttribute(XPathNavigator navigator, String attributeName)
        {
            Debug.Assert(attributeName.Length < 25, "Formatting alignment issue.  Format string will exceed allocated field width for attributeName.");

            String result = navigator.GetAttribute(attributeName, String.Empty);
            Program.Output.Write(OutputType.Verbose, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "{0,-25} '{1}'", attributeName + ":", result));

            return result;
        }

        public static String GetVariableNameKeyForVariableName(String variableName)
        {
            Debug.Assert(variableName.IndexOfAny(new char[] { '$', '(', ')' }) == -1);
            return String.Format(CultureInfo.InvariantCulture, "$({0})", variableName);
        }

        public static String GetVariableNameForVariableNameKey(String variableNameKey)
        {
            Debug.Assert(variableNameKey.StartsWith("$(") && variableNameKey.EndsWith(")"));
            return variableNameKey.Substring(2, variableNameKey.Length - 3);
        }

        public static Byte[] GetMD5HashForFileContent(String fileName)
        {
            Byte[] result;
            using(FileStream fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                using(MD5CryptoServiceProvider provider = new MD5CryptoServiceProvider())
                {
                    result = provider.ComputeHash(fileStream);
                }
            }
            return result;
        }

        public static String GetRootedPath(String path, ConfigInfo rootConfigInfo)
        {
            String result = path;

            if (!String.IsNullOrEmpty(result) && !Path.IsPathRooted(result))
            {
                result = Path.Combine(Path.GetDirectoryName(rootConfigInfo.ConfigFile), result);
            }

            return result;
        }

        public static void EnsureDirectoryExists(String directoryPath)
        {
            EnsureDirectoryExists(directoryPath, String.Empty);
        }

        public static void EnsureDirectoryExists(String directoryPath, String directoryDescription)
        {
            if (!Directory.Exists(directoryPath))
            {
                Program.Output.Write(OutputType.Info, "Directory does not exist;  creating.");
                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "{0}:   '{1}'", String.IsNullOrEmpty(directoryDescription) ? "Directory" : directoryDescription, directoryPath));
                Directory.CreateDirectory(directoryPath);
            }
        }

		public static String XmlEscape(String value)
		{
			StringBuilder result = new StringBuilder(value);
			result = result.Replace("&", "&amp;");
			result = result.Replace("<", "&lt;");
			result = result.Replace(">", "&gt;");
			result = result.Replace("\"", "&quot;");
			result = result.Replace("'", "&apos;");
			return result.ToString();
		}
		
		public static class NativeMethods
        {
            [DllImport("oleaut32.dll")]
            public static extern Int32 RegisterTypeLib(ITypeLib ptlib, [MarshalAs(UnmanagedType.BStr)] String szFullPath, [MarshalAs(UnmanagedType.BStr)] String szHelpDir);

            [DllImport("oleaut32.dll")]
            public static extern Int32 LoadTypeLib([MarshalAs(UnmanagedType.BStr)] String szFullPath, ref IntPtr pTypeLib);
        }

        private static String _sandboxLocation;
    }
}
