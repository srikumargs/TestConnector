using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;

namespace LibraryConfigTool.Internal
{
    //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
    internal sealed class SolutionBuildInfoItem : BuildInfoItem
    {
        public SolutionBuildInfoItem(ConfigInfo configInfo, XPathNavigator navigator)
            : base(Constants.SolutionBuildInfoElement, configInfo, navigator)
        {
            _platform = Utils.GetRequiredAttribute(navigator, Constants.PlatformAttribute, Constants.SolutionBuildInfoElement, configInfo.ConfigFile);
        }

        public String Platform
        {
            get
            {
                return _platform;
            }
        }

        private String _platform;
    }
}
