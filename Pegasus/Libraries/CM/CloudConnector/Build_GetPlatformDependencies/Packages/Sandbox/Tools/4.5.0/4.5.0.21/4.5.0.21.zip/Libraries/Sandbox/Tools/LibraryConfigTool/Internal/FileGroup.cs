﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal class FileGroup
    {
        public FileGroup(ConfigInfo configInfo, XPathNavigator navigator)
        {
            Program.Output.Write(OutputType.Verbose, "Adding file group:");
            _id = Utils.GetRequiredAttribute(navigator, Constants.IdAttribute, Constants.FileGroupsExpression, configInfo.ConfigFile);

            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = navigator.SelectChildren(XPathNodeType.Element);
                while (iterator.MoveNext())
                {
                    _steps.Add(StepFactory.Create(configInfo, iterator.Current));
                }
            }
        }

        public String Id
        { get { return _id; } }

        public ReadOnlyCollection<String> GetMatchingFiles(ConfigInfo rootConfigInfo)
        {
            FileGroup savedFileGroup = rootConfigInfo.FileGroup;
            try
            {
                rootConfigInfo.FileGroup = this;

                foreach (IStep step in _steps)
                {
                    step.Execute(rootConfigInfo);
                }
            }
            finally
            {
                rootConfigInfo.FileGroup = savedFileGroup;
            }

            return _files.AsReadOnly();
        }

        public void AddFiles(ReadOnlyCollection<String> files)
        {
            _files.AddRange(files);
        }

        private String _id;
        private List<String> _files = new List<String>();
        private readonly List<IStep> _steps = new List<IStep>();
    }
}
