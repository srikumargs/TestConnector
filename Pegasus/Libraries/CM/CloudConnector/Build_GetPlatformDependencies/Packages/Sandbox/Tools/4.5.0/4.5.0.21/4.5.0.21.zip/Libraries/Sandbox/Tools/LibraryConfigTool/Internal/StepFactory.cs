using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml.XPath;

namespace LibraryConfigTool.Internal
{
    internal static class StepFactory
    {
        private delegate IStep StepFactoryHandler(ConfigInfo configInfo, XPathNavigator navigator);

        public static IStep Create(ConfigInfo configInfo, XPathNavigator navigator)
        {
            IStep result = null;

            if (_stepFactoryHandlers == null)
            {
                _stepFactoryHandlers = CreateStepFactoryHandlers();
            }

            Program.Output.Write(OutputType.Verbose, String.Format("Adding '{0}':", navigator.Name));
            if (_stepFactoryHandlers.ContainsKey(navigator.Name))
            {
                result = _stepFactoryHandlers[navigator.Name](configInfo, navigator);
            }
            else
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.UnsupportedElement, navigator.Name);
                throw new LibraryConfigSchemaException(configInfo.ConfigFile, errorMessage);
            }

            return result;
        }

        private static Dictionary<String, StepFactoryHandler> CreateStepFactoryHandlers()
        {
            Dictionary<String, StepFactoryHandler> result = new Dictionary<String, StepFactoryHandler>();
            result.Add(Constants.UseTemplateElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new UseTemplateStep(configInfo, navigator); });
            result.Add(Constants.CopyFilesElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new CopyFilesStep(configInfo, navigator); });
            result.Add(Constants.CopyFileElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new CopyFileStep(configInfo, navigator); });
            result.Add(Constants.IfElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new IfStep(configInfo, navigator); });
            result.Add(Constants.ForEachElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new ForEachStep(configInfo, navigator); });
            result.Add(Constants.PublishManifestElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new PublishManifestStep(configInfo, navigator); });
            result.Add(Constants.DistributeReferencedLibraryManifestsElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new DistributeReferencedLibraryManifestsStep(configInfo, navigator); });
            result.Add(Constants.RegisterAssemblyElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new RegisterAssemblyStep(configInfo, navigator, RegistrationMode.RegisterAssembly); });
            result.Add(Constants.InstallAssemblyToGacElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new InstallAssemblyToGacStep(configInfo, navigator); });
            result.Add(Constants.RegTLibElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new RegTLibStep(configInfo, navigator); });
            result.Add(Constants.TlbImpElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new TlbImpStep(configInfo, navigator); });
            result.Add(Constants.TlbExpElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new RegisterAssemblyStep(configInfo, navigator, RegistrationMode.TlbExp); });
            result.Add(Constants.RegSvr32Element, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new RegSvr32Step(configInfo, navigator); });
            result.Add(Constants.ExecuteElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new ExecuteStep(configInfo, navigator); });
            result.Add(Constants.RegexReplaceInFileElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new RegexReplaceInFileStep(configInfo, navigator); });
            result.Add(Constants.InstallUtilElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new InstallUtilStep(configInfo, navigator); });
            result.Add(Constants.WithLocalVariableElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new WithLocalVariableStep(configInfo, navigator); });
            result.Add(Constants.EmitElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new EmitStep(configInfo, navigator); });
            result.Add(Constants.EmitDataElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new EmitDataStep(configInfo, navigator); });
            result.Add(Constants.ActionElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new ActionStep(configInfo, navigator); });
            result.Add(Constants.CopyDirectoryElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new CopyDirectoryStep(configInfo, navigator); });
            result.Add(Constants.AddFileElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new AddFileStep(configInfo, navigator); });
            result.Add(Constants.AddFilesElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new AddFilesStep(configInfo, navigator); });
            result.Add(Constants.AddFilesFromCollectionElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new AddFilesFromCollectionStep(configInfo, navigator); });
            result.Add(Constants.WXSRemoveUnusedDirectoryElementsElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new WXSRemoveUnusedDirectoryElementsStep(configInfo, navigator); });
            result.Add(Constants.WXSPopulateComponentGuidsElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new WXSPopulateComponentGuidsStep(configInfo, navigator); });
            result.Add(Constants.WXSUpdateDirectoriesElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new WXSUpdateDirectoriesStep(configInfo, navigator); });
            result.Add(Constants.WXSTransformInstalledFilesToDirectoryStructureElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new WXSTransformInstalledFilesToDirectoryStructureStep(configInfo, navigator); });
            result.Add(Constants.WXSReplaceDirectoryIdTokensElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new WXSReplaceDirectoryIdTokensStep(configInfo, navigator); });
            result.Add(Constants.XslTransformElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new XslTransformStep(configInfo, navigator); });
            result.Add(Constants.DeleteFilesElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new DeleteFilesStep(configInfo, navigator); });
            result.Add(Constants.CreateVirtualDirectoryElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new CreateIISVirtualDirectoryStep(configInfo, navigator); });
            result.Add(Constants.RemoveVirtualDirectoryElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new RemoveIISVirtualDirectoryStep(configInfo, navigator); });
            result.Add(Constants.RegSetValueElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new RegSetValueStep(configInfo, navigator); });
            result.Add(Constants.CallActionElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new CallActionStep(configInfo, navigator); });
            result.Add(Constants.AppendTextFileElement, (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new AppendTextFileStep(configInfo, navigator); });
            result.Add("Unzip", (StepFactoryHandler)delegate(ConfigInfo configInfo, XPathNavigator navigator) { return new UnzipStep(configInfo, navigator); });

            return result;
        }

        private static Dictionary<String, StepFactoryHandler> _stepFactoryHandlers;
    }
}
