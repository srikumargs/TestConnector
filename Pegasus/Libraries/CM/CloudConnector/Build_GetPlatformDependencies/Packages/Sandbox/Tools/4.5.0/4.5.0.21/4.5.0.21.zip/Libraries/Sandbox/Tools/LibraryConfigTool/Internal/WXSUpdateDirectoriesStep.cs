﻿using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class WXSUpdateDirectoriesStep : IStep
    {
        public WXSUpdateDirectoriesStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourceFile = Utils.GetRequiredAttribute(navigator, Constants.SourceFileAttribute, Constants.WXSUpdateDirectoriesElement, configInfo.ConfigFile);
            _destinationFile = Utils.GetRequiredAttribute(navigator, Constants.DestinationFileAttribute, Constants.WXSUpdateDirectoriesElement, configInfo.ConfigFile);
            _directoryIdIsSpecialFolder = Utils.GetRequiredAttribute(navigator, "IsSpecialFolder", Constants.WXSUpdateDirectoriesElement, configInfo.ConfigFile);
            _path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, Constants.WXSUpdateDirectoriesElement, configInfo.ConfigFile);
            _directoryId = Utils.GetRequiredAttribute(navigator, "DirectoryId", Constants.WXSUpdateDirectoriesElement, configInfo.ConfigFile);
        }

        static WXSUpdateDirectoriesStep()
        {
            _specialFoldersByDirectoryId.Add("ApplicationDataFolder", Environment.SpecialFolder.ApplicationData);
            _specialFoldersByDirectoryId.Add("CommonAppDataFolder", Environment.SpecialFolder.CommonApplicationData);
            _specialFoldersByDirectoryId.Add("CommonFilesFolder", Environment.SpecialFolder.CommonProgramFiles);
            _specialFoldersByDirectoryId.Add("CookiesFolder", Environment.SpecialFolder.Cookies);
            _specialFoldersByDirectoryId.Add("DesktopDirectoryFolder", Environment.SpecialFolder.DesktopDirectory);
            _specialFoldersByDirectoryId.Add("DesktopFolder", Environment.SpecialFolder.Desktop);
            _specialFoldersByDirectoryId.Add("FavoritesFolder", Environment.SpecialFolder.Favorites);
            _specialFoldersByDirectoryId.Add("HistoryFolder", Environment.SpecialFolder.History);
            _specialFoldersByDirectoryId.Add("InternetCacheFolder", Environment.SpecialFolder.InternetCache);
            _specialFoldersByDirectoryId.Add("LocalApplicationDataFolder", Environment.SpecialFolder.LocalApplicationData);
            _specialFoldersByDirectoryId.Add("MyComputerFolder", Environment.SpecialFolder.MyComputer);
            _specialFoldersByDirectoryId.Add("MyDocumentsFolder", Environment.SpecialFolder.MyDocuments);
            _specialFoldersByDirectoryId.Add("MyMusicFolder", Environment.SpecialFolder.MyMusic);
            _specialFoldersByDirectoryId.Add("MyPicturesFolder", Environment.SpecialFolder.MyPictures);
            _specialFoldersByDirectoryId.Add("PersonalFolder", Environment.SpecialFolder.Personal);
            _specialFoldersByDirectoryId.Add("ProgramFilesFolder", Environment.SpecialFolder.ProgramFiles);
            _specialFoldersByDirectoryId.Add("ProgramsFolder", Environment.SpecialFolder.Programs);
            _specialFoldersByDirectoryId.Add("RecentFolder", Environment.SpecialFolder.Recent);
            _specialFoldersByDirectoryId.Add("SendToFolder", Environment.SpecialFolder.SendTo);
            _specialFoldersByDirectoryId.Add("StartMenuFolder", Environment.SpecialFolder.StartMenu);
            _specialFoldersByDirectoryId.Add("StartupFolder", Environment.SpecialFolder.Startup);
            _specialFoldersByDirectoryId.Add("SystemFolder", Environment.SpecialFolder.System);
            _specialFoldersByDirectoryId.Add("TemplatesFolder", Environment.SpecialFolder.Templates);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_sourceFile), rootConfigInfo);
            String destinationFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_destinationFile), rootConfigInfo);
            Boolean specialFolder = Boolean.Parse(rootConfigInfo.ReplaceAllVariables(_directoryIdIsSpecialFolder));
            String path = rootConfigInfo.ReplaceAllVariables(_path);
            String directoryId = rootConfigInfo.ReplaceAllVariables(_directoryId);

            if (specialFolder)
            {
                if (_specialFoldersByDirectoryId.ContainsKey(directoryId))
                {
                    path = Environment.GetFolderPath(_specialFoldersByDirectoryId[directoryId]);
                    path = path.Substring(Path.GetPathRoot(path).Length);
                }
                else
                {
                    using (BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, "DirectoryId is unknown in WXSUpdateDirectoriesStep.");
                        output.AddErrorDetail("SourceFile", sourceFile);
                        output.AddErrorDetail("DestinationFile", destinationFile);
                        output.AddErrorDetail("IsSpecialFolder", specialFolder.ToString());
                        output.AddErrorDetail("Path", path);
                        output.AddErrorDetail("DirectoryId", directoryId);
                        output.EndWriteError();
                    }
                    return;
                }
            }

            String[] splitPath = path.Split('\\');

            XmlDocument document = new XmlDocument();
            _namespaceManager = new XmlNamespaceManager(document.NameTable);
            _namespaceManager.AddNamespace(String.Empty, "http://schemas.microsoft.com/wix/2006/wi");
            _namespaceManager.AddNamespace("ns", "http://schemas.microsoft.com/wix/2006/wi");
            document.Load(sourceFile);

            XPathNavigator navigator = document.CreateNavigator();
            XPathNavigator rootFragmentNavigator = navigator.SelectSingleNode("//ns:Fragment", _namespaceManager);
            XPathNavigator rootTargetDirDirectoryRefNavigator = navigator.SelectSingleNode("//ns:DirectoryRef[@Id='TARGETDIR']", _namespaceManager);

            XmlElement foundElement = FindPath(rootTargetDirDirectoryRefNavigator, splitPath, 0);
            if (foundElement != null)
            {
                _pathUnderlyingObjects.Add(foundElement);
                if (_pathUnderlyingObjects.Count == splitPath.GetLength(0))
                {
                    XPathNavigator addedDirectoryNavigator;
                    rootFragmentNavigator.AppendChild(String.Format("<DirectoryRef Id='{0}'/>", directoryId));
                    addedDirectoryNavigator = rootFragmentNavigator.SelectSingleNode(String.Format("//ns:Fragment/ns:DirectoryRef[@Id='{0}']", directoryId), _namespaceManager);
                    foreach (XmlNode childNode in _pathUnderlyingObjects[0].ChildNodes)
                    {
                        addedDirectoryNavigator.AppendChild(childNode.CreateNavigator());
                    }
                    _pathUnderlyingObjects[0].RemoveAll();
                }
            }
            document.Save(destinationFile);
        }

        #endregion

        private XmlElement FindPath(XPathNavigator navigator, String[] path, Int32 index)
        {
            // use translate() function to perform a case-insensitive search on the LongName attribute
            XPathNavigator result = navigator.SelectSingleNode(String.Format("ns:Directory[translate(@LongName,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='{0}']", path[index].ToUpperInvariant()), _namespaceManager);
            if (result == null)
            {
                // use translate() function to perform a case-insensitive search on the Name attribute
                result = navigator.SelectSingleNode(String.Format("ns:Directory[translate(@Name,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='{0}']", path[index].ToUpperInvariant()), _namespaceManager);
            }

            if (result != null)
            {
                if (index + 1 < path.GetLength(0))
                {
                    XmlElement foundElement = FindPath(result, path, index + 1);
                    if (foundElement != null)
                    {
                        _pathUnderlyingObjects.Add(foundElement);
                    }
                }
            }

            return (result != null) ? (result.UnderlyingObject as XmlElement) : null;
        }

        private String _sourceFile;
        private String _destinationFile;
        private String _directoryIdIsSpecialFolder;
        private String _path;
        private String _directoryId;
        private List<XmlElement> _pathUnderlyingObjects = new List<XmlElement>();
        private XmlNamespaceManager _namespaceManager;
        private static Dictionary<String, Environment.SpecialFolder> _specialFoldersByDirectoryId = new Dictionary<String, Environment.SpecialFolder>();
    }
}
