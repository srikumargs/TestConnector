using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Forms;

using CSProjCleaner.Internal;

namespace CSProjCleaner
{
	/// <summary>Required comment for publically available class </summary>
	public sealed class Program
	{
		#region Internal methods
		internal static void WriteLine(String line, Boolean writeAlways)
		{
			if (writeAlways || !_silent)
			{
				Console.WriteLine(line);
			}
		}

		internal static void WriteLine(String line)
		{
			WriteLine(line, false);
		}
		#endregion

		#region Private Methods
		[STAThread]
		private static void Main(String[] args)
		{
			System.Environment.ExitCode = (Int32)ExitCode.UnexpectedErrorsOccurred;

			try
			{
				CSProjFileProcessorOptions processorOptions = new CSProjFileProcessorOptions();
				// parse options out of the arguments
				ParseOptions(processorOptions, args);
				processorOptions.DebugCodeAnalysisValues();

				List<String> fileNameSpecifications = new List<string>();
				foreach (String arg in args)
				{
					if (!arg.StartsWith("/"))
					{
						fileNameSpecifications.Add(arg);
					}
				}

				if (_printHelp)
				{
					PrintHelp();
					Environment.ExitCode = 1;
				}
				else if (!_validActionSpecified)
				{
					Application.EnableVisualStyles();
					Application.SetCompatibleTextRenderingDefault(false);
					Application.Run(new MainForm(fileNameSpecifications.AsReadOnly(), _recursive));
				}
				else
				{
					PrintBanner();

					ConsoleEngineEventsSubscriber consoleEngineEventsSubscriber = new ConsoleEngineEventsSubscriber();
					EngineOptions engineOptions = new EngineOptions(false, fileNameSpecifications.AsReadOnly(), _recursive, processorOptions);
					Engine engine = new Engine();
					engine.Start(null, consoleEngineEventsSubscriber, engineOptions);
					engine.WaitUntilStopped();

					if (engine.FilesWithErrors == 0)
					{
						if (engine.FilesUpdated > 0)
						{
							System.Environment.ExitCode = (Int32)ExitCode.OneOrMoreProjectsUpdatedSuccessfully;
						}
						else
						{
							System.Environment.ExitCode = (Int32)ExitCode.NoChangesNecessary;
						}

						WriteLine(String.Format("{0} of {1} project files updated.", engine.FilesUpdated, engine.FilesProcessed));
					}
					else
					{
						WriteLine(String.Format("{0} of {1} project files updated;  errors encountered.", engine.FilesUpdated, engine.FilesProcessed));
					}
				}
			}
			catch (Exception ex)
			{
				WriteLine("!!! " + ex.ToString(), true);
			}
		}

		private static void ParseOptions(CSProjFileProcessorOptions processorOptions, String[] args)
		{
			Dictionary<String, OptionHandler> optionHandlers = new Dictionary<String, OptionHandler>();
			optionHandlers["/debug"] = new OptionHandler(DebugOptionHandler);
			optionHandlers["/help"] = new OptionHandler(HelpOptionHandler);
			optionHandlers["/?"] = new OptionHandler(HelpOptionHandler);
			optionHandlers["/nologo"] = new OptionHandler(NoLogoOptionHandler);
			optionHandlers["/silent"] = new OptionHandler(SilentOptionHandler);
			optionHandlers["/s"] = new OptionHandler(SilentOptionHandler);
			optionHandlers["/recurse"] = new OptionHandler(RecursiveOptionHandler);
			optionHandlers["/r"] = new OptionHandler(RecursiveOptionHandler);
			optionHandlers["/warnings:"] = new OptionHandler(WarningsOptionHandler);
			optionHandlers["/w:"] = new OptionHandler(WarningsOptionHandler);
			optionHandlers["/buildEvents:"] = new OptionHandler(BuildEventsOptionHandler);
			optionHandlers["/be:"] = new OptionHandler(BuildEventsOptionHandler);
			optionHandlers["/codeAnalysis:"] = new OptionHandler(CodeAnalysisOptionHandler);
			optionHandlers["/ca:"] = new OptionHandler(CodeAnalysisOptionHandler);
			optionHandlers["/config:"] = new OptionHandler(ConfigFileOptionHandler);
			optionHandlers["/c:"] = new OptionHandler(ConfigFileOptionHandler);
			optionHandlers["/sign"] = new OptionHandler(SignAssemblyOptionHandler);
			optionHandlers["/warningsAsErrors:"] = new OptionHandler(WarningAsErrorOptionHandler);
			optionHandlers["/wae:"] = new OptionHandler(WarningAsErrorOptionHandler);
			optionHandlers["/outputPaths"] = new OptionHandler(OutputPathsOptionHandler);
			optionHandlers["/op"] = new OptionHandler(OutputPathsOptionHandler);
			optionHandlers["/sage"] = new OptionHandler(SageOptionHandler);
			optionHandlers["/framework:"] = new OptionHandler(FrameworkOptionHandler);
			optionHandlers["/fw:"] = new OptionHandler(FrameworkOptionHandler);
			optionHandlers["/platformTarget:"] = new OptionHandler(PlatformTargetHandler);
			optionHandlers["/pt:"] = new OptionHandler(PlatformTargetHandler);
			optionHandlers["/assemblyReferences"] = new OptionHandler(AssemblyReferencesOptionHandler);
			optionHandlers["/ar"] = new OptionHandler(AssemblyReferencesOptionHandler);
			optionHandlers["/noBackup"] = new OptionHandler(NoBackupOptionHandler);
			optionHandlers["/nb"] = new OptionHandler(NoBackupOptionHandler);
			optionHandlers["/sourceControlServer:"] = new OptionHandler(SourceControlServerHandler);
			optionHandlers["/scs:"] = new OptionHandler(SourceControlServerHandler);
            optionHandlers["/sdk"] = new OptionHandler(SDKOptionHandler);

			foreach (String arg in args)
			{
				Int32 nPos = arg.IndexOf(':');
				String param = arg.Substring(nPos + 1);
				String option = (nPos == -1 ? arg : arg.Substring(0, nPos + 1));

				if (optionHandlers.ContainsKey(option))
				{
					optionHandlers[option](processorOptions, param);
				}
			}
		}

		private delegate void OptionHandler(CSProjFileProcessorOptions processorOptions, String param);

		private static void DebugOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{ processorOptions.Debug = true; }

		private static void HelpOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			_validActionSpecified = true;
			_printHelp = true;
		}

		private static void NoLogoOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{ _noLogo = true; }

		private static void SilentOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{ _silent = true; }

		private static void RecursiveOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{ _recursive = true; }

		private static void NoBackupOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{ processorOptions.NoBackup = true; }

		private static void AssemblyReferencesOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			_validActionSpecified = true;
			processorOptions.FixAssemblyReferences = true;
		}

		private static void OutputPathsOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			_validActionSpecified = true;
			processorOptions.FixOutputPaths = true;
		}

		private static void SignAssemblyOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			_validActionSpecified = true;
			processorOptions.SignAssemblyAction = CSProjCleaner.Internal.Action.Set;
			processorOptions.SetCommonPrivateKey = true;
		}

		private static void WarningAsErrorOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			_validActionSpecified = true;

			switch (param)
			{
				case "+":
					processorOptions.WarningsAsErrorsAction = CSProjCleaner.Internal.Action.Set;
					break;
				case "-":
					processorOptions.WarningsAsErrorsAction = CSProjCleaner.Internal.Action.Unset;
					break;
			}
		}

		private static void FrameworkOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			_validActionSpecified = true;

			String[] frameworkVersions = { "v2.0", "v3.0", "v3.5", "v4.0" };

			foreach (String s in frameworkVersions)
			{
				if (String.Compare(param, s, true, CultureInfo.InvariantCulture) == 0)
				{
					processorOptions.FrameworkVersion = param;
					break;
				}
			}
		}

		private static void PlatformTargetHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			_validActionSpecified = true;

			String[] platformTargets = { "AnyCPU", "x86", "x64", "Itanium" };

			foreach (String s in platformTargets)
			{
				if (String.Compare(param, s, true, CultureInfo.InvariantCulture) == 0)
				{
					processorOptions.PlatformTarget = param;
					break;
				}
			}
		}

		private static void SageOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
            AssemblyReferencesOptionHandler(processorOptions, param);
            BuildEventsOptionHandler(processorOptions, "+post");
            FrameworkOptionHandler(processorOptions, "v4.0");
            OutputPathsOptionHandler(processorOptions, param);
            PlatformTargetHandler(processorOptions, "x86");
            SignAssemblyOptionHandler(processorOptions, param);
			WarningAsErrorOptionHandler(processorOptions, "+");
		}

        private static void SDKOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
        {
            _validActionSpecified = true;

            processorOptions.PostBuildAction = CSProjCleaner.Internal.Action.Unset;
            processorOptions.PreBuildAction = CSProjCleaner.Internal.Action.Unset;
            processorOptions.SignAssemblyAction = CSProjCleaner.Internal.Action.Unset;
            OutputPathsOptionHandler(processorOptions, param);
            NoBackupOptionHandler(processorOptions, param);
        }

		private static void ConfigFileOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			try
			{
				String[] fileArgs = File.ReadAllLines(param);  // read in the new arguments from the file
				ParseOptions(processorOptions, fileArgs);      // recurse on ourselves to read the additional options
			}
			catch (Exception)
			{
				WriteLine(String.Format("Error: Unable to read specified config file '{0}'", param), true);
			}
		}

		private static void WarningsOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			_validActionSpecified = true;

			String[] splitWarningNumbers = param.Substring(param.IndexOf(':') + 1).Split(',');
			foreach (String warningNumber in splitWarningNumbers)
			{
				Match match = Regex.Match(warningNumber, @"([+-])([0-9]+)\((.*)\)");
				if (match.Success)
				{
					if (match.Groups[1].Value == "+")
					{
						processorOptions.EnableWarning(match.Groups[3].Value, Convert.ToInt32(match.Groups[2].Value));
					}
					else
					{
						processorOptions.SuppressWarning(match.Groups[3].Value, Convert.ToInt32(match.Groups[2].Value));
					}
				}
				else
				{
					match = Regex.Match(warningNumber, @"([+-])([0-9]+)");
					if (match.Success)
					{
						if (match.Groups[1].Value == "+")
						{
							processorOptions.EnableWarning(Convert.ToInt32(match.Groups[2].Value));
						}
						else
						{
							processorOptions.SuppressWarning(Convert.ToInt32(match.Groups[2].Value));
						}
					}
				}
			}
		}

		private static void BuildEventsOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			_validActionSpecified = true;

			String[] splitBuildEvents = param.Substring(param.IndexOf(':') + 1).Split(',');
			foreach (String buildEvent in splitBuildEvents)
			{
				Match match = Regex.Match(buildEvent, @"([+-])((pre)|(post))");
				if (match.Success)
				{
					if (match.Groups[1].Value == "+")
					{
						if (String.Compare(match.Groups[2].Value, "pre", true, CultureInfo.InvariantCulture) == 0)
						{
							processorOptions.PreBuildAction = CSProjCleaner.Internal.Action.Set;
						}
						else if (String.Compare(match.Groups[2].Value, "post", true, CultureInfo.InvariantCulture) == 0)
						{
							processorOptions.PostBuildAction = CSProjCleaner.Internal.Action.Set;
						}
					}
					else if (match.Groups[1].Value == "-")
					{
						if (String.Compare(match.Groups[2].Value, "pre", true, CultureInfo.InvariantCulture) == 0)
						{
							processorOptions.PreBuildAction = CSProjCleaner.Internal.Action.Unset;
						}
						else if (String.Compare(match.Groups[2].Value, "post", true, CultureInfo.InvariantCulture) == 0)
						{
							processorOptions.PostBuildAction = CSProjCleaner.Internal.Action.Unset;
						}
					}
				}
			}
		}

		private static void CodeAnalysisOptionHandler(CSProjFileProcessorOptions processorOptions, String param)
		{
			_validActionSpecified = true;

			String[] splitCodeAnalysis = param.Substring(param.IndexOf(':') + 1).Split(',');
			foreach (String codeAnalysis in splitCodeAnalysis)
			{
				Match match = Regex.Match(codeAnalysis, @"([+-])(run|all|default)\(""(.*)""\)");
				if (match.Success)
				{
					if (match.Groups[0].Value == "+")
					{
						if (match.Groups[1].Value == "run")
						{
							processorOptions.ChangeCodeAnalysisAction(match.Groups[2].Value, CSProjCleaner.Internal.Action.Set);
						}
						else
						{
							processorOptions.EnableCodeAnalysisRule(match.Groups[2].Value, match.Groups[1].Value);
						}
					}
					else
					{
						if (match.Groups[1].Value == "run")
						{
							processorOptions.ChangeCodeAnalysisAction(match.Groups[2].Value, CSProjCleaner.Internal.Action.Unset);
						}
						// no condition for -all or -default
					}
				}

				if (!match.Success)
				{
					match = Regex.Match(codeAnalysis, @"[+-](run|all|default)");
					if (match.Success)
					{
						if (codeAnalysis.StartsWith("+"))
						{
							if (match.Groups[1].Value == "run")
							{
								processorOptions.ChangeCodeAnalysisAction(CSProjCleaner.Internal.Action.Set);
							}
							else
							{
								processorOptions.EnableCodeAnalysisRule(match.Groups[1].Value);
							}
						}
						else
						{
							if (match.Groups[1].Value == "run")
							{
								processorOptions.ChangeCodeAnalysisAction(CSProjCleaner.Internal.Action.Unset);
							}
							else
							{
								// "-all" is not supported because it requires knowledge of all CA rule numbers
							}
						}
					}
				}

				if (!match.Success)
				{
					// -Microsoft.Design#CA1000("Debug|Any CPU") or +!Microsoft.Design#CA1000("Debug|Any CPU") or +Microsoft.Design#CA1000("Debug|Any CPU")
					match = Regex.Match(codeAnalysis, @"(-|\+!|\+)([a-zA-Z]+[a-zA-Z0-9.]*#[a-zA-Z]+[0-9]+)\(""(.*)""\)");
					if (match.Success)
					{
						String foo = match.Groups[3].Value.ToString();
						Debug.Assert(!(foo.StartsWith("\"")));
						if (match.Groups[1].Value == "-")
						{
							processorOptions.SuppressCodeAnalysisRule(match.Groups[3].Value, String.Format("{0}{1}", match.Groups[1].Value, match.Groups[2].Value));
						}
						else
						{
							processorOptions.EnableCodeAnalysisRule(match.Groups[3].Value, String.Format("{0}{1}", match.Groups[1].Value, match.Groups[2].Value));
						}
					}
				}

				if (!match.Success)
				{
					// -Microsoft.Design#CA1000 or +!Microsoft.Design#CA1000 or +Microsoft.Design#CA1000
					match = Regex.Match(codeAnalysis, @"(-|\+!|\+)([a-zA-Z]+[a-zA-Z0-9.]*#[a-zA-Z]+[0-9]+)");
					if (match.Success)
					{
						if (match.Groups[1].Value == "-")
						{
							processorOptions.SuppressCodeAnalysisRule(codeAnalysis);
						}
						else
						{
							processorOptions.EnableCodeAnalysisRule(codeAnalysis);
						}
					}
				}
			}
		}

		private static void SourceControlServerHandler(CSProjFileProcessorOptions processorOptions, String param)
		{ processorOptions.SourceControlServer = param; }

		private static void PrintBanner()
		{
			if (!_noLogo)
			{
				WriteLine("Sage C# Project File Cleaner Tool.  Version " + Assembly.GetExecutingAssembly().GetName().Version);
				WriteLine(String.Empty);
			}
		}

		private static void PrintHelp()
		{
			PrintBanner();

			WriteLine("Syntax: CSProjCleaner [Options] <file>|<folder> ...");
			WriteLine("");
			WriteLine("Options:");
			// /debug option purposefully not printed
			//WriteLine("  /debug");
			//WriteLine("    Writes details to debug output");
			//WriteLine("");
			WriteLine("  /recursive, /r");
			WriteLine("    Includes the specified directory and all the subdirectories");
			WriteLine("    in a search operation");
			WriteLine("");
			WriteLine("  /assemblyReferences, /ar");
			WriteLine("    Normalizes assembly file references");
			WriteLine("");
			WriteLine("  /buildEvents:[+-]pre|post, /be:[+-]pre|post");
			WriteLine("    Sets or clears the specified build event to hook the appropriate LibraryConfigTool action");
			WriteLine("");
			WriteLine("  /codeAnalysis:[+-]Section#Number[(\"configuration name\")], /ca:[+-]Section#Number[(\"configuration name\")]");
			WriteLine("    Enables (+) or suppresses (-) the specified Code Analysis warning");
			WriteLine("    Using +! will enable the warning and cause it to be treated as an error");
			WriteLine("    e.g., /ca:-Microsoft.Design#CA1012, /ca:+!Microsoft.Design#CA2210");
			WriteLine("    Optionally specify configuration name to apply setting to (e.g., /ca:-Microsoft.Design#CA1012(\"Debug|Any CPU\")");
			WriteLine("");
			WriteLine("  /codeAnalysis:all|default|[+-]run[(\"configuration name\")], /ca:all|default|[+-]run[(\"configuration name\")]");
			WriteLine("    'all' will enable all suppressed warnings before processing the list");
			WriteLine("    'default' will enabled all suppressed warnings and turn off all 'treat as errors' flags");
			WriteLine("    'run' will turn code analysis on (+run) or off (-run) before processing the list");
			WriteLine("    Optionally specify configuration name to apply setting to (e.g., /ca:default(\"Debug|Any CPU\")");
			WriteLine("");
			WriteLine("  /config:<file> or /c:<file>");
			WriteLine("    Loads the text from <file> and treats each line as a separate parameter");
			WriteLine("");
            WriteLine("  /framework:<version>, /fw:<version>");
            WriteLine("    Sets the target .NET framework version (i.e., 'v2.0', 'v3.0', 'v3.5', 'v4.0')");
            WriteLine("");
            WriteLine("  /noBackup, /nb");
            WriteLine("    Do not create backup files for the files being changed");
            WriteLine("");
            WriteLine("  /nologo");
            WriteLine("    Suppress display of the logo banner");
            WriteLine("");
            WriteLine("  /outputPaths, /op");
			WriteLine("    Normalizes the output paths for the build products");
			WriteLine("");
			WriteLine("  /platformTarget:<platform>, /pt:<platform>");
			WriteLine("    Sets the platform target (i.e., 'AnyCPU', 'x86', 'x64', 'Itanium')");
			WriteLine("");
			WriteLine("  /sage");
            WriteLine("    Equivalent to /ar /be:post+ /fw:v4.0 /op /pt:x86 /sign /wae:+");
			WriteLine("");
            WriteLine("  /sdk");
            WriteLine("    Removes the Sage specific settings.");
            WriteLine("    Used for project delivered on our Development Partner CD");
            WriteLine("");
            WriteLine("  /sign");
            WriteLine("    Sets the SignAssembly flag inside the project to True and changes the");
            WriteLine("    path for the private key used to sign the assembly to PlatformKeyfile.snk");
            WriteLine("    in the 'Build Files' folder of the sandbox");
            WriteLine("");
            WriteLine("  /silent");
            WriteLine("    Turns off the progress output to the console");
            WriteLine("");
            WriteLine("  /sourceControlServer:<server name>, /scs:<server name>");
			WriteLine("    Checks-out modified project files using specified source control server");
			WriteLine("");
            WriteLine("  /warnings:[+-]####[(\"configuration name\")], /wa:[+-]####[(\"configuration name\")]");
            WriteLine("    Enables (+) or suppresses (-) the specified compiler warning ####");
            WriteLine("    Optionally specify configuration name to apply setting to (e.g., /wa:+1234(\"Debug|Any CPU\")");
            WriteLine("");
            WriteLine("  /warningsAsErrors:[+-], /wae:[+-]");
            WriteLine("    Turns on (+) or off (-) TreatWarningsAsErrors flag");
            WriteLine("");
			WriteLine("  /?, /help");
			WriteLine("  Displays this usage mesage");
		}
		#endregion

		#region Private fields
		private static Boolean _recursive;
		private static Boolean _silent;
		private static Boolean _printHelp;
		private static Boolean _noLogo;
		private static Boolean _validActionSpecified;
		#endregion
	}
}
