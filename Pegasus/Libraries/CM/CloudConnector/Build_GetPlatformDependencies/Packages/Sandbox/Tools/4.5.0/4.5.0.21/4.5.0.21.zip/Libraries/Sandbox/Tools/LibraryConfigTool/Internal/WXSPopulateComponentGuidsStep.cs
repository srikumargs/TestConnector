﻿using System;
using System.Collections.Specialized;
using System.Collections.ObjectModel;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Linq;
using System.Collections.Generic;

namespace LibraryConfigTool.Internal
{
    internal sealed class WXSPopulateComponentGuidsStep : IStep
    {
        public WXSPopulateComponentGuidsStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourceFile = Utils.GetRequiredAttribute(navigator, Constants.SourceFileAttribute, Constants.WXSPopulateComponentGuidsElement, configInfo.ConfigFile);
            _destinationFile = Utils.GetRequiredAttribute(navigator, Constants.DestinationFileAttribute, Constants.WXSPopulateComponentGuidsElement, configInfo.ConfigFile);
            _guidFile = Utils.GetRequiredAttribute(navigator, Constants.GuidFileAttribute, Constants.WXSPopulateComponentGuidsElement, configInfo.ConfigFile);
            _usePathAsId = Utils.GetRequiredAttribute(navigator, "UsePathAsId", Constants.WXSPopulateComponentGuidsElement, configInfo.ConfigFile);
            _idFragment = Utils.GetOptionalAttribute(navigator, "IdFragment");
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_sourceFile), rootConfigInfo);
            String destinationFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_destinationFile), rootConfigInfo);
            String guidFile = rootConfigInfo.ReplaceAllVariables(_guidFile);
            Boolean usePathAsId = Boolean.Parse(rootConfigInfo.ReplaceAllVariables(_usePathAsId));
            String idFragment = rootConfigInfo.ReplaceAllVariables(_idFragment);

            // create new ID file if necessary
            if (!File.Exists(guidFile))
            {
                Utils.EnsureDirectoryExists(Path.GetDirectoryName(guidFile));

                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.CloseOutput = true;
                xmlWriterSettings.ConformanceLevel = ConformanceLevel.Document;
                xmlWriterSettings.Encoding = Encoding.UTF8;
                xmlWriterSettings.NewLineHandling = NewLineHandling.Entitize;
                xmlWriterSettings.OmitXmlDeclaration = false;

                using (XmlWriter xmlWriter = XmlWriter.Create(guidFile, xmlWriterSettings))
                {
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("LibraryConfigTool");
                    xmlWriter.WriteStartElement("Components");
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("Files");
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("Directories");
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndDocument();

                    xmlWriter.Flush();
                    xmlWriter.Close();
                }
            }


            // load ID file
            XmlDocument guidFileDocument = new XmlDocument();
            guidFileDocument.Load(guidFile);
            XPathNavigator guidFileNavigator = guidFileDocument.CreateNavigator();


            // load contents of ID file: components
            XPathNodeIterator iter = guidFileNavigator.Select("//Component");
            while (iter.MoveNext())
            {
                _componentIds.Add(iter.Current.GetAttribute("Id", String.Empty));
            }

            // load contents of ID file: files
            iter = guidFileNavigator.Select("//File");
            while (iter.MoveNext())
            {
                _fileIds.Add(iter.Current.GetAttribute("Id", String.Empty));
            }

            // load contents of ID file: directories
            iter = guidFileNavigator.Select("//Directory");
            while (iter.MoveNext())
            {
                _directoryIds.Add(iter.Current.GetAttribute("Id", String.Empty));
            }


            // load WXS file
            XmlDocument wxsFileDocument = new XmlDocument();
            _wxsNamespaceManager = new XmlNamespaceManager(wxsFileDocument.NameTable);
            _wxsNamespaceManager.AddNamespace(String.Empty, "http://schemas.microsoft.com/wix/2006/wi");
            _wxsNamespaceManager.AddNamespace("ns", "http://schemas.microsoft.com/wix/2006/wi");
            wxsFileDocument.Load(sourceFile);

            // populate Component guids
            Boolean guidFileChanged = false;
            XmlNodeList wxsComponentNodes = wxsFileDocument.SelectNodes("//ns:Component[@Guid='PUT-GUID-HERE']", _wxsNamespaceManager);
            XPathNavigator componentsNavigator = guidFileNavigator.SelectSingleNode("/LibraryConfigTool/Components");
            foreach (XmlNode node in wxsComponentNodes)
            {
                String newGuidAsString = String.Empty;
                String newComponentId = String.Empty;
                String newKeyFilePath = String.Empty;
                String componentId =  Utils.XmlEscape(node.Attributes["Id"].Value);
                String keyFilePathFromNodePath = Utils.XmlEscape(DerivePathFromNodePath(node, GetComponentStartingPath(node)));
                XPathNavigator navigator = null;
                if (usePathAsId)
                {
                    navigator = guidFileNavigator.SelectSingleNode(String.Format("//Component[@Path='{0}']", keyFilePathFromNodePath));
                }
                else
                {
					navigator = guidFileNavigator.SelectSingleNode(String.Format("//Component[@Id='{0}']", componentId));

					// If the ComponentID wasn't found, do a case insensitive search.  The guids are unique, but
					// the names may have been added with the wrong case.
					if (navigator == null)
					{
						XPathNodeIterator nodes = guidFileNavigator.Select("*//Component");
						foreach (XPathNavigator componentNode in nodes)
						{
							string attr = componentNode.GetAttribute("Id", "");
							if (!string.IsNullOrEmpty(attr))
							{
								if (string.Compare(attr, componentId, true) == 0)
								{
									// Found, but the case didn't match.  If it did, it would have been caught above.
									// Flag as an error
									using (BatchedOutput output = new BatchedOutput(false))
									{
										output.BeginWriteError(0, "Duplicate ComponentId found.  Although the names are the same, the case is different.");
										output.AddErrorDetail("SourceFile", sourceFile);
                                        output.AddErrorDetail("DestinationFile", destinationFile);
                                        output.AddErrorDetail("ComponentId", componentId);
                                        output.AddErrorDetail("CaseMismatchedComponentId", attr);
										output.EndWriteError();
									}
                                    return;

									// -- Old code which used to just ignore the case.
									// navigator = componentNode;
									// break;
								}
							}
						}
					}
                }

                if (navigator != null)
                {
                    newGuidAsString = navigator.GetAttribute("Guid", String.Empty);
                    newComponentId = navigator.GetAttribute("Id", String.Empty);
                    newKeyFilePath = navigator.GetAttribute("Path", String.Empty);
                }
                else
                {
                    newGuidAsString = Guid.NewGuid().ToString().ToUpper();
                    newKeyFilePath = keyFilePathFromNodePath;
                    if (usePathAsId)
                    {
                        newComponentId = CreateNewId("COM", idFragment, keyFilePathFromNodePath, _componentIds);
                        _componentIds.Add(newComponentId);
                    }
                    else
                    {
                        newComponentId = componentId;
                    }
                    componentsNavigator.AppendChild(String.Format("<Component Id='{0}' Guid='{1}' Path='{2}'/>", newComponentId, newGuidAsString, newKeyFilePath));
                    guidFileChanged = true;
                }

                node.Attributes.RemoveNamedItem("Guid");
                node.CreateNavigator().CreateAttribute(String.Empty, "Guid", String.Empty, newGuidAsString);

                node.Attributes.RemoveNamedItem("Id");
                node.CreateNavigator().CreateAttribute(String.Empty, "Id", String.Empty, newComponentId);
            }


            // populate file id's
            XmlNodeList wxsFileNodes = wxsFileDocument.SelectNodes("//ns:File[@Id='PUT-FILE-ID-HERE']", _wxsNamespaceManager);
            XPathNavigator filesNavigator = guidFileNavigator.SelectSingleNode("/LibraryConfigTool/Files");
            foreach (XmlNode node in wxsFileNodes)
            {
                String newFileId = String.Empty;
                String newFilePath = String.Empty;
                String fileId = Utils.XmlEscape(node.Attributes["Id"].Value);
                String filePathFromNodePath = Utils.XmlEscape(DerivePathFromNodePath(node, node.Attributes["Name"].Value));
                XPathNavigator navigator = null;
                if (usePathAsId)
                {
                    navigator = guidFileNavigator.SelectSingleNode(String.Format("//File[@Path='{0}']", filePathFromNodePath));
                }
                else
                {
                    navigator = guidFileNavigator.SelectSingleNode(String.Format("//File[@Id='{0}']", fileId));
                }

                if (navigator != null)
                {
                    newFileId = navigator.GetAttribute("Id", String.Empty);
                }
                else
                {
                    newFilePath = filePathFromNodePath;
                    if (usePathAsId)
                    {
                        newFileId = CreateNewId("FIL", idFragment, filePathFromNodePath, _fileIds);
                        _fileIds.Add(newFileId);
                    }
                    else
                    {
                        newFileId = fileId;
                    }
                    filesNavigator.AppendChild(String.Format("<File Id='{0}' Path='{1}'/>", newFileId, newFilePath));
                    guidFileChanged = true;
                }

                node.Attributes.RemoveNamedItem("Id");
                node.CreateNavigator().CreateAttribute(String.Empty, "Id", String.Empty, newFileId);
            }


            // populate directory id's
            XmlNodeList wxsDirectoryNodes = wxsFileDocument.SelectNodes("//ns:Directory[@Id='PUT-DIRECTORY-ID-HERE']", _wxsNamespaceManager);
            XPathNavigator directoriesNavigator = guidFileNavigator.SelectSingleNode("/LibraryConfigTool/Directories");
            foreach (XmlNode node in wxsDirectoryNodes)
            {
                String newDirectoryId = String.Empty;
                String newDirectoryPath = String.Empty;
                String directoryId = Utils.XmlEscape(node.Attributes["Id"].Value);
                String directoryPathFromNodePath = Utils.XmlEscape(DerivePathFromNodePath(node, node.Attributes["Name"].Value));
                XPathNavigator navigator = null;
                if (usePathAsId)
                {
                    navigator = guidFileNavigator.SelectSingleNode(String.Format("//Directory[@Path='{0}']", directoryPathFromNodePath));
                }
                else
                {
                    navigator = guidFileNavigator.SelectSingleNode(String.Format("//Directory[@Id='{0}']", directoryId));
                }

                if (navigator != null)
                {
                    newDirectoryId = navigator.GetAttribute("Id", String.Empty);
                }
                else
                {
                    newDirectoryPath = directoryPathFromNodePath;
                    if (usePathAsId)
                    {
                        newDirectoryId = CreateNewId("DIR", idFragment, directoryPathFromNodePath, _directoryIds);
                        _directoryIds.Add(newDirectoryId);
                    }
                    else
                    {
                        newDirectoryId = directoryId;
                    }
                    directoriesNavigator.AppendChild(String.Format("<Directory Id='{0}' Path='{1}'/>", newDirectoryId, newDirectoryPath));
                    guidFileChanged = true;
                }

                node.Attributes.RemoveNamedItem("Id");
                node.CreateNavigator().CreateAttribute(String.Empty, "Id", String.Empty, newDirectoryId);
            }


            // save ID file
            Utils.EnsureDirectoryExists(Path.GetDirectoryName(destinationFile));
            wxsFileDocument.Save(destinationFile);
            if (guidFileChanged)
            {
                File.SetAttributes(guidFile, File.GetAttributes(guidFile) & ~FileAttributes.ReadOnly);
                guidFileDocument.Save(guidFile);
            }
        }

        private String GetComponentStartingPath(XmlNode node)
        {
            String startingPath = String.Empty;
            XmlNode fileNode = node.SelectSingleNode("ns:File[@KeyPath='yes']", _wxsNamespaceManager);
            if (fileNode != null)
            {
                startingPath = fileNode.Attributes["Name"].Value;
            }
            else
            {
                fileNode = node.SelectSingleNode("ns:File", _wxsNamespaceManager);
                if (fileNode != null)
                {
                    startingPath = fileNode.Attributes["Name"].Value;
                }
            }

            return startingPath;
        }

        private static String CreateNewId(String prefix, String idFragment, String path, List<String> ids)
        {
            String[] splitPath = path.Split('\\');
            String result = CanonicalizeId(String.Format("{0}_{1}_", prefix, idFragment), splitPath[splitPath.Length - 1], String.Empty);
            Int32 i = 0;
            while (ids.Contains(result, StringComparer.InvariantCultureIgnoreCase))
            {
                result = CanonicalizeId(String.Format("{0}_{1}_", prefix, idFragment), splitPath[splitPath.Length - 1], String.Format("_{0}", i++));
            }
            return result;
        }

        private static String CanonicalizeId(String prefix, String mainId, String suffix)
        {
            String legalCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.";
            prefix = new String(prefix.ToCharArray().Select(x => legalCharacters.Contains(x) ? x : '_').ToArray());
            mainId = new String(mainId.ToCharArray().Select(x => legalCharacters.Contains(x) ? x : '_').ToArray());
            while (prefix.Length + mainId.Length + suffix.Length > 72)
            {
                Int32 oldLength = mainId.Length;
                Int32 index = mainId.LastIndexOfAny(new char[] { 'a', 'A', 'e', 'E', 'i', 'I', 'o', 'O', 'u', 'U', 'y', 'Y' });

                if (index >= 0)
                {
                    mainId = mainId.Remove(index, 1);

                    if (mainId.Length == oldLength)
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }

            if (prefix.Length + mainId.Length + suffix.Length > 72)
            {
                mainId = mainId.Substring(0, 72 - prefix.Length - suffix.Length);
            }

            return prefix + mainId + suffix;
        }

        private String DerivePathFromNodePath(XmlNode node, String startingPath)
        {
            String path = startingPath;

            XmlNode contextNode = node;
            do
            {
                if (contextNode.ParentNode.Name == "Directory")
                {
                    XmlNode longNameAttribute = contextNode.ParentNode.Attributes.GetNamedItem("LongName");
                    if (longNameAttribute != null)
                    {
                        path = String.Format(@"{0}\{1}", longNameAttribute.Value, path);
                    }
                    else
                    {
                        path = String.Format(@"{0}\{1}", contextNode.ParentNode.Attributes["Name"].Value, path);
                    }
                }
                else if (contextNode.ParentNode.Name == "DirectoryRef")
                {
                    path = String.Format(@"{0}\{1}", contextNode.ParentNode.Attributes["Id"].Value, path);
                }

                contextNode = contextNode.ParentNode;
                if (contextNode != null && (contextNode.ParentNode == null || (contextNode.ParentNode.Name != "Directory" && contextNode.ParentNode.Name != "DirectoryRef")))
                {
                    contextNode = null;
                }
            } while (contextNode != null);
            return path.TrimEnd('\\');
        }

        #endregion

        private String _sourceFile;
        private String _destinationFile;
        private String _guidFile;
        private String _usePathAsId;
        private String _idFragment;
        private List<String> _componentIds = new List<String>();
        private List<String> _fileIds = new List<String>();
        private List<String> _directoryIds = new List<String>();
        private XmlNamespaceManager _wxsNamespaceManager;
    }
}
