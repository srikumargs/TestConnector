using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Reflection;
using System.IO;
using System.Runtime.Remoting.Messaging;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class TypeLibExporterNotifySink : ITypeLibExporterNotifySink, IDisposable
    {
        public TypeLibExporterNotifySink(String assemblyFullName, IMessageSink outputMessageSink)
        {
            _assemblyFullName = assemblyFullName;
            _outputMessageSink = outputMessageSink;
        }

        public void ReportEvent(ExporterEventKind eventKind, Int32 eventCode, String eventMsg)
        {
            Output(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "eventKind='{0}' eventCode='{1}' eventMsg='{2}'", eventKind, eventCode, eventMsg));
        }

        public Object ResolveRef(Assembly assembly)
        {
            // Don't automatically try to resolve references; it appears that possibly this is only needed if you are trying
            // to register in the improper order (i.e., registering a dependent library before registering libraries it depends
            // on).
            //
            // The automatic resolution of references is problematic if it is a reference to another TLB that is going to be 
            // registered later on within the same library.  The problem is that LoadTypeLib appears to hang on to a file handle
            // to the TLB despite best efforts to clean it up (Dispose, Release, CoFreeUnusedLibraries, GC.Collect).  These
            // "out of order" problems can normally be corrected by resequencign the Targets in the LibraryConfig.
            throw new InvalidOperationException(String.Format("Unresolved reference to '{0}' during TLB export of '{1}; if necessary, make certain Target order is correct for this library.", assembly.FullName, _assemblyFullName));

            //// Resolve the reference here and return a correct type library.
            //Output(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "Resolving a reference to '{0}'...", assembly.FullName.ToString()));

            //String path = Path.Combine(Utils.SandboxLocation, String.Format(CultureInfo.InvariantCulture, @"TLBs\{0}.tlb", Path.GetFileNameWithoutExtension(assembly.Location)));
            //Output(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "Attempting '{0}'...'", path));

            //IntPtr typeLibPtr = IntPtr.Zero;
            //ITypeLib typeLib = null;
            //if (Utils.NativeMethods.LoadTypeLib(path, ref typeLibPtr) != 0 ||
            //    typeLibPtr == IntPtr.Zero ||
            //    ((typeLib = (ITypeLib)Marshal.GetTypedObjectForIUnknown(typeLibPtr, typeof(ITypeLib))) == null))
            //{
            //    Output(OutputType.Error, Strings.LoadTypeLibFailed);
            //}
            //else
            //{
            //    _loadedTypeLibs.Add(typeLib);
            //    _loadedTypeLibPtrs.Add(typeLibPtr);
            //}

            //return typeLib;
        }

        private void Output(OutputType outputType, String message)
        {
            Output(outputType, IndentAction.None, message);
        }

        private void Output(OutputType outputType, IndentAction indentAction, String message)
        {
            _outputMessageSink.SyncProcessMessage(new OutputMessage(outputType, indentAction, message));
        }

        private String _assemblyFullName;
        private IMessageSink _outputMessageSink;
        private List<IntPtr> _loadedTypeLibPtrs = new List<IntPtr>();
        private List<ITypeLib> _loadedTypeLibs = new List<ITypeLib>();

        #region IDisposable Members

        ~TypeLibExporterNotifySink()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(Boolean disposing)
        {
            if (disposing)
            {
                foreach (ITypeLib typeLib in _loadedTypeLibs)
                {
                    Marshal.ReleaseComObject(typeLib);
                }
                _loadedTypeLibs.Clear();


                foreach (IntPtr typeLibPtr in _loadedTypeLibPtrs)
                {
                    Marshal.Release(typeLibPtr);
                }
                _loadedTypeLibPtrs.Clear();
            }
        }

        #endregion
    }
}
