using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class ConfigInfoFinder
    {
        public ConfigInfoFinder(String configFile)
        {
            _configFile = configFile;
        }

        public Boolean HasSameName(ConfigInfo configInfo)
        {
            return (String.Compare(configInfo.ConfigFile, _configFile, true, CultureInfo.InvariantCulture) == 0);
        }

        private String _configFile;

    }
}
