using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.IO;

namespace LibraryConfigTool.Internal
{
    internal sealed class RegTLibStep : IStep
    {
        public RegTLibStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, Constants.RegTLibElement, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String path = rootConfigInfo.ReplaceAllVariables(_path);

            try
            {
                if(!File.Exists(path))
                {
                    using(BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, Strings.RegTLibFailedFileNotFound);
                        output.AddErrorDetail(Strings.Path, path);
                        output.EndWriteError();
                    }
                }
                else
                {
                    IntPtr typeLibPtr = IntPtr.Zero;
                    ITypeLib typeLib = null;
                    try
                    {
                        if (Utils.NativeMethods.LoadTypeLib(path, ref typeLibPtr) != 0 || 
                            typeLibPtr == IntPtr.Zero ||
                            ((typeLib = (ITypeLib)Marshal.GetTypedObjectForIUnknown(typeLibPtr, typeof(ITypeLib))) == null))
                        {
                            using (BatchedOutput output = new BatchedOutput(false))
                            {
                                output.BeginWriteError(0, Strings.RegTLibFailedLoadTypeLibFailed);
                                output.AddErrorDetail(Strings.Path, path);
                                output.EndWriteError();
                            }
                        }
                        else if (Utils.NativeMethods.RegisterTypeLib(typeLib, path, null) != 0)
                        {
                            using (BatchedOutput output = new BatchedOutput(false))
                            {
                                output.BeginWriteError(0, Strings.RegTLibFailedRegisterTypeLibFailed);
                                output.AddErrorDetail(Strings.Path, path);
                                output.EndWriteError();
                            }
                        }
                        else
                        {
                            Program.Output.Write(OutputType.Info, Strings.RegTLibSucceeded);
                            Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:         '{0}'", path));
                        }
                    }
                    finally
                    {
                        if (typeLib != null)
                        {
                            Marshal.ReleaseComObject(typeLib);
                            typeLib = null;
                        }
                        if (typeLibPtr != IntPtr.Zero)
                        {
                            Marshal.Release(typeLibPtr);
                            typeLibPtr = IntPtr.Zero;
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                using(BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, Strings.RegTLibFailed);
                    output.AddErrorDetail(Strings.Path, path);
                    output.AddErrorDetail(Strings.Error, ex.ToString());
                    output.EndWriteError();
                }
            }
        }

        #endregion

        private String _path;
    }
}
