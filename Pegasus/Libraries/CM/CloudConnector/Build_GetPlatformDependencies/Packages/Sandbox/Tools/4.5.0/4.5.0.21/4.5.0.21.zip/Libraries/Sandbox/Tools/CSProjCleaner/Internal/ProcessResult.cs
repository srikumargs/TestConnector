namespace CSProjCleaner.Internal
{
    internal enum ProcessResult
    {
        NoChangesNecessary = 0,
        ChangesApplied,
        Error
    }
}
