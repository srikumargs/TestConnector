﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace CSProjCleaner.Internal
{
    internal struct EngineOptions
    {
        public EngineOptions(Boolean testOnly, ReadOnlyCollection<String> fileFolderSpecifications, Boolean recursive, CSProjFileProcessorOptions processorOptions)
        {
            _testOnly = testOnly;
            _fileFolderSpecifications = fileFolderSpecifications;
            _recursive = recursive;
            _processorOptions = processorOptions;
        }

        public Boolean TestOnly
        { get { return _testOnly; } }

        public ReadOnlyCollection<String> FileFolderSpecifications
        { get { return _fileFolderSpecifications; } }

        public Boolean Recursive
        { get { return _recursive; } }

        public CSProjFileProcessorOptions ProcessorOptions
        { get { return _processorOptions; } }

        private Boolean _testOnly;
        private ReadOnlyCollection<String> _fileFolderSpecifications;
        private Boolean _recursive;
        private CSProjFileProcessorOptions _processorOptions;
    }
}
