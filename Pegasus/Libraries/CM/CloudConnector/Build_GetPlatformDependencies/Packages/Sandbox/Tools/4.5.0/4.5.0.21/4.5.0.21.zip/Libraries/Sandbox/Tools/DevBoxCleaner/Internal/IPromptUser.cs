using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace DevBoxCleaner.Internal
{
    interface IPromptUser
    {
        DialogResult RetryCancel(String text, String caption);
    }
}
