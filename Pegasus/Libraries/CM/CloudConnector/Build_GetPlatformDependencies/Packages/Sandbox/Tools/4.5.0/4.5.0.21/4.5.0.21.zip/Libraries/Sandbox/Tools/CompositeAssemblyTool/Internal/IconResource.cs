using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace CompositeAssemblyTool.Internal
{
    /// <summary>
    /// The IconResource class represents an icon resource. Normally when you 
    /// load an icon the operating system returns an icon image targeted to 
    /// the current display. The IconResource class contains all the images in
    /// the icon resource.
    /// </summary>
    internal sealed class IconResource
    {
        #region Constructors
        /// <summary>
        /// Create an IconResource object to represent the icon resource in the
        /// given library.
        /// </summary>
        unsafe public IconResource(Library library, IntPtr resourceName)
        {
            _resourceName = resourceName;

            // Get the RT_GROUP_ICON resource data.
            IntPtr groupInfo = library.FindResource(_resourceName, NativeMethods.RT_GROUP_ICON);
            IntPtr groupResource = library.LoadResource(groupInfo);
            UInt32 groupResourceSize = library.SizeofResource(groupInfo);

            NativeMethods.MEMICONDIR* directory = (NativeMethods.MEMICONDIR*)Library.LockResource(groupResource);

            // Get the RT_ICON resource data for each icon in the RT_GROUP_ICON.
            _images = new IconImage[directory->wCount];
            for (UInt16 i = 0; i < directory->wCount; ++i)
            {
                NativeMethods.MEMICONDIRENTRY* entry = GetDirectoryEntry(directory, i);

                _images[i] = new IconImage(library, new IntPtr(entry->wId));
            }
        }
        #endregion

        #region Public properties
        /// <summary>
        /// Gets the name of the resource as a string.
        /// </summary>
        public string Text
        {
            get
            {
                if (0 == _text.Length)
                {
                    if (NativeMethods.IS_INTRESOURCE(_resourceName))
                    {
                        _text = _resourceName.ToString();
                    }
                    else
                    {
                        _text = Marshal.PtrToStringAuto(_resourceName);
                    }
                }

                return _text;
            }
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Saves the icon resource to a .ICO file.
        /// </summary>
        public void Save(String fileName)
        {
            Stream stream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None);

            using (BinaryWriter writer = new BinaryWriter(stream))
            {
                WriteHeader(writer);
                WriteDirectoryEntries(writer);
                WriteImages(writer);
            }
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Helper function get the icon directory entry at the given index.
        /// </summary>
        unsafe private static NativeMethods.MEMICONDIRENTRY* GetDirectoryEntry(NativeMethods.MEMICONDIR* directory, UInt16 index)
        {
            NativeMethods.MEMICONDIRENTRY* entry = &directory->arEntries;
            return entry += index;
        }

        /// <summary>
        /// Writes the .ICO file header data to the stream.
        /// </summary>
        private void WriteHeader(BinaryWriter writer)
        {
            // Write the reserved WORD (0).
            UInt16 word = 0;
            writer.Write(word);

            // Write the resource type (1 for icons).
            word = 1;
            writer.Write(word);

            // Write the image count.
            word = (ushort)_images.Length;
            writer.Write(word);
        }

        /// <summary>
        /// Writes the icon directory entries to the stream.
        /// </summary>
        private void WriteDirectoryEntries(BinaryWriter writer)
        {
            for (Int32 i = 0; i < _images.Length; ++i)
            {
                IconImage image = _images[i];
                image.WriteDirectoryEntry(writer, (UInt32)GetIcoImageOffset(i));
            }
        }

        /// <summary>
        /// Writes the icon image data to the stream.
        /// </summary>
        private void WriteImages(BinaryWriter writer)
        {
            for (Int32 i = 0; i < _images.Length; ++i)
            {
                IconImage image = _images[i];
                image.WriteImage(writer);
            }
        }

        /// <summary>
        /// Gets the offset of the image data from the beginning of the .ICO 
        /// file. This is used by WriteDirectoryEntries to write the icon 
        /// directory entries.
        /// </summary>
        private int GetIcoImageOffset(Int32 index)
        {
            // Space for the ICO header.
            Int32 offset = 3 * Marshal.SizeOf(typeof(ushort));

            // Space for the FILEICONDIRENTRY structures.
            offset += _images.Length * Marshal.SizeOf(typeof(NativeMethods.FILEICONDIRENTRY));

            // Space for any preceding images.
            for (Int32 i = 0; i < index; ++i)
            {
                IconImage image = _images[i];
                offset += image.Size;
            }

            return offset;
        }
        #endregion

        #region Private fields
        private IntPtr _resourceName;
        private IconImage[] _images;
        private String _text = string.Empty;
        #endregion
    }
}
