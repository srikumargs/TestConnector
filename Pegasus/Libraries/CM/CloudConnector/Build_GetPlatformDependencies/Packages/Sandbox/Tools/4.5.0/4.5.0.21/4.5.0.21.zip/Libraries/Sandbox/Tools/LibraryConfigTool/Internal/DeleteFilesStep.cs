﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
	internal sealed class DeleteFilesStep : IStep
	{
		public DeleteFilesStep(ConfigInfo configInfo, XPathNavigator navigator)
		{
			_recursive = Utils.GetOptionalAttribute(navigator, Constants.RecursiveAttribute);
			_fileSpec = Utils.GetRequiredAttribute(navigator, Constants.FileSpecAttribute, Constants.DeleteFilesElement, configInfo.ConfigFile);
		}

		#region IStep Members

		public void Execute(ConfigInfo rootConfigInfo)
		{
			String recursive = rootConfigInfo.ReplaceAllVariables(_recursive);
			String fileSpec = rootConfigInfo.ReplaceAllVariables(_fileSpec);

			SearchOption searchOption = SearchOption.TopDirectoryOnly;
			if (!String.IsNullOrEmpty(recursive) && Boolean.Parse(recursive))
			{
				searchOption = SearchOption.AllDirectories;
			}

			String[] fileNames = null;
			String searchPattern = String.Empty;
			if (fileSpec.Contains("*") || fileSpec.Contains("?"))
			{
				searchPattern = fileSpec.Substring(fileSpec.LastIndexOf('\\') + 1);
				fileNames = Directory.GetFiles(fileSpec.Substring(0, fileSpec.LastIndexOf('\\')), searchPattern, searchOption);
			}
			else
			{
				fileNames = new String[] { fileSpec };
			}

			foreach (String fileName in fileNames)
			{
				if(!File.Exists(fileName))
				{
					// nothing to do, the file doesn't exist
					continue;
				}

				if (!String.IsNullOrEmpty(searchPattern) && Utils.FileSpecEndsInConcrete3LetterExtension(searchPattern))
				{
					// The search pattern looks like something with exactly a 3 character extension.
					// We must work around the goofy .NET behavior which will match any file that has an
					// extension that starts with those three character ... but may have more.
					if (!fileName.ToLower(CultureInfo.InvariantCulture).EndsWith(searchPattern.ToLower(CultureInfo.InvariantCulture).Substring(searchPattern.LastIndexOf('.')).ToLower(CultureInfo.InvariantCulture)))
					{
						// skip the file, it is not a true match
						continue;
					}
				}

				try
				{
                    File.SetAttributes(fileName, File.GetAttributes(fileName) & ~FileAttributes.ReadOnly);
                    File.Delete(fileName);

					Program.Output.Write(OutputType.Info, "File deleted succeeded.");
					Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "FileName:      '{0}'", fileName));
				}
				catch (Exception ex)
				{
					using (BatchedOutput output = new BatchedOutput(false))
					{
						output.BeginWriteError(0, "File delete failed.");
						output.AddErrorDetail(Strings.FileName, fileName);
						output.AddErrorDetail(Strings.Error, ex.ToString());
						output.EndWriteError();
					}
				}
			}
		}

		#endregion

		private String _recursive;
		private String _fileSpec;
	}
}
