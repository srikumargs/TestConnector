// (c) 2005 Richard Grimes
// snSig library used to get information about a strong name signature of
// a .NET assembly

using System;
using System.IO;

namespace LibraryConfigTool.Internal
{
    /// <summary>
    /// Used to obtain the file offset and the size of the strong name signature
    /// and the strong name data directory
    /// http://www.grimes.demon.co.uk/workshops/fusionWSCrackThree.htm
    /// </summary>
    internal sealed class StrongNameSignature
    {
        // Locations and sizes of various things in the PE file
        const Int32 pePos = 0x003c;
        const Int32 numSectOffset = 0x02;
        const Int32 peIdentSize = 0x04;
        const Int32 coffHeaderSize = 0x14;
        const Int32 dataDirectoryOffset = 0x60;
        const Int32 dataDirectoryLength = 0x08;
        const Int32 clrHeaderIndex = 0x0e;
        const Int32 strongNameSigOffset = 0x20;
        const Int32 sectionHeaderSize = 0x28;
        const Int32 sectionSizeOffSet = 0x08;
        const Int32 sectionRVAOffset = 0x0c;
        const Int32 sectionRawOffset = 0x14;

        Int32 strongNameSigSize = 0;
        // Returns the size of the strong name signature
        public Int32 Size
        {
            get { return strongNameSigSize; }
        }

        Int32 strongNameSig = 0;
        // Returns the offset in the file of the strong name signature
        public Int32 Address
        {
            get { return strongNameSig; }
        }

        Int32 strongNameDataDirectory = 0;
        // Returns the offset of the strong name data directory
        public Int32 StrongNameDataDirectory
        {
            get { return strongNameDataDirectory; }
        }

        FileStream fs;
        // Passed an open file of a .NET assembly
        public StrongNameSignature(FileStream file)
        {
            fs = file;

            // Find the pointer to the PE identifier before the COFF header 
            Int32 coffHeader = GetInt(pePos);
            // Get the number of sections from the COFF header
            Int16 numSections = GetWord(coffHeader + peIdentSize + numSectOffset);

            // Calculate the location of the PE header
            Int32 peHeader = coffHeader + coffHeaderSize + peIdentSize;
            // Determine the location of the data directories
            Int32 dataDirectories = peHeader + dataDirectoryOffset;
            // Determine the location of the CLR directory
            Int32 clrHeaderDD = dataDirectories + (dataDirectoryLength * clrHeaderIndex);

            // Read the RVA of the CLR header
            Int32 clrHeader = GetInt(clrHeaderDD);
            // Read the size of the CLR header
            Int32 clrHeaderSize = GetInt(clrHeaderDD + 4);

            // Note that CLR header is stored in the .text section, so read this section
            // so that we can convert between RVA and actual file offsets
            Int32 textRVA = 0;
            Int32 textRaw = 0;
            Int32 textSize = 0;
            // Determine the location of the section headers
            Int32 sections = clrHeaderDD + (2 * dataDirectoryLength);
            // Iterate through the section headers until we find the header for the 
            // .text section
            Byte[] bText = { 0x2e, 0x74, 0x65, 0x78, 0x74, 0x00, 0x00, 0x00 };
            for (Int32 idx = 0; idx < numSections; ++idx)
            {
                // Read the first eight bytes which will have the name of the section
                // Note that this is NOT a NUL terminated string, the section name
                // can be 8 characters.
                Int32 sectionStart = sections + (idx * sectionHeaderSize);
                Byte[] eightBuf = GetEightBytes(sectionStart);
                if (!Compare(eightBuf, bText)) continue;

                // We have the right section so get the values
                textSize = GetInt(sectionStart + sectionSizeOffSet);
                textRVA = GetInt(sectionStart + sectionRVAOffset);
                textRaw = GetInt(sectionStart + sectionRawOffset);
            }

            // Convert RVA to file offset
            clrHeader = clrHeader - textRVA + textRaw;
            // Calculate the file offset of the strong name data directory 
            strongNameDataDirectory = clrHeader + strongNameSigOffset;
            // Get the RVA of the strong name signature
            strongNameSig = GetInt(clrHeader + strongNameSigOffset);
            // Convert RVA to file offset
            strongNameSig = strongNameSig - textRVA + textRaw;
            // Get the size of the strong name signature
            strongNameSigSize = GetInt(clrHeader + strongNameSigOffset + 4);
        }

        // Do a character by character comparison
        private static Boolean Compare(Byte[] lhs, Byte[] rhs)
        {
            Int32 size = (lhs.Length > rhs.Length) ? rhs.Length : lhs.Length;
            for (Int32 idx = 0; idx < size; ++idx)
            {
                if (lhs[idx] != rhs[idx]) return false;
            }
            return true;
        }
        // Read a 16-bit value from the file
        private Int16 GetWord(Int32 pos)
        {
            Byte[] wordBuf = new byte[2];
            fs.Seek(pos, SeekOrigin.Begin);
            fs.Read(wordBuf, 0, wordBuf.Length);
            return BitConverter.ToInt16(wordBuf, 0);
        }
        // Read a 32-bit value from the file
        private Int32 GetInt(Int32 pos)
        {
            Byte[] intBuf = new byte[4];
            fs.Seek(pos, SeekOrigin.Begin);
            fs.Read(intBuf, 0, intBuf.Length);
            return BitConverter.ToInt32(intBuf, 0);
        }
        // Read an eight byte array from the file
        private Byte[] GetEightBytes(Int32 pos)
        {
            Byte[] eightBuf = new byte[8];
            fs.Seek(pos, SeekOrigin.Begin);
            fs.Read(eightBuf, 0, eightBuf.Length);
            return eightBuf;
        }
    }
}