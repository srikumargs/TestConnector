﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Collections;
using System.IO;

namespace Alias.Internal
{
    internal sealed class AliasProcessorOptions
    {
        public Boolean Debug
        {
            get { return _debug; }
            set { _debug = value; }
        }

        public Boolean TestOnly
        {
            get { return _testOnly; }
            set { _testOnly = value; }
        }

        public void AddAssemblyNameMapping(String oldName, String newName)
        {
            _assemblyNameMappinngs.Add(oldName, newName);
        }

        public Dictionary<String, String> AssemblyNameMappings
        { get { return _assemblyNameMappinngs; } }

        public void AssociateAssemblyNameToOriginalProjectFileName(String originalAssemblyName, String originalProjectFileName)
        {
            String key = originalAssemblyName.ToLowerInvariant();
            if (!_assemblyNameToOriginalFileNames.ContainsKey(key))
            {
                _assemblyNameToOriginalFileNames.Add(key, new List<String>());
            }

            _assemblyNameToOriginalFileNames[key].Add(originalProjectFileName);
        }

        public ReadOnlyCollection<String> GetOriginalProjectFileNamesForAssemblyName(String originalAssemblyName)
        {
            List<String> result = new List<String>();

            String key = originalAssemblyName.ToLowerInvariant();
            if (_assemblyNameToOriginalFileNames.ContainsKey(key))
            {
                result = _assemblyNameToOriginalFileNames[key];
            }

            return result.AsReadOnly();
        }

        public void SaveOriginalFileNames(String[] fileNames)
        {
            foreach (String fileName in fileNames)
            {
                _fileNameMappings.Add(fileName, fileName);
            }
        }

        public ReadOnlyCollection<String> GetCurrentFileNamesForSuffix(String suffixToMatch)
        {
            List<String> result = new List<String>();

            String suffixToMatchAsLowerInvariant = suffixToMatch.ToLowerInvariant();
            foreach (String fileName in _fileNameMappings.Values)
            {
                if (fileName.ToLowerInvariant().EndsWith(suffixToMatchAsLowerInvariant))
                {
                    result.Add(fileName);
                }
            }

            return result.AsReadOnly();
        }

        public Dictionary<String, String> FileNameMappings
        { get { return _fileNameMappings; } }

        public void UpdateFileName(String oldFileName, String newFileName)
        {
            if (_fileNameMappings.ContainsKey(oldFileName))
            {
                _fileNameMappings[oldFileName] = newFileName;
            }
        }

        public void UpdateFolderLocation(String oldPath, String newPath)
        {
            oldPath += "\\";
            newPath += "\\";
            List<String> keysToUpdate = new List<string>();
            foreach (String originalFileName in _fileNameMappings.Keys)
            {
                if (_fileNameMappings[originalFileName].StartsWith(oldPath))
                {
                    keysToUpdate.Add(originalFileName);
                }
            }

            foreach (String keyToUpdate in keysToUpdate)
            {
                _fileNameMappings[keyToUpdate] = _fileNameMappings[keyToUpdate].Replace(oldPath, newPath);
            }
        }

        private void DebugDictionary(Dictionary<String, List<String>> dictionary, String prefix)
        {
            foreach (KeyValuePair<String, List<String>> key in dictionary)
            {
                System.Diagnostics.Debug.WriteLine(String.Format(CultureInfo.InvariantCulture, "Key: {0}", key.Key));
                foreach (String value in key.Value)
                {
                    System.Diagnostics.Debug.WriteLine(String.Format(CultureInfo.InvariantCulture, "  {0}{1}", prefix, value));
                }
            }
        }

        private Boolean _debug;
        private Boolean _testOnly;
        private Dictionary<String, String> _assemblyNameMappinngs = new Dictionary<String, String>();
        private Dictionary<String, String> _fileNameMappings = new Dictionary<String, String>();
        private Dictionary<String, List<String>> _assemblyNameToOriginalFileNames = new Dictionary<String, List<String>>();
    }
}
