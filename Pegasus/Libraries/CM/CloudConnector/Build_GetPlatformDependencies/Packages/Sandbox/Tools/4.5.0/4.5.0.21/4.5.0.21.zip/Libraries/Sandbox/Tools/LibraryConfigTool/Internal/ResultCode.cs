using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryConfigTool.Internal
{
    [Flags]
    internal enum OutputType
    {
        None    = 0x00,
        Error   = 0x01,
        Info    = 0x02,
        Verbose = 0x04,
        Banner  = 0x08,
        Help    = 0x10,
        Status  = 0x20
    }
}
