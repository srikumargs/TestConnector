﻿using System;
using System.Xml.XPath;
using Microsoft.Win32;

namespace LibraryConfigTool.Internal
{
    internal sealed class RegSetValueStep : IStep
    {
        public RegSetValueStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _keyName = Utils.GetRequiredAttribute(navigator, Constants.KeyNameAttribute, Constants.RegSetValueElement, configInfo.ConfigFile);
            _valueName = Utils.GetRequiredAttribute(navigator, Constants.ValueNameAttribute, Constants.RegSetValueElement, configInfo.ConfigFile);
            _value = Utils.GetRequiredAttribute(navigator, Constants.ValueAttribute, Constants.RegSetValueElement, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String keyName = rootConfigInfo.ReplaceAllVariables(_keyName);
            String valueName = rootConfigInfo.ReplaceAllVariables(_valueName);
            String value = rootConfigInfo.ReplaceAllVariables(_value);

            try
            {
                Registry.SetValue(keyName, valueName, value);
                Program.Output.Write(OutputType.Info, "Registry set value succeeded.");

            }
            catch (Exception ex)
            {
                using (BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, "Failed to set registry value.");
                    output.AddErrorDetail(Constants.KeyNameAttribute, _keyName);
                    output.AddErrorDetail(Constants.ValueNameAttribute, _valueName);
                    output.AddErrorDetail(Constants.ValueAttribute, _value);
                    output.AddErrorDetail(Strings.Error, ex.ToString());
                    output.EndWriteError();
                }
            }
        }

        #endregion

        private String _keyName;
        private String _valueName;
        private String _value;
    }
}
