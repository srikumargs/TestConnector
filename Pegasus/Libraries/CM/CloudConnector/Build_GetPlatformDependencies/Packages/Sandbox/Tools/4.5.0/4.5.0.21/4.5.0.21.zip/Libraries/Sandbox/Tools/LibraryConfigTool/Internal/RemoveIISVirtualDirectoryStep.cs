﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.DirectoryServices;
using System.Globalization;
using System.Xml.XPath;
using System.Diagnostics;

namespace LibraryConfigTool.Internal
{
    internal sealed class RemoveIISVirtualDirectoryStep : IStep
    {

        internal RemoveIISVirtualDirectoryStep(ConfigInfo configInfo, XPathNavigator navigator)
		{
            _virtualFolderName = Utils.GetRequiredAttribute(navigator, Constants.VirtualFolderNameAttribute, Constants.RemoveVirtualDirectoryElement, configInfo.ConfigFile);
		}

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            try
            {
                String fullPathToVirtualDirectory = Constants.ActiveDirectoryPathToIISRoot + "/" + _virtualFolderName;
                if (DirectoryEntry.Exists(fullPathToVirtualDirectory))
                {
                    DirectoryEntry existingEntry = new DirectoryEntry(fullPathToVirtualDirectory);
                    existingEntry.DeleteTree();

                    // make sure that DeleteTree actually removed the directory
                    Debug.Assert(!DirectoryEntry.Exists(fullPathToVirtualDirectory));

                    Program.Output.Write(OutputType.Info, Strings.VirtualDirectoryRemoved);
                }
                else
                {
                    Program.Output.Write(OutputType.Info, Strings.NoVirtualDirectoryToRemove);
                }
                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "IIS virtual directory name:      '{0}'", _virtualFolderName));

            }
            catch (Exception ex)
            {
                using (BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, Strings.RemoveVirtualDirectoryFailed);
                    output.AddErrorDetail(Strings.VirtualDirectory, _virtualFolderName);
                    output.AddErrorDetail(Strings.Error, ex.ToString());
                    output.EndWriteError();
                }
            }
        }

        #endregion

        private String _virtualFolderName;
    }
}
