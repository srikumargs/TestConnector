using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Permissions;
using System.Runtime.Remoting.Messaging;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1812:AvoidUninstantiatedInternalClasses", Justification = "This class is called in a late-bound manner through a subordinate AppDomain.")]
    internal sealed class RemoteDllComServerRegistrar : MarshalByRefObject
    {
        public override object InitializeLifetimeService()
        {
            return null; // prevent leased-based lifetime management
        }

        public void RegisterDllComServer(IMessageSink outputMessageSink, String path)
        {
            _outputMessageSink = outputMessageSink;

            //Assembly libraryManagementAssembly = Assembly.LoadFrom(Path.Combine(Utils.SandboxLocation, Constants.AssembliesSageLS1LibraryManagementDll));
            //if(libraryManagementAssembly != null)
            //{
            //    Type libraryManagerType = libraryManagementAssembly.GetType(Constants.SageConfigurationLibraryManager);
            //    String libraryManifestLocation = (String) libraryManagerType.InvokeMember(Constants.LibraryManifestLocationForBinary, BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static, null, null, new Object[] { path }, CultureInfo.InvariantCulture);
            //    libraryManagerType.InvokeMember(Constants.InitializeLibraries, BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static, null, null, new Object[] { libraryManifestLocation }, CultureInfo.InvariantCulture);
            //}

            DoRegisterComServer(path);
        }

        private void DoRegisterComServer(String path)
        {
            String savedCurrentDirectory = Environment.CurrentDirectory;
            Environment.CurrentDirectory = Path.GetDirectoryName(path);
            IntPtr hModule = IntPtr.Zero;
            try
            {
                hModule = NativeMethods.LoadLibrary(Path.GetFileName(path));
                if(hModule != IntPtr.Zero)
                {
                    IntPtr hProcAddress = NativeMethods.GetProcAddress(hModule, Constants.DllRegisterServer);
                    if(hProcAddress != IntPtr.Zero)
                    {
                        VoidDelegate func = (VoidDelegate) Marshal.GetDelegateForFunctionPointer(hProcAddress, typeof(VoidDelegate));
                        if(func() == 0)
                        {
                            Output(OutputType.Info, Strings.DllRegisterServerInvokeSucceeded);
                            Output(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:        '{0}'", path));
                        }
                        else
                        {
                            throw new Exception(Strings.DllRegisterServerFailed);
                        }
                    }
                    else
                    {
                        throw new Exception(Strings.GetProcAddressFailed);
                    }
                }
                else
                {
                    throw new Exception(Strings.LoadLibraryFailed);
                }
            }
            finally
            {
                Environment.CurrentDirectory = savedCurrentDirectory;

                if(hModule != IntPtr.Zero)
                {
                    NativeMethods.FreeLibrary(hModule);
                }
            }
        }

        private void Output(OutputType outputType, String message)
        {
            Output(outputType, IndentAction.None, message);
        }

        private void Output(OutputType outputType, IndentAction indentAction, String message)
        {
            _outputMessageSink.SyncProcessMessage(new OutputMessage(outputType, indentAction, message));
        }

        private static class NativeMethods
        {
            [DllImport("kernel32")]
            public extern static IntPtr LoadLibrary(String lpLibFileName);

            [DllImport("kernel32")]
            [return: MarshalAs(UnmanagedType.Bool)]
            public extern static Boolean FreeLibrary(IntPtr hLibModule);

            [DllImport("kernel32", CharSet = CharSet.Ansi)]
            public extern static IntPtr GetProcAddress(IntPtr hModule, String lpProcName);
        }

        private delegate Int32 VoidDelegate();
        private IMessageSink _outputMessageSink;
    }
}
