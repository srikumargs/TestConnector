using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

namespace LibraryConfigTool.Internal
{
    internal sealed class EmitDataStep : IStep
    {
        public EmitDataStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _id = Utils.GetRequiredAttribute(navigator, Constants.EmitIdAttribute, Constants.EmitDataElement, configInfo.ConfigFile);
            _writeLine = Utils.GetOptionalAttribute(navigator, Constants.WriteLineAttribute);
            _rawData = navigator.Select(".").Current.Value;
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String id = rootConfigInfo.ReplaceAllVariables(_id);
            Boolean writeLine = (String.IsNullOrEmpty(_writeLine) ? false : Boolean.Parse(rootConfigInfo.ReplaceAllVariables(_writeLine)));
            String rawData = rootConfigInfo.ReplaceAllVariables(_rawData);

            if (writeLine)
            {
                rawData += "\r\n";
            }

            rootConfigInfo.EmitData(id, rawData);
        }

        #endregion

        private String _id;
        private String _writeLine;
        private String _rawData;
    }
}
