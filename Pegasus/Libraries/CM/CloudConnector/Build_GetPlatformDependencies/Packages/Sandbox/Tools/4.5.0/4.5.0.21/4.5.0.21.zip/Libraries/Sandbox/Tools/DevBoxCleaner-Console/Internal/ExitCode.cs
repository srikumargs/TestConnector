﻿namespace DevBoxCleanerConsole.Internal
{
    internal enum ExitCode
    {
        Success = 0,
        OneOrMoreFailuresOccurred = 1
    }
}
