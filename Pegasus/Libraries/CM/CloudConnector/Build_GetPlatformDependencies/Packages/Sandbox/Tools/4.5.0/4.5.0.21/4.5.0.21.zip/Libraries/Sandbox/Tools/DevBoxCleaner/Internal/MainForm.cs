using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace DevBoxCleaner.Internal
{
    enum ResultCode
    {
        None = 0,
        Fail,
        Success,
        Info
    }

    internal sealed partial class MainForm : Form, IPromptUser, IEngineEventsSubscriber
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void _cleanButton_Click(Object sender, EventArgs e)
        {
            StartCleaning();
        }

        private void StartCleaning()
        {
            if(!_engine.IsRunning)
            {
                if(!_testOnlyCheckBox.Checked &&
                    DialogResult.No == MessageBox.Show("Proceed with the clean operation?\n\nWarning:  this will make changes to your local machine!", "Confirm Clean", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                {
                    return;
                }

                if ((_cleanRegistryCheckBox.Checked || _cleanSandboxCheckBox.Checked) && String.IsNullOrEmpty(_sandboxLocationTextBox.Text))
                {
                    MessageBox.Show("Sandbox location is required for cleaning sandbox and/or registry", "Sandbox Location Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                _cleanButton.Text = "&Pause";
                _cleanToolTip = this._toolTip.GetToolTip(this._cleanButton);

                _resultsDataGridView.Rows.Clear();

                AppendResultToResultDataGridView(new ResultEventArgs(ResultCode.Info, _testOnlyCheckBox.Checked ? "Started (test-only)..." : "Started..."));
                EngineOptions engineOptions = new EngineOptions();
                engineOptions.TestOnly = _testOnlyCheckBox.Checked;
                engineOptions.Gac = _cleanGacCheckBox.Checked;
                engineOptions.Registry = _cleanRegistryCheckBox.Checked;
                engineOptions.Sandbox = _cleanSandboxCheckBox.Checked;
                engineOptions.SandboxLocation = _sandboxLocationTextBox.Text;
                _engine.Start(this, this, engineOptions);
            }
            else
            {
                if(!_engine.IsSuspended)
                {
                    _engine.Suspend();
                    _cleanButton.Text = "&Resume";
                    this._toolTip.SetToolTip(this._cleanButton, "Resumes the clean operation which is currently paused.  You can terminate the in-progress Clean by closing the application.");
                }
                else
                {
                    _engine.Resume();
                    _cleanButton.Text = "&Pause";
                    this._toolTip.SetToolTip(this._cleanButton, "Pauses the clean operation which is currently running.  Can be resumed.  You can terminate the in-progress Clean  by closing the application.");
                }
            }
        }

        private void _closeButton_Click(Object sender, EventArgs e)
        {
            Close();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(_engine.IsRunning)
            {
                if(DialogResult.Yes != MessageBox.Show("Clean operation is currently running.  Stop cleaning and close the application?", "Stop Cleaning", MessageBoxButtons.YesNo))
                {
                    e.Cancel = true;
                }
            }
        }

        public void OnStop()
        {
            if(this.InvokeRequired)
            {
                Invoke(new MethodInvoker(OnStop));
            }
            else
            {
                _cleanButton.Text = "C&lean";
                this._toolTip.SetToolTip(this._cleanButton, _cleanToolTip);

                FLASHWINFO fInfo = new FLASHWINFO();

                fInfo.cbSize = (ushort) Marshal.SizeOf(fInfo);
                fInfo.hwnd = this.Handle;
                fInfo.dwFlags = FLASHW_ALL | FLASHW_TIMERNOFG;
                fInfo.uCount = UInt16.MaxValue;
                fInfo.dwTimeout = 0;

                FlashWindowEx(ref fInfo);

                AppendResultToResultDataGridView(new ResultEventArgs(ResultCode.Info, String.Format(CultureInfo.CurrentUICulture, "Finished.  Number of failures: {0}.  Elapsed time:  {1}.", _engine.FailureCount, _engine.RunTime)));

                if(_resultsDataGridView.Rows.Count > 0)
                {
                    _resultsDataGridView.FirstDisplayedScrollingRowIndex = _resultsDataGridView.Rows.Count - 1;
                }
            }
        }

        private void MainForm_Load(Object sender, EventArgs e)
        {
            this.Text += " v" + FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion;
            this.comboBox1.SelectedIndex = 1;

            _resultsDataGridView.CellContentClick += new DataGridViewCellEventHandler(_resultsDataGridView_CellContentClick);

            _sandboxLocationTextBox.Text = Environment.GetEnvironmentVariable("SAGE_SANDBOX");
            if(String.IsNullOrEmpty(_sandboxLocationTextBox.Text))
            {
                // pre 9.5.22
                _sandboxLocationTextBox.Text = Environment.GetEnvironmentVariable("TS_SANDBOX");
            }
        }

        void _resultsDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.ColumnIndex == 2)
            {
                ThreadPool.QueueUserWorkItem(new WaitCallback(DisplayErrorDetailsThreadFunction), _resultsDataGridView.Rows[e.RowIndex].Cells[1].Value + "\r\n\r\n" + (_resultsDataGridView.Rows[e.RowIndex].Cells[3].Value as ResultEventArgs).Details);
            }
        }

        void DisplayErrorDetailsThreadFunction(object args)
        {
            String tempFileName = Path.GetTempFileName();
            using(StreamWriter streamWriter = new StreamWriter(tempFileName, false))
            {
                streamWriter.Write((String) args);
            }

            try
            {
                String notepadPath = Path.Combine(Environment.GetEnvironmentVariable("WINDIR"), @"notepad");

                Process notepadProcess;
                using(notepadProcess = new Process())
                {
                    notepadProcess.StartInfo.FileName = notepadPath;

                    notepadProcess.StartInfo.Arguments = tempFileName;
                    notepadProcess.StartInfo.CreateNoWindow = true;
                    notepadProcess.StartInfo.UseShellExecute = false;
                    notepadProcess.StartInfo.RedirectStandardInput = true;
                    notepadProcess.StartInfo.RedirectStandardOutput = true;
                    notepadProcess.StartInfo.RedirectStandardError = true;
                    notepadProcess.Start();
                    String output = notepadProcess.StandardOutput.ReadToEnd();
                    notepadProcess.WaitForExit();
                }
            }
            finally
            {
                File.Delete(tempFileName);
            }
        }

        public void OnAppendResult(Object sender, ResultEventArgs args)
        {
            AppendResultToResultDataGridView(args);
        }

        private delegate void ResultDelegate(ResultEventArgs args);

        private void AppendResultToResultDataGridView(ResultEventArgs args)
        {
            if(this.InvokeRequired)
            {
                Invoke(new ResultDelegate(AppendResultToResultDataGridView), args);
            }
            else
            {
                DataGridViewRow row = new DataGridViewRow();
                switch(args.Code)
                {
                    case ResultCode.None:
                        row.Visible = (comboBox1.SelectedIndex == 0);
                        row.CreateCells(_resultsDataGridView, _imageList.Images[0], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        row.Cells[2] = new DataGridViewTextBoxCell();
                        break;
                    case ResultCode.Fail:
                        row.Visible = true;
                        row.CreateCells(_resultsDataGridView, _imageList.Images[1], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        break;
                    case ResultCode.Success:
                        row.Visible = (comboBox1.SelectedIndex == 0);
                        row.CreateCells(_resultsDataGridView, _imageList.Images[2], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        row.Cells[2] = new DataGridViewTextBoxCell();
                        break;
                    case ResultCode.Info:
                        row.Visible = true;
                        row.CreateCells(_resultsDataGridView, _imageList.Images[3], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        row.Cells[2] = new DataGridViewTextBoxCell();
                        break;
                }

                //if(_resultsDataGridView.Rows.Count > _resultsDataGridView.DisplayedRowCount(false))
                //{
                //    _resultsDataGridView.FirstDisplayedScrollingRowIndex = _resultsDataGridView.Rows.Count - _resultsDataGridView.DisplayedRowCount(false);
                //}
                //_resultsDataGridView.CurrentCell = _resultsDataGridView.Rows[_resultsDataGridView.Rows.Count - 1].Cells[0];
                //Application.DoEvents();
            }
        }

        private delegate DialogResult PromptUserDelegate(String text, String caption);
        public DialogResult RetryCancel(String text, String caption)
        {
            DialogResult result = DialogResult.None;

            if(this.InvokeRequired)
            {
                result = (DialogResult) Invoke(new PromptUserDelegate(RetryCancel), text, caption);
            }
            else
            {
                result = MessageBox.Show(text, caption, MessageBoxButtons.RetryCancel);
            }

            return result;
        }

        [DllImport("user32.dll")]
        static extern Int16 FlashWindowEx(ref FLASHWINFO pwfi);

        [StructLayout(LayoutKind.Sequential)]
        public struct FLASHWINFO
        {
            public UInt16 cbSize;
            public IntPtr hwnd;
            public UInt32 dwFlags;
            public UInt16 uCount;
            public UInt32 dwTimeout;
        }

        //Stop flashing. The system restores the window to its original state. 
        public const UInt32 FLASHW_STOP = 0;
        //Flash the window caption. 
        public const UInt32 FLASHW_CAPTION = 1;
        //Flash the taskbar button. 
        public const UInt32 FLASHW_TRAY = 2;
        //Flash both the window caption and taskbar button.
        //This is equivalent to setting the FLASHW_CAPTION | FLASHW_TRAY flags. 
        public const UInt32 FLASHW_ALL = 3;
        //Flash continuously, until the FLASHW_STOP flag is set. 
        public const UInt32 FLASHW_TIMER = 4;
        //Flash continuously until the window comes to the foreground. 
        public const UInt32 FLASHW_TIMERNOFG = 12;

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                ResultEventArgs args;
                foreach(DataGridViewRow row in _resultsDataGridView.Rows)
                {
                    if(comboBox1.SelectedIndex == 0)
                    {
                        row.Visible = true;
                    }
                    else
                    {
                        args = (row.Cells[3].Value as ResultEventArgs);
                        row.Visible = (args.Code == ResultCode.Info || args.Code == ResultCode.Fail);
                    }
                }
            }
            finally
            {
                this.Cursor = Cursors.Default;
                if(_resultsDataGridView.Rows.Count > 0)
                {
                    _resultsDataGridView.FirstDisplayedScrollingRowIndex = 0;
                }
            }
        }

        #region Private fields
        private String _cleanToolTip;
        private Engine _engine = new Engine();
        #endregion
    }
}