using System;
using System.Collections.Generic;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using System.Reflection;

namespace DevBoxCleaner.Internal
{
    internal sealed class SandboxFilesCleaner : Cleaner
    {
        #region Fields

        /// <summary>
        /// The list of files to exempt from cleaning.
        /// </summary>
        private static StringCollection _exemptFiles = new StringCollection();

        /// <summary>
        /// The set of directories to exempt from cleaning.
        /// </summary>
        private static List<string> _exemptDirectories = new List<string>();

        /// <summary>
        /// The starting path or location.
        /// </summary>
        private String _location;

        #endregion

        static SandboxFilesCleaner()
        {
            // make those files that not built to the list of exemptions
            _exemptFiles.Add("icsharpcode.sharpziplib.dll");
            _exemptFiles.Add("dbgview.exe");
            _exemptFiles.Add("devboxcleaner.exe");
            _exemptFiles.Add("devboxcleaner.pdb");
            _exemptFiles.Add("devboxcleaner-console.exe");
            _exemptFiles.Add("devboxcleaner-console.pdb");
            _exemptFiles.Add("mspview.exe");
            _exemptFiles.Add("regtlib.exe");
            _exemptFiles.Add("setx.exe");
        }

        public SandboxFilesCleaner(String location)
            : this(location, null)
        { }

        public SandboxFilesCleaner(String location, IList<string> exemptPaths)
        {
            _location = location;

            if (exemptPaths != null)
            {
                foreach (string path in exemptPaths)
                {
                    // Catch bad args...
                    if (string.IsNullOrEmpty(path))
                    {
                        continue;
                    }

                    // Assume that any path with an extension is an excluded file.
                    if (System.IO.Path.HasExtension(path))
                    {
                        string file = System.IO.Path.GetFileName(path);

                        if (!CheckIsExemptFile(file))
                        {
                            _exemptFiles.Add(file.ToLower());
                        }
                    }
                    else
                    {
                        string directory = path;

                        if (!CheckIsExemptDirectory(directory))
                        {
                            CreatePathNoTrailingSlash(ref directory);
                            _exemptDirectories.Add(directory.ToLower());
                        }
                    }
                }
            }
        }

        protected override void DoExecute()
        {
            FireAppendResult(ResultCode.Info, "Cleaning sandbox files...");

            if (String.IsNullOrEmpty(_location) || !Directory.Exists(_location))
            {
                FireAppendResult(ResultCode.Info, "No sandbox location specified or location does not exist; skipping cleaning of sandbox files.");
                return;
            }

            // pre STO 9.5.20
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "tsOffice"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Desktop"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "lib"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "PSG\\lib"));

            // STO 9.5.21 and beyond
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Library Sets\\STO\\Libraries\\Legacy\\tsOffice"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Library Sets\\STO\\Libraries\\Legacy\\Desktop"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Library Sets\\STO\\Libraries\\Legacy\\lib"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Library Sets\\STO\\Libraries\\Legacy\\PSG\\lib"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Type Libraries"));

            // Current
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Assemblies"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Build"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Deployments"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Runtime Files\\Program Files"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Runtime Files\\GAC"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "Tools\\Bin"));
            DeleteBuildProductFilesFromTargetFolder(Path.Combine(_location, "TLBs"));

            DeleteProjectIntermediateSubFolders(_location);
            DeleteLibraryBuildProductFolders(_location);
        }

        private DialogResult RetryCancelGetFiles(String path, String searchPattern, SearchOption searchOption, out String[] files)
        {
            DialogResult result = DialogResult.None;
            files = null;
            do
            {
                try
                {
                    files = Directory.GetFiles(path, searchPattern, searchOption);
                    result = DialogResult.OK;
                }
                catch (Exception ex)
                {
                    result = PromptUser.RetryCancel("An error was encounterred during GetFiles('" + path + "', ...).\n\nMessage: " + ex.Message, "Error During GetFiles");
                }
            } while (result == DialogResult.Retry);

            return result;
        }

        private void DeleteLibraryBuildProductFolders(String folder)
        {
            FireAppendResult(ResultCode.Info, "Scanning '" + folder + "' for library build product folders...");

            String[] libraryConfigFiles = null;
            if (DialogResult.Cancel == RetryCancelGetFiles(folder, "LibraryConfig-Library.xml", SearchOption.AllDirectories, out libraryConfigFiles))
            {
                return;
            }

            Int32 count = 0;
            foreach (String file in libraryConfigFiles)
            {
                count += DeleteSubFolderFromFolder(Path.GetDirectoryName(file), "WiX");
                count += DeleteSubFolderFromFolder(Path.GetDirectoryName(file), "Publish");
            }
            FireAppendResult(ResultCode.Info, "Deleted " + count + " library build product folders.");
        }

        private void DeleteProjectIntermediateSubFolders(String folder)
        {
            // Skip any directory marked as exempt
            if (CheckIsExemptDirectory(folder))
            {
                return;
            }

            FireAppendResult(ResultCode.Info, "Scanning '" + folder + "' for intermediate project folders...");

            String[] projectFiles = null;
            if (DialogResult.Cancel == RetryCancelGetFiles(folder, "*.*proj", SearchOption.AllDirectories, out projectFiles))
            {
                return;
            }

            Int32 count = 0;
            foreach (String file in projectFiles)
            {
                count += DeleteSubFolderFromFolder(Path.GetDirectoryName(file), "bin");
                count += DeleteSubFolderFromFolder(Path.GetDirectoryName(file), "obj");
                count += DeleteSubFolderFromFolder(Path.GetDirectoryName(file), "debug");
                count += DeleteSubFolderFromFolder(Path.GetDirectoryName(file), "release");

                String projectFolder = Path.GetDirectoryName(file);
                FireAppendResult(ResultCode.Info, "Scanning for XML documentation files in '" + projectFolder + "'...");

                count = DeleteXmlDocFilesFromTargetFolder(projectFolder);

                FireAppendResult(ResultCode.Info, "Deleted " + count + " XML documentation files in '" + projectFolder + "'.");
            }
            FireAppendResult(ResultCode.Info, "Deleted " + count + " intermediate project folders.");
        }

        private Int32 DeleteSubFolderFromFolder(String folder, String subfolder)
        {
            Int32 result = 0;
            String[] directories = Directory.GetDirectories(folder, subfolder, SearchOption.TopDirectoryOnly);
            if (directories.GetLength(0) > 0)
            {
                string directory = directories[0];

                // Skip any directory marked as exempt
                if (!CheckIsExemptDirectory(directory))
                {
                    try
                    {
                        if (!TestOnly)
                        {
                            Directory.Delete(directory, true);
                        }
                        result++;
                        FireAppendResult(ResultCode.Success, "Directory.Delete('" + directory + "')");
                    }
                    catch (Exception ex)
                    {
                        FireAppendResult(ResultCode.Fail, "Directory.Delete('" + directory + "')", ex.ToString());
                    }
                }
            }

            return result;
        }

        private void DeleteBuildProductFilesFromTargetFolder(String folder)
        {
            // Skip any directory marked as exempt
            if (CheckIsExemptDirectory(folder))
            {
                return;
            }

            FireAppendResult(ResultCode.Info, "Scanning for Build Product Files in '" + folder + "'...");

            if (!Directory.Exists(folder))
            {
                FireAppendResult(ResultCode.Info, "Folder '" + folder + "' does not exist.");
                return;
            }

            int count = 0;
            String[] files = Directory.GetFiles(folder, "*.dll", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.exe", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.pdb", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.lib", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.tlb", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.ilk", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.exp", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.fbpinf", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.fbl6", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.wixlib", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.wixpdb", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.msm", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            files = Directory.GetFiles(folder, "*.msi", SearchOption.AllDirectories);
            count += DeleteFiles(files);

            FireAppendResult(ResultCode.Info, "Deleted " + count + " Build Product Files in '" + folder + "'.");


            FireAppendResult(ResultCode.Info, "Scanning for XML documentation files in '" + folder + "'...");

            count = DeleteXmlDocFilesFromTargetFolder(folder);

            FireAppendResult(ResultCode.Info, "Deleted " + count + " XML documentation files in '" + folder + "'.");
        }

        private int DeleteXmlDocFilesFromTargetFolder(String folder)
        {
            // Skip any directory marked as exempt
            if (CheckIsExemptDirectory(folder))
            {
                return 0;
            }

            Int32 count = 0;
            String[] xmlFiles = Directory.GetFiles(folder, "*.xml", SearchOption.AllDirectories);
            ArrayList filesCollection = new ArrayList();
            XmlDocument document = new XmlDocument();
            foreach (String s in xmlFiles)
            {
                try
                {
                    document.Load(s);
                    if (document.SelectSingleNode("/doc") != null &&
                        document.SelectSingleNode("/doc/assembly") != null &&
                        document.SelectSingleNode("/doc/assembly/name") != null &&
                        document.SelectSingleNode("/doc/members") != null)
                    {
                        filesCollection.Add(s);
                    }
                }
                catch (Exception ex)
                {
                    FireAppendResult(ResultCode.Fail, "Failed to load XML file '" + s + ";  file will not be deleted.", ex.ToString());
                }
            }
            count = DeleteFiles((String[])filesCollection.ToArray(typeof(String)));
            return count;
        }

        private Int32 DeleteFiles(String[] files)
        {
            Int32 result = 0;

            foreach (String file in files)
            {
                if (_exemptFiles.Contains(Path.GetFileName(file).ToLower()))
                {
                    // skip any files marked as exempt
                    continue;
                }

                try
                {
                    if (!TestOnly)
                    {
                        File.SetAttributes(file, FileAttributes.Normal);
                        File.Delete(file);
                    }
                    result++;
                    FireAppendResult(ResultCode.Success, "File.Delete('" + file + "')");
                }
                catch (Exception ex)
                {
                    FireAppendResult(ResultCode.Fail, "File.Delete('" + file + "')", ex.ToString());
                }
            }

            return result;
        }

        private static void CreatePathNoTrailingSlash(ref string path)
        {
            if (path.EndsWith(System.IO.Path.DirectorySeparatorChar.ToString()) ||
                path.EndsWith(System.IO.Path.AltDirectorySeparatorChar.ToString()))
            {
                path = path.Substring(0, path.Length - 1);
            }
        }

        private bool CheckIsExemptFile(string path)
        {
            return _exemptFiles.Contains(path.ToLower());
        }

        private bool CheckIsExemptDirectory(string path)
        {
            string pathNoTrailingSlash = path;
            CreatePathNoTrailingSlash(ref pathNoTrailingSlash);
            pathNoTrailingSlash = pathNoTrailingSlash.ToLower();

            // Replace the path with this exclusion path to determine if it's a sub-directory.
            return _exemptDirectories.Exists(delegate(string excludePath)
            {
                string temp = pathNoTrailingSlash.Replace(excludePath, string.Empty);

                if (temp.Length == 0 || temp.Length < pathNoTrailingSlash.Length)
                {
                    FireAppendResult(ResultCode.Info, "Skipping exempt directory '" + path + "'...");
                    return true;
                }

                return false;
            });
        }
    }
}
