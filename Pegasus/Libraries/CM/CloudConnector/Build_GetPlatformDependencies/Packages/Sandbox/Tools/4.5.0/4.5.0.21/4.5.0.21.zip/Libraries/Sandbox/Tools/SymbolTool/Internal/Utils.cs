﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace SymbolTool.Internal
{
    /// <summary>
    /// Defines static methods for common routines
    /// </summary>
    public static class Utils
    {
        #region GetTopLevelFiles

        /// <summary>
        /// Gets a list of all files from the specified top-level directory.
        /// </summary>
        public static IEnumerable<FileInfo> GetTopLevelFiles(string directory)
        {
            return GetTopLevelFiles(directory, null);
        }

        /// <summary>
        /// Gets a list of files from the specified directory that should be candidates for symbol server indexing or publishing.
        /// </summary>
        public static IEnumerable<FileInfo> GetTopLevelFiles(string directory, IList<string> extensions)
        {
            IEnumerable<FileInfo> files = null;
            DirectoryInfo di = new DirectoryInfo(directory);

            if (extensions == null)
            {
                files = di.EnumerateFiles("*", System.IO.SearchOption.AllDirectories);
            }
            else
            {
                files = di.EnumerateFiles("*", System.IO.SearchOption.AllDirectories)
                          .Where(f => extensions.Contains(f.Extension.ToLower(CultureInfo.CurrentCulture)))
                          .ToArray();
            }

            return files;
        }

        #endregion

        #region SearchTransaction

        /// <summary>
        /// Search the list of transactions for the specified one.
        /// </summary>
        /// <param name="transactions">The list of transactions.</param>
        /// <param name="transactionId">The transaction Id to search.</param>
        /// <returns>Returns the transaction if found; otherwise, null.</returns>
        public static SymbolTransaction SearchTransaction(IList<SymbolTransaction> transactions, string transactionId)
        {
            return transactions.ToList().Find(x => string.Compare(x.TransactionId, transactionId, true, CultureInfo.InvariantCulture) == 0);
        }

        #endregion

        #region ReadTransactions

        // 0000000001,add,file,11/08/2011,10:52:35,"Sage Estimating","11.2.0.2","",
        // string fullPath = @"C:\Estimating Symbols\000Admin\";

        /// <summary>
        /// Gets a list of all symbol history transactions from the specified symbol store.
        /// </summary>
        /// <param name="fullPathSymbolServer">The full path to the symbol store.</param>
        /// <returns>Returns the list of transactions.</returns>
        public static IList<SymbolTransaction> ReadTransactions(string fullPathSymbolServer)
        {
            List<SymbolTransaction> transactions = new List<SymbolTransaction>();
            string historyLogPath = System.IO.Path.Combine(fullPathSymbolServer, "000Admin");
            historyLogPath = System.IO.Path.Combine(historyLogPath, "history.txt");

            if (System.IO.File.Exists(historyLogPath))
            {
                string[] linesArr = System.IO.File.ReadAllLines(historyLogPath);

                if (linesArr != null)
                {
                    foreach (string line in linesArr)
                    {
                        transactions.Add(new SymbolTransaction(fullPathSymbolServer, line));
                    }
                }
            }

            // Hunt down all of the Delete transactions and then find the original Add transaction so it can be marked.
            foreach (SymbolTransaction transaction in transactions)
            {
                if (transaction.Action == TransactionAction.Delete)
                {
                    SymbolTransaction deletedTransaction = SearchTransaction(transactions, transaction.DeletedTransactionId);

                    if (deletedTransaction != null)
                    {
                        // This will identify the fact that this Add tranaction was later deleted.
                        deletedTransaction.HasBeenDeleted = true;
                    }
                }
            }

            return transactions;
        }

        #endregion

        #region SearchOlderThan

        /// <summary>
        /// Searches all symbol history transactions from the specified symbol store that are older than the specified number of days.
        /// </summary>
        /// <param name="fullPathSymbolServer">The full path to the symbol store.</param>
        /// <param name="numDays">Specify the number of days to search.</param>
        /// <returns>Returns the list of transactions.</returns>
        public static IList<SymbolTransaction> SearchOlderThan(string fullPathSymbolServer, int numDays)
        {
            List<SymbolTransaction> olderTransactions = new List<SymbolTransaction>();

            foreach (SymbolTransaction transaction in ReadTransactions(fullPathSymbolServer))
            {
                TimeSpan diff = DateTime.Today - transaction.TransactionDate;

                if (diff.Days >= numDays)
                {
                    olderTransactions.Add(transaction);
                }
            }

            return olderTransactions;
        }

        #endregion
    }
}
