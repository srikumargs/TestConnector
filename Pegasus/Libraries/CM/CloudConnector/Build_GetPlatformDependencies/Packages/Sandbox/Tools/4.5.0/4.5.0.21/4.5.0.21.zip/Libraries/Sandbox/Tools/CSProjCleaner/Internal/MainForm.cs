﻿using System;
using System.Collections.ObjectModel;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Globalization;

namespace CSProjCleaner.Internal
{
    internal partial class MainForm : Form, IEngineEventsSubscriber
    {
        public MainForm()
        {
            InitializeComponent();
        }

        public MainForm(ReadOnlyCollection<String> fileNameSpecifications, Boolean recursive)
        {
            _fileNameSpecifications = fileNameSpecifications;
            _recursive = recursive;

            InitializeComponent();
        }

        #region IEngineEventsSubscriber Members

        public void OnWorkProgress(object sender, WorkProgressEventArgs args)
        {
            if (this.InvokeRequired)
            {
                Invoke(new EventHandler<WorkProgressEventArgs>(OnWorkProgress), sender, args);
            }
            else
            {
                DataGridViewRow row = new DataGridViewRow();
                switch (args.Code)
                {
                    case WorkProgressCode.None:
                        row.Visible = true;
                        row.CreateCells(_resultsDataGridView, _imageList.Images[0], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        row.Cells[2] = new DataGridViewTextBoxCell();
                        break;
                    //case ResultCode.Fail:
                    //    row.Visible = true;
                    //    row.CreateCells(_resultsDataGridView, _imageList.Images[1], args.Description, null, args);
                    //    _resultsDataGridView.Rows.Add(row);
                    //    break;
                    //case ResultCode.Success:
                    //    row.Visible = (comboBox1.SelectedIndex == 0);
                    //    row.CreateCells(_resultsDataGridView, _imageList.Images[2], args.Description, null, args);
                    //    _resultsDataGridView.Rows.Add(row);
                    //    row.Cells[2] = new DataGridViewTextBoxCell();
                    //    break;
                    case WorkProgressCode.File:
                        row.Visible = true;
                        row.CreateCells(_resultsDataGridView, _imageList.Images[4], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        row.Cells[2] = new DataGridViewTextBoxCell();
                        break;
                    case WorkProgressCode.Edit:
                        row.Visible = true;
                        row.CreateCells(_resultsDataGridView, _imageList.Images[5], args.Description, null, args);
                        _resultsDataGridView.Rows.Add(row);
                        row.Cells[2] = new DataGridViewTextBoxCell();
                        break;
                }
            }
        }

        public void OnStop()
        {
            if (this.InvokeRequired)
            {
                Invoke(new MethodInvoker(OnStop));
            }
            else
            {
                _cleanButton.Text = "C&lean";
                this._toolTip.SetToolTip(this._cleanButton, _cleanToolTip);

                FLASHWINFO fInfo = new FLASHWINFO();

                fInfo.cbSize = (ushort)Marshal.SizeOf(fInfo);
                fInfo.hwnd = this.Handle;
                fInfo.dwFlags = FLASHW_ALL | FLASHW_TIMERNOFG;
                fInfo.uCount = UInt16.MaxValue;
                fInfo.dwTimeout = 0;

                FlashWindowEx(ref fInfo);

                OnWorkProgress(this, new WorkProgressEventArgs(WorkProgressCode.None, String.Format(CultureInfo.CurrentUICulture, "Finished.  Number of failures: {0}.  Elapsed time:  {1}.", _engine.FailureCount, _engine.RunTime)));

                if (_resultsDataGridView.Rows.Count > 0)
                {
                    _resultsDataGridView.FirstDisplayedScrollingRowIndex = _resultsDataGridView.Rows.Count - 1;
                }
            }
        }

        #endregion

        private void MainForm_Load(object sender, EventArgs e)
        {
            if (_fileNameSpecifications != null && _fileNameSpecifications.Count == 1 && !_recursive)
            {
                _fileTextBox.Text = _fileNameSpecifications[0];
                _fileRadioButton.Checked = true;
            }
            else
            {
                _rootFolderTextBox.Text = System.Environment.CurrentDirectory;
                _rootFolderRadioButton.Checked = true;
                _recursiveCheckBox.Checked = _recursive;
            }
            FileFolderRadioButtonCheckedChanged();
        }

        private void _cleanButton_Click(object sender, EventArgs e)
        {
            if (!_engine.IsRunning)
            {
                //if (!_testOnlyCheckBox.Checked &&
                //    DialogResult.No == MessageBox.Show("Proceed with the clean operation?\n\nWarning:  this will make changes to your local machine!", "Confirm Clean", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                //{
                //    return;
                //}

                _cleanButton.Text = "&Pause";
                _cleanToolTip = this._toolTip.GetToolTip(this._cleanButton);

                _resultsDataGridView.Rows.Clear();

                OnWorkProgress(this, new WorkProgressEventArgs(WorkProgressCode.None, /*_testOnlyCheckBox.Checked ? "Started (test-only)..." :*/ "Started..."));
                String fileSpecification = (_fileRadioButton.Checked) ? _fileTextBox.Text : _rootFolderTextBox.Text;
                _engine.Start(null, this, new EngineOptions(false, new ReadOnlyCollection<String>(new String[] {fileSpecification}), _recursiveCheckBox.Checked, optionsControl1.PopulateOptions()));
            }
            else
            {
                if (!_engine.IsSuspended)
                {
                    _engine.Suspend();
                    _cleanButton.Text = "&Resume";
                    this._toolTip.SetToolTip(this._cleanButton, "Resumes the clean operation which is currently paused.  You can terminate the in-progress Clean by closing the application.");
                }
                else
                {
                    _engine.Resume();
                    _cleanButton.Text = "&Pause";
                    this._toolTip.SetToolTip(this._cleanButton, "Pauses the clean operation which is currently running.  Can be resumed.  You can terminate the in-progress Clean by closing the application.");
                }
            }
        }

        private void _fileBrowseButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.AddExtension = true;
            dialog.AutoUpgradeEnabled = true;
            dialog.CheckFileExists = true;
            dialog.CheckPathExists = true;
            dialog.DefaultExt = ".csproj";
            dialog.Filter = "C# project files (*.csproj)|*.csproj|All files (*.*)|*.*";
            dialog.InitialDirectory = _rootFolderTextBox.Text;
            dialog.Multiselect = false;
            dialog.SupportMultiDottedExtensions = true;
            dialog.Title = "Select C# Project File";
            dialog.ValidateNames = true;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                _fileTextBox.Text = dialog.FileName;
            }
        }

        private void _fileRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            FileFolderRadioButtonCheckedChanged();
        }

        private void _rootFolderBrowseButton_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.ShowNewFolderButton = false;
            dialog.Description = "Select the parent folder continaing C# project file(s):";
            dialog.RootFolder = Environment.SpecialFolder.MyComputer;
            dialog.SelectedPath = _rootFolderTextBox.Text;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                _rootFolderTextBox.Text = dialog.SelectedPath;
            }
        }

        private void _rootFolderRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            FileFolderRadioButtonCheckedChanged();
        }

        private void FileFolderRadioButtonCheckedChanged()
        {
            _fileTextBox.Enabled = _fileRadioButton.Checked;
            _fileBrowseButton.Enabled = _fileRadioButton.Checked;
            _rootFolderTextBox.Enabled = !_fileRadioButton.Checked;
            _rootFolderBrowseButton.Enabled = !_fileRadioButton.Checked;
            _recursiveCheckBox.Enabled = !_fileRadioButton.Checked;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_engine.IsRunning)
            {
                if (DialogResult.Yes != MessageBox.Show("Clean operation is currently running.  Stop cleaning and close the application?", "Stop Cleaning", MessageBoxButtons.YesNo))
                {
                    e.Cancel = true;
                }
            }
        }

        private void _closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        [DllImport("user32.dll")]
        static extern Int16 FlashWindowEx(ref FLASHWINFO pwfi);

        [StructLayout(LayoutKind.Sequential)]
        public struct FLASHWINFO
        {
            public UInt16 cbSize;
            public IntPtr hwnd;
            public UInt32 dwFlags;
            public UInt16 uCount;
            public UInt32 dwTimeout;
        }

        //Stop flashing. The system restores the window to its original state. 
        public const UInt32 FLASHW_STOP = 0;
        //Flash the window caption. 
        public const UInt32 FLASHW_CAPTION = 1;
        //Flash the taskbar button. 
        public const UInt32 FLASHW_TRAY = 2;
        //Flash both the window caption and taskbar button.
        //This is equivalent to setting the FLASHW_CAPTION | FLASHW_TRAY flags. 
        public const UInt32 FLASHW_ALL = 3;
        //Flash continuously, until the FLASHW_STOP flag is set. 
        public const UInt32 FLASHW_TIMER = 4;
        //Flash continuously until the window comes to the foreground. 
        public const UInt32 FLASHW_TIMERNOFG = 12; 
        
        private Engine _engine = new Engine();
        private String _cleanToolTip;
        private ReadOnlyCollection<String> _fileNameSpecifications;
        private Boolean _recursive;
    }
}
