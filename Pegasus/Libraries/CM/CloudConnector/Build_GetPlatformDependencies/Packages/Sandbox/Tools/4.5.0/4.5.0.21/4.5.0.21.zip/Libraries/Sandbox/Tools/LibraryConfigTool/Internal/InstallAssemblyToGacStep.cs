using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Xml.XPath;

namespace LibraryConfigTool.Internal
{
	internal sealed class InstallAssemblyToGacStep : IStep
	{
		public InstallAssemblyToGacStep(ConfigInfo configInfo, XPathNavigator navigator)
		{
			_path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, Constants.InstallAssemblyToGacElement, configInfo.ConfigFile);
		}

		#region IStep Members

		public void Execute(ConfigInfo rootConfigInfo)
		{
			String path = rootConfigInfo.ReplaceAllVariables(_path);

			try
			{
				if (!File.Exists(path))
				{
					using (BatchedOutput output = new BatchedOutput(false))
					{
						output.BeginWriteError(0, Strings.GACInstallationOfAssemblyFailedFileNotFound);
						output.AddErrorDetail(Strings.Path, path);
						output.EndWriteError();
					}
				}
				else
				{
					// The above GacInstall does not throw an error in all possible situations (E.g., failed
					// because the assembly wasn't strong-named). Verify that the assembly in the GAC actually is 
					// the same as the one we just tried to install.
					AssemblyName assemblyName = AssemblyName.GetAssemblyName(path);
					String assemblyNameAsString = String.Empty;
					if (assemblyName.ProcessorArchitecture == ProcessorArchitecture.None)
					{
						// for 1.0/1.1 assemblies, the full name of the assembly does not include the ProcessorArchitecture
						assemblyNameAsString = assemblyName.FullName;
					}
					else
					{
						// for 2.0 and above, the full name of the assembly includes ProcessorArchitecture
						assemblyNameAsString = String.Format("{0}, ProcessorArchitecture={1}", assemblyName.FullName, ProcessorArchitectureAsString(assemblyName.ProcessorArchitecture));
					}

					ASSEMBLY_INFO assemblyInfo = Gac.QueryAssemblyInfo(assemblyNameAsString);
					if (!String.IsNullOrEmpty(assemblyInfo.currentAssemblyPath))
					{
						try
						{
							// First attempt to uninstall any assembly in the GAC with the same name.
							// This helps protect against assemblies with the same assembly version number, but higher
							// file versions ... which wouldn't get overwritten by publish.GacInstall()
							Gac.RemoveAssemblyFromCache(assemblyNameAsString);
						}
						catch (Exception ex)
						{
							Program.Output.Write(OutputType.Info, "GAC uninstallation of assembly (prior to installation) failed.");
							Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:        '{0}'", assemblyInfo.currentAssemblyPath));
							Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Error:       '{0}'", ex.ToString()));
						}
					}

					Gac.AddAssemblyToCache(path);

					assemblyInfo = Gac.QueryAssemblyInfo(assemblyNameAsString);
					if (!String.IsNullOrEmpty(assemblyInfo.currentAssemblyPath) && CompareByteArrays(File.ReadAllBytes(path), File.ReadAllBytes(assemblyInfo.currentAssemblyPath)))
					{
						Program.Output.Write(OutputType.Info, "GAC installation of assembly succeeded.");
						Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:        '{0}'", path));
					}
					else
					{
						using (BatchedOutput output = new BatchedOutput(false))
						{
							output.BeginWriteError(0, Strings.GACInstallationOfAssemblyFailed);
							output.AddErrorDetail(Strings.Path, path);
							output.AddErrorDetail(Strings.Error, "No file found in the GAC which matches the file attempted to be installed;  installation must have failed.");
							output.EndWriteError();
						}
					}
				}
			}
			catch (Exception ex)
			{
				using (BatchedOutput output = new BatchedOutput(false))
				{
					output.BeginWriteError(0, Strings.GACInstallationOfAssemblyFailed);
					output.AddErrorDetail(Strings.Path, path);
					output.AddErrorDetail(Strings.Error, ex.ToString());
					output.EndWriteError();
				}
			}
		}

		private String ProcessorArchitectureAsString(ProcessorArchitecture processorArchitecture)
		{
			String result = String.Empty;

			switch (processorArchitecture)
			{
				case ProcessorArchitecture.None:
					break;

				case ProcessorArchitecture.X86:
					result = "x86";
					break;

				case ProcessorArchitecture.MSIL:
					result = "msil";
					break;

				case ProcessorArchitecture.IA64:
					result = "ia64";
					break;

				case ProcessorArchitecture.Amd64:
					result = "amd64";
					break;
			}

			return result;
		}

		#endregion

		private static Boolean CompareByteArrays(Byte[] data1, Byte[] data2)
		{
			// If both are null, they're equal
			if (data1 == null && data2 == null)
			{
				return true;
			}
			// If either but not both are null, they're not equal
			if (data1 == null || data2 == null)
			{
				return false;
			}
			if (data1.Length != data2.Length)
			{
				return false;
			}
			for (int i = 0; i < data1.Length; i++)
			{
				if (data1[i] != data2[i])
				{
					return false;
				}
			}
			return true;
		}
		private String _path;
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct ASSEMBLY_INFO
	{
		public Int32 cbAssemblyInfo;
		public Int32 assemblyFlags;
		public Int64 assemblySizeInKB;
		[MarshalAs(UnmanagedType.LPWStr)]
		public String currentAssemblyPath;
		public Int32 cchBuf;
	}


	[ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("e707dcde-d1cd-11d2-bab9-00c04f8eceae")]
	internal interface IAssemblyCache
	{
		[PreserveSig()]
		int UninstallAssembly(uint dwFlags, [MarshalAs(UnmanagedType.LPWStr)] string pszAssemblyName, IntPtr pvReserved, out uint pulDisposition);

		[PreserveSig()]
		int QueryAssemblyInfo(uint dwFlags, [MarshalAs(UnmanagedType.LPWStr)] string pszAssemblyName, ref ASSEMBLY_INFO pAsmInfo);

		[PreserveSig()]
		int CreateAssemblyCacheItem(uint dwFlags, IntPtr pvReserved, out /*IAssemblyCacheItem*/IntPtr ppAsmItem, [MarshalAs(UnmanagedType.LPWStr)] String pszAssemblyName);

		[PreserveSig()]
		int CreateAssemblyScavenger(out object ppAsmScavenger);

		[PreserveSig()]
		int InstallAssembly(uint dwFlags, [MarshalAs(UnmanagedType.LPWStr)] string pszManifestFilePath, IntPtr pvReserved);
	}

	internal sealed class Gac
	{
		static public void AddAssemblyToCache(string assembly)
		{
			IAssemblyCache assemblyCache = null;

			int hr = CreateAssemblyCache(out assemblyCache, 0);
			if (hr >= 0)
			{
				hr = assemblyCache.InstallAssembly(0, assembly, (IntPtr)0);
			}

			if (hr < 0)
			{
				Marshal.ThrowExceptionForHR(hr);
			}
		}

		static public void RemoveAssemblyFromCache(string assembly)
		{
			IAssemblyCache assemblyCache = null;

			uint n;
			int hr = CreateAssemblyCache(out assemblyCache, 0);
			if (hr >= 0)
			{
				hr = assemblyCache.UninstallAssembly(0, assembly, (IntPtr)0, out n);
			}

			if (hr < 0)
			{
				Marshal.ThrowExceptionForHR(hr);
			}
		}

		static public ASSEMBLY_INFO QueryAssemblyInfo(String assemblyName)
		{
			ASSEMBLY_INFO result = new ASSEMBLY_INFO();
			result.cchBuf = 1024;
			result.currentAssemblyPath = new String('\0', result.cchBuf);

			// Get IAssemblyCache pointer
			IAssemblyCache assemblyCache = null;
			Int32 hr = CreateAssemblyCache(out assemblyCache, 0);
			if (hr >= 0)
			{
				hr = assemblyCache.QueryAssemblyInfo(0, assemblyName, ref result);
			}

			// If the assembly doesn't exist in the GAC, we will get back a 0x80070002
			if (hr != unchecked((Int32)0x80070002) && hr < 0)
			{
				Marshal.ThrowExceptionForHR(hr);
			}

			return result;
		}

		[DllImport("Fusion.dll", CharSet = CharSet.Auto)]
		internal static extern int CreateAssemblyCache(out IAssemblyCache ppAsmCache, uint dwReserved);
	}
}
