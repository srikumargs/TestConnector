using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Threading;

namespace LibraryConfigTool.Internal
{
    internal enum EmitType
    {
        None,
        Xml,
        Txt,
        Zip
    }

    internal sealed class EmitStep : IStep
    {
        public EmitStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _id = Utils.GetRequiredAttribute(navigator, Constants.IdAttribute, Constants.EmitElement, configInfo.ConfigFile);
            _emitType = Utils.GetRequiredAttribute(navigator, "Type", Constants.EmitElement, configInfo.ConfigFile);
            _path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, Constants.EmitElement, configInfo.ConfigFile);
            _zipRoot = Utils.GetOptionalAttribute(navigator, Constants.ZipRootAttribute);
            _openExisting = Utils.GetOptionalAttribute(navigator, "OpenExisting");

            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                XPathNodeIterator iterator = navigator.Select("child::*");
                while (iterator.MoveNext())
                {
                    _steps.Add(StepFactory.Create(configInfo, iterator.Current));
                }
            }
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String id = rootConfigInfo.ReplaceAllVariables(_id);
            EmitType emitType = (EmitType)Enum.Parse(typeof(EmitType), rootConfigInfo.ReplaceAllVariables(_emitType), true);
            String path = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_path), rootConfigInfo);
            String zipRoot = rootConfigInfo.ReplaceAllVariables(_zipRoot);
            Boolean openExisting = false;
            String openExistingAsString = rootConfigInfo.ReplaceAllVariables(_openExisting);
            if (!String.IsNullOrEmpty(openExistingAsString))
            {
                openExisting = Boolean.Parse(openExistingAsString);
            }

            if (String.IsNullOrEmpty(zipRoot))
            {
                zipRoot = rootConfigInfo.GetSystemVariableValue(Utils.GetVariableNameKeyForVariableName("System::SandboxDir"));
            }

            Program.Output.Write(OutputType.Info, String.Format("Emit '{0}' as '{1}'...", path, id));
            using (IndentedOutput indentedOutput = new IndentedOutput())
            {
                Boolean writerOpened = false;
                try
                {
                    Utils.EnsureDirectoryExists(Path.GetDirectoryName(path), "TargetDir");

                    rootConfigInfo.OpenEmitWriter(emitType, id, path, zipRoot, openExisting);
                    writerOpened = true;

                    foreach (IStep step in _steps)
                    {
                        step.Execute(rootConfigInfo);
                    }
                }
                catch (Exception ex)
                {
                    using (BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, "Failed to emit data.");
                        output.AddErrorDetail(Strings.Error, ex.ToString());
                        output.EndWriteError();
                    }
                }
                finally
                {
                    if (writerOpened)
                    {
                        rootConfigInfo.CloseEmitWriter(id);
                    }
                }
            }

            Program.Output.Write(OutputType.Info, String.Format("Emit '{0}' closed", id));
        }

        #endregion

        private String _id;
        private String _emitType;
        private String _path;
        private String _zipRoot;
        private String _openExisting;
        private readonly List<IStep> _steps = new List<IStep>();
    }
}
