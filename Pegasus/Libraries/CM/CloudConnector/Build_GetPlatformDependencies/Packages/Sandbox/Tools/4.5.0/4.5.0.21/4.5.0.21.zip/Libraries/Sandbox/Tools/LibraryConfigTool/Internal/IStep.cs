using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryConfigTool.Internal
{
    internal interface IStep
    {
        void Execute(ConfigInfo rootConfigInfo);
    }
}
