﻿
namespace CompressionBase64Encoder.Internal
{
    internal enum ExitCode
    {
        Success = 0,
        NoActionTaken = 1,
        UnexpectedErrorsOccurred = 2
    }
}
