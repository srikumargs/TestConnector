﻿using System.Collections.Generic;
using System.Globalization;

namespace SymbolTool.Internal
{
    /// <summary>
    /// Defines a command to clean symbols from the symbol store based on a specified retention policy.
    /// </summary>
    public class CleanSymbolsCommand
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="CleanSymbolsCommand"/> class.
        /// </summary>
        public CleanSymbolsCommand()
        { }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the retention policy in days.
        /// </summary>
        public int Days
        { get; set; }

        /// <summary>
        /// Gets or sets the root directory for the symbol store.
        /// </summary>
        /// <value>The root directory for the symbol store.</value>
        public string Store { get; set; }

        #endregion

        #region Execute

        /// <summary>
        /// Executes the cleaning process.
        /// </summary>
        /// <exception cref="SymbolToolException">The exception thrown if a failure occurs.</exception>
        public void Execute()
        {
            Program.Output.Write(OutputType.Status, string.Format(CultureInfo.CurrentCulture, "Preparing to remove symbols from '{0}' that are older than {1} days.", this.Store, this.Days));

            // Retrieve all of the transactions older than the retention policy.
            IList<SymbolTransaction> transactions = Utils.SearchOlderThan(this.Store, this.Days);

            foreach (SymbolTransaction transaction in transactions)
            {
                // Only delete symbols that have not yet been deleted.
                if (transaction.Action == TransactionAction.Add && !transaction.HasBeenDeleted)
                {
                    transaction.Delete();
                    Program.Output.Write(OutputType.Verbose, IndentAction.IndentOnce, string.Format(CultureInfo.CurrentCulture, "Successfully removed symbol with transaction Id {0}.", transaction.TransactionId));
                }
            }
        }

        #endregion
    }
}
