﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;

using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.Zip;

namespace LibraryConfigTool.Internal
{
    internal sealed class ZipEmitWriter : IDisposable
    {
        public ZipEmitWriter(String filePath, String zipRoot)
        {
            _zipRoot = zipRoot;
            _zipOutputStream = new ZipOutputStream(File.Create(filePath));
            _zipOutputStream.SetLevel(6); // 0 - store only to 9 - means best compression

            _zipBuffer = new Byte[0xFFFF];
            _zipEntryFileNames = new StringCollection();
            _zipEntryFileNames.Add(MakeFileNameForZipEntry(filePath).ToLower(CultureInfo.InvariantCulture)); // add the name of the file we are producing ... to make certain we don't try to zip it up
            _filePath = filePath;
        }

        public void Write(String filePath)
        {
            String fileNameForZipEntry = MakeFileNameForZipEntry(filePath);
            String fileNameForZipEntryAsLower = fileNameForZipEntry.ToLower(CultureInfo.InvariantCulture);
            if (!_zipEntryFileNames.Contains(fileNameForZipEntryAsLower))
            {
                Program.Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "Zipping file:  '{0}'", filePath));

                _zipEntryFileNames.Add(fileNameForZipEntryAsLower);

                _zipOutputStream.PutNextEntry(new ZipEntry(fileNameForZipEntry));

                using (FileStream fileStream = File.OpenRead(filePath))
                {
                    StreamUtils.Copy(fileStream, _zipOutputStream, _zipBuffer);
                }
            }
        }

        private String MakeFileNameForZipEntry(String filePath)
        {
            return filePath.Substring(_zipRoot.Length + 1).Replace('\\', '/');
        }

        public void Flush()
        {
            _zipOutputStream.Finish();
        }

        public void Close()
        {
            Program.Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "Zip file '{0}' closed; {1} files archived", _filePath, _zipEntryFileNames.Count - 1));
            _zipOutputStream.Close();
        }

        private readonly String _zipRoot;
        private readonly ZipOutputStream _zipOutputStream; 
        private readonly Byte[] _zipBuffer;
        private readonly String _filePath;
        private readonly StringCollection _zipEntryFileNames;

        #region IDisposable Members

        public void Dispose()
        {
            _zipOutputStream.Dispose();
        }

        #endregion
    }
}
