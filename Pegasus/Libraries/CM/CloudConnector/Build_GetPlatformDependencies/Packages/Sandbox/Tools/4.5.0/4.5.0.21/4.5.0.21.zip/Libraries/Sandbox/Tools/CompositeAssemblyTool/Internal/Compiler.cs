using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using System.IO;
using System.Globalization;
using System.Text;
using System.ComponentModel;
using System.Diagnostics;
using Microsoft.CSharp;
using System.Diagnostics.CodeAnalysis;

namespace CompositeAssemblyTool.Internal
{
    /// <summary>
    /// This class compiles C# code from CodeDOM generated code
    /// </summary>
    internal sealed class Compiler
    {
        #region Public properties
        /// <summary>
        /// This is the file version of the compiled assembly (1.2.3.4)
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String AssemblyFileVersion
        {
            get { return _assemblyFileVersion; }
            set { _assemblyFileVersion = value; }
        }

        /// <summary>
        /// This is the assembly version to use when compiling the assembly (1.2.3.4)
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String AssemblyVersion
        {
            get { return _assemblyVersion; }
            set { _assemblyVersion = value; }
        }

        /// <summary>
        /// This is the assembly version to use when compiling the assembly (1.2.3.4)
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String AssemblyInformationalVersion
        {
            get { return _assemblyInformationalVersion; }
            set { _assemblyInformationalVersion = value; }
        }

        /// <summary>
        /// This is the assembly title to use when compiling the assembly
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String AssemblyTitle
        {
            get { return _assemblyTitle; }
            set { _assemblyTitle = value; }
        }

        /// <summary>
        /// This is the assembly description to use when compiling the assembly
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String AssemblyDescription
        {
            get { return _assemblyDescription; }
            set { _assemblyDescription = value; }
        }

        /// <summary>
        /// This is the assembly configuration to use when compiling the assembly
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String AssemblyConfiguration
        {
            get { return _assemblyConfiguration; }
            set { _assemblyConfiguration = value; }
        }

        /// <summary>
        /// This is the assembly company to use when compiling the assembly
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification="Property getter included for completeness.")]
        public String AssemblyCompany
        {
            get { return _assemblyCompany; }
            set { _assemblyCompany = value; }
        }

        /// <summary>
        /// This is the assembly company to use when compiling the assembly
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String AssemblyProduct
        {
            get { return _assemblyProduct; }
            set { _assemblyProduct = value; }
        }

        /// <summary>
        /// This is the assembly copyright to use when compiling the assembly
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String AssemblyCopyright
        {
            get { return _assemblyCopyright; }
            set { _assemblyCopyright = value; }
        }

        /// <summary>
        /// This is the assembly trademark to use when compiling the assembly
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String AssemblyTrademark
        {
            get { return _assemblyTrademark; }
            set { _assemblyTrademark = value; }
        }

        /// <summary>
        /// This is the assembly culture to use when compiling the assembly
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String AssemblyCulture
        {
            get { return _assemblyCulture; }
            set { _assemblyCulture = value; }
        }

        /// <summary>
        /// This is the location of the keyfile to use.
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String KeyfileName
        {
            get { return _keyfileName; }
            set { _keyfileName = value; }
        }

        /// <summary>
        /// This is the location of the icon file to use.
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Property getter included for completeness.")]
        public String Win32IconFileName
        {
            get { return _win32IconFileName; }
            set { _win32IconFileName = value; }
        }

        public String EmbeddedCommandLine
        {
            get { return _embeddedCommandLine; }
            set { _embeddedCommandLine = value; }
        }

        public Boolean ConsoleApplication
        {
            get { return _consoleApplication; }
            set { _consoleApplication = value; }
        }

        #endregion

        #region Public methods
        /// <summary>
        /// This method will compile the code in nameSpace in memory and return the assembly from the compilation
        /// The assembly can immediately be used to run the stored procedures
        /// </summary>
        /// <param name="additionalAssemblyFileNames"></param>
        /// <param name="outputAssembly"></param>
        /// <param name="primaryAssemblyFileName"></param>
        /// <param name="rootNamespace"></param>
        /// <returns></returns>
        public Assembly Compile(String rootNamespace, String primaryAssemblyFileName, ReadOnlyCollection<String> additionalAssemblyFileNames, String outputAssembly)
        {
            Boolean compileInMemory = (String.IsNullOrEmpty(outputAssembly));

            //Get a CSharpCodeProvider, generate and compile the code
            CSharpCodeProvider codeProvider = new CSharpCodeProvider();

            StringWriter stringWriter = new StringWriter(CultureInfo.InvariantCulture);
            CodeGeneratorOptions options = new CodeGeneratorOptions();
            options.BlankLinesBetweenMembers = false;
            options.BracingStyle = "C";
            String sourceCode = String.Empty;
            if (!compileInMemory)
            {
                using (FileStream fileStream = new FileStream(primaryAssemblyFileName, FileMode.Open, FileAccess.Read))
                using (BinaryReader binaryReader = new BinaryReader(fileStream))
                {
                    Byte[] primaryAssemblyBytes = binaryReader.ReadBytes((Int32) fileStream.Length);
                    Assembly primaryAssembly = Assembly.Load(primaryAssemblyBytes);

                    Object[] customAttributes = primaryAssembly.GetCustomAttributes(false);
                    List<Object> customAttributesList = new List<object>(customAttributes);

                    _assemblyTitle = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyTitleAttribute), "Title", _assemblyTitle);
                    _assemblyDescription = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyDescriptionAttribute), "Description", _assemblyDescription);
                    _assemblyConfiguration = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyConfigurationAttribute), "Configuration", _assemblyConfiguration);
                    _assemblyCompany = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyCompanyAttribute), "Company", _assemblyConfiguration);
                    _assemblyProduct = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyProductAttribute), "Product", _assemblyProduct);
                    _assemblyCopyright = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyCopyrightAttribute), "Copyright", _assemblyCopyright);
                    _assemblyTrademark = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyTrademarkAttribute), "Trademark", _assemblyTrademark);
                    _assemblyCulture = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyCultureAttribute), "Culture", _assemblyCulture);
                    _assemblyVersion = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyVersionAttribute), "Version", String.IsNullOrEmpty(_assemblyVersion) ? "1.0.0.0" : _assemblyVersion);
                    _assemblyFileVersion = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyFileVersionAttribute), "Version", String.IsNullOrEmpty(_assemblyFileVersion) ? "1.0.0.0" : _assemblyFileVersion);
                    _assemblyInformationalVersion = GetAttributeProperty(customAttributesList, typeof(System.Reflection.AssemblyInformationalVersionAttribute), "InformationalVersion", String.IsNullOrEmpty(_assemblyInformationalVersion) ? "1.0.0.0" : _assemblyInformationalVersion);
                }

                CodeCompileUnit compileUnit = new CodeCompileUnit();

                CodeAttributeDeclaration[] attributeDeclarations = 
                    {
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyTitleAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyTitle)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyDescriptionAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyDescription)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyConfigurationAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyConfiguration)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyCompanyAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyCompany)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyProductAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyProduct)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyCopyrightAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyCopyright)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyTrademarkAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyTrademark)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyCultureAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyCulture)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyVersionAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyVersion)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyFileVersionAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyFileVersion)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyInformationalVersionAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodePrimitiveExpression(_assemblyInformationalVersion)) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.CLSCompliantAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodeSnippetExpression("true")) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Runtime.InteropServices.ComVisible"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodeSnippetExpression("false")) }),
                        new CodeAttributeDeclaration(new CodeTypeReference("System.Reflection.AssemblyDelaySignAttribute"), new CodeAttributeArgument[] { new CodeAttributeArgument(new CodeSnippetExpression("false")) })
                    };

                foreach (CodeAttributeDeclaration attributeDeclaration in attributeDeclarations)
                {
                    compileUnit.AssemblyCustomAttributes.Add(attributeDeclaration);
                }

                codeProvider.GenerateCodeFromCompileUnit(compileUnit, stringWriter, options);
                sourceCode = stringWriter.ToString();
            }
            sourceCode += GetHelperCode();
            sourceCode = sourceCode.Replace("__CompositeAssemblyTool_Namespace", rootNamespace);
            sourceCode = sourceCode.Replace("__CompositeAssemblyTool_PrimaryAssemblyName", Path.GetFileName(primaryAssemblyFileName));
            sourceCode = sourceCode.Replace("__CompositeAssemblyTool_EmbeddedCommandLine", EmbeddedCommandLine); 

            CompilerParameters parameters = new CompilerParameters();

            parameters.ReferencedAssemblies.Add("System.dll");
            parameters.ReferencedAssemblies.Add("System.Xml.dll");
            parameters.ReferencedAssemblies.Add("System.Data.dll");

            parameters.EmbeddedResources.Add(primaryAssemblyFileName);
            foreach (String fileName in additionalAssemblyFileNames)
            {
                parameters.EmbeddedResources.Add(fileName);
            }

            parameters.GenerateExecutable = true;
            parameters.MainClass = rootNamespace + ".Program";
            parameters.IncludeDebugInformation = true;
            parameters.WarningLevel = 4;
            parameters.TreatWarningsAsErrors = true;

            if (compileInMemory)
            {
                parameters.OutputAssembly = Path.GetTempFileName();
                parameters.GenerateInMemory = true;
            }
            else
            {
                if (!String.IsNullOrEmpty(_keyfileName))
                {
                    parameters.CompilerOptions = String.Format(CultureInfo.CurrentCulture, "/keyfile:\"{0}\"", _keyfileName);
                }
                parameters.OutputAssembly = outputAssembly;
                parameters.GenerateInMemory = false;
            }


            // if an icon was specified, then load it
            if (String.IsNullOrEmpty(_win32IconFileName))
            {
                using (Library library = new Library(primaryAssemblyFileName, NativeMethods.LOAD_LIBRARY_AS_DATAFILE))
                {
                    library.EnumResourceNames(NativeMethods.RT_GROUP_ICON, new NativeMethods.EnumResNameProc(AddIconToList), IntPtr.Zero);

                    _tempWin32IconFileName = Path.GetTempFileName();

                    if (_icons.Count > 0)
                    {
                        _icons[0].Save(_tempWin32IconFileName);
                        _win32IconFileName = _tempWin32IconFileName;
                    }
                }
            }
            if (!ConsoleApplication)
            {
                parameters.CompilerOptions += " /t:winexe";
            }

            if (!string.IsNullOrEmpty(_win32IconFileName))
                parameters.CompilerOptions += " /win32icon:\"" + _win32IconFileName + "\"";

            CompilerResults compileResults = null;
            if (!compileInMemory)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(outputAssembly));

                String tempSourceCodeFileName = Path.Combine(Path.GetDirectoryName(outputAssembly), Path.GetFileNameWithoutExtension(outputAssembly) + ".Program.Generated.cs");
                if (File.Exists(tempSourceCodeFileName))
                {
                    File.Delete(tempSourceCodeFileName);
                }

                using (TextWriter textWriter = File.CreateText(tempSourceCodeFileName))
                {
                    textWriter.Write(sourceCode);
                }

                compileResults = codeProvider.CompileAssemblyFromFile(parameters, tempSourceCodeFileName);
            }
            else
            {
                compileResults = codeProvider.CompileAssemblyFromSource(parameters, sourceCode);
            }

            try
            {
                if (compileResults.Errors.Count != 0)
                {
                    String compilerErrors = "";
                    foreach (CompilerError error in compileResults.Errors)
                    {
                        compilerErrors += String.Format(CultureInfo.CurrentCulture, "{0}: {1} ({2},{3})\n", error.ErrorNumber, error.ErrorText, error.Line, error.Column);
                    }
                    throw new Exception("Compiler errors\n" + compilerErrors);
                }
            }
            finally
            {
                if (compileInMemory && File.Exists(parameters.OutputAssembly))
                {
                    File.Delete(parameters.OutputAssembly);
                }

                if (!String.IsNullOrEmpty(_tempWin32IconFileName))
                {
                    File.Delete(_tempWin32IconFileName);
                    _tempWin32IconFileName = String.Empty;
                }
            }

            return compileResults.CompiledAssembly;
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Retrieves the helper functions from the embedded resource xSQL.helperfunctions.cs.
        /// </summary>
        /// <returns></returns>
        private String GetHelperCode()
        {
            String results;

            Stream stream = GetType().Assembly.GetManifestResourceStream("CompositeAssemblyTool.Internal.Program.Generated.cs");
            using (TextReader reader = new StreamReader(stream))
            {
                results = reader.ReadToEnd();
            }

            return results;
        }

        /// <summary>
        /// This is the callback that gets called for any icon resources that 
        /// are found. Create an IconResource object to represent it and an 
        /// item to the list.
        /// </summary>
        private bool AddIconToList(IntPtr module, IntPtr type, IntPtr name, IntPtr param)
        {
            try
            {
                Library library = new Library(module, false);
                IconResource iconResource = new IconResource(library, name);

                _icons.Add(iconResource);
            }
            catch (Win32Exception e)
            {
                throw new Exception("Failed to load an icon resource.", e);
            }

            return true;
        }

        private static String GetAttributeProperty(List<Object> attributesList, Type attributeType, String propertyName, String defaultValue)
        {
            String result = defaultValue;

            if (String.IsNullOrEmpty(result))
            {
                Attribute attribute = attributesList.Find(delegate(Object attributeObject) {return attributeType.Equals(attributeObject.GetType());}) as Attribute;
                if (attribute != null)
                {
                    PropertyInfo propertyInfo = attributeType.GetProperty(propertyName);
                    result = propertyInfo.GetValue(attribute, null) as String;
                }
            }

            return result;
        }

        #endregion

        #region Private fields
        private String _assemblyTitle = String.Empty;
        private String _assemblyDescription = String.Empty;
        private String _assemblyConfiguration = String.Empty;
        private String _assemblyCompany = String.Empty;
        private String _assemblyProduct = String.Empty;
        private String _assemblyCopyright = String.Empty;
        private String _assemblyTrademark = String.Empty;
        private String _assemblyCulture = String.Empty;
        private String _assemblyVersion = String.Empty;
        private String _assemblyFileVersion = String.Empty;
        private String _assemblyInformationalVersion = String.Empty;
        private String _keyfileName = String.Empty;
        private String _win32IconFileName = String.Empty;
        private String _tempWin32IconFileName = String.Empty;
        private String _embeddedCommandLine = String.Empty;
        private Boolean _consoleApplication;
        private List<IconResource> _icons = new List<IconResource>();
        #endregion
    }
}
