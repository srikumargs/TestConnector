using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyCompany("TAG_CREBuildSystem_Company")]
[assembly: AssemblyCopyright("TAG_CREBuildSystem_Copyright")]
[assembly: AssemblyTrademark("TAG_CREBuildSystem_Trademark")]
[assembly: AssemblyConfiguration("TAG_CREBuildSystem_Configuration")]

// AssemblyVersion changes only by release
[assembly: AssemblyVersion("TAG_CREBuildSystem_AssemblyVersion")] 

// AssemblyFileVersion and AssemblyInformationalVersionAttribute change with each build
[assembly: AssemblyFileVersion("TAG_CREBuildSystem_FileVersion")]
[assembly: AssemblyInformationalVersionAttribute("TAG_CREBuildSystem_AssemblyInformationalVersion")]
