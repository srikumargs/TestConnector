﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSProjCleaner.Internal
{
    internal enum WorkProgressCode
    {
        None = 0,
        Error,
        File,
        Edit
    }

    internal sealed class WorkProgressEventArgs : EventArgs
    {
        public WorkProgressEventArgs(WorkProgressCode code, String description)
            : this(code, description, null)
        { }

        public WorkProgressEventArgs(WorkProgressCode code, String description, String details)
        {
            _code = code;
            _description = description;
            _details = details;
        }

        #region Public properties
        public WorkProgressCode Code
        { get { return _code; } }

        public String Description
        { get { return _description; } }

        public String Details
        { get { return _details; } }
        #endregion

        #region Private fields
        private WorkProgressCode _code;
        private String _description;
        private String _details;
        #endregion
    }
}
