#include "stdafx.h"
#include <tchar.h>

LONG OverrideClassesRoot(HKEY hKeyBase, LPCWSTR szOverrideKey)
{
	HKEY hKey;
	LONG l = RegOpenKey(hKeyBase, szOverrideKey, &hKey);
	
	if (l == ERROR_SUCCESS)
	{
		l = RegOverridePredefKey(HKEY_CLASSES_ROOT, hKey);

		RegCloseKey(hKey);
	}

	return l;
}

LONG CreateOpenRegistryKey(HKEY key, LPCTSTR path, HKEY* newKey)
{
	DWORD dwDisposition = 0;
	return ::RegCreateKeyEx(key, path, 0, NULL, 0, KEY_ALL_ACCESS, 0, newKey, &dwDisposition);
}

void RemapRegistryKey(HKEY registryKey, HKEY regRootToOverride, LPCTSTR remappedPath)
{
	HKEY remappedKey = NULL;
	if(ERROR_SUCCESS == CreateOpenRegistryKey(regRootToOverride, remappedPath, &remappedKey))
	{
	    if(ERROR_SUCCESS == ::RegOverridePredefKey(registryKey, remappedKey))
		{
			::RegCloseKey(remappedKey);
		}
		else
		{
			::OutputDebugString(_T("RegOverridePredefKey fail!"));
		}
	}
	else
	{
		::OutputDebugString(_T("CreateOpenRegistryKey fail!"));
	}
}

LPCTSTR Append(LPTSTR tszTemp, LPCTSTR tsz1, LPCTSTR tsz2)
{
	::memset(tszTemp, 0, sizeof(tszTemp));
	_stprintf(tszTemp, _T("%s%s"), tsz1, tsz2);
	return tszTemp;
}

void RemapRegistry()
{
	OSVERSIONINFO osvi;
	::ZeroMemory(&osvi, sizeof(osvi));
	osvi.dwOSVersionInfoSize = sizeof(osvi);
	::GetVersionEx(&osvi);

	TCHAR tszTemp[512];

	// Detect OS major version and set the hive to use when
	// redirecting registry writes. We want to redirect registry
	// writes to HKCU on Windows Vista and higher to avoid UAC
	// problems, and to HKLM on downlevel OS's.
	HKEY regKeyToOverride = HKEY_LOCAL_MACHINE;
	HKEY regRootToOverride = HKEY_LOCAL_MACHINE;
	if (osvi.dwMajorVersion >= 6)
	{
		regKeyToOverride = HKEY_CURRENT_USER;
		regRootToOverride = HKEY_CURRENT_USER;
	}

    // create a path in the registry for redirected keys which is process-specific
	TCHAR tszRemappedPath[1024];
	::memset(tszRemappedPath, 0, sizeof(tszRemappedPath));
	::GetEnvironmentVariable(_T("SPARK_REG_REMAP_ROOT"), tszRemappedPath, sizeof(tszRemappedPath) / sizeof(TCHAR));
	::OutputDebugString(tszRemappedPath);

	// remove the previous remapped key if it exists
	::RegDeleteKey(regKeyToOverride, tszRemappedPath);

	// remap the registry roots supported by MSI
	// note - order is important here - the hive being used to redirect
	// to must be overridden last to avoid creating the other override
	// hives in the wrong location in the registry. For example, if HKLM is
	// the redirect destination, overriding it first will cause other hives
	// to be overridden under HKLM\Software\Sage\Sandbox\Spark\HKLM\Software\WiX\HKCR
	// instead of under HKLM\Software\Sage\Sandbox\Spark\HKCR
	if (osvi.dwMajorVersion < 6)
	{
		RemapRegistryKey(HKEY_CLASSES_ROOT, regRootToOverride, Append(tszTemp, tszRemappedPath, _T("\\HKEY_CLASSES_ROOT")));
		RemapRegistryKey(HKEY_CURRENT_USER, regRootToOverride, Append(tszTemp, tszRemappedPath, _T("\\HKEY_CURRENT_USER")));
		RemapRegistryKey(HKEY_USERS, regRootToOverride, Append(tszTemp, tszRemappedPath, _T("\\HKEY_USERS")));
		RemapRegistryKey(HKEY_LOCAL_MACHINE, regRootToOverride, Append(tszTemp, tszRemappedPath, _T("\\HKEY_LOCAL_MACHINE")));
	}
	else
	{
		RemapRegistryKey(HKEY_CLASSES_ROOT, regRootToOverride, Append(tszTemp, tszRemappedPath, _T("\\HKEY_CLASSES_ROOT")));
		RemapRegistryKey(HKEY_LOCAL_MACHINE, regRootToOverride, Append(tszTemp, tszRemappedPath, _T("\\HKEY_LOCAL_MACHINE")));
		RemapRegistryKey(HKEY_USERS, regRootToOverride, Append(tszTemp, tszRemappedPath, _T("\\HKEY_USERS")));
		RemapRegistryKey(HKEY_CURRENT_USER, regRootToOverride, Append(tszTemp, tszRemappedPath, _T("\\HKEY_CURRENT_USER")));

		// Typelib registration on Windows Vista requires that the key 
		// HKLM\Software\Classes exist, so add it to the remapped root
		HKEY hkey = NULL;
		if(ERROR_SUCCESS == CreateOpenRegistryKey(HKEY_LOCAL_MACHINE, _T("Software\\Classes"), &hkey))
		{
			RegCloseKey(hkey);
		}
	}
}

BOOL APIENTRY DllMain( HMODULE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID /*lpReserved*/
					 )
{
	if (ul_reason_for_call == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(hModule);

		RemapRegistry();


		LONG l = ERROR_SUCCESS;
		
		if (l != ERROR_SUCCESS)
			ExitProcess(l);
	}
	
	return TRUE;
}

