﻿namespace CSProjCleaner.Internal
{
    internal partial class OptionsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this._tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this._assemblySigningComboBox = new System.Windows.Forms.ComboBox();
            this._platformTargetComboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this._normalizeOutputPathsComboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this._preBuildEventComboBox = new System.Windows.Forms.ComboBox();
            this._postBuildEventComboBox = new System.Windows.Forms.ComboBox();
            this._dotNetFrameworkVersionComboBox = new System.Windows.Forms.ComboBox();
            this._warningsAsErrorsComboBox = new System.Windows.Forms.ComboBox();
            this._runCodeAnalysisComboBox = new System.Windows.Forms.ComboBox();
            this._normalizeAssemblyReferencesComboBox = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this._sourceControlServerTextBox = new System.Windows.Forms.TextBox();
            this._helpTextLabel = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            this._tableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Window;
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this._helpTextLabel);
            this.splitContainer1.Size = new System.Drawing.Size(404, 376);
            this.splitContainer1.SplitterDistance = 336;
            this.splitContainer1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this._tableLayoutPanel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(404, 336);
            this.panel1.TabIndex = 2;
            // 
            // _tableLayoutPanel
            // 
            this._tableLayoutPanel.AutoSize = true;
            this._tableLayoutPanel.ColumnCount = 2;
            this._tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 170F));
            this._tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this._tableLayoutPanel.Controls.Add(this.label10, 0, 9);
            this._tableLayoutPanel.Controls.Add(this._assemblySigningComboBox, 0, 9);
            this._tableLayoutPanel.Controls.Add(this._platformTargetComboBox, 0, 8);
            this._tableLayoutPanel.Controls.Add(this.label9, 0, 8);
            this._tableLayoutPanel.Controls.Add(this.label7, 0, 7);
            this._tableLayoutPanel.Controls.Add(this._normalizeOutputPathsComboBox, 0, 7);
            this._tableLayoutPanel.Controls.Add(this.label6, 0, 6);
            this._tableLayoutPanel.Controls.Add(this.label5, 0, 5);
            this._tableLayoutPanel.Controls.Add(this.label4, 0, 4);
            this._tableLayoutPanel.Controls.Add(this.label3, 0, 3);
            this._tableLayoutPanel.Controls.Add(this.label2, 0, 2);
            this._tableLayoutPanel.Controls.Add(this.label1, 0, 1);
            this._tableLayoutPanel.Controls.Add(this._preBuildEventComboBox, 1, 1);
            this._tableLayoutPanel.Controls.Add(this._postBuildEventComboBox, 1, 2);
            this._tableLayoutPanel.Controls.Add(this._dotNetFrameworkVersionComboBox, 1, 3);
            this._tableLayoutPanel.Controls.Add(this._warningsAsErrorsComboBox, 1, 4);
            this._tableLayoutPanel.Controls.Add(this._runCodeAnalysisComboBox, 1, 5);
            this._tableLayoutPanel.Controls.Add(this._normalizeAssemblyReferencesComboBox, 1, 6);
            this._tableLayoutPanel.Controls.Add(this.label8, 0, 0);
            this._tableLayoutPanel.Controls.Add(this._sourceControlServerTextBox, 1, 0);
            this._tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this._tableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this._tableLayoutPanel.Name = "_tableLayoutPanel";
            this._tableLayoutPanel.RowCount = 10;
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this._tableLayoutPanel.Size = new System.Drawing.Size(402, 271);
            this._tableLayoutPanel.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(3, 244);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(164, 27);
            this.label10.TabIndex = 19;
            this.label10.Text = "Assembly signing:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _assemblySigningComboBox
            // 
            this._assemblySigningComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._assemblySigningComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._assemblySigningComboBox.FormattingEnabled = true;
            this._assemblySigningComboBox.Items.AddRange(new object[] {
            "No change",
            "Set",
            "Remove"});
            this._assemblySigningComboBox.Location = new System.Drawing.Point(173, 247);
            this._assemblySigningComboBox.Name = "_assemblySigningComboBox";
            this._assemblySigningComboBox.Size = new System.Drawing.Size(226, 21);
            this._assemblySigningComboBox.TabIndex = 20;
            this.toolTip1.SetToolTip(this._assemblySigningComboBox, "Specifies whether the assembly is to be digitally signed.");
            // 
            // _platformTargetComboBox
            // 
            this._platformTargetComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._platformTargetComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._platformTargetComboBox.FormattingEnabled = true;
            this._platformTargetComboBox.Items.AddRange(new object[] {
            "No change",
            "AnyCPU",
            "x86",
            "x64",
            "Itanium"});
            this._platformTargetComboBox.Location = new System.Drawing.Point(173, 220);
            this._platformTargetComboBox.Name = "_platformTargetComboBox";
            this._platformTargetComboBox.Size = new System.Drawing.Size(226, 21);
            this._platformTargetComboBox.TabIndex = 18;
            this.toolTip1.SetToolTip(this._platformTargetComboBox, "Specifies the assembly\'s platform target.  NOTE: option is limited to changing th" +
        "e PlatformTarget setting in the \"Any CPU\" configurations and doesn\'t rename the " +
        "\"Any CPU\" configuration.");
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(3, 217);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(164, 27);
            this.label9.TabIndex = 17;
            this.label9.Text = "Platform target:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(3, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(164, 27);
            this.label7.TabIndex = 14;
            this.label7.Text = "Nomalize output paths:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _normalizeOutputPathsComboBox
            // 
            this._normalizeOutputPathsComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._normalizeOutputPathsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._normalizeOutputPathsComboBox.FormattingEnabled = true;
            this._normalizeOutputPathsComboBox.Items.AddRange(new object[] {
            "No change",
            "Perform normalization"});
            this._normalizeOutputPathsComboBox.Location = new System.Drawing.Point(173, 193);
            this._normalizeOutputPathsComboBox.Name = "_normalizeOutputPathsComboBox";
            this._normalizeOutputPathsComboBox.Size = new System.Drawing.Size(226, 21);
            this._normalizeOutputPathsComboBox.TabIndex = 13;
            this.toolTip1.SetToolTip(this._normalizeOutputPathsComboBox, "Normalize all project output paths to use the correct %SAGE_SANDBOX%-relative pat" +
        "hs.");
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(3, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 27);
            this.label6.TabIndex = 12;
            this.label6.Text = "Normalize assembly references:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 134);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(164, 29);
            this.label5.TabIndex = 9;
            this.label5.Text = "Run code analysis on build:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(3, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(164, 27);
            this.label4.TabIndex = 8;
            this.label4.Text = "Treat compile warnings as errors:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(164, 27);
            this.label3.TabIndex = 7;
            this.label3.Text = ".NET Framework:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 27);
            this.label2.TabIndex = 6;
            this.label2.Text = "Post-build event:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 27);
            this.label1.TabIndex = 5;
            this.label1.Text = "Pre-build event:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _preBuildEventComboBox
            // 
            this._preBuildEventComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._preBuildEventComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._preBuildEventComboBox.FormattingEnabled = true;
            this._preBuildEventComboBox.Items.AddRange(new object[] {
            "No change",
            "Set",
            "Remove"});
            this._preBuildEventComboBox.Location = new System.Drawing.Point(173, 29);
            this._preBuildEventComboBox.Name = "_preBuildEventComboBox";
            this._preBuildEventComboBox.Size = new System.Drawing.Size(226, 21);
            this._preBuildEventComboBox.TabIndex = 0;
            this.toolTip1.SetToolTip(this._preBuildEventComboBox, "Sets/clears the pre-build event.  When set, will add the standard invocation of t" +
        "he LibraryConfigTool.");
            // 
            // _postBuildEventComboBox
            // 
            this._postBuildEventComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._postBuildEventComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._postBuildEventComboBox.FormattingEnabled = true;
            this._postBuildEventComboBox.Items.AddRange(new object[] {
            "No change",
            "Set",
            "Remove"});
            this._postBuildEventComboBox.Location = new System.Drawing.Point(173, 56);
            this._postBuildEventComboBox.Name = "_postBuildEventComboBox";
            this._postBuildEventComboBox.Size = new System.Drawing.Size(226, 21);
            this._postBuildEventComboBox.TabIndex = 1;
            this.toolTip1.SetToolTip(this._postBuildEventComboBox, "Sets/clears the post-build event.  When set, will add the standard invocation of " +
        "the LibraryConfigTool.");
            // 
            // _dotNetFrameworkVersionComboBox
            // 
            this._dotNetFrameworkVersionComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._dotNetFrameworkVersionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._dotNetFrameworkVersionComboBox.FormattingEnabled = true;
            this._dotNetFrameworkVersionComboBox.Items.AddRange(new object[] {
            "No change",
            "v2.0",
            "v3.0",
            "v3.5",
            "v4.0"});
            this._dotNetFrameworkVersionComboBox.Location = new System.Drawing.Point(173, 83);
            this._dotNetFrameworkVersionComboBox.Name = "_dotNetFrameworkVersionComboBox";
            this._dotNetFrameworkVersionComboBox.Size = new System.Drawing.Size(226, 21);
            this._dotNetFrameworkVersionComboBox.TabIndex = 2;
            this.toolTip1.SetToolTip(this._dotNetFrameworkVersionComboBox, "Specifies the .NET Framework version that the assembly targets.");
            // 
            // _warningsAsErrorsComboBox
            // 
            this._warningsAsErrorsComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._warningsAsErrorsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._warningsAsErrorsComboBox.FormattingEnabled = true;
            this._warningsAsErrorsComboBox.Items.AddRange(new object[] {
            "No change",
            "Set",
            "Remove"});
            this._warningsAsErrorsComboBox.Location = new System.Drawing.Point(173, 110);
            this._warningsAsErrorsComboBox.Name = "_warningsAsErrorsComboBox";
            this._warningsAsErrorsComboBox.Size = new System.Drawing.Size(226, 21);
            this._warningsAsErrorsComboBox.TabIndex = 3;
            this.toolTip1.SetToolTip(this._warningsAsErrorsComboBox, "Specifies whether compiler warnings should be treated as errors.");
            // 
            // _runCodeAnalysisComboBox
            // 
            this._runCodeAnalysisComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._runCodeAnalysisComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._runCodeAnalysisComboBox.FormattingEnabled = true;
            this._runCodeAnalysisComboBox.Items.AddRange(new object[] {
            "No change",
            "Set",
            "Remove"});
            this._runCodeAnalysisComboBox.Location = new System.Drawing.Point(173, 137);
            this._runCodeAnalysisComboBox.Name = "_runCodeAnalysisComboBox";
            this._runCodeAnalysisComboBox.Size = new System.Drawing.Size(226, 21);
            this._runCodeAnalysisComboBox.TabIndex = 4;
            this.toolTip1.SetToolTip(this._runCodeAnalysisComboBox, "Specifies whether Code Analysis should be enabled.");
            // 
            // _normalizeAssemblyReferencesComboBox
            // 
            this._normalizeAssemblyReferencesComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._normalizeAssemblyReferencesComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._normalizeAssemblyReferencesComboBox.FormattingEnabled = true;
            this._normalizeAssemblyReferencesComboBox.Items.AddRange(new object[] {
            "No change",
            "Perform normalization"});
            this._normalizeAssemblyReferencesComboBox.Location = new System.Drawing.Point(173, 166);
            this._normalizeAssemblyReferencesComboBox.Name = "_normalizeAssemblyReferencesComboBox";
            this._normalizeAssemblyReferencesComboBox.Size = new System.Drawing.Size(226, 21);
            this._normalizeAssemblyReferencesComboBox.TabIndex = 11;
            this.toolTip1.SetToolTip(this._normalizeAssemblyReferencesComboBox, "Normalize all file-type assembly references to use the correct %SAGE_SANDBOX%-rel" +
        "ative hint path, to not be version specific, and to not be copy local.");
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(3, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(164, 26);
            this.label8.TabIndex = 15;
            this.label8.Text = "Source control server:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _sourceControlServerTextBox
            // 
            this._sourceControlServerTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._sourceControlServerTextBox.Location = new System.Drawing.Point(173, 3);
            this._sourceControlServerTextBox.Name = "_sourceControlServerTextBox";
            this._sourceControlServerTextBox.Size = new System.Drawing.Size(226, 20);
            this._sourceControlServerTextBox.TabIndex = 16;
            this._sourceControlServerTextBox.Text = "http://orbdevtfs2:8080/tfs/SageCRE";
            // 
            // _helpTextLabel
            // 
            this._helpTextLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._helpTextLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._helpTextLabel.Location = new System.Drawing.Point(0, 0);
            this._helpTextLabel.Name = "_helpTextLabel";
            this._helpTextLabel.Padding = new System.Windows.Forms.Padding(3);
            this._helpTextLabel.Size = new System.Drawing.Size(404, 36);
            this._helpTextLabel.TabIndex = 0;
            // 
            // toolTip1
            // 
            this.toolTip1.Active = false;
            // 
            // OptionsControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Name = "OptionsControl";
            this.Size = new System.Drawing.Size(404, 376);
            this.Load += new System.EventHandler(this.OptionsControl_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this._tableLayoutPanel.ResumeLayout(false);
            this._tableLayoutPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label _helpTextLabel;
        private System.Windows.Forms.TableLayoutPanel _tableLayoutPanel;
        private System.Windows.Forms.ComboBox _preBuildEventComboBox;
        private System.Windows.Forms.ComboBox _postBuildEventComboBox;
        private System.Windows.Forms.ComboBox _dotNetFrameworkVersionComboBox;
        private System.Windows.Forms.ComboBox _warningsAsErrorsComboBox;
        private System.Windows.Forms.ComboBox _runCodeAnalysisComboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox _normalizeAssemblyReferencesComboBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ComboBox _normalizeOutputPathsComboBox;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox _sourceControlServerTextBox;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.ComboBox _platformTargetComboBox;
        private System.Windows.Forms.ComboBox _assemblySigningComboBox;
        private System.Windows.Forms.Label label10;
    }
}
