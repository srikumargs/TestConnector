﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.XPath;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace LibraryConfigTool.Internal
{
    internal sealed class UnzipStep : IStep
    {
        public UnzipStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _zipFileName = Utils.GetRequiredAttribute(navigator, Constants.FileNameAttribute, "Unzip", configInfo.ConfigFile);
            _destinationDir = Utils.GetRequiredAttribute(navigator, Constants.DestinationDirAttribute, "Unzip", configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String zipFileName = rootConfigInfo.ReplaceAllVariables(_zipFileName);
            String destinationDir = rootConfigInfo.ReplaceAllVariables(_destinationDir);

            if(!File.Exists(zipFileName))
            {
                using(BatchedOutput output = new BatchedOutput(false))
                {
                    output.BeginWriteError(0, Strings.SourceFileDoesNotExist);
                    output.AddErrorDetail("SourceFile", zipFileName);
                    output.EndWriteError();
                }
            }
            else
            {
                Utils.EnsureDirectoryExists(Directory.GetParent(destinationDir).FullName, "DestinationDir");

                ZipFile zipFile = new ZipFile(File.OpenRead(zipFileName));
                byte[] buffer = new byte[4096];
                String fileName = String.Empty;

                try
                {
                    for (Int32 i = 0; i < zipFile.Count; i++)
                    {
                        ZipEntry zipEntry = zipFile[i];

                        fileName = Path.Combine(destinationDir, zipEntry.Name);
                        fileName = fileName.Replace('/', '\\');

                        //log.LogMessage(MessageImportance.Normal, "Extracting: {0}", fileName);

                        FileDelete(fileName);

                        Utils.EnsureDirectoryExists(Path.GetDirectoryName(fileName));

                        Int32 size = 0;
                        using (Stream zipStream = zipFile.GetInputStream(zipEntry))
                        {
                            FileStream fileStream = File.Create(fileName);

                            do
                            {
                                size = zipStream.Read(buffer, 0, buffer.Length);

                                if (size > 0)
                                {
                                    fileStream.Write(buffer, 0, size);
                                }
                            } while (size > 0);
                            fileStream.Close();
                        }
                    }
                }
                finally
                {
                    zipFile.Close();
                }
            }
        }

        public static void FileDelete(String fileName)
        {
            FileInfo fileInfo = new FileInfo(fileName);
            if (fileInfo.Exists)
            {
                if (fileInfo.Attributes != FileAttributes.Normal)
                {
                    System.IO.File.SetAttributes(fileInfo.FullName, FileAttributes.Normal);
                }

                System.IO.File.Delete(fileName);
            }
        }

        #endregion

        private String _zipFileName;
        private String _destinationDir;
    }
}
