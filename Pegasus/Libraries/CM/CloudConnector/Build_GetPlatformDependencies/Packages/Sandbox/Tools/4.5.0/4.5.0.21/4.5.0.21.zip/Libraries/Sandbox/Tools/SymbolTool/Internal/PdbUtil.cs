﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace SymbolTool.Internal
{
    /// <summary>
    /// Defines static methods to perform symbol store functions on PDB files.
    /// </summary>
    public static class PdbUtil
    {
        /// <summary>
        /// Gets a list of all source files contained in the specified PDB file.
        /// </summary>
        /// <param name="pdb">The PDB file.</param>
        /// <returns>Returns a list of strings.</returns>
        /// <exception cref="SymbolToolException">The exception thrown if a failure occurs.</exception>
        public static IList<string> ReadSourceFiles(PdbFile pdb)
        {
            SymbolStoreTools.VerifyAllToolsExist();
            ProcessStartInfo info = new ProcessStartInfo(SymbolStoreTools.FullPathSrcTool);

            info.UseShellExecute = false;
            info.RedirectStandardError = true;
            info.RedirectStandardOutput = true;
            info.Arguments = string.Format("-r \"{0}\"", pdb.File.FullName);

            string output;
            string errors;

            using (Process p = Process.Start(info))
            {
                output = p.StandardOutput.ReadToEnd();
                errors = p.StandardError.ReadToEnd();

                p.WaitForExit();
            }

            if (!string.IsNullOrEmpty(errors))
            {
                throw new SymbolToolException(string.Format("Error reading source files from PDB \"{1}\".\n\nMessage: {1}", pdb.File, errors));
            }

            List<string> result = new List<string>();

            if (!string.IsNullOrEmpty(output))
            {
                foreach (string item in output.Split('\r', '\n'))
                {
                    string sourceFile = item.Trim();

                    if (string.IsNullOrEmpty(sourceFile))
                        continue;

                    result.Add(sourceFile);
                }
            }

            return result;
        }

        /// <summary>
        /// Writes the source file .ini information into the PDB file.
        /// </summary>
        /// <param name="pdb">The PDB file.</param>
        /// <param name="tempFile">The temp file containing the .ini source file/control section.</param>
        /// <exception cref="SymbolToolException">The exception thrown if a failure occurs.</exception>
        public static void WriteSourceFileStream(PdbFile pdb, FileInfo tempFile)
        {
            SymbolStoreTools.VerifyAllToolsExist();
            ProcessStartInfo info = new ProcessStartInfo(SymbolStoreTools.FullPathPdbStr);
            info.UseShellExecute = false;
            info.RedirectStandardError = true;
            info.RedirectStandardOutput = true;
            info.Arguments = string.Format("-w -p:\"{0}\" -i:\"{1}\" -s:srcsrv", pdb.File.FullName, tempFile.FullName);

            string output;
            string errors;

            using (Process p = Process.Start(info))
            {
                output = p.StandardOutput.ReadToEnd();
                errors = p.StandardError.ReadToEnd();
                p.WaitForExit();
            }

            if (!string.IsNullOrEmpty(errors))
            {
                throw new SymbolToolException(string.Format("Error writing source info to PDB \"{0}\".\n\nMessage: {1}", pdb.File.FullName, errors));
            }
        }
    }
}
