using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Threading;

namespace LibraryConfigTool.Internal
{
    //[Obsolete("Vestige of v1.0 LibraryConfig schema ... should be removed once all clients have upgraded.")]
    internal sealed class DistributeReferencedLibraryManifestsStep : IStep
    {
        public DistributeReferencedLibraryManifestsStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourceDir = Utils.GetRequiredAttribute(navigator, Constants.SourceDirAttribute, Constants.DistributeReferencedLibraryManifestsElement, configInfo.ConfigFile);
            _destinationDir = Utils.GetRequiredAttribute(navigator, Constants.DestinationDirAttribute, Constants.DistributeReferencedLibraryManifestsElement, configInfo.ConfigFile);
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceDir = rootConfigInfo.ReplaceAllVariables(_sourceDir);
            String targetDir = rootConfigInfo.ReplaceAllVariables(_destinationDir);

            ReadOnlyCollection<LibraryReference> libraryReferences = rootConfigInfo.LibraryReferences;
            if(libraryReferences.Count > 0)
            {
                if(!Directory.Exists(sourceDir))
                {
                    using(BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, "Missing library manifest source directory.");
                        output.AddErrorDetail(Strings.Path, sourceDir);
                        output.EndWriteError();
                    }
                    return;
                }

                String targetLibraryManifestsDir = Path.Combine(targetDir, "Library Manifests");
                Utils.EnsureDirectoryExists(targetLibraryManifestsDir, "TargetDir");

                Program.Output.Write(OutputType.Info, "Distributing referenced library manifests...");
                foreach(LibraryReference libraryReference in libraryReferences)
                {
                    String libraryReferenceManifestFile = Path.Combine(sourceDir, Utils.GetReferencedLibraryManfiestFilePath(libraryReference));

                    if(!File.Exists(libraryReferenceManifestFile))
                    {
                        using(BatchedOutput output = new BatchedOutput(false))
                        {
                            output.BeginWriteError(0, "Missing library manifest for referenced library.");
                            output.AddErrorDetail(Strings.Path, libraryReferenceManifestFile);
                            output.EndWriteError();
                        }
                        return;
                    }

                    Boolean fileNeedsToBeCopied = true;

                    String targetFileName = Path.Combine(targetLibraryManifestsDir, Path.GetFileName(libraryReferenceManifestFile));
                    if(File.Exists(targetFileName))
                    {
                        if(Convert.ToBase64String(Utils.GetMD5HashForFileContent(libraryReferenceManifestFile)) == Convert.ToBase64String(Utils.GetMD5HashForFileContent(targetFileName)))
                        {
                            Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Skipping distribution of identical referenced library manifest '{0}'.", targetFileName));
                            fileNeedsToBeCopied = false;
                        }
                    }

                    using(IndentedOutput indentedOutput = new IndentedOutput())
                    {
                        if(fileNeedsToBeCopied)
                        {
                            Utils.CopyFileToTargetDir(libraryReferenceManifestFile, targetLibraryManifestsDir, true);
                        }
                    }
                }
            }
            else
            {
                Program.Output.Write(OutputType.Info, "Skipping distribution of referenced library manifests;  library does not contain any references.");
            }
        }

        #endregion

        private String _sourceDir;
        private String _destinationDir;

    }
}
