﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;

namespace SymbolTool.Internal
{
    internal enum IndentAction
    {
        None = 0,
        Increment,
        Decrement,
        IndentOnce,
        NoIndent,
        Clear
    }

    internal sealed class OutputManager : MarshalByRefObject
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="OutputManager"/> class.
        /// </summary>
        public OutputManager()
        {
            _outputType = OutputType.Banner | OutputType.Error | OutputType.Info | OutputType.Status;
        }

        #endregion

        public override object InitializeLifetimeService()
        {
            return null; // prevent leased-based lifetime management
        }

        #region IResultEventsSubscriber Members

        public Int32 ErrorCount
        {
            get
            {
                return _errorCount;
            }
        }

        public Int32 ChangeIndent(IndentAction indentAction)
        {
            Int32 result = 0;

            switch (indentAction)
            {
                case IndentAction.Decrement:
                    Debug.Assert(_indentLevel > 0);
                    result = (_indentLevel--);
                    break;

                case IndentAction.Increment:
                    result = (_indentLevel++);
                    break;

                case IndentAction.Clear:
                    result = (_indentLevel = 0);
                    break;

                case IndentAction.IndentOnce:
                    result = _indentLevel + 1;
                    break;

                case IndentAction.NoIndent:
                    result = 0;
                    break;

                case IndentAction.None:
                    result = _indentLevel;
                    break;
            }

            return result;
        }

        public OutputType OutputType
        {
            get
            {
                return _outputType;
            }

            set
            {
                _outputType = value;
            }
        }

        public void Write(OutputType outputType, String description)
        {
            Write(null, new ResultEventArgs(outputType, IndentAction.None, description));
        }

        public void Write(OutputType outputType, IndentAction indentAction, String description)
        {
            Write(null, new ResultEventArgs(outputType, indentAction, description));
        }

        public void Write(Object sender, ResultEventArgs args)
        {
            if (args.OutputType == OutputType.Error)
            {
                _errorCount++;
            }

            Int32 indentLevel = ChangeIndent(args.IndentAction);
            String message = string.Format(CultureInfo.CurrentCulture, "{0}{1}", new String(' ', indentLevel * 3), args.Description);
            if ((args.OutputType & _outputType) != OutputType.None)
            {
                Console.WriteLine(message);
            }
            System.Diagnostics.Trace.WriteLine(message);
        }

        public Int32 PushIndentLevel(Int32 indentLevel)
        {
            Int32 result = _indentLevel;
            _indentLevelStack.Push(_indentLevel);
            _indentLevel = indentLevel;
            return result;
        }

        public Int32 PopIndentLevel()
        {
            _indentLevel = _indentLevelStack.Pop();
            return _indentLevel;
        }

        #endregion

        private Int32 _indentLevel;     //= 0; (automatically initialized by runtime)
        private OutputType _outputType; //= OutputType.None; (automatically initialized by runtime)
        private Int32 _errorCount;      //= 0; (automatically initialized by runtime)
        private Stack<Int32> _indentLevelStack = new Stack<Int32>();
    }
}
