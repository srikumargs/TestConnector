﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.IO;

namespace LibraryConfigTool.Internal
{
    internal sealed class XslTransformStep : IStep
    {
        public XslTransformStep(ConfigInfo configInfo, XPathNavigator navigator)
        {
            _sourceFile = Utils.GetRequiredAttribute(navigator, Constants.SourceFileAttribute, Constants.XslTransformElement, configInfo.ConfigFile);
            _xsltFile = Utils.GetRequiredAttribute(navigator, "XsltFile", Constants.XslTransformElement, configInfo.ConfigFile);
            _destinationFile = Utils.GetRequiredAttribute(navigator, Constants.DestinationFileAttribute, Constants.XslTransformElement, configInfo.ConfigFile);
            _arguments = Utils.GetOptionalAttribute(navigator, "Arguments");
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            String sourceFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_sourceFile), rootConfigInfo);
            String xsltFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_xsltFile), rootConfigInfo);
            String destinationFile = Utils.GetRootedPath(rootConfigInfo.ReplaceAllVariables(_destinationFile), rootConfigInfo);
            String arguments = rootConfigInfo.ReplaceAllVariables(_arguments);

            XslCompiledTransform xslTransform = new XslCompiledTransform();
            XsltSettings settings = XsltSettings.Default;
            settings.EnableDocumentFunction = true;
            settings.EnableScript = true;
            xslTransform.Load(xsltFile, settings, null);

            XPathDocument xmlToTransform = new XPathDocument(XmlReader.Create(new StreamReader(new FileStream(sourceFile, FileMode.Open, FileAccess.Read), Encoding.UTF8)));

            Utils.EnsureDirectoryExists(Path.GetDirectoryName(destinationFile));

            XmlTextWriter xmlTextWriter = new XmlTextWriter(destinationFile, Encoding.UTF8);
            xmlTextWriter.Formatting = Formatting.Indented;

            if(!String.IsNullOrEmpty(arguments))
            {
                String[] splitArguments = arguments.Split(';');
                XsltArgumentList argumentList = new XsltArgumentList();
                foreach (String splitArgument in splitArguments)
                {
                    argumentList.AddParam(splitArgument.Substring(0, splitArgument.IndexOf('=')), "", splitArgument.Substring(splitArgument.IndexOf('=') + 1));
                }

                xslTransform.Transform(xmlToTransform, argumentList, xmlTextWriter);
            }
            else
            {
                xslTransform.Transform(xmlToTransform, xmlTextWriter);
            }
            xmlTextWriter.Flush();
            xmlTextWriter.Close();
        }

        #endregion

        private String _sourceFile;
        private String _xsltFile;
        private String _destinationFile;
        private String _arguments;
    }
}
