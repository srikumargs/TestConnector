using System;
using System.Collections.Generic;
using System.Text;

namespace DevBoxCleaner.Internal
{
    internal abstract class Cleaner : ICleaner
    {
        public void Execute(IPromptUser promptUser, Boolean testOnly)
        {
            _promptUser = promptUser;
            _testOnly = testOnly;
            DoExecute();
        }

        public event EventHandler<ResultEventArgs> AppendResult
        {
            add
            {
                _appendResult += value;
            }
            remove
            {
                _appendResult -= value;
            }
        }

        protected abstract void DoExecute();

        protected IPromptUser PromptUser
        {
            get
            {
                return _promptUser;
            }
        }

        protected Boolean TestOnly
        {
            get
            {
                return _testOnly;
            }
        }

        protected void FireAppendResult(ResultCode code, String description)
        {
            if(_appendResult != null)
            {
                _appendResult(this, new ResultEventArgs(code, TestOnly ? "[TEST] " + description : description));
            }
        }

        protected void FireAppendResult(ResultCode code, String description, String details)
        {
            if(_appendResult != null)
            {
                _appendResult(this, new ResultEventArgs(code, TestOnly ? "[TEST] " + description : description, details));
            }
        }

        private EventHandler<ResultEventArgs> _appendResult; // = null; (automatically initialized by runtime)
        private IPromptUser _promptUser;                    // = null; (automatically initialized by runtime)
        private Boolean _testOnly;                          // = false; (automatically initialized by runtime)
    }
}
