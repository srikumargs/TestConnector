﻿using System;

namespace CompressionBase64Encoder.Internal
{
    internal sealed class Options
    {
        public Boolean IsValid
        {
            get
            {
                Boolean result = true;

                if (String.IsNullOrEmpty(InputFileName))
                {
                    result = false;
                }

                if (result &&
                    (String.IsNullOrEmpty(TemplateFileName) && !String.IsNullOrEmpty(ReplaceTag) ||
                    !String.IsNullOrEmpty(TemplateFileName) && String.IsNullOrEmpty(ReplaceTag)))
                {
                    result = false;
                }

                return result;
            }
        }

        public Boolean DoTemplateReplace
        {
            get
            {
                return !String.IsNullOrEmpty(TemplateFileName);
            }
        }

        public Boolean DoOutputToFile
        {
            get
            {
                return !String.IsNullOrEmpty(OutputFileName);
            }
        }

        public Boolean Debug
        {
            get;
            set;
        }

        public String InputFileName
        {
            get;
            set;
        }

        public String TemplateFileName
        {
            get;
            set;
        }

        public String ReplaceTag
        {
            get;
            set;
        }

        public String OutputFileName
        {
            get;
            set;
        }
    }
}
