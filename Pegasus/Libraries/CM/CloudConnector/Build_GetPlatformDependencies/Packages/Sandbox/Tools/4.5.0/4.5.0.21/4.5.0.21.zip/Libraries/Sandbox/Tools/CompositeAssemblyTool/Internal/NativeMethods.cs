using System;
using System.Runtime.InteropServices;

namespace CompositeAssemblyTool.Internal
{
    /// <summary>
    /// Contains definitions of common unmanaged Win32 API functions, 
    /// constants, and structures. For more information see the Platform SDK
    /// documentation.
    /// </summary>
    internal static class NativeMethods
    {
        /// <summary>
        /// ThrowLastError is a helper function to translate Win32 error codes
        /// into exceptions that can be handled by managed code. It is 
        /// conceptually the same as the following C++ code:
        /// 
        ///     throw HRESULT_FROM_WIN32(::GetLastError());
        /// 
        /// </summary>
        public static void ThrowLastWin32Error()
        {
            throw new System.ComponentModel.Win32Exception();
        }

        [DllImport("Kernel32.dll", SetLastError=true, CharSet=CharSet.Auto)]
        public static extern IntPtr LoadLibraryEx(String strFileName, IntPtr hFile, UInt32 ulFlags);

        [DllImport("Kernel32.dll", SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern Boolean FreeLibrary(IntPtr hModule);

        [DllImport("Kernel32.dll", SetLastError=true, CharSet=CharSet.Auto)]
        public static extern IntPtr FindResource(IntPtr hModule, IntPtr pName, IntPtr pType);

        [DllImport("Kernel32.dll", SetLastError=true)]
        public static extern IntPtr LoadResource(IntPtr hModule, IntPtr hResource);

        [DllImport("Kernel32.dll", SetLastError=true)]
        public static extern UInt32 SizeofResource(IntPtr hModule, IntPtr hResource);

        [DllImport("Kernel32.dll")]
        public static extern IntPtr LockResource(IntPtr hGlobal);

        [DllImport("Kernel32.dll", SetLastError=true, CharSet=CharSet.Auto)]
        public static extern Int32 EnumResourceNames(IntPtr hModule, IntPtr pType, EnumResNameProc enumFunc, IntPtr param);

        [DllImport("User32.dll", SetLastError=true, CharSet=CharSet.Auto)]
        public static extern IntPtr LoadIcon(IntPtr hInstance, IntPtr pName);

        unsafe public static Boolean IS_INTRESOURCE(IntPtr wInteger)
        {
            UInt32 uiInteger = (UInt32) wInteger.ToPointer();
            return ((uiInteger >> 16) == 0);
        }

        public static readonly IntPtr RT_ICON = new IntPtr(3);
        public static readonly IntPtr RT_GROUP_ICON = new IntPtr(14);

        public const UInt32 LOAD_LIBRARY_AS_DATAFILE = 0x00000002;

        public delegate Boolean EnumResNameProc(IntPtr hModule, IntPtr pType, IntPtr pName, IntPtr param);

        [StructLayout(LayoutKind.Sequential)]
        public struct BITMAPINFOHEADER
        {
            public UInt32 biSize;
            public Int32 biWidth;
            public Int32 biHeight;
            public UInt16 biPlanes;
            public UInt16 biBitCount;
            public UInt32 biCompression;
            public UInt32 biSizeImage;
            public Int32 biXPelsPerMeter;
            public Int32 biYPelsPerMeter;
            public UInt32 biClrUsed;
            public UInt32 biClrImportant;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct RGBQUAD
        {
            public Byte rgbBlue;
            public Byte rgbGreen;
            public Byte rgbRed;
            public Byte rgbReserved;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct BITMAPINFO
        {
            public BITMAPINFOHEADER bmiHeader;
            public RGBQUAD bmiColors; // inline array
        }

        /// <summary>
        /// MEMICONDIRENTRY helps to defines the memory layout of a 
        /// RT_GROUP_ICON resource. In particular its wId member indicates the
        /// RT_ICON resource for the directory entry.
        /// </summary>
        [StructLayout(LayoutKind.Sequential, Pack=2)]
        public struct MEMICONDIRENTRY
        {
            public Byte bWidth;
            public Byte bHeight;
            public Byte bColorCount;
            public Byte bReserved;
            public UInt16 wPlanes;
            public UInt16 wBitCount;
            public UInt32 dwBytesInRes;
            public UInt16 wId;
        }

        /// <summary>
        /// MEMICONDIR defines the memory layout of a RT_GROUP_ICON Win32
        /// resource.
        /// </summary>
        [StructLayout(LayoutKind.Sequential, Pack=2)]
        public struct MEMICONDIR
        {
            public UInt16 wReserved;
            public UInt16 wType;
            public UInt16 wCount;
            public MEMICONDIRENTRY arEntries; // inline array
        }

        /// <summary>
        /// FILEICONDIRENTRY defines the peristent format of an icon directory 
        /// entry in a .ICO file.
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct FILEICONDIRENTRY
        {
            public Byte bWidth;
            public Byte bHeight;
            public Byte bColorCount;
            public Byte bReserved;
            public UInt16 wPlanes;
            public UInt16 wBitCount;
            public UInt32 dwBytesInRes;
            public UInt32 dwImageOffset;
        }
    }
}
