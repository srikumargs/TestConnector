using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.IO;
using System.Reflection;

using CompositeAssemblyTool.Internal;

namespace CompositeAssemblyTool
{
    internal static class Program
    {
        [STAThread]
        static void Main(String[] args)
        {
            Environment.ExitCode = 1;

            DateTime startTime = DateTime.Now;

            try
            {
                String rootNamespace = String.Empty;
                String primaryAssembly = String.Empty;
                List<String> additionalAssemblies = new List<string>();
                String outFile = Path.Combine(Environment.CurrentDirectory, "Composite.exe");

                String assemblyTitle = String.Empty;
                String assemblyConfiguration = String.Empty;
                String assemblyDescription = String.Empty;
                String assemblyCompany = String.Empty;
                String assemblyProduct = String.Empty;
                String assemblyCopyright = String.Empty;
                String assemblyTrademark = String.Empty;
                String assemblyCulture = String.Empty;
                String assemblyFileVersion = String.Empty;
                String assemblyVersion = String.Empty;
                String assemblyInformationalVersion = String.Empty;
                String keyfileName = String.Format(CultureInfo.InvariantCulture, @"{0}\Build\PlatformKeyfile.snk", Environment.GetEnvironmentVariable("SAGE_SANDBOX"));
                String win32IconFileName = String.Empty;
                String embeddedCommandLine = String.Empty;
                Boolean consoleApplication = false;

                foreach (String arg in args)
                {
                    if (String.Compare(arg, "/help", true, CultureInfo.InvariantCulture) == 0 || String.Compare(arg, "/?", true, CultureInfo.InvariantCulture) == 0)
                    {
                        _command |= Command.PrintHelp;
                    }
                    else if (arg.StartsWith("/primary:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/p:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        primaryAssembly = Path.GetFullPath(arg.Substring(arg.IndexOf(':') + 1));
                    }
                    else if (arg.StartsWith("/assembly:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/a:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        additionalAssemblies.Add(Path.GetFullPath(arg.Substring(arg.IndexOf(':') + 1)));
                    }
                    else if (arg.StartsWith("/out:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/o:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        outFile = Path.GetFullPath(arg.Substring(arg.IndexOf(':') + 1));
                    }
                    else if (arg.StartsWith("/asmtitle:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/ati:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyTitle = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/asmconfig:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/acn:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyConfiguration = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/asmdescription:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/ad:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyDescription = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/asmcompany:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/aco:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyCompany = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/asmproduct:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/ap:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyProduct = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/asmcopyright:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/acp:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyCopyright = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/asmtrademark:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/atr:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyTrademark = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/asmculture:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/acu:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyCulture = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/asmfilever:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/afv:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyFileVersion = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/asmver:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/av:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyVersion = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/asminfover:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/aiv:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        assemblyInformationalVersion = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                    }
                    else if (arg.StartsWith("/keyfile:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/k:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        keyfileName = Path.GetFullPath(arg.Substring(arg.IndexOf(':') + 1));
                    }
                    else if (arg.StartsWith("/win32icon:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/w:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        win32IconFileName = Path.GetFullPath(arg.Substring(arg.IndexOf(':') + 1));
                    }
                    else if (arg.StartsWith("/commandlineparam:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/clp:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        embeddedCommandLine = arg.Substring(arg.IndexOf(':') + 1).Trim('"');
                        embeddedCommandLine += " ";
                    }
                    else if (String.Compare(arg, "/consoleapp", true, CultureInfo.InvariantCulture) == 0)
                    {
                        consoleApplication = true;
                    }
                    else if (String.Compare(arg, "/nologo", true, CultureInfo.InvariantCulture) == 0)
                    {
                        _outputManager.OutputType = _outputManager.OutputType & ~OutputType.Banner;
                    }
                    else if (String.Compare(arg, "/silent", true, CultureInfo.InvariantCulture) == 0)
                    {
                        _outputManager.OutputType = _outputManager.OutputType & ~(OutputType.Banner | OutputType.Info | OutputType.Verbose);
                    }
                    else if (String.Compare(arg, "/verbose", true, CultureInfo.InvariantCulture) == 0)
                    {
                        _outputManager.OutputType = _outputManager.OutputType | (OutputType.Info | OutputType.Verbose);
                    }
                }

                if (String.IsNullOrEmpty(rootNamespace))
                {
                    rootNamespace = Path.GetFileNameWithoutExtension(outFile).Replace(".", "_");
                }

                if (String.IsNullOrEmpty(primaryAssembly) || additionalAssemblies.Count == 0 || String.IsNullOrEmpty(additionalAssemblies[0]))
                {
                    _command |= Command.PrintHelp;
                }
                else
                {
                    _command |= Command.Create;
                }

                if (PrintHelp)
                {
                    _outputManager.OutputType = _outputManager.OutputType | OutputType.Help;
                    DoPrintHelp();
                    Environment.ExitCode = 1;
                }
                else
                {
                    PrintBanner();

                    if (Create)
                    {
                        Compiler compiler = new Compiler();
                        compiler.AssemblyTitle = assemblyTitle;
                        compiler.AssemblyConfiguration = assemblyConfiguration;
                        compiler.AssemblyDescription = assemblyDescription;
                        compiler.AssemblyCompany = assemblyCompany;
                        compiler.AssemblyProduct = assemblyProduct;
                        compiler.AssemblyCopyright = assemblyCopyright;
                        compiler.AssemblyTrademark = assemblyTrademark;
                        compiler.AssemblyCulture = assemblyCulture;
                        compiler.AssemblyVersion = assemblyVersion;
                        compiler.AssemblyFileVersion = assemblyFileVersion;
                        compiler.AssemblyInformationalVersion = assemblyInformationalVersion;
                        compiler.KeyfileName = keyfileName;
                        compiler.Win32IconFileName = win32IconFileName;
                        compiler.EmbeddedCommandLine = embeddedCommandLine;
                        compiler.ConsoleApplication = consoleApplication;

                        compiler.Compile(rootNamespace, primaryAssembly, additionalAssemblies.AsReadOnly(), outFile);
                    }

                    Environment.ExitCode = 0;
                }
            }
            catch (Exception ex)
            {
                //using (BatchedOutput output = new BatchedOutput(false))
                //{
                //    output.BeginWriteError(0, ex.ToString());
                //    output.EndWriteError();
                //}
                Output.Write(OutputType.Error, ex.ToString());
            }

            if (_outputManager.ErrorCount > 0)
            {
                if (!PrintHelp)
                {
                    Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "CompositeAssemblyTool '{0}' action FAILED;  elapsed time {1}", _command, DateTime.Now - startTime));
                }
                Environment.ExitCode = 1;
            }
            else
            {
                if (!PrintHelp)
                {
                    Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "CompositeAssemblyTool '{0}' action successfully completed;  elapsed time {1}", _command, DateTime.Now - startTime));
                }
            }
        }

        public static Boolean PrintHelp
        {
            get
            {
                return (_command & Command.PrintHelp) != Command.None;
            }
        }

        public static Boolean Create
        {
            get
            {
                return (_command & Command.Create) != Command.None;
            }
        }

        private static void PrintBanner()
        {
            Program.Output.Write(OutputType.Banner, "Sage Composite Assembly Tool.  Version " + Assembly.GetExecutingAssembly().GetName().Version);
            Program.Output.Write(OutputType.Banner, "");
        }

        private static void DoPrintHelp()
        {
            PrintBanner();

            Output.Write(OutputType.Help, "Syntax: CompositeAssemblyTool /p:<primary assembly> [/a:<additional assembly>] [Options]");
            Output.Write(OutputType.Help, "Commands:");
            Output.Write(OutputType.Help, "  /primary, /p:<file>");
            Output.Write(OutputType.Help, "    Specifies the primary assembly to embed into the composite result");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /assembly, /a:<file>");
            Output.Write(OutputType.Help, "    Specifies an additional assembly to embed into the composite result");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "Options:");
            Output.Write(OutputType.Help, "  /out, /o:<file>");
            Output.Write(OutputType.Help, "    Specifies output file name (default: Composite.exe)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /namespace, /n:<root namespace>");
            Output.Write(OutputType.Help, "    Specifies root namespace (default: base name of output file)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asmtitle, /ati:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyTitleAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asmconfig, /acn:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyConfigurationAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asmdescription, /ad:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyDescriptionAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asmcompany, /aco:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyCompanyAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asmproduct, /ap:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyProductAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asmcopyright, /acp:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyCopyrightAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asmtrademark, /atr:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyTrademarkAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asmculture, /acu:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyCultureAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asmfilever, /af:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyFileVersionAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asmver, /av:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyVersionAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /asminfover, /aiv:<file>");
            Output.Write(OutputType.Help, "    Specifies value of the AssemblyInformationalVersionAttribute (default: use attribute declared on primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /consoleapp");
            Output.Write(OutputType.Help, "    Generate composite result as a console application (default: generate result as a Windows application)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /keyfile, /k:<file>");
            Output.Write(OutputType.Help, "    Specifies a strong name key file");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /win32icon, /w:<file>");
            Output.Write(OutputType.Help, "    Specifies an icon file (default: use icon of primary assembly)");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /commandlineparam, /clp:<file>");
            Output.Write(OutputType.Help, "    Specifies a command-line parameter to embed into the composite assembly");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /nologo");
            Output.Write(OutputType.Help, "    Suppress display of the logo banner");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /silent");
            Output.Write(OutputType.Help, "    Silent mode. Prevents displaying of success messages");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /verbose");
            Output.Write(OutputType.Help, "    Displays extra information");
            Output.Write(OutputType.Help, "");
            Output.Write(OutputType.Help, "  /?, /help");
            Output.Write(OutputType.Help, "    Displays this usage message");
        }

        internal static OutputManager Output
        {
            get
            {
                return _outputManager;
            }
        }

        private static Command _command;    //= Command.None; (automatically initialized by runtime)
        private static OutputManager _outputManager = new OutputManager();
    }
}
