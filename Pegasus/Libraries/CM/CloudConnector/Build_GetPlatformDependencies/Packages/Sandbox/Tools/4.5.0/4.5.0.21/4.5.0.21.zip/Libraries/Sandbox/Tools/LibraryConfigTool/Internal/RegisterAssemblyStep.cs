using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Reflection;

namespace LibraryConfigTool.Internal
{
    [Flags]
    internal enum RegistrationMode
    {
        None                = 0x00,
        TlbExp              = 0x01,
        RegisterAssembly    = 0x02
    }

    internal sealed class RegisterAssemblyStep : IStep
    {
        public RegisterAssemblyStep(ConfigInfo configInfo, XPathNavigator navigator, RegistrationMode registrationMode)
        {
            _path = Utils.GetRequiredAttribute(navigator, Constants.PathAttribute, Constants.RegisterAssemblyElement, configInfo.ConfigFile);
            _typeLibPath = Utils.GetRequiredAttribute(navigator, Constants.TypeLibPathAttribute, Constants.RegisterAssemblyElement, configInfo.ConfigFile);
            _registrationMode = registrationMode;
        }

        #region IStep Members

        public void Execute(ConfigInfo rootConfigInfo)
        {
            switch (_registrationMode)
            {
                case RegistrationMode.RegisterAssembly:
                    Program.Output.Write(OutputType.Info, "Performing assembly registration...");
                    break;

                case RegistrationMode.TlbExp:
                    Program.Output.Write(OutputType.Info, "Performing type library export...");
                    break;
            }

            using(IndentedOutput indentedOutput = new IndentedOutput())
            {
                String path = rootConfigInfo.ReplaceAllVariables(_path);
                String typeLibPath = rootConfigInfo.ReplaceAllVariables(_typeLibPath);

                try
                {
                    if(!File.Exists(path))
                    {
                        using(BatchedOutput output = new BatchedOutput(false))
                        {
                            output.BeginWriteError(0, Strings.AssemblyRegistrationFailedFileNotFound);
                            output.AddErrorDetail(Strings.Path, path);
                            output.AddErrorDetail(Strings.TypeLibPath, typeLibPath);
                            output.EndWriteError();
                        }
                    }
                    else
                    {
                        Utils.EnsureDirectoryExists(Path.GetDirectoryName(typeLibPath), "TargetTypeLibDir");

                        using(IndentedOutput remoteIndentedOutput = new IndentedOutput())
                        {
                            AppDomainSetup appDomainSetup = new AppDomainSetup();
                            appDomainSetup.ApplicationBase = Directory.GetParent(path).FullName;
                            AppDomain appDomain = AppDomain.CreateDomain("RemoteAssemblyRegistrar", null, appDomainSetup);
                            try
                            {
                                RemoteAssemblyRegistrar registrar = (RemoteAssemblyRegistrar) appDomain.CreateInstanceFromAndUnwrap(Assembly.GetExecutingAssembly().CodeBase, "LibraryConfigTool.Internal.RemoteAssemblyRegistrar");
                                switch (_registrationMode)
                                {
                                    case RegistrationMode.RegisterAssembly:
                                        registrar.RegisterAssembly(Program.Output, path, typeLibPath);
                                        break;

                                    case RegistrationMode.TlbExp:
                                        registrar.ExportTypeLibrary(Program.Output, path, typeLibPath);
                                        break;
                                }
                            }
                            finally
                            {
                                AppDomain.Unload(appDomain);
                            }
                        }

                        switch (_registrationMode)
                        {
                            case RegistrationMode.RegisterAssembly:
                                Program.Output.Write(OutputType.Info, "Assembly registration succeeded.");
                                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:        '{0}'", path));
                                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "TypeLibPath: '{0}'", typeLibPath));
                                break;

                            case RegistrationMode.TlbExp:
                                Program.Output.Write(OutputType.Info, "Type library export succeeded.");
                                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "Path:        '{0}'", path));
                                Program.Output.Write(OutputType.Info, IndentAction.IndentOnce, String.Format(CultureInfo.CurrentCulture, "TypeLibPath: '{0}'", typeLibPath));
                                break;
                        }
                    }
                }
                catch(Exception ex)
                {
                    using(BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, Strings.AssemblyRegistrationFailed);
                        output.AddErrorDetail(Strings.Path, path);
                        output.AddErrorDetail(Strings.TypeLibPath, typeLibPath);
                        output.AddErrorDetail(Strings.Error, ex.ToString());
                        output.EndWriteError();
                    }
                }
            }
        }

        #endregion

        private String _path;
        private String _typeLibPath;
        private RegistrationMode _registrationMode;
    }
}
