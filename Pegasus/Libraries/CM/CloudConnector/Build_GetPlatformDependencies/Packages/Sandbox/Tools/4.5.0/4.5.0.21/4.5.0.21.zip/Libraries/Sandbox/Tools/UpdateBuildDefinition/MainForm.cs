﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Server;
using Microsoft.TeamFoundation.Build.Client;
using System.Globalization;

namespace UpdateBuildDefinition
{
    internal partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void _tfsServerTextBox_Leave(object sender, EventArgs e)
        {
            _tfsProjectComboBox.Items.Clear();

            using (var server = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(new Uri(_tfsServerTextBox.Text)))
            {
                var projectCollection = (ICommonStructureService)server.GetService(typeof(ICommonStructureService));
                foreach (var projectInfo in projectCollection.ListProjects())
                {
                    _tfsProjectComboBox.Items.Add(projectInfo.Name);
                }
            }

            if (_tfsProjectComboBox.Items.Count > 0)
            {
                _tfsProjectComboBox.SelectedIndex = 0;
            }
        }

        private void _tfsProjectComboBox_Leave(object sender, EventArgs e)
        {
            _sourceDefinitioncomboBox.Items.Clear();

            using (var server = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(new Uri(_tfsServerTextBox.Text)))
            {
                var buildServer = (IBuildServer)server.GetService(typeof(IBuildServer));
                foreach (var buildDefinition in buildServer.QueryBuildDefinitions(_tfsProjectComboBox.Text))
                {
                    _sourceDefinitioncomboBox.Items.Add(buildDefinition.Name);
                }
            }

            if (_sourceDefinitioncomboBox.Items.Count > 0)
            {
                _sourceDefinitioncomboBox.SelectedIndex = 0;
            }
        }

        private void _sourceDefinitioncomboBox_Leave(object sender, EventArgs e)
        {
            using (var server = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(new Uri(_tfsServerTextBox.Text)))
            {
                var buildServer = (IBuildServer)server.GetService(typeof(IBuildServer));
                var buildDefinition = buildServer.GetBuildDefinition(_tfsProjectComboBox.Text, _sourceDefinitioncomboBox.Text);

                _workspaceSearchRootComboBox.Items.Clear();
                foreach (var mapping in buildDefinition.Workspace.Mappings)
                {
                    _workspaceSearchRootComboBox.Items.Add(mapping.ServerItem);
                }
            }
        }

        private void _UpdateBuildDefinitionButton_Click(object sender, EventArgs e)
        {
            try
            {
                using (var server = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(new Uri(_tfsServerTextBox.Text)))
                {
                    var buildServer = (IBuildServer)server.GetService(typeof(IBuildServer));

                    var buildDefinition = buildServer.GetBuildDefinition(_tfsProjectComboBox.Text, _sourceDefinitioncomboBox.Text);
                    foreach (var mapping in buildDefinition.Workspace.Mappings)
                    {
                        mapping.ServerItem = mapping.ServerItem.Replace(_workspaceSearchRootComboBox.Text, _workspaceReplaceRootTextBox.Text);
                    }
                    buildDefinition.Save();
                    MessageBox.Show(this, String.Format(CultureInfo.CurrentUICulture, "'{0}' build definition updated successfully.", buildDefinition.Name));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.ToString());
            }
        }
    }
}
