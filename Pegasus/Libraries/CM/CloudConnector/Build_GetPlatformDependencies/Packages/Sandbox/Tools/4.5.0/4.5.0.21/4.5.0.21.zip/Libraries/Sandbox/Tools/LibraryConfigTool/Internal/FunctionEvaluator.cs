﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Reflection;
using System.IO;
using System.ServiceProcess;
using System.Globalization;
using System.Collections.ObjectModel;

namespace LibraryConfigTool.Internal
{
    internal sealed class FunctionEvaluator
    {
        public static Boolean IsFunction(String input)
        {
            Boolean result = false;

            Match match = Regex.Match(input, ValidFunctionRegex);
            if (match.Success)
            {
                String functionName = match.Groups[2].Value;
                MemberInfo[] memberInfos = typeof(FunctionEvaluator).GetMember(functionName, MemberTypes.Method, BindingFlags.NonPublic | BindingFlags.Instance);
                if (memberInfos != null && memberInfos.Length == 1)
                {
                    result = true;
                }
            }

            return result;
        }

        public static String Evaluate(ConfigInfo configInfo, String test)
        {
            FunctionEvaluator evaluator = new FunctionEvaluator(configInfo);
            return evaluator.DoEvaluate(test);
        }

        private FunctionEvaluator(ConfigInfo configInfo)
        {
            _rootConfigInfo = configInfo;
        }

        private static String ValidFunctionRegex
        { get { return @"([!]?)[ ]*([a-zA-z0-9_]+)\(((?>[^()]+|\((?<DEPTH>)|\)(?<-DEPTH>))*(?(DEPTH)(?!)))\)"; } }

        private String DoEvaluate(String test)
        {
            String result = String.Empty;

            Match match = Regex.Match(test, ValidFunctionRegex);
            if (match.Success)
            {
                String functionName = match.Groups[2].Value;
                Boolean negated = false;

                if ((match.Groups[1].Value.Length % 2) != 0)
                {
                    negated = true;
                }

                functionName = functionName.TrimStart('!', ' ');

                String[] parametersSubstrings = match.Groups[3].Value.Split(',');

                MemberInfo[] memberInfos = typeof(FunctionEvaluator).GetMember(functionName, MemberTypes.Method, BindingFlags.NonPublic | BindingFlags.Instance);
                if (memberInfos == null || memberInfos.Length != 1)
                {
                    using (BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, "Evaluation of if test failed;  unsupported function.");
                        output.AddErrorDetail("FunctionName", functionName);
                        output.EndWriteError();
                    }
                }
                else
                {
                    Object[] arguments = new object[parametersSubstrings.Length];
                    if (functionName != "BooleanTest")
                    {
                        for (Int32 i = 0; i < arguments.Length; i++)
                        {
                            arguments[i] = _rootConfigInfo.ReplaceAllVariables(parametersSubstrings[i]).Trim();
                        }
                    }
                    else
                    {
                        // BooleanTest is a special "function" which takes something that ought to be interpretted as a BooleanExpression; pass the unexpanded expression
                        // to the function rather than the standard ReplaceAllVariables
                        arguments[0] = parametersSubstrings[0];
                    }
                    result = typeof(FunctionEvaluator).InvokeMember(functionName, BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.InvokeMethod, null, this, arguments, CultureInfo.InvariantCulture).ToString();

                    Boolean tryParseResult;
                    if (negated && Boolean.TryParse(result, out tryParseResult))
                    {
                        result = (!tryParseResult).ToString();
                    }

                    result = test.Replace(match.Groups[0].Value, result);
                }
            }

            return result;
        }

        private Boolean BooleanTest(String expression)
        { return BooleanExpression.Parse(expression, _rootConfigInfo.ConfigFile).Evaluate(_rootConfigInfo); }

        private Boolean IsVariableDefined(String variableName)
        { return _rootConfigInfo.IsVariableDefined(variableName); }

        private Boolean IsServiceInstalled(String serviceName)
        {
            String displayName = String.Empty;

            try
            {
                // access a property as a proactive check to determine whether or not the service is actually installed
                ServiceController serviceController;
                using (serviceController = new ServiceController(serviceName))
                {
                    displayName = serviceController.DisplayName; // access a real property to force an exception to be thrown if service is not installed
                }
            }
            catch (InvalidOperationException)
            {
                // this exception gets thrown when trying to access a property for a service that is not actually installed
            }

            return (displayName.Length > 0);
        }

        private Boolean IsServiceRunning(String serviceName)
        {
            Boolean result = false;

            if (IsServiceInstalled(serviceName))
            {
                ServiceController serviceController;
                using (serviceController = new ServiceController(serviceName))
                {
                    result = (ServiceControllerStatus.Running == serviceController.Status);
                }
            }

            return result;
        }

        private String FormatVersionString(String versionAString, String formatString)
        {
            String result;

            Version version = new Version(versionAString);
            result = String.Format(formatString, version.Major, version.Minor, version.Build, version.Revision);

            return result;
        }

        private Boolean CollectionContains(String collectionName, String valueToFind)
        {
            Boolean result = false;

            String variableName = Utils.GetVariableNameKeyForVariableName(collectionName);
            if (_rootConfigInfo.IsCollectionVariableDefined(variableName))
            {
                ReadOnlyCollection<String> values = _rootConfigInfo.GetCollectionVariableValue(variableName);
                foreach (String value in values)
                {
                    if (value == valueToFind)
                    {
                        result = true;
                        break;
                    }
                }
            }

            return result;
        }

        private Boolean IsCollectionEmpty(String collectionName)
        {
            Boolean result = true;

            String variableName = Utils.GetVariableNameKeyForVariableName(collectionName);
            if (_rootConfigInfo.IsCollectionVariableDefined(variableName))
            {
                ReadOnlyCollection<String> values = _rootConfigInfo.GetCollectionVariableValue(variableName);
                if (values.Count > 0)
                {
                    result = false;
                }
            }

            return result;
        }

        private string CollectionValuesAsString(String collectionName)
        {
            String result = String.Empty;
            StringBuilder stringBuilder = new StringBuilder();

            String variableName = Utils.GetVariableNameKeyForVariableName(collectionName);
            if (_rootConfigInfo.IsCollectionVariableDefined(variableName))
            {
                ReadOnlyCollection<String> values = _rootConfigInfo.GetCollectionVariableValue(variableName);
                foreach (String value in values)
                {
                    stringBuilder.AppendFormat("{0};", value);
                }
                result = stringBuilder.ToString().TrimEnd(';');
            }

            return result;
        }

        /// <summary>
        /// Returns whether the specified file is a .NET assembly
        /// </summary>
        /// <remarks>
        /// There are some scenarios where need to programmatically check if
        /// the given file is a .NET assembly or not.  How do we do that?
        /// One way is to use reflection and try to load that file (assembly).
        /// 
        /// If the assembly gets loaded, and doesn’t throw any exception, then
        /// yes, it is a valid .NET assembly.  If it is not a valid file, then
        /// it will throw a "BadImageFormatException".  The idea of checking
        /// whether a file is assembly or not by loading it and checking if an
        /// exception is thrown or not is problematic, however, because it
        /// that references the assembly has to other assemblies may also need
        /// to be successfully resolved.
        /// 
        /// .NET assemblies are regular Win32 PE files.  The operating system
        /// does not differentiate between .NET assemblies and Win32 executable
        /// binaries.  They are both "normal" PE files.  So how does the
        /// Operating System know if this file is a managed assembly and, if so,
        /// how to load the CLR?
        /// 
        /// If we go through the ECMA Specifications (Ecma-335:  CLI Partition
        /// II – Metadata), which is shipped along with .NET SDK, we see that
        /// there is a separate CLI Header in the PE Format.  It is the 15th
        /// data directory in the PE Optional Headers. So, in simple terms,
        /// if we have value in this data directory, then it means that this is
        /// a valid .NET assembly, otherwise it is not.
        /// 
        /// http://msdn2.microsoft.com/en-us/netframework/aa569283.aspx
        /// </remarks>
        /// <param name="path"></param>
        /// <returns></returns>
        private Boolean IsAssemblyFile(String path)
        {
            Boolean result = false;

            try
            {
                UInt32 peHeader;
                UInt16 dataDirectoriesStart;
                UInt32[] dataDirectoryRVA = new uint[16];
                UInt32[] dataDirectorySize = new uint[16];

                using (Stream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read))
                using (BinaryReader binaryReader = new BinaryReader(fileStream))
                {
                    // PE Header starts @ 0x3C (60). Its a 4 byte header.
                    //
                    // (Ecma-335 - Partition II; section 25.2.1 "MS-DOS header")
                    fileStream.Position = 0x3C;
                    peHeader = binaryReader.ReadUInt32();

                    // Moving to PE Header start location...
                    fileStream.Position = peHeader;
                    /*UInt32 peHeaderSignature =*/
                    binaryReader.ReadUInt32();

                    // We can also show all these value, but we will be limiting to
                    // the CLI header test.
                    //
                    // (Ecma-335 - Partition II; section 25.2.2 "PE file header")
                    /*UInt16 machine =*/
                    binaryReader.ReadUInt16();
                    /*Uint16 numberOfSections =*/
                    binaryReader.ReadUInt16();
                    /*UInt32 timeDateStamp =*/
                    binaryReader.ReadUInt32();
                    /*UInt32 pointerToSymbolTable =*/
                    binaryReader.ReadUInt32();
                    /*UInt32 numberOfSymbols =*/
                    binaryReader.ReadUInt32();
                    /*UInt16 optionalHeaderSize =*/
                    binaryReader.ReadUInt16();
                    /*UInt16 characteristics =*/
                    binaryReader.ReadUInt16();

                    // Now we are at the end of the PE Header and from here, the PE
                    // optional header starts.
                    //
                    // (Ecma-335 - Partition II; section 25.2.3 "PE optional header")
                    //
                    // To go directly to the data directories in the PE optional
                    // header, we'll increase the stream’s current position by 96
                    // (0x60):  28 for standard fields and 68 for NT-specific
                    // fields.
                    //
                    // From here the data directories starts...and it is a total of 128
                    // bytes.  The directories are field/size pairs for special tables
                    // found in the image file (e.g., the Import Table and Export Table).
                    //
                    // The data directories has 16 directories in total.  Each data
                    // directory is 8 bytes:  4 bytes is of RVA and 4 bytes of size.
                    //
                    // NOTE:  the 15th directory consist of CLR header!  If it is 0,
                    // then it is not a CLR file.
                    dataDirectoriesStart = Convert.ToUInt16(Convert.ToUInt16(fileStream.Position) + 0x60);
                    fileStream.Position = dataDirectoriesStart;

                    for (Int32 i = 0; i < 15; i++)
                    {
                        dataDirectoryRVA[i] = binaryReader.ReadUInt32();
                        dataDirectorySize[i] = binaryReader.ReadUInt32();
                    }

                    if (dataDirectoryRVA[14] == 0)
                    {
                        // This is NOT a valid CLR File.
                        result = false;
                    }
                    else
                    {
                        // This is a valid CLR File.
                        result = true;
                    }
                }
            }
            catch (Exception)
            {
                // if we encountered a problem, then it probably isn't an assembly file
            }

            return result;
        }

        private Boolean IsStrongNamedAssemblyFile(String path)
        {
            Boolean result = IsAssemblyFile(path);

            if (result)
            {
                result = false;

                using (FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    StrongNameSignature signature = new StrongNameSignature(fileStream);
                    fileStream.Seek(signature.StrongNameDataDirectory, SeekOrigin.Begin);
                    byte[] buffer = new byte[8];
                    fileStream.Read(buffer, 0, buffer.Length);
                    UInt64 byteSum = 0;
                    foreach (Byte b in buffer)
                    {
                        byteSum += Convert.ToUInt64(b);
                    }
                    result = (byteSum != 0);
                }
            }

            return result;
        }

        private String GetAssemblyVersion(String filePath)
        {
            Assembly assembly = Assembly.ReflectionOnlyLoadFrom(filePath);
            return assembly.GetName().Version.ToString();
        }

        private ConfigInfo _rootConfigInfo = null;

        private Boolean FileExists(String fileName)
        { return File.Exists(fileName); }

        private Boolean DirectoryExists(String directory)
        { return Directory.Exists(directory); }

        private String FileNameForPath(String path)
        { return Path.GetFileName(path); }

        private String FileNameWithoutExtensionForPath(String path)
        { return Path.GetFileNameWithoutExtension(path); }

        private String FileExtensionForPath(String path)
        { return Path.GetExtension(path); }

        private String DirectoryNameForPath(String path)
        { return Path.GetDirectoryName(path); }

        private String FullPath(String path)
        { return Path.GetFullPath(path); }

        private String CanonicalizeWXSId(String input)
        {
            String result = input;

            Boolean somethingReplaced;
            do
            {
                somethingReplaced = false;
                String newValue = Regex.Replace(result, @"([A-Za-z_]+[A-Za-z_0-9\.]*)[^A-Za-z_0-9\.]([A-Za-z_0-9\.]*)", "$1$2");
                if (result != newValue)
                {
                    somethingReplaced = true;
                    result = newValue;
                }
            } while (somethingReplaced);

            return result;
        }

        private Boolean StringStartsWith(String referenceString, String inputToMatch)
        { return referenceString.StartsWith(inputToMatch); }

        private Boolean StringsAreEqual(String str1, String str2, String ignoreCase)
        { return (String.Compare(str1, str2, Boolean.Parse(ignoreCase)) == 0); }

        private String StringReplace(String stringToReplace, String oldValue, String newValue)
        { return stringToReplace.Replace(oldValue, newValue); }

        private String XmlEscape(String value)
        { return Utils.XmlEscape(value); }
    }
}
