﻿using System;
using System.Globalization;

namespace SymbolTool.Internal
{
    #region Enums

    /// <summary>
    /// Defines the available symbol store transaction actions.
    /// </summary>
    public enum TransactionAction
    {
        /// <summary>
        /// No action taken.
        /// </summary>
        None,

        /// <summary>
        /// The symbol file was added to the store.
        /// </summary>
        Add,

        /// <summary>
        /// The symbol file was deleted from the store.
        /// </summary>
        Delete
    }

    /// <summary>
    /// Defines the available transaction add types.
    /// </summary>
    public enum TransactionAddType
    {
        /// <summary>
        /// No action taken.
        /// </summary>
        None,

        /// <summary>
        /// A symbol file was added.
        /// </summary>
        File,

        /// <summary>
        /// A symbol file pointer was added.
        /// </summary>
        Pointer
    }

    #endregion Enums

    /// <summary>
    /// Defines a single symbol log transaction.
    /// </summary>
    /// <remarks>
    /// Refer to http://msdn.microsoft.com/en-us/library/windows/desktop/ms681417(v=vs.85).aspx for details.
    /// </remarks>
    public class SymbolTransaction
    {
        #region Fields

        private string _fullPathSymbolServer;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="SymbolTransaction"/> class.
        /// </summary>
        /// <param name="fullPathSymbolServer">The full path to the symbol server.</param>
        /// <param name="line">A single line from the transaction history log.</param>
        /// <exception cref="ArgumentNullException">The exception thrown if either argument is null or empty.</exception>
        public SymbolTransaction(string fullPathSymbolServer, string line)
        {
            if (string.IsNullOrEmpty(fullPathSymbolServer))
            {
                throw new ArgumentNullException("fullPathSymbolServer");
            }

            if (string.IsNullOrEmpty(line))
            {
                throw new ArgumentNullException("line");
            }

            this._fullPathSymbolServer = fullPathSymbolServer;
            this.HasBeenDeleted = false;

            // Strip out all quotes.
            line = line.Replace("\"", "");
            string[] linesArr = line.Split(new char[] { ',' }, StringSplitOptions.None);

            // This is a typical line in the log for a file that has been added.
            // 0000000001,add,file,11/08/2011,10:52:35,"Sage Estimating","11.2.0.2","",
            //
            // This is a typical line in the log for a file that has been deleted.
            // 0000000005,del,0000000001
            if (linesArr != null)
            {
                if (linesArr.Length > 0)
                {
                    this.TransactionId = linesArr[0];
                }

                if (linesArr.Length > 1)
                {
                    this.TransactionType = linesArr[1];
                }

                if (this.Action == TransactionAction.Delete)
                {
                    if (linesArr.Length > 2)
                    {
                        this.DeletedTransactionId = linesArr[2];
                    }

                    this.FilesOrPointers = string.Empty;
                    this.Date = string.Empty;
                    this.Time = string.Empty;
                    this.ProductName = string.Empty;
                    this.Version = string.Empty;
                    this.Comment = string.Empty;
                    this.Unused = string.Empty;
                }
                else
                {
                    this.DeletedTransactionId = string.Empty;

                    if (linesArr.Length > 2)
                    {
                        this.FilesOrPointers = linesArr[2];
                    }

                    if (linesArr.Length > 3)
                    {
                        this.Date = linesArr[3];
                    }

                    if (linesArr.Length > 4)
                    {
                        this.Time = linesArr[4];
                    }

                    if (linesArr.Length > 5)
                    {
                        this.ProductName = linesArr[5];
                    }

                    if (linesArr.Length > 6)
                    {
                        this.Version = linesArr[6];
                    }

                    if (linesArr.Length > 7)
                    {
                        this.Comment = linesArr[7];
                    }

                    if (linesArr.Length > 8)
                    {
                        this.Unused = linesArr[8];
                    }
                }
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the transaction Id.
        /// </summary>
        public string TransactionId
        { get; private set; }

        /// <summary>
        /// Gets the deleted transaction Id. This is only applicable if the Action is set to Delete.
        /// </summary>
        public string DeletedTransactionId
        { get; private set; }

        /// <summary>
        /// Gets whether this symbol was deleted by a separate transaction.
        /// </summary>
        public bool HasBeenDeleted
        { get; internal set; }

        /// <summary>
        /// Gets the transaction type ('add' or 'del')
        /// </summary>
        private string TransactionType
        { get; set; }

        /// <summary>
        /// Gets the transaction action.
        /// </summary>
        public TransactionAction Action
        {
            get
            {
                if (string.Compare(this.TransactionType, "add", true, CultureInfo.InvariantCulture) == 0)
                {
                    return TransactionAction.Add;
                }
                else if (string.Compare(this.TransactionType, "del", true, CultureInfo.InvariantCulture) == 0)
                {
                    return TransactionAction.Delete;
                }
                else
                {
                    return TransactionAction.None;
                }
            }
        }

        /// <summary>
        /// Gets whether files or pointers were added ('file' or 'ptr').
        /// </summary>
        private string FilesOrPointers
        { get; set; }

        /// <summary>
        /// Gets the transaction add type.
        /// </summary>
        public TransactionAddType AddType
        {
            get
            {
                if (string.Compare(this.FilesOrPointers, "file", true, CultureInfo.InvariantCulture) == 0)
                {
                    return TransactionAddType.File;
                }
                else if (string.Compare(this.FilesOrPointers, "ptr", true, CultureInfo.InvariantCulture) == 0)
                {
                    return TransactionAddType.Pointer;
                }
                else
                {
                    return TransactionAddType.None;
                }
            }
        }

        /// <summary>
        /// Gets the transaction date.
        /// </summary>
        public string Date
        { get; private set; }

        /// <summary>
        /// Gets the transaction time.
        /// </summary>
        public string Time
        { get; private set; }

        /// <summary>
        /// Gets the product name.
        /// </summary>
        public string ProductName
        { get; private set; }

        /// <summary>
        /// Gets the version (optional).
        /// </summary>
        public string Version
        { get; private set; }

        /// <summary>
        /// Get the comment (optional).
        /// </summary>
        public string Comment
        { get; private set; }

        /// <summary>
        /// Reserved for later use.
        /// </summary>
        public string Unused
        { get; private set; }

        /// <summary>
        /// Gets the complete transaction date.
        /// </summary>
        public DateTime TransactionDate
        {
            get
            {
                // The string will look like this: 11/08/2011 10:52:35
                string value = this.Date + " " + this.Time;

                try
                {
                    DateTime dt = DateTime.ParseExact(value, "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                    return dt;
                }
                catch (FormatException e)
                {
                    System.Diagnostics.Debug.Assert(false);
                    System.Diagnostics.Debug.WriteLine("*** Error formatting the date/time structure. Going to use today's date to ensure that it doesn't get deleted.\n\nMessage: " + e.Message);
                    return DateTime.Now;
                }
            }
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete this symbol and update the transaction info.
        /// </summary>
        /// <exception cref="SymbolToolException">The exception thrown if a delete failure occurs.</exception>
        public void Delete()
        {
            SymbolStoreCommand store = new SymbolStoreCommand();
            store.Command = SymStoreCommands.Delete;
            store.TransactionId = this.TransactionId;
            store.Store = this._fullPathSymbolServer;
            store.Verbose = true;
            store.Execute();
            
            this.HasBeenDeleted = true;
        }

        #endregion
    }
}
