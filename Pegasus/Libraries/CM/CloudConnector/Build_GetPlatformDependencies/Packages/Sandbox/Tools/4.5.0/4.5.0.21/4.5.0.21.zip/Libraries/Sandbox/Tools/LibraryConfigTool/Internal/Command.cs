using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryConfigTool.Internal
{
    [Flags]
    enum Command
    {
        None,
        PrintHelp   = 0x01,
        Query       = 0x02,
        Action      = 0x04
    }
}
