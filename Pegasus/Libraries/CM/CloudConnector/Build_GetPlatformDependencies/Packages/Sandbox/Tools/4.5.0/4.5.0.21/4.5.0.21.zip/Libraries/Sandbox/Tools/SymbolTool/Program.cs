﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Windows.Forms;
using SymbolTool.Internal;

namespace SymbolTool
{
    class Program
    {
        #region Fields

        /// <summary>
        /// Defines the CRE TFS Server.
        /// </summary>
        private static readonly string GlobalTeamFoundationServerUrl = "http://orbdevtfs2:8080/tfs/sagecre";

        /// <summary>
        /// Defines the current command.
        /// </summary>
        private static Command _command;

        /// <summary>
        /// Defines the global output manager.
        /// </summary>
        private static OutputManager _outputManager = new OutputManager();

        #endregion

        [STAThread]
        static void Main(string[] args)
        {
            // MessageBox.Show("SymbolTool.exe Starting...");

            try
            {
                Environment.ExitCode = 1;
                DateTime startTime = DateTime.Now;

                try
                {
                    Dictionary<String, String> variables = new Dictionary<String, String>();

                    foreach (String arg in args)
                    {
                        if (string.Compare(arg, "/help", true, CultureInfo.InvariantCulture) == 0 || string.Compare(arg, "/?", true, CultureInfo.InvariantCulture) == 0)
                        {
                            _command |= Command.PrintHelp;
                        }
                        else if (arg.StartsWith("/command:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/c:", StringComparison.InvariantCultureIgnoreCase))
                        {
                            string commandName = arg.Substring(arg.IndexOf(':') + 1);
                            _outputManager.OutputType = OutputType.Status;

                            if (string.Equals(commandName, Command.CleanSymbols.ToString(), StringComparison.InvariantCultureIgnoreCase))
                            {
                                _command |= Command.CleanSymbols;
                            }
                            else if (string.Equals(commandName, Command.IndexSources.ToString(), StringComparison.InvariantCultureIgnoreCase))
                            {
                                _command |= Command.IndexSources;
                            }
                            else if (string.Equals(commandName, Command.PublishSymbols.ToString(), StringComparison.InvariantCultureIgnoreCase))
                            {
                                _command |= Command.PublishSymbols;
                            }
                        }
                        else if (string.Compare(arg, "/nologo", true, CultureInfo.InvariantCulture) == 0)
                        {
                            _outputManager.OutputType = _outputManager.OutputType & ~OutputType.Banner;
                        }
                        else if (string.Compare(arg, "/silent", true, CultureInfo.InvariantCulture) == 0)
                        {
                            _outputManager.OutputType = _outputManager.OutputType & ~(OutputType.Banner | OutputType.Info | OutputType.Verbose);
                        }
                        else if (string.Compare(arg, "/verbose", true, CultureInfo.InvariantCulture) == 0)
                        {
                            _outputManager.OutputType = _outputManager.OutputType | (OutputType.Info | OutputType.Verbose);
                        }
                        else if (arg.StartsWith("/p:", StringComparison.InvariantCultureIgnoreCase))
                        {
                            string variableSpec = arg.Substring(arg.IndexOf(":") + 1);
                            string[] splitVariableSpec = variableSpec.Split('=');

                            if (splitVariableSpec == null || splitVariableSpec.GetLength(0) != 2)
                            {
                                throw new SymbolToolException("The property syntax must be of the form /p:{name}={value}");
                            }

                            variables.Add(splitVariableSpec[0], splitVariableSpec[1]);
                        }
                    }

                    // For simplification, let's not require all callers to specify the TFS URL.
                    if (!variables.ContainsKey(Strings.TeamFoundationServerUrlProperty))
                    {
                        variables.Add(Strings.TeamFoundationServerUrlProperty, GlobalTeamFoundationServerUrl);
                    }

                    if (PrintHelp)
                    {
                        _outputManager.OutputType = _outputManager.OutputType | OutputType.Help;
                        DoPrintHelp();
                        Environment.ExitCode = 1;
                    }
                    else
                    {
                        PrintBanner();
                        Program.Output.Write(OutputType.Verbose, string.Format(CultureInfo.CurrentCulture, "CurrentDirectory is '{0}'.", Environment.CurrentDirectory));

                        switch (_command)
                        {
                            case Command.CleanSymbols:
                                {
                                    int numDays = 30;
                                    ThrowNameValuePairNotDefined(variables, Strings.SymbolServerProperty);

                                    // The retention policy is optional.
                                    if (variables.ContainsKey(Strings.RetentionDaysProperty))
                                    {
                                        string numDaysString = variables[Strings.RetentionDaysProperty];

                                        try
                                        {
                                            numDays = Convert.ToInt32(numDaysString);
                                        }
                                        catch (FormatException e)
                                        {
                                            string message = "Failed to convert the " + Strings.RetentionDaysProperty + " value '" + numDaysString + "' to an integer.";
                                            throw new SymbolToolException(message, e);
                                        }
                                    }

                                    string symbolServer = variables[Strings.SymbolServerProperty];
                                    CleanSymbolsCommand command = new CleanSymbolsCommand();
                                    command.Store = symbolServer;
                                    command.Days = numDays;
                                    command.Execute();
                                }
                                break;

                            case Command.IndexSources:
                                {
                                    ThrowNameValuePairNotDefined(variables, Strings.TeamFoundationServerUrlProperty);
                                    ThrowNameValuePairNotDefined(variables, Strings.StartingDirProperty);
                                    ThrowNameValuePairNotDefined(variables, Strings.TargetDirProperty);

                                    IndexSourcesCommand command = new IndexSourcesCommand();
                                    command.TeamFoundationServerUrl = variables[Strings.TeamFoundationServerUrlProperty];
                                    command.SourceFilesDir = variables[Strings.StartingDirProperty];
                                    command.TargetDir = variables[Strings.TargetDirProperty];
                                    command.Execute();
                                }
                                break;

                            case Command.PublishSymbols:
                                {
                                    ThrowNameValuePairNotDefined(variables, Strings.SymbolServerProperty);
                                    ThrowNameValuePairNotDefined(variables, Strings.StartingDirProperty);
                                    ThrowNameValuePairNotDefined(variables, Strings.ProductProperty);
                                    ThrowNameValuePairNotDefined(variables, Strings.VersionProperty);

                                    SymbolStoreCommand command = new SymbolStoreCommand();
                                    command.Command = SymStoreCommands.Add;
                                    command.Recursive = true;
                                    command.Files = System.IO.Path.Combine(variables[Strings.StartingDirProperty], "*.pdb");
                                    command.Store = variables[Strings.SymbolServerProperty];
                                    command.Product = variables[Strings.ProductProperty];
                                    command.Version = variables[Strings.VersionProperty];
                                    command.Pointer = false;
                                    command.Local = false;
                                    command.Execute();
                                }
                                break;

                            default:
                                {
                                    DoPrintHelp();
                                }
                                break;
                        }

                        Environment.ExitCode = 0;
                    }
                }
                catch (Exception ex)
                {
                    using (BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, ex.ToString());
                        output.EndWriteError();
                    }
                }

                if (_outputManager.ErrorCount > 0)
                {
                    if (!PrintHelp)
                    {
                        Output.Write(OutputType.Status, string.Format(CultureInfo.CurrentCulture, "SymbolTool '{0}' action FAILED;  elapsed time {1}", _command, DateTime.Now - startTime));
                    }
                    Environment.ExitCode = 1;
                }
                else
                {
                    if (!PrintHelp)
                    {
                        Output.Write(OutputType.Status, string.Format(CultureInfo.CurrentCulture, "SymbolTool '{0}' action successfully completed;  elapsed time {1}", _command, DateTime.Now - startTime));
                    }
                }
            }
            catch (Exception ex)
            {
                WriteErrorLogException(ex);
                Environment.ExitCode = 1;
            }
        }

        public static Command CurrentCommand
        { get { return _command; } }

        public static Boolean PrintHelp
        { get { return (_command & Command.PrintHelp) != Command.None; } }

        private static void PrintBanner()
        {
            Program.Output.Write(OutputType.Banner, "Sage Symbol Tool.  Version " + Assembly.GetExecutingAssembly().GetName().Version);
            Program.Output.Write(OutputType.Banner, "");
        }

        private static void DoPrintHelp()
        {
            PrintBanner();

            using (BatchedOutput output = new BatchedOutput(false))
            {
                output.Write(OutputType.Help, "Syntax: SymbolTool <Command> [Options]");
                output.Write(OutputType.Help, "Commands:");
                output.Write(OutputType.Help, "  /command:<CleanSymbols|IndexSources|PublishSymbols>, /c:<CleanSymbols|IndexSources|PublishSymbols>");
                output.Write(OutputType.Help, "    Indexes all sources.");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "Options:");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /p:<name>=<value>");
                output.Write(OutputType.Help, "    Defines a property with the specified name and value.");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /nologo");
                output.Write(OutputType.Help, "    Suppress display of the logo banner");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /silent");
                output.Write(OutputType.Help, "    Silent mode. Prevents displaying of success messages");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /verbose");
                output.Write(OutputType.Help, "    Displays extra information");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /?, /help");
                output.Write(OutputType.Help, "  Displays this usage message");
            }
        }

        private static void ThrowNameValuePairNotDefined(Dictionary<String, String> variables, string propertyName)
        {
            if (!variables.ContainsKey(propertyName))
            {
                throw new SymbolToolException("The index sources command requires the '" + propertyName + "' name/value property pair.");
            }
        }

        private static void WriteErrorLogException(Exception ex)
        {
            if (ex != null)
            {
                WriteErrorLogMessage(ex.ToString());
            }
            else
            {
                WriteErrorLogMessage("Null exception object encountered.");
            }
        }

        private static void WriteErrorLogMessage(String message)
        {
            using (EventLog applicationEventLog = new EventLog("Application", ".", "Application Error"))
            {
                applicationEventLog.WriteEntry(string.Format(CultureInfo.CurrentCulture, "SymbolTool encountered a problem:\n\nMessage: {0}", message), EventLogEntryType.Error);
            }
        }

        /// <summary>
        /// Gets the output manager.
        /// </summary>
        internal static OutputManager Output
        { get { return _outputManager; } }
    }
}
