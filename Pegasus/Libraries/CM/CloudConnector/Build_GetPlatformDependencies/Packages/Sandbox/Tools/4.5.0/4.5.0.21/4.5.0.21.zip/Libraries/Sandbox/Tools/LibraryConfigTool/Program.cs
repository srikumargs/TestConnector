using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using LibraryConfigTool.Internal;

namespace LibraryConfigTool
{
    class Program
    {
        [STAThread]
        static void Main(String[] args)
        {
            try
            {
                Environment.ExitCode = 1;

                DateTime startTime = DateTime.Now;

                String actionId = null;
                String query = null;

                try
                {
                    List<KeyValuePair<String, String>> variables = new List<KeyValuePair<String, String>>();
                    foreach (String arg in args)
                    {
                        if (String.Compare(arg, "/help", true, CultureInfo.InvariantCulture) == 0 || String.Compare(arg, "/?", true, CultureInfo.InvariantCulture) == 0)
                        {
                            _command |= Command.PrintHelp;
                        }
                        else if (arg.StartsWith("/libraryConfig:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/lc:", StringComparison.InvariantCultureIgnoreCase))
                        {
                            _configFile = Path.GetFullPath(arg.Substring(arg.IndexOf(':') + 1));
                        }
                        else if (arg.StartsWith("/action:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/a:", StringComparison.InvariantCultureIgnoreCase))
                        {
                            _command |= Command.Action;
                            actionId = arg.Substring(arg.IndexOf(':') + 1);
                        }
                        else if (arg.StartsWith("/query:", StringComparison.InvariantCultureIgnoreCase) || arg.StartsWith("/q:", StringComparison.InvariantCultureIgnoreCase))
                        {
                            _command |= Command.Query;
                            _outputManager.OutputType = OutputType.Status;
                            query = arg.Substring(arg.IndexOf(':') + 1);
                        }
                        else if (String.Compare(arg, "/nologo", true, CultureInfo.InvariantCulture) == 0)
                        {
                            _outputManager.OutputType = _outputManager.OutputType & ~OutputType.Banner;
                        }
                        else if (String.Compare(arg, "/silent", true, CultureInfo.InvariantCulture) == 0)
                        {
                            _outputManager.OutputType = _outputManager.OutputType & ~(OutputType.Banner | OutputType.Info | OutputType.Verbose);
                        }
                        else if (String.Compare(arg, "/verbose", true, CultureInfo.InvariantCulture) == 0)
                        {
                            _outputManager.OutputType = _outputManager.OutputType | (OutputType.Info | OutputType.Verbose);
                        }
                        else if (arg.StartsWith("/sandbox:", StringComparison.InvariantCultureIgnoreCase))
                        {
                            Utils.SandboxLocation = arg.Substring(arg.IndexOf(':') + 1);
                        }
                        else if (arg.StartsWith("/currentdir:", StringComparison.InvariantCultureIgnoreCase))
                        {
                            System.Environment.CurrentDirectory = arg.Substring(arg.IndexOf(':') + 1);
                        }
                        else if (arg.StartsWith("/d:", StringComparison.InvariantCultureIgnoreCase))
                        {
                            String variableSpec = arg.Substring(arg.IndexOf(":") + 1);
                            String[] splitVariableSpec = variableSpec.Split('=');
                            if (splitVariableSpec == null || splitVariableSpec.GetLength(0) != 2)
                            {
                                // todo:
                            }

                            ConfigInfo.ValidateVariableName(splitVariableSpec[0]);

                            variables.Add(new KeyValuePair<String, String>(Utils.GetVariableNameKeyForVariableName(splitVariableSpec[0]), splitVariableSpec[1]));
                        }
                    }

                    // create variables for System environment

                    // Strange behavior differences on each platform make this workaround necessary.
                    // - On XP, Environment.GetEnvironmentVariables() will not contain the USERNAME variable.
                    // - On Vista, Environment.GetEnvironmentVariables() will contain the USERNAME variable, however, its
                    //   corresponding Value entry (from the DictionaryEntry is always "SYSTEM".
                    //
                    // Fix both of these issues by:
                    //   a) manually adding USERNAME into the list of variable names, and
                    //   b) always calling Environment.GetEnvironmentVariable() for each variable rather than getting the
                    //      values out of the dictionary returned by Environment.GetEnvironmentVariables()
                    ArrayList machineEnvironmentVariableNames = new ArrayList(Environment.GetEnvironmentVariables(EnvironmentVariableTarget.Process).Keys);
                    machineEnvironmentVariableNames.Sort(new CaseInsensitiveComparer(CultureInfo.InvariantCulture));
                    if (machineEnvironmentVariableNames.BinarySearch("USERNAME", new CaseInsensitiveComparer(CultureInfo.InvariantCulture)) < 0)
                    {
                        machineEnvironmentVariableNames.Add("USERNAME");
                    }
                    if (machineEnvironmentVariableNames.BinarySearch("COMPUTERNAME", new CaseInsensitiveComparer(CultureInfo.InvariantCulture)) < 0)
                    {
                        machineEnvironmentVariableNames.Add("COMPUTERNAME");
                    }
                    foreach (String machineEnvironmentVariableName in machineEnvironmentVariableNames)
                    {
                        variables.Add(new KeyValuePair<String, String>(Utils.GetVariableNameKeyForVariableName("Environment::Variable::" + machineEnvironmentVariableName.ToUpper(CultureInfo.InvariantCulture).Replace('(', '_').Replace(')', '_')), Environment.GetEnvironmentVariable(machineEnvironmentVariableName, EnvironmentVariableTarget.Process)));

                        // The STE PR build is using a new LibraryConfigTool.exe to build an older LibraryConfig schema.  
                        // Surface the legacy variable names for USERNAME and WINDIR so that backward compatibility is 
                        // maintained until such time as STE PR moves to current LibraryConfigTool.exe.
                        if (String.Compare(machineEnvironmentVariableName, "USERNAME", true) == 0 ||
                            String.Compare(machineEnvironmentVariableName, "WINDIR", true) == 0)
                        {
                            variables.Add(new KeyValuePair<String, String>(Utils.GetVariableNameKeyForVariableName("Environment::System::" + machineEnvironmentVariableName.ToUpper(CultureInfo.InvariantCulture)), Environment.GetEnvironmentVariable(machineEnvironmentVariableName)));
                        }               
                    }

                    if (((_command & Command.Query) != Command.Query) && MainForm.OverrideVerbosity)
                    {
                        switch (MainForm.VerbosityOverrideSetting)
                        {
                            case VerbosityOverrideSetting.Silent:
                                _outputManager.OutputType = _outputManager.OutputType & ~(OutputType.Banner | OutputType.Info | OutputType.Verbose);
                                break;

                            case VerbosityOverrideSetting.Normal:
                                _outputManager.OutputType = OutputType.Banner | OutputType.Error | OutputType.Info | OutputType.Status;
                                break;

                            case VerbosityOverrideSetting.Verbose:
                                _outputManager.OutputType = _outputManager.OutputType | (OutputType.Info | OutputType.Verbose);
                                break;
                        }
                    }

                    if (PrintHelp)
                    {
                        _outputManager.OutputType = _outputManager.OutputType | OutputType.Help;
                        DoPrintHelp();
                        Environment.ExitCode = 1;
                    }
                    else if (_command == Command.None)
                    {
                        Application.EnableVisualStyles();
                        Application.SetCompatibleTextRenderingDefault(false);
                        Application.Run(new MainForm());
                        Environment.ExitCode = 1;
                        return;
                    }
                    else
                    {
                        PrintBanner();

                        Program.Output.Write(OutputType.Verbose, String.Format(CultureInfo.CurrentCulture, "CurrentDirectory is '{0}'.", Environment.CurrentDirectory));

                        String configFilePath = _configFile;
                        if (String.IsNullOrEmpty(_configFile))
                        {
                            configFilePath = FindLibraryConfig();
                        }

                        variables.Add(new KeyValuePair<String, String>(Utils.GetVariableNameKeyForVariableName("System::RootConfigFilePath"), Path.GetFullPath(configFilePath)));
                        variables.Add(new KeyValuePair<String, String>(Utils.GetVariableNameKeyForVariableName("System::LibraryConfigToolPath"), Assembly.GetEntryAssembly().Location));

                        ConfigInfo configInfo = new ConfigInfo(configFilePath, variables.AsReadOnly());

                        if (Action)
                        {
                            _currentCommand = Command.Action;
                            configInfo.DoAction(actionId);
                            _currentCommand = Command.None;
                        }

                        if (Query)
                        {
                            _currentCommand = Command.Query;
                            Console.Write(configInfo.DoQuery(query));
                            _currentCommand = Command.None;
                        }

                        Environment.ExitCode = 0;
                    }
                }
                catch (Exception ex)
                {
                    using (BatchedOutput output = new BatchedOutput(false))
                    {
                        output.BeginWriteError(0, ex.ToString());
                        output.EndWriteError();
                    }
                }

                if (!Query)
                {
                    if (_outputManager.ErrorCount > 0)
                    {
                        if (!PrintHelp)
                        {
                            Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "LibraryConfigTool '{0}' action FAILED;  elapsed time {1}", _command, DateTime.Now - startTime));
                        }
                        Environment.ExitCode = 1;
                    }
                    else
                    {
                        if (!PrintHelp)
                        {
                            Output.Write(OutputType.Status, String.Format(CultureInfo.CurrentCulture, "LibraryConfigTool '{0}' action successfully completed;  elapsed time {1}", _command, DateTime.Now - startTime));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WriteErrorLogException(ex);
                Environment.ExitCode = 1;
            }
        }

        private static String FindLibraryConfig()
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(Environment.CurrentDirectory);

            String result = String.Empty;
            do
            {
                String candidatePath = Path.Combine(directoryInfo.FullName, Constants.LibraryConfigFileName);
                if (File.Exists(candidatePath))
                {
                    result = candidatePath;
                }
                else
                {
                    directoryInfo = directoryInfo.Parent;
                }
            }
            while (String.IsNullOrEmpty(result) && directoryInfo != null);

            if (String.IsNullOrEmpty(result))
            {
                String errorMessage = String.Format(CultureInfo.CurrentUICulture, Strings.UnableToFindLibraryConfigFormat, Constants.LibraryConfigFileName);
                throw new FileNotFoundException(errorMessage);
            }

            return result;
        }

        public static Command CurrentCommand
        { get { return _currentCommand; } }

        public static Boolean PrintHelp
        { get { return (_command & Command.PrintHelp) != Command.None; } }

        public static Boolean Query
        { get { return (_command & Command.Query) != Command.None; } }

        public static Boolean Action
        { get { return (_command & Command.Action) != Command.None; } }

        private static void PrintBanner()
        {
            Program.Output.Write(OutputType.Banner, "Sage Library Configuration Tool.  Version " + Assembly.GetExecutingAssembly().GetName().Version);
            Program.Output.Write(OutputType.Banner, "");
        }

        private static void DoPrintHelp()
        {
            PrintBanner();

            using (BatchedOutput output = new BatchedOutput(false))
            {
                output.Write(OutputType.Help, "Syntax: LibraryConfigTool <Command> [Options]");
                output.Write(OutputType.Help, "Commands:");
                output.Write(OutputType.Help, "  /query:<expression>, /q:<expression>");
                output.Write(OutputType.Help, "    Returns results of an expression query");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /action:<name>, /a:<name>");
                output.Write(OutputType.Help, "    Executes the specified named action");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "Options:");
                output.Write(OutputType.Help, "  /libraryConfig, lc:Path");
                output.Write(OutputType.Help, "    Specifies the path of a library configuration file to load");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /sandbox:<location>");
                output.Write(OutputType.Help, "    Defines the sandbox location to use; if not specified, defaults to the value of %SAGE_SANDBOX%");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /d:<name>=<value>");
                output.Write(OutputType.Help, "    Defines a global variable with the specified name and value");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /nologo");
                output.Write(OutputType.Help, "    Suppress display of the logo banner");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /silent");
                output.Write(OutputType.Help, "    Silent mode. Prevents displaying of success messages");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /verbose");
                output.Write(OutputType.Help, "    Displays extra information");
                output.Write(OutputType.Help, "");
                output.Write(OutputType.Help, "  /?, /help");
                output.Write(OutputType.Help, "  Displays this usage message");
            }
        }

        internal static OutputManager Output
        { get { return _outputManager; } }

        private static void WriteErrorLogMessage(String message)
        {
            using (EventLog applicationEventLog = new EventLog("Application", ".", "Application Error"))
            {
                applicationEventLog.WriteEntry(String.Format(CultureInfo.CurrentCulture, "LibraryConfigTool encountered a problem:\n\n{0}", message), EventLogEntryType.Error);
            }
        }

        private static void WriteErrorLogException(Exception ex)
        {
            if (ex != null)
            {
                WriteErrorLogMessage(ex.ToString());
            }
            else
            {
                WriteErrorLogMessage("Null exception object encountered.");
            }
        }

        private static String _configFile;  //= null; (automatically initialized by runtime)
        private static Command _command;    //= Command.None; (automatically initialized by runtime)
        private static Command _currentCommand;    //= Command.None; (automatically initialized by runtime)
        private static OutputManager _outputManager = new OutputManager();
    }
}
