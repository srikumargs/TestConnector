using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.EnterpriseServices.Internal;
using System.Reflection;
using System.Threading;

namespace DevBoxCleaner.Internal
{
    internal sealed class GacCleaner : Cleaner
    {
        protected override void DoExecute()
        {
            FireAppendResult(ResultCode.Info,  "Cleaning GAC...");

            // Figure out a "safe" name to use for a temp file;  then delete it and create a directory based on that name instead
            // This gyration is necessary because it seems there is no Path.GetTempSubdirectory API 
            String tempName = Path.GetTempFileName();
            File.Delete(tempName);
            Directory.CreateDirectory(tempName);
            String temp1033Dir = Path.Combine(tempName, "1033");
            Directory.CreateDirectory(temp1033Dir);

            StringCollection assembliesRemoved = new StringCollection();
            try
            {
                WriteResourceToTempDirectory("gacutil.exe", tempName);
                WriteResourceToTempDirectory("gacutil.exe.config", tempName);
                WriteResourceToTempDirectory("gacutlrc.dll", temp1033Dir);

                String gacutilPath = Path.Combine(tempName, @"gacutil.exe");

                Process gacutilProcess;
                using(gacutilProcess = new Process())
                {
                    gacutilProcess.StartInfo.FileName = gacutilPath;

                    gacutilProcess.StartInfo.Arguments = "/l";
                    gacutilProcess.StartInfo.CreateNoWindow = true;
                    gacutilProcess.StartInfo.UseShellExecute = false;
                    gacutilProcess.StartInfo.RedirectStandardInput = true;
                    gacutilProcess.StartInfo.RedirectStandardOutput = true;
                    gacutilProcess.StartInfo.RedirectStandardError = true;
                    gacutilProcess.Start();
                    String output = gacutilProcess.StandardOutput.ReadToEnd();
                    gacutilProcess.WaitForExit();
                    if(0 == gacutilProcess.ExitCode)
                    {
                        FireAppendResult(ResultCode.Success, "gacutil.exe " + gacutilProcess.StartInfo.Arguments, output);
                    }
                    else
                    {
                        FireAppendResult(ResultCode.Fail, "gacutil.exe " + gacutilProcess.StartInfo.Arguments, output);
                        return;
                    }

                    String[] splitOutput = output.Split('\n');
                    StringCollection assembliesToRemove = new StringCollection();
                    foreach(String s in splitOutput)
                    {
                        // TODO: extract this logic out into configuration
                        // 3e78b2cabf12f868 - public key token for ORB
                        // 7f465a1c156d4d57 - public key token for RedGate
                        // 0a4a2ad97614f98d - public key token for Sage Report Writer
                        // 1396755d4842d873 - public key token for Sage Cloud
                        // 8dabb1789e747c62 - public key token for SMB
                        if (s.Contains("PublicKeyToken=3e78b2cabf12f868") ||
                           s.Contains("PublicKeyToken=7f465a1c156d4d57") ||
                           s.Contains("PublicKeyToken=0a4a2ad97614f98d") ||
                           s.Contains("PublicKeyToken=1396755d4842d873") ||
                           s.Contains("PublicKeyToken=8dabb1789e747c62"))
                        {
                            String temp = s.TrimStart(' ');
                            temp = temp.TrimEnd('\r');
                            assembliesToRemove.Add(temp);
                        }
                    }

                    foreach(String s in assembliesToRemove)
                    {
                        gacutilProcess.StartInfo.Arguments = "/uf \"" + s + "\"";
                        if(!TestOnly)
                        {
                            gacutilProcess.Start();
                            output = gacutilProcess.StandardOutput.ReadToEnd();
                            gacutilProcess.WaitForExit();
                            if(0 == gacutilProcess.ExitCode)
                            {
                                assembliesRemoved.Add(s);
                                FireAppendResult(ResultCode.Success, "gacutil " + gacutilProcess.StartInfo.Arguments, output);
                            }
                            else
                            {
                                FireAppendResult(ResultCode.Fail, "gacutil " + gacutilProcess.StartInfo.Arguments, output);
                            }
                        }
                        else
                        {
                            assembliesRemoved.Add(s);
                            FireAppendResult(ResultCode.Success, "gacutil " + gacutilProcess.StartInfo.Arguments, output);
                        }
                    }
                }
            }
            finally
            {
                FireAppendResult(ResultCode.Info, "Removed " + assembliesRemoved.Count + " assemblies from the GAC.");

                // attempt to delete the temporary folder in a retry loop ... in case the OS hangs onto a file handle briefly after
                // the process ends
                Boolean folderDeleted = false;
                UInt16 retryCount = 0;
                const UInt16 maxNumberOfRetries = 10;
                do
                {
                    try
                    {
                        Directory.Delete(tempName, true);
                        folderDeleted = true;
                    }
                    catch (Exception)
                    {
                        Thread.Sleep(1000);
                        retryCount++;
                    }
                } while (!folderDeleted && retryCount < maxNumberOfRetries);
            }
        }

        private static void WriteResourceToTempDirectory(String resourceName, String tempDirectory)
        {
            String resourceFullName = String.Empty;
            foreach (String currentResourceName in Assembly.GetExecutingAssembly().GetManifestResourceNames())
            {
                if (currentResourceName.EndsWith(resourceName, StringComparison.InvariantCultureIgnoreCase))
                {
                    resourceFullName = currentResourceName;
                    break;
                }
            }

            if (!String.IsNullOrEmpty(resourceFullName))
            {
                using (Stream resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceFullName))
                using (BinaryReader binaryReader = new BinaryReader(resourceStream))
                {
                    Byte[] resourceBytes = new Byte[resourceStream.Length];
                    binaryReader.Read(resourceBytes, 0, Convert.ToInt32(resourceStream.Length));
                    binaryReader.Close();

                    String tempFileName = Path.Combine(tempDirectory, resourceName);
                    using (FileStream fileStream = new FileStream(tempFileName, FileMode.Create))
                    using (BinaryWriter binaryWriter = new BinaryWriter(fileStream))
                    {
                        binaryWriter.Write(resourceBytes);
                        binaryWriter.Flush();
                    }
                }
            }
        }
    }
}
