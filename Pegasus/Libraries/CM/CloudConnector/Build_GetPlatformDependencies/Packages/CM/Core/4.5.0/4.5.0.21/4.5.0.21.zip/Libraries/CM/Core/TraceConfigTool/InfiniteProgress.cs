using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;




namespace TraceConfigTool
{
    /// <summary>
    ///
    /// </summary>
    [System.ComponentModel.ToolboxItem(true)]
    internal sealed class InfiniteProgress : System.Windows.Forms.Control
    {
        #region Constructors
        /// <summary>
        /// 
        /// </summary>
        public InfiniteProgress()
        {
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            StartColor = Color.White;
            EndColor = Color.Blue;
            Position = 0;
            Step = 5;
        }
        #endregion



        #region Public properties
        /// <summary>
        /// 
        /// </summary>
        [Category("Style")]
        public Color StartColor
        {
            get
            {
                return _startColor;
            }
            set
            {
                _startColor = value;
            }
        }




        /// <summary>
        /// 
        /// </summary>
        [Category("Style")]
        public Color EndColor
        {
            get
            {
                return _endColor;
            }
            set
            {
                _endColor = value;
            }
        }




        /// <summary>
        /// 
        /// </summary>
        [Category("Behavior")]
        public float Position
        {
            get
            {
                return _position;
            }
            set
            {
                _position = value;
            }
        }




        /// <summary>
        /// 
        /// </summary>
        [Category("Behavior")]
        public float Step
        {
            get
            {
                return _step;
            }
            set
            {
                _step = value;
            }
        }
        #endregion



        #region Protected methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        protected override void OnPaint(PaintEventArgs args)
        {
            LinearGradientBrush brush = new LinearGradientBrush(this.Bounds, StartColor, EndColor, 0, false);
            try
            {
                brush.WrapMode = WrapMode.TileFlipX;
                brush.TranslateTransform(Position, 0, MatrixOrder.Append);
                args.Graphics.FillRectangle(brush, 0, 0, this.Width, this.Height);
            }
            finally
            {
                brush.Dispose();
            }

            base.OnPaint(args);
        }




        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        protected override void OnVisibleChanged(EventArgs args)
        {
            if(this.Visible)
            {
                if(null == _timer)
                {
                    _timer = new System.Windows.Forms.Timer();
                    _timer.Interval = 20;
                    _timer.Tick += new EventHandler(OnTick);
                }

                _timer.Start();
            }
            else
            {
                if(null != _timer)
                {
                    _timer.Stop();
                }
            }

            base.OnVisibleChanged(args);
        }
        #endregion



        #region Private fields
        private Timer _timer;
        private Color _startColor;
        private Color _endColor;
        private float _position;
        private float _step;
        #endregion



        #region Private methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        void OnTick(object sender, EventArgs args)
        {
            Position += Step;
            if(Position > this.Width)
            {
                Position = -this.Width;
            }

            this.Invalidate();
        }
        #endregion
    }
}