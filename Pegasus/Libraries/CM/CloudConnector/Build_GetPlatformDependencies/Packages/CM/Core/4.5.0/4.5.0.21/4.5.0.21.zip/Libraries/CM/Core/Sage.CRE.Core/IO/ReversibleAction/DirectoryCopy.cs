using System;
using System.Collections.Generic;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Copies one or more directories using the ReversibleAction pattern.
    /// The construction of a DirectoryCopy object copies the specified directory.
    /// If the object is disposed without calling the Commit() method, then the directory copy is reversed.
    /// 
    /// Typical usage:
    /// 
    /// using (DirectoryCopy dirCopy = new DirectoryCopy(@"C:\sourceDirectory",@"D:\destinationParentDirectory")) // results in a directory called "D:\destinationParentDirectory\sourceDirectory"
    ///     {
    ///         dirCopy.Forward();
    ///         
    ///         // do some code that might throw. If this code throws, we need to reverse the directory copy
    /// 
    ///         dirCopy.Commit();
    ///     }
    /// </summary>
    public class DirectoryCopy : ReversibleActionBase
    {
        /// <summary>
        /// Copies a single directory.
        /// The directory's security attributes are not copied.
        /// The directory's file attributes are not copied.
        /// The directory's auditing (Creation, LastAccess, and LastWrite) fields are not copied.
        /// </summary>
        /// <param name="sourceDirectory">The directory to be copied.</param>
        /// <param name="destinationParentDirectory">The parent directory that will contain the copied directory.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1805:DoNotInitializeUnnecessarily")]
        public DirectoryCopy(string sourceDirectory, string destinationParentDirectory)
        {
            _directoriesToBeCopied.Add(sourceDirectory, destinationParentDirectory);
            _overwriteFiles = false;
            _overwriteDirectories = false;
            _copyACL = false;
            _copyAttributes = false;
            _copyAuditFields = false;

        }
        
        /// <summary>
        /// Copies a set of directories.
        /// The directory's security attributes are not copied.
        /// The directory's file attributes are not copied.
        /// The directory's auditing (Creation, LastAccess, and LastWrite) fields are not copied.
        /// </summary>
        /// <param name="sourcesAndDestinations">A dictionary of source and destination directories.
        /// Note that each destination directory is the directory that will contain the copied directory.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1805:DoNotInitializeUnnecessarily")]
        public DirectoryCopy(Dictionary<string, string> sourcesAndDestinations)
        {
            _directoriesToBeCopied = sourcesAndDestinations;
            _overwriteFiles = false;
            _overwriteDirectories = false;
            _copyACL = false;
            _copyAttributes = false;
            _copyAuditFields = false;

        }

        /// <summary>
        /// Copy a single directory.
        /// </summary>
        /// <param name="source">The directory to be copied.</param>
        /// <param name="destination">The parent directory that will contain the copied directory.</param>
        /// <param name="overwriteFiles">Overwrite existing files in the destination.</param>
        /// <param name="overwriteDirectories">Overwrite existing directories in the destination.</param>
        /// <param name="copyACL">Copy the security attributes (Access Control Lists) from source directory and files and apply them to destination directories and files.</param>
        /// <param name="copyAttributes">Copy the attributes of the source directories and files.</param>
        /// <param name="copyAuditFields">Copy the audit (Creation, LastAccess, and LastWrite) fields.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "ACL")]
        public DirectoryCopy(string source, string destination, bool overwriteFiles, bool overwriteDirectories, bool copyACL, bool copyAttributes, bool copyAuditFields)
        {
            _directoriesToBeCopied.Add(source, destination);
            _overwriteFiles = overwriteFiles;
            _overwriteDirectories = overwriteDirectories;
            _copyACL = copyACL;
            _copyAttributes = copyAttributes;
            _copyAuditFields = copyAuditFields;

        }

        /// <summary>
        /// Copy a set of directories
        /// </summary>
        /// <param name="sourcesAndDestinations">A dictionary of source and destination directories.
        /// Note that each destination directory to the directory that will contain the copied directory.</param>
        /// <param name="overwriteFiles">Overwrite existing files in the destination.</param>
        /// <param name="overwriteDirectories">Overwrite existing directories in the destination.</param>
        /// <param name="copyACL">Copy the security attributes (Access Control Lists) from source directory and files and apply them to destination directories and files.</param>
        /// <param name="copyAttributes">Copy the attributes of the source directories and files.</param>
        /// <param name="copyAuditFields">Copy the audit (Creation, LastAccess, and LastWrite) fields.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "ACL")]
        public DirectoryCopy(Dictionary<string, string> sourcesAndDestinations, bool overwriteFiles, bool overwriteDirectories, bool copyACL, bool copyAttributes, bool copyAuditFields)
        {
            _directoriesToBeCopied = sourcesAndDestinations;
            _overwriteFiles = overwriteFiles;
            _overwriteDirectories = overwriteDirectories;
            _copyACL = copyACL;
            _copyAttributes = copyAttributes;
            _copyAuditFields = copyAuditFields;

        }




        #region Protected methods

        /// <summary>
        /// Copy the directories. Keep a list of everything copied.
        /// </summary>
        public override void Forward()
        {
            base.Forward();
            _directoriesCopied.Clear();
            foreach (KeyValuePair<string, string> kvp in _directoriesToBeCopied)
            {
                string src = kvp.Key;
                string dest = System.IO.Path.Combine(kvp.Value,System.IO.Path.GetFileName(src));


                DirectoryCopyRecursive(src, dest, _overwriteFiles, _overwriteDirectories, _copyACL, _copyAttributes, _copyAuditFields);
                _directoriesCopied.Add(src, dest);
            }
        }

        /// <summary>
        /// Delete any directories that have been copied.
        /// </summary>
        public override void Reverse()
        {
            base.Reverse();
            foreach (KeyValuePair<string, string> kvp in _directoriesCopied)
            {
                string dest = kvp.Value;
                if (System.IO.Directory.Exists(dest)) System.IO.Directory.Delete(dest, true);
            }
            _directoriesCopied.Clear();
        }

        #endregion

        #region Private methods
        /// <summary>
        /// Recursive directory and file copy.
        /// </summary>
        /// <param name="source">The source directory.</param>
        /// <param name="destination">The destination directory</param>
        /// <param name="fileOverwriteAllowed">Overwrite files?</param>
        /// <param name="directoryOverwriteAllowed">Overwrite directories?</param>
        /// <param name="copyACL">Copy security attributes (Access Control Lists)?</param>
        /// <param name="copyAttributes">Copy file and directory attributes?</param>
        /// <param name="copyAuditFields">Copy file and directory audit fields?</param>
        private static void DirectoryCopyRecursive(string source, string destination, bool fileOverwriteAllowed, bool directoryOverwriteAllowed, bool copyACL, bool copyAttributes, bool copyAuditFields)
        {
            System.IO.DirectoryInfo srcDirInfo = new System.IO.DirectoryInfo(source);
            System.IO.DirectoryInfo destDirInfo = null;
            if (!System.IO.Directory.Exists(destination))
            {
                destDirInfo = System.IO.Directory.CreateDirectory(destination);
            }
            else if (!directoryOverwriteAllowed)
            {
                throw new System.IO.IOException(String.Format(System.Globalization.CultureInfo.CurrentCulture,StringsCustomerFacing.ReversibleFileSystemAction_DirectoryAlreadyExists_EmbeddedMessage,destination));
            }
            else
            {
                destDirInfo = new System.IO.DirectoryInfo(destination);
            }

            if (copyACL)
            {
                destDirInfo.SetAccessControl(srcDirInfo.GetAccessControl());
            }

            if (copyAttributes)
            {
                destDirInfo.Attributes = srcDirInfo.Attributes;
            }

            if (copyAuditFields)
            {
                destDirInfo.CreationTimeUtc = srcDirInfo.CreationTimeUtc;
                destDirInfo.LastAccessTimeUtc = srcDirInfo.LastAccessTimeUtc;
                destDirInfo.LastWriteTimeUtc = srcDirInfo.LastWriteTimeUtc;
            }

            string[] srcFiles = System.IO.Directory.GetFiles(source);
            foreach (string file in srcFiles)
            {
                System.IO.FileInfo srcFileInfo = new System.IO.FileInfo(file);
                string destFileName = System.IO.Path.Combine(destination, System.IO.Path.GetFileName(srcFileInfo.FullName));
                System.IO.File.Copy(srcFileInfo.FullName, destFileName, fileOverwriteAllowed);
                System.IO.FileInfo destFileInfo = new System.IO.FileInfo(destFileName);

                if (copyACL)
                {
                    destFileInfo.SetAccessControl(srcFileInfo.GetAccessControl());
                }

                if (copyAttributes)
                {
                    destFileInfo.Attributes = srcFileInfo.Attributes;
                }

                if (copyAuditFields)
                {
                    destFileInfo.CreationTimeUtc = srcFileInfo.CreationTimeUtc;
                    destFileInfo.LastAccessTimeUtc = srcFileInfo.LastAccessTimeUtc;
                    destFileInfo.LastWriteTimeUtc = srcFileInfo.LastWriteTimeUtc;
                }
            }


            string[] srcDirectories = System.IO.Directory.GetDirectories(source);
            foreach (string srcDirectory in srcDirectories)
            {
                string destDirectory = System.IO.Path.Combine(destination, System.IO.Path.GetFileName(srcDirectory));
                DirectoryCopyRecursive(srcDirectory, destDirectory, fileOverwriteAllowed, directoryOverwriteAllowed,copyACL,copyAttributes,copyAuditFields);
            }
        }
        #endregion

        #region Private members
        private Dictionary<string, string> _directoriesToBeCopied = new Dictionary<string, string>();
        private Dictionary<string, string> _directoriesCopied = new Dictionary<string, string>();

        private bool _overwriteFiles;
        private bool _overwriteDirectories;
        private bool _copyACL;
        private bool _copyAttributes;
        private bool _copyAuditFields;
        #endregion


    }
}
