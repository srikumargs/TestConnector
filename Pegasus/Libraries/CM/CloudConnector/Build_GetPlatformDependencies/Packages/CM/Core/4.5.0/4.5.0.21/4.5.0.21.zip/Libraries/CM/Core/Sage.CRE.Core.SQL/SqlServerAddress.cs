﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sage.CRE.Core.SQL
{
    /// <summary>
    /// Encapsulates a SQL server address.
    /// Note that the protocol has been forced to TCP.
    /// </summary>
    [Serializable]
    public class SqlServerAddress : ICloneable
    {
        private System.String _host = String.Empty;
        private System.String _sqlInstanceName = String.Empty;
        private System.Int32 _port = 0;

        /// <summary>
        /// Gets or sets the host address of the SQL server.
        /// The host address must be DNS resolvable.
        /// </summary>
        public System.String Host
        {
            get { return _host; }
            set
            {
                _host = value;
                if ((_host == ".") || (_host == "(local)")) _host = "localhost";
                _host = System.Net.Dns.GetHostEntry(_host).HostName;
            }
        }

        /// <summary>
        /// Gets or sets the SQL server instance name.
        /// </summary>
        public System.String InstanceName
        {
            get { return _sqlInstanceName; }
            set { _sqlInstanceName = value; }
        }

        /// <summary>
        /// Gets or sets the SQL servers TCP port.
        /// </summary>
        public System.Int32 Port
        {
            get { return _port; }
            set
            {
                if ((value < 0) || (value > 65535))
                {
                    throw new System.ArgumentOutOfRangeException("Port", value, "Valid TCP and UDP ports are from 1 to 65535.");
                }
                _port = value;
            }            
        }

        /// <summary>
        /// Gets a properly formatted string for this SQL Server's data source.
        /// </summary>
        public System.String DataSource
        {
            get
            {
                if (_port == 0)
                {
                    if (String.IsNullOrEmpty(_sqlInstanceName))
                    {
                        return String.Format(@"tcp:{0}", _host);
                    }
                    else
                    {
                        return String.Format(@"tcp:{0}\{1}", _host, _sqlInstanceName);
                    }
                }
                else
                {

                    if (String.IsNullOrEmpty(_sqlInstanceName))
                    {
                        return String.Format(@"tcp:{0}, {1}", _host, _port);
                    }
                    else
                    {
                        return String.Format(@"tcp:{0}\{1}, {2}", _host, _sqlInstanceName, _port);
                    }
                }
            }

        }

        /// <summary>
        /// Creates a clone of the object.
        /// </summary>
        /// <returns></returns>
        public object Clone()
        {
            SqlServerAddress result = new SqlServerAddress();
            result._host = this._host;
            result._port = this._port;
            result._sqlInstanceName = this._sqlInstanceName;

            return result;
        }
    }
}
