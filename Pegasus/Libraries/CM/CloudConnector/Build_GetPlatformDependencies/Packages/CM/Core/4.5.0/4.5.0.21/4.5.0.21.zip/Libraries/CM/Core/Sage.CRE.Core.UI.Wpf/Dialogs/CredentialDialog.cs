using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Security.Permissions;
using System.Net;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.ComponentModel;
using System.Security;
using Sage.Credentials;
using Sage.Utilities;

namespace Sage.CRE.Core.UI.Wpf.Dialogs
{
    /// <summary>
    /// Represents a dialog box that allows the user to enter generic credentials.
    /// </summary>
    /// <remarks>
    /// <para>
    ///   This class is meant for generic credentials; it does not provide access to all the functionality
    ///   of the Windows CredUI API. Features such as Windows domain credentials or alternative security
    ///   providers (e.g. smartcards or biometric devices) are not supported.
    /// </para>
    /// <para>
    ///   The <see cref="CredentialDialog"/> class provides methods for storing and retrieving credentials,
    ///   and also manages automatic persistence of credentials by using the "Save password" checkbox on
    ///   the credentials dialog. 
    /// </para>
    /// <note>
    ///   This class requires Windows XP or later.
    /// </note>
    /// </remarks>
    /// <threadsafety instance="false" static="true" />
    [DefaultProperty("MainInstruction"), DefaultEvent("UserNameChanged"), Description("Allows access to credential UI for generic credentials.")]
    public partial class CredentialDialog : Component
    {
        private String _userName = String.Empty;
        private SecureString _password = new SecureString();
        private bool _isSaveChecked;

        private string _caption;
        private string _text;
        private string _windowTitle;

        /// <summary>
        /// Event raised when the <see cref="UserName"/> property changes.
        /// </summary>
        [Category("Property Changed"), Description("Event raised when the value of the UserName property changes.")]
        public event EventHandler UserNameChanged = delegate(Object sender, EventArgs args) { };

        /// <summary>
        /// Event raised when the <see cref="Password"/> property changes.
        /// </summary>
        [Category("Property Changed"), Description("Event raised when the value of the Password property changes.")]
        public event EventHandler PasswordChanged = delegate(Object sender, EventArgs args) { };

        /// <summary>
        /// Initializes a new instance of the <see cref="CredentialDialog"/> class.
        /// </summary>
        public CredentialDialog()
        { InitializeComponent(); }

        /// <summary>
        /// Initializes a new instance of the <see cref="CredentialDialog"/> class with the specified container.
        /// </summary>
        /// <param name="container">The <see cref="IContainer"/> to add the component to.</param>
        public CredentialDialog(IContainer container)
        {
            if (container != null)
                container.Add(this);

            InitializeComponent();
        }

        /// <summary>
        /// Gets or sets whether the "save password" checkbox is checked.
        /// </summary>
        /// <value>
        /// <see langword="true" /> if the "save password" is checked; otherwise, <see langword="false" />.
        /// The default value is <see langword="false" />.
        /// </value>
        /// <remarks>
        /// The value of this property is only valid if the dialog box is displayed with a save checkbox.
        /// Set this property before showing the dialog to determine the initial checked value of the save checkbox.
        /// </remarks>
        [Category("Appearance"), Description("Indicates whether the \"Save password\" checkbox is checked."), DefaultValue(false)]
        public bool IsSaveChecked
        {
            get { return _isSaveChecked; }
            set
            {
                _isSaveChecked = value;
            }
        }

        /// <summary>
        /// Gets the password the user entered in the dialog.
        /// </summary>
        /// <value>
        /// The password entered in the password field of the credentials dialog.
        /// </value>
        [Browsable(false)]
        public SecureString Password
        {
            get { return _password; }
            set
            {
                _password = value;
                OnPasswordChanged(EventArgs.Empty);
            }
        }

        /// <summary>
        /// Gets the user name the user entered in the dialog.
        /// </summary>
        /// <value>
        /// The user name entered in the user name field of the credentials dialog.
        /// The default value is an empty string ("").
        /// </value>
        [Browsable(false)]
        public String UserName
        {
            get { return _userName; }
            set
            {
                _userName = value;
                OnUserNameChanged(EventArgs.Empty);
            }
        }

        /// <summary>
        /// Gets or sets the title of the credentials dialog.
        /// </summary>
        /// <value>
        /// The title of the credentials dialog. The default value is an empty string ("").
        /// </value>
        /// <remarks>
        /// <para>
        ///   This property is not used on Windows Vista and newer versions of windows; the window title will always be "Windows Security"
        ///   in that case.
        /// </para>
        /// </remarks>
        [Localizable(true), Category("Appearance"), Description("The title of the credentials dialog."), DefaultValue("")]
        public string WindowTitle
        {
            get { return _windowTitle ?? string.Empty; }
            set { _windowTitle = value; }
        }

        /// <summary>
        /// Gets or sets a brief message to display in the dialog box.
        /// </summary>
        /// <value>
        /// A brief message that will be displayed in the dialog box. The default value is an empty string ("").
        /// </value>
        /// <remarks>
        /// <para>
        ///   On Windows Vista and newer versions of Windows, this text is displayed using a different style to set it apart
        ///   from the other text. In the default style, this text is a slightly larger and colored blue. The style is identical
        ///   to the main instruction of a task dialog.
        /// </para>
        /// <para>
        ///   On Windows XP, this text is not distinguished from other text. It's display mode depends on the <see cref="DownlevelTextMode"/>
        ///   property.
        /// </para>
        /// </remarks>
        [Localizable(true), Category("Appearance"), Description("A brief message that will be displayed in the dialog box."), DefaultValue("")]
        public string MainInstruction
        {
            get { return _caption ?? string.Empty; }
            set { _caption = value; }
        }

        /// <summary>
        /// Gets or sets additional text to display in the dialog.
        /// </summary>
        /// <value>
        /// Additional text to display in the dialog. The default value is an empty string ("").
        /// </value>
        /// <remarks>
        /// <para>
        ///   On Windows Vista and newer versions of Windows, this text is placed below the <see cref="MainInstruction"/> text.
        /// </para>
        /// <para>
        ///   On Windows XP, how and if this text is displayed depends on the value of the <see cref="DownlevelTextMode"/>
        ///   property.
        /// </para>
        /// </remarks>
        [Localizable(true), Category("Appearance"), Description("Additional text to display in the dialog."), DefaultValue(""), Editor(typeof(System.ComponentModel.Design.MultilineStringEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string Content
        {
            get { return _text ?? string.Empty; }
            set { _text = value; }
        }

        /// <summary>
        /// Gets or sets a value that indicates how the text of the <see cref="MainInstruction"/> and <see cref="Content"/> properties
        /// is displayed on Windows XP.
        /// </summary>
        /// <value>
        /// One of the values of the <see cref="Sage.CRE.Core.UI.Wpf.Dialogs.DownlevelTextMode"/> enumeration. The default value is
        /// <see cref="Sage.CRE.Core.UI.Wpf.Dialogs.DownlevelTextMode.MainInstructionAndContent"/>.
        /// </value>
        /// <remarks>
        /// <para>
        ///   Windows XP does not support the distinct visual style of the main instruction, so there is no visual difference between the
        ///   text of the <see cref="CredentialDialog.MainInstruction"/> and <see cref="CredentialDialog.Content"/> properties. Depending
        ///   on your requirements, you may wish to hide either the main instruction or the content text.
        /// </para>
        /// <para>
        ///   This property has no effect on Windows Vista and newer versions of Windows.
        /// </para>
        /// </remarks>
        [Localizable(true), Category("Appearance"), Description("Indicates how the text of the MainInstruction and Content properties is displayed on Windows XP."), DefaultValue(DownlevelTextMode.MainInstructionAndContent)]
        public DownlevelTextMode DownlevelTextMode { get; set; }

        /// <summary>
        /// Gets or sets a value that indicates whether a check box is shown on the dialog that allows the user to choose whether to save
        /// the credentials or not.
        /// </summary>
        /// <value>
        /// <see langword="true" /> when the "save password" checkbox is shown on the credentials dialog; otherwise, <see langword="false"/>.
        /// The default value is <see langword="false" />.
        /// </value>
        /// <remarks>
        /// When this property is set to <see langword="true" />, you must call the <see cref="ConfirmCredentials"/> method to save the
        /// credentials. When this property is set to <see langword="false" />, the credentials will never be saved, and you should not call
        /// the <see cref="ConfirmCredentials"/> method.
        /// </remarks>
        [Category("Appearance"), Description("Indicates whether a check box is shown on the dialog that allows the user to choose whether to save the credentials or not."), DefaultValue(false)]
        public bool ShowSaveCheckBox { get; set; }

        /// <summary>
        /// Shows the credentials dialog as a modal dialog.
        /// </summary>
        /// <returns><see langword="true" /> if the user clicked OK; otherwise, <see langword="false" />.</returns>
        /// <remarks>
        /// <para>
        ///   The credentials dialog will not be shown if one of the following conditions holds:
        /// </para>
        /// <list type="bullet">
        ///   <item>
        ///     <description>
        ///       <see cref="UseApplicationInstanceCredentialCache"/> is <see langword="true"/> and the application instance
        ///       credential cache contains credentials for the specified <see cref="Target"/>, even if <see cref="ShowUIForSavedCredentials"/>
        ///       is <see langword="true"/>.
        ///     </description>
        ///   </item>
        ///   <item>
        ///     <description>
        ///       <see cref="ShowSaveCheckBox"/> is <see langword="true"/>, <see cref="ShowUIForSavedCredentials"/> is <see langword="false"/>, and the operating system credential store
        ///       for the current user contains credentials for the specified <see cref="Target"/>.
        ///     </description>
        ///   </item>
        /// </list>
        /// <para>
        ///   In these cases, the <see cref="Credentials"/>, <see cref="UserName"/> and <see cref="Password"/> properties will
        ///   be set to the saved credentials and this function returns immediately, returning <see langword="true" />.
        /// </para>
        /// <para>
        ///   If the <see cref="ShowSaveCheckBox"/> property is <see langword="true"/>, you should call <see cref="ConfirmCredentials"/>
        ///   after validating if the provided credentials are correct.
        /// </para>
        /// </remarks>
        /// <exception cref="CredentialException">An error occurred while showing the credentials dialog.</exception>
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.UnmanagedCode)]
        public bool ShowDialog()
        { return ShowDialog(null); }

        /// <summary>
        /// Shows the credentials dialog as a modal dialog with the specified owner.
        /// </summary>
        /// <param name="owner">The <see cref="Window"/> that owns the credentials dialog.</param>
        /// <returns><see langword="true" /> if the user clicked OK; otherwise, <see langword="false" />.</returns>
        /// <remarks>
        /// <para>
        ///   The credentials dialog will not be shown if one of the following conditions holds:
        /// </para>
        /// <list type="bullet">
        ///   <item>
        ///     <description>
        ///       <see cref="UseApplicationInstanceCredentialCache"/> is <see langword="true"/> and the application instance
        ///       credential cache contains credentials for the specified <see cref="Target"/>, even if <see cref="ShowUIForSavedCredentials"/>
        ///       is <see langword="true"/>.
        ///     </description>
        ///   </item>
        ///   <item>
        ///     <description>
        ///       <see cref="ShowSaveCheckBox"/> is <see langword="true"/>, <see cref="ShowUIForSavedCredentials"/> is <see langword="false"/>, and the operating system credential store
        ///       for the current user contains credentials for the specified <see cref="Target"/>.
        ///     </description>
        ///   </item>
        /// </list>
        /// <para>
        ///   In these cases, the <see cref="Credentials"/>, <see cref="UserName"/> and <see cref="Password"/> properties will
        ///   be set to the saved credentials and this function returns immediately, returning <see langword="true" />.
        /// </para>
        /// <para>
        ///   If the <see cref="ShowSaveCheckBox"/> property is <see langword="true"/>, you should call <see cref="ConfirmCredentials"/>
        ///   after validating if the provided credentials are correct.
        /// </para>
        /// </remarks>
        /// <exception cref="CredentialException">An error occurred while showing the credentials dialog.</exception>
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.UnmanagedCode)]
        public bool ShowDialog(Object owner)
        {
            Window ownerWindow = owner as Window;

            IntPtr ownerHandle = ownerWindow == null ? NativeMethods.GetActiveWindow() : new WindowInteropHelper(ownerWindow).Handle;
            bool result;
            if (NativeMethods.IsWindowsVistaOrLater)
            {
                result = PromptForCredentialsCredUIWin(ownerHandle);
            }
            else
            {
                result = PromptForCredentialsCredUI(ownerHandle);
            }

            return result;
        }

        /// <summary>
        /// Raises the <see cref="UserNameChanged"/> event.
        /// </summary>
        /// <param name="e">The <see cref="EventArgs"/> containing data for the event.</param>
        protected virtual void OnUserNameChanged(EventArgs e)
        { UserNameChanged(this, e); }

        /// <summary>
        /// Raises the <see cref="PasswordChanged"/> event.
        /// </summary>
        /// <param name="e">The <see cref="EventArgs"/> containing data for the event.</param>
        protected virtual void OnPasswordChanged(EventArgs e)
        { PasswordChanged(this, e); }

        private bool PromptForCredentialsCredUI(IntPtr owner)
        {
            Sage.PInvoke.WinCred.CREDUI_INFO info = CreateCredUIInfo(owner, true);
            Sage.PInvoke.WinCred.CREDUI_FLAGS flags = Sage.PInvoke.WinCred.CREDUI_FLAGS.GENERIC_CREDENTIALS | Sage.PInvoke.WinCred.CREDUI_FLAGS.DO_NOT_PERSIST | Sage.PInvoke.WinCred.CREDUI_FLAGS.ALWAYS_SHOW_UI;
            if (ShowSaveCheckBox)
                flags |= Sage.PInvoke.WinCred.CREDUI_FLAGS.SHOW_SAVE_CHECK_BOX;

            IntPtr userNamePtr = IntPtr.Zero;
            IntPtr passwordPtr = IntPtr.Zero;
            try
            {
                // The maximum number of characters that can be copied to (pszUserName|szPassword) including the terminating null character.
                const Int32 USERNAME_BUFFER_SIZE_IN_BYTES = (Sage.PInvoke.WinCred.CREDUI_MAX_USERNAME_LENGTH + 1) * sizeof(Int16);
                if (UserName == null || UserName.Length == 0)
                {
                    userNamePtr = Marshal.AllocCoTaskMem(USERNAME_BUFFER_SIZE_IN_BYTES);
                    ZeroMemory(userNamePtr, USERNAME_BUFFER_SIZE_IN_BYTES);
                }
                else
                {
                    userNamePtr = Marshal.StringToCoTaskMemUni(UserName);
                    userNamePtr = Marshal.ReAllocCoTaskMem(userNamePtr, USERNAME_BUFFER_SIZE_IN_BYTES);
                    ZeroMemory(userNamePtr + (UserName.Length * sizeof(Int16)), USERNAME_BUFFER_SIZE_IN_BYTES - (UserName.Length * sizeof(Int16)));
                }

                const Int32 PASSWORD_BUFFER_SIZE_IN_BYTES = (Sage.PInvoke.WinCred.CREDUI_MAX_PASSWORD_LENGTH + 1) * sizeof(Int16);
                if (Password == null || Password.Length == 0)
                {
                    passwordPtr = Marshal.AllocCoTaskMem(PASSWORD_BUFFER_SIZE_IN_BYTES);
                    ZeroMemory(passwordPtr, PASSWORD_BUFFER_SIZE_IN_BYTES);
                }
                else
                {
                    passwordPtr = Marshal.SecureStringToCoTaskMemUnicode(Password);
                    passwordPtr = Marshal.ReAllocCoTaskMem(passwordPtr, PASSWORD_BUFFER_SIZE_IN_BYTES);
                    ZeroMemory(passwordPtr + (Password.Length * sizeof(Int16)), PASSWORD_BUFFER_SIZE_IN_BYTES - (Password.Length * sizeof(Int16)));
                }

                Sage.PInvoke.WinCred.CredUIReturnCodes result = Sage.PInvoke.WinCred.CredUIPromptForCredentials(ref info, String.Empty, IntPtr.Zero, 0,
                    userNamePtr,
                    Sage.PInvoke.WinCred.CREDUI_MAX_USERNAME_LENGTH,
                    passwordPtr,
                    Sage.PInvoke.WinCred.CREDUI_MAX_PASSWORD_LENGTH,
                    ref _isSaveChecked, flags);

                switch (result)
                {
                    case Sage.PInvoke.WinCred.CredUIReturnCodes.NO_ERROR:
                        UserName = Marshal.PtrToStringUni(userNamePtr);
                        Password = SecureStringUtils.PtrToSecureString(passwordPtr);
                        IsSaveChecked = _isSaveChecked;
                        return true;
                    case Sage.PInvoke.WinCred.CredUIReturnCodes.ERROR_CANCELLED:
                        return false;
                    default:
                        throw new CredentialException((int)result);
                }
            }
            finally
            {
                if (userNamePtr != IntPtr.Zero)
                    Marshal.ZeroFreeCoTaskMemUnicode(userNamePtr);
                if (passwordPtr != IntPtr.Zero)
                    Marshal.ZeroFreeCoTaskMemUnicode(passwordPtr);
            }
        }

        [DllImport("Kernel32.dll", EntryPoint = "RtlZeroMemory", SetLastError = false)]
        static extern void ZeroMemory(IntPtr dest, int size);

        private bool PromptForCredentialsCredUIWin(IntPtr owner)
        {
            Sage.PInvoke.WinCred.CREDUI_INFO info = CreateCredUIInfo(owner, false);
            Sage.PInvoke.WinCred.CredUIWinFlags flags = Sage.PInvoke.WinCred.CredUIWinFlags.Generic;
            if (ShowSaveCheckBox)
                flags |= Sage.PInvoke.WinCred.CredUIWinFlags.Checkbox;

            IntPtr inAuthBuffer = IntPtr.Zero;
            Int32 inAuthBufferSize = 0;
            IntPtr outBuffer = IntPtr.Zero;
            IntPtr userNamePtr = IntPtr.Zero;
            IntPtr passwordPtr = IntPtr.Zero;

            try
            {
                if ((UserName != null && UserName.Length > 0) || (Password != null && Password.Length > 0))
                {
                    userNamePtr = Marshal.StringToCoTaskMemUni(String.IsNullOrEmpty(UserName) ? "" : UserName);
                    passwordPtr = Marshal.SecureStringToCoTaskMemUnicode(Password == null ? new SecureString() : Password);
                }

                // prefilled with UserName or Password
                if (userNamePtr != IntPtr.Zero || passwordPtr != IntPtr.Zero)
                {
                    inAuthBufferSize = 0;
                    CredPackAuthenticationBuffer(0x00, userNamePtr, passwordPtr, IntPtr.Zero, ref inAuthBufferSize);
                    var win32Error = Marshal.GetLastWin32Error();
                    if (win32Error == 122 /*ERROR_INSUFFICIENT_BUFFER*/)
                    {
                        inAuthBuffer = Marshal.ReAllocCoTaskMem(inAuthBuffer, inAuthBufferSize);
                        ZeroMemory(inAuthBuffer, inAuthBufferSize);
                        if (
                            !CredPackAuthenticationBuffer(0x00, userNamePtr, passwordPtr, inAuthBuffer,
                                                                ref inAuthBufferSize))
                        {
                            throw new CredentialException(Marshal.GetLastWin32Error());
                        }
                    }
                    else
                    {
                        throw new Win32Exception(win32Error);
                    }
                }

                uint outBufferSize;
                uint package = 0;
                Sage.PInvoke.WinCred.CredUIReturnCodes result = Sage.PInvoke.WinCred.CredUIPromptForWindowsCredentials(ref info, 0, ref package, inAuthBuffer, inAuthBufferSize, out outBuffer, out outBufferSize, ref _isSaveChecked, flags);
                switch (result)
                {
                    case Sage.PInvoke.WinCred.CredUIReturnCodes.NO_ERROR:
                        using (var credentials = CredUnPackAuthenticationBufferWrapSecureString(true, outBuffer, Convert.ToInt32(outBufferSize)))
                        {
                            UserName = credentials.UserName;
                            Password = credentials.Password.Copy();
                            IsSaveChecked = _isSaveChecked;
                        }
                        return true;
                    case Sage.PInvoke.WinCred.CredUIReturnCodes.ERROR_CANCELLED:
                        return false;
                    default:
                        throw new CredentialException((int)result);
                }
            }
            finally
            {
                if (inAuthBuffer != IntPtr.Zero)
                    Marshal.ZeroFreeCoTaskMemUnicode(inAuthBuffer);
                if (outBuffer != IntPtr.Zero)
                    Marshal.FreeCoTaskMem(outBuffer);
                if (userNamePtr != IntPtr.Zero)
                    Marshal.ZeroFreeCoTaskMemUnicode(userNamePtr);
                if (passwordPtr != IntPtr.Zero)
                    Marshal.ZeroFreeCoTaskMemUnicode(passwordPtr);

            }
        }

        [DllImport("credui.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern Boolean CredPackAuthenticationBuffer(
            Int32 dwFlags,
            IntPtr pszUserName,
            IntPtr pszPassword,
            IntPtr pPackedCredentials,
            ref Int32 pcbPackedCredentials
        );

        [DllImport("credui.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern Boolean CredUnPackAuthenticationBuffer(
            Int32 dwFlags,
            IntPtr pAuthBuffer,
            Int32 cbAuthBuffer,
            IntPtr pszUserName,
            ref Int32 pcchMaxUserName,
            IntPtr pszDomainName,
            ref Int32 pcchMaxDomainame,
            IntPtr pszPassword,
            ref Int32 pcchMaxPassword
        );

        public static SecureCredentials CredUnPackAuthenticationBufferWrapSecureString(Boolean decryptProtectedCredentials, IntPtr authBufferPtr, Int32 authBufferSize)
        {
            Int32 userNameSize = 255;
            Int32 domainNameSize = 255;
            Int32 passwordSize = 255;
            IntPtr userNamePtr = IntPtr.Zero;
            IntPtr domainNamePtr = IntPtr.Zero;
            IntPtr passwordPtr = IntPtr.Zero;
            try
            {
                userNamePtr = Marshal.AllocCoTaskMem(userNameSize);
                ZeroMemory(userNamePtr, userNameSize);

                domainNamePtr = Marshal.AllocCoTaskMem(domainNameSize);
                ZeroMemory(domainNamePtr, domainNameSize);

                passwordPtr = Marshal.AllocCoTaskMem(passwordSize);
                ZeroMemory(passwordPtr, passwordSize);

                //#define CRED_PACK_PROTECTED_CREDENTIALS      0x1
                //#define CRED_PACK_WOW_BUFFER                 0x2
                //#define CRED_PACK_GENERIC_CREDENTIALS        0x4

                Boolean result = CredUnPackAuthenticationBuffer((decryptProtectedCredentials ? 0x1 : 0x0),
                                                                authBufferPtr,
                                                                authBufferSize,
                                                                userNamePtr,
                                                                ref userNameSize,
                                                                domainNamePtr,
                                                                ref domainNameSize,
                                                                passwordPtr,
                                                                ref passwordSize
                                                                );
                if (!result)
                {
                    var win32Error = Marshal.GetLastWin32Error();
                    if (win32Error == 122 /*ERROR_INSUFFICIENT_BUFFER*/)
                    {
                        userNamePtr = Marshal.ReAllocCoTaskMem(userNamePtr, userNameSize);
                        ZeroMemory(userNamePtr, userNameSize);

                        domainNamePtr = Marshal.ReAllocCoTaskMem(domainNamePtr, domainNameSize);
                        ZeroMemory(domainNamePtr, domainNameSize);

                        passwordPtr = Marshal.ReAllocCoTaskMem(passwordPtr, passwordSize);
                        ZeroMemory(passwordPtr, passwordSize);

                        result = CredUnPackAuthenticationBuffer((decryptProtectedCredentials ? 0x1 : 0x0),
                                                                authBufferPtr,
                                                                authBufferSize,
                                                                userNamePtr,
                                                                ref userNameSize,
                                                                domainNamePtr,
                                                                ref domainNameSize,
                                                                passwordPtr,
                                                                ref passwordSize);
                        if (!result)
                        {
                            throw new Win32Exception(Marshal.GetLastWin32Error());
                        }
                    }
                    else
                    {
                        throw new Win32Exception(win32Error);
                    }
                }

                return new SecureCredentials
                {
                    UserName = Marshal.PtrToStringUni(userNamePtr),
                    Password = SecureStringUtils.PtrToSecureString(passwordPtr)
                };
            }
            finally
            {
                if (userNamePtr != IntPtr.Zero)
                    Marshal.ZeroFreeCoTaskMemUnicode(userNamePtr);
                if (domainNamePtr != IntPtr.Zero)
                    Marshal.ZeroFreeCoTaskMemUnicode(domainNamePtr);
                if (passwordPtr != IntPtr.Zero)
                    Marshal.ZeroFreeCoTaskMemUnicode(passwordPtr);
            }
        }

        private Sage.PInvoke.WinCred.CREDUI_INFO CreateCredUIInfo(IntPtr owner, bool downlevelText)
        {
            Sage.PInvoke.WinCred.CREDUI_INFO info = new Sage.PInvoke.WinCred.CREDUI_INFO();
            info.cbSize = System.Runtime.InteropServices.Marshal.SizeOf(info);
            info.hwndParent = owner;
            if (downlevelText)
            {
                info.pszCaptionText = WindowTitle;
                switch (DownlevelTextMode)
                {
                    case DownlevelTextMode.MainInstructionAndContent:
                        if (MainInstruction.Length == 0)
                            info.pszMessageText = Content;
                        else if (Content.Length == 0)
                            info.pszMessageText = MainInstruction;
                        else
                            info.pszMessageText = MainInstruction + Environment.NewLine + Environment.NewLine + Content;
                        break;
                    case DownlevelTextMode.MainInstructionOnly:
                        info.pszMessageText = MainInstruction;
                        break;
                    case DownlevelTextMode.ContentOnly:
                        info.pszMessageText = Content;
                        break;
                }
            }
            else
            {
                // Vista and later don't use the window title.
                info.pszMessageText = Content;
                info.pszCaptionText = MainInstruction;
            }
            return info;
        }
    }
}
