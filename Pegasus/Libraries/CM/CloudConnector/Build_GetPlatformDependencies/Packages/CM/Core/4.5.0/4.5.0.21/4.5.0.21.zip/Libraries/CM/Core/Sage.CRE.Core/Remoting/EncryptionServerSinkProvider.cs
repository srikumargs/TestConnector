using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using System.IO;

using Sage.CRE.LinkedSource;

namespace Sage.Remoting
{
    public sealed class EncryptionServerSinkProvider : IServerChannelSinkProvider
    {
        public EncryptionServerSinkProvider(String algorithmName, Byte[] encryptionKey)
        {
            Initialize(algorithmName, encryptionKey);
        }

        public EncryptionServerSinkProvider(String algorithmName, String keyFilePath)
        {
            FileInfo fileInfo = new FileInfo(keyFilePath);
            if (!fileInfo.Exists)
            {
                throw new FileNotFoundException("Key file does not exist.", keyFilePath);
            }

            FileStream keyFileStream = new FileStream(keyFilePath, FileMode.Open, FileAccess.Read);
            Byte[] encryptionKey = new Byte[fileInfo.Length];
            keyFileStream.Read(encryptionKey, 0, encryptionKey.Length);

            Initialize(algorithmName, encryptionKey);
        }

        #region IServerChannelSinkProvider Members
        public IServerChannelSink CreateSink(IChannelReceiver channel)
        {
            IServerChannelSink nextChannelSink = _nextProvider.CreateSink(channel);
            return new EncryptionServerSink(nextChannelSink, _cryptoAlgorithm, _encryptionKey);
        }

        public void GetChannelData(IChannelDataStore channelData)
        { }

        public IServerChannelSinkProvider Next
        {
            get { return _nextProvider; }
            set { _nextProvider = value; }
        }
        #endregion

        #region Private methods
        private void Initialize(String algorithmName, Byte[] encryptionKey)
        {
            _cryptoAlgorithm = Cryptography.GetCryptoAlgorithm(algorithmName);
            _encryptionKey = new Byte[encryptionKey.GetLength(0)];
            encryptionKey.CopyTo(_encryptionKey, 0);
        }
        #endregion

        #region Private fields
        private IServerChannelSinkProvider _nextProvider;
        private CryptoAlgorithm _cryptoAlgorithm;
        private Byte[] _encryptionKey;
        #endregion
    }
}
