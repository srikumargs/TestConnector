using System;
using System.Collections.Generic;
using System.Windows.Forms;

using Sage.Configuration;

namespace TraceConfigTool
{
    static class Program
    {
        /// <summary>
        /// Static constructor to initialize the LibraryManager prior to any other members or field initialization being JIT-compiled and used.
        /// </summary>
        /// <remarks>
        /// This is needed becuase, in theory, the only Sage assembly that can be successfully found may be
        /// Sage.CRE.LibraryManagement.dll until the LibraryManager is initialized.
        /// </remarks>
        static Program()
        {
//            LibraryManager.InitializeLibraries(LibraryManager.LibraryManifestsLocationForProcess);
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }


        static public System.Configuration.AppSettingsReader appSettings = new System.Configuration.AppSettingsReader();

    }
}