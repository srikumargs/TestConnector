﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Security.Principal;
using Sage.CRE.Core.UI.Wpf.Controls;

namespace Sage.CRE.Core.UI.Wpf.UACShieldSupport
{
    /// <summary>
    /// Provides a WPF button that displays a UAC Shield icon when required
    /// </summary>
    public class UACShieldButton : Button, INotifyPropertyChanged
    {
        #region Constructors
        /// <summary>
        /// Creates the default shield icon and registers the dependency property with it
        /// </summary>
        static UACShieldButton()
        {
            ImageSource shield;

            BitmapSource shieldSource = null;
            if (Environment.OSVersion.Version.Major >= 6)
            {
                shieldSource = StockIcons.GetBitmapSource(StockIconIdentifier.Shield, StockIconOptions.Handle | StockIconOptions.Small);
            }
            else
            {
                shieldSource = System.Windows.Interop.Imaging.CreateBitmapSourceFromHIcon(
                    System.Drawing.SystemIcons.Shield.Handle,
                    Int32Rect.Empty,
                    BitmapSizeOptions.FromEmptyOptions());
            }

            shield = shieldSource;
            ShieldIconProperty = DependencyProperty.Register("ShieldIcon",
                typeof(ImageSource), typeof(UACShieldButton),
                new FrameworkPropertyMetadata(shield, FrameworkPropertyMetadataOptions.AffectsRender, OnShieldIconChanged));

            // _needsShieldDisplay indicates if the current OS/application/user needs a UAC shield displayed.
            // If the OS is not UAC enabled or the users is already elevated then no shield is required.
            // If _needsShieldDisplay is false (no shield required) the most of this class becomes a no-op.
            if (Environment.OSVersion.Version.Major >= 6) // Vista or higher
                _needsShieldDisplay = (!WindowsIdentity.GetCurrent().IsUserAdmin()); // If already an admin don't bother
        }


        /// <summary>
        /// Initializes an instance of the <see cref="UACShieldButton"/> class
        /// </summary>
        public UACShieldButton()
            : base()
        {
            base.Loaded += new RoutedEventHandler(OnLoaded);
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets/Sets if the caller desires the <see cref="ShieldIcon"/> to be displayed.  This is a dependency property.
        /// </summary>
        /// <value>A bool that indicates if the <see cref="ShieldIcon"/> caller wants the <see cref="ShieldIcon"/>  displayed</value>
        /// <remarks>
        /// This is only an indication of desire.  If the operating system does not support UAC or the user is already
        /// elevated, any request to display is ignored.
        /// </remarks>
        public bool DesiresShield
        {
            get { return (bool)GetValue(DesiresShieldProperty); }
            set { SetValue(DesiresShieldProperty, value); }
        }

        /// <summary>
        /// Gets/Sets the icon so show when elevation is required.  This is a dependency property.
        /// </summary>
        /// <value>An ImageSoruce that represents a graphic to be displayed </value>
        public ImageSource ShieldIcon
        {
            get { return (ImageSource)GetValue(ShieldIconProperty); }
            set { SetValue(ShieldIconProperty, value); }
        }

        /// <summary>
        /// Indicates taht the shield is desired and the OS supports elevation
        /// </summary>
        public bool ShowingShield
        {
            get { return _needsShieldDisplay && DesiresShield; }
        }

        /// <summary>
        /// Gets/Sets ToolTip shown when elevation has been preformed
        /// </summary>
        /// <value>A string that is used as the ToolTip when elevation is complete</value>
        public object ToolTipElevated
        {
            get { return _tooltipElevated; }
            set { _tooltipElevated = value; }
        }

        /// <summary>
        /// Gets/Sets ToolTip shown when elevation has not been preformed
        /// </summary>
        /// <value>A string that is used as the ToolTip when elevation is required</value>
        public object ToolTipNotElevated
        {
            get { return _tooltipNotElevated; }
            set { _tooltipNotElevated = value; }
        }
        #endregion


        #region Methods
        /// <summary>
        /// Creates/Gets current UACShieldAdorner based on the <see cref="ShieldIcon"/>
        /// </summary>
        /// <remarks>
        /// If there is no current, a new UACShieldAdorner is created wit the current <see cref="ShieldIcon"/>
        /// and made current.  The current UACShieldAdorner is returned.
        /// </remarks>
        private UACShieldAdorner GetUACShieldAdorner()
        {
            if (_shieldAdorner == null)
                _shieldAdorner = new UACShieldAdorner(this, ShieldIcon);
            return _shieldAdorner;
        }

        /// <summary>
        /// Returns current "actual" ToolTip
        /// </summary>
        /// <returns>
        /// If both <see cref="ToolTipElevated"/> and <see cref="ToolTipNotElevated"/> are null,
        /// <see cref="Button.ToolTip"/> is returned.
        /// Otherwise <see cref="ToolTipElevated"/> or <see cref="ToolTipNotElevated"/> is rturned
        /// based on <see cref="DesiresShield"/>
        /// </returns>
        /// <remarks>
        /// </remarks>
        public object GetToolTip()
        {
            if (ToolTipElevated == null && ToolTipNotElevated == null)
                return base.ToolTip;
            return DesiresShield ? ToolTipNotElevated : ToolTipElevated;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            if (ShowingShield)
                ShieldAdormentAdd();
            base.ToolTip = GetToolTip();
        }

        /// <summary>
        /// Add the shield image as an adorner 
        /// </summary>
        private void ShieldAdormentAdd()
        {
            if (!_shieldShowing)
            {
                AdornerLayer.GetAdornerLayer(this).Add(GetUACShieldAdorner());
                _shieldShowing = true;
            }
        }

        /// <summary>
        /// Removes the shield image adorner
        /// </summary>
        private void ShieldAdormentRemove()
        {
            if (_shieldShowing)
            {
                AdornerLayer.GetAdornerLayer(this).Remove(GetUACShieldAdorner());
                _shieldShowing = false;
            }
        }

        /// <summary>
        /// Handles a change to the <see cref="DesiresShield"/> property
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="e"></param>
        /// <remarks>
        /// Adds or removes the UACShieldAdorner as appropriate
        /// <para>
        /// Sets the <see cref="Button.ToolTip"/> as appropriate
        /// </para>
        /// </remarks>
        private static void OnDesiresShieldChanged(DependencyObject obj, DependencyPropertyChangedEventArgs e)
        {
            bool showShield = (bool)e.NewValue && _needsShieldDisplay;
            UACShieldButton me = (UACShieldButton)obj;

            if (showShield)
                me.ShieldAdormentAdd();
            else
                me.ShieldAdormentRemove();
            me.ToolTip = me.GetToolTip();
            me.FirePropertyChangedEvent("DesiresShield");
        }

        /// <summary>
        /// Handles a change to the <see cref="ShieldIcon"/> property
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="e"></param>
        /// <remarks>
        /// Removes any exising adorner
        /// <para>
        /// Clears the adorner to force a new one to be created when needed.
        /// </para>
        /// <para>
        /// If <see cref="DesiresShield"/> is ture, it adds the new UACShieldAdorner
        /// </para>
        /// </remarks>
        private static void OnShieldIconChanged(DependencyObject obj, DependencyPropertyChangedEventArgs e)
        {
            ImageSource image = (ImageSource)e.NewValue;
            UACShieldButton me = (UACShieldButton)obj;

            // Remove any existing adorner with the old image
            me.ShieldAdormentRemove();

            // Force a new UACShieldAdorner to be created on next use
            me._shieldAdorner = null;
            if (me.ShowingShield)
                me.ShieldAdormentAdd();
            me.FirePropertyChangedEvent("ShieldIcon");
        }
        #endregion

        #region INotifyPropertyChanged
        private void FirePropertyChangedEvent(string propertyName)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion

        #region Fields
        /// <summary>
        /// Dependency Property - Indicates if the UAC Shield is desired on the button
        /// </summary>
        public static readonly DependencyProperty DesiresShieldProperty = DependencyProperty.Register("DesiresShield",
                                                                                                    typeof(bool), typeof(UACShieldButton),
                                                                                                    new FrameworkPropertyMetadata(true, FrameworkPropertyMetadataOptions.Inherits |
                                                                                                        FrameworkPropertyMetadataOptions.AffectsRender, OnDesiresShieldChanged));
        /// <summary>
        /// Dependency Property - The shield icon to display
        /// </summary>
        public static readonly DependencyProperty ShieldIconProperty;

        private static bool _needsShieldDisplay;
        private UACShieldAdorner _shieldAdorner;
        private bool _shieldShowing;
        private object _tooltipElevated;
        private object _tooltipNotElevated;
        #endregion

        public event PropertyChangedEventHandler PropertyChanged = delegate(object sender, PropertyChangedEventArgs e) { };
    }
}
