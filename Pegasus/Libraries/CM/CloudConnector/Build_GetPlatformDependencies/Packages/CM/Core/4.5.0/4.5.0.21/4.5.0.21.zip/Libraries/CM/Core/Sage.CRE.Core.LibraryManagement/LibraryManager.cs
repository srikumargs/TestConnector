using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml;
using System.Xml.XPath;

using Sage.Configuration.Internal;
using Sage.Sandbox.Tools.LinkedSource;

namespace Sage.Configuration
{
    /// <summary>
    /// The library Manager class is used to support shared component 
    /// libraries. The library Manager class uses Library Manifest files 
    /// to provided library dependency validations, assembly location 
    /// resolutions, and COM ProgId Mappings from version independent 
    /// ProgIds to version specific ProgIds.
    /// </summary>
    public static class LibraryManager
    {
        #region Fields
        
        // A flag that indicates if the assembly resolve event has been initialized or not
        private static Boolean _resolveEventInitialized; // = false; Initialized by the runtime.

        // Used for thread syncronization
        private static Object _syncRoot = new Object();

        // A collection of additional directories which should be searched
        private static readonly List<String> _supplementaryResolveDirectories = new List<String>();

        // A switch to control trace output.
        private static BooleanSwitch _traceSwitch = new BooleanSwitch("Sage.CRE.LibraryManagement", "Controls tracing for Sage.CRE.LibraryManagement.", "0");

        #endregion

        #region Public Properties

        /// <summary>
        /// Returns the location where the shared Sage libraries are installed
        /// </summary>
        /// <remarks>Although shared libraries are typically expected to be 
        /// located at "Program Files\Common Files\Sage", an alternate location 
        /// can be specified via the 'Location' attribute on the 'SharedLibraries' 
        /// element in a FolderRedirect.xml file at: 
        /// C:\Documents and Settings\All Users\Application Data\Sage</remarks>
        public static String SharedLibrariesLocation
        { get { return FolderManager.SageCommonProgramFilesLocation; } }


        /// <summary>
        /// Returns the location where the shared libraries are installed
        /// </summary>
        /// <remarks>Although shared libraries are typically expected to be 
        /// located at "Program Files\Common Files", an alternate location 
        /// can be specified via the 'Location' attribute on the 'SharedLibraries' 
        /// element in a FolderRedirect.xml file at: 
        /// C:\Documents and Settings\All Users\Application Data\Sage</remarks>
        public static String CommonProgramFiles
        { get { return FolderManager.CommonProgramFilesLocation; } }
        
        /// <summary>
        /// Return the location for shared documents on the current machine
        /// </summary>
        /// <remarks>Although this location is typically 
        /// "C:\Documents and Settings\All Users\Application Data\Shared Documents", 
        /// an alternate location can be specified via the 'Location' attribute on the 'SharedDocuments'
        /// element in a FolderRedirect.xml file at: 
        /// C:\Documents and Settings\All Users\Application Data\Sage</remarks>
        public static String SharedDocumentsLocation
        { get { return FolderManager.SharedDocumentsLocation; } }

        /// <summary>
        /// Return the location for configuration files shared by all users on a machine
        /// </summary>
        /// <remarks>Although this location is typically 
        /// "C:\Documents and Settings\All Users\Application Data\Sage", 
        /// an alternate location can be specified via the 'Location' attribute on the 
        /// 'SharedConfiguration' element in a FolderRedirect.xml file at: 
        /// C:\Documents and Settings\All Users\Application Data\Sage</remarks>
        public static String SharedConfigLocation
        { get { return FolderManager.SageCommonApplicationDataLocation; } }

        /// <summary>
        /// Base location for configuration files for a specific user on a machine
        /// </summary>
        /// <remarks>Although this location is typically 
        /// "C:\Documents and Settings\[User Name]\Application Data\Sage", 
        /// an alternate location can be specified via the 'Location' attribute on 
        /// the 'UserConfigurationBase' element in a FolderRedirect.xml file at: 
        /// C:\Documents and Settings\All Users\Application Data\Sage</remarks>
        public static String UserConfigLocation
        { get { return FolderManager.SageApplicationDataLocation; } }


        /// <summary>
        /// Return the location for My Documents for a specific user on a machine
        /// </summary>
        /// <remarks>Although this location is typically 
        /// "C:\Documents and Settings\[User Name]\My Documents", 
        /// an alternate location can be specified via the 'Location' attribute on the 
        /// 'UserConfigurationBase' element in a FolderRedirect.xml file at: 
        /// C:\Documents and Settings\All Users\Application Data\Sage</remarks>
        public static String MyDocumentsLocation
        { get { return FolderManager.MyDocumentsLocation; } }

        #endregion

        #region Public Methods

        /// <summary>
        /// Appends a specific directory to the list of directories which should be explicitly searched when
        /// trying to resolve an assembly.
        /// </summary>
        /// <remarks>
        /// These supplementary search directories are processed after all standard shared library directories.
        /// 
        /// No library manifest processing will occur in this location.
        /// </remarks>
        /// <param name="directory">The additional directory which should be searched</param>
        public static void AddSupplementaryResolveDirectory(String directory)
        {
            if (String.IsNullOrEmpty(directory))
            {
                throw new ArgumentNullException(Constants.DirectoryParameter, Strings.AddSupplementaryResolveDirectoryNullOrEmptyArgument);
            }

            if (!Directory.Exists(directory))
            {
                throw new DirectoryNotFoundException(String.Format(CultureInfo.CurrentUICulture, Strings.DirectoryLocationNotFoundErrorFormat, directory));
            }

            lock (_syncRoot)
            {
                if (!_resolveEventInitialized)
                {
                    AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(ResolveLibraryAssembly);
                    _resolveEventInitialized = true;
                }

                if (!_supplementaryResolveDirectories.Contains(directory.ToLowerInvariant()))
                {
                    _supplementaryResolveDirectories.Add(directory.ToLowerInvariant());
                }
            }
        }

        #endregion

        #region Private Methods


        /// <summary>
        /// Attempt to resolve assembly loads for component lbraries 
        /// </summary>
        /// <param name="sender">Current AppDomain</param>
        /// <param name="args">Event Arguments used to determine what assembly is trying to be resolved</param>
        /// <returns>The requested assembly if it could be resolved, Null if it could not be resolved</returns>
        private static Assembly ResolveLibraryAssembly(Object sender, ResolveEventArgs args)
        {
            Debug.Assert(args != null);

            Assembly result = null;
            String fileName = args.Name;

            // first search to see if the assembly is already loaded;  if so,
            // then return it rather than loading again
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                if (assembly.FullName == args.Name)
                {
                    result = assembly;
                    break;
                }
            }

            // try to find assembly in Shared Library structure
            if (result == null)
            {
                if (fileName.Contains(Internal.Constants.AssemblyNameSprarator))
                {
                    String[] fileNameParts = fileName.Split(Internal.Constants.AssemblyNameSprarator[0]);
                    fileName = fileNameParts[0];
                }
                if (!fileName.EndsWith(Internal.Constants.DllExtension, StringComparison.InvariantCultureIgnoreCase))
                {
                    fileName += Internal.Constants.DllExtension;
                }
            }

            // if it hasn't yet been found, then try the supplementary directories
            if (result == null)
            {
                foreach (String directory in _supplementaryResolveDirectories)
                {
                    String filePath = Path.Combine(directory, fileName);
                    if (File.Exists(filePath))
                    {
                        ConditionalTrace(Strings.TraceResolvedAssemblyFormat, fileName, filePath);
                        result = Assembly.LoadFrom(filePath);
                        break;
                    }
                }
            }

            if (result != null)
            {
                ConditionalTrace(Strings.TraceLoadedAssemblyFormat, result.FullName);
            }
            else
            {
                ConditionalTrace(Strings.TraceUnableToResolveAssemblyFormat, fileName);
            }

            return result;
        }

        /// <summary>
        /// Writes a message to the trace listeners if the "Sage.CRE.LibraryManagement"
        /// trace switch is enabled.
        /// </summary>
        /// <remarks>
        /// To enable the switch, place the following in the application's exe.config:
        /// <example>
        ///     <system.diagnostics>
        ///         <switches>
        ///             <add name="Sage.CRE.LibraryManagement" value="1" />
        ///         </switches> 
        ///     </system.diagnostics>
        /// </example>
        /// </remarks>
        /// <param name="format">A String containing zero or more format items.</param>
        /// <param name="args">An Object array containing zero or more objects to format.</param>
        private static void ConditionalTrace(String format, params Object[] args)
        {
            Trace.WriteLineIf(_traceSwitch.Enabled, String.Format(CultureInfo.CurrentUICulture, String.Format(CultureInfo.CurrentUICulture, Strings.TraceFormat, typeof(LibraryManager).FullName, format), args));
        }

        #endregion
    }
}
