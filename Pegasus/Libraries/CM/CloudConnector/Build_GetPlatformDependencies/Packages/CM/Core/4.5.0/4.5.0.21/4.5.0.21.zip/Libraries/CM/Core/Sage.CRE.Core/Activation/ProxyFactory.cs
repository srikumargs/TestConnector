using System;
using System.Collections;
using System.Collections.Specialized;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading;

using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Generates a proxy.  This overrides the .NET proxy requirements
    /// that forces one to extend MarshalByRefObject or (for a different purpose)
    /// ContextBoundObject in order to have a proxy-able class.
    /// 
    /// Generated proxy types use a specified IInvokeHandler to give you an opportunity
    /// to do interception and customization of the proxy implementation on a method-by-method
    /// basis.
    /// </summary>
    /// <remarks>
    /// The <see cref="ProxyFactory"/> should be used to generate a class
    /// implementing the specified interfaces (and deriving from the specified base).
    /// The class implementation will only call the internal <see cref="IInvokeHandler"/> instance.
    /// </remarks>
    /// <example>
    /// <code>
    /// IInterfaceExposed proxy = 
    ///     (IInterfaceExposed) ProxyFactory.CreateProxy( "MyProxyTypeName", new Type[] { typeof(IInterfaceExposed) }, new MyinvokeHandler() );
    /// </code>
    /// </example>
    public static class ProxyFactory
    {
        #region Public methods
        /// <summary>
        /// Generates a proxy implementing all the specified interfaces and
        /// redirecting method invocations to the specifed invokeHandler.
        /// </summary>
        /// <param name="generatedProxyTypeName">The type name of the generated proxy.</param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the generated proxy type implements.</param>
        /// <param name="invokeHandler">Instance of <see cref="IInvokeHandler"/>.</param>
        /// <returns>an instance of the generated proxy type</returns>
        public static object CreateProxy(string generatedProxyTypeName, Type[] interfaceTypesToImplement, IInvokeHandler invokeHandler)
        {
            ArgumentValidator.ValidateNonEmptyString(generatedProxyTypeName, "generatedProxyTypeName", _myTypeName + ".CreateProxy");
            ArgumentValidator.ValidateNonEmptyArray(interfaceTypesToImplement, "interfaceTypesToImplement", _myTypeName + ".CreateProxy");
            ArgumentValidator.ValidateNonNullReference(invokeHandler, "invokeHandler", _myTypeName + ".CreateProxy");

            return PrivateCreateProxyAndSaveAssembly(generatedProxyTypeName, interfaceTypesToImplement, invokeHandler, null, null, null);
        }

        /// <summary>
        /// Generates a proxy implementing all the specified interfaces and
        /// redirecting method invocations to the specifed invokeHandler.
        /// </summary>
        /// <param name="generatedProxyTypeName">The type name of the generated proxy.</param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the generated proxy type implements.</param>
        /// <param name="invokeHandler">Instance of <see cref="IInvokeHandler"/>.</param>
        /// <param name="parentType">The type that the generated proxy should extend.</param>
        /// <returns>an instance of the generated proxy type</returns>
        public static object CreateProxy(string generatedProxyTypeName, Type[] interfaceTypesToImplement, IInvokeHandler invokeHandler, Type parentType)
        {
            ArgumentValidator.ValidateNonEmptyString(generatedProxyTypeName, "generatedProxyTypeName", _myTypeName + ".CreateProxy");
            ArgumentValidator.ValidateNonEmptyArray(interfaceTypesToImplement, "interfaceTypesToImplement", _myTypeName + ".CreateProxy");
            ArgumentValidator.ValidateNonNullReference(invokeHandler, "invokeHandler", _myTypeName + ".CreateProxy");
            ArgumentValidator.ValidateNonNullReference(parentType, "parentType", _myTypeName + ".CreateProxy");

            return PrivateCreateProxyAndSaveAssembly(generatedProxyTypeName, interfaceTypesToImplement, invokeHandler, parentType, null, null);
        }

        /// <summary>
        /// Generates a proxy implementing all the specified interfaces and
        /// redirecting method invocations to the specifed invokeHandler.
        /// </summary>
        /// <param name="generatedProxyTypeName">The type name of the generated proxy.</param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the generated proxy type implements.</param>
        /// <param name="invokeHandler">Instance of <see cref="IInvokeHandler"/>.</param>
        /// <param name="parentType">The type that the generated proxy should extend.</param>
        /// <param name="parentTypeMethodNames">Array of parent type method names which should be proxied;  null if all eligible methods should be proxied</param>
        /// <returns>an instance of the generated proxy type</returns>
        public static object CreateProxy(string generatedProxyTypeName, Type[] interfaceTypesToImplement, IInvokeHandler invokeHandler, Type parentType, string[] parentTypeMethodNames)
        {
            ArgumentValidator.ValidateNonEmptyString(generatedProxyTypeName, "generatedProxyTypeName", _myTypeName + ".CreateProxy");
            ArgumentValidator.ValidateNonEmptyArray(interfaceTypesToImplement, "interfaceTypesToImplement", _myTypeName + ".CreateProxy");
            ArgumentValidator.ValidateNonNullReference(invokeHandler, "invokeHandler", _myTypeName + ".CreateProxy");
            ArgumentValidator.ValidateNonNullReference(parentType, "parentType", _myTypeName + ".CreateProxy");
            ArgumentValidator.ValidateNonEmptyArray(parentTypeMethodNames, "parentTypeMethodNames", _myTypeName + ".CreateProxy");

            return PrivateCreateProxyAndSaveAssembly(generatedProxyTypeName, interfaceTypesToImplement, invokeHandler, parentType, parentTypeMethodNames, null);
        }

        /// <summary>
        /// Generates a proxy implementing all the specified interfaces and
        /// redirecting method invocations to the specifed invokeHandler.  Saves the
        /// generated assembly to disk.
        /// </summary>
        /// <param name="generatedProxyTypeName">The type name of the generated proxy.</param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the generated proxy type implements.</param>
        /// <param name="invokeHandler">Instance of <see cref="IInvokeHandler"/>.</param>
        /// <param name="assemblyFileName">The file name (no path) that should be used to save the dynamic assembly to disk</param>
        /// <returns>an instance of the generated proxy type</returns>
        public static object CreateProxyAndSaveAssembly(string generatedProxyTypeName, Type[] interfaceTypesToImplement, IInvokeHandler invokeHandler, string assemblyFileName)
        {
            ArgumentValidator.ValidateNonEmptyString(generatedProxyTypeName, "generatedProxyTypeName", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonEmptyArray(interfaceTypesToImplement, "interfaceTypesToImplement", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonNullReference(invokeHandler, "invokeHandler", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonEmptyString(assemblyFileName, "assemblyFileName", _myTypeName + ".CreateProxyAndSaveAssembly");

            return PrivateCreateProxyAndSaveAssembly(generatedProxyTypeName, interfaceTypesToImplement, invokeHandler, null, null, assemblyFileName);
        }

        /// <summary>
        /// Generates a proxy implementing all the specified interfaces and
        /// redirecting method invocations to the specifed invokeHandler.  Saves the
        /// generated assembly to disk.
        /// </summary>
        /// <param name="generatedProxyTypeName">The type name of the generated proxy.</param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the generated proxy type implements.</param>
        /// <param name="invokeHandler">Instance of <see cref="IInvokeHandler"/>.</param>
        /// <param name="parentType">The type that the generated proxy should extend.</param>
        /// <param name="assemblyFileName">The file name (no path) that should be used to save the dynamic assembly to disk</param>
        /// <returns>an instance of the generated proxy type</returns>
        public static object CreateProxyAndSaveAssembly(string generatedProxyTypeName, Type[] interfaceTypesToImplement, IInvokeHandler invokeHandler, Type parentType, string assemblyFileName)
        {
            ArgumentValidator.ValidateNonEmptyString(generatedProxyTypeName, "generatedProxyTypeName", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonEmptyArray(interfaceTypesToImplement, "interfaceTypesToImplement", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonNullReference(invokeHandler, "invokeHandler", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonNullReference(parentType, "parentType", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonEmptyString(assemblyFileName, "assemblyFileName", _myTypeName + ".CreateProxyAndSaveAssembly");

            return PrivateCreateProxyAndSaveAssembly(generatedProxyTypeName, interfaceTypesToImplement, invokeHandler, parentType, null, assemblyFileName);
        }

        /// <summary>
        /// Generates a proxy implementing all the specified interfaces and
        /// redirecting method invocations to the specifed invokeHandler.  Saves the
        /// generated assembly to disk.
        /// </summary>
        /// <param name="generatedProxyTypeName">The type name of the generated proxy.</param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the generated proxy type implements.</param>
        /// <param name="invokeHandler">Instance of <see cref="IInvokeHandler"/>.</param>
        /// <param name="parentType">The type that the generated proxy should extend.</param>
        /// <param name="parentTypeMethodNames">Array of parent type method names which should be proxied;  null if all eligible methods should be proxied</param>
        /// <param name="assemblyFileName">The file name (no path) that should be used to save the dynamic assembly to disk</param>
        /// <returns>an instance of the generated proxy type</returns>
        public static object CreateProxyAndSaveAssembly(string generatedProxyTypeName, Type[] interfaceTypesToImplement, IInvokeHandler invokeHandler, Type parentType, string[] parentTypeMethodNames, string assemblyFileName)
        {
            ArgumentValidator.ValidateNonEmptyString(generatedProxyTypeName, "generatedProxyTypeName", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonEmptyArray(interfaceTypesToImplement, "interfaceTypesToImplement", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonNullReference(invokeHandler, "invokeHandler", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonNullReference(parentType, "parentType", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonEmptyArray(parentTypeMethodNames, "parentTypeMethodNames", _myTypeName + ".CreateProxyAndSaveAssembly");
            ArgumentValidator.ValidateNonEmptyString(assemblyFileName, "assemblyFileName", _myTypeName + ".CreateProxyAndSaveAssembly");

            return PrivateCreateProxyAndSaveAssembly(generatedProxyTypeName, interfaceTypesToImplement, invokeHandler, parentType, parentTypeMethodNames, assemblyFileName);
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Generates a proxy implementing all the specified interfaces and
        /// redirecting method invocations to the specifed invokeHandler.  Saves the
        /// generated assembly to disk.
        /// </summary>
        /// <param name="generatedProxyTypeName">The type name of the generated proxy.</param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the generated proxy type implements.</param>
        /// <param name="invokeHandler">Instance of <see cref="IInvokeHandler"/>.</param>
        /// <param name="parentType">The type that the generated proxy should extend.</param>
        /// <param name="parentTypeMethodNames">Array of parent type method names which should be proxied;  null if all eligible methods should be proxied</param>
        /// <param name="assemblyFileName">The file name (no path) that should be used to save the dynamic assembly to disk</param>
        /// <returns>an instance of the generated proxy type</returns>
        private static object PrivateCreateProxyAndSaveAssembly(string generatedProxyTypeName, Type[] interfaceTypesToImplement, IInvokeHandler invokeHandler, Type parentType, string[] parentTypeMethodNames, string assemblyFileName)
        {
            // look up the generatedProxyTypeName if we have already created the dynamic assembly for this type
            Type generatedType = TypeBuilder.GetType(generatedProxyTypeName);
            if(generatedType == null)
            {
                GenerateTypeAndSaveAssembly(generatedProxyTypeName, interfaceTypesToImplement, parentType, parentTypeMethodNames, assemblyFileName);
            }

            return TypeBuilder.CreateObject(generatedProxyTypeName, new object[] { invokeHandler });
        }

        /// <summary>
        /// Generates the proxy type definition.
        /// </summary>
        /// <param name="generatedProxyTypeName">The type name of the generated proxy.</param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the generated proxy type implements.</param>
        /// <param name="parentType">The type that the generated proxy should extend.</param>
        /// <param name="parentTypeMethodNames">Array of parent type method names which should be proxied;  null if all eligible methods should be proxied</param>
        /// <param name="assemblyFileName">The file name (no path) that should be used to save the dynamic assembly to disk</param>
        /// <returns>the generated proxy type definition</returns>
        private static void GenerateTypeAndSaveAssembly(string generatedProxyTypeName, Type[] interfaceTypesToImplement, Type parentType, string[] parentTypeMethodNames, string assemblyFileName)
        {
            TypeBuilder typeBuilder = new TypeBuilder(assemblyFileName);


            // define the new type
            typeBuilder.DefinePublicClassType(generatedProxyTypeName, parentType, interfaceTypesToImplement);


            // create a member field inside the type to hold on to the invokeHandler
            FieldBuilder invokeHandlerFieldBuilder = typeBuilder.DefinePrivateInstanceField("_invokeHandler", typeof(IInvokeHandler));

            // create a constructor for the new type
            typeBuilder.DefinePublicInstanceConstructor(new Type[] { typeof(IInvokeHandler) }, new TypeBuilder.EmitImplementationCallback(EmitConstructorImplementation), new object[] { invokeHandlerFieldBuilder });

            // create implementations for the specified interfaces
            GenerateImplementationForInterfaces(typeBuilder, interfaceTypesToImplement, invokeHandlerFieldBuilder);


            // If we have been given a parent type, then proxy those methods too
            if(parentType != null)
            {
                MethodInfo[] methodInfos = parentType.GetMethods();

                // if the caller provided specific method names, then sort them so that we can call
                // BinarySearch on the array later on.
                if(parentTypeMethodNames != null)
                {
                    Array.Sort(parentTypeMethodNames);
                }

                foreach(MethodInfo methodInfo in methodInfos)
                {
                    // if the caller did not specify any method names or if the current name matches a specified name,
                    // then generate the method on the proxy
                    if(parentTypeMethodNames == null || Array.BinarySearch(parentTypeMethodNames, methodInfo.Name) >= 0)
                    {
                        // cannot generate methods which are already marked as final!
                        if(!methodInfo.IsFinal)
                        {
                            GenerateMethodImplementation(typeBuilder, methodInfo, invokeHandlerFieldBuilder);
                        }
                    }
                }
            }


            // finished defining the type ... call CreateType() to indicate we are done
            typeBuilder.CreateType();


            // if a name was provided for the assembly, then use it and save the assembly to disk
            if(assemblyFileName != null && assemblyFileName.Length > 0)
            {
                typeBuilder.SaveAssembly();
            }
        }

        private static void EmitConstructorImplementation(ILGenerator constructorIL, object[] data)
        {
            Assertions.Assert(data.Length == 1);
            Assertions.Assert(data[0] is FieldBuilder);

            FieldBuilder invokeHandlerFieldBuilder = (FieldBuilder) data[0];

            // Load "this"
            constructorIL.Emit(OpCodes.Ldarg_0);
            // Load first constructor parameter
            constructorIL.Emit(OpCodes.Ldarg_1);
            // Set the first parameter into the handler field
            constructorIL.Emit(OpCodes.Stfld, invokeHandlerFieldBuilder);
        }

        /// <summary>
        /// Generates implementation for all properties and methods int the specified interfaces
        /// </summary>
        /// <param name="typeBuilder">the <see cref="TypeBuilder"/> for the proxy type being generated.</param>
        /// <param name="interfaceTypesToImplement">the list of interfaces that the generated proxy type implements.</param>
        /// <param name="invokeHandlerFieldBuilder">the <see cref="FieldBuilder"/> instance representing the invoke handler field</param>
        private static void GenerateImplementationForInterfaces(TypeBuilder typeBuilder, Type[] interfaceTypesToImplement, FieldBuilder invokeHandlerFieldBuilder)
        {
            foreach(Type interfaceType in interfaceTypesToImplement)
            {
                GenerateInterfaceImplementation(typeBuilder, interfaceType, invokeHandlerFieldBuilder);
            }
        }

        /// <summary>
        /// Generates implementation for all properties and methods in the specified interface
        /// </summary>
        /// <param name="typeBuilder">the <see cref="TypeBuilder"/> for the proxy type being generated.</param>
        /// <param name="interfaceType">interface type that the generated proxy should implement</param>
        /// <param name="invokeHandlerFieldBuilder">the <see cref="FieldBuilder"/> instance representing the invoke handler field</param>
        private static void GenerateInterfaceImplementation(TypeBuilder typeBuilder, Type interfaceType, FieldBuilder invokeHandlerFieldBuilder)
        {
            ArgumentValidator.ValidateTypeIsInterface(interfaceType, "interfaceType", _myTypeName + ".GenerateInterfaceImplementation");

            Type[] baseInterfaceTypes = interfaceType.FindInterfaces(new TypeFilter(NoFilterImpl), interfaceType);
            GenerateImplementationForInterfaces(typeBuilder, baseInterfaceTypes, invokeHandlerFieldBuilder);

            PropertyInfo[] propertyInfos = interfaceType.GetProperties();
            for(int i = 0 ; i < propertyInfos.Length ; i++)
            {
                typeBuilder.DefineProperty(propertyInfos[i].Name, propertyInfos[i].Attributes, propertyInfos[i].PropertyType);
            }

            MethodInfo[] methodInfos = interfaceType.GetMethods();
            foreach(MethodInfo methodInfo in methodInfos)
            {
                GenerateMethodImplementation(typeBuilder, methodInfo, invokeHandlerFieldBuilder);
            }
        }

        /// <summary>
        /// Generates implementation for a method
        /// </summary>
        /// <param name="typeBuilder">the <see cref="TypeBuilder"/> for the proxy type being generated.</param>
        /// <param name="methodInfo">the <see cref="MethodInfo"/> instance for the method being implemented.</param>
        /// <param name="invokeHandlerFieldBuilder">the <see cref="FieldBuilder"/> instance representing the invoke handler field</param>
        private static void GenerateMethodImplementation(TypeBuilder typeBuilder, MethodInfo methodInfo, FieldBuilder invokeHandlerFieldBuilder)
        {
            MethodInfoCache.AddMethodInfo(methodInfo);

            ParameterInfo[] parameterInfos = methodInfo.GetParameters();

            System.Type[] parameters = new System.Type[parameterInfos.Length];
            for(int i = 0 ; i < parameterInfos.Length ; i++)
            {
                parameters[i] = parameterInfos[i].ParameterType;
            }

            typeBuilder.DefinePublicInstanceMethod(methodInfo, new TypeBuilder.EmitMethodImplementationWithMethodInfoCallback(EmitMethodImplementationWithMethodInfo), new object[] { invokeHandlerFieldBuilder });
        }

        /// <summary>
        /// Writes the stack for the method implementation.  This 
        /// method generates the IL stack for property get/set method as
        /// well as ordinary methods.
        /// </summary>
        /// <remarks>
        /// The method implementation will be simple as:
        /// <code>
        /// public void SomeMethod( int parameter )
        /// {
        ///    MethodInfo info1 = MethodInfoCache.GetMethodInfo("SomeTypeName", 1);
        ///    return this._invokeHandler.Invoke(this, info1, new object[] { parameter });
        /// }
        /// </code>
        /// </remarks>
        /// <param name="methodBuilder">the <see cref="MethodBuilder"/> instance for the method being implemented.</param>
        /// <param name="methodInfo">the <see cref="MethodInfo"/> instance for the method being implemented.</param>
        /// <param name="parameterTypes">the types of the parameters for the method being implemented.</param>
        /// <param name="ilGenerator"></param>
        /// <param name="data"></param>
        //private static void WriteILForMethod(MethodBuilder methodBuilder, MethodInfo methodInfo, System.Type[] parameterTypes, FieldBuilder invokeHandlerFieldBuilder)
        private static void EmitMethodImplementationWithMethodInfo(MethodBuilder methodBuilder, MethodInfo methodInfo, Type[] parameterTypes, ILGenerator ilGenerator, object[] data)
        {
            Assertions.Assert(data.Length == 1);
            Assertions.Assert(data[0] is FieldBuilder);

            FieldBuilder invokeHandlerFieldBuilder = (FieldBuilder) data[0];

            int arrayPositionInStack = 1;

            //ILGenerator ilGenerator = methodBuilder.GetILGenerator();
            ilGenerator.DeclareLocal(typeof(MethodInfo));

            // Emit a declaration of a local variable if there is a return
            // type defined
            if(methodBuilder.ReturnType != typeof(void))
            {
                ilGenerator.DeclareLocal(methodBuilder.ReturnType);
                arrayPositionInStack = 2;
            }

            // local object array for parameters for the method
            ilGenerator.DeclareLocal(typeof(object[]));

            // Add the MethodInfo key to the cache.  Emit code to load the method info key, used to get the MethodInfo object
            // from MethodInfoCache
            ilGenerator.Emit(OpCodes.Ldstr, MethodInfoCache.AddMethodInfo(methodInfo));
            // invoke GetMethodInfo in MethodInfoCache
            ilGenerator.Emit(OpCodes.Call, typeof(MethodInfoCache).GetMethod("GetMethodInfo", new Type[] { typeof(string) }));
            // store the result of the GetMethodInfo call into the local variable
            ilGenerator.Emit(OpCodes.Stloc_0);

            // load "this"
            ilGenerator.Emit(OpCodes.Ldarg_0);
            // load the handler
            ilGenerator.Emit(OpCodes.Ldfld, invokeHandlerFieldBuilder);
            // load "this"
            ilGenerator.Emit(OpCodes.Ldarg_0);
            // load the result of the GetMethodInfo call
            ilGenerator.Emit(OpCodes.Ldloc_0);
            // load the number of parameters onto the stack
            ilGenerator.Emit(OpCodes.Ldc_I4, parameterTypes.Length);
            // create a new array, using the size that was just pused on the stack
            ilGenerator.Emit(OpCodes.Newarr, typeof(object));

            if(parameterTypes.Length != 0)
            {
                ilGenerator.Emit(OpCodes.Stloc, arrayPositionInStack);
                ilGenerator.Emit(OpCodes.Ldloc, arrayPositionInStack);
            }

            // if we have any parameters, then iterate through and set the values
            // of each element to the corresponding arguments
            for(int c = 0 ; c < parameterTypes.Length ; c++)
            {
                ilGenerator.Emit(OpCodes.Ldc_I4, c);
                ilGenerator.Emit(OpCodes.Ldarg, c + 1);

                if(parameterTypes[c].IsValueType)
                {
                    ilGenerator.Emit(OpCodes.Box, parameterTypes[c].UnderlyingSystemType);
                }

                ilGenerator.Emit(OpCodes.Stelem_Ref);
                ilGenerator.Emit(OpCodes.Ldloc, arrayPositionInStack);
            }

            // call the Invoke method
            ilGenerator.Emit(OpCodes.Callvirt, typeof(IInvokeHandler).GetMethod("Invoke"));

            if(methodBuilder.ReturnType != typeof(void))
            {
                // if the return type if a value type, then unbox the return value
                // so that we don't get junk.
                if(!methodBuilder.ReturnType.IsValueType)
                {
                    ilGenerator.Emit(OpCodes.Castclass, methodBuilder.ReturnType);
                }
                else
                {
                    ilGenerator.Emit(OpCodes.Unbox, methodBuilder.ReturnType);
                    ilGenerator.Emit(TypeBuilder.ConvertTypeToOpCode(methodBuilder.ReturnType));
                }

                // store the result
                ilGenerator.Emit(OpCodes.Stloc, 1);

                // declare a lable for returning from the method
                Label label = ilGenerator.DefineLabel();
                // jump to the return statement
                ilGenerator.Emit(OpCodes.Br_S, label);
                // mark the return statement
                ilGenerator.MarkLabel(label);
                // load the result
                ilGenerator.Emit(OpCodes.Ldloc, 1);
            }
            else
            {
                // pop the return value that Invoke returned from the stack since
                // the method's return type is void. 
                ilGenerator.Emit(OpCodes.Pop);
            }

            // Return
            ilGenerator.Emit(OpCodes.Ret);
        }

        /// <summary>
        /// Filters the classes represented in an array of Type objects. 
        /// </summary>
        /// <param name="m">The Type object to which the filter is applied.</param>
        /// <param name="filterCriteria">An arbitrary object used to filter the list. </param>
        /// <returns>true to include the Type in the filtered list; otherwise false. </returns>
        private static bool NoFilterImpl(Type m, object filterCriteria)
        {
            return true; // include all types
        }
        #endregion

        #region Private fields
        private static string _myTypeName = typeof(ProxyFactory).FullName;
        #endregion
    }
}