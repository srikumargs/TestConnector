using System;
using System.Runtime.InteropServices;

namespace Sage.Net
{
    /// <summary>
    /// Summary description for WNet.
    /// </summary>
    public sealed class mpr
    {
        // various #defines from WinNetwk.h (an MS header)
        /// <summary>
        /// Windows define - see MSDN
        /// </summary>
        public static readonly uint RESOURCETYPE_ANY = 0x00000000;
        /// <summary>
        /// Windows define - see MSDN
        /// </summary>
        public static readonly uint RESOURCE_GLOBALNET = 0x00000002;
        /// <summary>
        /// Windows define - see MSDN
        /// </summary>
        public static readonly uint RESOURCE_CONTEXT = 0x00000005;

        /// <summary>
        /// Windows define - see MSDN
        /// </summary>
        public static readonly uint RESOURCEUSAGE_CONTAINER = 0x00000002;

        /// <summary>
        /// Windows define - see MSDN
        /// </summary>
        public static readonly uint RESOURCEDISPLAYTYPE_GENERIC = 0x00000000;
        /// <summary>
        /// Windows define - see MSDN
        /// </summary>
        public static readonly uint RESOURCEDISPLAYTYPE_SERVER = 0x00000002;


        // Network types; used by WNetGetProviderName
        /// <summary>
        /// Microsoft network type
        /// </summary>
        public static readonly int WNNC_NET_LANMAN = 0x00020000;
        // other types exist; see WinNetWk.h for complete list


        /// <summary>
        /// Windows structure - see MSDN
        /// </summary>
        [ComVisible(false)]
        public struct NETRESOURCE
        {
            /// <summary>
            /// See MSDN help for NETRESOURCE
            /// </summary>
            public uint dwScope;
            /// <summary>
            /// See MSDN help for NETRESOURCE
            /// </summary>
            public uint dwType;
            /// <summary>
            /// See MSDN help for NETRESOURCE
            /// </summary>
            public uint dwDisplayType;
            /// <summary>
            /// See MSDN help for NETRESOURCE
            /// </summary>
            public uint dwUsage;

            /// <summary>
            /// See MSDN help for NETRESOURCE
            /// </summary>
            [MarshalAs(UnmanagedType.LPTStr)]
            public string lpLocalName;
            /// <summary>
            /// See MSDN help for NETRESOURCE
            /// </summary>
            [MarshalAs(UnmanagedType.LPTStr)]
            public string lpRemoteName;
            /// <summary>
            /// See MSDN help for NETRESOURCE
            /// </summary>
            [MarshalAs(UnmanagedType.LPTStr)]
            public string lpComment;
            /// <summary>
            /// See MSDN help for NETRESOURCE
            /// </summary>
            [MarshalAs(UnmanagedType.LPTStr)]
            public string lpProvider;
        };


        /// <summary>
        /// WNetGetProviderName
        /// </summary>
        /// <param name="dwNetType">network type</param>
        /// <param name="lpProviderName">[out] buffer to receive provider name</param>
        /// <param name="lpBufferSize">size of buffer</param>
        /// <returns>zero for success</returns>
        [DllImport("mpr.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern int WNetGetProviderName(int dwNetType,
            System.Text.StringBuilder lpProviderName, ref int lpBufferSize);

        /// <summary>
        /// WNetOpenEnum
        /// </summary>
        [DllImport("mpr.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern int WNetOpenEnum(uint dwScope, uint dwType, uint dwUsage,
            [MarshalAs(UnmanagedType.AsAny)][In] Object lpNetResource, out IntPtr lphEnum);

        /// <summary>
        /// WNetEnumResource
        /// </summary>
        [DllImport("mpr.dll", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int WNetEnumResource(IntPtr hEnum, ref int lpcCount,
            IntPtr lpBuffer, ref int lpBufferSize);

        /// <summary>
        /// WNetCloseEnum
        /// </summary>
        [DllImport("mpr.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern int WNetCloseEnum(IntPtr hEnum);

        static private readonly int NO_ERROR = 0;
        static private readonly int ERROR_NO_MORE_ITEMS = 259;



        /// <summary>
        /// Get the network provider name
        /// </summary>
        /// <param name="dwNetType">network type define</param>
        /// <returns>network provider name; for our purposes it should be "Microsoft Windows Network"</returns>
        static public string GetProviderName(int dwNetType)
        {
            int bufSize = 256;
            string providerName = "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder(bufSize);
            if (NO_ERROR == WNetGetProviderName(dwNetType, sb, ref bufSize))
            {
                providerName = sb.ToString();
            }

            return providerName;
        }


        /// <summary>
        /// Get a list of servers; internally uses the WNetEnumResource function.
        /// </summary>
        /// <param name="domain">domain name for the servers</param>
        /// <param name="alServers">collection of Server objects</param>
        /// <returns>true</returns>
        static public bool EnumServers(string domain, System.Collections.ArrayList alServers)
        {
            int errorCode = 0;
            if (alServers == null)
            {
                throw new ArgumentNullException("EnumServers", "Null ArrayList of servers");
            }

            // limit our network enumeration to servers on the specified domain
            mpr.NETRESOURCE nr = new mpr.NETRESOURCE();
            uint dwScope = nr.dwScope = mpr.RESOURCE_GLOBALNET;
            uint dwType = nr.dwType = mpr.RESOURCETYPE_ANY;
            uint dwUsage = nr.dwUsage = mpr.RESOURCEUSAGE_CONTAINER;
            nr.dwDisplayType = mpr.RESOURCEDISPLAYTYPE_SERVER;
            nr.lpRemoteName = domain;
            nr.lpLocalName = nr.lpComment = null;
            nr.lpProvider = GetProviderName(WNNC_NET_LANMAN);       // #506112 - required for Terminal Server on Win2003 Server 

            // For debugging, some common WNet errors:
            //   87 = ERROR_INVALID_PARAMETER;
            // 1204 = ERROR_BAD_PROVIDER;
            // 1207 = ERROR_NOT_CONTAINER;
            // 1208 = ERROR_EXTENDED_ERROR;
            // 1222 = ERROR_NO_NETWORK;
            IntPtr lphEnum = new IntPtr();
            errorCode = mpr.WNetOpenEnum(dwScope, dwType, dwUsage, (object)nr, out lphEnum);

            if (errorCode == NO_ERROR)
            {
                int dwCount = -1;     // number of entries desired
                int nBufferSize = 16384;
                IntPtr pBuffer = Marshal.AllocHGlobal(nBufferSize);
                do
                {
                    errorCode = mpr.WNetEnumResource(lphEnum, ref dwCount, pBuffer, ref nBufferSize);
                    if (NO_ERROR == errorCode)
                    {
                        Int32 ptr = pBuffer.ToInt32();
                        for (int i = 0; i < dwCount; i++)
                        {
                            nr = (mpr.NETRESOURCE)Marshal.PtrToStructure(new IntPtr(ptr), typeof(mpr.NETRESOURCE));
                            ptr += Marshal.SizeOf(nr);
                            alServers.Add(new Server(nr.lpRemoteName.Substring(2)));     // Remove the "\\" at the front of the server name
                        }
                    }
                } while (NO_ERROR == errorCode);
                Marshal.FreeHGlobal(pBuffer);
                mpr.WNetCloseEnum(lphEnum);
            }
            if (errorCode != NO_ERROR &&        /*   0 */
                errorCode != ERROR_NO_MORE_ITEMS /* 259 */ )
            {
                throw new System.ComponentModel.Win32Exception();
            }
            return true;
        }
    }
}
