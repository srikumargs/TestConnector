﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace Sage.CRE.Core.SQL
{
    /// <summary>
    /// Describes a connection to a SQL server.
    /// </summary>
    [Serializable]
    public class SqlConnectionContext : ICloneable
    {
        /// <summary>
        /// Default ctor.
        /// </summary>
        public SqlConnectionContext()
        {

        }

        /// <summary>
        /// Creates a SqlConntectionContext from a SqlConnectionStringBuilder.
        /// </summary>
        /// <param name="connectionStringBuilder"></param>
        public SqlConnectionContext(SqlConnectionStringBuilder connectionStringBuilder)
        {
            WorkTheString(connectionStringBuilder.DataSource);
            _initialCatalog = connectionStringBuilder.InitialCatalog;
            _intergratedSecurity = connectionStringBuilder.IntegratedSecurity;
            _userid = connectionStringBuilder.UserID;
            _password = connectionStringBuilder.Password;
        }

        private void WorkTheString(string serverInstance)
        {
            if (serverInstance.Contains(@":"))
            {
                if (!serverInstance.ToLower().StartsWith(@"tcp:")) throw new System.ArgumentException(StringsCustomerFacing.DatabaseLibrary_OnlyTCPIsSupported);
                string[] parts = serverInstance.Split(new char[] { ':' });
                if ((parts.Length != 2) || (String.IsNullOrEmpty(parts[1]))) throw new System.ArgumentException(StringsCustomerFacing.DatabaseLibrary_ColonsMustOnlyBeUsedToSpecifyTheProtocol);
                serverInstance = parts[1];
                // we're discarding the protocol.
            }

            if (serverInstance.Contains(@","))
            {
                string[] parts = serverInstance.Split(new char[] { ',' });
                if ((parts.Length != 2) || (String.IsNullOrEmpty(parts[1]))) throw new System.ArgumentException(StringsCustomerFacing.DatabaseLibrary_NoCommasInHostOrInstanceName);
                _dataSource.Port = System.Convert.ToUInt16(parts[1]);
                serverInstance = parts[0];
            }

            if (serverInstance.Contains(@"\"))
            {
                string[] parts = serverInstance.Split(new char[] { '\\' });
                if ((parts.Length != 2) || (String.IsNullOrEmpty(parts[1]))) throw new System.ArgumentException(StringsCustomerFacing.DatabaseLibrary_InvalidHostOrInstanceName);
                serverInstance = parts[0];
                _dataSource.InstanceName = parts[1];
            }

            _dataSource.Host = serverInstance;

        }

        /// <summary>
        /// Creates a SqlConntectionContext from jsut a server name.
        /// </summary>
        /// <param name="serverInstance">The server instance.</param>
        public SqlConnectionContext(string serverInstance)
        {

            WorkTheString(serverInstance);

        }

        /// <summary>
        /// Creates a context based on a host and database name.
        /// </summary>
        /// <param name="host"></param>
        /// <param name="database"></param>
        public SqlConnectionContext(string host, string database)
        {
            WorkTheString(host);
            _initialCatalog = database;
        }

        /// <summary>
        /// Creates a context based on a host, database, userID, and password.
        /// </summary>
        /// <param name="host"></param>
        /// <param name="database"></param>
        /// <param name="userID"></param>
        /// <param name="password"></param>
        public SqlConnectionContext(string host, string database, string userID, string password)
        {
            WorkTheString(host);
            _initialCatalog = database;
            _intergratedSecurity = false;
            _userid = userID;
            _password = password;
        }

        /// <summary>
        /// Creates a context based on a host, tcp port, and database.
        /// </summary>
        /// <param name="host"></param>
        /// <param name="port"></param>
        /// <param name="database"></param>
        public SqlConnectionContext(string host, int port, string database)
        {
            WorkTheString(host);
            _dataSource.Port = port;
            _initialCatalog = database;
        }


        /// <summary>
        /// Creates a context based on a host, port, database, userID, and password.
        /// </summary>
        /// <param name="host"></param>
        /// <param name="port"></param>
        /// <param name="database"></param>
        /// <param name="userID"></param>
        /// <param name="password"></param>
        public SqlConnectionContext(string host, int port, string database, string userID, string password)
        {
            WorkTheString(host);
            _dataSource.Port = port;
            _initialCatalog = database;
            _intergratedSecurity = false;
            _userid = userID;
            _password = password;
        }
        
        /// <summary>
        /// Creates a context based on a host, instance name, and database name.
        /// </summary>
        /// <param name="host"></param>
        /// <param name="instance"></param>
        /// <param name="database"></param>
        public SqlConnectionContext(string host, string instance, string database)
        {
            _dataSource.Host = host;
            _dataSource.InstanceName = instance;
            _initialCatalog = database;
        }


        /// <summary>
        /// Creates a context based on host, instance name, database, userID, and password.
        /// </summary>
        /// <param name="host"></param>
        /// <param name="instance"></param>
        /// <param name="database"></param>
        /// <param name="userID"></param>
        /// <param name="password"></param>
        public SqlConnectionContext(string host, string instance, string database, string userID, string password)
        {
            WorkTheString(host);
            _dataSource.InstanceName = instance;
            _initialCatalog = database;
            _intergratedSecurity = false;
            _userid = userID;
            _password = password;
        }

        /// <summary>
        /// Creates a context based on host, port, instance, and database.
        /// </summary>
        /// <param name="host"></param>
        /// <param name="port"></param>
        /// <param name="instance"></param>
        /// <param name="database"></param>
        public SqlConnectionContext(string host, int port, string instance, string database)
        {
            WorkTheString(host);
            _dataSource.Port = port;
            _dataSource.InstanceName = instance;
            _initialCatalog = database;
        }

        /// <summary>
        /// Creates a context based on host, port, instance, database, userID, password.
        /// </summary>
        /// <param name="host"></param>
        /// <param name="port"></param>
        /// <param name="instance"></param>
        /// <param name="database"></param>
        /// <param name="userID"></param>
        /// <param name="password"></param>
        public SqlConnectionContext(string host, int port, string instance, string database, string userID, string password)
        {
            WorkTheString(host);
            _dataSource.Port = port;
            _dataSource.InstanceName = instance;
            _initialCatalog = database;
            _intergratedSecurity = false;
            _userid = userID;
            _password = password;
        }



        private SqlServerAddress _dataSource = new SqlServerAddress();

        private System.String   _initialCatalog = String.Empty;
        private System.Boolean  _intergratedSecurity = true;

        private System.String   _password = String.Empty;
        private System.String   _userid = String.Empty;
        private System.String _applicationName = System.Diagnostics.Process.GetCurrentProcess().ProcessName;

        /// <summary>
        /// Gets or sets the application name of the context.
        /// </summary>
        public System.String Application
        {
            get { return _applicationName; }
            set { _applicationName = value; }
        }

        /// <summary>
        /// Gets or sets the address of the SQL server.
        /// </summary>
        public SqlServerAddress DataSource
        {
            get { return _dataSource; }
            set { _dataSource = value; }
        }

        /// <summary>
        /// Gets or Sets the InitialCatalog of the context.
        /// </summary>
        public System.String InitialCatalog
        {
            get { return _initialCatalog; }
            set { _initialCatalog = value; }
        }

        /// <summary>
        /// Gets or sets whether Integrated Securty (NTLM, SSPI) should be used to authenticated against the SQL server.
        /// </summary>
        public System.Boolean IntegratedSecurity
        {
            get { return _intergratedSecurity; }
            set { _intergratedSecurity = value; }
        }

        /// <summary>
        /// Gets or sets the password used to authenticate against the SQL server.
        /// </summary>
        public System.String Password
        {
            get { return _password; }
            set { _password = value; }
        }

        /// <summary>
        /// Gets or sets the user id used to authentication against the SQL server.
        /// </summary>
        public System.String UserID
        {
            get { return _userid; }
            set { _userid = value; }
        }

        /// <summary>
        /// Gets a properly formated connection string.
        /// </summary>
        public System.String ConnectionString
        {
            get
            {
                System.Data.SqlClient.SqlConnectionStringBuilder b = new System.Data.SqlClient.SqlConnectionStringBuilder();
                b.ApplicationName = _applicationName;
                b.AsynchronousProcessing = false;
                b.ConnectTimeout = 5;
                b.DataSource = _dataSource.DataSource;
                b.Encrypt = false;
                b.InitialCatalog = _initialCatalog;
                b.IntegratedSecurity = _intergratedSecurity;
                b.Password = _password;
                b.TypeSystemVersion = "SQL Server 2008";
                b.UserID = _userid;
                b.WorkstationID = System.Environment.MachineName;

                return b.ConnectionString;
                
            }
        }

        #region ICloneable Members

        /// <summary>
        /// Clones the SqlConnectionContext object.
        /// </summary>
        /// <returns></returns>
        public object Clone()
        {
            SqlConnectionContext result = new SqlConnectionContext();
            result._dataSource = this._dataSource;
            result._initialCatalog = this._initialCatalog;
            result._intergratedSecurity = this._intergratedSecurity;
            result._password = this._password;
            result._userid = this._userid;
            result._applicationName = this._applicationName;

            return result;
        }

        #endregion
    }
}
