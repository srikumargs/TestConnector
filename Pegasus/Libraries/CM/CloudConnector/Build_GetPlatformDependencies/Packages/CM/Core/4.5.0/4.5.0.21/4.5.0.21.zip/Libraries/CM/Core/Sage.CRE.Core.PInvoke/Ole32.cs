using System;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;
namespace Sage.PInvoke
{
    /// <summary>
    /// Summary description for COle32.
    /// </summary>
    public static class Ole32
    {
        public static void CoFreeUnusedLibraries()
        {
            PInvoke.NativeMethods.CoFreeUnusedLibraries();
        }
    }
}
