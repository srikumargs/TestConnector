using System;
using System.ServiceModel;

namespace Sage.SystemModel
{
    /// <summary>
    /// Generic interface contract to manage event subscriptions.
    /// </summary>
    [ServiceContract]
    public interface ISubscriptionService
    {
        /// <summary>
        /// Initiate the duplex communication with the subscription service. A conversation with the service must begin with this method call.
        /// </summary>
        [OperationContract(IsOneWay = true, IsInitiating = true, IsTerminating = false)]
        void Connect();

        /// <summary>
        /// Subscribes the caller to the specific event named.  Use String.Empty or null to subscribe to all operations in the callback contract.
        /// </summary>
        /// <remarks>
        /// Note that the caller can subscribe to all events and then unsubscribe from a particular one.
        /// </remarks>
        /// <param name="eventOperation"></param>
        [OperationContract(IsOneWay = true, IsInitiating = false, IsTerminating = false)]
        void Subscribe(String eventOperation);

        /// <summary>
        /// Simple keep-alive operation
        /// </summary>
        [OperationContract(IsOneWay = true, IsInitiating = false, IsTerminating = false)]
        void KeepAlive();

        /// <summary>
        /// Unsubscribes the caller from the specific event named.  Use String.Empty or null to unsubscribe to all operations in the callback contract.
        /// </summary>
        /// <param name="eventOperation"></param>
        [OperationContract(IsOneWay = true, IsInitiating = false, IsTerminating = false)]
        void Unsubscribe(String eventOperation);

        /// <summary>
        /// Terminate the duplex communication with the subscription service. A conversation with the service should end with this method call.
        /// </summary>
        [OperationContract(IsOneWay = true, IsInitiating = false, IsTerminating = true)]
        void Disconnect();
    }
}