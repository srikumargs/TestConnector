using System;
using System.Runtime.InteropServices;
using System.Collections;
using System.Xml;
using Sage.IO;
using Sage.Diagnostics;

namespace Sage.Activation
{

	/// <summary>
	/// A factory for creating plugin components
	/// </summary>
    [ComVisible(false)]
	public class PluginComponentFactory
	{
        // Interface to a component that will provide info about available plugins
        private readonly IDataStreamProvider _provider; //= null; (automatically initialized by runtime)

        // A cache of instantiated components
        private SortedList _componentCache; //= null; (automatically initialized by runtime)

        // XPath extression for locating the components node in the file
        private string _componentsExpression = "//Components";
      
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="provider">A data stream provider</param>
        /// <remarks>The data stream provider must provide XML streams defining the components to load</remarks>
		public PluginComponentFactory( IDataStreamProvider provider )
		{
		    _provider = provider;
            _provider.DataRead += new DataReadEventHandler( OnDataRead );
		}

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="provider">A data stream provider</param>
        /// <param name="cacheLoadedPlugins">A flag indicating if loaded plugins should be cached or not. By default caching is disabled</param>
        /// <remarks>The data stream provider must provide XML streams defining the components to load</remarks>
        public PluginComponentFactory( IDataStreamProvider provider, bool cacheLoadedPlugins )
        {
            _provider = provider;
            _provider.DataRead += new DataReadEventHandler( OnDataRead );
            if( cacheLoadedPlugins )
            {
                _componentCache = new SortedList();
            }
        }

        /// <summary>
        /// Event fired when a plugin is loaded
        /// </summary>
        public event PluginLoadedEventHandler PluginLoaded;

        /// <summary>
        /// Event fired if there is an error loading a plugin
        /// </summary>
        public event PluginErrorEventHandler PluginLoadError;

        /// <summary>
        /// Load all available components
        /// </summary>
        public void Load()
        {
            ClearPluginCache();
            _provider.Read();   
        }

        /// <summary>
        /// Clear the cache of currently loaded components
        /// </summary>
        public void ClearPluginCache()
        {
            if( _componentCache != null )
            {
                _componentCache.Clear();
            }
        }

        /// <summary>
        /// Set/Get an XPath expression used to locate the component entries in a plugin's file
        /// </summary>
        public string ComponentsExpression
        {
            get{ return _componentsExpression; }
            set
            { 
                ArgumentValidator.ValidateNonEmptyString( value, "ComponentsExpression", "PluginComponentFactory" );
                _componentsExpression = value; 
            }
        }

        /// <summary>
        /// Retrieve a collection of the names of cached plugins
        /// </summary>
        /// <exception cref="InvalidOperationException"/>
        /// <remarks>Will throw an InvalidOperationException if caching is not enabled</remarks>
        public ICollection PluginNamesCache
        {
            get
            {
                MakeSureCachingIsOn();
                return _componentCache.Keys;
            }
        }

        /// <summary>
        /// Retrieve the collection of cached components.
        /// </summary>
        /// <exception cref="InvalidOperationException"/>
        /// <remarks>Will throw an InvalidOperationException if caching is not enabled</remarks>
        public ICollection PluginCache
        {
            get
            {
                MakeSureCachingIsOn();
                return _componentCache.Values;
            }
        }

        /// <summary>
        /// Make sure that caching has been enabled
        /// </summary>
        private void MakeSureCachingIsOn()
        {
            if( _componentCache == null )
            {
                throw new InvalidOperationException( Strings.PluginCachingIsNotEnabled );
            }
        }

        /// <summary>
        /// Read all components in a data stream
        /// </summary>
        /// <param name="sender">The IDataStreamProvider component providing the data stream</param>
        /// <param name="args">Event arguments</param>
        private void OnDataRead( object sender, DataReadEventArgs args )
        {
        
            try
            {
                XmlDocument document = new XmlDocument();
                document.Load( args.DataStream );
                XmlNode root = document.SelectSingleNode( _componentsExpression );
                if( root != null )
                {
                    foreach( XmlNode node in root.SelectNodes( "child::Component" ) )
                    {
                        try
                        {
                            object component = TypeFactory.CreateObject( node );
                            if( component != null && component is IPluginComponent )
                            {
                                XmlNode componentInfo = node.SelectSingleNode("child::ComponentInfo");
                                if( componentInfo != null )
                                {
                                    (component as IPluginComponent).InitializeFromXml( componentInfo.OuterXml );
                                }
                                OnPluginLoaded( component );
                            }
                            else 
                            {
                                if( component == null )
                                {
                                    throw new NullReferenceException( Strings.NullReferenceReturnedFromFactory );
                                }
                                else
                                {
                                    throw new InvalidCastException( Strings.ComponentDoesNotSupportIPluginComponentInterface );     
                                }
                            }
                        }
                        catch( Exception error )
                        {
                            OnErrorLoadingPlugin( error, node.OuterXml );
                        }
                    }
                }
            }
            catch( Exception error )
            {
                OnErrorLoadingPlugin( error, args.DataSourceId );
            }
        }

        /// <summary>
        /// Fire the error loading plugin event
        /// </summary>
        /// <param name="error"></param>
        /// <param name="additionalData"></param>
        private void OnErrorLoadingPlugin( Exception error, string additionalData )
        {
            if( PluginLoadError != null )
            {
                PluginLoadError( this, new PluginErrorEventArgs( error, additionalData ) );
            }
        }

        /// <summary>
        /// Fire the plugin loaded event
        /// </summary>
        /// <param name="component">The component that was loaded</param>
        /// <remarks>Will also cache the component if caching is turned on</remarks>
        private void OnPluginLoaded( object component )
        {
            if( PluginLoaded != null )
            {
                PluginLoaded( this, new PluginLoadedEventArgs( component ) );
            }
            if( _componentCache != null )
            {
                 _componentCache.Add( ((IPluginComponent)component).Name, component );
            }
        }
	}
}
