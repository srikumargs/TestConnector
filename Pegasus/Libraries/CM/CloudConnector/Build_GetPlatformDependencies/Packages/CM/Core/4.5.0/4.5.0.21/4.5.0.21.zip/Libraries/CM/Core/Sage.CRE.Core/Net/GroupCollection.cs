using System;
using System.Collections;
using System.DirectoryServices;


namespace Sage.Net
{
    /// <summary>
    /// Summary description for GroupCollection.
    /// </summary>
    public class GroupCollection
      : CollectionBase
      , IGroupCollection
    {

        /// <summary>
        /// ctor
        /// </summary>
        public GroupCollection()
            : base()
        {
        }

        /// <summary>
        /// Indexer into the group collection
        /// </summary>
        public IGroup this[int index]
        {
            get
            {
                return (IGroup)_collection[index];
            }
        }

        /// <summary>
        /// Populates the group collection
        /// </summary>
        public override void PopulateCollection()
        {
            _collection.Clear();

            try
            {
                DirectoryEntry de = new DirectoryEntry("WinNT://" + Domain);
                de.Children.SchemaFilter.Add("group");

                foreach (DirectoryEntry deIter in de.Children)
                {
                    _collection.Add(new Group(deIter.Name));
                }
            }
            catch (Exception ex)
            {
                throw new NetworkException("Error retrieving group list", ex);
            }
        }

    }
}
