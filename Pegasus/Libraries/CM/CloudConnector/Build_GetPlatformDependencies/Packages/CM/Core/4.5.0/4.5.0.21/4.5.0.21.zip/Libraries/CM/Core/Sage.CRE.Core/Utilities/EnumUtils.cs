using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Text;

namespace Sage.Utilities
{
    /// <summary>
    /// Utilities for use with Enums.
    /// To use this class decorate your enum with the DescriptionResxNamespaceAttribute and
    /// provide the namespace of the resx file containing the descriptions.
    /// </summary>
    /// <example>
    /// [DescriptionResxNamespaceAttribute("Sage.MyProject.Strings")]
    /// enum Color {
    ///     ForestGreen = 0,
    ///     BurntUmber,
    ///     NavyBlue
    /// }
    /// 
    /// In the same assembly as the enum above the following entries would appear in 
    /// the Strings.resx file:
    ///     Color_ForestGreen   "Forest Green"
    ///     Color_BurntUmber    "Burnt Umber"
    ///     Color_NavyBlue      "Navy Blue"
    /// The naming convention (if not obvious) is [EnumTypeName]_[EnumConstantName].
    /// Storing the descriptions in .resx files allows them to be internationalized.
    /// 
    /// The EnumUtils uses reflection and the namespace information in the 
    /// DescriptionResxNamespaceAttribute to retrieve the strings from the resx file.
    /// 
    /// The first time any information is requested a cache is built of the name and 
    /// description pairs.  This cache is then used for all subsequent lookups.
    /// 
    /// UnitTests/examples for using this class are at
    /// %SAGE_SANDBOX%\Libraries\STO\Libraries\Legacy\PSG\Core\Business\Sage.CRE.Logging\Sage.CRE.Logging.UnitTests\Test_EnumUtils.cs
    /// </example>
    /// <typeparam name="T">An enum</typeparam>
    sealed public class EnumUtils<T> where T : new()
    {
        /// <summary>
        /// Make constructor private, since all methods are static
        /// </summary>
        private EnumUtils()
        {
        }

        private static Boolean _cacheBuilt = false;
        // cache is Dictionary<enum name, resx description>
        private static Dictionary<String, String> _cacheNameToDesc = new Dictionary<string,string>();
        // cache is Dictionary<resx description, enum name>
        private static Dictionary<String, String> _cacheDescToName = new Dictionary<string,string>();

        // used throughout the class
        private static Type _t = typeof( T );
        
                                
        /// <summary>
        /// Builds the caches used for looking up descriptions
        /// </summary>
        private static void BuildCache()
        {
            if (!_cacheBuilt)
            {
                String[] names = Enum.GetNames(_t);
                foreach (String name in names)
                {
                    T enumValue = (T)Enum.Parse(_t, name);
                    String desc = InternalGetString(enumValue);
                    _cacheNameToDesc.Add(name, desc);
                    _cacheDescToName.Add(desc, name);
                }
            }
            _cacheBuilt = true;
        }

        /// <summary>
        /// Used by the cache to obtain the description of an enum.
        /// </summary>
        /// <param name="enumValue"></param>
        /// <returns></returns>
        private static string InternalGetString(T enumValue)
        {
            T t2 = new T();
            t2.GetType(); 
            Type t = enumValue.GetType();
            if (null != t)
            {
                object[] attrs = t.GetCustomAttributes(typeof(DescriptionResxNamespaceAttribute), true);
                if (attrs != null && attrs.Length > 0)
                {
                    String resxNamespace = ( (DescriptionResxNamespaceAttribute)attrs[0] ).ResxNamespace;
                    String resxName = String.Format( "{0}_{1}", t.Name, enumValue.ToString());
                    String retVal = ResourceHelpers.LoadStringFromResource( enumValue.GetType().Assembly, resxNamespace, resxName );
                    return retVal;
                }
            }
            return enumValue.ToString();
        }

        #region public methods
        /// <summary>
        /// Returns the string associated with this enum value.  The value is retrieved
        /// from the resx file specified on the Enum's DescriptionResxNamespaceAttribute.
        /// If there is no attribute on the enum, returns the Enum value name.
        /// </summary>
        /// <param name="enumValue"></param>
        /// <returns></returns>
        public static string GetString(T enumValue)
        {
            BuildCache();
            String desc;
            if (_cacheNameToDesc.TryGetValue(enumValue.ToString(), out desc))
            {
                return desc;
            }

            return enumValue.ToString();
        }

        /// <summary>
        /// Returns the EnumValue associated with the passed-in string. 
        /// The passed-in string can be either the Enum value name, or it's Resx description as
        /// specified using the DescriptionResxNamespaceAttribute.
        /// </summary>
        /// <param name="description"></param>
        /// <returns></returns>
        public static T GetEnum(string description)
        {
            BuildCache();
            // Look in the resx descriptions for a matching value
            // ensure the cache is built
            String enumName;
            if (_cacheDescToName.TryGetValue(description, out enumName))
            {
                return (T)Enum.Parse( _t, enumName, true );

            }

            // check for description being the enum name
            if( Enum.IsDefined( _t, description ) )
            {
                enumName = Enum.GetName( _t, description );
                return (T)Enum.Parse( _t, enumName, true );
            }

            // No match, return default value
            return default( T );
        }

        #endregion
    }
}
