using System;
using System.Runtime.InteropServices;

namespace PInvokeCore
{
    internal class Win32Error
    {
        #region Constructors
        /// <remarks>
        /// Private default constructor to prevent instantiation of static class.
        /// </remarks>
        private Win32Error()
        {}
        #endregion

        /// <summary>
        /// The handle is invalid.
        /// </summary>
        internal const uint ERROR_INVALID_HANDLE = 6;

        /// <summary>
        /// Cannot create a file when that file already exists.
        /// </summary>
        internal const uint ERROR_ALREADY_EXISTS = 183; 
    }


    // Use Naming Conventions to Indicate Risk (Chapter 8 � Code Access Security in Practice)
    // http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dnnetsec/html/THCMCh08.asp

    
    /// <summary>
    /// Safe.  This identifies code that poses no possible security threat.  It
    /// is harmless for any code, malicious or otherwise, to call.  An example is
    /// code that returns the current processor tick count.  Safe classes can be
    /// annotated with the SuppressUnmanagedCode attribute which turns off the
    /// code access security permission demand for full trust. 
    /// </summary>
    //[System.Security.SuppressUnmanagedCode]
    internal class SafeNativeMethods 
    {
        #region Constructors
        /// <remarks>
        /// Private default constructor to prevent instantiation of static class.
        /// </remarks>
        private SafeNativeMethods()
        {}
        #endregion
    }

    /// <summary>
    /// Native.  This is potentially dangerous unmanaged code, but code that is protected
    /// with a full stack walking demand for the unmanaged code permission.  These are
    /// implicitly made by the interop layer unless they have been suppressed with the
    /// SupressUnmanagedCode attribute. 
    /// </summary>
    internal class NativeMethods 
    {
        #region Constructors
        /// <remarks>
        /// Private default constructor to prevent instantiation of static class.
        /// </remarks>
        private NativeMethods()
        {}
        #endregion
    }


    /// <summary>
    /// Unsafe.  This is potentially dangerous unmanaged code that has the security demand
    /// for the unmanaged code permission declaratively suppressed.  These methods are
    /// potentially dangerous.  Any caller of these methods must do a full security review
    /// to ensure that the usage is safe and protected because no stack walk is performed. 
    /// </summary>
    [System.Security.SuppressUnmanagedCodeSecurityAttribute]
    internal class UnsafeNativeMethods 
    {
        #region Constructors
        /// <remarks>
        /// Private default constructor to prevent instantiation of static class.
        /// </remarks>
        private UnsafeNativeMethods()
        {}
        #endregion

        #region Internal members
        [DllImport("kernel32.dll", SetLastError=true)]
        internal static extern System.IntPtr CreateMutex(System.IntPtr lpMutexAttributes, [MarshalAs(UnmanagedType.Bool)] bool bInitialOwner, System.String lpName);

        [DllImport("kernel32.dll", SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool CloseHandle(System.IntPtr hObject);
        #endregion
    }
}
