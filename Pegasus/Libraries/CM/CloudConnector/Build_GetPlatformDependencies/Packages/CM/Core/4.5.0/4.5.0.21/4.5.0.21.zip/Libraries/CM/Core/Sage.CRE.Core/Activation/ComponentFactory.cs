using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using Sage.Activation;
using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Factory class for creating late bound components
    /// </summary>
    public static class ComponentFactory
    {
        #region Public Methods

        /// <summary>
        /// Create a late bound component
        /// </summary>
        /// <param name="activationInfo">Activation information for the component to create</param>
        /// <returns>The component created</returns>
        [SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter", Justification="The implicit type passed wouldn't be used within the method body and may actually make the interface more confusing")]
        public static T CreateComponent<T>(ComponentActivationInfo activationInfo) where T : class
        {
            ArgumentValidator.ValidateNonNullReference(activationInfo, "activationInfo", "");

            T component = default(T); 
            if (activationInfo.ActivationType == ComponentActivationType.Local)
            {
                component = TypeFactory.CreateDotNetComponent(activationInfo.AssemblyName, activationInfo.FullyQualifiedTypeName, activationInfo.CodeBase) as T;
            }
            else if (activationInfo.ActivationType == ComponentActivationType.Remote)
            {
                component = Activator.GetObject(typeof(T), activationInfo.Url.OriginalString) as T;
            }
            else
            {
                Assertions.Assert(activationInfo.ActivationType != ComponentActivationType.None);
                throw new InvalidTypeException();
            }
            return component;
        }

        /// <summary>
        /// Create a late bound component
        /// </summary>
        /// <param name="activationInfo">Activation information for the component to create</param>
        /// <param name="constructorArguments">Arguments that should be passed to the constructor</param>
        /// <returns>The component created</returns>
        [SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter", Justification = "The implicit type passed wouldn't be used within the method body and may actually make the interface more confusing")]
        public static T CreateLocalComponent<T>(ComponentActivationInfo activationInfo, object[] constructorArguments) where T : class
        {
            ArgumentValidator.ValidateNonNullReference(activationInfo, "activationInfo", "");
            Assertions.Assert(activationInfo.ActivationType == ComponentActivationType.Local);

            T component = default(T);
            if (activationInfo.ActivationType == ComponentActivationType.Local)
            {
                component = TypeFactory.CreateDotNetComponent(activationInfo.AssemblyName, activationInfo.FullyQualifiedTypeName, activationInfo.CodeBase, constructorArguments) as T;
            }
            else
            {
                throw new InvalidTypeException();
            }
            return component;
        }

        #endregion
    }
}
