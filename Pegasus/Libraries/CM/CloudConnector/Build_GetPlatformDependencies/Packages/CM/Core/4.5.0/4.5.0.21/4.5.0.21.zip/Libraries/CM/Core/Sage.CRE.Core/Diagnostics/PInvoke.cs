using System;
using System.Diagnostics;
using System.Text;
using System.Runtime.InteropServices;

namespace Sage.Diagnostics
{
    /// <summary>
    /// PInvoke signatures from WinUser space
    /// </summary>
    internal class WinUser
    {
        #region Constructors
        /// <remarks>
        /// Private default constructor to prevent instantiation of static class.
        /// </remarks>
        private WinUser()
        {}
        #endregion

        #region Public fields
        public const int UOI_FLAGS     = 1;
        public const int UOI_NAME      = 2;
        public const int UOI_TYPE      = 3;
        public const int UOI_USER_SID  = 4;

        public const int WSF_VISIBLE   = 1;
        #endregion

        #region Public types
        [StructLayout(LayoutKind.Sequential)]
            public struct USEROBJECTFLAGS 
        {
            [MarshalAs(UnmanagedType.Bool)]
            public Boolean fInherit;
            [MarshalAs(UnmanagedType.Bool)]
            public Boolean fReserved;
            public UInt32 dwFlags;
        }
        #endregion
    }

    /// <summary>
    /// PInvoke signatures from User32 space
    /// </summary>
    internal class User32
    {
        #region Constructors
        /// <remarks>
        /// Private default constructor to prevent instantiation of static class.
        /// </remarks>
        private User32()
        {}
        #endregion

        #region Public members
        [DllImport(USER32, SetLastError=true)]
        public static extern IntPtr GetProcessWindowStation();

        [DllImport(USER32, SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetUserObjectInformation
            (
            IntPtr hObj,
            int nIndex,
            IntPtr pvInfo,
            int nLength,
            out int lpnLengthNeeded
            );
        #endregion

        #region Private fields
        private const string USER32 = "user32.dll";
        #endregion
    }
}