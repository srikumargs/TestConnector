using System;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Sage.PInvoke
{
    /// <summary>
    /// Summary description for CGdi32.
    /// </summary>
    public static class Gdi32
    {
        public static int GetDIBits(IntPtr hdc, IntPtr hbmp, int uStartScan,
            int cScanLines, IntPtr lpvBits, IntPtr lpbmi, int uUsage)
        {
            return PInvoke.SafeNativeMethods.GetDIBits(hdc, hbmp, uStartScan,
                                                    cScanLines, lpvBits, lpbmi, uUsage);
        }

        /// <summary>
        /// CreateCompatibleDC
        /// </summary>
        public static IntPtr CreateCompatibleDC(
            IntPtr hdc)
        {
            return PInvoke.SafeNativeMethods.CreateCompatibleDC(hdc);
        }

        /// <summary>
        /// CreateDC
        /// </summary>
        public static IntPtr CreateDC(
            [MarshalAs(UnmanagedType.LPTStr)]string lpDriverName,
            IntPtr lpDeviceName,
            IntPtr lpOutput,
            IntPtr lpInitData)
        {
            return PInvoke.SafeNativeMethods.CreateDC(lpDriverName, lpDeviceName,
                                       lpOutput, lpInitData);
        }

        /// <summary>
        /// DeleteDC
        /// </summary>
        public static int DeleteDC(IntPtr hdc)
        {
            return PInvoke.SafeNativeMethods.DeleteDC(hdc);
        }

        public static bool DeleteObject(IntPtr hObject)
        {
            return PInvoke.SafeNativeMethods.DeleteObject(hObject);
        }
    }
}
