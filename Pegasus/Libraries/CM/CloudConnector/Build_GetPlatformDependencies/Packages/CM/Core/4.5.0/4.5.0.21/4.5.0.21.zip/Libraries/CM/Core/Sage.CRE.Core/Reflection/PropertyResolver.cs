using System;
using System.Reflection;
using System.Runtime.InteropServices;
using Sage.Diagnostics;

namespace Sage.Reflection
{
	/// <summary>
	/// Set/Get property values by name on managed objects
	/// </summary>
	[ ComVisible( false ) ]
	public class PropertyResolver: IPropertyResolver, INamedProperty
	{
        // A flag indicating if private properties should be exposed
        private bool _exposePrivateProperties = false;

        // The type instance to resolve properties on
        private object _typeInstance = null;

        /// <summary>
        /// Constructor
        /// </summary>
		public PropertyResolver()
		{
			
		}

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="typeInstance">The type instance to resolve properties on</param>
        public PropertyResolver( object typeInstance )
        {
            ValidateTypeInstanceArgument( typeInstance );
            _typeInstance = typeInstance;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="typeInstance">The type instance to resolve properties on</param>
        /// <param name="exposePrivateProperties">A flag indicating if private properties should be exposed</param>
        public PropertyResolver( object typeInstance, bool exposePrivateProperties )
        {
            ValidateTypeInstanceArgument( typeInstance );
            _typeInstance = typeInstance;
            _exposePrivateProperties = exposePrivateProperties;
        }

        /// <summary>
        /// Set the type instance to resolve properties on
        /// </summary>
        public object TypeInstance
        { 
            set
            { 
                ValidateTypeInstanceArgument( value );
                _typeInstance = value; 
            }
        }

        /// <summary>
        /// Set/Get a flag indicating if private properties should be exposed.
        /// </summary>
        /// <remarks>The default value of the property is false</remarks>
        public bool ExposePrivateProperties
        { 
            set{ _exposePrivateProperties = value; }
            get{ return _exposePrivateProperties; } 
        }

        /// <summary>
        /// set a given property value by name
        /// </summary>
        /// <param name="propName">the string property name</param>
        /// <param name="val">the actual value</param>
        public void SetPropertyValue(string propName, object val)
        {
            InsureValidTypeInstance();
            PropertyInfo propinfo = _typeInstance.GetType().GetProperty( propName, ResolverBindingFlags );
            if( propinfo == null )
            {
                string errorMessage = string.Format( Strings.NoAvailableOnFormat, propName, _typeInstance.GetType().Name );
                EventLogger.WriteMessage( "PropertyResolver", errorMessage, MessageType.Error );
                throw new ArgumentException( errorMessage, propName );
            }
            propinfo.SetValue( _typeInstance, val, null );
        }

        /// <summary>
        /// get the given property value
        /// </summary>
        /// <param name="propName">the string property name</param>
        /// <returns>the value as object</returns>
        public object GetPropertyValue(string propName)
        {
            InsureValidTypeInstance();
            PropertyInfo propinfo = _typeInstance.GetType().GetProperty( propName, ResolverBindingFlags );
            if( propinfo == null )
            {
                string errorMessage = string.Format( Strings.NoAvailableOnFormat, propName, _typeInstance.GetType().Name );
                EventLogger.WriteMessage( "PropertyResolver", errorMessage, MessageType.Error );
                throw new ArgumentException( errorMessage, propName );
            }
            return propinfo.GetValue(_typeInstance, null);
        }

        /// <summary>
        /// Is the given property implemented on the object
        /// </summary>
        /// <param name="propName">the string property name</param>
        /// <returns>true if exists</returns>
        public bool HasProperty(string propName)
        {
            InsureValidTypeInstance();
            PropertyInfo propinfo = _typeInstance.GetType().GetProperty( propName, ResolverBindingFlags );
            return propinfo != null;
        }

        /// <summary>
        /// Validate a typeInstance argument
        /// </summary>
        /// <param name="typeInstance">The argument to validate</param>
        private void ValidateTypeInstanceArgument( object typeInstance )
        {
            ArgumentValidator.ValidateNonNullReference( typeInstance, "typeInstance", "PropertyResolver" );
        }

        /// <summary>
        /// Make sure we have a valid type instance.
        /// </summary>
        private void InsureValidTypeInstance()
        {
            if( _typeInstance == null )
            {
                string errorMessage = Strings.PropertyResolverCannotPerformOperationsOnNull;
                EventLogger.WriteMessage( "PropertyResolver", errorMessage, MessageType.Error );
                throw new InvalidOperationException( errorMessage );
            }
        }

        /// <summary>
        /// Retrieve the resolvers current binding flags
        /// </summary>
        private BindingFlags ResolverBindingFlags
        {
            get
            {
                BindingFlags flags = BindingFlags.GetProperty | BindingFlags.Instance | BindingFlags.Public;
                if( _exposePrivateProperties )
                {
                    flags |= BindingFlags.NonPublic;
                }
                return flags;
            }
        }
    
	}
}
