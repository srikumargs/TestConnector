using System;
using System.ComponentModel;




namespace TraceConfigTool
{
    /// <summary>
    /// Summary description for PleaseWaitForm.
    /// </summary>
    internal sealed class PleaseWaitForm : System.Windows.Forms.Form
    {
        #region Constructors
        public PleaseWaitForm()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();
        }
        #endregion


        public string LabelText
        {
            get
            {
                return _label.Text;
            }

            set
            {
                _label.Text = value;
            }
        }

        #region Protected methods
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if(disposing)
            {
                if(null != components)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }




        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        protected override void OnClosing(CancelEventArgs args)
        {
            // Prevent the user from being able to close the window
            args.Cancel = true;

            //base.OnClosing(e);
        }
        #endregion



        #region Private fields
        private System.Windows.Forms.Label _label;
        private InfiniteProgress _infiniteProgress;
        private System.ComponentModel.Container components = null; // Required designer variable.
        #endregion



        #region Private methods
        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._label = new System.Windows.Forms.Label();
            this._infiniteProgress = new TraceConfigTool.InfiniteProgress();
            this.SuspendLayout();
            // 
            // _label
            // 
            this._label.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._label.Location = new System.Drawing.Point(7, 7);
            this._label.Name = "_label";
            this._label.Size = new System.Drawing.Size(346, 21);
            this._label.TabIndex = 0;
            this._label.Text = "Program is busy ... please wait.";
            // 
            // _infiniteProgress
            // 
            this._infiniteProgress.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this._infiniteProgress.EndColor = System.Drawing.Color.Blue;
            this._infiniteProgress.Location = new System.Drawing.Point(13, 40);
            this._infiniteProgress.Name = "_infiniteProgress";
            this._infiniteProgress.Position = -59F;
            this._infiniteProgress.Size = new System.Drawing.Size(334, 7);
            this._infiniteProgress.StartColor = System.Drawing.Color.White;
            this._infiniteProgress.Step = 5F;
            this._infiniteProgress.TabIndex = 1;
            // 
            // PleaseWaitForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(360, 64);
            this.ControlBox = false;
            this.Controls.Add(this._infiniteProgress);
            this.Controls.Add(this._label);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PleaseWaitForm";
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.ResumeLayout(false);

        }
        #endregion
        #endregion
    }
}