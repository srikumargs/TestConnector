namespace TraceConfigTool
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this._traceConfigControl = new TraceConfigTool.TraceConfigControl();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 669);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(492, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // _traceConfigControl
            // 
            this._traceConfigControl.AutoSize = true;
            this._traceConfigControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this._traceConfigControl.Location = new System.Drawing.Point(0, 0);
            this._traceConfigControl.Margin = new System.Windows.Forms.Padding(2);
            this._traceConfigControl.Name = "_traceConfigControl";
            this._traceConfigControl.Size = new System.Drawing.Size(492, 669);
            this._traceConfigControl.TabIndex = 3;
            this._traceConfigControl.DataStateChanged += new System.EventHandler(this._traceConfigControl_DataStateChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(492, 691);
            this.Controls.Add(this._traceConfigControl);
            this.Controls.Add(this.statusStrip1);
            this.Icon = ((System.Drawing.Icon) (resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(500, 725);
            this.Name = "MainForm";
            this.Text = "Trace Configuration Tool";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TraceConfigControl _traceConfigControl;
        private System.Windows.Forms.StatusStrip statusStrip1;
    }
}

