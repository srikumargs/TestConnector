using System;
using System.Reflection;
using System.Collections;
using System.Globalization;

using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Factory class used to cache MethodInfo instances.  Class used by ProxyFactory so that dynamically
    /// created proxy instances (via Reflection.Emit) can easily pass the correct MethodInfo to the
    /// IInvocationHandler.
    /// </summary>
    public static class MethodInfoCache
    {
        #region Public methods
        ///<summary>
        /// Add a new MethodInfo instances to the cache
        ///</summary>
        ///<param name="methodInfo">MethodInfo to cache</param>
        ///<returns>The string key that can be used to lookup the cached MethodInfo later via a call to GetMethodInfo</returns>
        public static string AddMethodInfo(MethodInfo methodInfo)
        {
            ArgumentValidator.ValidateNonNullReference(methodInfo, "methodInfo", _myTypeName + ".AddMethodInfo");

            string result = GetMethodInfoKey(methodInfo);

            lock(_methodInfoMap.SyncRoot)
            {
                if(!_methodInfoMap.ContainsKey(result))
                {
                    _methodInfoMap.Add(result, methodInfo);
                }
            }

            return result;
        }

        ///<summary>
        /// Returns the MethodInfo previously cached.
        ///</summary>
        ///<param name="methodInfoKey">the key for the cached MethodInfo (returned by AddMethodInfo)</param>
        ///<returns>the MethodInfo for the specified key</returns>
        public static MethodInfo GetMethodInfo(string methodInfoKey)
        {
            ArgumentValidator.ValidateNonEmptyString(methodInfoKey, "methodInfoKey", _myTypeName + ".GetMethodInfo");

            MethodInfo methodInfo = null;
            lock(_methodInfoMap.SyncRoot)
            {
                methodInfo = (MethodInfo) _methodInfoMap[methodInfoKey];
            }

            ArgumentValidator.ValidateNonNullReference(methodInfo, "methodInfo", _myTypeName + ".GetMethodInfo");

            return methodInfo;
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Creates a unique key for a method represented by the passed in methodInfo
        /// </summary>
        /// <param name="methodInfo">the MethodInfo for which the key should be created</param>
        /// <returns>the string key used by the cache</returns>
        private static string GetMethodInfoKey(MethodInfo methodInfo)
        {
            ArgumentValidator.ValidateNonNullReference(methodInfo, "methodInfo", _myTypeName + ".GetMethodInfoKey");
            return string.Format(CultureInfo.InvariantCulture, "{0}:{1}", methodInfo.ReflectedType.ToString(), methodInfo.ToString());
        }
        #endregion

        #region Private fields
        private static Hashtable _methodInfoMap = new Hashtable();
        private static String _myTypeName = typeof(MethodInfoCache).FullName;
        #endregion
    }
}
