using System;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

using Microsoft.Win32;

namespace Sage.Diagnostics
{
	/// <summary>
	/// Write messages to the Event log
	/// </summary>
    [ComVisible(false)]
    [TraceListenerIgnoreTypeAttribute]
    public class EventLogger: IEventLogger
	{
        /// <summary>
        /// The custom log name for this class.
        /// </summary>
        public const string LogName = "Sage";
        /// <summary>Used to get Windows event log information on the local machine.</summary>
        public const string LocalMachine = ".";
        /// <summary>Used to write events to the Application log in Windows event viewer.</summary>
        public const string AppLogName = "Application";
        /// <summary>Used to write events to the Application log in Windows event viewer.</summary>
        public const string AppSourceName = "Application Error";
        /// <summary>Used to write events to the Sage.Diagnostics.Exception source in Windows event viewer.</summary>
        public const string DefaultSourceExceptionName = "Sage.Diagnostics.Exception";
        /// <summary>Used to write events to the Sage.Diagnostics source in Windows event viewer.</summary>
        public const string DefaultSourceName = "Sage.Diagnostics";

            
        /// <summary>
        /// Constructor
        /// </summary>
		public EventLogger()
		{}

        #region IEventLogger

        /// <summary>
        /// Write a message in the Event Log
        /// </summary>
        /// <param name="source">The source of the messsage</param>
        /// <param name="message">The message text</param>
        /// <param name="type">The type of the message</param>
        void IEventLogger.WriteMessage(string source, string message, MessageType type)
        {
            WriteMessage(source, message, type);
        }

        #endregion

        /// <summary>
        /// Write a message in the Event Log
        /// </summary>
        /// <param name="source">The source of the messsage</param>
        /// <param name="message">The message text</param>
        /// <param name="type">The type of the message</param>
        public static void WriteMessage(string source, string message, MessageType type)
        {
            WriteMessage(source, message, type, true);
        }

        /// <summary>
        /// Write a message in the Event Log
        /// </summary>
        /// <param name="source">The source of the messsage</param>
        /// <param name="message">The message text</param>
        /// <param name="type">The type of the message</param>
        /// <param name="trace">Whether or not the message should be written to trace output as well</param>
        public static void WriteMessage(string source, string message, MessageType type, bool trace)
        {
            string logNameToUse = LogName;
            try
            {
                //Check to see if the source exists
                source = FormatEventLogSource(source);  // The source part of the message source cannot contain a '.' ... if it does, then the event won't get written.
                if (!EventLogger.EventLogSourceExists(logNameToUse, source))
                {
                    //now check to see if the default sage source name exists (Sage Diagnostics)
                    source = FormatEventLogSource(DefaultSourceName);
                    if (EventLogger.EventLogSourceExists(logNameToUse, source))
                    {
                        string logForSource = EventLog.LogNameFromSourceName(source, LocalMachine);
                        logNameToUse = logForSource;
                    }
                    else
                    {
                        Debug.WriteLine(String.Format(Strings.EventLogSourceDoesNotExist, source));

                        //Finally let's write the event to the Application -> Application Error source
                        source = FormatEventLogSource(AppSourceName);
                        logNameToUse = AppLogName;
                    }
                }
                else
                {
                    string logForSource = EventLog.LogNameFromSourceName(source, LocalMachine);
                    logNameToUse = logForSource;
                }

                // and finally, write the message to our custom log.
                using (EventLog customLog = new EventLog(logNameToUse, LocalMachine, source))
                {
                    // set the overflow property [512496]
                    // Doesn't work on Vista - Commenting out for now.
                    //SetOverflowPolicy(bEventLogCreated, logNameToUse, customLog);

                    if(trace)
                    {
                        switch(type)
                        {
                            case MessageType.Error:
                                ErrorTrace.WriteLine(null, message);
                                break;
                            case MessageType.Warning:
                                WarningTrace.WriteLine(null, message);
                                break;
                            case MessageType.Information:
                                InfoTrace.WriteLine(null, message);
                                break;
                            default:
                                VerboseTrace.WriteLine(null, message);
                                break;
                        }
                    }
                    if (message.Length >= 32766) message = message.Substring(0, 32765);
                    customLog.WriteEntry(message, GetEventLogType(type));
                }
                
            }
            catch (Exception e)
            {
                string errMsg = string.Format(Thread.CurrentThread.CurrentCulture, Strings.ErrorWritingToCustomEventLogFormat, logNameToUse, e.Message, message);
                Debug.WriteLine(errMsg);
                Debug.WriteLine(e.Message);
                try
                {
                    using (EventLog appLog = new EventLog(AppLogName, LocalMachine, AppSourceName))
                    {
                        if(trace)
                        {
                            ErrorTrace.WriteLine(null, errMsg);
                        }
                        appLog.WriteEntry(errMsg, EventLogEntryType.Error);
                    }
                }
                catch( Exception ) {}
            }
        }


        /// <summary>
        /// A helper method to set preferential default of 'overwrite' as needed
        /// if the event log size exceed maximum size.
        /// </summary>
        /// <param name="bForceOverwrite"></param>
        /// <param name="sLogName"></param>
        public static void SetOverflowPolicy(bool bForceOverwrite, string sLogName)
        {
            try
            {
                if (!bForceOverwrite)
                {
                    // Determine if there are user specifications before clobbering
                    RegistryKey rk = Registry.LocalMachine.OpenSubKey(string.Format("SYSTEM\\CurrentControlSet\\Services\\EventLog\\{0}", sLogName));
                    if (null != rk)
                    {
                        if (null != rk.GetValue("Retention"))
                        {
                            // Registry value found, leave as is...
                            return;
                        }
                    }
                }

                EventLog customLog = new EventLog(sLogName, LocalMachine);
                customLog.ModifyOverflowPolicy(OverflowAction.OverwriteAsNeeded, customLog.MinimumRetentionDays);
            }
            catch
            {
                // Swallow all exceptions, this is a 'nice-to-do' setting
            }
        }

        /// <summary>
        /// A helper method providing a standardized method of logging an exception in the event log.
        /// </summary>
        /// <param name="ex">The exception to log.</param>
        public static void LogException(Exception ex)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat(Strings.ExLogHeaderFormat, Environment.NewLine);
                Exception exLog = ex;
                while (exLog != null)
                {
                    //Log the source of the exception
                    string source = exLog.Source;
                    if (source == null || source == string.Empty)
                    {
                        source = exLog.GetType().Name;
                    }
                    sb.AppendFormat(Strings.ExLogMessageFormat, Environment.NewLine, source, exLog.Message);

                    // If we are called from an exception constructor, the stack trace will be empty.
                    // Stack traces are populated by the actual throw of an exception.
                    if (exLog.StackTrace != null && exLog.StackTrace != string.Empty)
                    {
                        sb.AppendFormat(Strings.ExLogTraceFormat, Environment.NewLine, exLog.StackTrace);
                    }
                    else
                    {
                        sb.Append(Environment.NewLine);
                    }
                    if (!(exLog.InnerException is LoggingBaseException))
                    {
                        exLog = exLog.InnerException;
                    }
                    else
                    {
                        exLog = null;
                    }
                }
                WriteMessage(DefaultSourceExceptionName, sb.ToString(), MessageType.Error);
            }
            catch
            {}
        }

        /// <summary>
        /// Check to see if the event log source exists.  In Windows Vista,
        /// if the source does not exist AND you are not running elevated,
        /// an exception is thrown.  We will eat that exception and return
        /// false.
        /// </summary>
        /// <param name="sLogName">The Log name to look for.  Typically 'Sage'.</param>
        /// <param name="source">The source to look for.  It gets altered.</param>
        /// <returns></returns>
        public static bool EventLogSourceExists(string sLogName, string source)
        {
            bool returnVal = false;
            try
            {
                source = FormatEventLogSource(source);
                if (EventLog.Exists(sLogName) && EventLog.SourceExists(source))
                {
                    returnVal = true;
                }
            }
            catch
            {
                returnVal = false;
            }
            
            return returnVal;
        }

        /// <summary>
        /// This method requires elevated privileges on Windows Vista in order
        /// to work.  It won't fail.
        /// </summary>
        /// <param name="sLogName"></param>
        /// <param name="source"></param>
        public static void CreateEventLogSource(string sLogName, string source)
        {
            try
            {
                source = FormatEventLogSource(source);
                if (EventLogger.EventLogSourceExists(sLogName, source))
                {
                    string logForSource = EventLog.LogNameFromSourceName(source, LocalMachine);
                    if (logForSource != LogName)
                        // Ensure that source is registered to the correct log...
                        EventLog.DeleteEventSource(source);
                    else
                        return;
                }

                EventLog.CreateEventSource(source, sLogName);
            }
            catch { }
        }

        /// <summary>
        /// Returns the log name (usually 'Sage' or 'Application') where the source exists
        /// </summary>
        /// <param name="source">source name to look for.</param>
        /// <returns></returns>
        public static string LogNameFromSourceName(string source)
        {
            source = FormatEventLogSource(source);
            return EventLog.LogNameFromSourceName(source, LocalMachine);
        }

        /// <summary>
        /// Format the event log source.  It cannot contain periods.
        /// 
        /// I don't know what the event view has against periods, I mean
        /// what if I really want a period.  Why don't we just remove periods 
        /// from the English language.  Instead of a period, we'll end the sentence with
        /// a space, kind of like what this function does.  That's pretty messed
        /// up don't you think?  I mean if we replaced all periods with a space,
        /// it would be much harder to differentiate the beginning of a sentence
        /// with the end of a sentence.  That is precisely what this function does...
        /// Go Figure!
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        private static string FormatEventLogSource(string source)
        {
            return string.Format("{0}", source.Replace('.', ' '));
        }

        #region Private methods
        /// <summary>
        /// Retrieve the Windows Event log type for the message type
        /// </summary>
        /// <param name="type">The message type</param>
        /// <returns>The Windows event log type for the provided message type</returns>
        private static EventLogEntryType GetEventLogType(MessageType type)
        {
            EventLogEntryType retval = EventLogEntryType.Error;
            switch (type)
            {
                case MessageType.Information:
                    retval = EventLogEntryType.Information;
                    break;
                case MessageType.Warning:
                    retval = EventLogEntryType.Warning;
                    break;
            }
            return retval;
        }
        #endregion
    }
}
