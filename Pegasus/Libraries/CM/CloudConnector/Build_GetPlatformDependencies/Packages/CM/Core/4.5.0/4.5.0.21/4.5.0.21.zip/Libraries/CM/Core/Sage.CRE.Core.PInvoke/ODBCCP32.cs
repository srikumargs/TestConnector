using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Sage.PInvoke
{
    /// <summary>
    /// Defines ODBC P/Invoke API declarations.
    /// </summary>
    public class ODBCCP32
    {
        /// <summary>
        /// Configure an ODBC data source.
        /// </summary>
        /// <param name="hwndParent">The parent HWND pointer.</param>
        /// <param name="requestFlags">The data source request flags.</param>
        /// <param name="driver">The driver string.</param>
        /// <param name="attributes">The attributes string.</param>
        /// <returns>Returns true if the data source is successfully configured; otherwise, false.</returns>
        public static bool SQLConfigDataSource(IntPtr hwndParent, RequestFlags requestFlags, string driver, string attributes)
        {
            return NativeMethods.SQLConfigDataSource(hwndParent, requestFlags, driver, attributes);
        }
    }
}
