﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Waf.BookLibrary.Library.Applications")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Waf Book Library")]


[assembly: Guid("5702694f-eea6-4f35-a8e9-42c8dc1eaf6d")]


[assembly: InternalsVisibleTo("Waf.BookLibrary.Library.Applications.Test")]