using System;

namespace Sage.Net
{
    internal abstract class NameBase
    {
        public NameBase(string name)
        {
            m_strName = name;
        }
        private string m_strName = null;
        public string Name
        {
            get { return m_strName; }
            //set { m_strName = value; }
        }
    }


    /// <summary>
    /// Summary description for Server.
    /// </summary>
    internal class Server
      : NameBase
      , IServer
    {
        public Server(string name)
            : base(name)
        {
            //
            // TODO: Add constructor logic here
            //
        }

    }
}
