using System;
using System.Text.RegularExpressions;
using System.Text;

namespace Sage.Xml
{
    /// <summary>
    /// This class is a light weight Xml fragment parser.
    /// </summary>
    public class XmlElementFinder
	{
        private string _xml;

        /// <summary>
        /// Return the first XML frag that has the specified element name
        /// </summary>
        /// <param name="xml">well formed xml frag</param>
        /// <param name="elementName"></param>
        /// <returns></returns>
        public static string OuterText(string xml, string elementName)
        {
            XmlElementFinder f = new XmlElementFinder(xml);
            return f.OuterText(elementName);
        }

        /// <summary>
        /// Return the first XML inner fragment
        /// </summary>
        /// <param name="xml">well formed xml frag</param>
        /// <param name="elementName"></param>
        /// <returns></returns>
        public static string InnerText(string xml, string elementName)
        {
            XmlElementFinder f = new XmlElementFinder(xml);
            return f.InnerText(elementName);
        }

        /// <summary>
        /// Does the element name exist?
        /// </summary>
        /// <param name="xml">well formed xml frag</param>
        /// <param name="elementName"></param>
        /// <returns></returns>
        public static bool ElementExists(string xml, string elementName)
        {
            XmlElementFinder f = new XmlElementFinder(xml);
            return f.ElementExists(elementName);
        }
        
        /// <summary>
        /// Ctor takes the XML to parse
        /// </summary>
        /// <param name="inputXml">well-formed XML frag</param>
        public XmlElementFinder(string inputXml)
        {
            _xml = inputXml;
        }

        /// <summary>
        /// Or set the Xml to parse via this property
        /// </summary>
        public string InputXml
        {
            set { _xml = value; }
        }

        /// <summary>
        /// Return the first XML frag that has the specified element name
        /// </summary>
        /// <param name="elementName">element name w/out angle brackets</param>
        /// <returns>well-formed XML including element name</returns>
        public string OuterText(string elementName)
        {
            bool bFoundMatch;
            string parse = parseElement(elementName, out bFoundMatch);
            if (bFoundMatch == true)
            {
                StringBuilder b = new StringBuilder();
                b.AppendFormat("<{0}>{1}</{0}>", elementName, parse); 
                parse = b.ToString();
            }
            return parse;
        }

        /// <summary>
        /// Return the first XML inner fragment
        /// </summary>
        /// <param name="elementName">element name w/out angle brackets</param>
        /// <returns>Xml fragment that is a subtree of first element</returns>
        public string InnerText(string elementName)
        {
            bool bFoundMatch;
            return parseElement(elementName, out bFoundMatch);
        }

        /// <summary>
        /// Does the element name exist?
        /// </summary>
        /// <param name="elementName">element name w/out angle brackets</param>
        /// <returns>whether the element exists</returns>
        public bool ElementExists(string elementName)
        {
            bool bFoundMatch;
            parseElement(elementName, out bFoundMatch);
            return bFoundMatch;
        }
        
        /// <summary>
        /// The worker method
        /// </summary>
        /// <param name="elementName">the name of the element</param>
        /// <param name="bFoundMatch">whether found or not</param>
        /// <returns></returns>
        private string parseElement(string elementName, out bool bFoundMatch)
        {
            StringBuilder openTag  = new StringBuilder();
            StringBuilder closeTag = new StringBuilder();
            StringBuilder expr     = new StringBuilder();

            openTag.AppendFormat(@"<{0}>", elementName);
            closeTag.AppendFormat(@"</{0}>", elementName);
            expr.AppendFormat(@"<{0}>.*</{0}>", elementName);

            // Get everything including the tags
            Regex r = new Regex(expr.ToString());

            string retval = String.Empty;
            bFoundMatch = r.IsMatch(_xml);
            if (bFoundMatch == true)
            {
                // If matched, return the stuff between the tags
                Match m = r.Match(_xml);
                r = new Regex(openTag.ToString());
                string s = r.Split(m.Value)[1];
                r = new Regex(closeTag.ToString());
                retval = r.Split(s)[0];
            }
            else
            {
                StringBuilder expr2 = new StringBuilder();
                expr2.AppendFormat(@"<{0}.*/>", elementName);
                r = new Regex(expr2.ToString());
                bFoundMatch = r.IsMatch(_xml);
            }
            return retval;
        }
	}
}
