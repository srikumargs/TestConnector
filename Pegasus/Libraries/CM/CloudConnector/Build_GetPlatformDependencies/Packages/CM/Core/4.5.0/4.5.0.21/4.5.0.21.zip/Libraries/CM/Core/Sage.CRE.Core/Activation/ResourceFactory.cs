using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Reflection;
using System.IO;
using Sage.Configuration;
using System.Resources;

namespace Sage.Activation
{
    /// <summary>
    /// Static class with static methods that provide resource objects
    /// to the caller given all the needed information for the resource.
    /// If you don't find the method which return resource type you are
    /// looking for you can add it here.
    /// </summary>
    public static class ResourceFactory
    {
        /// <summary>
        /// Gets the image object from an embedded image resource
        /// </summary>
        /// <param name="asmName"> name of the assembly in which resource resides</param>
        /// <param name="asmPath"> path of the assembly </param>
        /// <param name="resourceName"> 
        /// full name of the resource file along with extension. 
        /// You can find this out using the reflector utility
        /// <example>
        /// If you have included an image file "sample.bmp" in your project Sage.MyApplication
        /// and added it as Embedded resource, the full resource name for this will be 
        /// 'Sage.MyApplication.sample.bmp'
        /// Usage :
        /// ResourceFactory.GetEmbeddedBitmap([all the right parameter values])
        /// </example>
        /// </param>
        /// <returns></returns>
        public static Image GetEmbeddedBitmap(string asmName, string asmPath, string resourceName)
        {
            Image img = SystemIcons.Application.ToBitmap();
            Assembly asm = Assembly.LoadFile(Path.Combine(PathRegistrar.ResolveUrl(asmPath), asmName));
            Stream stream = asm.GetManifestResourceStream(resourceName);
            if ( stream != null )
            {
                img = Image.FromStream(stream);
            }
            return img;
        }

        /// <summary>
        /// Get the image object given all the raw information
        /// for the resource that is included inside a resource file
        /// </summary>
        /// <param name="asmName"> name of the assembly in which resource resides</param>
        /// <param name="asmPath"> path of the assembly </param>
        /// <param name="basename">
        /// Base of the namespace where you want resource manager to search for
        /// the give resource
        /// <example>
        /// If your resource file is in the Sage.Windows.Forms.Properties or 
        /// Sage.Windows.Forms.Internal namespace 
        /// your base namespace can be Sage.Windows.Forms or Sage.Windows or just Sage
        /// </example>
        /// </param>
        /// <param name="resourceName">
        /// Just name of the image resource as it appears in the resource(.resx) file
        /// </param>
        /// <returns></returns>
        public static Image GetResourceBitmap(string asmName, string asmPath, string basename, string resourceName)
        {
            Image img = SystemIcons.Application.ToBitmap();
            Assembly asm = Assembly.LoadFile(Path.Combine(PathRegistrar.ResolveUrl(asmPath), asmName));
            ResourceManager res = new ResourceManager(basename, asm);
            object obj = res.GetObject(resourceName);
            if (obj != null)
            {
                img = obj as Image;
            }
            return img;
        }
    }
}
