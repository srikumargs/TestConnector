using System;
using System.Collections;
using System.DirectoryServices;


namespace Sage.Net
{
    /// <summary>
    /// Summary description for UserCollection.
    /// </summary>
    public class UserCollection
      : CollectionBase
      , IUserCollection
    {

        /// <summary>
        /// ctor
        /// </summary>
        public UserCollection()
            : base()
        {
        }

        /// <summary>
        /// Indexer into the user collection
        /// </summary>
        public IUser this[int index]
        {
            get
            {
                return (IUser)_collection[index];
            }
        }

        /// <summary>
        /// Populates the user collection
        /// </summary>
        public override void PopulateCollection()
        {
            _collection.Clear();

            try
            {
                DirectoryEntry de = new DirectoryEntry("WinNT://" + Domain);
                de.Children.SchemaFilter.Add("user");

                foreach (DirectoryEntry deIter in de.Children)
                {
                    _collection.Add(new User(deIter.Name));
                }
            }
            catch (Exception ex)
            {
                throw new NetworkException(Strings.UserListError, ex);
            }
        }

    }
}
