using System;
using System.Collections;
using System.Runtime.InteropServices;

namespace Sage.Net
{
    // Interfaces for defining network information such as
    // Domains, servers, groups and users.
    // Interface "hierarchy":
    // - INetworkInfo          - overall interface
    //    - IDomainCollection  - collection of domains
    //       - IDomain         - an individual domain on the network
    //    - IServerCollection  - collection of servers
    //       - IServer         - an individual server on the network
    //    - IGroupCollection   - collection of groups
    //       - IGroup          - an individual group on the network
    //    - IUserCollection    - collection of users
    //       - ICollection     - an individual user on the network
    //
    // - IServerValidation  - validates that a server name actually exists on the network


    /// <summary>
    /// Network information interface
    /// </summary>
    public interface INetworkInfo
    {
        /// <summary>
        /// Gets a collection of servers
        /// </summary>
        IServerCollection Servers { get; }

        /// <summary>
        /// Gets a collection of domains
        /// </summary>
        IDomainCollection Domains { get; }

        /// <summary>
        /// Gets a collection of groups
        /// </summary>
        IGroupCollection Groups { get; }

        /// <summary>
        /// Gets a collection of users
        /// </summary>
        IUserCollection Users { get; }
    }

    #region IDomainCollection information

    /// <summary>
    /// A collection of network domains
    /// </summary>
    public interface IDomainCollection
    {
        /// <summary>
        /// Get an enumerator for the collection
        /// </summary>
        IEnumerator GetEnumerator();
        /// <summary>
        /// Return the number of items in the collection
        /// </summary>
        int Count { get; }
        /// <summary>
        /// Indexer into the collection
        /// </summary>
        IDomain this[int i] { get; }

        /// <summary>
        /// Populate the list
        /// </summary>
        void Populate();
    }

    /// <summary>
    /// Represents an individual domain in the domain collection
    /// </summary>
    public interface IDomain
    {
        /// <summary>
        /// Returns the name of the domain
        /// </summary>
        string Name { get; }
    }

    #endregion

    #region IServerCollection information

    /// <summary>
    /// A collection of network servers
    /// </summary>
    public interface IServerCollection
    {
        /// <summary>
        /// Get an enumerator for the collection
        /// </summary>
        IEnumerator GetEnumerator();
        /// <summary>
        /// Get the number of items in the collection
        /// </summary>
        int Count { get; }
        /// <summary>
        /// Indexer into the collection
        /// </summary>
        IServer this[int i] { get; }

        /// <summary>
        /// Populate the list using the default (current user's) domain
        /// </summary>
        void Populate();

        /// <summary>
        /// Populate the list using the specified domain
        /// </summary>
        /// <param name="domain"></param>
        void Populate(string domain);
    }

    /// <summary>
    /// Represents an individual server in the server collection
    /// </summary>
    public interface IServer
    {
        /// <summary>
        /// Returns the name of the server
        /// </summary>
        string Name { get; }
    }

    #endregion

    #region IGroupCollection information

    /// <summary>
    /// A collection of groups on a network
    /// </summary>
    public interface IGroupCollection
    {
        /// <summary>
        /// Get an enumerator for the collection
        /// </summary>
        IEnumerator GetEnumerator();
        /// <summary>
        /// Get the number of items in the collection
        /// </summary>
        int Count { get; }
        /// <summary>
        /// Indexer into the collection
        /// </summary>
        IGroup this[int i] { get; }

        /// <summary>
        /// Populate the list using the default (current user's) domain
        /// </summary>
        void Populate();

        /// <summary>
        /// Populate the list using the specified domain
        /// </summary>
        /// <param name="domain"></param>
        void Populate(string domain);
    }

    /// <summary>
    /// Represents an individual group in the collection
    /// </summary>
    public interface IGroup
    {
        /// <summary>
        /// Returns the group name
        /// </summary>
        string Name { get; }
    }

    #endregion

    #region IUserCollection information

    /// <summary>
    /// A collection of users on a network
    /// </summary>
    public interface IUserCollection
    {
        /// <summary>
        /// Get an enumerator for the collection
        /// </summary>
        IEnumerator GetEnumerator();
        /// <summary>
        /// Get the number of items in the collection
        /// </summary>
        int Count { get; }
        /// <summary>
        /// Indexer into the collection
        /// </summary>
        IUser this[int i] { get; }

        /// <summary>
        /// Populate the list using the default (current user's) domain
        /// </summary>
        void Populate();

        /// <summary>
        /// Populate the list using the specified domain
        /// </summary>
        /// <param name="domain"></param>
        void Populate(string domain);
    }

    /// <summary>
    /// Represents an individual user in the user collection
    /// </summary>
    public interface IUser
    {
        /// <summary>
        /// Returns the user name
        /// </summary>
        string Name { get; }
    }

    #endregion

    #region IDomainValidation information
    /// <summary>
    /// Summary information for IDomainValidation interface
    /// </summary>
    public interface IDomainValidation
    {
        /// <summary>
        /// Checks to see if the domain exists
        /// </summary>
        /// <param name="domainName">name of the domain to validate</param>
        /// <returns></returns>
        bool Validate(string domainName);
        /// <summary>
        /// The error message for a failed validation.
        /// </summary>
        string ErrorMessage { set; get; }
    }

    #endregion

    #region IServerValidation information
    /// <summary>
    /// Summary information for IServerValidation interface
    /// </summary>
    public interface IServerValidation
    {
        /// <summary>
        /// Checks to see if the server exists
        /// </summary>
        /// <param name="serverName">name of the server to validate</param>
        /// <returns></returns>
        bool Validate(string serverName);
        /// <summary>
        /// The error message for a failed validation.
        /// </summary>
        string ErrorMessage { set; get; }
    }

    #endregion

    #region IGroupValidation information
    /// <summary>
    /// Summary information for IGroupValidation interface
    /// </summary>
    public interface IGroupValidation
    {
        /// <summary>
        /// Checks to see if a group exists on the default domain
        /// </summary>
        /// <param name="groupName">name of the group to validate</param>
        /// <returns>true if the group exists on the default domain</returns>
        bool Validate(string groupName);

        /// <summary>
        /// Checks to see if a group exists on the specified domain
        /// </summary>
        /// <param name="domainName">domain on which to look for the group</param>
        /// <param name="groupName">group name to validate</param>
        /// <returns>true if the group was found on the specified domain</returns>
        bool Validate(string domainName, string groupName);

        /// <summary>
        /// The error message for a failed validation.
        /// </summary>
        string ErrorMessage { set; get; }
    }

    #endregion

    #region IUserValidation information
    /// <summary>
    /// Summary information for IUserValidation interface
    /// </summary>
    public interface IUserValidation
    {
        /// <summary>
        /// Checks to see if a user exists on the default domain
        /// </summary>
        /// <param name="userName">name of the user to validate</param>
        /// <returns></returns>
        bool Validate(string userName);

        /// <summary>
        /// Checks to see if a user exists on the specified domain
        /// </summary>
        /// <param name="domainName">domain on which to look for the user</param>
        /// <param name="userName">user name to validate</param>
        /// <returns>true if the user was found on the specified domain</returns>
        bool Validate(string domainName, string userName);

        /// <summary>
        /// The error message for a failed validation.
        /// </summary>
        string ErrorMessage { set; get; }
    }

    #endregion
}
