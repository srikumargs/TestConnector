using System;
using System.Windows.Forms;
using System.Xml;
using Sage.CM.Core.LinkedSource;

namespace TraceConfigTool
{
    public partial class OutputOptionsControl : UserControl
    {
        #region Constructors
        public OutputOptionsControl()
        {
            InitializeComponent();
        }
        #endregion

        public event EventHandler DataChanged;

        public void Reset()
        {
            switch(OutputType)
            {
                case OutputType.DebugOutput:
                    _enabledCheckBox.Checked = true;
                    break;

                case OutputType.LogFile:
                    _enabledCheckBox.Checked = false;
                    break;
            }
            _enabledCheckBox.Text = GetEnabledCheckBoxLabel();
            _outputOptionsPropertyGrid.SelectedObject = CreateTraceOptionsObject();
        }

        public void Reset(XmlDocument document)
        {
            Reset();

            XmlNode configSection;
            XmlNode customConfigSection;
            XmlNode addListenerElement;

            if(OutputType == OutputType.DebugOutput)
            {
                configSection = document.SelectSingleNode("//configuration/configSections/section[@name='DebugOutputWriterConfigSection']");
                customConfigSection = document.SelectSingleNode("//configuration/DebugOutputWriterConfigSection");
                addListenerElement = document.SelectSingleNode("//configuration/system.diagnostics/trace/listeners/add[@name='DebugOutputWriter']");
            }
            else
            {
                configSection = document.SelectSingleNode("//configuration/configSections/section[@name='TextFileWriterConfigSection']");
                customConfigSection = document.SelectSingleNode("//configuration/TextFileWriterConfigSection");
                addListenerElement = document.SelectSingleNode("//configuration/system.diagnostics/trace/listeners/add[@name='TextFileWriter']");
            }

            TraceOptions traceOptions;
            if(configSection != null && customConfigSection != null && addListenerElement != null)
            {
                _enabledCheckBox.Checked = true;
                traceOptions = CreateTraceOptionsObject(customConfigSection, addListenerElement);
            }
            else
            {
                _enabledCheckBox.Checked = false;
                traceOptions = CreateTraceOptionsObject();
            }

            _outputOptionsPropertyGrid.SelectedObject = traceOptions;
        }

        public void WriteConfigSectionElement(XmlTextWriter xmlTextWriter)
        {
            if(_enabledCheckBox.Checked)
            {
                // <section name="DebugOutputWriterConfigSection" type="Sage.Diagnostics.ConfigurationSectionHandler, Sage.CRE.Core.TraceListeners,Version=<version>,Culture=neutral,PublicKeyToken=3e78b2cabf12f868" />
                // - OR -
                // <section name="TextFileWriterConfigSection" type="Sage.Diagnostics.ConfigurationSectionHandler, Sage.CRE.Core.TraceListeners,Version=<version>,Culture=neutral,PublicKeyToken=3e78b2cabf12f868" />

                xmlTextWriter.WriteStartElement("section");
                if(OutputType == OutputType.DebugOutput)
                {
                    xmlTextWriter.WriteAttributeString("name", "DebugOutputWriterConfigSection");
                }
                else
                {
                    xmlTextWriter.WriteAttributeString("name", "TextFileWriterConfigSection");
                }
                xmlTextWriter.WriteAttributeString("type", String.Format("Sage.Diagnostics.ConfigurationSectionHandler, Sage.CRE.Core.TraceListeners,Version={0}.0.0,Culture=neutral,PublicKeyToken=3e78b2cabf12f868", LibraryConstants.LibraryVersion));
                xmlTextWriter.WriteEndElement(); // section
            }
        }

        public void WriteCustomConfigSectionElement(XmlTextWriter xmlTextWriter)
        {
            if(_enabledCheckBox.Checked)
            {
                // <DebugOutputWriterConfigSection xshowDate="true" xshowTime="true" xshowMilliseconds="true" xshow24Hour="true" xshowProcessId="true" showThreadId="true" showObjectId="true" showTypeName="true" showMessageCategory="true" showMemberName="true" xshowMemberSignature="true" xshowFileLocation="true"/>
                // - OR -
                // <TextFileWriterConfigSection xshowDate="true" showTime="true" showMilliseconds="true" show24Hour="true" xshowProcessId="true" showThreadId="true" showObjectId="true" xshowTypeName="true" showMessageCategory="true" showMemberName="true" xshowMemberSignature="true" xshowFileLocation="true"/>

                if(OutputType == OutputType.DebugOutput)
                {
                    xmlTextWriter.WriteStartElement("DebugOutputWriterConfigSection");
                }
                else
                {
                    xmlTextWriter.WriteStartElement("TextFileWriterConfigSection");
                }

                (_outputOptionsPropertyGrid.SelectedObject as TraceOptions).WriteOptionsAttributes(xmlTextWriter);

                xmlTextWriter.WriteEndElement();
            }
        }

        public void WriteAddListenerElement(XmlTextWriter xmlTextWriter)
        {
            if(_enabledCheckBox.Checked)
            {
                // <add name="DebugOutputWriter" type="Sage.Diagnostics.DebugOutputWriterTraceListener,Sage.CRE.Core.TraceListeners,Version=<version>,Culture=neutral,PublicKeyToken=3e78b2cabf12f868" />
                // - OR -
                // <add name="TextFileWriter" type="Sage.Diagnostics.TextFileWriterTraceListener,Sage.CRE.Core.TraceListeners,Version=<version>,Culture=neutral,PublicKeyToken=3e78b2cabf12f868" initializeData="c:\Sage.ServiceHosts.WorkstationServiceHost.exe.txt" />

                xmlTextWriter.WriteStartElement("add");
                {
                    if(OutputType == OutputType.DebugOutput)
                    {
                        xmlTextWriter.WriteAttributeString("name", "DebugOutputWriter");
                        xmlTextWriter.WriteAttributeString("type", String.Format("Sage.Diagnostics.DebugOutputWriterTraceListener, Sage.CRE.Core.TraceListeners,Version={0}.0.0,Culture=neutral,PublicKeyToken=3e78b2cabf12f868", LibraryConstants.LibraryVersion));
                    }
                    else
                    {
                        xmlTextWriter.WriteAttributeString("name", "TextFileWriter");
                        xmlTextWriter.WriteAttributeString("type", String.Format("Sage.Diagnostics.TextFileWriterTraceListener, Sage.CRE.Core.TraceListeners,Version={0}.0.0,Culture=neutral,PublicKeyToken=3e78b2cabf12f868", LibraryConstants.LibraryVersion));
                    }

                    (_outputOptionsPropertyGrid.SelectedObject as TraceOptions).WriteAddListnerElementAttributes(xmlTextWriter);
                }
                xmlTextWriter.WriteEndElement(); // add
            }
        }

        public OutputType OutputType
        {
            get
            {
                return _outputType;
            }

            set
            {
                _outputType = value;

                Reset();
            }
        }

        #region Private methods
        private string GetEnabledCheckBoxLabel()
        {
            string result = string.Empty;

            switch(OutputType)
            {
                case OutputType.DebugOutput:
                    result = "Enable debug output";
                    break;

                case OutputType.LogFile:
                    result = "Enable log file output";
                    break;
            }

            return result;
        }

        private TraceOptions CreateTraceOptionsObject()
        {
            return CreateTraceOptionsObject(null, null);
        }

        private TraceOptions CreateTraceOptionsObject(XmlNode customConfigSection, XmlNode addListenerElement)
        {
            TraceOptions result = null;

            switch(OutputType)
            {
                case OutputType.DebugOutput:
                    result = new DebugOutputTraceOptions(customConfigSection);
                    break;

                case OutputType.LogFile:
                    result = new LogFileOutputTraceOptions(customConfigSection, addListenerElement);
                    break;
            }

            return result;
        }

        private void _enabledCheckBox_CheckStateChanged(object sender, EventArgs e)
        {
            _outputOptionsPropertyGrid.Enabled = (sender as CheckBox).Checked;

            FireDataChanged();
        }

        private void _outputOptionsPropertyGrid_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            FireDataChanged();
        }

        private void FireDataChanged()
        {
            if(DataChanged != null)
            {
                DataChanged(this, new EventArgs());
            }
        }
        #endregion

        #region Private fields
        private OutputType _outputType;
        #endregion

        private void OutputOptionsControl_Load(object sender, EventArgs e)
        {
            AssemblyUtils.PostMessage(this.Handle, AssemblyUtils.WM_RESIZE_HELP_AREA, 0, 0);
        }

        protected override void WndProc(ref Message m)
        {
            if(m.Msg == AssemblyUtils.WM_RESIZE_HELP_AREA)
            {
                AssemblyUtils.ResizePropertyGridHelpArea(_outputOptionsPropertyGrid, 1.5);
            }

            base.WndProc(ref m);
        }
    }
    
    public enum OutputType
    {
        None,
        DebugOutput,
        LogFile
    }
}
