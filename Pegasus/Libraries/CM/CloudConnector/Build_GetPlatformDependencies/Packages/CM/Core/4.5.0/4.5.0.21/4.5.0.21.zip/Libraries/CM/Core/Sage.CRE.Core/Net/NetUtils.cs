using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using Sage.Diagnostics;
using System.Net;
using System.Globalization;

namespace Sage.Net
{
    /// <summary>
    /// Class providing path utility methods.
    /// </summary>
    [ComVisible(false)]
    public class NetUtils : INetUtils
    {

        /// <summary>
        /// Pings a machine using ICMP. Throws a detailed error if the machine can't be pinged.
        /// </summary>
        /// <param name="host"></param>
        static public void PingMachine(string host)
        {
            using (System.Net.NetworkInformation.Ping ping = new System.Net.NetworkInformation.Ping())
            {
                System.Net.NetworkInformation.PingReply reply = ping.Send(host);
                if (reply.Status != System.Net.NetworkInformation.IPStatus.Success)
                {
                    throw new Sage.Net.PingException(reply.Status);
                }
            }
        }


        /// <summary>
        /// Test the specified address to determine whether it's remote or not.
        /// </summary>
        /// <param name="address">The address to test. This can be an IP address, a hostname, or even a UNC path.</param>
        /// <returns>Returns true if the address is remote; otherwise, false.</returns>
        public static bool IsRemoteAddress(string address)
        {
            // Run the address through the IP comparer and invert.
            return !IPCompare.IsLocalAddress(address);
        }

        /// <summary>
        /// Parse the IP address and determine if it's the loopback device.
        /// </summary>
        /// <param name="address">The IP address to test.</param>
        /// <returns>Returns true if the IP address is the loopback device; otherwise, false.</returns>
        public static bool IsLoopbackAddress(string address)
        {
            System.Net.IPAddress ipAddress = null;

            if (!IsIPAddress(address, out ipAddress))
                return false;

            return System.Net.IPAddress.IsLoopback(ipAddress);
        }

        /// <summary>
        /// Test the specified string to determine if it's a valid IP address.
        /// </summary>
        /// <param name="address">The IP address to test.</param>
        /// <returns>Returns true if it's a valid IP address; otherwise, false.</returns>
        public static bool IsIPAddress(string address)
        {
            System.Net.IPAddress ipAddress = null;
            return IsIPAddress(address, out ipAddress);
        }

        /// <summary>
        /// Test the specified string to determine if it's a valid IP address.
        /// </summary>
        /// <param name="address">The IP address to test.</param>
        /// <param name="ipAddress">The converted IP address object.</param>
        /// <returns>Returns true if it's a valid IP address; otherwise, false.</returns>
        public static bool IsIPAddress(string address, out System.Net.IPAddress ipAddress)
        {
            ipAddress = null;
            return System.Net.IPAddress.TryParse(address, out ipAddress);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serverName"></param>
        /// <returns></returns>
        public static Boolean ServerNameIsLocalMachine(String serverName)
        {
            VerboseTrace.WriteLine(null, "Invoked: serverName={0}", serverName);

            Boolean result = false;

            String dnsHostName = Dns.GetHostName();
            IPHostEntry hostInfo = Dns.GetHostEntry(dnsHostName);
            IPAddress[] ipAddresses = hostInfo.AddressList;
            for (int i = 0; i < ipAddresses.Length; i++)
            {
                InfoTrace.WriteLine(null, "IP address {0}:  {1}", i, ipAddresses[i].ToString());
            }


            Boolean hostNameIsMyIPAddress = false;
            if (-1 != serverName.IndexOf('.'))
            {
                // Machine names cannot contain '.' ... so if this is true it is because this is actually an
                // IP address rather than a host name.  This can happen if the user mapped a network drive
                // using an IP address rather than the host name.  In that situation, ServerNameFromMappedFolder
                // will return to us the server portion of the UNC ... but that is actually an IP address.

                for (Int32 i = 0; !hostNameIsMyIPAddress && i < ipAddresses.Length; i++)
                {
                    if (String.Compare(serverName, ipAddresses[i].ToString(), true, CultureInfo.InvariantCulture) == 0)
                    {
                        hostNameIsMyIPAddress = true;
                    }
                }
            }

            if (hostNameIsMyIPAddress ||
                String.Compare(serverName, IPAddress.Loopback.ToString(), true, CultureInfo.InvariantCulture) == 0 ||
                String.Compare(serverName, IPAddress.IPv6Loopback.ToString(), true, CultureInfo.InvariantCulture) == 0 ||
                String.Compare(serverName, "0:0:0:0:0:0:0:1", true, CultureInfo.InvariantCulture) == 0 ||
                String.Compare(serverName, dnsHostName, true, CultureInfo.InvariantCulture) == 0 ||
                String.Compare(serverName, hostInfo.HostName, true, CultureInfo.InvariantCulture) == 0 ||
                String.Compare(serverName, System.Environment.MachineName, true, CultureInfo.InvariantCulture) == 0 ||
                String.Compare(serverName, "localhost", true, CultureInfo.InvariantCulture) == 0)
            {
                result = true;
            }

            return result;
        }

        public static string ConvertHostNameToIPv4AddressOnlyIfWellKnownNamedFileExistsOnServerShare(string server)
        {
            try
            {
                string wellKnownFile = String.Format(@"\\{0}\ste\ConvertHostNameToIPv4Address.txt",server).ToLower();
                if (System.IO.File.Exists(wellKnownFile))
                {
                    foreach (System.Net.IPAddress address in System.Net.Dns.GetHostAddresses(server))
                    {
                        if (address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            return address.ToString();
                        }
                    }
                }
                return server;
            }
            catch
            {
                return server;
            }
        }

        #region INetUtils Members

        bool INetUtils.IsRemoteAddress(string address)
        {
            return IsRemoteAddress(address);
        }

        bool INetUtils.IsLoopbackAddress(string address)
        {
            return IsLoopbackAddress(address);
        }

        bool INetUtils.IsIPAddress(string address)
        {
            return IsIPAddress(address);
        }

        #endregion
    }
}
