﻿using System;
using System.Collections.Generic;


namespace Sage.CRE.Core.SQL
{
    /// <summary>Detaches a database from a MDF/LDF file set using the Reversible Action pattern
    /// The construction of a DetachDatabase object will Detach the specified database from the specified files.
    /// If the object is disposed without calling the Commit() method, then the newly Detached database will be detached.
    /// </summary>
    public class DetachDatabase : Sage.IO.ReversibleAction.ReversibleActionBase
    {

        /// <summary>
        /// Detaches a database and copies the MDF and LDF files to the 
        /// </summary>
        /// <param name="context">The database to detach.</param>
        /// <param name="directory">Where to put the MDF and LDF files.</param>
        /// <returns></returns>
        public static bool Detach(SqlConnectionContext context, string directory)
        {
            bool result = false;

                using (DetachDatabase detacher = new DetachDatabase(context))
                {
                    detacher.Forward();

                    if (!String.IsNullOrEmpty(directory))
                    {
                        Dictionary<string, string> filesToCopy = new Dictionary<string, string>();
                        filesToCopy.Add(detacher.MDF, System.IO.Path.Combine(directory, context.InitialCatalog) + ".MDF");
                        filesToCopy.Add(detacher.LDF, System.IO.Path.Combine(directory, context.InitialCatalog) + ".LDF");


                        using (Sage.IO.ReversibleAction.DirectoryCreate mdfDirCreate = new Sage.IO.ReversibleAction.DirectoryCreate(directory))
                        {
                            mdfDirCreate.Forward();


                            using (Sage.IO.ReversibleAction.FileCopy copier = new Sage.IO.ReversibleAction.FileCopy(filesToCopy, true, false, false, false))
                            {
                                copier.Forward();

                                result = true;
                                System.Data.SqlClient.SqlConnection.ClearAllPools();
                                while (SqlCommands.DatabaseExists(context)) System.Threading.Thread.Sleep(1000);


                                copier.Commit();
                            }

                            mdfDirCreate.Commit();
                        }

                    }
                    else
                    {
                        result = true;
                    }

                    detacher.Commit();

                    System.IO.File.Delete(detacher.MDF);
                    System.IO.File.Delete(detacher.LDF);

                }

                return result;

        }

        #region Private members
        private SqlConnectionContext _context = new SqlConnectionContext();
        private string _mdf = String.Empty;
        private string _ldf = String.Empty;
        private bool _Detached;
        #endregion


        /// <summary>
        /// The MDF filename of the detached database.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "MDF")]
        public string MDF
        {
            get { return _mdf; }
        }

        /// <summary>
        /// The LDF filename of the detached database.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "LDF")]
        public string LDF
        {
            get { return _ldf; }
        }

        /// <summary>Creates the DetachDatabase object
        /// </summary>
        /// <param name="context">The database to detach.</param>
        public DetachDatabase(SqlConnectionContext context)
        {
            _context = context;
        }


        /// <summary>Detaches the database.
        /// </summary>
        public override void Forward()
        {
            base.Forward();

            using (System.Data.DataTable files = SqlCommands.SelectDataTable(_context, @"SELECT * FROM sys.database_files ORDER BY type"))
            {
                _mdf = files.Rows[0][@"physical_name"].ToString();
                _ldf = files.Rows[1][@"physical_name"].ToString();

                SqlCommands.DetachDatabase(_context,true);
            }

            _Detached = true;
        }



        /// <summary>Reverses the Detachment of the database.
        /// </summary>
        public override void Reverse()
        {
            if (_Detached)
            {
                SqlCommands.AttachDatabase(_context,_mdf,_ldf);
                SqlCommands.MultiUser(_context);
                _Detached = false;
            }

            base.Reverse();
        }
    }
}
