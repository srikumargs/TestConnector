using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Sage.IO
{
    /// <summary>
    /// Defines static methods used to perform a comparison between 2 files or 2 file streams.
    /// </summary>
    public static class DataComparer
    {
        private static FileStream GetReadOnlyFileStream(string fullPathToFile)
        {
            if (string.IsNullOrEmpty(fullPathToFile))
                return null;

            if (!File.Exists(fullPathToFile))
                return null;

            // Make sure we explicitely request read-only access.
            return new FileStream(fullPathToFile, FileMode.Open, FileAccess.Read);
        }

        /// <summary>
        /// Compare the data found between 2 files.
        /// </summary>
        /// <param name="fullPathToFile1">The full path to the first file.</param>
        /// <param name="fullPathToFile2">The full path to the second file.</param>
        /// <returns>Returns true if the 2 contain equivalent data; otherwise, false.</returns>
        /// <exception cref="System.UnauthorizedAccessException">Throws an exception if insufficient permissions exist to access either file.</exception>
        /// <exception cref="System.Security.SecurityException">Throws an exception if a security violation occurs when accessing either file.</exception>
        /// <exception cref="System.IOException">Throws an exception if an IO exception occurs.</exception>
        public static bool CompareData(string fullPathToFile1, string fullPathToFile2)
        {
            if (string.Compare(fullPathToFile1, fullPathToFile2, true, System.Globalization.CultureInfo.CurrentCulture) == 0)
                return true;

            // Make sure we open these streams in read-only mode.
            FileStream fs1 = GetReadOnlyFileStream(fullPathToFile1);
            FileStream fs2 = GetReadOnlyFileStream(fullPathToFile2);

            if (fs1 == null ||
                fs2 == null)
            {
                return false;
            }

            // Default to false since the lengths may not be equal.
            bool result = false;

            // Don't event bother comparing unless they're of equal length.
            if (fs1.Length == fs2.Length)
            {
                result = CompareData(fs1, fs2);
            }

            fs1.Close();
            fs2.Close();
            return result;
        }

        /// <summary>
        /// Compare the data found between a file and a stream.
        /// </summary>
        /// <param name="fullPathToFile">The full path to the file.</param>
        /// <param name="stream2">The second stream.</param>
        /// <returns>Returns true if the 2 contain equivalent data; otherwise, false.</returns>
        /// <exception cref="System.UnauthorizedAccessException">Throws an exception if insufficient permissions exist to access the file.</exception>
        /// <exception cref="System.Security.SecurityException">Throws an exception if a security violation occurs when accessing the file.</exception>
        /// <exception cref="System.IOException">Throws an exception if an IO exception occurs.</exception>
        public static bool CompareData(string fullPathToFile, Stream stream2)
        {            
            if (stream2 == null)
                return false;

            FileStream fs1 = GetReadOnlyFileStream(fullPathToFile);

            if (fs1 == null)
            {
                return false;
            }

            bool result = CompareData(fs1, stream2);
            fs1.Close();
            return result;
        }

        /// <summary>
        /// Compare the data found between 2 streams.
        /// </summary>
        /// <param name="stream1">The first stream.</param>
        /// <param name="stream2">The second stream.</param>
        /// <returns>Returns true if the 2 contain equivalent data; otherwise, false.</returns>
        /// <exception cref="System.NotSupportedException">Throws an exception if a failure occurs while reading data from either stream.</exception>
        /// <exception cref="System.ObjectDisposedException">Throws an exception if an operation is performed on a disposed object.</exception>
        public static bool CompareData(Stream stream1, Stream stream2)
        {            
            if (stream1 == null ||
                stream2 == null)
            {
                return false;
            }

            int s1ByteValue;
            int s2ByteValue;
            bool areEqual = true;

            while (areEqual)
            {
                s1ByteValue = stream1.ReadByte();
                s2ByteValue = stream2.ReadByte();

                if (s1ByteValue == -1 ||
                    s2ByteValue == -1)
                {
                    break;
                }
                else if (s1ByteValue != s2ByteValue)
                {
                    areEqual = false;
                }
            }

            return areEqual;
        }
    }
}
