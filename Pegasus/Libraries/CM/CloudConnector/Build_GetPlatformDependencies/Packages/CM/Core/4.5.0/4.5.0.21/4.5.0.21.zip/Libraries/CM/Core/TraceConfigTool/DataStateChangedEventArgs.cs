using System;
using System.Collections.Generic;
using System.Text;

namespace TraceConfigTool
{
    internal sealed class DataStateChangedEventArgs : EventArgs
    {
        #region Constructors
        public DataStateChangedEventArgs(bool dirty, string fileName)
        {
            _dirty = dirty;
            _fileName = fileName;
        }
        #endregion

        #region Public properties
        public bool Dirty
        {
            get
            {
                return _dirty;
            }
        }

        public string FileName
        {
            get
            {
                return _fileName;
            }
        }
        #endregion

        #region Private fields
        private bool _dirty;
        private string _fileName;
        #endregion
    }
}
