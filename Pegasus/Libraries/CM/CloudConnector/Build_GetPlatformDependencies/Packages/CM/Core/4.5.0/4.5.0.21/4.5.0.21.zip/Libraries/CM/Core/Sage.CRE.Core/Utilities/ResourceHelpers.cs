using System;
using System.Reflection;
using System.Drawing;
using System.IO;
using System.Resources;

namespace Sage.Utilities
{
	/// <summary>
	/// Summary description for ResourceHelpers.
	/// </summary>
	public static class ResourceHelpers
	{
        /// <summary>
        /// Loads the image from the stream from an assembly
        /// </summary>
        /// <param name="theAssembly">The assembly.</param>
        /// <param name="resourceName">Name of the resource.</param>
        /// <returns></returns>
        public static Image LoadImageFromResource(Assembly theAssembly, string resourceName)
        {
            Image img = null;
            if (theAssembly != null)
            {
                Stream file = theAssembly.GetManifestResourceStream(resourceName);
                if (null != file) 
                {
                    img = Image.FromStream(file);
                }
            }
            return img;
        }

        /// <summary>
        /// Loads a string from the resource.
        /// </summary>
        /// <param name="theAssembly">The assembly.</param>
        /// <param name="resourceName">Name of the resource.</param>
        /// <param name="resxName">Name of the RESX.</param>
        /// <returns></returns>
        public static String LoadStringFromResource( Assembly theAssembly, String resourceName, String resxName )
        {
            String str = null;
            if (theAssembly != null)
            {
                ResourceManager rm = new ResourceManager( resourceName, theAssembly );
                str = rm.GetString( resxName );
            }
            return str;
        }

        /// <summary>
        /// Loads a bytes from the resource.
        /// </summary>
        /// <param name="theAssembly">The assembly.</param>
        /// <param name="resourceName">Name of the resource.</param>
        /// <param name="resxName">Name of the RESX.</param>
        /// <returns></returns>
        public static Byte[] LoadBytesFromResource(Assembly theAssembly, String resourceName, String resxName)
        {
            Byte[] result = null;
            if (theAssembly != null)
            {
                ResourceManager rm = new ResourceManager(resourceName, theAssembly);
                result = (Byte[])rm.GetObject(resxName);
            }
            return result;
        }
	}
}
