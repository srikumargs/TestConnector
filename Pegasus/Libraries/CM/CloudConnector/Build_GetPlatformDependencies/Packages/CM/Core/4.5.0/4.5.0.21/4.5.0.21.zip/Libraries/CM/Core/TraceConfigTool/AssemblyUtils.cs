using System;
using System.Windows.Forms;
using System.Drawing;
using System.Reflection;
using System.Runtime.InteropServices;

namespace TraceConfigTool
{
    /// <summary>
    /// Summary description for AssemblyUtils.
    /// </summary>
    internal static class AssemblyUtils
    {
        public static bool IsCurrentlyShowingInDesigner
        {
            get
            {
                return System.Reflection.Assembly.GetEntryAssembly() == null && (System.Diagnostics.Process.GetCurrentProcess().ProcessName == "devenv");
            }
        }

        public static void ResizePropertyGridHelpArea(PropertyGrid propertyGrid, double factor)
        {
            FieldInfo fieldInfo = propertyGrid.GetType().GetField("doccomment", BindingFlags.Instance | BindingFlags.NonPublic);
            object doccomment = fieldInfo.GetValue(propertyGrid);
            Size size = (Size) doccomment.GetType().InvokeMember("Size", BindingFlags.Public | BindingFlags.Instance | BindingFlags.GetProperty, null, doccomment, new object[] { });
            int oldSize = size.Height;
            int newSize = (int) (size.Height * factor);
            size.Height = newSize;
            doccomment.GetType().InvokeMember("Size", BindingFlags.Public | BindingFlags.Instance | BindingFlags.SetProperty, null, doccomment, new object[] { size });

            FieldInfo gridViewFieldInfo = propertyGrid.GetType().GetField("gridView", BindingFlags.Instance | BindingFlags.NonPublic);
            object gridView = gridViewFieldInfo.GetValue(propertyGrid);
            size = (Size) gridView.GetType().InvokeMember("Size", BindingFlags.Public | BindingFlags.Instance | BindingFlags.GetProperty, null, gridView, new object[] { });
            size.Height += (oldSize - newSize);
            gridView.GetType().InvokeMember("Size", BindingFlags.Public | BindingFlags.Instance | BindingFlags.SetProperty, null, gridView, new object[] { size });

            FieldInfo userSizedFieldInfo = doccomment.GetType().GetField("userSized", BindingFlags.Instance | BindingFlags.NonPublic);
            userSizedFieldInfo.SetValue(doccomment, true);

            propertyGrid.GetType().InvokeMember("OnLayoutInternal", BindingFlags.NonPublic | BindingFlags.InvokeMethod | BindingFlags.Instance, null, propertyGrid, new object[] { true });
        }

        [DllImport("user32.dll")]
        public static extern int PostMessage(IntPtr window, int message, int wparam, int lparam);

        public const int WM_RESIZE_HELP_AREA = 0x0400 + 0x0999;  //WM_USER + 999
    }
}
