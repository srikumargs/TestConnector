using System;
using System.Net;

namespace Sage.Net
{
    /// <summary>
    /// Summary description for ServerValidation.
    /// </summary>
    public class ServerValidation
      : IServerValidation
    {
        /// <summary>
        /// ctor
        /// </summary>
        public ServerValidation()
        {
        }

        /// <summary>
        /// Checks to see if the specified server exists on the network
        /// </summary>
        /// <param name="serverName">name of the server</param>
        /// <returns>true if the server was found</returns>
        public bool Validate(string serverName)
        {
            bool bServerExists = true;
            try
            {
                IPHostEntry iphe = Dns.GetHostByName(serverName);
                int i = 0; i++;   // for debugging...
            }
            catch (Exception /*ex*/ )
            {
                bServerExists = false;
            }
            finally
            {
                string str = (bServerExists) ? "" : "not ";
                ErrorMessage = serverName + " was " + str + "found on the network.";
            }
            return bServerExists;
        }

        private string _errorMessage = String.Empty;
        /// <summary>
        /// The error message string for a validation failure
        /// </summary>
        public string ErrorMessage
        {
            get { return _errorMessage; }
            set { _errorMessage = value; }
        }

    }
}
