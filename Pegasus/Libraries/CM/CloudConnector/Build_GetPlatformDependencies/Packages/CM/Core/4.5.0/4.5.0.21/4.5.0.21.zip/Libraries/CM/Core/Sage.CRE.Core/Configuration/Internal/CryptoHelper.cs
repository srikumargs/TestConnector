using System;
using System.Security.Cryptography;

namespace Sage.Configuration.Internal
{
	/// <summary>
	/// Summary description for CryptoHelper.
	/// </summary>
	internal class CryptoHelper
	{
        #region Types

        /// <summary>
        /// Available types of encryption actions
        /// </summary>
        public enum EncryptionAction
        {
            /// <summary>
            /// Encrypt
            /// </summary>
            Encrypt,

            /// <summary>
            /// Decrypt
            /// </summary>
            Decrypt
        }

        #endregion

        /// <summary>
        /// Hide the instance constructor
        /// </summary>
		private CryptoHelper()
		{
			
		}

        /// <summary>
        /// Encrypt/Decrypt a data array
        /// </summary>
        /// <param name="data">The bytes to encrypt/decrypt</param>
        /// <param name="action">The encryption action to perform</param>
        /// <returns>A encrypted byte array</returns>
        public static byte[] TransformBytes( byte[] data, EncryptionAction action )
        {
            byte[] buffer = null;
            byte[] Key = {0xD,  0x20, 0x8A, 0xCF, 0x3D, 0xA5, 0xC,  0x98};
            byte[] IV =  {0x5C, 0x10, 0x6F, 0xB4, 0x18, 0x40, 0xD8, 0xEE};

            DESCryptoServiceProvider DES = new DESCryptoServiceProvider();
            if( action ==  EncryptionAction.Encrypt )
            {
                buffer = DES.CreateEncryptor( Key, IV ).TransformFinalBlock( data, 0, data.Length );
            }
            else
            {   
                buffer =  DES.CreateDecryptor( Key, IV ).TransformFinalBlock( data, 0, data.Length );
            }
            
            return buffer;
        }
	}
}
