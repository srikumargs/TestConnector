using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Threading;
using Microsoft.Win32;

using Sage.Diagnostics;

namespace Sage.Remoting
{
    /// <summary>
    /// This is used to pass service specific information to the ServiceController
    /// </summary>
    [ComVisible(false)]
    public struct ServiceControllerStartInfo
    {
        private string _serviceName;
        private string _installFolderPath;
        private string _executableName;

        /// <summary>
        /// Get and set the service name
        /// </summary>
        public string ServiceName
        {
            get { return _serviceName;  }
            set { _serviceName = value; }
        }


        /// <summary>
        /// get and set the full path for the service if install or uninstall 
        /// is desired
        /// </summary>
        public string InstallFolderPath
        {
            get { return _installFolderPath;  }
            set { _installFolderPath = value; }
        }

        /// <summary>
        /// get/set The executable name plus extension
        /// </summary>
        public string ExecutableName
        {
            get { return _executableName;  }
            set { _executableName = value; }
        }
    }


    /// <summary>
    /// What is the status of the service
    /// </summary>
    [ComVisible(false)]
    public enum ServiceStatus
    {
        /// <summary>
        /// The service is running
        /// </summary>
        Running,
        /// <summary>
        /// The service is installed but not running
        /// </summary>
        Stopped,
        /// <summary>
        /// The service is not installed
        /// </summary>
        NotInstalled
    }

    /// <summary>
    /// Controller for starting the service
    /// </summary>
    [ComVisible(false)]
    public class ServiceController
    {
        private ServiceControllerStartInfo _serviceControllerStartInfo;

        // hide
        private ServiceController() {}

        /// <summary>
        /// This class is used to install, uninstall, stop start and query an NT Service for status
        /// </summary>
        /// <param name="serviceControllerStartInfo"></param>
        public ServiceController(ServiceControllerStartInfo serviceControllerStartInfo)
        {
            ArgumentValidator.ValidateNonEmptyString(serviceControllerStartInfo.ServiceName, "ServiceControllerStartInfo.ServiceName", typeof(ServiceController).FullName + "..ctor");
            
            _serviceControllerStartInfo = serviceControllerStartInfo;
            //
            // The executable name does not need to be set.  If it isn't just create from the service name
            //
            if (_serviceControllerStartInfo.ExecutableName == null || _serviceControllerStartInfo.ExecutableName.Length == 0)
            {
                _serviceControllerStartInfo.ExecutableName = _serviceControllerStartInfo.ServiceName + ".exe";
            }
        }

        /// <summary>
        /// attempt to start the specified service.
        /// </summary>
        /// <returns>true if started else false</returns>
        public bool Start()
        {
            RegisterChannels();

            bool started = true;
            try
            {
                System.ServiceProcess.ServiceController sc =
                    new System.ServiceProcess.ServiceController(_serviceControllerStartInfo.ServiceName);
                
                sc.Start();
                int count = 0;
                while (true)
                {
                    Thread.Sleep(50);
                    count++;
                    sc.Refresh();
                    if (sc.Status == System.ServiceProcess.ServiceControllerStatus.Running)
                    {
                        //Trace.WriteLine("start service iterations={0}", count);
                        break;
                    }
                }
            }
            catch (Exception)
            {
                started = false;
            }
            return started;
        }

        /// <summary>
        /// Attempt to stop a service
        /// </summary>
        /// <returns>returns true if stopped, else false</returns>
        public bool Stop()
        {
            UnRegisterChannels();

            bool stopped = true;
            try
            {
                System.ServiceProcess.ServiceController sc =
                    new System.ServiceProcess.ServiceController(_serviceControllerStartInfo.ServiceName);
                
                sc.Stop();
                int count = 0;
                while (true)
                {
                    Thread.Sleep(50);
                    count++;
                    sc.Refresh();
                    if (sc.Status == System.ServiceProcess.ServiceControllerStatus.Stopped)
                    {
                        //Trace.WriteLine("stop service iterations={0}", count);
                        break;
                    }
                }
            }
            catch (Exception)
            {
                stopped = false;
            }
            return stopped;
        }

        
        /// <summary>
        /// Uses installutil exe to uninstall the specified service
        /// </summary>
        public void Uninstall()
        {
            System.ServiceProcess.ServiceController[] services = System.ServiceProcess.ServiceController.GetServices();
            foreach (System.ServiceProcess.ServiceController sc in services)
            {
                if (sc.ServiceName == _serviceControllerStartInfo.ServiceName)
                {
                    this.Stop();

                    ArgumentValidator.ValidateNonEmptyString(_serviceControllerStartInfo.InstallFolderPath,
                        "ServiceControllerStartInfo.InstallFolderPath", typeof(ServiceController) + ".Uninstall");
                    string arg =  "/U " + _serviceControllerStartInfo.InstallFolderPath + @"\" + 
                        _serviceControllerStartInfo.ExecutableName;

                    RunInstallUtilProcess(arg);

                    break;
                }
            }
        }

        /// <summary>
        /// Uses the installutil exe to install the specified service
        /// </summary>
        public void Install()
        {
            Uninstall();

            ArgumentValidator.ValidateNonEmptyString(_serviceControllerStartInfo.InstallFolderPath, "ServiceControllerStartInfo.InstallFolderPath", typeof(ServiceController) + ".Install");
            string arg = _serviceControllerStartInfo.InstallFolderPath + @"\" + _serviceControllerStartInfo.ExecutableName;
            RunInstallUtilProcess(arg);
        }

        /// <summary>
        /// Is the service running, stopped or not installed?
        /// </summary>
        public ServiceStatus Status
        {
            get
            {
                ServiceStatus status = ServiceStatus.NotInstalled;
                System.ServiceProcess.ServiceController[] services = System.ServiceProcess.ServiceController.GetServices();
                foreach (System.ServiceProcess.ServiceController sc in services)
                {
                    if (sc.ServiceName == _serviceControllerStartInfo.ServiceName)
                    {
                        sc.Refresh();
                        if (sc.Status == System.ServiceProcess.ServiceControllerStatus.Running)
                        {
                            status = ServiceStatus.Running;
                        }
                        else
                        {
                            status = ServiceStatus.Stopped;
                        }
                    }
                }
                return status;
            }
        }

        /// <summary>
        /// Helper to execute the process
        /// </summary>
        /// <param name="arg"></param>
        private void RunInstallUtilProcess(string arg)
        {

            ProcessStartInfo info = new ProcessStartInfo(GetInstallUtilPath(), arg);
            info.CreateNoWindow         = true;
            info.RedirectStandardOutput = true;
            
            info.RedirectStandardError  = true;
            info.UseShellExecute        = false;

            Process installUtilProc = Process.Start(info);
            installUtilProc.WaitForExit();
            StreamReader sr = installUtilProc.StandardOutput;
            Trace.WriteLine(sr.ReadLine());
            sr = installUtilProc.StandardError;
            Trace.WriteLine(sr.ReadLine());
            sr.Close();
        }

        private string GetInstallUtilPath()
        {
            const string frameWorkKey = @"SOFTWARE\Microsoft\.NETFramework";
            const string installLocation = "InstallRoot";
            const string V1 = @"v1.0.3705\InstallUtil.exe";
            const string V2 = @"v1.1.4322\InstallUtil.exe";
            const string V3 = @"v2.0.50727\InstallUtil.exe";

            RegistryKey key = Registry.LocalMachine.OpenSubKey(frameWorkKey);
            string installPath = (string) key.GetValue(installLocation);
            string installUtilPath = installPath + V3;
            if (File.Exists(installUtilPath) == false)
            {
                installUtilPath = installPath + V2;
                if (File.Exists(installUtilPath) == false)
                {
                    installUtilPath = installPath + V1;
                    if(File.Exists(installUtilPath) == false)
                    {
                        string errMsg = Strings.CannotLocateInstallUtilExe;
                        EventLogger.WriteMessage("ServiceController", errMsg, MessageType.Error);
                        throw new FileNotFoundException(errMsg);
                    }
                }
            }
            return installUtilPath;
        }

        private void RegisterChannels()
        {
            ChannelRegistrar r = new ChannelRegistrar();
            r.RegisterServer(ChannelType.NamedPipe);
        }

        private void UnRegisterChannels()
        {
            ChannelRegistrar.UnregisterPipe();
        }
    }
}

