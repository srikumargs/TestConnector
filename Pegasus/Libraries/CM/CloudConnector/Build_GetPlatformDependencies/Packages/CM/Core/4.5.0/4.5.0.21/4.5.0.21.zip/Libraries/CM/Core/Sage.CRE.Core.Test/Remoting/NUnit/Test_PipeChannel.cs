#if DEBUG
using System;
using System.Collections;
using System.Runtime.InteropServices;
using NUnit.Framework;
using System.Xml;
using System.Xml.XPath;
using System.Text;
using System.Threading;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using Sage.Remoting;

namespace Sage.Remoting.NUnit
{

    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class Test_Parse
    {
        readonly string channType = @"pipe://";

        private string Parse(string inUrl, out string machineName, out string objUri)
        {
          
            string pipeName;
            machineName = ".";
            if (inUrl.StartsWith(channType) == true)
            {
                string url =  inUrl.Substring(channType.Length);
                string[] toks = url.Split('/');
                if (toks.Length == 2)
                {
                    pipeName = toks[0];
                    objUri   = toks[1];
                }
                else if (toks.Length == 3)
                {
                    machineName = toks[0];
                    pipeName    = toks[1];
                    objUri      = toks[2];
                }
                else
                {
                    throw new FormatException(string.Format("Named Pipe Url is badly formed: {0}", inUrl));
                }
            }
            else
            {
                throw new FormatException(string.Format("Named Pipe Url is badly formed: {0}", inUrl));
            }
            return pipeName;
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void LocalParseTest()
        {
            string machineName, objUri;
            string url = @"pipe://MyPipe/MyObject.rem";
            string pipeName = this.Parse(url, out machineName, out objUri);
            Assert.AreEqual(pipeName, "MyPipe");
            Assert.AreEqual(machineName, ".");
            Assert.AreEqual(objUri, "MyObject.rem");
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void ServerParseTest()
        {
            string machineName, objUri;
            string url = @"pipe://MyServer/MyPipe/MyObject.rem";
            string pipeName = this.Parse(url, out machineName, out objUri);
            Assert.AreEqual(pipeName, "MyPipe");
            Assert.AreEqual(machineName, "MyServer");
            Assert.AreEqual(objUri, "MyObject.rem");
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        [ExpectedException(typeof(FormatException))]
        public void BadChannelTest()
        {
            string machineName, objUri;
            string url = @"foozle://MyPipe/MyObject.rem";
            string pipeName = this.Parse(url, out machineName, out objUri);
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        [ExpectedException(typeof(FormatException))]
        public void TooManySlashTest()
        {
            string machineName, objUri;
            string url = @"pipe://MyPipe/WhattheHell/AnotherOne/MyObject.rem";
            string pipeName = this.Parse(url, out machineName, out objUri);
        }
    }



    /*
    /// <summary>
    /// Test the ResourceLocator
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class Test_PipeChannel
    {
        [Test]
        [Ignore("Named pipe thread cleanup problem")]
        public void AChannelRegTest()
        {
            IDictionary dict = new Hashtable();
            dict.Add("name", "bazzle");
            dict.Add("pipe", "TestPipe");
            
            PipeChannel pChan = new PipeChannel(dict, null, null);
            
            ChannelServices.RegisterChannel(pChan);
        }
        [Test]
        [Ignore("Named pipe thread cleanup problem")]
        public void AChannelUnRegTest()
        {
            IChannel chan = ChannelServices.GetChannel("bazzle");
            Assertion.AssertNotNull(chan);
            ChannelServices.UnregisterChannel(chan);
            chan = ChannelServices.GetChannel("bazzle");
            Assertion.AssertNull(chan);
        }

        [Test]
        [Ignore("Named pipe thread cleanup problem")]
        public void ChannelRegUnregTest()
        {
            IDictionary dict = new Hashtable();
            dict.Add("name", "bazzle");
            dict.Add("pipe", "TestPipe");
            
            PipeChannel pChan = new PipeChannel(dict, null, null);
            
            ChannelServices.RegisterChannel(pChan);

            IChannel chan = ChannelServices.GetChannel("bazzle");
            Assertion.AssertNotNull(chan);
            ChannelServices.UnregisterChannel(chan);
            chan = ChannelServices.GetChannel("bazzle");
            Assertion.AssertNull(chan);
        }
    }
    */
}
#endif // DEBUG