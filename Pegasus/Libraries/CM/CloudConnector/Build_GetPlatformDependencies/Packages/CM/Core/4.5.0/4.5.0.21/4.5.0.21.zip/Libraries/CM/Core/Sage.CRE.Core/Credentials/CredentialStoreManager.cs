﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using Sage.Utilities;

namespace Sage.Credentials
{
    public static class CredentialStoreManager
    {
        /// <summary>
        /// Stores the specified credentials in the operating system's credential store for the currently logged on user.
        /// </summary>
        /// <param name="target">The target name for the credentials.</param>
        /// <param name="credential">The credentials to store.</param>
        /// <exception cref="ArgumentNullException">
        /// <para>
        ///   <paramref name="target"/> is <see langword="null" />.
        /// </para>
        /// <para>
        ///   -or-
        /// </para>
        /// <para>
        ///   <paramref name="credential"/> is <see langword="null" />.
        /// </para>
        /// </exception>
        /// <exception cref="ArgumentException"><paramref name="target"/> is an empty string ("").</exception>
        /// <exception cref="CredentialException">An error occurred storing the credentials.</exception>
        /// <remarks>
        /// <para>
        ///   If the credential manager already contains credentials for the specified <paramref name="target"/>, they
        ///   will be overwritten; this can even overwrite credentials that were stored by another application. Therefore 
        ///   it is strongly recommended that you prefix the target name to ensure uniqueness, e.g. using the
        ///   form "Company_ApplicationName_www.example.com".
        /// </para>
        /// </remarks>
        public static void StoreCredential(String target, SecureCredentials credential)
        {
            if (target == null)
            {
                throw new ArgumentNullException("target");
            }
            if (target.Length == 0)
            {
                throw new ArgumentException("The credential target may not be an empty string.", "target");
            }
            if (credential == null)
            {
                throw new ArgumentNullException("credential");
            }

            var c = new Sage.PInvoke.WinCred.CREDENTIAL();
            c.CredentialBlob = IntPtr.Zero;
            try
            {
                c.Flags = 0;
                c.Type = Sage.PInvoke.WinCred.CredTypes.CRED_TYPE_GENERIC;
                c.TargetName = target;
                c.CredentialBlob = Marshal.SecureStringToCoTaskMemUnicode(credential.Password);
                c.CredentialBlobSize = (uint)credential.Password.Length * sizeof(char);
                c.Persist = Sage.PInvoke.WinCred.CredPersist.LocalMachine;
                c.AttributeCount = 0;
                c.Attributes = IntPtr.Zero;
                c.TargetAlias = null;
                c.UserName = credential.UserName;

                bool retVal = Sage.PInvoke.WinCred.CredWrite(ref c, 0);
                if (!retVal)
                {
                    throw new CredentialException(System.Runtime.InteropServices.Marshal.GetLastWin32Error());
                }
            }
            finally
            {
                if (IntPtr.Zero != c.CredentialBlob)
                {
                    Marshal.ZeroFreeCoTaskMemUnicode(c.CredentialBlob);
                    c.CredentialBlob = IntPtr.Zero;
                }
            }
        }

        /// <summary>
        /// Retrieves credentials for the specified target from the operating system's credential store for the current user.
        /// </summary>
        /// <param name="target">The target name for the credentials.</param>
        /// <returns>The credentials if they were found; otherwise, <see langword="null" />.</returns>
        /// <remarks>
        /// </remarks>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is <see langword="null" />.</exception>
        /// <exception cref="ArgumentException"><paramref name="target"/> is an empty string ("").</exception>
        /// <exception cref="CredentialException">An error occurred retrieving the credentials.</exception>
        public static SecureCredentials RetrieveCredential(String target)
        {
            if (target == null)
            {
                throw new ArgumentNullException("target");
            }
            if (target.Length == 0)
            {
                throw new ArgumentException("The credential target may not be an empty string.", "target");
            }

            SecureCredentials result = null;
            IntPtr credential;
            if (Sage.PInvoke.WinCred.CredRead(target, Sage.PInvoke.WinCred.CredTypes.CRED_TYPE_GENERIC, 0, out credential))
            {
                try
                {
                    var c = (Sage.PInvoke.WinCred.CREDENTIAL)Marshal.PtrToStructure(credential, typeof(Sage.PInvoke.WinCred.CREDENTIAL));
                    result = new SecureCredentials() { UserName = c.UserName, Password = SecureStringUtils.PtrToSecureString(c.CredentialBlob, (int)(c.CredentialBlobSize / sizeof(char))) };
                }
                finally
                {
                    Sage.PInvoke.WinCred.CredFree(credential);
                }
            }
            else
            {
                int error = System.Runtime.InteropServices.Marshal.GetLastWin32Error();
                if (error != (int)Sage.PInvoke.WinCred.CredUIReturnCodes.ERROR_NOT_FOUND)
                {
                    throw new CredentialException(error);
                }
            }

            return result;
        }

        /// <summary>
        /// Deletes the credentials for the specified target.
        /// </summary>
        /// <param name="target">The name of the target for which to delete the credentials.</param>
        /// <returns><see langword="true"/> if the credential was deleted from the operating system's store; <see langword="false"/> if no credentials for the specified target could be found
        /// in the store.</returns>
        /// <remarks>
        /// <para>
        ///   The credentials for the specified target will be removed from the operating system's credential store.
        /// </para>
        /// </remarks>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is <see langword="null" />.</exception>
        /// <exception cref="ArgumentException"><paramref name="target"/> is an empty string ("").</exception>
        /// <exception cref="CredentialException">An error occurred deleting the credentials from the operating system's credential store.</exception>
        public static Boolean DeleteCredential(String target)
        {
            if (target == null)
            {
                throw new ArgumentNullException("target");
            }
            if (target.Length == 0)
            {
                throw new ArgumentException("The credential target may not be an empty string.", "target");
            }

            bool result = false;
            if (Sage.PInvoke.WinCred.CredDelete(target, Sage.PInvoke.WinCred.CredTypes.CRED_TYPE_GENERIC, 0))
            {
                result = true;
            }
            else
            {
                int error = Marshal.GetLastWin32Error();
                if (error != (int)Sage.PInvoke.WinCred.CredUIReturnCodes.ERROR_NOT_FOUND)
                {
                    throw new CredentialException(error);
                }
            }
            return result;
        }
    }

}
