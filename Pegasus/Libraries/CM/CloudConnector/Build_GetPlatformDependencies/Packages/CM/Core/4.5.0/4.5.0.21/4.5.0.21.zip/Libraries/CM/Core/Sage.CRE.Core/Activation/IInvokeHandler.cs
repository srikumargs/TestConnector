using System;
using System.Reflection;

namespace Sage.Activation
{
    /// <summary>
    /// Defines the handler that will receive all methods invoked on a proxy object created by the ProxyFactory.
    /// </summary>
    public interface IInvokeHandler
    {
        /// <summary>
        /// Proxy implementation should invoke the method on the real object.
        /// </summary>
        /// <param name="instanceBeingProxied">The instance of the real object for which a proxy has been created</param>
        /// <param name="methodInfo">The method info that can be used to invoke the actual method on the real object instance</param>
        /// <param name="parameters">Parameters to pass to the method</param>
        /// <returns>The result of method invocation on the real object instance</returns>
        Object Invoke(Object instanceBeingProxied, MethodInfo methodInfo, Object[] parameters);
    }
}
