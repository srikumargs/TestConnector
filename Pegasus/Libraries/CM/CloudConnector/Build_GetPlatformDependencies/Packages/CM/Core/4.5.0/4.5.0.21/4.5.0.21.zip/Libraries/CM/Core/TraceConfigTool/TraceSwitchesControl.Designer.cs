namespace TraceConfigTool
{
    partial class TraceSwitchesControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this._traceLevelsHeaderPanel = new System.Windows.Forms.Panel();
            this._resetButton = new System.Windows.Forms.Button();
            this._traceLevelsHeaderLabel = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this._importReferencesToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this._setAllAssemblySwitchLevelsToolStripDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this._offToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._errorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._warningToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._verboseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._deleteToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._addToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.panel2 = new System.Windows.Forms.Panel();
            this._propertyGrid = new System.Windows.Forms.PropertyGrid();
            this._importReferencesBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this._traceLevelsHeaderPanel.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this._traceLevelsHeaderPanel);
            this.panel1.Controls.Add(this.toolStrip1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(544, 54);
            this.panel1.TabIndex = 0;
            // 
            // _traceLevelsHeaderPanel
            // 
            this._traceLevelsHeaderPanel.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._traceLevelsHeaderPanel.Controls.Add(this._resetButton);
            this._traceLevelsHeaderPanel.Controls.Add(this._traceLevelsHeaderLabel);
            this._traceLevelsHeaderPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._traceLevelsHeaderPanel.Location = new System.Drawing.Point(0, 0);
            this._traceLevelsHeaderPanel.Name = "_traceLevelsHeaderPanel";
            this._traceLevelsHeaderPanel.Padding = new System.Windows.Forms.Padding(3);
            this._traceLevelsHeaderPanel.Size = new System.Drawing.Size(544, 29);
            this._traceLevelsHeaderPanel.TabIndex = 5;
            // 
            // _resetButton
            // 
            this._resetButton.BackColor = System.Drawing.SystemColors.Control;
            this._resetButton.Dock = System.Windows.Forms.DockStyle.Right;
            this._resetButton.Location = new System.Drawing.Point(466, 3);
            this._resetButton.Name = "_resetButton";
            this._resetButton.Size = new System.Drawing.Size(75, 23);
            this._resetButton.TabIndex = 4;
            this._resetButton.Text = "R&eset";
            this.toolTip1.SetToolTip(this._resetButton, "Removes all assembly trace switches.");
            this._resetButton.UseVisualStyleBackColor = false;
            this._resetButton.Click += new System.EventHandler(this._resetButton_Click);
            // 
            // _traceLevelsHeaderLabel
            // 
            this._traceLevelsHeaderLabel.BackColor = System.Drawing.Color.Transparent;
            this._traceLevelsHeaderLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._traceLevelsHeaderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._traceLevelsHeaderLabel.ForeColor = System.Drawing.SystemColors.Window;
            this._traceLevelsHeaderLabel.Location = new System.Drawing.Point(3, 3);
            this._traceLevelsHeaderLabel.Name = "_traceLevelsHeaderLabel";
            this._traceLevelsHeaderLabel.Size = new System.Drawing.Size(538, 23);
            this._traceLevelsHeaderLabel.TabIndex = 3;
            this._traceLevelsHeaderLabel.Text = "Assembly Trace Switch Levels";
            this._traceLevelsHeaderLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._importReferencesToolStripButton,
            this.toolStripSeparator5,
            this._setAllAssemblySwitchLevelsToolStripDropDownButton,
            this._deleteToolStripButton,
            this._addToolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 29);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(544, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // _importReferencesToolStripButton
            // 
            this._importReferencesToolStripButton.Image = global::TraceConfigTool.Properties.Resources.scanAssembly;
            this._importReferencesToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this._importReferencesToolStripButton.Name = "_importReferencesToolStripButton";
            this._importReferencesToolStripButton.Size = new System.Drawing.Size(120, 22);
            this._importReferencesToolStripButton.Text = "S&can References...";
            this._importReferencesToolStripButton.ToolTipText = "Scans a given assembly for all of its assembly references.  Adds assembly trace s" +
                "witches for every reference found.";
            this._importReferencesToolStripButton.Click += new System.EventHandler(this._importReferencesToolStripButton_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // _setAllAssemblySwitchLevelsToolStripDropDownButton
            // 
            this._setAllAssemblySwitchLevelsToolStripDropDownButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._setAllAssemblySwitchLevelsToolStripDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._offToolStripMenuItem,
            this._errorToolStripMenuItem,
            this._warningToolStripMenuItem,
            this._infoToolStripMenuItem,
            this._verboseToolStripMenuItem});
            this._setAllAssemblySwitchLevelsToolStripDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this._setAllAssemblySwitchLevelsToolStripDropDownButton.Name = "_setAllAssemblySwitchLevelsToolStripDropDownButton";
            this._setAllAssemblySwitchLevelsToolStripDropDownButton.Size = new System.Drawing.Size(117, 22);
            this._setAllAssemblySwitchLevelsToolStripDropDownButton.Text = "&Set All Switch &Levels";
            this._setAllAssemblySwitchLevelsToolStripDropDownButton.ToolTipText = "Change the trace switch level for all assembly switches.";
            // 
            // _offToolStripMenuItem
            // 
            this._offToolStripMenuItem.Name = "_offToolStripMenuItem";
            this._offToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this._offToolStripMenuItem.Text = "&Off";
            this._offToolStripMenuItem.Click += new System.EventHandler(this._offToolStripMenuItem_Click);
            // 
            // _errorToolStripMenuItem
            // 
            this._errorToolStripMenuItem.Name = "_errorToolStripMenuItem";
            this._errorToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this._errorToolStripMenuItem.Text = "&Error";
            this._errorToolStripMenuItem.Click += new System.EventHandler(this._errorToolStripMenuItem_Click);
            // 
            // _warningToolStripMenuItem
            // 
            this._warningToolStripMenuItem.Name = "_warningToolStripMenuItem";
            this._warningToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this._warningToolStripMenuItem.Text = "&Warning";
            this._warningToolStripMenuItem.Click += new System.EventHandler(this._warningToolStripMenuItem_Click);
            // 
            // _infoToolStripMenuItem
            // 
            this._infoToolStripMenuItem.Name = "_infoToolStripMenuItem";
            this._infoToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this._infoToolStripMenuItem.Text = "&Info";
            this._infoToolStripMenuItem.Click += new System.EventHandler(this._infoToolStripMenuItem_Click);
            // 
            // _verboseToolStripMenuItem
            // 
            this._verboseToolStripMenuItem.Name = "_verboseToolStripMenuItem";
            this._verboseToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this._verboseToolStripMenuItem.Text = "&Verbose";
            this._verboseToolStripMenuItem.Click += new System.EventHandler(this._verboseToolStripMenuItem_Click);
            // 
            // _deleteToolStripButton
            // 
            this._deleteToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this._deleteToolStripButton.Image = global::TraceConfigTool.Properties.Resources.removeAssembly;
            this._deleteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this._deleteToolStripButton.Name = "_deleteToolStripButton";
            this._deleteToolStripButton.Size = new System.Drawing.Size(100, 22);
            this._deleteToolStripButton.Text = "Remo&ve Switch";
            this._deleteToolStripButton.ToolTipText = "Remove the currently selected assembly trace switch.";
            this._deleteToolStripButton.Click += new System.EventHandler(this._deleteToolStripButton_Click);
            // 
            // _addToolStripButton
            // 
            this._addToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this._addToolStripButton.Image = global::TraceConfigTool.Properties.Resources.addAssembly;
            this._addToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this._addToolStripButton.Name = "_addToolStripButton";
            this._addToolStripButton.Size = new System.Drawing.Size(103, 22);
            this._addToolStripButton.Text = "A&dd Switches...";
            this._addToolStripButton.ToolTipText = "Add assembly trace switches for the assemblies you select.";
            this._addToolStripButton.Click += new System.EventHandler(this._addToolStripButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this._propertyGrid);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 54);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(3);
            this.panel2.Size = new System.Drawing.Size(544, 216);
            this.panel2.TabIndex = 1;
            // 
            // _propertyGrid
            // 
            this._propertyGrid.CommandsVisibleIfAvailable = false;
            this._propertyGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this._propertyGrid.Location = new System.Drawing.Point(3, 3);
            this._propertyGrid.Name = "_propertyGrid";
            this._propertyGrid.PropertySort = System.Windows.Forms.PropertySort.Alphabetical;
            this._propertyGrid.Size = new System.Drawing.Size(538, 210);
            this._propertyGrid.TabIndex = 3;
            this._propertyGrid.ToolbarVisible = false;
            this._propertyGrid.PropertyValueChanged += new System.Windows.Forms.PropertyValueChangedEventHandler(this._propertyGrid_PropertyValueChanged);
            // 
            // _importReferencesBackgroundWorker
            // 
            this._importReferencesBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this._importReferencesBackgroundWorker_DoWork);
            this._importReferencesBackgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this._importReferencesBackgroundWorker_RunWorkerCompleted);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.ReshowDelay = 100;
            // 
            // TraceSwitchesControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "TraceSwitchesControl";
            this.Size = new System.Drawing.Size(544, 270);
            this.Load += new System.EventHandler(this.TraceSwitchesControl_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this._traceLevelsHeaderPanel.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Label _traceLevelsHeaderLabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PropertyGrid _propertyGrid;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.ComponentModel.BackgroundWorker _importReferencesBackgroundWorker;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton _importReferencesToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripDropDownButton _setAllAssemblySwitchLevelsToolStripDropDownButton;
        private System.Windows.Forms.ToolStripButton _deleteToolStripButton;
        private System.Windows.Forms.ToolStripButton _addToolStripButton;
        private System.Windows.Forms.ToolStripMenuItem _offToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _errorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _warningToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _infoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _verboseToolStripMenuItem;
        private System.Windows.Forms.Button _resetButton;
        private System.Windows.Forms.Panel _traceLevelsHeaderPanel;
        private System.Windows.Forms.ToolTip toolTip1;

    }
}
