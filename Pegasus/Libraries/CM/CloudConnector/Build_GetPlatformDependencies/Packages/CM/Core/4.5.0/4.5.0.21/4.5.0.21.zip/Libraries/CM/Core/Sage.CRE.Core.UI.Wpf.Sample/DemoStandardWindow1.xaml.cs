﻿using Sage.CRE.Core.UI.Wpf.CustomWindow;

namespace Sage.CRE.Core.UI.Wpf.Sample
{
    /// <summary>
    /// Interaction logic for MyWindow.xaml
    /// </summary>
    public partial class DemoWindow1 : StandardWindow
    {
        public DemoWindow1()
        {
            InitializeComponent();
        }
    }
}
