﻿using System;
using Sage.Diagnostics;

namespace Sage.CRE.Core.SQL
{
    /// <summary>
    /// 
    /// </summary>
    public class Mutex : System.IDisposable
    {
        /// <summary>
        /// 
        /// </summary>
        [Flags]
        public enum LockLevel
        {
            /// <summary>
            /// 
            /// </summary>
            /// <remarks>
            /// This is default value the runtime automatically initializes any LockLevel instance to
            /// </remarks>
            Global = 0,
            /// <summary>
            /// 
            /// </summary>
            Domain = 1,
            /// <summary>
            /// 
            /// </summary>
            Machine = 2,
            /// <summary>
            /// 
            /// </summary>
            Application = 4,
            /// <summary>
            /// 
            /// </summary>
            User = 8,
            /// <summary>
            /// 
            /// </summary>
            SQLConnection = 16
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="name"></param>
        /// <param name="level"></param>
        /// <param name="acquire"></param>
        public Mutex(Sage.CRE.Core.SQL.SqlConnectionContext context, string name, LockLevel level, bool acquire)
            :this(context, name, level, acquire, "Security")
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="name"></param>
        /// <param name="level"></param>
        /// <param name="acquire"></param>
        /// <param name="schema"></param>
        public Mutex(Sage.CRE.Core.SQL.SqlConnectionContext context, string name, LockLevel level, bool acquire, String schema)
        {
            ArgumentValidator.ValidateNonNullReference(context, "context", String.Format("{0}.ctor()", typeof(Mutex).FullName));
            ArgumentValidator.ValidateNonEmptyString(name, "name", String.Format("{0}.ctor()", typeof(Mutex).FullName));
            ArgumentValidator.ValidateNonEmptyString(schema, "schema", String.Format("{0}.ctor()", typeof(Mutex).FullName));

            _context = context;
            _Name = name;
            _LockLevel = level;
            _schema = schema;

            if ((level & LockLevel.Domain)>0) _DomainName = System.Environment.UserDomainName;
            if ((level & LockLevel.Machine)>0) _MachineName = System.Environment.MachineName;
            if ((level & LockLevel.Application)>0) _ApplicationName = System.Diagnostics.Process.GetCurrentProcess().ProcessName;
            if ((level & LockLevel.User) > 0) _UserName = String.Format(@"{0}\{1}",System.Environment.UserDomainName,System.Environment.UserName);
            if ((level & LockLevel.SQLConnection) > 0) _UseConnectionID = true;

            // start thread to insert the record
            _thread = new System.Threading.Thread(new System.Threading.ThreadStart(insertRow));
            if (acquire)
            {
                Acquire();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void Acquire()
        {
            _thread.Start();
            _m2.WaitOne();
        }

        /// <summary>
        /// 
        /// </summary>
        public void Release()
        {
            _mutex.ReleaseMutex();
            if (_thread.ThreadState != System.Threading.ThreadState.Unstarted)
            {
                _thread.Join();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool Exists()
        {
            bool result = false;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_context.ConnectionString))
            {
                try
                {
                    connection.Open();

                    using (System.Data.SqlClient.SqlTransaction tran = connection.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
                    {
                        using (System.Data.SqlClient.SqlCommand command = connection.CreateCommand())
                        {
                            command.Transaction = tran;

                            try
                            {
                                command.CommandType = System.Data.CommandType.Text;

                                string whereClause = String.Format(@" WHERE [Name] = @Name");

                                if (!String.IsNullOrEmpty(_DomainName)) whereClause += String.Format(" AND ([DomainName] = @DomainName)");
                                if (!String.IsNullOrEmpty(_ApplicationName)) whereClause += String.Format(" AND ([ApplicationName] = @ApplicationName)");
                                if (!String.IsNullOrEmpty(_MachineName)) whereClause += String.Format(" AND ([MachineName] = @MachineName)");
                                if (!String.IsNullOrEmpty(_UserName)) whereClause += String.Format(" AND ([UserName] = @UserName)");
                                if (_UseConnectionID) whereClause += String.Format("AND ([ConnectionID] = @@SPID)");


                                command.CommandText = String.Format(@"SELECT COUNT(*) FROM [{0}].[Synchronizer] WITH (READUNCOMMITTED) {1}", _schema, whereClause);
                                command.CommandTimeout = 0;

                                command.Parameters.AddWithValue("Name", _Name);
                                command.Parameters.AddWithValue("DomainName", _DomainName);
                                command.Parameters.AddWithValue("MachineName", _MachineName);
                                command.Parameters.AddWithValue("ApplicationName", _ApplicationName);
                                command.Parameters.AddWithValue("UserName", _UserName);
                                command.Parameters.AddWithValue("UseConnectionID", _UseConnectionID);

                                int count = (int) command.ExecuteScalar();
                                result = (count > 0);
                            }
                            finally
                            {
                                tran.Rollback();
                            }
                        }
                    }
                }
                finally
                {
                    connection.Close();
                }
            }

            return result;
        }

        private void insertRow()
        {
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_context.ConnectionString))
            {
                try
                {
                    connection.Open();

                    using (System.Data.SqlClient.SqlTransaction tran = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                    {
                        using (System.Data.SqlClient.SqlCommand command = connection.CreateCommand())
                        {
                            command.Transaction = tran;

                            try
                            {
                                command.CommandType = System.Data.CommandType.StoredProcedure;
                                command.CommandText = String.Format(@"[{0}].[Synchronizer_Insert]", _schema);
                                command.CommandTimeout = 0;

                                command.Parameters.AddWithValue("Name", _Name);
                                command.Parameters.AddWithValue("DomainName", _DomainName);
                                command.Parameters.AddWithValue("MachineName", _MachineName);
                                command.Parameters.AddWithValue("ApplicationName", _ApplicationName);
                                command.Parameters.AddWithValue("UserName", _UserName);
                                command.Parameters.AddWithValue("UseConnectionID", _UseConnectionID);

                                command.ExecuteNonQuery();

                                _m2.Release();

                                _mutex.WaitOne();
                            }
                            catch (System.Threading.AbandonedMutexException)
                            {
                            }
                            finally
                            {
                                tran.Rollback();
                            }
                        }

                    }
                }
                finally
                {
                    connection.Close();
                    _m2.Release();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Release();
        }

        private string _Name = String.Empty;
        private LockLevel _LockLevel = LockLevel.Global;
        private String _schema = String.Empty;
        private string _DomainName = String.Empty;
        private string _MachineName = String.Empty;
        private string _ApplicationName = String.Empty;
        private string _UserName = String.Empty;
        private bool _UseConnectionID = false;

        private Sage.CRE.Core.SQL.SqlConnectionContext _context = null;

        private System.Threading.Thread _thread = null;
        private System.Threading.Mutex _mutex = new System.Threading.Mutex(true);
        private System.Threading.Semaphore _m2 = new System.Threading.Semaphore(0, 1);
    }
}