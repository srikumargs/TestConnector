﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sage
{
    public class MRU
    {
        public string Last = String.Empty;
        public List<string> List = new List<string>();

        public MRU()
        {
        }

        public void Serialize(System.IO.FileInfo file)
        {
            System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(this.GetType());
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(file.FullName))
            {
                x.Serialize(sw, this);
            }
        }
        
        public string Serialize()
        {
            System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(this.GetType());
            using (System.IO.StringWriter mem = new System.IO.StringWriter())
            {
                x.Serialize(mem, this);
                return mem.ToString();
            }
        }

        public static MRU Deserialize(System.IO.FileInfo file)
        {
            System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(typeof(MRU));
            using (System.IO.StreamReader sr = new System.IO.StreamReader(file.FullName))
            {
                return (MRU)x.Deserialize(sr);
            }
        }

        
        public static MRU Deserialize(string s)
        {
            System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(typeof(MRU));
            using (System.IO.StringReader sr = new System.IO.StringReader(s))
            {
                return (MRU)x.Deserialize(sr);
            }
        }
    }
}
