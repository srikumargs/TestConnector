using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Win32;

using Sage.IO;

namespace Sage.Configuration.Internal
{
    /// <summary>
    /// This path class contains information needed to resolve registry paths.
    /// </summary>
    internal sealed class RegistryUrlResolver : IUrlResolver
    {
        #region private fields
        /// <summary>
        /// Prefix of encoded registry stored paths
        /// </summary>
        private const string RegistryPathUrlPrefix = "registrypath://";
        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        public RegistryUrlResolver()
        {
        }

        #region IUrlResolver
        /// <summary>
        /// Determine if this is a registry url
        /// </summary>
        /// <param name="url">Url to examine</param>
        /// <returns>True if the url is a registry url, otherwise false</returns>
        public Boolean CanResolveUrl(string url)
        {
            string temp = url.ToLower();
            if (temp.StartsWith(RegistryPathUrlPrefix))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Resolves an URL that uses the registry path protocol to a file system reference.
        /// No guarantees are provided that the resolved path is valid in the file system.
        /// </summary>
        /// <remarks>
        /// A Paths URL has the form registrypath://context/path where path is a path relative to 
        /// one of the context folders and context is a key to a specific folder. 
        /// </remarks>
        /// <param name="url">Path to resolve.</param>
        /// <returns>A resolved path if a valid registry paths URL is provided otherwise the path unchanged</returns>
        public string ResolveUrl(string url)
        {
            string retval = url;
            int prefixSize = RegistryPathUrlPrefix.Length;
            
            string[] parts = url.Substring(prefixSize).Split(new char[] { '/', '\\' }, 2);
            string spec = null;
            if (parts.Length == 2)
            {
                spec = parts[1];
            }

            switch (parts[0].ToLower())
            {
                case "registry.classesroot":
                    retval = ParseRegistryKey(Registry.ClassesRoot, url, spec);
                    break;
                case "registry.currentconfig":
                    retval = ParseRegistryKey(Registry.CurrentConfig, url, spec);
                    break;
                case "registry.currentuser":
                    retval = ParseRegistryKey(Registry.CurrentUser, url, spec);
                    break;
                case "registry.dyndata":
                    retval = ParseRegistryKey(Registry.DynData, url, spec);
                    break;
                case "registry.localmachine":
                    retval = ParseRegistryKey(Registry.LocalMachine, url, spec);
                    break;
                case "registry.performancedata":
                    retval = ParseRegistryKey(Registry.PerformanceData, url, spec);
                    break;
                case "registry.users":
                    retval = ParseRegistryKey(Registry.Users, url, spec);
                    break;
                default:
                    throw new ArgumentException(Strings.SpecifiedRegistryKeyInvalid, parts[0]);
            }
            return PathUtils.StripTrailingSlash(retval);
        }

        /// <summary>
        /// This property equals true if the path object can encode urls
        /// </summary>
        public Boolean CanEncodeUrl
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Generate an encoded url (i.e. registrypath://context/path) from an url
        /// </summary>
        /// <param name="url">A url to encode</param>
        /// <returns>The encoded url if the method is able to encode it, otherwise the original url is returned</returns>
        public string EncodeUrl(string url)
        {
            throw new NotImplementedException();  
        }
        #endregion

        #region private helper methods
        /// <summary>
        /// Looks up the subkey default value or named value and returns the string
        /// path.  If there is no value the original url is returned
        /// </summary>
        /// <param name="key">The hive subkey</param>
        /// <param name="path">the original url</param>
        /// <param name="spec">the spec minus the url part</param>
        /// <returns></returns>
        private static string ParseRegistryKey(RegistryKey key, string path, string spec)
        {
            string valName = "";
            string retval = path;

            spec = spec.Replace("/", @"\");
            string[] keyAndName = spec.Split(':');

            // there is a key name
            if (keyAndName.Length == 2)
            {
                spec = keyAndName[0];
                valName = keyAndName[1];
            }

            RegistryKey subkey = key.OpenSubKey(spec);
            if (subkey != null)
            {
                string s = subkey.GetValue(valName) as string;
                if (s != null)
                {
                    retval = s;
                }
            }
            return PathUtils.StripTrailingSlash(retval);
        }
        #endregion
    }
}
