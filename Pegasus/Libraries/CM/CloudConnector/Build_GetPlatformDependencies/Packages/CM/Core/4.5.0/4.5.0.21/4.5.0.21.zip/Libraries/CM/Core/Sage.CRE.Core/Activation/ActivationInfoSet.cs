using System;

namespace Sage.Activation
{
    /// <summary>
    /// Possible types of activation information stored in an ActivationInfoSet
    /// </summary>
    public enum ActivationInfoType
    {
        /// <summary>
        /// Not initialized
        /// </summary>
        None,

        /// <summary>
        /// Activation information for a Managed .Netcomponent
        /// </summary>
        Managed,

        /// <summary>
        /// Activation information for a COM component
        /// </summary>
        COM,

        /// <summary>
        /// Information for a serialized component
        /// </summary>
        Serialization
    }

	/// <summary>
	/// Summary description for ActivationInfoSet.
	/// </summary>
	public class ActivationInfoSet
	{
        // The type of activation that information is stored for
        ActivationInfoType _activationType = ActivationInfoType.None;

        // Activation parameters
        private string _assembly = null;
        private string _type = null;
        private string _codebase = null;

        /// <summary>
        /// Constructor
        /// </summary>
		public ActivationInfoSet()
		{
		    
		}

        /// <summary>
        /// Set the activation information for a Managed .Net component
        /// </summary>
        /// <param name="assembly">The components assembly</param>
        /// <param name="type">The components type</param>
        /// <param name="codebase">The location of the assemblies codebase</param>
        public void SetManagedActivationInfo( string assembly, string type, string codebase )
        {
            _activationType = ActivationInfoType.Managed;
            _param1 = assembly;
            _param2 = type;
            _param3 = codebase;
        }

        /// <summary>
        /// Set the activation information for a COM component
        /// </summary>
        /// <param name="progId">The component's ProgID</param>
        public void SetCOMActivationInfo( string progId )
        {
            _activationType = ActivationInfoType.COM;
            _param1 = progId;
        }

        /// <summary>
        /// Set the location of a serialization file to use when constructing a managed component
        /// </summary>
        /// <param name="serializationFile">The path to a serialization file</param>
        public void SetSerializationActivationInfo( string assembly, string type, string codebase, string serializationFile )
        {
            _activationType = ActivationInfoType.Serialization;
            _param1 = serializationFile;
        
        }

        /// <summary>
        /// Retrieve the type of the activation info
        /// </summary>
        public ActivationInfoType ActivationType
        {
            get{ return _type; }
        }

        

	}
}
