﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sage.Configuration
{
    public class PerUserMRU
    {
        private string _name = String.Empty;
        private string _filename = String.Empty;

        private MRU _MRU = new MRU();

        public PerUserMRU(string name)
        {
            _name = name;
            
#if !CORE_INSTALL
            _filename = LibraryManager.UserConfigLocation;
#else
            _filename = Path.Combine(System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Sage");
#endif

            System.IO.Directory.CreateDirectory(_filename);
            _filename = System.IO.Path.Combine(_filename, String.Format(@"{0}.xml",_name));
            
        }

        public string Name
        {
            get
            {
                return _name;
            }
        }

        public List<string> List
        {
            get { return _MRU.List; }
        }

        public string Last
        {
            get { return _MRU.Last; }
            set { _MRU.Last = value; }
        }

        public void Write()
        {
            try
            {
                _MRU.Serialize(new System.IO.FileInfo(_filename));
            }
            catch (System.Exception x)
            {
                System.Diagnostics.Debug.WriteLine(x.Message);
            }
        }


        public void Read()
        {
            if (System.IO.File.Exists(_filename))
            {
                try
                {
                    _MRU = MRU.Deserialize(new System.IO.FileInfo(_filename));
                }
                catch (System.Exception x)
                {
                    System.Diagnostics.Debug.WriteLine(x.Message);
                }
            }
        }

    }
}
