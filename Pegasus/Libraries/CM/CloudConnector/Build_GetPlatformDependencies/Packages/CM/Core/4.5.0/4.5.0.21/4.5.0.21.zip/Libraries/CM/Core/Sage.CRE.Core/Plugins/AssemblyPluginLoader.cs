﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Collections.ObjectModel;
using System.IO;
using Sage.Diagnostics;

namespace Sage.Plugins
{
    public static class AssemblyPluginLoader
    {
        public static IList<Assembly> LoadPluginAssemblies(String configurationFileFolderPath)
        {
            List<Assembly> assemblies = new List<Assembly>();

            ReadOnlyCollection<String> assemblyNames = AssemblyPluginConfigurationReader.GetAssemblyNames(configurationFileFolderPath);

            // add-in the late-bound checks
            foreach (String assemblyPathOrFullName in assemblyNames)
            {
                VerboseTrace.WriteLine(null, "LoadPluginAssemblies - working on assembly {0}", assemblyPathOrFullName);
                try
                {
                    // Load candidate assemblies
                    Assembly checkAssembly = null;
                    if (File.Exists(assemblyPathOrFullName))
                    {
                        VerboseTrace.WriteLine(null, "LoadPluginAssemblies - assembly found at specified path.");
                        checkAssembly = Assembly.LoadFile(assemblyPathOrFullName);
                    }
                    else
                    {
                        VerboseTrace.WriteLine(null, "LoadPluginAssemblies - assembly not found at specified path.");
                        checkAssembly = Assembly.Load(assemblyPathOrFullName);
                    }
                    if (checkAssembly != null)
                    {
                        VerboseTrace.WriteLine(null, "LoadPluginAssemblies - assembly {0} was loaded.", checkAssembly.FullName);
                        assemblies.Add(checkAssembly);
                    }
                }
                catch (Exception ex)
                {
                    WarningTrace.WriteLine(null, Internal.Strings.PluginAssemblyLoadFailedFormat, assemblyPathOrFullName, ex.Message);
                }
            }

            return assemblies;
        }
    }
}
