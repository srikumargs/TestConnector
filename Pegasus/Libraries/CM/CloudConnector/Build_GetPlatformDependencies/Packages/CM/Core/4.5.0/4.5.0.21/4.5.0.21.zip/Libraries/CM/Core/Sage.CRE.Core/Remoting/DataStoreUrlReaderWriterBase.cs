using System;
using System.Runtime.InteropServices;

namespace Sage.Remoting
{
	
    /// <summary>
    /// Common base 
    /// </summary>
    [ComVisible(false)]
    public class DataStoreUrlReaderWriterBase
    {

        // How to munge the Uri with an identifier
        private IFormatter _formatter;
         
        // Data Store application name
        private string _dataStoreApplication = "Remoting";

        // Data Store table name
        private const string _dataStoreTable = "URLs";

        // Data Store dataPath
        private const string _dataStoreDataPath = "RegisteredURLs";

        /// <summary>
        /// By default, don't munge the input Uri lookup
        /// </summary>
        protected DataStoreUrlReaderWriterBase()
        {
            _formatter = new NullFormatter();
        }

        /// <summary>
        /// Set the uri factory
        /// </summary>
        /// <param name="formatter"></param>
        protected DataStoreUrlReaderWriterBase(IFormatter formatter)
        {
            _formatter = formatter;
        }


        /// <summary>
        /// Get/Set the DataStore Application Name
        /// </summary>
        protected string DataStoreApplication
        {
            get{ return _dataStoreApplication; }
            set
            { 
                if( value != null && value.Length > 0 )
                {
                    _dataStoreApplication = value;  
                } 
            }
        }

        /// <summary>
        /// Get the DataStore DataTable name
        /// </summary>
        protected string DataStoreTable
        {
            get{ return _dataStoreTable; }
        }
        
        /// <summary>
        /// Get the DataTable datapath
        /// </summary>
        protected string DataStorePath
        {
            get{ return _dataStoreDataPath; }
        }
        
        /// <summary>
        /// Optional to set the Uri munging policy
        /// </summary>
        public IFormatter Formatter
        {
            set { _formatter = value; }
            get { return _formatter;  }
        }

        /// <summary>
        /// optional call
        /// </summary>
        /// <param name="configNode">The config node to store the data under</param>
        public void Open(string configNode )
        {
            DataStoreApplication = configNode;
        }

        /// <summary>
        /// no-op part of the interface
        /// </summary>
        public void Close()
        {
        }
    }

}
