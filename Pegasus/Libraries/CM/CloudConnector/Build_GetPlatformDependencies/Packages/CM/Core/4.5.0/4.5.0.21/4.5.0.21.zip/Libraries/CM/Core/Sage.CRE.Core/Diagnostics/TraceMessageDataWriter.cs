using System;
using System.Runtime.InteropServices;

using Sage.Xml;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Encodes and writestrace message data in a format read by <see cref="Sage.Diagnostics.TraceMessageDataReader"/>.
    /// </summary>
    /// <remarks>
    /// Should be used in conjunction with <see cref="Sage.Diagnostics.TraceMessageDataReader"/>.
    /// </remarks>
    [ComVisible(false)]
    public class TraceMessageDataWriter
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the TraceMessageDataWriter class.
        /// </summary>
        public TraceMessageDataWriter()
        {}
        #endregion

        #region Public properties
        /// <summary>
        /// The encoded trace message content.
        /// </summary>
        public string Message
        {
            get
            {
                return _message;
            }
            set
            {
                _message = value;
            }
        }
        #endregion

        #region Public members
        /// <summary>
        /// Clears all message data.
        /// </summary>
        public void Clear()
        {
            _message = string.Empty;
            _messageData.Clear();
        }

        /// <summary>
        /// Adds a data element with the specified name and value into the encoded message data. 
        /// </summary>
        /// <param name="name">The name of the data element to add. </param>
        /// <param name="dataValue">The value of the data element to add.</param>
        public void AddData(string name, object dataValue)
        {
            _messageData.Add(name, dataValue);
        }

        /// <summary>
        /// Returns a String that represents the current Object.
        /// </summary>
        /// <returns>A String that represents the current Object.</returns>
        public override string ToString()
        {
            // keeping the XML tags very terse in order to minimize the overhead
            //   TM - TraceMessage
            //   M  - Message
            //   MD - MessageData
            //   D  - Data
            //   n  - name

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendFormat("<TM><M>{0}</M><MD>", XmlStringEscape.Escape(_message));
            foreach(System.Collections.DictionaryEntry de in _messageData)
            {
                sb.AppendFormat("<D n='{0}'>{1}</D>", XmlStringEscape.Escape(de.Key.ToString()), XmlStringEscape.Escape(de.Value.ToString()));
            }
            sb.Append("</MD></TM>");
            return sb.ToString();
        }
        #endregion

        #region Private fields
        private string                          _message;       // = null; (automatically initialized by runtime)
        private System.Collections.Hashtable    _messageData    = new System.Collections.Hashtable();
        #endregion
    }
}
