using System;
using System.Collections.Generic;
using System.Text;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Create an error message from the exception message and any inner exceptions.
    /// </summary>
    public static class ExceptionMessage
    {
        /// <summary>
        /// Creates an error message from the exception and any inner exceptions.
        /// </summary>
        /// <param name="ex">The exception from which to generate the message.
        /// The default format string is "{0}" and the default separator string is
        /// ":" plus a line break.</param>
        /// <returns>A string with the exception messages.</returns>
        public static String Create( Exception ex )
        {
            String separator = String.Format(
                System.Globalization.CultureInfo.CurrentCulture,
                Strings.ExceptionMessageSeparatorFormat, Environment.NewLine);
            return Create( ex, Strings.ExceptionMessageFormatterFormat, separator );
        }

        // Creates an error message from the exception and any inner exceptions.

        /// <summary>
        /// Creates an error message from the exception and any inner exceptions.
        /// </summary>
        /// <param name="ex">The exception from which to generate the message</param>
        /// <param name="exFormatString">A format string to use with the actual error message.  This 
        /// string needs to include a "{0}" in it somewhere for the actual exception message.</param>
        /// <param name="separatorString">The string to use between each exception; typically this is 
        /// just Environment.NewLine.</param>
        /// <returns>A string with the exception messages.</returns>
        public static String Create( Exception ex, String exFormatString, String separatorString )
        {
            Sage.Diagnostics.ArgumentValidator.ValidateNonNullReference( ex, "ex", typeof( ExceptionMessage ).FullName );
            Sage.Diagnostics.ArgumentValidator.ValidateNonEmptyString( exFormatString, "exFormatString", typeof( ExceptionMessage ).FullName );
            Sage.Diagnostics.ArgumentValidator.ValidateNonEmptyString( separatorString, "separatorString", typeof( ExceptionMessage ).FullName );
            StringBuilder sb = new StringBuilder();
            Exception x = ex;
            while( x != null )
            {
                if( !String.IsNullOrEmpty( sb.ToString() ) )
                {
                    sb.Append(separatorString);
                }
                sb.Append(
                    String.Format(
                        System.Globalization.CultureInfo.InvariantCulture,
                        exFormatString,
                        x.Message ) );
                x = x.InnerException;
            }
            return sb.ToString();
        }
    
    }
}
