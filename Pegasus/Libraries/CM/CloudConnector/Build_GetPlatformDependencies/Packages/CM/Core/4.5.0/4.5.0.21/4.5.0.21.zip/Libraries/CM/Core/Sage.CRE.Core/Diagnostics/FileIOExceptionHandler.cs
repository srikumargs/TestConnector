using System;
using System.Collections.Generic;
using System.Text;
using Sage.Diagnostics;
using System.IO;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Use this exception handler to handle errors returned from file system IO.  This should 
    /// include errors that are user-friendly and that users can do something about.  For example 
    /// users can verify a file path (FileNotFoundException) but wouldn't know what to do about 
    /// an EndOfStreamException.
    /// </summary>
    /// <remarks>
    /// To use an ExceptionHandler, like the FileIOExceptionHandler, from UI code do the following:
    /// 1) In your UI code surround the segment of code which could throw file IO exceptions with try/catch
    /// Your catch block should look something like this
    /// catch (Exception e)
    /// {
    ///     Boolean handled = false;
    ///     if (e.Data.Contains(Sage.AOF.Constants.FileIOExceptionHandler))
    ///     {
    ///         IReportErrorExceptionHandler handler = e.Data[Sage.AOF.Constants.DataAccessExceptionHandler] as IReportErrorExceptionHandler;
    ///         handled = handler.HandleException(e, "My Dialog", new ReportError(TaskMessageBox.ReportError));
    ///     }
    ///     if (!handled)
    ///     {
    ///         Sage.Diagnostics.ErrorTrace.WriteLine(null, "Unexpected exception, {0}. {1}", e.GetType().ToString(), e.Message);
    ///         throw;
    ///     }
    /// }
    /// </remarks>
    [Serializable]
    public class FileIOExceptionHandler : ReportErrorExceptionHandler
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="FileIOExceptionHandler"/> class.
        /// </summary>
        /// <param name="errorSummary">The error summary to use in the ErrorInfo.</param>
        public FileIOExceptionHandler( String errorSummary )
            : base()
        {
            ErrorSummary = errorSummary;
            AddHandledExceptions();
        }

        private void AddHandledExceptions()
        {
            base.AddHandledException( typeof( DirectoryNotFoundException ), Action.DebugOut | Action.Delegate, new CustomHandler( ReportException ) );
            //base.AddHandledException( typeof( FileLoadException ), Action.DebugOut | Action.Delegate, new CustomHandler( ReportException ) );
            base.AddHandledException( typeof( FileNotFoundException ), Action.DebugOut | Action.Delegate, new CustomHandler( ReportException ) );
            base.AddHandledException( typeof( PathTooLongException ), Action.DebugOut | Action.Delegate, new CustomHandler( ReportException ) );
        }

        /// <summary>
        /// Gets the name of this exception handler for use with associated exception handler classes.
        /// </summary>
        /// <value>The name.</value>
        public static String Name 
        {
            get { return "FileIOExceptionHandler"; }
        }

        private String _errorSummary;

        /// <summary>
        /// The error summary used in the ErrorInfo object.  Typically this is a task or action name.
        /// </summary>
        /// <value>The error summary.</value>
        public String ErrorSummary
        {
            get { return _errorSummary; }
            set { _errorSummary = value; }
        }

        /// <summary>
        /// This method translates the Exceptions into an ErrorInfo object.
        /// ErrorInfo objects contain user consumable strings.
        /// </summary>
        /// <param name="e">The exception to translate</param>
        /// <param name="errorInfo">The error info object to populate</param>
        protected override void TranslateExceptionToErrorInfo( Exception e, ref ExceptionErrorInfo errorInfo )
        {
            errorInfo.ErrorSummary = ErrorSummary;
            errorInfo.ErrorDetails = e.Message;

            // The exception that is thrown when part of a file or directory cannot be found.
            DirectoryNotFoundException dnf = e as DirectoryNotFoundException;
            //The exception that is thrown when an attempt is made to access a file that does not exist.
            FileNotFoundException fnf = e as FileNotFoundException;
            if( dnf != null || fnf != null )
            {
                errorInfo.ErrorDetails += Environment.NewLine + Strings.FileOrDirectoryNotFoundExceptionContent;
                return;
            }
            
            //The exception that is thrown when a managed assembly is found but cannot be loaded.
            //FileLoadException; 

            // The exception that is thrown when a pathname or filename is longer than the system-defined maximum length.
            PathTooLongException ptl = e as PathTooLongException;
            if (ptl != null)
            {
                errorInfo.ErrorDetails += Environment.NewLine + Strings.PathTooLongExceptionContent;
                return;
            }

        }

    }
}
