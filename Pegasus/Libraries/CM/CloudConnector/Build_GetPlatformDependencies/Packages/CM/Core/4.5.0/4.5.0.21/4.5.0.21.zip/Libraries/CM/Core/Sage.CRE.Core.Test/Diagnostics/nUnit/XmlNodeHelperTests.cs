#if DEBUG
using NUnit.Framework;
using System;
using System.Runtime.InteropServices;
using System.Configuration;

namespace Sage.Diagnostics.NUnit
{
    /// <summary>
    /// Class for testing the XmlNodeHelper class
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public sealed class XmlNodeHelperTests
    {
        static XmlNodeHelperTests()
        {
            //Sage.Configuration.LibraryManager.InitializeLibraries(
            //    System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory,
            //        Sage.Configuration.LibraryManager.LibraryManifestFolderName ) );
        }

        /// <summary>
        /// Test fixture set up.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixtureSetUp()
        {
            _document = new System.Xml.XmlDocument();
            _document.LoadXml(string.Format(XML_TO_FORMAT, new object[]{INT32_VALUE_NAME, INT32_VALUE, ENUM_VALUE_NAME, ENUM_VALUE, STRING_VALUE_NAME, STRING_VALUE, BOOL_VALUE_NAME, BOOL_VALUE}));
            _node = _document.SelectSingleNode("//node1");
            Console.WriteLine(_node.OuterXml);
        }

        /// <summary>
        /// Test fixture tear down.
        /// </summary>
        [TestFixtureTearDown]
        public void TestFixtureTearDown()
        {
            _document = null;
            _node = null;
        }

        /// <summary>
        /// Test XmlNodeHelper.GetInt32AttributeValue passing a valid attribute name.
        /// </summary>
        [Test]
        public void TestGetInt32AttributeValueWithValidName()
        {
            int result = XmlNodeHelper.GetInt32AttributeValue(_node, INT32_VALUE_NAME);
            Assert.AreEqual(INT32_VALUE, result);
        }

        /// <summary>
        /// Test XmlNodeHelper.GetEnumAttributeValue passing a valid attribute name.
        /// </summary>
        [Test]
        public void TestGetEnumAttributeValueWithValidName()
        {
            int result = XmlNodeHelper.GetEnumAttributeValue(_node, ENUM_VALUE_NAME, typeof(Color));
            Assert.AreEqual(ENUM_VALUE, (Color) result);
        }

        /// <summary>
        /// Test XmlNodeHelper.GetStringAttributeValue passing a valid attribute name.
        /// </summary>
        [Test]
        public void TestGetStringAttributeValueWithValidName()
        {
            string result = XmlNodeHelper.GetStringAttributeValue(_node, STRING_VALUE_NAME);
            Assert.AreEqual(STRING_VALUE, result);
        }

        /// <summary>
        /// Test XmlNodeHelper.GetBoolAttributeValue passing a valid attribute name.
        /// </summary>
        [Test]
        public void TestGetBoolAttributeValueWithValidName()
        {
            bool result = XmlNodeHelper.GetBoolAttributeValue(_node, BOOL_VALUE_NAME);
            Assert.AreEqual(BOOL_VALUE, result);
        }

        /// <summary>
        /// Test XmlNodeHelper.GetInt32AttributeValue passing an invalid attribute name.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestGetInt32AttributeValueWithInvalidName()
        {
            int result = XmlNodeHelper.GetInt32AttributeValue(_node, "_" + INT32_VALUE_NAME);
            Assert.AreEqual(INT32_VALUE, result);
        }

        /// <summary>
        /// Test XmlNodeHelper.GetEnumAttributeValue passing an invalid attribute name.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestGetEnumAttributeValueWithInvalidName()
        {
            int result = XmlNodeHelper.GetEnumAttributeValue(_node, "_" + ENUM_VALUE_NAME, typeof(Color));
            Assert.AreEqual(ENUM_VALUE, (Color) result);
        }

        /// <summary>
        /// Test XmlNodeHelper.GetStringAttributeValue passing an invalid attribute name.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestGetStringAttributeValueWithInvalidName()
        {
            string result = XmlNodeHelper.GetStringAttributeValue(_node, "_" + STRING_VALUE_NAME);
            Assert.AreEqual(STRING_VALUE, result);
        }

        /// <summary>
        /// Test XmlNodeHelper.GetBoolAttributeValue passing an invalid attribute name.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestGetBoolAttributeValueWithInvalidName()
        {
            bool result = XmlNodeHelper.GetBoolAttributeValue(_node, "_" + BOOL_VALUE_NAME);
            Assert.AreEqual(BOOL_VALUE, result);
        }

        private enum Color
        {
            Red,
            Blue,
            Green
        }

        private static readonly string  XML_TO_FORMAT       = @"<doc><node1 {0}='{1}' {2}='{3}' {4}='{5}' {6}='{7}'/></doc>";
        private static readonly string  INT32_VALUE_NAME    = "intvalue";
        private static readonly int     INT32_VALUE         = 123;
        private static readonly string  ENUM_VALUE_NAME     = "enumvalue";
        private static readonly Color   ENUM_VALUE          = Color.Green;
        private static readonly string  STRING_VALUE_NAME   = "stringvalue";
        private static readonly string  STRING_VALUE        = "HELLO WORLD!";
        private static readonly string  BOOL_VALUE_NAME     = "boolvalue";
        private static readonly bool    BOOL_VALUE          = true;
        
        private static System.Xml.XmlDocument _document;
        private static System.Xml.XmlNode     _node;
    }
}
#endif