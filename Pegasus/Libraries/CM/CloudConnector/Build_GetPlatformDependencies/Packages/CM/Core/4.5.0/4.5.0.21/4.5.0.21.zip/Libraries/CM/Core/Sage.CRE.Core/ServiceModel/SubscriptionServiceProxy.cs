﻿using System;
using System.ServiceModel;
using Sage.SystemModel;

namespace Sage.ServiceModel
{
    /// <summary>
    /// 
    /// </summary>
    public class SubscriptionServiceProxy<TSubcriptionInterface> : DuplexClientBase<TSubcriptionInterface>
        where TSubcriptionInterface : class, ISubscriptionService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputInstance"></param>
        public SubscriptionServiceProxy(InstanceContext inputInstance)
            : base(inputInstance)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputInstance"></param>
        /// <param name="endpointConfigurationName"></param>
        public SubscriptionServiceProxy(InstanceContext inputInstance, String endpointConfigurationName)
            : base(inputInstance, endpointConfigurationName)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputInstance"></param>
        /// <param name="endpointConfigurationName"></param>
        /// <param name="remoteAddress"></param>
        public SubscriptionServiceProxy(InstanceContext inputInstance, String endpointConfigurationName, String remoteAddress)
            : base(inputInstance, endpointConfigurationName, remoteAddress)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputInstance"></param>
        /// <param name="endpointConfigurationName"></param>
        /// <param name="remoteAddress"></param>
        public SubscriptionServiceProxy(InstanceContext inputInstance, String endpointConfigurationName, EndpointAddress remoteAddress)
            : base(inputInstance, endpointConfigurationName, remoteAddress)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputInstance"></param>
        /// <param name="binding"></param>
        /// <param name="remoteAddress"></param>
        public SubscriptionServiceProxy(InstanceContext inputInstance, System.ServiceModel.Channels.Binding binding, EndpointAddress remoteAddress)
            : base(inputInstance, binding, remoteAddress)
        { }

        /// <summary>
        /// The minimum amount of time (in milliseconds) to wait between KeepAlives
        /// </summary>
        public Int32 MinimumKeepAliveInterval
        {
            get { return _minimumKeepAliveInterval; }
            set { _minimumKeepAliveInterval = value; }
        }

        /// <summary>
        /// The maximum amount of time (in milliseconds) to wait between KeepAlives
        /// </summary>
        public Int32 MaximumKeepAliveInterval
        {
            get { return _maximumKeepAliveInterval; }
            set { _maximumKeepAliveInterval = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public void Connect()
        {
            lock (_syncRoot)
            {
                Channel.Connect();
                _random = new Random(System.Diagnostics.Process.GetCurrentProcess().Id);
                _timer = new System.Timers.Timer(_random.Next(_minimumKeepAliveInterval, _maximumKeepAliveInterval));
                _timer.Elapsed += TimerElapsed;
                _timer.AutoReset = false;
                _timer.Start();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventOperation"></param>
        public void Subscribe(string eventOperation)
        {
            lock (_syncRoot)
            {
                Channel.Subscribe(eventOperation);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventOperation"></param>
        public void Unsubscribe(string eventOperation)
        {
            lock (_syncRoot)
            {
                Channel.Unsubscribe(eventOperation);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void KeepAlive()
        {
            lock (_syncRoot)
            {
                Channel.KeepAlive();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void Disconnect()
        {
            lock (_syncRoot)
            {
                _timer.Stop();
                _timer.Dispose();
                _timer = null;
                _random = null;

                Channel.Disconnect();
            }
        }

        private void TimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            lock (_syncRoot)
            {
                if (_timer != null)
                {
                    _timer.Stop();
                    try
                    {
                        KeepAlive();
                    }
                    finally
                    {
                        _timer.Interval = _random.Next(_minimumKeepAliveInterval, _maximumKeepAliveInterval);
                        _timer.Start();
                    }
                }
            }
        }

        private readonly Object _syncRoot = new Object();
        private System.Timers.Timer _timer;
        private System.Random _random;
        private Int32 _minimumKeepAliveInterval = 1 * 60 * 1000; // 1 minute
        private Int32 _maximumKeepAliveInterval = 5 * 60 * 1000; // 5 minutes
    }

}
