using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;

namespace Sage.IO.ReversibleAction.Tests
{
    /// <summary>
    /// Tests complex Reversible File System actions.
    /// </summary>
    [TestFixture]
    public class ComplexOperations
    {
        /// <summary>
        /// Tests reversing the creation of a directory.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification="NUnit requirement.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "Not applicable to unit tests.")]
        [Test]
        public void DirectoryCreate_Reverse()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryCreate_Reverse");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName);
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(dirName));
            }
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }

        /// <summary>
        /// Tests creation of a directory.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic",Justification="NUnit requirement.")]
        [Test]
        public void DirectoryCreate_Commit()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryCreate_Commit");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName);
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(dirName));
                dirCreate.Commit();
            }
            Assert.IsTrue(System.IO.Directory.Exists(dirName));

            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);
        }

        /// <summary>
        /// Test the reversal of a directory create action due to an exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification="NUnit requirement.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Not applicable to unit tests.")]
        [Test]
        public void DirectoryCreate_ExceptionReverse()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryCreate_ExceptionReverse");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName);
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            try
            {
                using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
                {
                    dirCreate.Forward();
                    Assert.IsTrue(System.IO.Directory.Exists(dirName));
                    throw new System.Exception();
                    //dirCreate.Commit();
                }
                //Assert.IsTrue(System.IO.Directory.Exists(dirName));
            }
            catch
            {
                Assert.IsFalse(System.IO.Directory.Exists(dirName));
            }
        }

        /// <summary>
        /// Tests the reversal of a directory create action due to the desired directory already existing.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification="NUnit requirement.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Not applicable to unit tests.")]
        [Test]
        public void DirectoryCreate_ExistingDirectory()
        {
            string dirName = System.Environment.CurrentDirectory;
            try
            {
                Assert.IsTrue(System.IO.Directory.Exists(dirName));
                using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
                {
                    dirCreate.Forward();
                    throw new System.Exception();
                }
            }
            catch
            {
                Assert.IsTrue(System.IO.Directory.Exists(dirName));
            }
        }

        /// <summary>
        /// Tests the reversal of a directory create action due to the path of the desired directory being too long.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic",Justification="NUnit requirement.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "Not applicable to unit tests.")]
        [Test]
        public void DirectoryCreate_PathTooLong()
        {
            string dirName = new String('X', 260);
            try
            {
                using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
                {
                    dirCreate.Forward();
                    Assert.Fail("Created a directory with 260 characters");
                }
            }
            catch (System.IO.PathTooLongException)
            {
            }

        }

        /// <summary>
        /// Tests the Forward and reverse methods of a DirectoryCreate action.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requirement.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification="Not applicable to unit tests.")]
        [Test]
        public void DirectoryCreate_BackAndForth()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryCreate_BackAndForth");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(dirName));

            DirectoryCreate dirCreate = new DirectoryCreate(dirName);
            dirCreate.Forward();
            Assert.IsTrue(System.IO.Directory.Exists(dirName));

            dirCreate.Reverse();
            Assert.IsFalse(System.IO.Directory.Exists(dirName));

            dirCreate.Forward();
            Assert.IsTrue(System.IO.Directory.Exists(dirName));

            dirCreate.Reverse();
            Assert.IsFalse(System.IO.Directory.Exists(dirName));

            dirCreate.Forward();
            Assert.IsTrue(System.IO.Directory.Exists(dirName));

            dirCreate.Dispose();
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }

        /// <summary>
        /// Test the reversal of a DirectoryCopy action.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode",Justification="Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requirement.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores",Justification="Not applicable to unit tests.")]
        [Test]
        public void DirectoryCopy_Reverse()
        {
            string srcDirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryCopy_ReverseSource");
            if (System.IO.Directory.Exists(srcDirName)) System.IO.Directory.Delete(srcDirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(srcDirName));
            using (DirectoryCreate dirCreate = new DirectoryCreate(srcDirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(srcDirName));

                string fileName = System.IO.Path.Combine(srcDirName, System.DateTime.Now.ToFileTimeUtc().ToString(System.Globalization.CultureInfo.InvariantCulture));

                Assert.IsFalse(System.IO.File.Exists(fileName));
                using (FileCreate fileCreate = new FileCreate(fileName))
                {
                    fileCreate.Forward();
                    Assert.IsTrue(System.IO.File.Exists(fileName));

                    string destDirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryCopy_ReverseDest");

                    Assert.IsFalse(System.IO.Directory.Exists(destDirName));
                    using (DirectoryCreate destDirCreate = new DirectoryCreate(destDirName))
                    {
                        destDirCreate.Forward();
                        Assert.IsTrue(System.IO.Directory.Exists(destDirName));

                        string copiedFile = System.IO.Path.Combine(System.IO.Path.Combine(destDirName, System.IO.Path.GetFileName(srcDirName)), System.IO.Path.GetFileName(fileName));
                        Assert.IsFalse(System.IO.File.Exists(copiedFile));
                        Assert.IsTrue(System.IO.Directory.GetDirectories(destDirName).Length == 0);
                        Assert.IsTrue(System.IO.Directory.GetFiles(destDirName).Length == 0);
                        using (DirectoryCopy dirCopy = new DirectoryCopy(srcDirName, destDirName))
                        {
                            dirCopy.Forward();
                            Assert.IsTrue(System.IO.File.Exists(copiedFile));
                        }
                        Assert.IsFalse(System.IO.File.Exists(copiedFile));
                        Assert.IsTrue(System.IO.Directory.GetDirectories(destDirName).Length == 0);
                        Assert.IsTrue(System.IO.Directory.GetFiles(destDirName).Length == 0);
                    }
                    Assert.IsFalse(System.IO.Directory.Exists(destDirName));

                }
                Assert.IsFalse(System.IO.File.Exists(fileName));

            }
            Assert.IsFalse(System.IO.Directory.Exists(srcDirName));
            
        }

        /// <summary>
        /// Tests the reversal of a DirectoryCopy action due to an invalid destination.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode",Justification="Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores")]
        [Test]
        public void DirectoryCopy_InvalidDestination()
        {
            string srcDir = System.Environment.CurrentDirectory;
            string destDir = String.Format(System.Globalization.CultureInfo.InvariantCulture,@"X:\{0}",System.Guid.NewGuid().ToString());

            try
            {
                DirectoryCopy dirCopy = new DirectoryCopy(srcDir, destDir);
                dirCopy.Forward();
                Assert.Fail("DirectoryCopy to invalid destination.");
            }
            catch (System.IO.DirectoryNotFoundException)
            {

            }
        }
    }
}
