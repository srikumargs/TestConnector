using System;
using System.Runtime.InteropServices;

namespace Sage.Reflection
{
    /// <summary>
    /// Generic property accessor interface used by the BaseTask implementation.
    /// Precludes the need for strongly typed properties on derived classes
    /// </summary>
    [ComVisible(false)]
    public interface INamedProperty
    {
        /// <summary>
        /// set a given property value by name
        /// </summary>
        /// <param name="propName">the string property name</param>
        /// <param name="val">the actual value</param>
        void SetPropertyValue(string propName, object val);

        /// <summary>
        /// get the given property value
        /// </summary>
        /// <param name="propName">the string property name</param>
        /// <returns>the value as object</returns>
        object GetPropertyValue(string propName);

        /// <summary>
        /// Is the given property implemented on the object
        /// </summary>
        /// <param name="propName">the string property name</param>
        /// <returns>true if exists</returns>
        bool HasProperty(string propName);
    }
}
