using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Xml.XPath;
using Sage.Activation;
using Sage.Configuration.Internal;
using Sage.IO;
using Sage.CM.Core.LinkedSource;

namespace Sage.Configuration
{
    /// <summary>
    /// The PathRegistrar class is used to register, unregister and lookup registered paths.
    /// </summary>
    public class PathRegistrar : IPathRegistrar, IPathResolver
    {
        #region Fields
        static private List<IUrlResolver> _urlResolvers = new List<IUrlResolver>();
        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        public PathRegistrar()
        { }

        /// <summary>
        /// Register a path with the path registrar helper
        /// </summary>
        /// <param name="key">A key used to identify the path</param>
        /// <param name="path">The path to register</param>
        public static void RegisterPath(String key, String path)
        {
            PathRegistrarHelper.RegisterPath(key, path);
        }

        /// <summary>
        /// Unregister a path with the path registrar
        /// </summary>
        /// <param name="key">The key of the path to unregister</param>
        public static void UnRegisterPath(String key)
        {
            PathRegistrarHelper.UnRegisterPath(key);
        }

        /// <summary>
        /// Determine if a particular path is registered
        /// </summary>
        /// <param name="key">A key for the path</param>
        /// <returns>True if the path is registered, false if not</returns>
        public static Boolean IsRegistered(String key)
        {
            return PathRegistrarHelper.IsRegistered(key);
        }

        /// <summary>
        /// Retrieve a registered path
        /// </summary>
        /// <param name="key">Key of a registered path</param>
        /// <returns>The registered path</returns>
        public static String GetRegisteredPath(String key)
        {
            return PathRegistrarHelper.GetRegisteredPath(key);
        }

        /// <summary>
        /// Retrieve a collection of all registered paths
        /// </summary>
        public static IKeyValueSet[] GetRegisteredPaths()
        {
            return PathRegistrarHelper.GetRegisteredPaths();
        }

        /// <summary>
        /// Resolves an URL that uses one of the encoded paths protocol to a file system reference.
        /// No guarantees are provided that the resolved path is valid in the file system.
        /// </summary>
        /// <remarks>
        /// A Paths URL has the form Protocol://context/path where 'Protocol' is either registeredpath, 
        /// specialpath, registrypath, or a plugin path type. 'path' is a path relative to one
        /// of the context folders and 'context' is a key to a specific folder. 
        /// </remarks>
        /// <param name="url">Path to resolve.</param>
        /// <returns>A resolved path if a valid Paths URL or the path unchanged otherwise</returns>
        public static String ResolveUrl(String url)
        {
            String result = url;

            ReadOnlyCollection<IUrlResolver> urlResolvers = GetUrlResolvers();
            foreach (IUrlResolver urlResolver in urlResolvers)
            {
                if (urlResolver.CanResolveUrl(url))
                {
                    result = urlResolver.ResolveUrl(url);
                    break;
                }
            }
            
            return PathUtils.StripTrailingSlash(result);
        }

        /// <summary>
        /// Generate a registered path String from a URL
        /// </summary>
        /// <param name="url">A URL to transform</param>
        /// <returns>The URL reformated using the registered path syntax if applicable or else a the original URL is returned</returns>
        public static String RegisteredPathFromUrl(String url)
        {
            String result = url;
            
            if (url != null && url.Length > 0)
            {
                ReadOnlyCollection<IUrlResolver> urlResolvers = GetUrlResolvers();
                foreach (IUrlResolver urlResolver in urlResolvers)
                {
                    if (urlResolver.CanEncodeUrl)
                    {
                        result = urlResolver.EncodeUrl(url);
                        if (result != url) // if the original url has been converted stop, otherwise continue trying
                        {
                            break;
                        }
                    }
                }
            }
            
            return result;
        }

        private static ReadOnlyCollection<IUrlResolver> GetUrlResolvers()
        {
            if (_urlResolvers.Count == 0)
            {
                // hard-coded url resolvers
                _urlResolvers.Add(new RegisteredPathUrlResolver());
                _urlResolvers.Add(new SpecialPathUrlResolver());
                _urlResolvers.Add(new RegistryUrlResolver());

                // add-in url resolvers
                String folder = Path.Combine(LibraryConstants.VersionIndependent.LibraryApplicationDataFolder(LibraryManager.SharedConfigLocation), @"Path Registrar\Url Resolvers");
                if (Directory.Exists(folder))
                {
                    XPathNavigator navigator = XPathNavigatorFactory.CreateFromFolderPath(folder);
                    TypeFactoryReader typeFactoryReader = new TypeFactoryReader(navigator);

                    TypeFactory[] factories = typeFactoryReader.GetInterfaceImplementors("IUrlResolver");
                    foreach (TypeFactory factory in factories)
                    {
                        IUrlResolver urlResolver = (IUrlResolver)factory.GetLocalObject();
                        _urlResolvers.Add(urlResolver);
                    }
                }
            }

            return _urlResolvers.AsReadOnly();
        }

        #region IPathRegistrar

        /// <summary>
        /// Register a path with the path registrar
        /// </summary>
        /// <param name="key">A key used to identify the path</param>
        /// <param name="path">The path to register</param>
        void IPathRegistrar.RegisterPath(String key, String path)
        {
            PathRegistrarHelper.RegisterPath(key, path);
        }

        /// <summary>
        /// Unregister a path with the path registrar
        /// </summary>
        /// <param name="key">The key of the path to unregister</param>
        void IPathRegistrar.UnRegisterPath(String key)
        {
            PathRegistrarHelper.UnRegisterPath(key);
        }

        /// <summary>
        /// Determine if a particular path is registered
        /// </summary>
        /// <param name="key">A key for the path</param>
        /// <returns>True if the path is registered, false if not</returns>
        Boolean IPathRegistrar.IsRegistered(String key)
        {
            return PathRegistrarHelper.IsRegistered(key);
        }

        /// <summary>
        /// Retrieve a registered path
        /// </summary>
        /// <param name="key">Key of a registered path</param>
        /// <returns>The registered path</returns>
        String IPathRegistrar.GetRegisteredPath(String key)
        {
            return PathRegistrarHelper.GetRegisteredPath(key);
        }

        /// <summary>
        /// Retrieve a collection of all registered paths
        /// </summary>
        IKeyValueSet[] IPathRegistrar.GetRegisteredPaths()
        {
            return PathRegistrarHelper.GetRegisteredPaths();
        }

        /// <summary>
        /// Resolves an URL that uses one of the encoded paths protocol to a file system reference.
        /// No guarantees are provided that the resolved path is valid in the file system.
        /// </summary>
        /// <remarks>
        /// A Paths URL has the form Protocol://context/path where "Protocol" is either registeredpath, tspath, specialpath, or registrypath and path is a path relative to one
        /// of the context folders and context is a key to a specific folder. 
        /// </remarks>
        /// <param name="url">Path to resolve.</param>
        /// <returns>A resolved path if a valid Paths URL or the path unchanged otherwise</returns>
        String IPathRegistrar.ResolveUrl(String url)
        {
            return ResolveUrl(url);
        }

        /// <summary>
        /// Generate a registered path String from a URL
        /// </summary>
        /// <param name="url">A URL to transform</param>
        /// <returns>The URL reformated using the registered path syntax if applicable or else a the original URL is returned</returns>
        String IPathRegistrar.RegisteredPathFromUrl(String url)
        {
            return RegisteredPathFromUrl(url);
        }

        #endregion

        #region IPathResolver

        /// <summary>
        /// Determine if a particular path is registered
        /// </summary>
        /// <param name="key">A key for the path</param>
        /// <returns>True if the path is registered, false if not</returns>
        Boolean IPathResolver.IsRegistered(String key)
        {
            return PathRegistrarHelper.IsRegistered(key);
        }


        /// <summary>
        /// Retrieve a registered path
        /// </summary>
        /// <param name="key">Key of a registered path</param>
        /// <returns>The registered path</returns>
        String IPathResolver.GetRegisteredPath(String key)
        {
            return PathRegistrarHelper.GetRegisteredPath(key);
        }

        /// <summary>
        /// Resolves an URL that uses one of the encoded paths protocol to a file system reference.
        /// No guarantees are provided that the resolved path is valid in the file system.
        /// </summary>
        /// <remarks>
        /// A Paths URL has the form Protocol://context/path where "Protocol" is either registeredpath, tspath, specialpath, or registrypath and path is a path relative to one
        /// of the context folders and context is a key to a specific folder. 
        /// </remarks>
        /// <param name="url">Path to resolve.</param>
        /// <returns>A resolved path if a valid Paths URL or the path unchanged otherwise</returns>
        String IPathResolver.ResolveUrl(String url)
        {
            return ResolveUrl(url);
        }

        /// <summary>
        /// Generate a registered path String from a URL
        /// </summary>
        /// <param name="url">A URL to transform</param>
        /// <returns>The URL reformated using the registered path syntax if applicable or else a the original URL is returned</returns>
        String IPathResolver.RegisteredPathFromUrl(String url)
        {
            return RegisteredPathFromUrl(url);
        }

        #endregion
    }
}
