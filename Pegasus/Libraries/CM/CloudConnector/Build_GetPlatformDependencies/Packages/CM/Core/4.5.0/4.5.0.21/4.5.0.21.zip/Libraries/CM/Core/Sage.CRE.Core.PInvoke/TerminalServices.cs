using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Sage.PInvoke
{
    public static class TerminalServices
    {
        #region Internal methods
        public static bool IsAppServerSession
        {
            get
            {
                /*
                 * This system metric is used in a Terminal Services environment. If the calling process is associated with
                 *  a Terminal Services client session, the return value is nonzero. If the calling process is associated with 
                 * the Terminal Server console session, the return value is 0 (zero). The console session is not necessarily the
                 *  physical console. For more information, see WTSGetActiveConsoleSessionId. 
                 * Windows NT 4.0 SP3 and earlier and Windows Me/98/95:  This value is not supported.
                 **/
                return (IsInstalledInAppServerMode && 0 != User32.GetSystemMetrics(SystemMetric.RemoteSession));
            }
        }

        /// <summary>
        /// returns whether Terminal Services is installed
        /// </summary>
        /// <returns></returns>
        public static bool IsInstalledInAppServerMode
        {
            get
            {
                bool result = false;

                OSVersionInfoEx osVersionInfo = new OSVersionInfoEx();
                osVersionInfo.dwOSVersionInfoSize = Marshal.SizeOf(typeof(OSVersionInfoEx));

                if(Kernel32.GetVersionEx(ref osVersionInfo))
                {
                    if((ushort)(osVersionInfo.wSuiteMask & VersionSuite.Terminal) == (ushort) VersionSuite.Terminal)
                    {
                        result = true;
                    }
                }
                else
                {
                    //ErrorTrace.WriteLine(null, "GetVersionEx returned error={0}", Marshal.GetLastWin32Error());
                }

                return result;
            }
        }
        #endregion
    }
}
