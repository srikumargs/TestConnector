using System;
using System.Runtime.InteropServices;


namespace Sage.Remoting
{
    // TODO - Either create a custom attr or add to this class.
    //        We need to indicate whether service or process, and other
    //        info for tool generation of remoting config.
    
    /// <summary>
    /// This class implements the infinite lifetime for singletons
    /// </summary>
    [ ComVisible( false ) ]
    public class MarshalByRefBase : MarshalByRefObject
    {
        /// <summary>
        /// Keep the ctor protected
        /// </summary>
        protected MarshalByRefBase() : base() {}

        /// <summary>
        /// Override and return null to specify infinite lifetime for the singleton.
        /// </summary>
        public override object InitializeLifetimeService()
        {
            return null;
        }

        /// <summary>
        /// By default the URI is the derivative Type
        /// </summary>
        public virtual string ObjectUri 
        {
            get
            {
                Type t = this.GetType();
                return t.Name;
            }
        }
    }

}