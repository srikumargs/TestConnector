using System;
using Sage.CM.Core.LinkedSource;


namespace Sage.Configuration
{
	/// <summary>
	/// Summary description for AppPaths.
	/// </summary>
	public static class AppPaths
	{
		/// <summary>
		/// The path to the library common files folder (e.g., CRE\Core\2.0).
		/// </summary>
		/// <param name="sharedConfigLocation">The shared config location (typically supplied by Sage.Configuration.LibraryManager.SharedConfigLocation (Sage.CRE.Core.LibraryManager.dll)</param>
		/// <returns>The path to the library common files folder.</returns>
		public static String LibraryCommonFilesFolder( String sharedLibrariesLocation )
		{	
			return LibraryConstants.VersionIndependent.LibraryCommonFilesFolder( sharedLibrariesLocation );
		}
	}
}
