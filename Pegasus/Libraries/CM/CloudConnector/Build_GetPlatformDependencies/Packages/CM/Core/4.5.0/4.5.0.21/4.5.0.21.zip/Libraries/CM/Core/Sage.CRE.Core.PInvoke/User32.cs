using System;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;
namespace Sage.PInvoke
{
    /// <summary>
    /// Summary description for CUser32.
    /// </summary>
    public static class User32
	{
		#region Public constants and statics
		/// <summary>First item in list.</summary>
		public const uint CMD_FIRST = 1;
		
		/// <summary>Menu item by position.</summary>
		public const uint MF_BYPOSITION = 0x00000400;
		
		/// <summary>Menu item by separator.</summary>
		public const uint MF_SEPARATOR = 0x00000800;

		/// <summary>Size of the CMINVOKECOMMANDINFOEX structure.</summary>
		public static int cbInvokeCommandSize = Marshal.SizeOf( typeof( CMINVOKECOMMANDINFOEX ) );

		/// <summary>Guid for IID_IShellFolder.</summary>
		public static Guid IID_IShellFolder = new Guid( "{000214E6-0000-0000-C000-000000000046}" );

		/// <summary>Guid for IID_IContextMenu.</summary>
		public static Guid IID_IContextMenu = new Guid( "{000214E4-0000-0000-c000-000000000046}" );
		#endregion
		
		public static short GetKeyState(int nVirtKey)
        {
            return SafeNativeMethods.GetKeyState(nVirtKey);
        }
        public static IntPtr SetWindowsHookEx(int idHook, [MarshalAs(UnmanagedType.FunctionPtr)]HOOKPROC lpfn, IntPtr hMod, int dwThreadId)
        {
            return NativeMethods.SetWindowsHookEx(idHook, lpfn, hMod, dwThreadId);
        }
        public static void UnhookWindowsHookEx(IntPtr hhk)
        {
            NativeMethods.UnhookWindowsHookEx(hhk);
        }
        public static IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam)
        {
            return NativeMethods.CallNextHookEx(hhk, nCode, wParam, lParam);
        }

        public static bool ExitWindowsEx(ExitWindows flags, ShutdownReason reason)
        {
            return NativeMethods.ExitWindowsEx(flags, reason);
        }

        public static IntPtr CopyIcon(IntPtr hIcon)
        {
            return SafeNativeMethods.CopyIcon(hIcon);
        }

        public static bool PostMessage(
            IntPtr hWnd, // handle to destination window
            uint Msg, // message
            IntPtr wParam, // first message parameter
            IntPtr lParam // second message parameter
            )
        {
            return SafeNativeMethods.PostMessage(hWnd, // handle to destination window
                                                        Msg, // message
                                                        wParam, // first message parameter
                                                        lParam // second message parameter
                                                        );
        }


        public static IntPtr SendMessage(IntPtr window, uint message, IntPtr wParam, IntPtr lParam)
        {
            return SafeNativeMethods.SendMessage(window, message, wParam, lParam);
        }

        public static int DestroyIcon(IntPtr hIcon)
        {
            return SafeNativeMethods.DestroyIcon(hIcon);
        }

        public static bool AttachThreadInput(int idAttach, int idAttachTo, bool fAttach)
        {
            return SafeNativeMethods.AttachThreadInput(idAttach, idAttachTo, fAttach);
        }

        public static IntPtr GetWindow(IntPtr window, uint cmd)
        {
            return SafeNativeMethods.GetWindow(window, cmd);
        }

        public static IntPtr GetTopWindow(IntPtr window)
        {
            return SafeNativeMethods.GetTopWindow(window);
        }

        public static bool BringWindowToTop(IntPtr window)
        {
            return SafeNativeMethods.BringWindowToTop(window);
        }

        public static int GetClassName(IntPtr window, [In][Out] StringBuilder text, int copyCount)
        {
            return SafeNativeMethods.GetClassName(window, text, copyCount);
        }

        public static IntPtr FindWindowEx(IntPtr parent, IntPtr childAfter, string className, string windowName)
        {
            return SafeNativeMethods.FindWindowEx(parent, childAfter, className, windowName);
        }

        public static IntPtr FindWindow(string className, string windowName)
        {
            return SafeNativeMethods.FindWindow(className, windowName);
        }

        public static IntPtr GetParent(IntPtr window)
        {
            return SafeNativeMethods.GetParent(window);
        }

        public static IntPtr GetDesktopWindow()
        {
            return SafeNativeMethods.GetDesktopWindow();
        }

        public static IntPtr GetForegroundWindow()
        {
            return SafeNativeMethods.GetForegroundWindow();
        }

        public static bool AllowSetForegroundWindow(int processId)
        {
            return SafeNativeMethods.AllowSetForegroundWindow(processId);
        }

        public static IntPtr GetActiveWindow()
        {
            return SafeNativeMethods.GetActiveWindow();
        }

        public static IntPtr GetLastActivePopup(IntPtr window)
        {
            return SafeNativeMethods.GetLastActivePopup(window);
        }

        public static int GetWindowText(IntPtr window, [In][Out] StringBuilder text, int copyCount)
        {
            return SafeNativeMethods.GetWindowText(window, text, copyCount);
        }

        public static bool SetWindowText(IntPtr window, [MarshalAs(UnmanagedType.LPTStr)] string text)
        {
            return SafeNativeMethods.SetWindowText(window, text);
        }

        public static int GetWindowTextLength(IntPtr window)
        {
            return SafeNativeMethods.GetWindowTextLength(window);
        }

        public static int SetWindowLong(IntPtr window, int index, int val)
        {
            return SafeNativeMethods.SetWindowLong(window, index, val);
        }

        public static int GetWindowLong(IntPtr window, int index)
        {
            return SafeNativeMethods.GetWindowLong(window, index);
        }

        public static bool EnableWindow(IntPtr window, bool bEnable)
        {
            return SafeNativeMethods.EnableWindow(window, bEnable);
        }

        public static bool IsWindowEnabled(IntPtr window)
        {
            return SafeNativeMethods.IsWindowEnabled(window);
        }

        public static bool IsWindowVisible(IntPtr window)
        {
            return SafeNativeMethods.IsWindowVisible(window);
        }

        public static bool EnumChildWindows(IntPtr window, EnumWindowsProc callback, IntPtr i)
        {
            return SafeNativeMethods.EnumChildWindows(window, (EnumWindowsProc) callback, i);
        }

        public static bool EnumThreadWindows(int threadId, EnumWindowsProc callback, IntPtr i)
        {
            return SafeNativeMethods.EnumThreadWindows(threadId, callback, i);
        }

        public static bool EnumWindows(EnumWindowsProc callback, IntPtr i)
        {
            return SafeNativeMethods.EnumWindows(callback, i);
        }

        public static int GetWindowThreadProcessId(IntPtr window, ref int processId)
        {
            return SafeNativeMethods.GetWindowThreadProcessId(window, ref processId);
        }

        public static bool GetWindowPlacement(IntPtr hwnd, out WINDOWPLACEMENT lpwndpl)
        {
            return SafeNativeMethods.GetWindowPlacement(hwnd, out lpwndpl);
        }

        public static bool SetWindowPlacement(IntPtr hwnd, ref WINDOWPLACEMENT lpwndpl)
        {
            return SafeNativeMethods.SetWindowPlacement(hwnd, ref lpwndpl);
        }

        public static bool IsChild(IntPtr parent, IntPtr window)
        {
            return SafeNativeMethods.IsChild(parent, window);
        }

        public static bool IsIconic(IntPtr window)
        {
            return SafeNativeMethods.IsIconic(window);
        }

        public static bool IsZoomed(IntPtr window)
        {
            return SafeNativeMethods.IsZoomed(window);
        }

        public static int SetForegroundWindow(IntPtr window)
        {
            return SafeNativeMethods.SetForegroundWindow(window);
        }

        public static IntPtr GetDC(IntPtr hwnd)
        {
            return SafeNativeMethods.GetDC(hwnd);
        }

        public static IntPtr GetWindowDC(IntPtr hwnd)
        {
            return SafeNativeMethods.GetWindowDC(hwnd);
        }

        public static int ReleaseDC(IntPtr hwnd, IntPtr dc)
        {
            return SafeNativeMethods.ReleaseDC(hwnd, dc);
        }

        public static IntPtr WindowFromPoint(POINT point)
        {
            return SafeNativeMethods.WindowFromPoint(point);
        }

        public static bool GetWindowRect(IntPtr hwnd, ref Rect rectangle)
        {
            return SafeNativeMethods.GetWindowRect(hwnd, ref rectangle);
        }

        public static bool GetClientRect(IntPtr hwnd, ref Rect rectangle)
        {
            return SafeNativeMethods.GetClientRect(hwnd, ref rectangle);
        }

        public static bool GetCursorPos(out Point position)
        {
            return SafeNativeMethods.GetCursorPos(out position);
        }

        public static int SetParent(IntPtr hWndChild, IntPtr hWndParent)
        {
            return SafeNativeMethods.SetParent(hWndChild, hWndParent);
        }

        public static bool ShowWindow(IntPtr hWnd, int cmd)
        {
            return SafeNativeMethods.ShowWindow(hWnd, cmd);
        }

        public static IntPtr SetFocus(IntPtr hWnd)
        {
            return SafeNativeMethods.SetFocus(hWnd);
        }

        public static IntPtr GetFocus()
        {
            return SafeNativeMethods.GetFocus();
        }

        public static int SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int x, int y, int cx, int cy, uint flags)
        {
            return SafeNativeMethods.SetWindowPos(hWnd, hWndInsertAfter, x, y, cx, cy, flags);
        }

        public static IntPtr GetNextDlgTabItem(IntPtr hDlg, IntPtr hCtrl, bool bPrevious)
        {
            return SafeNativeMethods.GetNextDlgTabItem(hDlg, hCtrl, bPrevious);
        }

        public static bool IsWindow(IntPtr hWnd)
        {
            return SafeNativeMethods.IsWindow(hWnd);
        }

        public static bool MoveWindow(IntPtr hWnd, int x, int y, int w, int h, bool bRepaint)
        {
            return SafeNativeMethods.MoveWindow(hWnd, x, y, w, h, bRepaint);
        }

        public static bool UpdateWindow(IntPtr hWnd)
        {
            return SafeNativeMethods.UpdateWindow(hWnd);
        }

        public static IntPtr SetActiveWindow(IntPtr hWnd)
        {
            return SafeNativeMethods.SetActiveWindow(hWnd);
        }

        public static bool WinHelp(IntPtr hWndMain, string lpszHelp, uint uCommand, IntPtr dwData)
        {
            return SafeNativeMethods.WinHelp(hWndMain, lpszHelp, uCommand, dwData);
        }

        public static uint MessageBox(IntPtr hWnd, String text, String caption, uint type)
        {
            return SafeNativeMethods.MessageBox(hWnd, text, caption, type);
        }
        public static bool MessageBeep(uint uType)
        {
            return SafeNativeMethods.MessageBeep(uType);
        }
        public static bool LockWindowUpdate(int windowHandle)
        {
            return SafeNativeMethods.LockWindowUpdate(windowHandle);
        }
        public static void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo)
        {
            SafeNativeMethods.keybd_event(bVk, bScan, dwFlags, dwExtraInfo);
        }
        public static bool IsDialogMessage(IntPtr hDlg, IntPtr msg)
        {
            return SafeNativeMethods.IsDialogMessage(hDlg, msg);
        }
        public static IntPtr FindWindowWin32(string className, string windowName)
        {
            return SafeNativeMethods.FindWindowWin32(className, windowName);
        }

        public static int GetSystemMetrics(SystemMetric systemMetric)
        {
            return NativeMethods.GetSystemMetrics(systemMetric);
        }

		public static IntPtr CreatePopupMenu()
		{
			return NativeMethods.CreatePopupMenu();
		}

		public static int GetMenuItemCount(
			IntPtr hMenu )
		{
			return NativeMethods.GetMenuItemCount(
				hMenu );
		}

		public static uint TrackPopupMenuEx(
			IntPtr hMenu,
			TrackPopupMenuFlags uFlags,
			int x,
			int y,		
			IntPtr hWnd,
			IntPtr prcRect )
		{
			return PInvoke.NativeMethods.TrackPopupMenuEx(
				hMenu,
				uFlags,
				x,
				y,		
				hWnd,
				prcRect );
		}

		public static bool DeleteMenu(
			IntPtr hMenu,
			uint uPosition,
			uint uFlags )
		{
			return NativeMethods.DeleteMenu(
				hMenu,
				uPosition,
				uFlags );
		}
				
		public static int GetMenuString(
			IntPtr hMenu,
			uint uIDItem,
			StringBuilder lpString,
			int nMaxCount,
			uint uFlag )
		{
			return NativeMethods.GetMenuString(
				hMenu,
				uIDItem,
				lpString,
				nMaxCount,
				uFlag );
		}

		public static uint GetMenuState(
			IntPtr hMenu,
			uint uId,
			uint uFlags )
		{
			return NativeMethods.GetMenuState(
				hMenu,
				uId,
				uFlags );
		}

        public static int GetDlgItem(IntPtr hDlg, int nIDDlgItem)
        {
            return SafeNativeMethods.GetDlgItem(hDlg, nIDDlgItem);
        }

        public static bool SetDlgItemText(IntPtr hDlg,
            int nIDDlgItem,
            string lpString)
        {
            return SafeNativeMethods.SetDlgItemText(hDlg, nIDDlgItem, lpString);
        }

        public static int CreateWindowEx(uint dwExStyle, string lpClassName, string lpWindowName, uint dwStyle, int x, int y, int nWidth, int nHeight, IntPtr hWndParent, IntPtr hMenu, IntPtr hInstance, IntPtr lpParam)
        {
            return SafeNativeMethods.CreateWindowEx(dwExStyle, lpClassName, lpWindowName, dwStyle, x, y, nWidth, nHeight, hWndParent, hMenu, hInstance, lpParam);
        }

        public static bool ScreenToClient(IntPtr hWnd, ref POINT lpPoint)
        {
            return SafeNativeMethods.ScreenToClient(hWnd, ref lpPoint);
        }

        public static bool DestroyWindow(IntPtr hwnd)
        {
            return SafeNativeMethods.DestroyWindow(hwnd);
        }

        public static bool CloseWindow(IntPtr hWnd)
        {
            return SafeNativeMethods.CloseWindow(hWnd);
        }
    }
}
