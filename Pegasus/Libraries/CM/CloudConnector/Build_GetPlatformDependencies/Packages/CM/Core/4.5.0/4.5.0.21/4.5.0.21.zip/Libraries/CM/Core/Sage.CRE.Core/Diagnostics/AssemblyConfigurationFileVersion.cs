using System;
using System.Reflection;
using System.Runtime.InteropServices;

namespace Sage.Diagnostics
{
	/// <summary>
	/// Attribute used on assemblies that support different versioned configuration files
	/// </summary>
	/// 
    [ AttributeUsage( AttributeTargets.Assembly ) ]
    [ ComVisible( false ) ]
	public class AssemblyConfigurationFileVersion : Attribute
	{
        private int _major    = 1;
        private int _minor    = 0;
        private int _build    = 0;
        private int _revision = 0;


        /// <summary>
        /// Default Constructor
        /// </summary>
		public AssemblyConfigurationFileVersion()
		{
            
		}

        /// <summary>
        /// Property to set/get the major version
        /// </summary>
        public int Major 
        {
            get { return _major; }
            set { _major = value; }
        }

        /// <summary>
        /// Property ot set/get the minor version
        /// </summary>
        public int Minor 
        {
            get { return _minor; }
            set { _minor = value; }
        }

        /// <summary>
        /// Property to get/set the build version
        /// </summary>
        public int Build
        {
            get { return _build; }
            set { _build = value; }
        }

        /// <summary>
        /// Property to get/set the revision number
        /// </summary>
        public int Revision
        {
            get { return _revision; }
            set { _revision = value; }
        }

        /// <summary>
        /// //Property that returns the major, minor, build and revision numbers as a Version object
        /// </summary>
        public Version Version
        {
            get { return new Version( Major, Minor, Build, Revision ); }
        }



        /// <summary>
        /// Format the return value so it's useful in picking the correction configuration file version.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Version.ToString();
        }

        /// <summary>
        /// Returns the Configuration File Version as a string for the calling assembly.
        /// </summary>
        /// <returns></returns>
        public static Version GetVersion()
        {
            Assembly assembly = Assembly.GetCallingAssembly();

            foreach ( object attribObject in assembly.GetCustomAttributes( true ) )
            {
                if ( attribObject is AssemblyConfigurationFileVersion )
                {
                    return ((AssemblyConfigurationFileVersion)attribObject).Version;
                }
            }
            throw new InvalidOperationException( Strings.MissingAssemblyConfigFileVersionError );
        }


        /// <summary>
        /// Returns the Configuration File Version for the Assembly passed in.
        /// </summary>
        /// <param name="assembly"></param>
        /// <returns></returns>
        public static Version GetVersion( Assembly assembly )
        {
            ArgumentValidator.ValidateNonNullReference( assembly, "assembly", "AssemblyConfigurationFileVersion" );

            foreach ( object attribObject in assembly.GetCustomAttributes( true ) )
            {
                if ( attribObject is AssemblyConfigurationFileVersion )
                {
                    return ((AssemblyConfigurationFileVersion)attribObject).Version;
                }
            }
            throw new InvalidOperationException( Strings.MissingAssemblyConfigFileVersionError );
        }
	}




}
