#if DEBUG
using System;
using System.IO;
using System.Threading;
using NUnit.Framework;

namespace Sage.IO.Tests
{
	/// <summary>
	/// Provide unit tests for the FolderContentsReader
	/// </summary>
	[TestFixture]
	public class TestFolderContentsReader
	{
        // Used for counting the number of files read
        private int _fileCount = 0;

        /// <summary>
        /// Constructor
        /// </summary>
		public TestFolderContentsReader()
		{
			
		}

        /// <summary>
        /// Test performing a cached batch file read on default file types
        /// </summary>
        [Test]
        [Ignore("path sepcific stuff needs to go")]
        public void TestCachedReader()
        {

            IDataStreamProvider reader = new FolderContentsReader( @"C:\Devel\Current\BatchReaderTestFolder" );
            reader.Read();

            Assert.IsTrue( reader.CachedDataStreams.Count == 4 );

            foreach( Stream fileStream in reader.CachedDataStreams )
            {
                Assert.IsTrue( fileStream != null );    
            }
        }

        /// <summary>
        /// Test using the reader in uncached mode
        /// </summary>
        [Test]
        [Ignore("path sepcific stuff needs to go")]
        public void TestEventBasedReader()
        {
            _fileCount = 0;

            IDataStreamProvider reader = new FolderContentsReader( new FolderContentsReaderInfo( @"C:\Devel\Current\BatchReaderTestFolder", false ) );
            reader.DataRead += new DataReadEventHandler( OnFileRead );
            reader.Read();

            Assert.IsTrue( _fileCount == 4 ); 
        }

        /// <summary>
        /// Test skippin gthe read on one specific file
        /// </summary>
        [Test]
        [Ignore("path sepcific stuff needs to go")]
        public void TestSkippingTheReadOfASpecificFile()
        {
            IDataStreamProvider reader = new FolderContentsReader( @"C:\Devel\Current\BatchReaderTestFolder" );
            reader.BeforeDataRead += new BeforeDataReadEventHandler( OnBeforeFileReadSkipOne );
            reader.Read();

            Assert.IsTrue( reader.CachedDataStreams.Count == 3 );
        }

        /// <summary>
        /// Test canceling the read Via the BeforeFileRead event
        /// </summary>
        [Test]
        [Ignore("path sepcific stuff needs to go")]
        public void TestCancelingTheRead()
        {
            IDataStreamProvider reader = new FolderContentsReader( @"C:\Devel\Current\BatchReaderTestFolder" );
            reader.BeforeDataRead += new BeforeDataReadEventHandler( OnBeforeFileReadCancel );
            reader.Read();

            Assert.IsTrue( reader.CachedDataStreams.Count == 0 );
        }

        /// <summary>
        /// Test adding and removing files with folder monitoring on.
        /// </summary>
        [Ignore("path sepcific stuff needs to go")]
        [Test]
        public void TestFolderMonitoring()
        {

            IDataStreamProvider reader = new FolderContentsReader( new FolderContentsReaderInfo( @"C:\Devel\Current\BatchReaderTestFolder", true, true ) );
            reader.DataSourceAdded += new DataSourceEventHandler( OnFileAdded );
            reader.DataSourceDeleted += new DataSourceEventHandler( OnFileDeleted );
            reader.Read();
            File.Copy( @"C:\Devel\Current\BatchReaderTestFolder\Backup\approvider.acx",  @"C:\Devel\Current\BatchReaderTestFolder\approvider.acx" );
            Thread.Sleep( 500 );
            File.Delete( @"C:\Devel\Current\BatchReaderTestFolder\approvider.acx" );
            Thread.Sleep( 500 );
            
        }

        /// <summary>
        /// Handle the file added event
        /// </summary>
        /// <param name="sender">BatchFileReader</param>
        /// <param name="args">Event arguments</param>
        private void OnFileAdded( object sender, DataSourceEventArgs args )
        {
            Assert.IsTrue( Path.GetFileName( args.DataSourceId ).ToLower() == "approvider.acx" );
            Assert.IsTrue( ((FolderContentsReader)sender).CachedDataStreams.Count == 5 );
        }

        /// <summary>
        /// Handle the file deleted event
        /// </summary>
        /// <param name="sender">BatchFileReader</param>
        /// <param name="args">Event arguments</param>
        private void OnFileDeleted( object sender, DataSourceEventArgs args )
        {
            Assert.IsTrue( Path.GetFileName( args.DataSourceId ).ToLower() == "approvider.acx" );
            Assert.IsTrue( ((FolderContentsReader)sender).CachedDataStreams.Count == 4 );
        }

        /// <summary>
        /// Handle the file read event
        /// </summary>
        /// <param name="sender">BatchFileReader</param>
        /// <param name="args">Event arguments</param>
        private void OnFileRead( object sender, DataReadEventArgs args )
        {
            Stream fileStream = args.DataStream;
            _fileCount++;
        }

        /// <summary>
        /// Handle the before file read event and skip one file
        /// </summary>
        /// <param name="sender">BatchFileReader</param>
        /// <param name="args">Event arguments</param>
        private void OnBeforeFileReadSkipOne( object sender, BeforeDataReadEventArgs args )
        {
            if( Path.GetFileName( args.DataSourceId ).ToLower() == "actprovider.acx" )
            {
                args.SkipThisDataSource = true;
            }
        }

        /// <summary>
        /// Handle the before file read event and cancel all the reads
        /// </summary>
        /// <param name="sender">BatchFileReader</param>
        /// <param name="args">Event arguments</param>
        private void OnBeforeFileReadCancel( object sender, BeforeDataReadEventArgs args )
        {
            args.CancelAllRemainingDataSourceReads = true;
        }
	}
}

#endif