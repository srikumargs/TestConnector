#if DEBUG
using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Text;
using NUnit.Framework;

namespace Sage.IO.Tests
{
    /// <summary>
    /// Tests the DirectoryAccessRights class.  In order to properly run this test, you will
    /// need to create directories with limited rights and make sure that the functions
    /// return the correct results.
    /// </summary>
    [TestFixture]
    public class TestDirectoryAccessRights
    {
        string _fullAccessPath;
        string _denyWritePath;

        /// <summary>
        /// Setup function
        /// </summary>
        [TestFixtureSetUp]
        public void SetupTestDirectories()
        {
            _fullAccessPath = @"C:\Documents and Settings\Administrator";
            _denyWritePath = @"D:\ZipTest\Test1";
        }

        /// <summary>
        /// Teardown function
        /// </summary>
        [TestFixtureTearDown]
        public void RemoveTestDirectories()
        {
        }

        /// <summary>
        /// Make sure that the DirectoryAccessRights classes is returning the correct results
        /// for the paths specified above.
        /// </summary>
        [Test]
        public void TestDirectoryAccess()
        {
            DirectoryAccessRights fullAccessPath = new DirectoryAccessRights(_fullAccessPath);
            Assert.IsTrue(fullAccessPath.HasFullControlRights, string.Format("{0} does not have Full Control Rights.", _fullAccessPath));
            
            DirectoryAccessRights denyWritePath = new DirectoryAccessRights(_denyWritePath);
            Assert.IsTrue(!denyWritePath.HasWriteRights, string.Format("{0} has Write rights and should not.", _denyWritePath));
        }
    }
}
#endif