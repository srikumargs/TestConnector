/*=====================================================================

  File:        PipeClientChannel.cs

=====================================================================*/

using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Channels;
using System.Threading;

using Sage.Diagnostics;
using Sage.CRE.LinkedSource;

namespace Sage.Remoting
{
    /// <summary>
    /// PipeChannelClient
    /// </summary>
    internal sealed class PipeClientChannel : IChannelSender
    {
        // pipe:// prefix
        private const String _channelScheme = "pipe";

        private const int _defaultChannelPriority = 1;

        private int _channelPriority;
        private String _channelName;
        private String _pipeName;

        private IClientChannelSinkProvider _clientSinkProvider; // client sink chain provider

        public PipeClientChannel()
        {
            InitDefaults();
            InitProperties(null);
            InitProviders(null);
            VerboseTrace.WriteLine(this, "_channelName={0}, _channelPriority={1}, _pipeName={2}", _channelName, _channelPriority, _pipeName);
        }

        public PipeClientChannel(IDictionary properties,
                                 IClientChannelSinkProvider clientProviderChain)
        {
            InitDefaults();
            InitProperties(properties);
            InitProviders(clientProviderChain);
            VerboseTrace.WriteLine(this, "_channelName={0}, _channelPriority={1}, _pipeName={2}", _channelName, _channelPriority, _pipeName);
        }

        internal void InitDefaults()
        {
            _channelPriority = _defaultChannelPriority;
            _channelName = Guid.NewGuid().ToString();
        }

        internal void InitProperties(IDictionary properties)
        {
            if(properties != null)
            {
                foreach(DictionaryEntry entry in properties)
                {
                    switch((String) entry.Key)
                    {
                        case "name":
                            _channelName = (String) entry.Value;
                            break;

                        case "priority":
                            _channelPriority = Convert.ToInt32(entry.Value);
                            break;

                        case "pipe":
                            _pipeName = (String) entry.Value;
                            break;
                    }
                }
            }
        }

        void InitProviders(IClientChannelSinkProvider clientProviderChain)
        {
            _clientSinkProvider = clientProviderChain;

            if(_clientSinkProvider == null)
            {
                _clientSinkProvider = new BinaryClientFormatterSinkProvider();
                _clientSinkProvider.Next = new PipeClientTransportSinkProvider();
            }
            else
            {
                AddClientProviderToChain(_clientSinkProvider, new PipeClientTransportSinkProvider());
            }
        }

        private static void AddClientProviderToChain(IClientChannelSinkProvider clientChain, IClientChannelSinkProvider clientProvider)
        {
            while(clientChain.Next != null)
            {
                clientChain = clientChain.Next;
            }
            clientChain.Next = clientProvider;
        }

        #region IChannel
        public String ChannelName
        {
            get
            {
                return (_channelName);
            }
        }

        public int ChannelPriority
        {
            get
            {
                return (_channelPriority);
            }
        }

        public String Parse(String url, out string uri)
        {
            VerboseTrace.WriteLine(this, "*** In Client Parse:  input Url={0}", url);
            string machineName;
            string pipeName = PipeConnection.Parse(url, out machineName, out uri);
            uri = PipeConnection.BuildObjectUri(machineName, uri);
            VerboseTrace.WriteLine(this, "*** In Client Parse:  PipeName={0}, Machine={1}, Uri={2}", pipeName, machineName, uri);
            return pipeName;
        }
        #endregion


        #region IChannelSender
        public IMessageSink CreateMessageSink(String url, Object remoteChannelData, out String objectURI)
        {
            VerboseTrace.WriteLine(null, "CreateMessageSink: url={0}", url);
            // Set the out parameters
            objectURI = null;
            String ChannelURI = null;

            if(url != null) // Is this a well known object?
            {
                // Parse returns null if this is not one of the pipe channel url's
                ChannelURI = Parse(url, out objectURI);
            }
            else if(remoteChannelData != null)
            {
                IChannelDataStore cds = remoteChannelData as IChannelDataStore;
                if(cds != null)
                {
                    VerboseTrace.WriteLine(null, "ChannelUris[0]={0}", cds.ChannelUris[0]);

                    ChannelURI = Parse(cds.ChannelUris[0], out objectURI);
                    VerboseTrace.WriteLine(null, "CreateMessageSink: chanuri={0}, objuri={1}", ChannelURI, objectURI);
                    if(ChannelURI != null)
                    {
                        url = cds.ChannelUris[0];
                    }
                }
            }

            if(null != ChannelURI)
            {
                if(url == null)
                {
                    url = ChannelURI;
                }

                VerboseTrace.WriteLine(this, "*** CreateMessageSink: delegating w/ url={0}", url);
                return (IMessageSink) _clientSinkProvider.CreateSink(this, url, remoteChannelData);
            }

            VerboseTrace.WriteLine(null, "CreateMessageSink: ignoring request...");
            objectURI = "";
            return null;
        } // CreateMessageSink
        #endregion

        public void Dispose()
        {
            // Nothing to do
        }
    }

    //==============================================================================================

    /// <summary>
    /// PipeClientTransportSinkProvider
    /// </summary>
    internal sealed class PipeClientTransportSinkProvider : IClientChannelSinkProvider
    {
        internal PipeClientTransportSinkProvider()
        {
        }

        public IClientChannelSink CreateSink(IChannelSender channel,
                                             String url,
                                             Object data)
        {
            return new PipeClientTransportSink(url);
        }

        public IClientChannelSinkProvider Next
        {
            get
            {
                return null;
            }
            set
            {
                throw new NotSupportedException();
            }
        }
    }

    //==============================================================================================

    /// <summary>
    /// PipeClientTransportSink
    /// </summary>
    internal sealed class PipeClientTransportSink : IClientChannelSink, IDisposable
    {
        private String _pipeName;
        private String _machineName = ".";

        private PipeConnectionPool _pipeConnectionPool = null;
        private int _defaultRetryCount = 2;

        private ManualResetEvent _stopListeningEvent;

        internal PipeClientTransportSink(String url)
        {
            VerboseTrace.WriteLine(this, "*** In PipeClientTransportSink:  In Url={0}", url);
            String objUri = null;
            String machineName = null;
            String pipeName = PipeConnection.Parse(url, out machineName, out objUri);
            objUri = PipeConnection.BuildObjectUri(machineName, objUri);
            VerboseTrace.WriteLine(this, "*** In PipeClientTransportSink:  PipeName={0}, Machine={1}, Uri={2}", pipeName, machineName, objUri);

            _pipeName = pipeName;
            _machineName = machineName;

            _pipeConnectionPool = PipeConnectionPoolManager.LookupPool(_machineName + _pipeName);

            _stopListeningEvent = new ManualResetEvent(false);
        }

        public IDictionary Properties
        {
            get
            {
                return null;
            }
        }

        public void AsyncProcessRequest(IClientChannelSinkStack sinkStack,
                                        IMessage msg,
                                        ITransportHeaders headers,
                                        Stream stream)
        {
            ITransportHeaders headers1;
            Stream stream1;
            AsyncCallback callback1 = new AsyncCallback(this.AsyncFinishedCallback);
            new AsyncMessageDelegate(this.AsyncProcessMessage).BeginInvoke(msg, headers, stream, out headers1, out stream1, sinkStack, callback1, null);
        }

        public void AsyncProcessResponse(IClientResponseChannelSinkStack sinkStack,
                                         Object state,
                                         ITransportHeaders headers,
                                         Stream stream)
        {
            throw new NotSupportedException();
        }

        public Stream GetRequestStream(IMessage msg, ITransportHeaders headers)
        {
            return null;
        }

        public void ProcessMessage(IMessage msg,
                                   ITransportHeaders requestHeaders,
                                   Stream requestStream,
                                   out ITransportHeaders responseHeaders,
                                   out Stream responseStream)
        {
            VerboseTrace.WriteLine(this, "Being asked to process the serialized message!");

            requestStream = PreProcess(requestStream);

            // Send the message across the pipe.
            PipeConnection _pipe = SendWithRetry(msg, requestHeaders, requestStream);
            try
            {

                // Read response
                _pipe.BeginReadMessage(_stopListeningEvent);
                if(_stopListeningEvent.WaitOne(0, false))
                {
                    VerboseTrace.WriteLine(this, "_stopListeningEvent signalled in ProcessMessage().  Exiting.");
                    responseHeaders = null;
                    responseStream = null;
                    return;
                }

                responseHeaders = _pipe.ReadHeaders();
                responseStream = _pipe.ReadStream();
                _pipe.EndReadMessage();
            }
            finally
            {
                if(_pipeConnectionPool != null && _pipe != null)
                {
                    _pipeConnectionPool.ReturnToPool(_pipe);
                }

                _pipe = null;
            }

            responseStream = PostProcess(responseStream);
        }

        public IClientChannelSink NextChannelSink
        {
            get
            {
                return null;
            }
        }

        private delegate IClientChannelSinkStack AsyncMessageDelegate(IMessage msg, ITransportHeaders requestHeaders, Stream requestStream, out ITransportHeaders responseHeaders, out Stream responseStream, IClientChannelSinkStack sinkStack);

        #region Private methods
        private IClientChannelSinkStack AsyncProcessMessage(IMessage msg, ITransportHeaders requestHeaders, Stream requestStream, out ITransportHeaders responseHeaders, out Stream responseStream, IClientChannelSinkStack sinkStack)
        {
            (this as IClientChannelSink).ProcessMessage(msg, requestHeaders, requestStream, out responseHeaders, out responseStream);
            return sinkStack;
        }

        private void AsyncFinishedCallback(IAsyncResult asyncResult)
        {
            IClientChannelSinkStack sinkStack = null;
            try
            {
                ITransportHeaders headers;
                Stream stream;
                sinkStack = ((AsyncMessageDelegate) ((AsyncResult) asyncResult).AsyncDelegate).EndInvoke(out headers, out stream, asyncResult);
                sinkStack.AsyncProcessResponse(headers, stream);
            }
            catch(Exception ex)
            {
                try
                {
                    if(sinkStack != null)
                    {
                        sinkStack.DispatchException(ex);
                    }
                    return;
                }
                catch
                {
                    return;
                }
            }
            catch
            {
                try
                {
                    if(sinkStack != null)
                    {
                        sinkStack.DispatchException(new Exception(Strings.NonCLSCompliantException));
                    }
                    return;
                }
                catch
                {
                    return;
                }
            }
        }

        private PipeConnection SendWithRetry(IMessage msg,
                                            ITransportHeaders requestHeaders,
                                            Stream requestStream)
        {
            IMethodCallMessage mcm = (IMethodCallMessage) msg;

            String uri = mcm.Uri;
            PipeConnection _pipe = null;

            int tryCount = _defaultRetryCount;
            long reqStmPosition = -1;

            if(requestStream.CanSeek == false)
                tryCount = 1;
            else
                reqStmPosition = requestStream.Position;

            while(tryCount > 0)
            {
                try
                {
                    if(_pipeConnectionPool != null)
                    {
                        VerboseTrace.WriteLine(this, "Look in pipe connection in pool");
                        _pipe = (PipeConnection) _pipeConnectionPool.Obtain();
                    }

                    // otherwise create a new connection
                    if(_pipe == null)
                    {
                        _pipe = new PipeConnection(_machineName, _pipeName, false, IntPtr.Zero);
                    }

                    //Send with Retry
                    _pipe.BeginWriteMessage();
                    _pipe.WriteHeaders(uri, requestHeaders);
                    _pipe.Write(requestStream);
                    _pipe.EndWriteMessage(_stopListeningEvent);
                    if(_stopListeningEvent.WaitOne(0, false))
                    {
                        VerboseTrace.WriteLine(this, "_stopListeningEvent signalled in SendWithRetry().  Exiting.");
                        _pipe.Dispose();
                        _pipe = null;
                    }

                    tryCount = 0;
                }
                catch(PipeIOException /*pe*/)
                {
                    //pe=pe;
                    if(_pipe != null)
                    {
                        _pipe.Dispose();
                        _pipe = null;
                    }

                    tryCount--;
                    requestStream.Position = reqStmPosition;

                    if(tryCount == 0)
                    {
                        throw;
                    }
                }
            }

            return _pipe;
        }

        private Stream PreProcess(Stream stream)
        {
            return Cryptography.EncryptStream(stream, CryptoAlgorithm.DES, CryptoConstants.Key, CryptoConstants.IV);
        }

        private Stream PostProcess(Stream stream)
        {
            return Cryptography.DecryptStream(stream, CryptoAlgorithm.DES, CryptoConstants.Key, CryptoConstants.IV);
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            _stopListeningEvent.Set();
        }
        #endregion
    }
}