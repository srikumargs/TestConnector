using System;
using System.Collections;
using System.IO;
using System.Diagnostics;
using System.Threading;

// Sage.Diagnostics.ExceptionHandler allows you to easily
// identify the exceptions you want to handle (e.g., SecurityExceptions)
// and, specify how you want the ExceptionHandler to behave for each exception you identified (e.g., Add the exception to the EventLogger)
//
// To use Sage.Diagnostics. ExceptionHandler
// Create an instance of ExceptionHandler, _handler.
// Call _handler.AddHandledException() for each exception type you want handled
// Call _handler.UnhandledExceptionAction() to specify what to do with the exceptions that you do not handle 
// In your catch blocks call _handler.HandleException()
//
// In the example below the handler has been configured so that SecurityExceptions will be logged to the EventViewer and then re-thrown.  And, all other exceptions will be re-thrown.
//
//  ExceptionHandler handler = new ExceptionHandler();
//  handler.AddHandledException(typeof(SecurityException), ExceptionHandler.Action.EventLogger | ExceptionHandler.Action.Rethrow);
//  handler.UnhandledExceptionAction(ExceptionHandler.Action.Rethrow);
//
//  try
//  {
//      throw new SecurityException();
//  }
//  catch(Exception ex)
//  {
//      handler.HandleException(ex);
//  }
//
// If you want to customize how an exception is handled, e.g., you want to add information to a custom journal, use the Delegate action.
//
// In the example below the handler has been configured so that DataExceptions will be printed to the debug output window and myCustomHandler will be called.  Within myCustomHandler you can do what ever you want with the exception.
//
//  handler.AddHandledException(typeof(DataException), ExceptionHandler.Action.DebugOut | ExceptionHandler.Action.Delegate,
//  new ExceptionHandler.CustomHandler(this.myCustomHandler));
//
//  public void myCustomHandler(Exception ex)
//  {
//  }

namespace Sage.Diagnostics
{
    /// <summary>
    /// The ExceptionHandler class can be used to identify and handle different types of Exceptions
    /// </summary>
    public class ExceptionHandler
    {
        /// <summary>
        /// The list of possible actions that can be performed on an exception
        /// </summary>
        [FlagsAttribute]
        public enum Action
        {
            /// <summary>
            /// None specifies that no action should be taken
            /// </summary>
            None = 0,
            /// <summary>
            /// EventLogger specifies that the exception should be logged to the event logger
            /// </summary>
            EventLogger = 1,
            /// <summary>
            /// DebugOut specifies that the exception should be printed to the debug output window
            /// </summary>
            DebugOut = 2,
            /// <summary>
            /// Delegate specifies that the exception will be handled by a delegate
            /// </summary>
            Delegate = 4,
            /// <summary>
            /// Rethrow specifies that the exception should be rethrown
            /// </summary>
            Rethrow = 8
            //BE CAREFUL these Actions should be able to be OR'd together
        }

        /// <summary>
        /// The signature of the custom handler called when the action is to delegate.
        /// </summary>
        public delegate void CustomHandler( Exception ex );

        #region private fields
        private Exception _handledException = null;
        private ArrayList _handledExceptionTypes = new ArrayList();
        private Action _unhandledAction = Action.None;
        private CustomHandler _unhandledCustomHandler = null;
        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        public ExceptionHandler()
        {
        }

        #region public methods

        /// <summary>
        /// Call this method to specify that a particular type of exception should be handled
        /// with the specified action.
        /// </summary>
        /// <param name="exceptionType">The type of exception that can be handled</param>
        /// <param name="action">The action that should be performed to handle the exception</param>
        public void AddHandledException(Type exceptionType, Action action)
        {
            AddHandledException(exceptionType, action, null);
        }

        /// <summary>
        /// Call this method to specify that a particular type of exception should be handled
        /// with the specified action.
        /// </summary>
        /// <param name="exceptionType">The type of exception that can be handled</param>
        /// <param name="action">The action that should be performed to handle the exception</param>
        /// <param name="handler">The CustomHandler which will be called if action is Delegate, otherwise null</param>
        public void AddHandledException(Type exceptionType, Action action, CustomHandler handler)
        {
            _handledExceptionTypes.Add(new ExceptionInfo(exceptionType, action, handler));
        }

        /// <summary>
        /// Call this method to specify the action which should be performed on exceptions that
        /// can't be handled.
        /// </summary>
        /// <param name="action">The action to should be performed on unhandled exceptions</param>
        public void UnhandledExceptionAction(Action action)
        {
            UnhandledExceptionAction(action, null);
        }

        /// <summary>
        /// Call this method to specify the action which should be performed on exceptions that
        /// can't be handled.
        /// </summary>
        /// <param name="action">The action that should be performed on unhandled exceptions</param>
        /// <param name="handler">the CustomHandler that will be used if action is Delegate, otherwise null</param>
        public void UnhandledExceptionAction(Action action, CustomHandler handler)
        {
            _unhandledAction = action;
            _unhandledCustomHandler = handler;
        }

        /// <summary>
        /// Handle any exceptions that can be
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        public bool HandleException(Exception ex)
        {
            bool handled = false;
            Action action = Action.None;
            try
            {
                handled = InternalHandleException(ex, ref action);
            }
            catch 
            {
                // swallow any exceptions that might be generated from this code so that we don't 
                // accidentally hide the real exception that occurred
            }
            finally
            {
                if (handled && action == Action.Rethrow)
                {
                    throw ex;
                }
            }
            return handled;
        }


        /// <summary>
        /// Get the exception that was handled
        /// </summary>
        public Exception Exception
        {
            get
            {
                return _handledException;
            }
        }
        #endregion


        #region protected virtual methods

        /// <summary>
        /// This method will return true if the exception can be handled.
        /// </summary>
        /// <param name="ex">The exception to check</param>
        /// <param name="action">The action to perform on the exception if it can be handled</param>
        /// <param name="customHandler">The delegate to call if the action is Delegate, this parameter can be null</param>
        /// <returns>true if the exception can be handled, otherwise false</returns>
        protected virtual bool CanHandleException(Exception ex, ref Action action, ref CustomHandler customHandler)
        {
            bool handled = false;
            action = Action.None;
            customHandler = null;

            foreach (ExceptionInfo exception in _handledExceptionTypes)
            {
                if (exception.Type.IsInstanceOfType(ex))
                {
                    action = exception.Action;
                    customHandler = exception.CustomHandler;
                    handled = true;
					break;
                }
            }

            return handled;
        }

        /// <summary>
        /// This method will perform the specified action on the exception
        /// </summary>
        /// <param name="ex">The exception on which to perform the action</param>
        /// <param name="action">The action to perform</param>
        /// <param name="customHandler">If the action is to delegate, then the CustomHandler to delegate to, otherwise null</param>
        /// <param name="handled">true if this exception is a handled exception, otherwise false</param>
        protected virtual void PerformAction(Exception ex, Action action, CustomHandler customHandler, bool handled)
        {
            if ((action & Action.EventLogger) == Action.EventLogger)
            {
                PrintErrorInfoToEventLogger(ex);
            }
            if ((action & Action.DebugOut) == Action.DebugOut)
            {
                PrintErrorInfoToDebugOutputWindow(ex, handled);
            }
            if ((action & Action.Delegate) == Action.Delegate)
            {
                if (customHandler != null)
                {
                    customHandler(ex);
                }
            }
            // if action & Action.Rethrow == Action.Rethrow ... the exception will be rethrown by HandleException
        }

        #endregion

        #region private methods

        private bool InternalHandleException(Exception ex, ref Action action)
        {
            bool handled = false;
            action = Action.None;
            CustomHandler customHandler = null;
            if (CanHandleException(ex, ref action, ref customHandler))
            {
                PerformAction(ex, action, customHandler, true);
                handled = true;
                _handledException = ex;
            }
            if (!handled && ex.InnerException != null)
            {
                handled = InternalHandleException(ex.InnerException, ref action);
            }
            if (!handled)
            {
                PerformAction(ex, _unhandledAction, _unhandledCustomHandler, false);
            }

            return handled;
        }

        /// <summary>
        /// This method prints error information to the debug output window
        /// </summary>
        /// <param name="ex">The exception</param>
        /// <param name="bHandled">true if this exception is 'handled', this information will be printed in the debug output window</param>
        private void PrintErrorInfoToDebugOutputWindow(Exception ex, bool bHandled)
        {
            StringWriter sw = new StringWriter();
            if (!bHandled)
            {
                sw.WriteLine(string.Format( Thread.CurrentThread.CurrentCulture, Strings.UnhandledExceptionErrorFormat, this.GetType().Name));
            }
            else
            {
                sw.WriteLine(string.Format(Strings.HandledTheFollowingExceptionFormat, this.GetType().Name));
            }
            sw.WriteLine();

            // Dig into the inner exceptions to report an exception of actual value and 
            // to get the full stack trace to where the error occurred.
            Stack stackTraces = new Stack();
            Exception e = ex;
            string prefix = "";
            while (e != null)
            {
                sw.WriteLine(string.Format("{0}{1}: {2}", prefix, e.GetType().Name, e.Message));
                if (e.StackTrace != null && e.StackTrace != string.Empty)
                {
                    stackTraces.Push(e.StackTrace);
                }
                e = e.InnerException;
                if (prefix == string.Empty)
                {
                    prefix = "InnerException: ";
                }
            }

            // write out the stack
            sw.WriteLine();
            sw.WriteLine(Strings.StackTrace);
            while (stackTraces.Count > 0)
            {
                sw.WriteLine(stackTraces.Pop().ToString());
            }
                    
            // report out the stack from here to provide additional context
            StackTrace st = new StackTrace(true);
            sw.WriteLine();
            sw.WriteLine(Strings.ExceptionBeingReportedAt);
            sw.WriteLine(st.ToString());

            Trace.Write(sw.ToString());   
        }


        /// <summary>
        /// This method logs the exception in the event logger
        /// </summary>
        /// <param name="ex">The exception to log</param>
        private void PrintErrorInfoToEventLogger(Exception ex)
        {
            EventLogger.LogException(ex);
        }

        #endregion
    }

    internal class ExceptionInfo
    {
        #region private fields
        private Type _type = null;
        private ExceptionHandler.Action _action = ExceptionHandler.Action.None;
        private ExceptionHandler.CustomHandler _customHandler = null;
        #endregion

        internal ExceptionInfo(Type exceptionType, ExceptionHandler.Action action, ExceptionHandler.CustomHandler customHandler)
        {
            _type = exceptionType;
            _action = action;
            _customHandler = customHandler;
        }

        internal Type Type
        {
            get
            {
                return _type;
            }
        }

        internal ExceptionHandler.Action Action
        {
            get
            {
                return _action;
            }
        }

        internal ExceptionHandler.CustomHandler CustomHandler
        {
            get
            {
                return _customHandler;
            }
        }
    }
}
