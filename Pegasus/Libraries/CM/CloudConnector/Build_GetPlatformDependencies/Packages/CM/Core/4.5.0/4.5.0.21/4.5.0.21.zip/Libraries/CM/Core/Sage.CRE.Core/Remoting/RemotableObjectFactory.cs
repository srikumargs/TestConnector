using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.XPath;
using System.Runtime.InteropServices;

namespace Sage.Remoting
{
    /// <summary>
    /// Used to create one or more RemotableObject instances from Xml configuration file
    /// </summary>
    [ComVisible(false)]
    public class RemotableObjectFactory
    {
        #region Constructors
        /// <summary>
        /// Disable the default constructor
        /// </summary>
        private RemotableObjectFactory()
        {
        }

        /// <summary>
        /// set the IUrlPersist collection and the remote host xml node
        /// </summary>
        /// <param name="remotableObjectHostNavigator"></param>
        /// <param name="hostId"></param>
        /// <param name="urlWriter"></param>
        public RemotableObjectFactory(XPathNavigator remotableObjectHostNavigator, string hostId, IUrlWriter urlWriter)
        {
            _remotableObjectHostNavigator = remotableObjectHostNavigator;
            _hostId = hostId;
            _urlWriter = urlWriter;
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Factory method for a given xml object node
        /// </summary>
        /// <param name="objNav"></param>
        /// <returns></returns>
        public virtual RemotableObject Create(XPathNavigator objNav)
        {
            return new RemotableObject(objNav, _remotableObjectHostNavigator, _hostId, _urlWriter);
        }
        #endregion

        #region Protected properties
        /// <summary>
        /// Gets the host id.
        /// </summary>
        /// <value>The host id.</value>
        protected string HostId
        {
            get
            {
                return _hostId;
            }
        }

        /// <summary>
        /// Gets the remotable object host navigator.
        /// </summary>
        /// <value>The remotable object host navigator.</value>
        protected XPathNavigator RemotableObjectHostNavigator
        {
            get
            {
                return _remotableObjectHostNavigator;
            }
        }

        /// <summary>
        /// Gets the URL writer.
        /// </summary>
        /// <value>The URL writer.</value>
        protected IUrlWriter UrlWriter
        {
            get
            {
                return _urlWriter;
            }
        }
        #endregion

        #region Private fields
        // passed in
        private readonly string _hostId;

        // the root node for the RemoteHost
        private XPathNavigator _remotableObjectHostNavigator;

        // The persistence for the url
        private IUrlWriter _urlWriter;
        #endregion
    }
}
