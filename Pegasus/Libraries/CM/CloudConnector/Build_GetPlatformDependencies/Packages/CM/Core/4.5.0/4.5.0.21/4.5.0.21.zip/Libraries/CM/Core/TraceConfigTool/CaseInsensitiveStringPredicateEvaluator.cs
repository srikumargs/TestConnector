using System;
using System.Collections.Generic;
using System.Text;

namespace TraceConfigTool
{
    internal sealed class CaseInsensitiveStringPredicateEvaluator
    {
        #region Constructors
        public CaseInsensitiveStringPredicateEvaluator(string stringToMatch)
        {
            _stringToMatch = stringToMatch;
        }
        #endregion

        #region Public methods
        public bool Matches(string value)
        {
            return (string.Compare(value, _stringToMatch, true) == 0);
        }
        #endregion

        #region Private fields
        private string _stringToMatch;
        #endregion
    }
}
