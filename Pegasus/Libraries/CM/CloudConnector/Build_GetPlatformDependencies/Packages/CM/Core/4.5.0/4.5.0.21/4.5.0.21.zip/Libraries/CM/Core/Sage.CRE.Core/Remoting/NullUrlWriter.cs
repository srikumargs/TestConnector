using System;
using System.Diagnostics;
using System.Runtime.InteropServices;


namespace Sage.Remoting
{
    /// <summary>
    /// Null Object pattern
    /// </summary>
    public class NullUrlWriter : IUrlWriter
    {
    
        #region Implementation of IUrlWriter

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contextInfo"></param>
        public void Open(string contextInfo)
        {
        
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="urlKey"></param>
        /// <param name="urlValue"></param>
        public void SaveUrl(string urlKey, string urlValue)
        {
        
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="urlKey"></param>
        public void RemoveUrl(string urlKey)
        {
        
        }
        /// <summary>
        /// 
        /// </summary>
        public void Close()
        {
        
        }
        /// <summary>
        /// 
        /// </summary>
        public IFormatter Formatter
        {
            set
            {
            }
        }
        #endregion
    }
}