using System;
using System.Collections;
using System.Collections.Specialized;
using System.Reflection;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;

// This source file resides in the "LinkedSource" source code folder in order to prevent the introduction
// of a new dependency on a custom assembly which may not be present at install time.
namespace Sage.CRE.LinkedSource
{
    /// <summary>
    /// A static helper class that can be used to facilitate the calling of objects
    /// within an isolated AppDomain without introducing a dependency on any other
    /// (custom) assembly which would define the interface used to go across the
    /// AppDomain boundary.
    /// </summary>
    internal class IsolatedAppDomainHelper : IDisposable
    {
        /// <summary>
        /// A simple method to create an app-domain and invoke a delegate in it in one shot.
        /// </summary>
        /// <param name="delegateToInvoke"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static Object InvokeDelegate(Delegate delegateToInvoke, params Object[] args)
        {
            AppDomain appDomain = AppDomain.CreateDomain(String.Format("{0}-Invoke-{1}", typeof(IsolatedAppDomainHelper).FullName, delegateToInvoke.GetHashCode()));
            Object result = null;
            try
            {
                result = InvokeDelegate(delegateToInvoke, appDomain, args);
            }
            finally
            {
                AppDomain.Unload(appDomain);
            }
            return result;
        }

        private static Object InvokeDelegate(Delegate delegateToInvoke, AppDomain targetAppDomain, params Object[] args)
        {
            DelegateDynamicInvoker delegateInvoker = new DelegateDynamicInvoker(delegateToInvoke, args);
            targetAppDomain.DoCallBack(new CrossAppDomainDelegate(delegateInvoker.Invoke));
            return delegateInvoker.GetInvokeResultOnAppDomain(targetAppDomain);
        }

        [Serializable]
        private sealed class DelegateDynamicInvoker
        {
            public DelegateDynamicInvoker(Delegate delegateToInvoke, Object[] args)
            {
                _delegateToInvoke = delegateToInvoke;
                _args = args;
                _hashCode = delegateToInvoke.GetHashCode();
            }

            public void Invoke()
            {
                if (_delegateToInvoke != null)
                {
                    AppDomain.CurrentDomain.SetData(AppDomainResultDataKey, _delegateToInvoke.DynamicInvoke(_args));
                }
            }

            public Object GetInvokeResultOnAppDomain(AppDomain targetAppDomain)
            {
                return targetAppDomain.GetData(AppDomainResultDataKey);
            }

            private String AppDomainResultDataKey
            {
                get { return String.Format("{0}-result-{1}", typeof(DelegateDynamicInvoker).FullName, _hashCode); }
            }

            private Delegate _delegateToInvoke;
            private Object[] _args;
            private Int32 _hashCode;
        }


        #region Constructors
        /// <summary>
        /// Constructor
        /// </summary>
        public IsolatedAppDomainHelper(string domainFriendlyName)
        {
            //Assertions.Assert(domainFriendlyName != null && domainFriendlyName.Length > 0);

            _domainFriendlyName = domainFriendlyName;
            _configurationFile = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public IsolatedAppDomainHelper(String domainFriendlyName, String configurationFile)
        {
            //Assertions.Assert(domainFriendlyName != null && domainFriendlyName.Length > 0);

            _domainFriendlyName = domainFriendlyName;
            _configurationFile = configurationFile;
        }
        #endregion

        /// <summary>
        /// Standard IDisposable implementation
        /// </summary>
        public void Dispose()
        {
            Dispose(true);

            // This object will be cleaned up by the Dispose method.  Therefore, you should call GC.SupressFinalize to
            // take this object off the finalization queue and prevent finalization code for this object from executing
            // a second time.
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// C# destructor syntax for finalization code.  This destructor will run only if the Dispose method 
        /// does not get called.
        /// </summary>
        ~IsolatedAppDomainHelper()
        {
            // Do not re-create Dispose clean-up code here.
            // Calling Dispose(false) is optimal in terms of readability and maintainability.

            Dispose(false);
        }

        /// <summary>
        /// Standard IDisposable implementation
        /// </summary>
        /// <param name="disposing">true if this object is being disposed; false if it is being finalized</param>
        private void Dispose(bool disposing)
        {
            lock(_syncRoot)
            {
                // Check to see if Dispose has already been called.
                if(!_disposed)
                {
                    // If disposing equals true, dispose all managed and unmanaged resources ... the
                    // method has been called directly (or indirectly) by user's code.
                    //
                    // If disposing equals false, then the method has been called by the runtime from
                    // inside the finalizer and so, no other managed objects should be referenced.  Only
                    // unmanaged resources can be disposed.
                    if(disposing)
                    {
                        // Dispose managed resources here.
                        UnloadAppDomain();
                    }

                    // Clean up unmanaged resources here.
                }

                _disposed = true;
            }
        }

        /// <summary>
        /// Makes certain that this object instance hasn't already been disposed
        /// </summary>
        private void VerifyNotDisposed()
        {
            lock (_syncRoot)
            {
                if(_disposed)
                {
                    throw new ObjectDisposedException(this.GetType().FullName);
                }
            }
        }

        private bool _disposed; //= false; (automatically initialized by runtime)

        #region Public methods
        public object CreateInstanceAndUnwrap(Type targetType)
        {
            //Assertions.Assert(targetType != null);

            object result = null;

            lock (_syncRoot)
            {
                result =  AppDomain.CreateInstanceAndUnwrap(Assembly.GetExecutingAssembly().GetName().FullName, targetType.FullName);
            }

            return result;
        }

        public object InvokeMethod(object target, Type targetType, string methodName, params object[] parameterList)
        {
            //Assertions.Assert(target != null);
            //Assertions.Assert(targetType != null);
            //Assertions.Assert(methodName != null && methodName.Length > 0);

            object result = null;

            if(methodName != null && methodName.Length > 0)
            {
                result = TargetInvoker.InvokeMember(methodName, BindingFlags.Instance | BindingFlags.InvokeMethod | BindingFlags.Public, null, target, parameterList, null, null, null);
            }

            return result;
        }

        public object InvokeStaticMethod(Type targetType, string methodName, params object[] parameterList)
        {
            //Assertions.Assert(targetType != null);
            //Assertions.Assert(methodName != null && methodName.Length > 0);

            object result = null;

            if(methodName != null && methodName.Length > 0)
            {
                Object[] supplementedParameterList = new Object[parameterList.GetLength(0) + 1];
                supplementedParameterList[0] = targetType;
                Array.Copy(parameterList, 0, supplementedParameterList, 1, parameterList.GetLength(0));
                result = TargetInvoker.InvokeMember(methodName, BindingFlags.InvokeMethod, null, null, supplementedParameterList, null, null, null);
            }

            return result;
        }

        public void UnloadAppDomain()
        {
            lock (_syncRoot)
            {
                if(_targetInvoker != null)
                {
                    _targetInvoker = null;
                }

                if(_isolatedAppDomain != null)
                {
                    AppDomain.Unload(_isolatedAppDomain);
                    _isolatedAppDomain = null;
                }
            }
        }
        #endregion

        #region Private properties
        private AppDomain AppDomain
        {
            get
            {
                AppDomain result = null;

                lock (_syncRoot)
                {
                    if(_isolatedAppDomain == null)
                    {
                        // setup the AppDomain
                        AppDomainSetup appDomainSetup = new AppDomainSetup();
                        appDomainSetup.ApplicationBase = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                        appDomainSetup.PrivateBinPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                        appDomainSetup.ConfigurationFile = _configurationFile;

                        // create the AppDomain
                        _isolatedAppDomain = AppDomain.CreateDomain(_domainFriendlyName, Assembly.GetExecutingAssembly().Evidence, appDomainSetup);

                        // initialize the Library Manager in the new AppDomain
                        //String libraryManifestLocation = (String) InvokeStaticMethod(typeof(Sage.Configuration.LibraryManager), "LibraryManifestLocationForBinary", new Object[] { Assembly.GetExecutingAssembly().Location });
                        //InvokeStaticMethod(typeof(Sage.Configuration.LibraryManager), "InitializeLibraries", new object[] { libraryManifestLocation });
                    }

                    result = _isolatedAppDomain;
                }

                return result;
            }
        }

        private IReflect TargetInvoker
        {
            get
            {
                IReflect result = null;

                lock (_syncRoot)
                {
                    if(_targetInvoker == null)
                    {
                        object o = AppDomain.CreateInstanceAndUnwrap(Assembly.GetExecutingAssembly().GetName().FullName, typeof(TargetMemberInvoker).FullName);
                        _targetInvoker = (IReflect) o;
                    }

                    result = _targetInvoker;
                }

                return result;
            }
        }
        #endregion

        #region Private fields
        private readonly Object _syncRoot = new Object();
        private string _domainFriendlyName;
        private String _configurationFile;
        private AppDomain _isolatedAppDomain;
        private IReflect _targetInvoker;
        #endregion

        #region Protected types
        /// <summary>
        /// Utility class used by the AppDomainIsolationHelper to invoke an instance method in a cross-AppDomain context.
        /// </summary>
        /// <remarks>
        /// There are two important design elements to this class:
        ///     1) it is a MarshalByRefObject so it can be marshalled across AppDomain boundaries
        ///     2) it implements a standard interface (i.e., IReflect) which is NOT defined in this assembly
        /// </remarks>
        protected sealed class TargetMemberInvoker : MarshalByRefObject, IReflect
        {
            #region Constructors
            /// <summary>
            /// Creates a new instance of the TargetMemberInvoker class.
            /// </summary>
            public TargetMemberInvoker()
            {
            }
            #endregion

            /// <summary>
            /// Override and return null to specify infinite lifetime for the singleton.
            /// </summary>
            public override object InitializeLifetimeService()
            {
                return null;
            }

            #region Public properties
            /// <summary>
            /// Gets the underlying type that represents the IReflect object.
            /// </summary>
            /// <remarks>Not implemented.</remarks>
            Type IReflect.UnderlyingSystemType
            {
                get
                {
                    if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                    {
                        throw new NotImplementedException();
                    }
                    return null;
                }
            }
            #endregion

            #region Public methods
            /// <summary>
            /// Returns the FieldInfo object corresponding to the specified field and BindingFlag.
            /// </summary>
            /// <param name="name"></param>
            /// <param name="bindingAttr"></param>
            /// <returns></returns>
            /// <remarks>Not implemented.</remarks>
            FieldInfo IReflect.GetField(string name, BindingFlags bindingAttr)
            {
                if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                {
                    throw new NotImplementedException();
                }
                return null;
            }

            /// <summary>
            /// Returns an array of FieldInfo objects corresponding to all fields of the current class.
            /// </summary>
            /// <param name="bindingAttr"></param>
            /// <returns></returns>
            /// <remarks>Not implemented.</remarks>
            FieldInfo[] IReflect.GetFields(BindingFlags bindingAttr)
            {
                if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                {
                    throw new NotImplementedException();
                }
                return null;
            }

            /// <summary>
            /// Retrieves an array of MemberInfo objects corresponding to all public members or to all members that match a specified name.
            /// </summary>
            /// <param name="name"></param>
            /// <param name="bindingAttr"></param>
            /// <returns></returns>
            /// <remarks>Not implemented.</remarks>
            MemberInfo[] IReflect.GetMember(string name, BindingFlags bindingAttr)
            {
                if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                {
                    throw new NotImplementedException();
                }
                return null;
            }

            /// <summary>
            /// Retrieves an array of MemberInfo objects corresponding either to all public members or to all members of the current class.
            /// </summary>
            /// <param name="bindingAttr"></param>
            /// <returns></returns>
            /// <remarks>Not implemented.</remarks>
            MemberInfo[] IReflect.GetMembers(BindingFlags bindingAttr)
            {
                if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                {
                    throw new NotImplementedException();
                }
                return null;
            }

            /// <summary>
            /// Retrieves a MethodInfo object corresponding to a specified method.
            /// </summary>
            /// <param name="name"></param>
            /// <param name="bindingAttr"></param>
            /// <returns></returns>
            /// <remarks>Not implemented.</remarks>
            MethodInfo IReflect.GetMethod(string name, BindingFlags bindingAttr)
            {
                if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                {
                    throw new NotImplementedException();
                }
                return null;
            }

            /// <summary>
            /// Retrieves a MethodInfo object corresponding to a specified method, using a Type array to choose from among overloaded methods.
            /// </summary>
            /// <param name="name"></param>
            /// <param name="bindingAttr"></param>
            /// <param name="binder"></param>
            /// <param name="types"></param>
            /// <param name="modifiers"></param>
            /// <returns></returns>
            /// <remarks>Not implemented.</remarks>
            MethodInfo IReflect.GetMethod(string name, BindingFlags bindingAttr, Binder binder, Type[] types, ParameterModifier[] modifiers)
            {
                if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                {
                    throw new NotImplementedException();
                }
                return null;
            }

            /// <summary>
            /// Retrieves an array of MethodInfo objects with all public methods or all methods of the current class.
            /// </summary>
            /// <param name="bindingAttr"></param>
            /// <returns></returns>
            /// <remarks>Not implemented.</remarks>
            MethodInfo[] IReflect.GetMethods(BindingFlags bindingAttr)
            {
                if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                {
                    throw new NotImplementedException();
                }
                return null;
            }

            /// <summary>
            /// Retrieves an array of PropertyInfo objects corresponding to all public properties or to all properties of the current class.
            /// </summary>
            /// <param name="bindingAttr"></param>
            /// <returns></returns>
            /// <remarks>Not implemented.</remarks>
            PropertyInfo[] IReflect.GetProperties(BindingFlags bindingAttr)
            {
                if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                {
                    throw new NotImplementedException();
                }
                return null;
            }

            /// <summary>
            /// Retrieves a PropertyInfo object corresponding to a specified property under specified search constraints.
            /// </summary>
            /// <param name="name"></param>
            /// <param name="bindingAttr"></param>
            /// <returns></returns>
            /// <remarks>Not implemented.</remarks>
            PropertyInfo IReflect.GetProperty(string name, BindingFlags bindingAttr)
            {
                if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                {
                    throw new NotImplementedException();
                }
                return null;
            }

            /// <summary>
            /// Retrieves a PropertyInfo object corresponding to a specified property with specified search constraints.
            /// </summary>
            /// <param name="name"></param>
            /// <param name="bindingAttr"></param>
            /// <param name="binder"></param>
            /// <param name="returnType"></param>
            /// <param name="types"></param>
            /// <param name="modifiers"></param>
            /// <returns></returns>
            /// <remarks>Not implemented.</remarks>
            PropertyInfo IReflect.GetProperty(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers)
            {
                if(_throwNotImplementedException) // comparison performed in order to suppress 'warning CS0162: Unreachable code detected'
                {
                    throw new NotImplementedException();
                }
                return null;
            }

            /// <summary>
            /// Invokes a specified member.
            /// </summary>
            /// <param name="name"></param>
            /// <param name="invokeAttr"></param>
            /// <param name="binder"></param>
            /// <param name="target"></param>
            /// <param name="args"></param>
            /// <param name="modifiers"></param>
            /// <param name="culture"></param>
            /// <param name="namedParameters"></param>
            /// <returns></returns>
            /// <remarks>Implemented to work only on instance members (rather than static members)</remarks>
            [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", Scope = "member", Target = "Sage.CRE.LinkedSource.AppDomainIsolationHelper+TargetMemberInvoker.System.Reflection.IReflect.InvokeMember(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object,System.Object[],System.Reflection.ParameterModifier[],System.Globalization.CultureInfo,System.String[]):System.Object", MessageId = "System.ArgumentException.#ctor(System.String,System.String)")]
            object IReflect.InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, object[] args, ParameterModifier[] modifiers, System.Globalization.CultureInfo culture, string[] namedParameters)
            {
                Object[] realArgs;
                Type targetType;
                if((invokeAttr & BindingFlags.Instance) != BindingFlags.Instance)
                {
                    targetType = (args[0] as Type);
                    realArgs = new Object[args.GetLength(0) - 1];
                    Array.Copy(args, 1, realArgs, 0, args.GetLength(0) - 1);
                }
                else
                {
                    if(target == null)
                    {
                        throw new ArgumentNullException("target");
                    }

                    targetType = target.GetType();
                    realArgs = args;
                }

                return targetType.InvokeMember(name, invokeAttr, binder, target, realArgs, modifiers, culture, namedParameters);
            }
            #endregion

            #region Private methods
            private bool _throwNotImplementedException = true; // a simplistic approach to getting the compiler to not complain about methods which are not implemented
            #endregion

        }
        #endregion
    }
}