using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using Sage.Diagnostics;

namespace Sage.IO
{
    
   
	/// <summary>
	/// A class for reading files in a folder
	/// </summary>
	/// <remarks>Use this class for reading file based data that 
	/// may be spread accross multiple files in a specific folder</remarks>
	public class FolderContentsReader: IDataStreamProvider
	{

        #region Types

        // Encryption type.
        private enum EncryptionAction
        {
            Encrypt,
            Decrypt
        }

        #endregion

        #region Fields

        // File reader settings
        private readonly FolderContentsReaderInfo _info = null;

        // A dynamic cache of read in file streams
        private readonly SortedList _streamCache = null;

        // Monitor the folder for changes with encrypted files 
        private FileSystemWatcher _encryptedFileMonitor = null; 

        // Monitor the folder for changes with unencrypted files 
        private FileSystemWatcher _unEncryptedFileMonitor = null;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="folder">The folder to process</param>
        /// <remarks>This constructor uses the default values 
        /// provided by the FolderContentsReaderInfo class. To override 
        /// the default settings, use the alternate constructor and 
        /// pass in FolderContentsReaderInfo</remarks>
		public FolderContentsReader( string folder )
		{
            _info = new FolderContentsReaderInfo( folder );
            if( _info.CacheFileStreams )
            {
                _streamCache = new SortedList();
            }
            InitializeFolderMonitor();
		}

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="info">FolderContentsReader settings</param>
        public FolderContentsReader( FolderContentsReaderInfo info )
        {
            _info = info;
            if( _info.CacheFileStreams )
            {
                _streamCache = new SortedList();
            }
            InitializeFolderMonitor();
        }

        /// <summary>
        /// Event fired before a file is read
        /// </summary>
        public event BeforeDataReadEventHandler BeforeDataRead;

        /// <summary>
        /// Event fired when a file is read
        /// </summary>
        public event DataReadEventHandler DataRead;

        /// <summary>
        /// A new file has been added into the monitored file folder
        /// </summary>
        public event DataSourceEventHandler DataSourceAdded;

        /// <summary>
        /// A file has been removed from the monitored file folder
        /// </summary>
        public event DataSourceEventHandler DataSourceDeleted;

        /// <summary>
        /// Read all the applicable files in the designated folder
        /// </summary>
        /// <remarks>If caching is on the streams are stored in the cache. If not, you must 
        /// must retrieve the read streams via the file read event</remarks>
        public void Read()
        {
            ClearStreamCache();
            if( _info.ProcessUnEncryptedFiles )
            {
                foreach( string file in Directory.GetFiles( _info.Folder, _info.UnEncryptedFileFilter ) )
                {
                    BeforeDataReadEventArgs args = new BeforeDataReadEventArgs( file );
                    ReadFile( args );
                    if( args.CancelAllRemainingDataSourceReads )
                    {
                        return;   
                    }
                }
            }

            if( _info.ProcessEncryptedFiles )
            {
                foreach( string file in Directory.GetFiles( _info.Folder, _info.EncryptedFileFilter ) )
                {
                    BeforeDataReadEventArgs args = new BeforeDataReadEventArgs( file );
                    ReadFile( args );
                    if( args.CancelAllRemainingDataSourceReads )
                    {
                        return;   
                    }
                }
            }
        }

        /// <summary>
        /// Read a specific file and return a stream
        /// </summary>
        /// <param name="dataSourceId">The full name and path of a file to read</param>
        /// <returns>A stream of all the bytes in the file</returns>
        public Stream ReadDataStream( string dataSourceId )
        {
            BeforeDataReadEventArgs args = new BeforeDataReadEventArgs( dataSourceId );
            return ReadFile( args );
        }

        /// <summary>
        /// Clear the collection of processed files
        /// </summary>
        public void ClearStreamCache()
        {
            if( _streamCache != null )
            {
                _streamCache.Clear();
            }
        }

        /// <summary>
        /// Retrieve a collection of file names of all files read in the batch
        /// </summary>
        public ICollection CachedDataSourceIds
        {
            get
            { 
                ICollection retval = null;
                if( _streamCache != null )
                { 
                    retval = _streamCache.Keys; 
                }
                return retval;
            }
        }

        /// <summary>
        /// Retrieve a collection of all the file streams read from the folder
        /// </summary>
        public ICollection CachedDataStreams
        {
            get
            { 
                ICollection retval = null;
                if( _streamCache != null )
                {
                    retval = _streamCache.Values;
                }
                return retval;
            }
        }

        /// <summary>
        /// Retrieve the file stream for a particular file
        /// </summary>
        /// <param name="dataSourceId">The name of the file</param>
        /// <returns>The stream of the named file</returns>
        public Stream GetCachedDataStream( string dataSourceId )
        {
            ArgumentValidator.ValidateNonEmptyString( dataSourceId, "dataSourceId", this.GetType().Name );
            Stream retval = null;
            if( _streamCache != null && _streamCache.Contains( dataSourceId ) )
            {
                retval = (Stream)_streamCache[dataSourceId];
            }
            return retval;
        }

        /// <summary>
        /// Remove a file stream from the cache
        /// </summary>
        /// <param name="dataSourceId">The name of the file whose stream should be removed</param>
        public void RemoveCachedDataStream( string dataSourceId )
        {
            ArgumentValidator.ValidateNonEmptyString( dataSourceId, "dataSourceId", this.GetType().Name );
            if( _streamCache != null && _streamCache.Contains( dataSourceId ) )
            {
                _streamCache.Remove( dataSourceId );
            }
        }

        /// <summary>
        /// Read a in a file
        /// </summary>
        /// <param name="args">BeforeFileReadEventArgs with the file to read already set</param>
        /// <returns>A stream containing the files data</returns>
        private Stream ReadFile( BeforeDataReadEventArgs args )
        {
            Stream fileStream = null;
            if( BeforeDataRead != null )
            {
                BeforeDataRead( this, args );
            }
            if( !args.CancelAllRemainingDataSourceReads && !args.SkipThisDataSource )
            {
                fileStream = ReadFileStream( args.DataSourceId );
                if( _streamCache != null )
                {
                    if( _streamCache.Contains( args.DataSourceId ) )
                    {
                        _streamCache[args.DataSourceId] = fileStream;  
                    }
                    else
                    {
                        _streamCache.Add( args.DataSourceId, fileStream );
                    }
                }
            }
            return fileStream;
        }

        /// <summary>
        /// Read a stream of bytes from a file
        /// </summary>
        /// <param name="filePath">The path to the file to process</param>
        /// <returns>The retrieved stream of bytes</returns>
        private Stream ReadFileStream( string filePath )
        {
            ArgumentValidator.ValidateNonEmptyString( filePath, "filePath", this.GetType().Name );

            byte[] bytes = ReadBytes( filePath );
            if( Path.GetExtension( filePath ).ToLower() == Path.GetExtension( _info.EncryptedFileFilter ) )
            {
                bytes = Crypto( bytes, EncryptionAction.Decrypt );
            }
            System.IO.MemoryStream stream = new MemoryStream( bytes, 0, bytes.Length );
            OnFileRead( filePath, stream, bytes.Length );
            return stream;
        }

        /// <summary>
        /// Read a stream of bytes from a file
        /// </summary>
        /// <param name="path">The full name and path of the file to read from</param>
        /// <returns></returns>
        private byte[] ReadBytes( string path )
        {
            byte[] bytes = null;
            FileStream stream = new FileStream( path, FileMode.Open, FileAccess.Read );
            BinaryReader reader = new BinaryReader( stream );
            bytes = reader.ReadBytes( (int)stream.Length );
            reader.Close();
            stream.Close();
            return bytes;
            
        }

        /// *************************************************************
        /// <summary>
        /// Encrypt/Decrypt a data array
        /// </summary>
        /// <param name="data">The bytes to encrypt/decrypt</param>
        /// <param name="action">The encryption action to perform</param>
        /// <returns>A encrypted byte array</returns>
        /// *************************************************************
        private byte[] Crypto( byte[] data, EncryptionAction action )
        {
            byte[] buffer = null;
            byte[] Key = {0xD,  0x20, 0x8A, 0xCF, 0x3D, 0xA5, 0xC,  0x98};
            byte[] IV =  {0x5C, 0x10, 0x6F, 0xB4, 0x18, 0x40, 0xD8, 0xEE};

            DESCryptoServiceProvider DES = new DESCryptoServiceProvider();
            if( action ==  EncryptionAction.Encrypt )
            {
                buffer = DES.CreateEncryptor( Key, IV ).TransformFinalBlock( data, 0, data.Length );
            }
            else
            {   
                buffer =  DES.CreateDecryptor( Key, IV ).TransformFinalBlock( data, 0, data.Length );
            }
            
            return buffer;
        }

        /// <summary>
        /// Fire the File Read event
        /// </summary>
        /// <param name="file">The file that was read</param>
        /// <param name="fileStream">The file stream read</param>
        /// <param name="streamSize">The number of bytes in the file stream</param>
        private void OnFileRead( string file, Stream fileStream, int streamSize )
        {
            if( DataRead != null )
            {
                DataRead( this, new DataReadEventArgs( file, fileStream, streamSize ) );
            }
        }

        /// <summary>
        /// Initialize the folder monitors
        /// </summary>
        private void InitializeFolderMonitor()
        {
            if( _info.MonitorFolderForChanges )
            {
                if( _info.ProcessEncryptedFiles )
                {
                    _encryptedFileMonitor = new FileSystemWatcher( _info.Folder, _info.EncryptedFileFilter );
                    _encryptedFileMonitor.Created += new FileSystemEventHandler( OnFileAdded );
                    _encryptedFileMonitor.Deleted += new FileSystemEventHandler( OnFileDeleted );
                    _encryptedFileMonitor.EnableRaisingEvents = true;
                }
                if( _info.ProcessUnEncryptedFiles )
                {
                    _unEncryptedFileMonitor = new FileSystemWatcher( _info.Folder, _info.UnEncryptedFileFilter );
                    _unEncryptedFileMonitor.Created += new FileSystemEventHandler( OnFileAdded );
                    _unEncryptedFileMonitor.Deleted += new FileSystemEventHandler( OnFileDeleted );
                    _unEncryptedFileMonitor.EnableRaisingEvents = true;
                }
            }
        }

        /// <summary>
        /// Handle the file added event
        /// </summary>
        /// <param name="sender">One of the File System Watchers</param>
        /// <param name="args">Event arguments</param>
        private void OnFileAdded( object sender, FileSystemEventArgs args )
        {
            if( _info.CacheFileStreams )
            {
                ReadDataStream( args.FullPath );
            }
            if( DataSourceAdded != null )
            {
                DataSourceAdded( this, new DataSourceEventArgs( args.FullPath ) );
            }
        }

        /// <summary>
        /// Handle the file deleted event
        /// </summary>
        /// <param name="sender">One of theFile Sytems Watchers</param>
        /// <param name="args">Event Arguments</param>
        private void OnFileDeleted( object sender, FileSystemEventArgs args )
        {
            if( _info.CacheFileStreams )
            {
                RemoveCachedDataStream( args.FullPath );
            }
            if( DataSourceDeleted != null )
            {
                DataSourceDeleted( this, new DataSourceEventArgs( args.FullPath ) );
            }
        }

	}
}
