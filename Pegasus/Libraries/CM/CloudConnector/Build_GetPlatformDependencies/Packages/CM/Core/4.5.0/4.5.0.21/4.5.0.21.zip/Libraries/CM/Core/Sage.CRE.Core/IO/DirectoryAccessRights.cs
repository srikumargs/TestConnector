using System;
using System.Collections.Generic;
using System.IO;
using System.Security;
using System.Security.AccessControl;
using System.Security.Permissions;
using System.Security.Principal;
using System.Text;

namespace Sage.IO
{
    /// <summary>
    /// Checks the permission set of a certain folder for a specific user both of which
    /// are passed into the constructor of the class.
    /// </summary>
    public class DirectoryAccessRights
    {
        #region Private Member Variables
        private string _path;
        private WindowsIdentity _user;

        private bool _denyAppendData = false;
        private bool _denyChangePermissions = false;
        private bool _denyCreateDirectories = false;
        private bool _denyCreateFiles = false;
        private bool _denyDelete = false;
        private bool _denyDeleteSubdirectoriesAndFiles = false;
        private bool _denyExecuteFile = false;
        private bool _denyFullControl = false;
        private bool _denyListDirectory = false;
        private bool _denyModify = false;
        private bool _denyRead = false;
        private bool _denyReadAndExecute = false;
        private bool _denyReadAttributes = false;
        private bool _denyReadData = false;
        private bool _denyReadExtendedAttributes = false;
        private bool _denyReadPermissions = false;
        private bool _denySynchronize = false;
        private bool _denyTakeOwnership = false;
        private bool _denyTraverse = false;
        private bool _denyWrite = false;
        private bool _denyWriteAttributes = false;
        private bool _denyWriteData = false;
        private bool _denyWriteExtendedAttributes = false;

        private bool _allowAppendData = false;
        private bool _allowChangePermissions = false;
        private bool _allowCreateDirectories = false;
        private bool _allowCreateFiles = false;
        private bool _allowDelete = false;
        private bool _allowDeleteSubdirectoriesAndFiles = false;
        private bool _allowExecuteFile = false;
        private bool _allowFullControl = false;
        private bool _allowListDirectory = false;
        private bool _allowModify = false;
        private bool _allowRead = false;
        private bool _allowReadAndExecute = false;
        private bool _allowReadAttributes = false;
        private bool _allowReadData = false;
        private bool _allowReadExtendedAttributes = false;
        private bool _allowReadPermissions = false;
        private bool _allowSynchronize = false;
        private bool _allowTakeOwnership = false;
        private bool _allowTraverse = false;
        private bool _allowWrite = false;
        private bool _allowWriteAttributes = false;
        private bool _allowWriteData = false;
        private bool _allowWriteExtendedAttributes = false;
        #endregion

        #region Public Properties
        /// <summary>
        /// The path to retrieve permission information from.
        /// </summary>
        public string Path { get { return _path; } }

        /// <summary>
        /// The user to retrive permission information on.
        /// </summary>
        public WindowsIdentity User { get { return _user; } }

        /// <summary>
        /// Determine if the user has AppendDataRights to the path
        /// </summary>
        public bool HasAppendDataRights { get { return !_denyAppendData && _allowAppendData; } }

        /// <summary>
        /// Determine if the user has ChangePermissionsRights to the path
        /// </summary>
        public bool HasChangePermissionsRights { get { return !_denyChangePermissions && _allowChangePermissions; } }

        /// <summary>
        /// Determine if the user has CreateDirectoriesRights to the path
        /// </summary>
        public bool HasCreateDirectoriesRights { get { return !_denyCreateDirectories && _allowCreateDirectories; } }

        /// <summary>
        /// Determine if the user has CreateFilesRights to the path
        /// </summary>
        public bool HasCreateFilesRights { get { return !_denyCreateFiles && _allowCreateFiles; } }

        /// <summary>
        /// Determine if the user has DeleteRights to the path
        /// </summary>
        public bool HasDeleteRights { get { return !_denyDelete && _allowDelete; } }

        /// <summary>
        /// Determine if the user has DeleteSubdirectoriesAndFilesRights to the path
        /// </summary>
        public bool HasDeleteSubdirectoriesAndFilesRights { get { return !_denyDeleteSubdirectoriesAndFiles && _allowDeleteSubdirectoriesAndFiles; } }

        /// <summary>
        /// Determine if the user has ExecuteFileRights to the path
        /// </summary>
        public bool HasExecuteFileRights { get { return !_denyExecuteFile && _allowExecuteFile; } }

        /// <summary>
        /// Determine if the user has FullControlRights to the path
        /// </summary>
        public bool HasFullControlRights { get { return !_denyFullControl && _allowFullControl; } }

        /// <summary>
        /// Determine if the user has ListDirectoryRights to the path
        /// </summary>
        public bool HasListDirectoryRights { get { return !_denyListDirectory && _allowListDirectory; } }

        /// <summary>
        /// Determine if the user has ModifyRights to the path
        /// </summary>
        public bool HasModifyRights { get { return !_denyModify && _allowModify; } }

        /// <summary>
        /// Determine if the user has ReadRights to the path
        /// </summary>
        public bool HasReadRights { get { return !_denyRead && _allowRead; } }

        /// <summary>
        /// Determine if the user has ReadAndExecuteRights to the path
        /// </summary>
        public bool HasReadAndExecuteRights { get { return !_denyReadAndExecute && _allowReadAndExecute; } }

        /// <summary>
        /// Determine if the user has ReadAttributesRights to the path
        /// </summary>
        public bool HasReadAttributesRights { get { return !_denyReadAttributes && _allowReadAttributes; } }

        /// <summary>
        /// Determine if the user has ReadDataRights to the path
        /// </summary>
        public bool HasReadDataRights { get { return !_denyReadData && _allowReadData; } }

        /// <summary>
        /// Determine if the user has ReadExtendedAttributesRights to the path
        /// </summary>
        public bool HasReadExtendedAttributesRights { get { return !_denyReadExtendedAttributes && _allowReadExtendedAttributes; } }

        /// <summary>
        /// Determine if the user has ReadPermissionsRights to the path
        /// </summary>
        public bool HasReadPermissionsRights { get { return !_denyReadPermissions && _allowReadPermissions; } }

        /// <summary>
        /// Determine if the user has SynchronizeRights to the path
        /// </summary>
        public bool HasSynchronizeRights { get { return !_denySynchronize && _allowSynchronize; } }

        /// <summary>
        /// Determine if the user has TakeOwnershipRights to the path
        /// </summary>
        public bool HasTakeOwnershipRights { get { return !_denyTakeOwnership && _allowTakeOwnership; } }

        /// <summary>
        /// Determine if the user has TraverseRights to the path
        /// </summary>
        public bool HasTraverseRights { get { return !_denyTraverse && _allowTraverse; } }

        /// <summary>
        /// Determine if the user has WriteRights to the path
        /// </summary>
        public bool HasWriteRights { get { return !_denyWrite && _allowWrite; } }

        /// <summary>
        /// Determine if the user has WriteAttributesRights to the path
        /// </summary>
        public bool HasWriteAttributesRights { get { return !_denyWriteAttributes && _allowWriteAttributes; } }

        /// <summary>
        /// Determine if the user has WriteDataRights to the path
        /// </summary>
        public bool HasWriteDataRights { get { return !_denyWriteData && _allowWriteData; } }

        /// <summary>
        /// Determine if the user has WriteExtendedAttributesRights to the path
        /// </summary>
        public bool HasWriteExtendedAttributesRights { get { return !_denyWriteExtendedAttributes && _allowWriteExtendedAttributes; } }
        #endregion

        #region Constructors
        /// <summary>
        /// Constructor.  This will use the CurrentUser by default.
        /// </summary>
        /// <param name="path">path to retrieve permission information on.</param>
        public DirectoryAccessRights(string path)
            : this(path, WindowsIdentity.GetCurrent())
        {}

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="path">path to retrieve permission information on.</param>
        /// <param name="user">The user to retrieve permission information for.</param>
        public DirectoryAccessRights(string path, WindowsIdentity user)
        {
            _path = path;
            _user = user;

            try
            {
                //check for UNC and/or mapped path.  This will not work on mapped / UNC paths
                if (PathUtils.IsPathMappedDrive(_path) || PathUtils.IsPathUNC(_path))
                    return;

                CheckIfUserHasAccessToFolder();
                CheckIfUserGroupHasAccessToFolder();
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// This method checks to see what type of rights the user (member variable) has access
        /// to the folder (member variable).
        /// </summary>
        private void CheckIfUserHasAccessToFolder()
        {
            try
            {
                //retrieve the rules collection for the passed in path.  This will determine
                //what users and groups have access to this particular folder.  You can retrieve
                //this information by right-clicking on the file in Windows Explorer and going
                //into Properties.  Click the Security tab
                AuthorizationRuleCollection rulesColl =
                    Directory.GetAccessControl(_path).GetAccessRules(true, true, typeof(SecurityIdentifier));

                //walk through all users and determine if the passed in user has access to the folder
                foreach (FileSystemAccessRule rule in rulesColl)
                {
                    if (_user.User.Equals(rule.IdentityReference))
                    {
                        //It looks like the user has access to the folder, detrmine the user's rights
                        if (AccessControlType.Deny.Equals(rule.AccessControlType))
                        {
                            if (HasRights(FileSystemRights.AppendData, rule)) _denyAppendData = true;
                            if (HasRights(FileSystemRights.ChangePermissions, rule)) _denyChangePermissions = true;
                            if (HasRights(FileSystemRights.CreateDirectories, rule)) _denyCreateDirectories = true;
                            if (HasRights(FileSystemRights.CreateFiles, rule)) _denyCreateFiles = true;
                            if (HasRights(FileSystemRights.Delete, rule)) _denyDelete = true;
                            if (HasRights(FileSystemRights.DeleteSubdirectoriesAndFiles, rule)) _denyDeleteSubdirectoriesAndFiles = true;
                            if (HasRights(FileSystemRights.ExecuteFile, rule)) _denyExecuteFile = true;
                            if (HasRights(FileSystemRights.FullControl, rule)) _denyFullControl = true;
                            if (HasRights(FileSystemRights.ListDirectory, rule)) _denyListDirectory = true;
                            if (HasRights(FileSystemRights.Modify, rule)) _denyModify = true;
                            if (HasRights(FileSystemRights.Read, rule)) _denyRead = true;
                            if (HasRights(FileSystemRights.ReadAndExecute, rule)) _denyReadAndExecute = true;
                            if (HasRights(FileSystemRights.ReadAttributes, rule)) _denyReadAttributes = true;
                            if (HasRights(FileSystemRights.ReadData, rule)) _denyReadData = true;
                            if (HasRights(FileSystemRights.ReadExtendedAttributes, rule)) _denyReadExtendedAttributes = true;
                            if (HasRights(FileSystemRights.ReadPermissions, rule)) _denyReadPermissions = true;
                            if (HasRights(FileSystemRights.Synchronize, rule)) _denySynchronize = true;
                            if (HasRights(FileSystemRights.TakeOwnership, rule)) _denyTakeOwnership = true;
                            if (HasRights(FileSystemRights.Traverse, rule)) _denyTraverse = true;
                            if (HasRights(FileSystemRights.Write, rule)) _denyWrite = true;
                            if (HasRights(FileSystemRights.WriteAttributes, rule)) _denyWriteAttributes = true;
                            if (HasRights(FileSystemRights.WriteData, rule)) _denyWriteData = true;
                            if (HasRights(FileSystemRights.WriteExtendedAttributes, rule)) _denyWriteExtendedAttributes = true;
                        }
                        else if (AccessControlType.Allow.Equals(rule.AccessControlType))
                        {
                            if (HasRights(FileSystemRights.AppendData, rule)) _allowAppendData = true;
                            if (HasRights(FileSystemRights.ChangePermissions, rule)) _allowChangePermissions = true;
                            if (HasRights(FileSystemRights.CreateDirectories, rule)) _allowCreateDirectories = true;
                            if (HasRights(FileSystemRights.CreateFiles, rule)) _allowCreateFiles = true;
                            if (HasRights(FileSystemRights.Delete, rule)) _allowDelete = true;
                            if (HasRights(FileSystemRights.DeleteSubdirectoriesAndFiles, rule)) _allowDeleteSubdirectoriesAndFiles = true;
                            if (HasRights(FileSystemRights.ExecuteFile, rule)) _allowExecuteFile = true;
                            if (HasRights(FileSystemRights.FullControl, rule)) _allowFullControl = true;
                            if (HasRights(FileSystemRights.ListDirectory, rule)) _allowListDirectory = true;
                            if (HasRights(FileSystemRights.Modify, rule)) _allowModify = true;
                            if (HasRights(FileSystemRights.Read, rule)) _allowRead = true;
                            if (HasRights(FileSystemRights.ReadAndExecute, rule)) _allowReadAndExecute = true;
                            if (HasRights(FileSystemRights.ReadAttributes, rule)) _allowReadAttributes = true;
                            if (HasRights(FileSystemRights.ReadData, rule)) _allowReadData = true;
                            if (HasRights(FileSystemRights.ReadExtendedAttributes, rule)) _allowReadExtendedAttributes = true;
                            if (HasRights(FileSystemRights.ReadPermissions, rule)) _allowReadPermissions = true;
                            if (HasRights(FileSystemRights.Synchronize, rule)) _allowSynchronize = true;
                            if (HasRights(FileSystemRights.TakeOwnership, rule)) _allowTakeOwnership = true;
                            if (HasRights(FileSystemRights.Traverse, rule)) _allowTraverse = true;
                            if (HasRights(FileSystemRights.Write, rule)) _allowWrite = true;
                            if (HasRights(FileSystemRights.WriteAttributes, rule)) _allowWriteAttributes = true;
                            if (HasRights(FileSystemRights.WriteData, rule)) _allowWriteData = true;
                            if (HasRights(FileSystemRights.WriteExtendedAttributes, rule)) _allowWriteExtendedAttributes = true;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This method checks to see if the user (member variable) is a member of a group
        /// that has access to the path (member variable).  If so, it checks what type of 
        /// rights the group has to the folder.
        /// </summary>
        private void CheckIfUserGroupHasAccessToFolder()
        {
            try
            {
                //retrieve the rules collection for the passed in path.  This will determine
                //what users and groups have access to this particular folder.  You can retrieve
                //this information by right-clicking on the file in Windows Explorer and going
                //into Properties.  Click the Security tab
                AuthorizationRuleCollection rulesColl =
                    Directory.GetAccessControl(_path).GetAccessRules(true, true, typeof(SecurityIdentifier));

                //now walk through all of the groups that the user is a part of
                //and see if any of the groups have access to the folder
                foreach (IdentityReference identity in _user.Groups)
                {
                    foreach (FileSystemAccessRule rule in rulesColl)
                    {
                        if (identity.Equals(rule.IdentityReference))
                        {
                            //It looks like the user has access to the folder, detrmine the user's rights
                            if (AccessControlType.Deny.Equals(rule.AccessControlType))
                            {
                                if (HasRights(FileSystemRights.AppendData, rule)) _denyAppendData = true;
                                if (HasRights(FileSystemRights.ChangePermissions, rule)) _denyChangePermissions = true;
                                if (HasRights(FileSystemRights.CreateDirectories, rule)) _denyCreateDirectories = true;
                                if (HasRights(FileSystemRights.CreateFiles, rule)) _denyCreateFiles = true;
                                if (HasRights(FileSystemRights.Delete, rule)) _denyDelete = true;
                                if (HasRights(FileSystemRights.DeleteSubdirectoriesAndFiles, rule)) _denyDeleteSubdirectoriesAndFiles = true;
                                if (HasRights(FileSystemRights.ExecuteFile, rule)) _denyExecuteFile = true;
                                if (HasRights(FileSystemRights.FullControl, rule)) _denyFullControl = true;
                                if (HasRights(FileSystemRights.ListDirectory, rule)) _denyListDirectory = true;
                                if (HasRights(FileSystemRights.Modify, rule)) _denyModify = true;
                                if (HasRights(FileSystemRights.Read, rule)) _denyRead = true;
                                if (HasRights(FileSystemRights.ReadAndExecute, rule)) _denyReadAndExecute = true;
                                if (HasRights(FileSystemRights.ReadAttributes, rule)) _denyReadAttributes = true;
                                if (HasRights(FileSystemRights.ReadData, rule)) _denyReadData = true;
                                if (HasRights(FileSystemRights.ReadExtendedAttributes, rule)) _denyReadExtendedAttributes = true;
                                if (HasRights(FileSystemRights.ReadPermissions, rule)) _denyReadPermissions = true;
                                if (HasRights(FileSystemRights.Synchronize, rule)) _denySynchronize = true;
                                if (HasRights(FileSystemRights.TakeOwnership, rule)) _denyTakeOwnership = true;
                                if (HasRights(FileSystemRights.Traverse, rule)) _denyTraverse = true;
                                if (HasRights(FileSystemRights.Write, rule)) _denyWrite = true;
                                if (HasRights(FileSystemRights.WriteAttributes, rule)) _denyWriteAttributes = true;
                                if (HasRights(FileSystemRights.WriteData, rule)) _denyWriteData = true;
                                if (HasRights(FileSystemRights.WriteExtendedAttributes, rule)) _denyWriteExtendedAttributes = true;
                            }
                            else if (AccessControlType.Allow.Equals(rule.AccessControlType))
                            {
                                if (HasRights(FileSystemRights.AppendData, rule)) _allowAppendData = true;
                                if (HasRights(FileSystemRights.ChangePermissions, rule)) _allowChangePermissions = true;
                                if (HasRights(FileSystemRights.CreateDirectories, rule)) _allowCreateDirectories = true;
                                if (HasRights(FileSystemRights.CreateFiles, rule)) _allowCreateFiles = true;
                                if (HasRights(FileSystemRights.Delete, rule)) _allowDelete = true;
                                if (HasRights(FileSystemRights.DeleteSubdirectoriesAndFiles, rule)) _allowDeleteSubdirectoriesAndFiles = true;
                                if (HasRights(FileSystemRights.ExecuteFile, rule)) _allowExecuteFile = true;
                                if (HasRights(FileSystemRights.FullControl, rule)) _allowFullControl = true;
                                if (HasRights(FileSystemRights.ListDirectory, rule)) _allowListDirectory = true;
                                if (HasRights(FileSystemRights.Modify, rule)) _allowModify = true;
                                if (HasRights(FileSystemRights.Read, rule)) _allowRead = true;
                                if (HasRights(FileSystemRights.ReadAndExecute, rule)) _allowReadAndExecute = true;
                                if (HasRights(FileSystemRights.ReadAttributes, rule)) _allowReadAttributes = true;
                                if (HasRights(FileSystemRights.ReadData, rule)) _allowReadData = true;
                                if (HasRights(FileSystemRights.ReadExtendedAttributes, rule)) _allowReadExtendedAttributes = true;
                                if (HasRights(FileSystemRights.ReadPermissions, rule)) _allowReadPermissions = true;
                                if (HasRights(FileSystemRights.Synchronize, rule)) _allowSynchronize = true;
                                if (HasRights(FileSystemRights.TakeOwnership, rule)) _allowTakeOwnership = true;
                                if (HasRights(FileSystemRights.Traverse, rule)) _allowTraverse = true;
                                if (HasRights(FileSystemRights.Write, rule)) _allowWrite = true;
                                if (HasRights(FileSystemRights.WriteAttributes, rule)) _allowWriteAttributes = true;
                                if (HasRights(FileSystemRights.WriteData, rule)) _allowWriteData = true;
                                if (HasRights(FileSystemRights.WriteExtendedAttributes, rule)) _allowWriteExtendedAttributes = true;
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Checks to see if the passed in rights are part of the rule.
        /// </summary>
        /// <param name="rights">The rights that you're looking for.</param>
        /// <param name="rule">The rule that contains a bunch of rights.</param>
        /// <returns></returns>
        private bool HasRights(FileSystemRights rights, FileSystemAccessRule rule)
        {
            bool returnVal = false;

            try
            {
                //convert to an integer so that we can do a bitwise AND
                int intRights = (int)rights;
                int intFileSystemRights = (int)rule.FileSystemRights;

                if ((intRights & intFileSystemRights) == intRights)
                    returnVal = true;
            }
            catch
            {
                throw;
            }

            return returnVal;
        }
        #endregion
    }
}
