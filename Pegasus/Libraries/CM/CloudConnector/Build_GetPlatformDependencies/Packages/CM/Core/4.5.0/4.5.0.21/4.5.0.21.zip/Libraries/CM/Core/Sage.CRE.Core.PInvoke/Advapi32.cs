using System;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Sage.PInvoke
{
    /// <summary>
    /// Summary description for CAdvapi32.
    /// </summary>
    public static class Advapi32
    {
        public static bool LogonUser(
            String lpszUsername, String lpszDomain, String lpszPassword,
            int dwLogonType, int dwLogonProvider, ref IntPtr phToken)
        {
            return PInvoke.NativeMethods.LogonUser(lpszUsername, lpszDomain, lpszPassword,
                                                    dwLogonType, dwLogonProvider, ref phToken);
        }

        public static bool InitializeSecurityDescriptor(
            IntPtr pSecurityDescriptor, // pointer to sd
            int dwRevision)         // revision must be SECURITY_DESCRIPTOR_REVISION (1)
        {
            return PInvoke.NativeMethods.InitializeSecurityDescriptor(pSecurityDescriptor, dwRevision);
        }

        public static bool SetSecurityDescriptorDacl(
            IntPtr pSecurityDescriptor, // pointer to sd
            bool bDaclPresent,
            IntPtr pDacl,
            bool bDaclDefaulted)
        {
            return PInvoke.NativeMethods.SetSecurityDescriptorDacl(pSecurityDescriptor, // pointer to sd
                                                                   bDaclPresent,
                                                                   pDacl,
                                                                   bDaclDefaulted);
        }

        public static bool IsValidSecurityDescriptor(IntPtr pSecurityDescriptor)
        {
            return PInvoke.NativeMethods.IsValidSecurityDescriptor(pSecurityDescriptor);
        }


        public static bool LookupAccountSid(
            string lpSystemName,
            IntPtr lpSid,
            StringBuilder lpName,
            ref int cchName,
            StringBuilder lpReferencedDomainName,
            ref uint cchReferencedDomainName,
            out SidAccount peUse)
        {
            return PInvoke.NativeMethods.LookupAccountSid(lpSystemName, lpSid, lpName, ref cchName, lpReferencedDomainName, ref cchReferencedDomainName, out peUse);
        }

        public static bool LookupAccountName(
            [In, MarshalAs(UnmanagedType.LPTStr)]
            string lpSystemName,
            [In, MarshalAs(UnmanagedType.LPTStr)]
            string lpAccountName,
            IntPtr Sid,
            ref uint cbSid,
            StringBuilder ReferencedDomainName,
            ref uint cchReferencedDomainName,
            out SidAccount peUse)
        {
            return PInvoke.NativeMethods.LookupAccountName(lpSystemName, lpAccountName, Sid, ref cbSid, ReferencedDomainName, ref cchReferencedDomainName, out peUse);
        }

        public static bool ConvertSidToStringSid(
            IntPtr Sid,
            [In, Out, MarshalAs(UnmanagedType.LPTStr)]
            ref string StringSid)
        {
            return PInvoke.NativeMethods.ConvertSidToStringSid(Sid, ref StringSid);
        }

        public static bool ConvertStringSidToSid(
            string StringSid,
            ref IntPtr Sid)
        {
            return PInvoke.NativeMethods.ConvertStringSidToSid(StringSid, ref Sid);
        }

        public static bool AdjustTokenPrivileges(IntPtr TokenHandle,
           bool DisableAllPrivileges,
           ref TOKEN_PRIVILEGES NewState,
           int BufferLength,
           ref TOKEN_PRIVILEGES PreviousState,
           ref int ReturnLength)
        {
            return PInvoke.NativeMethods.AdjustTokenPrivileges(TokenHandle, DisableAllPrivileges, ref NewState, BufferLength, ref PreviousState, ref ReturnLength);
        }

        public static bool AdjustTokenPrivileges(IntPtr TokenHandle,
           int DisableAllPrivileges,
           ref TOKEN_PRIVILEGES_ARR NewState)
        {
            return PInvoke.NativeMethods.AdjustTokenPrivileges(TokenHandle, DisableAllPrivileges, ref NewState, 0, 0, 0);
        }

        public static bool AdjustTokenPrivileges(IntPtr TokenHandle,
           int DisableAllPrivileges,
           ref TOKEN_PRIVILEGES_ARR NewState,
           int BufferLength,
           ref TOKEN_PRIVILEGES_ARR PreviousState,
           ref int ReturnLength)
        {
            return PInvoke.NativeMethods.AdjustTokenPrivileges(TokenHandle, DisableAllPrivileges, ref NewState, BufferLength, ref PreviousState, ref ReturnLength);
        }

        public static bool OpenProcessToken(IntPtr ProcessHandle,
            UInt32 DesiredAccess, out IntPtr TokenHandle)
        {
            return PInvoke.NativeMethods.OpenProcessToken(ProcessHandle, DesiredAccess, out TokenHandle);
        }

        public static bool LookupPrivilegeValue(string lpSystemName, string lpName,
            out LUID lpLuid)
        {
            return PInvoke.NativeMethods.LookupPrivilegeValue(lpSystemName, lpName, out lpLuid);
        }

        public static bool GetTokenInformation(
            IntPtr TokenHandle,
            TOKEN_INFORMATION_CLASS TokenInformationClass,
            IntPtr TokenInformation,
            uint TokenInformationLength,
            out uint ReturnLength)
        {
            return PInvoke.NativeMethods.GetTokenInformation(TokenHandle, TokenInformationClass, TokenInformation, TokenInformationLength, out ReturnLength);
        }

        public static int RegCreateKey(uint hKey, string lpSubKey, ref IntPtr phkResult)
        {
            return PInvoke.NativeMethods.RegCreateKey(hKey, lpSubKey, ref phkResult);
        }

        public static long RegOverridePredefKey(uint hkey, IntPtr hnewKey)
        {
            return PInvoke.NativeMethods.RegOverridePredefKey(hkey, hnewKey);
        }

        public static int RegLoadKey(uint hKey, string lpSubKey, string lpFile)
        {
            return PInvoke.NativeMethods.RegLoadKey(hKey, lpSubKey, lpFile);
        }

        public static int RegUnLoadKey(uint hKey, string lpSubKey)
        {
            return PInvoke.NativeMethods.RegUnLoadKey(hKey, lpSubKey);
        }

        public static int RegCloseKey(int hKey)
        {
            return PInvoke.NativeMethods.RegCloseKey(hKey);
        }

        public static int RegOpenKeyEx(
            UIntPtr hKey,
            string subKey,
            uint options,
            RegistryKeyAccessRights sam,
            out UIntPtr phkResult)
        {
            return PInvoke.NativeMethods.RegOpenKeyEx(hKey, subKey, options, (int)sam, out phkResult);
        }

        public static int RegQueryValueEx(
            UIntPtr hKey,
            string lpValueName,
            int lpReserved,
            out uint lpType,
            System.Text.StringBuilder lpData,
            ref uint lpcbData)
        {
            return PInvoke.NativeMethods.RegQueryValueEx(
                hKey,
                lpValueName,
                lpReserved,
                out lpType,
                lpData,
                ref lpcbData );
        }

		public static bool CreateProcessWithLogonW(
			String userName,
			String domain,
			String password,
			UInt32 logonFlags,
			String applicationName,
			String commandLine,
			UInt32 creationFlags,
			UInt32 environment,
			String currentDirectory,
			ref StartupInfo startupInfo,
			out ProcessInformation processInformation )
		{
			return PInvoke.NativeMethods.CreateProcessWithLogonW(
				userName,
				domain,
				password,
				logonFlags,
				applicationName,
				commandLine,
				creationFlags,
				environment,
				currentDirectory,
				ref startupInfo,
				out processInformation );
		}
    }
}
