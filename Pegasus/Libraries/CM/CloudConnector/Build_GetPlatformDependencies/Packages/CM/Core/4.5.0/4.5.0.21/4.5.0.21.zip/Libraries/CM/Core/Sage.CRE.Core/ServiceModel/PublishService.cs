using System;
using System.Diagnostics;
using System.Reflection;
using System.ServiceModel;
using System.Threading;
using Sage.ExtensionMethods;

namespace Sage.ServiceModel
{
    public abstract class PublishService<T> where T : class
    {
        protected static void FireEvent(params Object[] args)
        {
            String action = OperationContext.Current.IncomingMessageHeaders.Action;
            String[] slashes = action.Split('/');
            String methodName = slashes[slashes.Length - 1];

            FireEvent(methodName, args);
        }

        protected static void FireEvent(string methodName, params Object[] args)
        {
            T[] subscribers = SubscriptionManager<T>.GetSubscriberList(methodName);
            Publish(subscribers, methodName, args);
        }

        private static void Publish(T[] subscribers, String methodName, params Object[] args)
        {
            WaitCallback invokeSubscriber = (subscriber) =>
                                {
                                    Invoke(subscriber as T, methodName, args);
                                };
            Action<T> queueUpSubscriber = (subscriber) =>
                                {
                                    ThreadPool.QueueUserWorkItem(invokeSubscriber, subscriber);
                                };
            subscribers.ForEach(queueUpSubscriber);
        }

        private static void Invoke(T subscriber, String methodName, Object[] args)
        {
            Debug.Assert(subscriber != null);
            Type type = typeof(T);
            MethodInfo methodInfo = type.GetMethod(methodName);
            try
            {
                methodInfo.Invoke(subscriber, args);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
            }
        }
    }
}