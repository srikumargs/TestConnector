using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Text;
using Microsoft.Win32;

namespace Sage.Configuration
{
    /// <summary>
    /// Provides a mechanism to rip through the Registry and convert all the settings to the Data Registry.
    /// </summary>
    /// <remarks>
    /// This process intentionally makes a few changes when porting the Registry over to the data registry. It does not include all of the
    /// typical HKCU/SOFTWARE/TIMBERLINE/etc. stuff. The search criteria objects contain a member called the KeyValueSetName, which is used
    /// as the leading part of the data path.
    /// 
    /// For example, Estimating has a number of application that store settings in multiple keys. Rather than continue down this path or make an
    /// attempt to parse out the start of the application key, the KeyValueSetName serves as the root of the XML doc. Consider this example:
    /// 
    /// PeWin Registry key:     HKEY_CURRENT_USER\Software\Timberline\Precision
    /// KeyValueSetName:        PeWin
    /// DataRegistry:           PeWin/ApplicationPath
    ///                         PeWin/Database
    ///                         PeWin/DefaultLayouts
    ///                         PeWin/Settings
    /// </remarks>
    public class DataRegistryBuilder
    {
        private static string[][] m_invalidXPathChars = 
        {
            new string[] { " ", "" },
            new string[] { "\"", "" },
            new string[] { "(", "" },
            new string[] { ")", "" },
            new string[] { ".", "" },
            new string[] { "{", "" },
            new string[] { "}", "" },
            new string[] { ":", "" },
            new string[] { "-", "_" },
        };

        /// <summary>
        /// The callback that's invoked when some part of the Registry has been converted.
        /// </summary>
        /// <param name="sender">The event sender.</param>
        /// <param name="e">The Registry converted data.</param>
        public delegate void RegistryConvertedHandler(object sender, RegistryConvertedEventArgs e);
        
        /// <summary>
        /// The event raised when the Registry has been converted.
        /// </summary>
        public event RegistryConvertedHandler RegistryConverted;

        private List<DataRegistryInfo> m_registrySearchCriteria = new List<DataRegistryInfo>();

        /// <summary>
        /// Constructor.
        /// </summary>
        public DataRegistryBuilder()
        { }

        /// <summary>
        /// Add Registry search criteria to this builder.
        /// </summary>
        /// <param name="hive">The Registry hive to search.</param>
        /// <param name="subKey">The Registry sub key used for the search.</param>
        /// <param name="keyValueSetName">The data registry key value set name.</param>
        public void AddSearchCriteria(Microsoft.Win32.RegistryHive hive, string subKey, string keyValueSetName)
        {
            this.AddSearchCriteria(new DataRegistryInfo(hive, subKey, keyValueSetName));
        }

        /// <summary>
        /// Add Registry search criteria to this builder.
        /// </summary>
        /// <param name="registryInfo">The Registry info object.</param>
        public void AddSearchCriteria(DataRegistryInfo registryInfo)
        {
            this.m_registrySearchCriteria.Add(registryInfo);
        }

        /// <summary>
        /// Clear out all search criteria.
        /// </summary>
        public void Clear()
        {
            this.m_registrySearchCriteria.Clear();
        }

        /// <summary>
        /// Fire an event to all listeners that the Registry has been converted.
        /// </summary>
        /// <param name="registryPath">The converted Registry path.</param>
        /// <param name="dataPath">The data path.</param>
        /// <param name="keyName">The key name.</param>
        /// <param name="value">The value.</param>
        protected void FireRegistryConverted(string registryPath, string dataPath, string keyName, string value)
        {
            if (this.RegistryConverted != null)
            {
                this.RegistryConverted(this, new RegistryConvertedEventArgs(registryPath, dataPath, keyName, value));
            }
        }

        /// <summary>
        /// Iterates through all Registry search criteria, and creates the isolated Data Registry.
        /// </summary>
        /// <param name="scope">The data scope.</param>
        /// <param name="location">The location of the data keyed value set within the data registry.</param>
        /// <returns>Returns true if the Data Registry is successfully built; otherwise, false.</returns>
        public bool Build(DataScope scope, string location)
        {
            // Search over all criteria.
            foreach (DataRegistryInfo info in this.m_registrySearchCriteria)
            {
                // Handle this particular hive.
                if (!this.handleHive(scope, location, info))
                    return false;
            }

            return true;
        }

        private bool handleHive(DataScope scope, string location, DataRegistryInfo info)
        {
            List<RegistryNameValue> nameDataCollection = new List<RegistryNameValue>();
            RegistryHelper helper = new RegistryHelper(info.Hive, info.SubKey);

            // Populate a list of Registry objects.               
            this.collectRegistryNameData(helper, nameDataCollection);

            // Note: We're doing a try/catch because even calling ContainsKeyedValueSet will yield an error if the data registry file doesn't exist.
            try
            {
                // Remove the existing one.
                DataRegistry.RemoveKeyedValueSet(scope, location, info.KeyValueSetName);
            }
            catch (System.IO.DirectoryNotFoundException)
            {
                // This is OK. It just means the directory does not exist!
            }
            catch (Exception e)
            {
                // This is not OK.
                System.Diagnostics.Debug.WriteLine(e.ToString());
                return false;
            }

            // Remove all potential existing sets.
            DataRegistry.RemoveKeyedValueSet(scope, location, info.KeyValueSetName);

            // Create a new one.
            IKeyedValues keyedValues = DataRegistry.CreateKeyedValueSet(scope, location, info.KeyValueSetName);
            bool isSuccessful = true;

            foreach (RegistryNameValue nameData in nameDataCollection)
            {
                if (!this.handleValue(info, keyedValues, nameData, helper.GetFullKeyName()))
                   isSuccessful = false;
            }

            return isSuccessful;
        }

        private bool handleValue(DataRegistryInfo info, IKeyedValues keyedValues , RegistryNameValue nameData, string fullKeyName)
        {
            // Get the data path
            string dataPath = GetDataRegistryDataPath(nameData);

            // Remove the full sub key from the data path.
            dataPath = dataPath.Replace(info.SubKey, "");

            // Convert the data path, fixing things up to be compliant with the XML doc.
            ConvertDataPath(info.KeyValueSetName, ref dataPath);

            try
            {
                // Get the Registry value, which is always converted to an appropriate string.
                string value = nameData.ConvertValue();

                // The Registry value name will serve as our data registry key.
                string keyName = nameData.ValueName;
                ConvertKeyName(ref keyName);

                // Create the key.
                keyedValues.CreateKey(dataPath, keyName);

                // Set the value.
                System.Diagnostics.Debug.WriteLine(string.Format("{0}: {1} = {2}", dataPath, keyName, value));
                keyedValues.SetValue(dataPath, keyName, value);

                // Notify listeners of the conversion.
                this.FireRegistryConverted(fullKeyName, dataPath, keyName, value);
                return true;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.ToString());
                return false;
            }
        }

        /// <summary>
        /// Recursively searches the specified Registry key and stores all keys and value names.
        /// </summary>
        /// <param name="helper">The Registry helper object..</param>
        /// <param name="nameDataCollection">The collection that holds all Registry info.</param>
        /// <exception cref="System.ArgumentNullException">Throws an exception if any of the parameters are null.</exception>
        private void collectRegistryNameData(RegistryHelper helper, List<RegistryNameValue> nameDataCollection)
        {
            if (helper == null)
                throw new ArgumentNullException("helper");

            if (nameDataCollection == null)
                throw new ArgumentNullException("nameDataCollection");

            string[] valueNames = helper.GetValueNames();

            if (valueNames != null)
            {
                foreach (string valueName in valueNames)
                {
                    Type valueType = helper.GetTypeFromValueKind(valueName);
                    object value = helper.GetKeyValue(valueName);
                    nameDataCollection.Add(new RegistryNameValue(helper.GetFullKeyName(), valueType, valueName, value));
                }
            }

            // Get all sub keys.
            string[] subKeyNames = helper.GetSubKeyNames();

            if (subKeyNames != null)
            {
                foreach (string subKeyName in subKeyNames)
                {
                    string newsSubKey = helper.SubKey + "\\" + subKeyName;

                    // Create a new helper based on the current one.
                    RegistryHelper newHelper = new RegistryHelper(helper.Hive, newsSubKey);

                    // Recurse.
                    this.collectRegistryNameData(newHelper, nameDataCollection);
                }
            }
        }

        #region Data Registry Helper Methods

        /// <summary>
        /// Get the Data Registry data path for the specified Registry object.
        /// </summary>
        /// <param name="nameData">The Registry name/data object.</param>        
        /// <returns>Returns a Data Registry data path.</returns>
        public static string GetDataRegistryDataPath(RegistryNameValue nameData)
        {
            if (string.IsNullOrEmpty(nameData.FullKeyName))
                return "";

            string[] keyNameArr = nameData.FullKeyName.Split(new char[] { '\\' });
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            foreach (string elem in keyNameArr)
            {
                // Skip. We don't want to include Registry specific info. 
                if (string.Compare(elem, "HKEY_CLASSES_ROOT", true, CultureInfo.CurrentCulture) == 0 ||
                    string.Compare(elem, "HKEY_CURRENT_USER", true, CultureInfo.CurrentCulture) == 0 ||
                    string.Compare(elem, "HKEY_LOCAL_MACHINE", true, CultureInfo.CurrentCulture) == 0 ||
                    string.Compare(elem, "HKEY_USERS", true, CultureInfo.CurrentCulture) == 0 ||
                    string.Compare(elem, "HKEY_PERFORMANCE_DATA", true, CultureInfo.CurrentCulture) == 0 ||
                    string.Compare(elem, "HKEY_CURRENT_CONFIG", true, CultureInfo.CurrentCulture) == 0 ||
                    string.Compare(elem, "HKEY_DYN_DATA", true, CultureInfo.CurrentCulture) == 0)
                {
                    continue;
                }

                if (sb.Length > 0)
                    sb.Append("\\");

                sb.Append(elem);
            }

            return sb.ToString();
        }

        /// <summary>
        /// Convert the data path or key name. The conversion trims all white space from the string, as well as changing
        /// to lower-case. All forward/back slashes will also be removed, as well as any characters that would otherwise yield failures.
        /// </summary>
        /// <param name="keyValueSetName">The data registry key value set name.</param>
        /// <param name="dataPath">A reference to the data path.</param>
        /// <remarks>
        /// In testing against a large number of Registry settings, numerous failures occurred due to invalid
        /// XPath expressions; therefore, this method exists to ensure that expressions are transformed
        /// accordingly.
        /// </remarks>
        public static void ConvertDataPath(string keyValueSetName, ref string dataPath)
        {
            if (!string.IsNullOrEmpty(dataPath))
            {
                // Make sure there are no trailing slashes.
                dataPath = Sage.IO.PathUtils.StripTrailingSlash(dataPath);

                // Replace any possible back slashes with forward slashes.
                dataPath = dataPath.Replace(@"\", @"/");

                // Remove any leading forward or back slashes
                if (dataPath.StartsWith("/") ||
                    dataPath.StartsWith("\\"))
                {
                    dataPath = dataPath.Substring(1);
                }

                // Replace all invalid chars.
                validateXPathToken(ref dataPath, true);

                if (!dataPath.StartsWith(keyValueSetName.ToLower()))
                    dataPath = string.Format("{0}/{1}", keyValueSetName, dataPath);
            }
            else
            {
                dataPath = keyValueSetName;
            }
        }

        /// <summary>
        /// Convert the data path + key name. The conversion trims all white space from the string, as well as changing
        /// to lower-case.
        /// </summary>
        /// <param name="keyValueSetName">The data registry key value set name.</param>
        /// <param name="dataPath">The settings data path string reference.</param>
        /// <param name="keyName">The key name string reference.</param>
        /// <remarks>
        /// In addition to the comment above, this is a single catch-all method to transform both a 
        /// data path + key name since a query or update involves both to be well formed.
        /// </remarks>
        public static void ConvertDataPathAndKey(string keyValueSetName, ref string dataPath, ref string keyName)
        {
            // Convert the data path.
            ConvertDataPath(keyValueSetName, ref dataPath);

            // Convert the key name.
            ConvertKeyName(ref keyName);
        }

        /// <summary>
        /// Convert the key name. The conversion trims all white space from the string as well as any characters that would otherwise yield failures.
        /// </summary>
        /// <param name="keyName">A reference to the data registry key name.</param>
        /// <remarks>
        /// See comment above.
        /// </remarks>
        public static void ConvertKeyName(ref string keyName)
        {
            // Replace all invalid chars.
            validateXPathToken(ref keyName, false);
        }

        /// <summary>
        /// Make sure that the XPath token is valid.
        /// </summary>
        /// <param name="value">The current string value to be checked or changed.</param>
        /// <param name="isDataPath">Specify whether this is a data path validation or not.</param>
        private static void validateXPathToken(ref string value, bool isDataPath)
        {
            if (string.IsNullOrEmpty(value))
                return;

            value = value.ToLower();

            // Although the XML element rules tend to focus on the first character,
            // there are certain characters that should not be used (1st char or otherwise);
            // therefore, we will simply replace them.
            for (int i=0; i < m_invalidXPathChars.Length; i++)
            {
                value = value.Replace(m_invalidXPathChars[i][0], m_invalidXPathChars[i][1]);
            }

            if (string.IsNullOrEmpty(value))
                System.Diagnostics.Debug.Assert(false, "");

            if (isDataPath)
            {
                string[] splitArr = value.Split(new char[] { '/' });

                // See if a path actually exists.
                if (splitArr != null &&
                    splitArr.Length > 0)
                {
                    StringBuilder sb = new StringBuilder();

                    foreach (string segment in splitArr)
                    {
                        if (sb.Length > 0)
                            sb.Append("/");

                        // Make sure the first character is a letter; otherwise, prepend an underscore.
                        if (!Char.IsLetter(segment[0]))
                            sb.Append("_" + segment);
                        else
                            sb.Append(segment);
                    }

                    value = sb.ToString();
                }
            }            
        }

        #endregion
    }

    /// <summary>
    /// The data contained within a registry converted event occurs.
    /// </summary>
    public class RegistryConvertedEventArgs : System.EventArgs
    {
        private string m_registryPath;
        private string m_dataPath;
        private string m_keyName;
        private string m_value;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="registryPath">The Registry path.</param>
        /// <param name="dataPath">The data path.</param>
        /// <param name="keyName">The key name.</param>
        /// <param name="value">The value.</param>
        public RegistryConvertedEventArgs(string registryPath, string dataPath, string keyName, string value)
        {
            this.m_registryPath = registryPath;
            this.m_dataPath = dataPath;
            this.m_keyName = keyName;
            this.m_value = value;
        }

        /// <summary>
        /// Get the Registry path.
        /// </summary>
        public string RegistryPath
        {
            get { return this.m_registryPath; }
        }

        /// <summary>
        /// Get the data path.
        /// </summary>
        public string DataPath
        {
            get { return this.m_dataPath; }
        }

        /// <summary>
        /// Get the key name.
        /// </summary>
        public string KeyName
        {
            get { return this.m_keyName; }
        }

        /// <summary>
        /// Get the value.
        /// </summary>
        public string Value
        {
            get { return this.m_value; }
        }
    }
}
