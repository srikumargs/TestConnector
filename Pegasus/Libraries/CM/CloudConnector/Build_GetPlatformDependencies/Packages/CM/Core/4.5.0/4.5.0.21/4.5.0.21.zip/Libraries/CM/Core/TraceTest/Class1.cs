using System;
using System.Diagnostics;
using System.Reflection;

using Sage.CM.Core.LinkedSource;

namespace TraceTest
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
        /// <summary>
        /// Static constructor to initialize the LibraryManager prior to any other members or field initialization being JIT-compiled and used.
        /// </summary>
        /// <remarks>
        /// This is needed becuase, in theory, the only Sage assembly that can be successfully found may be
        /// Sage.CRE.LibraryManagement.dll until the LibraryManager is initialized.
        /// </remarks>
        static Class1()
        {
            //LibraryManager.InitializeLibraries(LibraryManager.LibraryManifestsLocationForProcess);
        }

        /// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
        {
            _args = args;

            // Wire up a handler for AssemblyResolve.  This can get called if either Sage.CRE.Core.TraceListeners or Sage.CRE.Core cannot be found by
            // the CLR.
            AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(CurrentDomain_AssemblyResolve);

            try
            {
                Console.WriteLine("Calling System.Diagnostics.Trace.WriteLine...");
                Trace.WriteLine("This message written by System.Diagnostics.Trace.WriteLine");

                // Use reflection to load up the Sage.CRE.Core assembly rather than referencing it directly ... so as to avoid embedding
                // of meta data in the assembly manifest for Sage.CRE.Core.
                Console.WriteLine("Late-bound loading Sage.CRE.Core...");
                Assembly assembly = Assembly.Load(LibraryConstants.LibraryAssemblyFullName("Sage.CRE.Core"));
                Type type = assembly.GetType("Sage.Diagnostics.ErrorTrace");
                Console.WriteLine("Calling Sage.Diagnostics.ErrorTrace.WriteLine...");
                type.InvokeMember("WriteLine", BindingFlags.Static|BindingFlags.Public|BindingFlags.InvokeMethod, null, null, new object[] {null, "This message written by Sage.Diagnostics.ErrorTrace.WriteLine"});
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private static Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            Assembly result = null;

            Console.WriteLine(string.Format("In AssemblyResolve for '{0}'...", args.Name));

            string directory = Environment.CurrentDirectory;
            if(_args.Length == 1)
            {
                Console.WriteLine(string.Format("Using provided alternate directory '{0}'...", _args[0]));
                directory = _args[0];
                result = Assembly.LoadFrom(System.IO.Path.Combine(directory, args.Name + ".dll"));
            }
            else
            {
                Console.WriteLine("No alternate directory provided.");
            }

            return result;
        }

        private static string[] _args;
    }
}
