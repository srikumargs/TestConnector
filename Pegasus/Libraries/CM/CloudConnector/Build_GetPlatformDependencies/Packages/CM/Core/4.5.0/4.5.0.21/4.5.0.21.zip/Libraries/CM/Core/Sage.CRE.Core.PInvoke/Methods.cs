/*******************************************************************************************
 * This project contains all the native PInvoke declarations and are distributed into different 
 * classes on the basis of there security requirements. For example a message box requires no 
 * special security check and so can be put in SafeNativeMethods class. and 
 * CreateFile requires some code access security check because this call can be dangerous so
 * its put into the Class NativeMethod where stalk walk is done by the CLR  to determine if 
 * the caller has the necessary code access permissions. 
 * There are further wrappers on the SafeNativeMethos,NativeMethods and UnSafeNativeMetjods 
 * The methods in those classes are grouped together on the basis of the dll they reside in 
 * so that they are easier to find. For example Kernel32 class groups together all the native 
 * methods in kernel32.dll.
 * 
 *******************************************************************************************/

using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Drawing;
using Microsoft.Win32.SafeHandles;

namespace Sage.PInvoke
{
	/// <summary>
	/// Constants for P-Invoke.
	/// </summary>
	public class Constants
	{
		/// <summary>GDI32 dll name.</summary>
		public const string GDI32 = "GDI32.DLL";

		/// <summary>KERNEL32 dll name.</summary>
		public const string KERNEL32 = "KERNEL32.DLL";

		/// <summary>MPR dll name.</summary>
		public const string MPR = "MPR.DLL";

		/// <summary>SHELL32 dll name.</summary>
		public const string SHELL32 = "SHELL32.DLL";

		/// <summary>SHLWAPI dll name.</summary>
		public const string SHLWAPI = "SHLWAPI.DLL";

		/// <summary>USER32 dll name.</summary>
		public const string USER32 = "USER32.DLL";

		/// <summary>WININET dll name.</summary>
		public const string WININET = "WININET.DLL";

		/// <summary>ADVAPI32 dll name.</summary>
		public const string ADVAPI32 = "ADVAPI32.DLL";

		/// <summary>NETAPI32 dll name.</summary>
		public const string NETAPI32 = "NETAPI32.DLL";

		/// <summary>OLE32 dll name.</summary>
		public const string OLE32 = "OLE32.DLL";

		/// <summary>WTSAPI32 dll name.</summary>
		public const string WTSAPI32 = "WTSAPI32.DLL";

        /// <summary>ODBCCP32 dll name.</summary>
        public const string ODBCCP32 = "ODBCCP32.DLL";

        /// <summary>WINMM dll name.</summary>
        public const string WINMM = "WINMM.DLL";

        /// <summary>COMDLG dll name.</summary>
        public const string COMDLG = "COMDLG32.DLL";

	}

    /*******************************************************************************************/
    [StructLayout(LayoutKind.Sequential)]
    public struct OVERLAPPED
    {
        public UIntPtr Internal;
        public UIntPtr publicHigh;
        public UInt32 Offset;
        public UInt32 OffsetHigh;
        public IntPtr hEvent;
    }
    /*******************************************************************************************/
    public struct POINT
    {
		/// <summary>
		/// Public constructor with x and y coords.
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		public POINT( int x, int y )
		{
			this.x = x;
			this.y = y;
		}

        /// <summary>
        /// The x-coordinate
        /// </summary>
        public int x;

        /// <summary>
        /// The y-coordinate
        /// </summary>
        public int y;
    }

    /// <summary>
    /// Defines Win32 Registry constants.
    /// </summary>
    public class RegistryConstants
    {
        /// <summary>Defines the HKCR Registry key.</summary>
        public const UInt32 HKEY_CLASSES_ROOT               = 0x80000000;
        /// <summary>Defines the HKCU Registry key.</summary>
        public const UInt32 HKEY_CURRENT_USER               = 0x80000001;
        /// <summary>Defines the HKLM Registry key.</summary>
        public const UInt32 HKEY_LOCAL_MACHINE              = 0x80000002;
        /// <summary>Defines the HKU Registry key.</summary>
        public const UInt32 HKEY_USERS                      = 0x80000003;
    };

    /// <summary>
    /// Defines Win32 Registry key access right values (IE SAM values)
    /// </summary>
    [Flags]
    public enum RegistryKeyAccessRights
    {
        /// <summary>Required to query the values of a registry key.</summary>
        KEY_QUERY_VALUE             = 0x1,
        /// <summary>Required to create, delete, or set a registry value.</summary>
        KEY_SET_VALUE               = 0x2,
        /// <summary>Required to create a subkey of a registry key.</summary>
        KEY_CREATE_SUB_KEY          = 0x4,
        /// <summary>Required to enumerate the subkeys of a registry key.</summary>
        KEY_ENUMERATE_SUB_KEYS      = 0x8,
        /// <summary>Required to request change notifications for a registry key or for subkeys of a registry key.</summary>
        KEY_NOTIFY                  = 0x10,
        /// <summary>Reserved for system use.</summary>
        KEY_CREATE_LINK             = 0x20,
        /// <summary>Indicates that an application on 64-bit Windows should operate on the 64-bit registry view. </summary>
        KEY_WOW64_64KEY             = 0x100,
        /// <summary>Indicates that an application on 64-bit Windows should operate on the 32-bit registry view.</summary>
        KEY_WOW64_32KEY             = 0x200,
        /// <summary></summary>
        KEY_WOW64_RES               = 0x300,
        /// <summary>Combines the STANDARD_RIGHTS_REQUIRED, KEY_QUERY_VALUE, KEY_SET_VALUE, KEY_CREATE_SUB_KEY, KEY_ENUMERATE_SUB_KEYS, KEY_NOTIFY, and KEY_CREATE_LINK access rights.</summary>
        KEY_ALL_ACCESS              = 0xF003F,
        /// <summary>Equivalent to KEY_READ.</summary>
        KEY_EXECUTE                 = 0x20019,
        /// <summary>Combines the STANDARD_RIGHTS_WRITE, KEY_SET_VALUE, and KEY_CREATE_SUB_KEY access rights.</summary>
        KEY_WRITE                   = 0x20006,
    };

    /// <summary>
    /// Defines all system folders.
    /// </summary>
    public enum SystemFolder
    {
        /// <summary>Defines the Desktop folder.</summary>
        Desktop                     = 0,
        /// <summary>Defines the Internet folder.</summary>
        Internet                    = 1,
        /// <summary>Defines the Programs folder.</summary>
        ProgramsFolderOnStartMenu   = 2,
        /// <summary>Defines the Control Panel folder.</summary>
        ControlPanel                = 3,
        /// <summary>Defines the Printers folder.</summary>
        Printers                    = 4,
        /// <summary>Defines the Personal (MyDocuments) folder.</summary>
        Personal                    = 5,
        /// <summary>Defines the Favorites folder.</summary>
        Favorites                   = 6,
        /// <summary>Defines the Startup folder.</summary>
        StartupFolderOnStartMenu    = 7,
        /// <summary>Defines the Recent Files folder.</summary>
        RecentFiles                 = 8,
        /// <summary>Defines the Send To folder.</summary>
        SendTo                      = 9,
        /// <summary>Defines the Recycle Bin folder.</summary>
        RecycleBin                  = 10,
        /// <summary>Defines the Start Menu folder.</summary>
        StartMenu                   = 11,
        /// <summary>Defines the MyDocuments folder.</summary>
        MyDocuments                 = 12,
        /// <summary>Defines the MyMusic folder.</summary>
        MyMusic                     = 13,
        /// <summary>Defines the MyVideo folder.</summary>
        MyVideo                     = 14,
        /// <summary>Defines the username\Desktop folder.</summary>
        DesktopDirectory            = 16,
        /// <summary>Defines the MyComputer folder.</summary>
        MyComputer                  = 17,
        /// <summary>Defines the My Network Places folder.</summary>
        MyNetworkPlaces             = 18,
        /// <summary>Defines the username\NetHood Places folder.</summary>
        NetHood                     = 19,
        /// <summary>Defines the Fonts folder.</summary>
        Fonts                       = 20,
        /// <summary>Defines the Templates folder.</summary>
        Templates                   = 21,
        /// <summary>Defines the All Users\Start folder.</summary>
        AllUsersStartMenu           = 22,
        /// <summary>Defines the All Users\Programs folder.</summary>
        AllUsersProgramsMenu        = 23,
        /// <summary>Defines the All Users\Startup folder.</summary>
        AllUsersStartupMenu         = 24,
        /// <summary>Defines the All Users\Desktop folder.</summary>
        AllUsersDesktopMenu         = 25,
        /// <summary>Defines the username\Application Data folder.</summary>
        AppData                     = 26,
        /// <summary>Defines the username\PrintHood folder.</summary>
        PrintHood                   = 27,
        /// <summary>Defines the Local Settings\Application Data folder.</summary>
        LocalAppData                = 28,
        /// <summary>Defines the non localized startup folder.</summary>
        AltStartup                  = 29,
        /// <summary>Defines the non localized common startup folder.</summary>
        CommonAltStartup            = 30,
        /// <summary>Defines the common Favorites folder.</summary>
        CommonFavorites             = 31,
        /// <summary>Defines the common Application Data folder.</summary>
        CommonAppData               = 35,
        /// <summary>Defines the Windows folder.</summary>
        Windows                     = 36,
        /// <summary>Defines the System folder.</summary>
        System                      = 37,
        /// <summary>Defines the Program Files folder.</summary>
        ProgramFiles                = 38,
        /// <summary>Defines the MyPictures folder.</summary>
        MyPictures                  = 39,
        /// <summary>Defines the user profile folder.</summary>
        Profile                     = 40,
        /// <summary>Defines the System (x86) folder.</summary>
        Systemx86                   = 41,
        /// <summary>Defines the Program Files (x86) folder.</summary>
        ProgramFilesx86             = 42,
        /// <summary>Defines the Program Files\Common folder.</summary>
        ProgramFilesCommon          = 43,
        /// <summary>Defines the Program Files (x86)\Common folder.</summary>
        ProgramFilesCommonx86       = 44,        
        /// <summary>Defines the All Users\Templates folder.</summary>
        CommonTemplates             = 45,        
        /// <summary>Defines the All Users\Documents folder.</summary>
        CommonDocuments             = 46,
        /// <summary>Defines the All Users\Start Menu\Programs\Administrative Tools folder.</summary>
        CommonAdminTools            = 47,
        /// <summary>Defines the username\Start Menu\Programs\Administrative Tools folder.</summary>
        AdminTools                  = 48,
        /// <summary>Defines the Network and dial-up connections folder.</summary>
        Connections                 = 49,
        /// <summary>Defines the All Users\My Music folder.</summary>
        CommonMusic                 = 53,
        /// <summary>Defines the All Users\My Pictures folder.</summary>
        CommonPictures              = 54,
        /// <summary>Defines the All Users\My Video folder.</summary>
        CommonVideo                 = 55,
        /// <summary>Defines the Resource folder.</summary>
        Resources                   = 56,
    };

    /// <summary>
    /// Defines the various flags for the SHGetFileInfo Win32 function.
    /// </summary>
    [Flags]    
    public enum SHGFI : uint
    {
        /// <summary>Get the large icon.</summary>
        LargeIcon                   = 0x000000000,
        /// <summary>Get the small icon.</summary>
        SmallIcon                   = 0x000000001,
        /// <summary>Get the open icon.</summary>
        OpenIcon                    = 0x000000002,
        /// <summary>Get the shell size icon.</summary>
        ShellIconSize               = 0x000000004,
        /// <summary>pszPath is a pidl.</summary>
        PIDL                        = 0x000000008,
        /// <summary>Use the passed in dwFileAttribute flag.</summary>
        UseFileAttributes           = 0x000000010,
        /// <summary>Add the overlays.</summary>
        AddOverlays                 = 0x000000020,
        /// <summary>Get the index of the overlay in the upper 8 bits of the iIcon.</summary>
        OverlayIndex                = 0x000000040,
        /// <summary>Get the icon.</summary>
        Icon                        = 0x000000100,
        /// <summary>Get the display name.</summary>
        DisplayName                 = 0x000000200,
        /// <summary>Get the type name.</summary>
        TypeName                    = 0x000000400,
        /// <summary>Get the attributes.</summary>
        Attributes                  = 0x000000800,
        /// <summary>Get the icon location.</summary>
        IconLocation                = 0x000001000,
        /// <summary>Get the EXE type.</summary>
        ExeType                     = 0x000002000,
        /// <summary>Get the system icon index.</summary>
        SysIconIndex                = 0x000004000,
        /// <summary>Put a link overlay on the icon.</summary>
        LinkOverlay                 = 0x000008000,
        /// <summary>Show the icon in a selected state.</summary>
        Selected                    = 0x000010000,
        /// <summary>Get only the specified attributes.</summary>
        Attr_Specified              = 0x000020000,
    };

    /// <summary>
    /// Defines Win32 Security constants.
    /// </summary>
    public class SecurityConstants
    {
        public const UInt32 SE_PRIVILEGE_ENABLED_BY_DEFAULT = 0x00000001;
        public const UInt32 SE_PRIVILEGE_ENABLED = 0x00000002;
        public const UInt32 SE_PRIVILEGE_REMOVED = 0x00000004;
        public const UInt32 SE_PRIVILEGE_USED_FOR_ACCESS = 0x80000000;

        public const UInt32 STANDARD_RIGHTS_REQUIRED = 0x000F0000;
        public const UInt32 STANDARD_RIGHTS_READ = 0x00020000;
        public const UInt32 TOKEN_ASSIGN_PRIMARY = 0x0001;
        public const UInt32 TOKEN_DUPLICATE = 0x0002;
        public const UInt32 TOKEN_IMPERSONATE = 0x0004;
        public const UInt32 TOKEN_QUERY = 0x0008;
        public const UInt32 TOKEN_QUERY_SOURCE = 0x0010;
        public const UInt32 TOKEN_ADJUST_PRIVILEGES = 0x0020;
        public const UInt32 TOKEN_ADJUST_GROUPS = 0x0040;
        public const UInt32 TOKEN_ADJUST_DEFAULT = 0x0080;
        public const UInt32 TOKEN_ADJUST_SESSIONID = 0x0100;
        public const UInt32 TOKEN_READ = (STANDARD_RIGHTS_READ | TOKEN_QUERY);
        public const UInt32 TOKEN_ALL_ACCESS = (STANDARD_RIGHTS_REQUIRED | TOKEN_ASSIGN_PRIMARY |
            TOKEN_DUPLICATE | TOKEN_IMPERSONATE | TOKEN_QUERY | TOKEN_QUERY_SOURCE |
            TOKEN_ADJUST_PRIVILEGES | TOKEN_ADJUST_GROUPS | TOKEN_ADJUST_DEFAULT |
            TOKEN_ADJUST_SESSIONID);

        public const string SE_CREATE_TOKEN_NAME = "SeCreateTokenPrivilege";
        public const string SE_ASSIGNPRIMARYTOKEN_NAME = "SeAssignPrimaryTokenPrivilege";
        public const string SE_LOCK_MEMORY_NAME = "SeLockMemoryPrivilege";
        public const string SE_INCREASE_QUOTA_NAME = "SeIncreaseQuotaPrivilege";
        public const string SE_UNSOLICITED_INPUT_NAME = "SeUnsolicitedInputPrivilege";
        public const string SE_MACHINE_ACCOUNT_NAME = "SeMachineAccountPrivilege";
        public const string SE_TCB_NAME = "SeTcbPrivilege";
        public const string SE_SECURITY_NAME = "SeSecurityPrivilege";
        public const string SE_TAKE_OWNERSHIP_NAME = "SeTakeOwnershipPrivilege";
        public const string SE_LOAD_DRIVER_NAME = "SeLoadDriverPrivilege";
        public const string SE_SYSTEM_PROFILE_NAME = "SeSystemProfilePrivilege";
        public const string SE_SYSTEMTIME_NAME = "SeSystemtimePrivilege";
        public const string SE_PROF_SINGLE_PROCESS_NAME = "SeProfileSingleProcessPrivilege";
        public const string SE_INC_BASE_PRIORITY_NAME = "SeIncreaseBasePriorityPrivilege";
        public const string SE_CREATE_PAGEFILE_NAME = "SeCreatePagefilePrivilege";
        public const string SE_CREATE_PERMANENT_NAME = "SeCreatePermanentPrivilege";
        public const string SE_BACKUP_NAME = "SeBackupPrivilege";
        public const string SE_RESTORE_NAME = "SeRestorePrivilege";
        public const string SE_SHUTDOWN_NAME = "SeShutdownPrivilege";
        public const string SE_DEBUG_NAME = "SeDebugPrivilege";
        public const string SE_AUDIT_NAME = "SeAuditPrivilege";
        public const string SE_SYSTEM_ENVIRONMENT_NAME = "SeSystemEnvironmentPrivilege";
        public const string SE_CHANGE_NOTIFY_NAME = "SeChangeNotifyPrivilege";
        public const string SE_REMOTE_SHUTDOWN_NAME = "SeRemoteShutdownPrivilege";
        public const string SE_UNDOCK_NAME = "SeUndockPrivilege";
        public const string SE_SYNC_AGENT_NAME = "SeSyncAgentPrivilege";
        public const string SE_ENABLE_DELEGATION_NAME = "SeEnableDelegationPrivilege";
        public const string SE_MANAGE_VOLUME_NAME = "SeManageVolumePrivilege";
        public const string SE_IMPERSONATE_NAME = "SeImpersonatePrivilege";
        public const string SE_CREATE_GLOBAL_NAME = "SeCreateGlobalPrivilege";
    }

    /// <summary>
    /// Defines different types of token information used when calling the GetTokenInformation method.
    /// </summary>
    public enum TOKEN_INFORMATION_CLASS
    {
        TokenUser = 1,
        TokenGroups,
        TokenPrivileges,
        TokenOwner,
        TokenPrimaryGroup,
        TokenDefaultDacl,
        TokenSource,
        TokenType,
        TokenImpersonationLevel,
        TokenStatistics,
        TokenRestrictedSids,
        TokenSessionId,
        TokenGroupsAndPrivileges,
        TokenSessionReference,
        TokenSandBoxInert,
        TokenAuditPolicy,
        TokenOrigin,
        TokenElevationType
    };

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct LUID
    {
        public int LowPart;
        public int HighPart;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct LUID_AND_ATTRIBUTES
    {
        public LUID Luid;
        public int Attributes;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct TOKEN_PRIVILEGES
    {
        public int PrivilegeCount;
        public LUID_AND_ATTRIBUTES Privileges;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct TOKEN_PRIVILEGES_ARR
    {
        public int PrivilegeCount;
        [MarshalAs(UnmanagedType.ByValArray)]
        public LUID_AND_ATTRIBUTES[] Privileges;
    }    

    /*******************************************************************************************/
    [ComVisible(false)]
    public struct Rect
    {
        /// <summary>The left most position of the rectangle</summary>
        public int left;

        /// <summary>The top most position of the rectangle</summary>
        public int top;

        /// <summary>The right most position of the rectangle</summary>
        public int right;

        /// <summary>The bottom most position of the rectangle</summary>
        public int bottom;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="rect">A .Net rectangle structure</param>
        public Rect(Rectangle rect)
        {
            this.bottom = rect.Bottom;
            this.left = rect.Left;
            this.right = rect.Right;
            this.top = rect.Top;
        }

        /// <summary>Get the width of the rectangle</summary>
        public int Width
        {
            get
            {
                return right - left;
            }
        }

        /// <summary>Get the hight of the rectangle</summary>
        public int Height
        {
            get
            {
                return bottom - top;
            }
        }
    }
    /*******************************************************************************************/
    [StructLayout(LayoutKind.Sequential)] 
    public struct NMHDR
    {
        public IntPtr HwndFrom;
        public IntPtr IdFrom;
        public int Code;
    };
    /*******************************************************************************************/
    [StructLayout(LayoutKind.Sequential)]
    public struct OFNOTIFY
    {
        public NMHDR hdr;
        public OPENFILENAME lpOFN;
        public string pszFile;
    };
    /*******************************************************************************************/
    [StructLayout(LayoutKind.Sequential)]
    public struct OFNOTIFYEX
    {
        [MarshalAs(UnmanagedType.Struct)]
        public NMHDR hdr;
        [MarshalAs(UnmanagedType.LPStruct)]
        public OPENFILENAME lpOFN;
        public IntPtr psf;
        public IntPtr pidl;
    };
    /*******************************************************************************************/
    public delegate IntPtr HOOKPROC(int nCode, IntPtr wParam, IntPtr lParam);
    public delegate bool EnumWindowsProc(IntPtr window, int i);
    public delegate int BrowseCallBackProc(IntPtr hwnd, int msg, IntPtr lp, IntPtr wp);
    public delegate int OFNHookProcDelegate(int hdlg, int msg, int wParam, int lParam);

    /*******************************************************************************************/
    [StructLayout(LayoutKind.Sequential)]
    public struct BrowseInfo
    {
        public IntPtr hwndOwner;
        public IntPtr pidlRoot;
        [MarshalAs(UnmanagedType.LPTStr)]
        public string displayname;
        [MarshalAs(UnmanagedType.LPTStr)]
        public string title;
        public int flags;
        [MarshalAs(UnmanagedType.FunctionPtr)]
        public BrowseCallBackProc callback;
        public IntPtr lparam;
    }

    /*******************************************************************************************/
    [StructLayout(LayoutKind.Sequential)]
    public struct APPBARDATA
    {
        public int cbSize;
        public int hWnd;
        public int uCallbackMessage;
        public int uEdge;
        public Rectangle rc;
        public int lParam;
    };

    /*******************************************************************************************/
    [ComVisible(false)]
    [StructLayout(LayoutKind.Sequential)]
    public struct WINDOWPLACEMENT
    {
        /// <summary>
        /// Size of the structure
        /// </summary>
        public uint length;

        /// <summary>
        /// Placement Flags
        /// </summary>
        public uint flags;

        /// <summary>
        ///  The current show command
        /// </summary>
        public uint showCmd;

        /// <summary>
        /// The minimize position
        /// </summary>
        public POINT ptMinPosition;

        /// <summary>
        /// The Maximize position
        /// </summary>
        public POINT ptMaxPosition;

        /// <summary>
        /// The normal position
        /// </summary>
        public Rect rcNormalPosition;
    };

    /*******************************************************************************************/
    [StructLayout(LayoutKind.Sequential)]
    public struct SHFILEINFO
    {
        public int hIcon;
        public int iIcon;
        public int dwAttributes;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string szDisplayName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
        public string szTypeName;
    };

    /*******************************************************************************************/
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct SERVER_INFO_100
    {
        public int sv100_platform_id;
        public string sv100_name;
    }

	[StructLayout( LayoutKind.Sequential )]
	public struct SERVER_INFO_101
	{
		[MarshalAs( System.Runtime.InteropServices.UnmanagedType.U4 )]
		public UInt32 sv101_platform_id;
		[MarshalAs( System.Runtime.InteropServices.UnmanagedType.LPWStr )]
		public string sv101_name;
		[MarshalAs( System.Runtime.InteropServices.UnmanagedType.U4 )]
		public UInt32 sv101_version_major;
		[MarshalAs( System.Runtime.InteropServices.UnmanagedType.U4 )]
		public UInt32 sv101_version_minor;
		[MarshalAs( System.Runtime.InteropServices.UnmanagedType.U4 )]
		public UInt32 sv101_type;
		[MarshalAs( System.Runtime.InteropServices.UnmanagedType.LPWStr )]
		public string sv101_comment;
	};

    /*******************************************************************************************/
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct GROUP_USERS_INFO_0
    {
        public string grui0_name;
    }

    public static class Win32Error
    {
        /// <summary>
        /// The handle is invalid.
        /// </summary>
        internal const uint ERROR_INVALID_HANDLE = 6;

        /// <summary>
        /// Cannot create a file when that file already exists.
        /// </summary>
        internal const uint ERROR_ALREADY_EXISTS = 183;
    }
	
    [Flags]
    public enum FileAccess : uint
    {
        /// <summary>
        /// The FileAccess value is invalid
        /// </summary>
        /// <remarks>
        /// This is default value the runtime automatically initializes any FileAccess instance to.
        /// </remarks>
        None = 0x00000000,

        /// <summary>
        /// Read access (a.k.a. GENERIC_READ)
        /// </summary>
        GenericRead = 0x80000000,

        /// <summary>
        /// Write access (a.k.a. GENERIC_WRITE)
        /// </summary>
        GenericWrite = 0x40000000,

        /// <summary>
        /// Execute access (a.k.a. GENERIC_EXECUTE)
        /// </summary>
        GenericExecute = 0x20000000,

        /// <summary>
        /// Read, write, and execute access (a.k.a. GENERIC_ALL)
        /// </summary>
        GenericAll = 0x10000000
    }

    //Courtesy of pinvoke.net
    [Flags]
    public enum ExitWindows : uint
    {
        // ONE of the following five:
        LogOff = 0x00,
        ShutDown = 0x01,
        Reboot = 0x02,
        PowerOff = 0x08,
        RestartApps = 0x40,
        // plus AT MOST ONE of the following two:
        Force = 0x04,
        ForceIfHung = 0x10,
    }

    //Courtesy of pinvoke.net
    [Flags]
    public enum ShutdownReason : uint
    {
        MajorApplication = 0x00040000,
        MajorHardware = 0x00010000,
        MajorLegacyApi = 0x00070000,
        MajorOperatingSystem = 0x00020000,
        MajorOther = 0x00000000,
        MajorPower = 0x00060000,
        MajorSoftware = 0x00030000,
        MajorSystem = 0x00050000,

        MinorBlueScreen = 0x0000000F,
        MinorCordUnplugged = 0x0000000b,
        MinorDisk = 0x00000007,
        MinorEnvironment = 0x0000000c,
        MinorHardwareDriver = 0x0000000d,
        MinorHotfix = 0x00000011,
        MinorHung = 0x00000005,
        MinorInstallation = 0x00000002,
        MinorMaintenance = 0x00000001,
        MinorMMC = 0x00000019,
        MinorNetworkConnectivity = 0x00000014,
        MinorNetworkCard = 0x00000009,
        MinorOther = 0x00000000,
        MinorOtherDriver = 0x0000000e,
        MinorPowerSupply = 0x0000000a,
        MinorProcessor = 0x00000008,
        MinorReconfig = 0x00000004,
        MinorSecurity = 0x00000013,
        MinorSecurityFix = 0x00000012,
        MinorSecurityFixUninstall = 0x00000018,
        MinorServicePack = 0x00000010,
        MinorServicePackUninstall = 0x00000016,
        MinorTermSrv = 0x00000020,
        MinorUnstable = 0x00000006,
        MinorUpgrade = 0x00000003,
        MinorWMI = 0x00000015,

        FlagUserDefined = 0x40000000,
        FlagPlanned = 0x80000000
    }

    [Flags]
    public enum FileShare : uint
    {
        /// <summary>
        /// The FileShare value is invalid
        /// </summary>
        /// <remarks>
        /// This is default value the runtime automatically initializes any FileShare instance to.
        /// </remarks>
        None = 0x00000000,

        /// <summary>
        /// Enables subsequent open operations on an object to request read access.
        /// Otherwise, other processes cannot open the object if they request read access.
        /// If this flag is not specified, but the object has been opened for read access, the function fails.
        /// (a.k.a. FILE_SHARE_READ)
        /// </summary>
        Read = 0x00000001,

        /// <summary>
        /// Enables subsequent open operations on an object to request write access.
        /// Otherwise, other processes cannot open the object if they request write access.
        /// If this flag is not specified, but the object has been opened for write access, the function fails.
        /// (a.k.a. FILE_SHARE_WRITE)
        /// </summary>
        Write = 0x00000002,

        /// <summary>
        /// Enables subsequent open operations on an object to request delete access.
        /// Otherwise, other processes cannot open the object if they request delete access.
        /// If this flag is not specified, but the object has been opened for delete access, the function fails.
        /// (a.k.a. FILE_SHARE_DELETE)
        /// </summary>
        Delete = 0x00000004
    }

    /// <summary>
    /// Defines the mask applied to the version test.
    /// </summary>
    public enum TestTypeMask : uint
    {
        /// <summary>The minor version.</summary>
        MinorVersion = 0x1,
        /// <summary>The major version.</summary>
        MajorVersion = 0x2,
        /// <summary>The build number version.</summary>
        BuildNumber = 0x4,
        /// <summary>The platform identifier.</summary>
        PlatformId = 0x8,
        /// <summary>The service pack minor version.</summary>
        ServicePackMinor = 0x10,
        /// <summary>The service pack major version.</summary>
        ServicePackMajor = 0x20,
        /// <summary>The suite name.</summary>
        SuiteName = 0x40,
        /// <summary>The product type.</summary>
        ProductType = 0x80,
    };

    /// <summary>
    /// Defines the condition placed on the OS test functions.
    /// </summary>
    public enum VersionConditionMask : byte
    {
        /// <summary>The test is for equality.</summary>
        Equal = 1,
        /// <summary>The test is for >.</summary>
        GreaterThan = 2,
        /// <summary>The test is for >=.</summary>
        GreaterThanEqual = 3,
        /// <summary>The test is for <.</summary>
        LessThan = 4,
        /// <summary>The test is for <=.</summary>
        LessThanEqual = 5,
        /// <summary>The test includes a logical AND.</summary>
        And = 6,
        /// <summary>The test includes a logical OR.</summary>
        Or = 7,
    };

    public enum CreationDisposition : uint
    {
        /// <summary>
        /// The CreationDisposition value is invalid
        /// </summary>
        /// <remarks>
        /// This is default value the runtime automatically initializes any CreationDisposition instance to.
        /// </remarks>
        None = 0,

        /// <summary>
        /// Creates a new file.  The function fails if a specified file exists.
        /// (a.k.a. CREATE_NEW)
        /// </summary>
        CreateNew = 1,

        /// <summary>
        /// Creates a new file, always.  If a file exists, the function overwrites the file, clears the existing attributes, combines the specified file attributes, and flags with FILE_ATTRIBUTE_ARCHIVE, but does not set the security descriptor that the SECURITY_ATTRIBUTES structure specifies.
        /// (a.k.a. CREATE_ALWAYS)
        /// </summary>
        CreateAlways = 2,

        /// <summary>
        /// Opens a file.  The function fails if the file does not exist.  For more information, see the Remarks section of this topic.
        /// (a.k.a. OPEN_EXISTING)
        /// </summary>
        OpenExisting = 3,

        /// <summary>
        /// Opens a file, always.  If a file does not exist, the function creates a file as if dwCreationDisposition is CREATE_NEW.
        /// (a.k.a. OPEN_ALWAYS)
        /// </summary>
        OpenAlways = 4,

        /// <summary>
        /// Opens a file and truncates it so that its size is 0 (zero) bytes.  The function fails if the file does not exist.  The calling process must open the file with the GENERIC_WRITE access right. 
        /// (a.k.a. TRUNCATE_EXISTING)
        /// </summary>
        TruncateExisting = 5,
    }

    [Flags]
    public enum FileAttributes : uint
    {
        /// <summary>
        /// The FileAttributes value is invalid
        /// </summary>
        /// <remarks>
        /// This is default value the runtime automatically initializes any FileAttributes instance to.
        /// </remarks>
        None = 0,

        /// <summary>
        /// A file is read only. Applications can read the file, but cannot write to or delete it.
        /// (a.k.a. FILE_ATTRIBUTE_READONLY)
        /// </summary>
        Readonly = 0x00000001,

        /// <summary>
        /// A file is hidden. Do not include it in an ordinary directory listing.
        /// (a.k.a. FILE_ATTRIBUTE_HIDDEN)
        /// </summary>
        Hidden = 0x00000002,

        /// <summary>
        /// A file is part of or used exclusively by an operating system. 
        /// (a.k.a. FILE_ATTRIBUTE_SYSTEM)
        /// </summary>
        System = 0x00000004,

        /// <summary>
        /// The file is a directory.
        /// (a.k.a. FILE_ATTRIBUTE_DIRECTORY)
        /// </summary>
        Directory = 0x00000010,

        /// <summary>
        /// A file should be archived. Applications use this attribute to mark files for backup or removal.
        /// (a.k.a. FILE_ATTRIBUTE_ARCHIVE)
        /// </summary>
        Archive = 0x00000020,

        /// <summary>
        /// Reserved; do not use.
        /// (a.k.a. FILE_ATTRIBUTE_DEVICE)
        /// </summary>
        Device = 0x00000040,

        /// <summary>
        /// A file does not have other attributes set. This attribute is valid only if used alone.
        /// (a.k.a. FILE_ATTRIBUTE_NORMAL)
        /// </summary>
        Normal = 0x00000080,

        /// <summary>
        /// A file is being used for temporary storage. File systems avoid writing data back to mass storage if sufficient cache memory is available, because an application deletes a temporary file after a handle is closed. In that case, the system can entirely avoid writing the data. Otherwise, the data is written after the handle is closed.
        /// (a.k.a. FILE_ATTRIBUTE_TEMPORARY)
        /// </summary>
        Temporary = 0x00000100,

        /// <summary>
        /// The file is a sparse file.
        /// (a.k.a. FILE_ATTRIBUTE_SPARSE_FILE)
        /// </summary>
        SparseFile = 0x00000200,

        /// <summary>
        /// The file or directory has an associated reparse point.
        /// (a.k.a. FILE_ATTRIBUTE_REPARSE_POINT)
        /// </summary>
        ReparsePoint = 0x00000400,

        /// <summary>
        /// The file or directory is compressed.
        /// For a file, this means that all of the data in the file is compressed.
        /// For a directory, this means that compression is the default for newly created files and subdirectories.
        /// (a.k.a. FILE_ATTRIBUTE_COMPRESSED)
        /// </summary>
        Compressed = 0x00000800,

        /// <summary>
        /// The file data is not immediately available.
        /// This attribute indicates that the file data has been physically moved to offline storage.
        /// This attribute is used by Remote Storage, the hierarchical storage management software.
        /// Applications should not arbitrarily change this attribute.
        /// (a.k.a. FILE_ATTRIBUTE_OFFLINE)
        /// </summary>
        Offline = 0x00001000,

        /// <summary>
        /// A file is not indexed by the content indexing service. 
        /// (a.k.a. FILE_ATTRIBUTE_NOT_CONTENT_INDEXED)
        /// </summary>
        NotContentIndexed = 0x00002000,

        /// <summary>
        /// A file or directory is encrypted. For a file, this means that all data in the file is encrypted. For a directory, this means that encryption is the default for newly created files and subdirectories. For more information, see File Encryption. 
        /// This flag has no effect if FILE_ATTRIBUTE_SYSTEM is also specified.
        /// (a.k.a. FILE_ATTRIBUTE_ENCRYPTED)
        /// </summary>
        Encrypted = 0x00004000
    }

    [Flags]
    public enum FileFlags : uint
    {
        /// <summary>
        /// The FileFlags value is invalid
        /// </summary>
        /// <remarks>
        /// This is default value the runtime automatically initializes any FileFlags instance to.
        /// </remarks>
        None = 0,

        /// <summary>
        /// The system writes through any intermediate cache and goes directly to disk. 
        /// If FILE_FLAG_NO_BUFFERING is not also specified, so that system caching is in effect, then the data is written to the system cache, but is flushed to disk without delay.
        /// If FILE_FLAG_NO_BUFFERING is also specified, so that system caching is not in effect, then the data is immediately flushed to disk without going through the system cache. The operating system also requests a write-through the hard disk cache to persistent media. However, not all hardware supports this write-through capability.
        /// (a.k.a. FILE_FLAG_WRITE_THROUGH)
        /// </summary>
        WriteThrough = 0x80000000,

        /// <summary>
        /// The file is being opened or created for asynchronous I/O. When the operation is complete, the event specified to the call in the OVERLAPPED structure is set to the signaled state. Operations that take a significant amount of time to process return ERROR_IO_PENDING. 
        /// If this flag is specified, the file can be used for simultaneous read and write operations. The system does not maintain the file pointer, therefore you must pass the file position to the read and write functions in the OVERLAPPED structure or update the file pointer.
        /// If this flag is not specified, then I/O operations are serialized, even if the calls to the read and write functions specify an OVERLAPPED structure.
        /// (a.k.a. FILE_FLAG_OVERLAPPED)
        /// </summary>
        Overlapped = 0x40000000,

        /// <summary>
        /// The system opens a file with no system caching. This flag does not affect hard disk caching. When combined with FILE_FLAG_OVERLAPPED, the flag gives maximum asynchronous performance, because the I/O does not rely on the synchronous operations of the memory manager. However, some I/O operations take more time, because data is not being held in the cache. Also, the file metadata may still be cached. To flush the metadata to disk, use the FlushFileBuffers function.
        /// An application must meet certain requirements when working with files that are opened with FILE_FLAG_NO_BUFFERING:
        /// File access must begin at byte offsets within a file that are integer multiples of the volume sector size. 
        /// File access must be for numbers of bytes that are integer multiples of the volume sector size. For example, if the sector size is 512 bytes, an application can request reads and writes of 512, 1024, or 2048 bytes, but not of 335, 981, or 7171 bytes. 
        /// Buffer addresses for read and write operations should be sector aligned, which means aligned on addresses in memory that are integer multiples of the volume sector size. Depending on the disk, this requirement may not be enforced. 
        /// One way to align buffers on integer multiples of the volume sector size is to use VirtualAlloc to allocate the buffers. It allocates memory that is aligned on addresses that are integer multiples of the operating system's memory page size. Because both memory page and volume sector sizes are powers of 2, this memory is also aligned on addresses that are integer multiples of a volume sector size.
        /// An application can determine a volume sector size by calling the GetDiskFreeSpace function.
        /// (a.k.a. FILE_FLAG_NO_BUFFERING)
        /// </summary>
        NoBuffering = 0x20000000,

        /// <summary>
        /// A file is accessed randomly. The system can use this as a hint to optimize file caching.
        /// (a.k.a. FILE_FLAG_RANDOM_ACCESS)
        /// </summary>
        RandomAccess = 0x10000000,

        /// <summary>
        /// A file is accessed sequentially from beginning to end. The system can use this as a hint to optimize file caching. If an application moves the file pointer for random access, optimum caching may not occur. However, correct operation is still guaranteed. 
        /// Specifying this flag can increase performance for applications that read large files using sequential access. Performance gains can be even more noticeable for applications that read large files mostly sequentially, but occasionally skip over small ranges of bytes.
        /// (a.k.a. FILE_FLAG_SEQUENTIAL_SCAN)
        /// </summary>
        SequentialScan = 0x08000000,

        /// <summary>
        /// The system deletes a file immediately after all of its handles are closed, which includes the specified handle and any other open or duplicated handles.
        /// If there are existing open handles to a file, the call fails unless they were all opened with the FILE_SHARE_DELETE share mode.
        /// Subsequent open requests for the file fail, unless the FILE_SHARE_DELETE share mode is specified.
        /// (a.k.a. FILE_FLAG_DELETE_ON_CLOSE)
        /// </summary>
        DeleteOnClose = 0x04000000,

        /// <summary>
        /// A file is being opened or created for a backup or restore operation. The system ensures that the calling process overrides file security checks when the process has SE_BACKUP_NAME and SE_RESTORE_NAME privileges. For more information, see Changing Privileges in a Token. 
        /// You can set this flag to obtain a handle to a directory. A directory handle can be passed to some functions instead of a file handle. For more information, see Obtaining A Handle to a Directory.
        /// Windows Me/98/95:  This flag is not supported.
        /// (a.k.a. FILE_FLAG_BACKUP_SEMANTICS)
        /// </summary>
        BackupSemantics = 0x02000000,

        /// <summary>
        /// A file is accessed according to POSIX rules. This includes allowing multiple files with names, differing only in case, for file systems that support that naming. Use care when using this option, because files created with this flag may not be accessible by applications that are written for MS-DOS or 16-bit Windows. 
        /// (a.k.a. FILE_FLAG_POSIX_SEMANTICS)
        /// </summary>
        PosixSemantics = 0x01000000,

        /// <summary>
        /// The system inhibits the reparse behavior of NTFS file system reparse points. When a file is opened, a file handle is returned, whether or not the filter that controls the reparse point is operational. This flag cannot be used with the CREATE_ALWAYS flag. 
        /// (a.k.a. FILE_FLAG_OPEN_REPARSE_POINT)
        /// </summary>
        OpenReparsePoint = 0x00200000,

        /// <summary>
        /// The file data is requested, but it should continue to be located in remote storage. It should not be transported back to local storage. This flag is for use by remote storage systems.
        /// (a.k.a. FILE_FLAG_OPEN_NO_RECALL)
        /// </summary>
        OpenNoRecall = 0x00100000,

        /// <summary>
        /// If you attempt to create multiple instances of a pipe with this flag, creation of the first instance succeeds, but creation of the next instance fails with ERROR_ACCESS_DENIED.
        /// Windows 2000/NT:  This flag is not supported until Windows 2000 SP2 and Windows XP.
        /// (a.k.a. FILE_FLAG_FIRST_PIPE_INSTANCE)
        /// </summary>
        FirstPipeInstance = 0x00080000
    }

    /// <summary>
    /// 
    /// (a.k.a. STORAGE_QUERY_TYPE)
    /// </summary>
    public enum StorageQueryType : uint
    {
        /// <summary>
        /// Retrieves the descriptor
        /// </summary>
        PropertyStandardQuery = 0,

        /// <summary>
        /// Used to test whether the descriptor is supported
        /// </summary>
        PropertyExistsQuery,

        /// <summary>
        /// Used to retrieve a mask of writeable fields in the descriptor
        /// </summary>
        PropertyMaskQuery,

        /// <summary>
        /// use to validate the value
        /// </summary>
        PropertyQueryMaxDefined
    }

    /// <summary>
    /// 
    /// (a.k.a. STORAGE_PROPERTY_ID)
    /// </summary>
    public enum StoragePropertyId : uint
    {
        /// <summary>
        /// 
        /// </summary>
        StorageDeviceProperty = 0,

        /// <summary>
        /// 
        /// </summary>
        StorageAdapterProperty,

        /// <summary>
        /// 
        /// </summary>
        StorageDeviceIdProperty
    }

    /// <summary>
    /// 
    /// (a.k.a. STORAGE_PROPERTY_QUERY)
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct StoragePropertyQuery
    {
        /// <summary>
        /// ID of the property being retrieved
        /// </summary>
        public StoragePropertyId PropertyId;

        /// <summary>
        /// Flags indicating the type of query being performed
        /// </summary>
        public StorageQueryType QueryType;

        /// <summary>
        /// Space for additional parameters if necessary
        /// </summary>
        public byte AdditionalParameters;
    }

    /// <summary>
    /// Define the different storage bus types
    /// Bus types below 128 (0x80) are reserved for Microsoft use
    /// (a.k.a. STORAGE_BUS_TYPE)
    /// </summary>
    public enum StorageBusType : uint
    {
        /// <summary>
        /// 
        /// </summary>
        Unknown = 0x00,

        /// <summary>
        /// 
        /// </summary>
        Scsi,

        /// <summary>
        /// 
        /// </summary>
        Atapi,

        /// <summary>
        /// 
        /// </summary>
        Ata,

        /// <summary>
        /// 
        /// </summary>
        Type1394,

        /// <summary>
        /// 
        /// </summary>
        Ssa,

        /// <summary>
        /// 
        /// </summary>
        Fibre,

        /// <summary>
        /// 
        /// </summary>
        Usb,

        /// <summary>
        /// 
        /// </summary>
        RAID,

        /// <summary>
        /// 
        /// </summary>
        MaxReserved = 0x7F
    }


    /// <summary>
    /// Device property descriptor - this is really just a rehash of the inquiry
    /// data retrieved from a scsi device
    ///
    /// This may only be retrieved from a target device.  Sending this to the bus
    /// will result in an error
    /// 
    /// (a.k.a. STORAGE_DEVICE_DESCRIPTOR)
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct StorageDeviceDescriptor
    {
        /// <summary>
        /// Sizeof(STORAGE_DEVICE_DESCRIPTOR)
        /// </summary>
        public UInt32 Version;

        /// <summary>
        /// Total size of the descriptor, including the space for additional
        /// data and id strings
        /// </summary>
        public UInt32 Size;

        /// <summary>
        /// The SCSI-2 device type
        /// </summary>
        public SCSIDeviceType DeviceType;

        /// <summary>
        /// The SCSI-2 device type modifier (if any) - this may be zero
        /// </summary>
        public byte DeviceTypeModifier;

        /// <summary>
        /// Flag indicating whether the device's media (if any) is removable.  This
        /// field should be ignored for media-less devices
        /// </summary>
        [MarshalAs(UnmanagedType.U1)]
        public bool RemovableMedia;

        /// <summary>
        /// Flag indicating whether the device can support mulitple outstanding
        /// commands.  The actual synchronization in this case is the responsibility
        /// of the port driver.
        /// </summary>
        [MarshalAs(UnmanagedType.U1)]
        public bool CommandQueueing;

        /// <summary>
        /// Byte offset to the zero-terminated ascii string containing the device's
        /// vendor id string.  For devices with no such ID this will be zero
        /// </summary>
        public UInt32 VendorIdOffset;

        /// <summary>
        /// Byte offset to the zero-terminated ascii string containing the device's
        /// product id string.  For devices with no such ID this will be zero
        /// </summary>
        public UInt32 ProductIdOffset;

        /// <summary>
        /// Byte offset to the zero-terminated ascii string containing the device's
        /// product revision string.  For devices with no such string this will be
        /// zero
        /// </summary>
        public UInt32 ProductRevisionOffset;

        /// <summary>
        /// Byte offset to the zero-terminated ascii string containing the device's
        /// serial number.  For devices with no serial number this will be zero
        /// </summary>
        public UInt32 SerialNumberOffset;

        /// <summary>
        /// Contains the bus type (as defined above) of the device.  It should be
        /// used to interpret the raw device properties at the end of this structure
        /// (if any)
        /// </summary>
        public StorageBusType BusType;

        /// <summary>
        /// The number of bytes of bus-specific data which have been appended to
        /// this descriptor
        /// </summary>
        public UInt32 RawPropertiesLength;

        /// <summary>
        /// Place holder for the first byte of the bus specific property data
        /// </summary>
        public byte RawDeviceProperties;
    }

    /// <summary>
    /// 
    /// (a.k.a. STORAGE_DEVICE_NUMBER)
    /// </summary>
    public struct StorageDeviceNumber
    {
        /// <summary>
        /// The FILE_DEVICE_XXX type for this device.
        /// </summary>
        public FileDeviceType DeviceType;

        /// <summary>
        /// The number of this device
        /// </summary>
        public UInt32 DeviceNumber;

        /// <summary>
        /// If the device is partitionable, the partition number of the device.
        /// Otherwise -1
        /// </summary>
        public UInt32 PartitionNumber;
    }

    /// <summary>
    /// Define the various device type values.  Note that values used by Microsoft
    /// Corporation are in the range 0-32767, and 32768-65535 are reserved for use
    /// by customers.
    /// </summary>
    public enum FileDeviceType : uint
    {
        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_BEEP)
        /// </summary>
        Beep = 0x00000001,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_CD_ROM)
        /// </summary>
        CDRom = 0x00000002,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_CD_ROM_FILE_SYSTEM)
        /// </summary>
        CDRomFileSystem = 0x00000003,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_CONTROLLER)
        /// </summary>
        Controller = 0x00000004,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_DATALINK)
        /// </summary>
        Datalink = 0x00000005,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_DFS)
        /// </summary>
        Dfs = 0x00000006,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_DISK)
        /// </summary>
        Disk = 0x00000007,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_DISK_FILE_SYSTEM)
        /// </summary>
        DiskFileSystem = 0x00000008,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_FILE_SYSTEM)
        /// </summary>
        FileSystem = 0x00000009,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_INPORT_PORT)
        /// </summary>
        InportPort = 0x0000000a,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_KEYBOARD)
        /// </summary>
        Keyboard = 0x0000000b,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_MAILSLOT)
        /// </summary>
        Mailslot = 0x0000000c,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_MIDI_IN)
        /// </summary>
        MidiIn = 0x0000000d,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_MIDI_OUT)
        /// </summary>
        MidiOut = 0x0000000e,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_MOUSE)
        /// </summary>
        Mouse = 0x0000000f,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_MULTI_UNC_PROVIDER)
        /// </summary>
        MultiUncProvider = 0x00000010,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_NAMED_PIPE)
        /// </summary>
        NamedPipe = 0x00000011,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_NETWORK)
        /// </summary>
        Network = 0x00000012,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_NETWORK_BROWSER)
        /// </summary>
        NetworkBrowser = 0x00000013,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_NETWORK_FILE_SYSTEM)
        /// </summary>
        NetworkFileSystem = 0x00000014,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_NULL)
        /// </summary>
        Null = 0x00000015,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_PARALLEL_PORT)
        /// </summary>
        ParallelPort = 0x00000016,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_PHYSICAL_NETCARD)
        /// </summary>
        PhysicalNetcard = 0x00000017,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_PRINTER)
        /// </summary>
        Printer = 0x00000018,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_SCANNER)
        /// </summary>
        Scanner = 0x00000019,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_SERIAL_MOUSE_PORT)
        /// </summary>
        SerialMousePort = 0x0000001a,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_SERIAL_PORT)
        /// </summary>
        SerialPort = 0x0000001b,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_SCREEN)
        /// </summary>
        Screen = 0x0000001c,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_SOUND)
        /// </summary>
        Sound = 0x0000001d,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_STREAMS)
        /// </summary>
        Streams = 0x0000001e,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_TAPE)
        /// </summary>
        Tape = 0x0000001f,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_TAPE_FILE_SYSTEM)
        /// </summary>
        TapeFileSystem = 0x00000020,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_TRANSPORT)
        /// </summary>
        transport = 0x00000021,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_UNKNOWN)
        /// </summary>
        Unknown = 0x00000022,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_VIDEO)
        /// </summary>
        Video = 0x00000023,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_VIRTUAL_DISK)
        /// </summary>
        VirtualDisk = 0x00000024,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_WAVE_IN)
        /// </summary>
        WaveIn = 0x00000025,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_WAVE_OUT)
        /// </summary>
        WaveOut = 0x00000026,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_8042_PORT)
        /// </summary>
        Type8042Port = 0x00000027,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_NETWORK_REDIRECTOR)
        /// </summary>
        NetworkRedirector = 0x00000028,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_BATTERY)
        /// </summary>
        Battery = 0x00000029,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_BUS_EXTENDER)
        /// </summary>
        BusExtender = 0x0000002a,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_MODEM)
        /// </summary>
        Modem = 0x0000002b,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_VDM)
        /// </summary>
        Vdm = 0x0000002c,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_MASS_STORAGE)
        /// </summary>
        MassStorage = 0x0000002d,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_SMB)
        /// </summary>
        Smb = 0x0000002e,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_KS)
        /// </summary>
        KS = 0x0000002f,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_CHANGER)
        /// </summary>
        Changer = 0x00000030,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_SMARTCARD)
        /// </summary>
        Smartcard = 0x00000031,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_ACPI)
        /// </summary>
        Acpi = 0x00000032,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_DVD)
        /// </summary>
        Dvd = 0x00000033,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_FULLSCREEN_VIDEO)
        /// </summary>
        FullscreenVideo = 0x00000034,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_DFS_FILE_SYSTEM)
        /// </summary>
        DfsFileSystem = 0x00000035,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_DFS_VOLUME)
        /// </summary>
        DfsVolume = 0x00000036,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_SERENUM)
        /// </summary>
        serenum = 0x00000037,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_TERMSRV)
        /// </summary>
        Termsrv = 0x00000038,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_KSEC)
        /// </summary>
        Ksec = 0x00000039,

        /// <summary>
        /// 
        /// (a.k.a FILE_DEVICE_FIPS)
        /// </summary>
        Fips = 0x0000003a
    }

    public static class IoctlUtils
    {
        /// <summary>
        /// IoControlCode values for storage devices
        /// (a.k.a. IOCTL_STORAGE_BASE)
        /// </summary>
        public const UInt16 IoctlStorageBase = (UInt16) FileDeviceType.MassStorage;

        /// <summary>
        /// 
        /// (a.k.a. METHOD_BUFFERED)
        /// </summary>
        public const UInt16 MethodBuffered = 0;

        /// <summary>
        /// 
        /// (a.k.a. METHOD_IN_DIRECT)
        /// </summary>
        public const UInt16 MethodInDirect = 1;


        /// <summary>
        /// 
        /// (a.k.a. METHOD_OUT_DIRECT)
        /// </summary>
        public const UInt16 MethodOutDirect = 2;

        /// <summary>
        /// 
        /// (a.k.a. METHOD_NEITHER)
        /// </summary>
        public const UInt16 MethodNeither = 3;

        /// <summary>
        /// FILE_SPECIAL_ACCESS is checked by the NT I/O system the same as FILE_ANY_ACCESS.
        /// The file systems, however, may add additional access checks for I/O and FS controls
        /// that use this value.
        /// 
        /// (a.k.a. FILE_ANY_ACCESS)
        /// </summary>
        public const UInt16 FileAnyAccess = 0x0000;

        /// <summary>
        /// FILE_SPECIAL_ACCESS is checked by the NT I/O system the same as FILE_ANY_ACCESS.
        /// The file systems, however, may add additional access checks for I/O and FS controls
        /// that use this value.
        /// 
        /// (a.k.a. FILE_SPECIAL_ACCESS)
        /// </summary>
        public const UInt16 FileSpecialAccess = FileAnyAccess;

        /// <summary>
        /// file & pipe
        /// 
        /// The FILE_READ_ACCESS and FILE_WRITE_ACCESS constants are also defined in
        /// ntioapi.h as FILE_READ_DATA and FILE_WRITE_DATA. The values for these
        /// constants *MUST* always be in sync.
        /// 
        /// (a.k.a. FILE_READ_ACCESS)
        /// </summary>
        public const UInt16 FileReadAccess = 0x0001;

        /// <summary>
        /// file & pipe
        /// 
        /// The FILE_READ_ACCESS and FILE_WRITE_ACCESS constants are also defined in
        /// ntioapi.h as FILE_READ_DATA and FILE_WRITE_DATA. The values for these
        /// constants *MUST* always be in sync.
        /// 
        /// (a.k.a. FILE_WRITE_ACCESS)
        /// </summary>
        public const UInt16 FileWriteAccess = 0x0002;

        /// <summary>
        /// Input Buffer:
        ///      a STORAGE_PROPERTY_QUERY structure which describes what type of query
        ///      is being done, what property is being queried for, and any additional
        ///      parameters which a particular property query requires.
        ///
        ///  Output Buffer:
        ///      Contains a buffer to place the results of the query into.  Since all
        ///      property descriptors can be cast into a STORAGE_DESCRIPTOR_HEADER,
        ///      the IOCTL can be called once with a small buffer then again using
        ///      a buffer as large as the header reports is necessary.
        /// 
        /// (a.k.a. IOCTL_STORAGE_QUERY_PROPERTY)
        /// </summary>
        public static UInt32 IoctlStorageQueryProperty = CTL_CODE(IoctlStorageBase, 0x0500, MethodBuffered, FileAnyAccess);

        /// <summary>
        /// input - none
        ///
        /// output - STORAGE_DEVICE_NUMBER structure
        ///          The values in the STORAGE_DEVICE_NUMBER structure are guaranteed
        ///          to remain unchanged until the system is rebooted.  They are not
        ///          guaranteed to be persistant across boots.
        /// 
        /// (a.k.a. IOCTL_STORAGE_GET_DEVICE_NUMBER)
        /// </summary>
        public static UInt32 IoctlStorageGetDeviceNumber = CTL_CODE(IoctlStorageBase, 0x0420, MethodBuffered, FileAnyAccess);

        private static UInt32 CTL_CODE(UInt16 deviceType, UInt16 function, UInt16 method, UInt16 access)
        {
            return (UInt32) (((deviceType) << (UInt16) 16) | ((access) << (UInt16) 14) | ((function) << (UInt16) 2) | (method));
        }
    }

    /// <summary>
    /// Inquiry defines. Used to interpret data returned from target as result
    /// of inquiry command.
    /// DeviceType field
    /// </summary>
    public enum SCSIDeviceType : byte
    {
        /// <summary>
        /// disks
        /// (a.k.a. DIRECT_ACCESS_DEVICE)
        /// </summary>
        DirectAccess = 0x00,

        /// <summary>
        /// tapes
        /// (a.k.a. SEQUENTIAL_ACCESS_DEVICE)
        /// </summary>
        SequentialAccess = 0x01,

        /// <summary>
        /// printers
        /// (a.k.a. PRINTER_DEVICE)
        /// </summary>
        Printer = 0x02,

        /// <summary>
        /// scanners, printers, etc
        /// (a.k.a. PROCESSOR_DEVICE)
        /// </summary>
        Processor = 0x03,

        /// <summary>
        /// worms
        /// (a.k.a. WRITE_ONCE_READ_MULTIPLE_DEVICE)
        /// </summary>
        WriteOnceReadMultiple = 0x04,

        /// <summary>
        /// cdroms
        /// (a.k.a. READ_ONLY_DIRECT_ACCESS_DEVICE)
        /// </summary>
        ReadOnlyDirectAccess = 0x05,

        /// <summary>
        /// scanners
        /// (a.k.a. SCANNER_DEVICE)
        /// </summary>
        Scanner = 0x06,

        /// <summary>
        /// optical disks
        /// (a.k.a. OPTICAL_DEVICE)
        /// </summary>
        Optical = 0x07,

        /// <summary>
        /// jukebox
        /// (a.k.a. MEDIUM_CHANGER)
        /// </summary>
        MediumChanger = 0x08,

        /// <summary>
        /// network
        /// (a.k.a. COMMUNICATION_DEVICE)
        /// </summary>
        Communication = 0x09,

        /// <summary>
        /// 
        /// (a.k.a. LOGICAL_UNIT_NOT_PRESENT_DEVICE)
        /// </summary>
        LogicalUnitNotPresent = 0x7F
    }

    /// <summary>
    /// (a.k.a SM_*)
    /// </summary>
    public enum SystemMetric : int
    {
        /// <summary>
        ///  Width of the screen of the primary display monitor, in pixels. This is the same values obtained by calling GetDeviceCaps as follows: GetDeviceCaps( hdcPrimaryMonitor, HORZRES).
        /// (a.k.a SM_CXSCREEN)
        /// </summary>
        ScreenWidth = 0,

        /// <summary>
        /// Height of the screen of the primary display monitor, in pixels. This is the same values obtained by calling GetDeviceCaps as follows: GetDeviceCaps( hdcPrimaryMonitor, VERTRES).
        /// (a.k.a SM_CYSCREEN)
        /// </summary>
        ScreenHeight = 1,

        /// <summary>
        /// Width of a vertical scroll bar, in pixels.
        /// (a.k.a. SM_CXVSCROLL)
        /// </summary>
        VScrollWidth = 2,

        /// <summary>
        /// Height of a horizontal scroll bar, in pixels.
        /// (a.k.a. SM_CYHSCROLL)
        /// </summary>
        HScrollHeight = 3,

        /// <summary>
        /// Height of a caption area, in pixels.
        /// (a.k.a. SM_CYCAPTION)
        /// </summary>
        CaptionHeight = 4,

        /// <summary>
        /// Width of a window border, in pixels. This is equivalent to the SM_CXEDGE value for windows with the 3-D look. 
        /// (a.k.a. SM_CXBORDER)
        /// </summary>
        WindowsBorderWidth = 5,

        /// <summary>
        /// Height of a window border, in pixels. This is equivalent to the SM_CYEDGE value for windows with the 3-D look. 
        /// (a.k.a. SM_CYBORDER)
        /// </summary>
        WindowsBorderHeight = 6,

        /// <summary>
        /// Thickness of the frame around the perimeter of a window that has a caption but is not sizable, in pixels. SM_CXFIXEDFRAME is the height of the horizontal border and SM_CYFIXEDFRAME is the width of the vertical border. 
        /// (a.k.a. SM_CXDLGFRAME)
        /// </summary>
        DialogFrameWidth = 7,

        /// <summary>
        /// Thickness of the frame around the perimeter of a window that has a caption but is not sizable, in pixels. SM_CXFIXEDFRAME is the height of the horizontal border and SM_CYFIXEDFRAME is the width of the vertical border. 
        /// (a.k.a. SM_CYDLGFRAME)
        /// </summary>
        DialogFrameHeight = 8,

        /// <summary>
        /// Height of the thumb box in a vertical scroll bar, in pixels
        /// (a.k.a. SM_CYVTHUMB)
        /// </summary>
        VScrollThumbHeight = 9,

        /// <summary>
        /// Width of the thumb box in a horizontal scroll bar, in pixels.
        /// (a.k.a. SM_CXHTHUMB)
        /// </summary>
        HScrollThumbWidth = 10,

        /// <summary>
        /// Default width of an icon, in pixels. The LoadIcon function can load only icons with the dimensions specified by SM_CXICON and SM_CYICON
        /// (a.k.a. SM_CXICON)
        /// </summary>
        IconWidth = 11,

        /// <summary>
        /// Default height of an icon, in pixels. The LoadIcon function can load only icons with the dimensions SM_CXICON and SM_CYICON.
        /// (a.k.a. SM_CYICON)
        /// </summary>
        IconHeight = 12,

        /// <summary>
        /// Width of a cursor, in pixels. The system cannot create cursors of other sizes.
        /// (a.k.a. SM_CXCURSOR)
        /// </summary>
        CursorWidth = 13,

        /// <summary>
        /// Height of a cursor, in pixels. The system cannot create cursors of other sizes.
        /// (a.k.a. SM_CYCURSOR)
        /// </summary>
        CursorHeight = 14,

        /// <summary>
        /// Height of a single-line menu bar, in pixels.
        /// (a.k.a. SM_CYMENU)
        /// </summary>
        MenuHeight = 15,

        /// <summary>
        /// Width of the client area for a full-screen window on the primary display monitor, in pixels. To get the coordinates of the portion of the screen not obscured by the system taskbar or by application desktop toolbars, call the SystemParametersInfo function with the SPI_GETWORKAREA value.
        /// (a.k.a. SM_CXFULLSCREEN)
        /// </summary>
        FullScreenWidth = 16,

        /// <summary>
        /// Height of the client area for a full-screen window on the primary display monitor, in pixels. To get the coordinates of the portion of the screen not obscured by the system taskbar or by application desktop toolbars, call the SystemParametersInfo function with the SPI_GETWORKAREA value.
        /// (a.k.a. SM_CYFULLSCREEN)
        /// </summary>
        FullScreenHeight = 17,

        /// <summary>
        /// For double byte character set versions of the system, this is the height of the Kanji window at the bottom of the screen, in pixels
        /// (a.k.a. SM_CYKANJIWINDOW)
        /// </summary>
        KanjiWindowHeight = 18,

        /// <summary>
        /// Nonzero if a mouse with a wheel is installed; zero otherwise
        /// (a.k.a. SM_MOUSEWHEELPRESENT)
        /// </summary>
        MouseWheelPresent = 75,

        /// <summary>
        /// Height of the arrow bitmap on a vertical scroll bar, in pixels.
        /// (a.k.a. SM_CYHSCROLL)
        /// </summary>
        VScrollArrowHeight = 20,

        /// <summary>
        /// Width of the arrow bitmap on a horizontal scroll bar, in pixels.
        /// (a.k.a. SM_CXHSCROLL)
        /// </summary>
        HScrollArrowWidth = 21,

        /// <summary>
        /// Nonzero if the debug version of User.exe is installed; zero otherwise.
        /// (a.k.a. SM_DEBUG)
        /// </summary>
        Debug = 22,

        /// <summary>
        /// Nonzero if the left and right mouse buttons are reversed; zero otherwise.
        /// (a.k.a. SM_SWAPBUTTON)
        /// </summary>
        SwapButton = 23,

        /// <summary>
        /// Reserved for future use
        /// (a.k.a. SM_RESERVED1)
        /// </summary>
        Reserved1 = 24,

        /// <summary>
        /// Reserved for future use
        /// (a.k.a. SM_RESERVED2)
        /// </summary>
        Reserved2 = 25,

        /// <summary>
        /// Reserved for future use
        /// (a.k.a. SM_RESERVED3)
        /// </summary>
        Reserved3 = 26,

        /// <summary>
        /// Reserved for future use
        /// (a.k.a. SM_RESERVED4)
        /// </summary>
        Reserved4 = 27,

        /// <summary>
        /// Minimum width of a window, in pixels.
        /// (a.k.a. SM_CXMIN)
        /// </summary>
        MinimumWindowWidth = 28,

        /// <summary>
        /// Minimum height of a window, in pixels.
        /// (a.k.a. SM_CYMIN)
        /// </summary>
        MinimumWindowHeight = 29,

        /// <summary>
        /// Width of a button in a window's caption or title bar, in pixels.
        /// (a.k.a. SM_CXSIZE)
        /// </summary>
        ButtonWidth = 30,

        /// <summary>
        /// Height of a button in a window's caption or title bar, in pixels.
        /// (a.k.a. SM_CYSIZE)
        /// </summary>
        ButtonHeight = 31,

        /// <summary>
        /// Thickness of the sizing border around the perimeter of a window that can be resized, in pixels. SM_CXSIZEFRAME is the width of the horizontal border, and SM_CYSIZEFRAME is the height of the vertical border. 
        /// (a.k.a. SM_CXFRAME)
        /// </summary>
        FrameWidth = 32,

        /// <summary>
        /// Thickness of the sizing border around the perimeter of a window that can be resized, in pixels. SM_CXSIZEFRAME is the width of the horizontal border, and SM_CYSIZEFRAME is the height of the vertical border. 
        /// (a.k.a. SM_CYFRAME)
        /// </summary>
        FrameHeight = 33,

        /// <summary>
        /// Minimum tracking width of a window, in pixels. The user cannot drag the window frame to a size smaller than these dimensions. A window can override this value by processing the WM_GETMINMAXINFO message.
        /// (a.k.a. SM_CXMINTRACK)
        /// </summary>
        MinimumTrackWidth = 34,

        /// <summary>
        /// Minimum tracking height of a window, in pixels. The user cannot drag the window frame to a size smaller than these dimensions. A window can override this value by processing the WM_GETMINMAXINFO message
        /// (a.k.a. SM_CYMINTRACK)
        /// </summary>
        MinimumTrackHeight = 35,

        /// <summary>
        /// Width of the rectangle around the location of a first click in a double-click sequence, in pixels. The second click must occur within the rectangle defined by SM_CXDOUBLECLK and SM_CYDOUBLECLK for the system to consider the two clicks a double-click
        /// (a.k.a. SM_CXDOUBLECLK)
        /// </summary>
        DoubleClickRectangleWidth = 36,

        /// <summary>
        /// Height of the rectangle around the location of a first click in a double-click sequence, in pixels. The second click must occur within the rectangle defined by SM_CXDOUBLECLK and SM_CYDOUBLECLK for the system to consider the two clicks a double-click. (The two clicks must also occur within a specified time.) 
        /// (a.k.a. SM_CYDOUBLECLK)
        /// </summary>
        DoubleClickRectangleHeight = 37,

        /// <summary>
        /// Width of a grid cell for items in large icon view, in pixels. Each item fits into a rectangle of size SM_CXICONSPACING by SM_CYICONSPACING when arranged. This value is always greater than or equal to SM_CXICON
        /// (a.k.a. SM_CXICONSPACING)
        /// </summary>
        IconSpacingWidth = 38,

        /// <summary>
        /// Height of a grid cell for items in large icon view, in pixels. Each item fits into a rectangle of size SM_CXICONSPACING by SM_CYICONSPACING when arranged. This value is always greater than or equal to SM_CYICON.
        /// (a.k.a. SM_CYICONSPACING)
        /// </summary>
        IconSpacingHeight = 39,

        /// <summary>
        /// Nonzero if drop-down menus are right-aligned with the corresponding menu-bar item; zero if the menus are left-aligned.
        /// (a.k.a. SM_MENUDROPALIGNMENT)
        /// </summary>
        MenuDropAlignment = 40,

        /// <summary>
        /// Nonzero if the Microsoft Windows for Pen computing extensions are installed; zero otherwise.
        /// (a.k.a. SM_PENWINDOWS)
        /// </summary>
        PenWindows = 41,

        /// <summary>
        /// Nonzero if User32.dll supports DBCS; zero otherwise. (WinMe/95/98): Unicode
        /// (a.k.a. SM_DBCSENABLED)
        /// </summary>
        DbcsEnabled = 42,

        /// <summary>
        /// Number of buttons on mouse, or zero if no mouse is installed.
        /// (a.k.a. SM_CMOUSEBUTTONS)
        /// </summary>
        MouseButtons = 43,

        /// <summary>
        /// Identical Values SM_CXFIXEDFRAME After Windows NT 4.0  
        /// (a.k.a. SM_CXFIXEDFRAME)
        /// </summary>
        FixedFrameWidth = DialogFrameWidth,

        /// <summary>
        /// Identical Values Changed After Windows NT 4.0
        /// (a.k.a. SM_CYFIXEDFRAME)
        /// </summary>
        FixedFrameHeight = DialogFrameHeight,

        /// <summary>
        /// Identical Values Changed After Windows NT 4.0
        /// (a.k.a. SM_CXSIZEFRAME)
        /// </summary>
        SizeFrameWidth = FrameWidth,

        /// <summary>
        /// Identical Values Changed After Windows NT 4.0
        /// (a.k.a. SM_CYSIZEFRAME)
        /// </summary>
        SizeFrameHeight = FrameHeight,

        /// <summary>
        /// Nonzero if security is present; zero otherwise.
        /// (a.k.a. SM_SECURE)
        /// </summary>
        Secure = 44,

        /// <summary>
        /// Width of a 3-D border, in pixels. This is the 3-D counterpart of SM_CXBORDER
        /// (a.k.a. SM_CXEDGE)
        /// </summary>
        EdgeWidth = 45,

        /// <summary>
        /// Height of a 3-D border, in pixels. This is the 3-D counterpart of SM_CYBORDER
        /// (a.k.a. SM_CYEDGE)
        /// </summary>
        EdgeHeight = 46,

        /// <summary>
        /// Width of a grid cell for a minimized window, in pixels. Each minimized window fits into a rectangle this size when arranged. This value is always greater than or equal to SM_CXMINIMIZED.
        /// (a.k.a. SM_CXMINSPACING)
        /// </summary>
        MinimizedSpacingWidth = 47,

        /// <summary>
        /// Height of a grid cell for a minimized window, in pixels. Each minimized window fits into a rectangle this size when arranged. This value is always greater than or equal to SM_CYMINIMIZED.
        /// (a.k.a. SM_CYMINSPACING)
        /// </summary>
        MinimizedSpacingHeight = 48,

        /// <summary>
        /// Recommended width of a small icon, in pixels. Small icons typically appear in window captions and in small icon view
        /// (a.k.a. SM_CXSMICON)
        /// </summary>
        SmallIconWidth = 49,

        /// <summary>
        /// Recommended height of a small icon, in pixels. Small icons typically appear in window captions and in small icon view.
        /// (a.k.a. SM_CYSMICON)
        /// </summary>
        SmallIconHeight = 50,

        /// <summary>
        /// Height of a small caption, in pixels
        /// (a.k.a. SM_CYSMCAPTION)
        /// </summary>
        SmallCaptionHeight = 51,

        /// <summary>
        /// Width of small caption buttons, in pixels.
        /// (a.k.a. SM_CXSMSIZE)
        /// </summary>
        SmallCaptionButtonWidth = 52,

        /// <summary>
        /// Height of small caption buttons, in pixels.
        /// (a.k.a. SM_CYSMSIZE)
        /// </summary>
        SmallCaptionButtonHeight = 53,

        /// <summary>
        /// Width of menu bar buttons, such as the child window close button used in the multiple document interface, in pixels.
        /// (a.k.a. SM_CXMENUSIZE)
        /// </summary>
        MenuSizeWidth = 54,

        /// <summary>
        /// Height of menu bar buttons, such as the child window close button used in the multiple document interface, in pixels.
        /// (a.k.a. SM_CYMENUSIZE)
        /// </summary>
        MenuSizeHeight = 55,

        /// <summary>
        /// Flags specifying how the system arranged minimized windows
        /// (a.k.a. SM_ARRANGE)
        /// </summary>
        Arrange = 56,

        /// <summary>
        /// Width of a minimized window, in pixels.
        /// (a.k.a. SM_CXMINIMIZED)
        /// </summary>
        MinimizedWidth = 57,

        /// <summary>
        /// Height of a minimized window, in pixels.
        /// (a.k.a. SM_CYMINIMIZED)
        /// </summary>
        MinimizedHeight = 58,

        /// <summary>
        /// Default maximum width of a window that has a caption and sizing borders, in pixels. This metric refers to the entire desktop. The user cannot drag the window frame to a size larger than these dimensions. A window can override this value by processing the WM_GETMINMAXINFO message.
        /// (a.k.a. SM_CXMAXTRACK)
        /// </summary>
        MaxTrackWidth = 59,

        /// <summary>
        /// Default maximum height of a window that has a caption and sizing borders, in pixels. This metric refers to the entire desktop. The user cannot drag the window frame to a size larger than these dimensions. A window can override this value by processing the WM_GETMINMAXINFO message.
        /// (a.k.a. SM_CYMAXTRACK)
        /// </summary>
        MaxTrackHeight = 60,

        /// <summary>
        /// Default width, in pixels, of a maximized top-level window on the primary display monitor.
        /// (a.k.a. SM_CXMAXIMIZED)
        /// </summary>
        MaximizedWidth = 61,

        /// <summary>
        /// Default height, in pixels, of a maximized top-level window on the primary display monitor.
        /// (a.k.a. SM_CYMAXIMIZED)
        /// </summary>
        MaximizedHeight = 62,

        /// <summary>
        /// Least significant bit is set if a network is present; otherwise, it is cleared. The other bits are reserved for future use
        /// (a.k.a. SM_NETWORK)
        /// </summary>
        Network = 63,

        /// <summary>
        /// Value that specifies how the system was started: 0-normal, 1-failsafe, 2-failsafe /w net
        /// (a.k.a. SM_CLEANBOOT)
        /// </summary>
        CleanBoot = 67,

        /// <summary>
        /// Width of a rectangle centered on a drag point to allow for limited movement of the mouse pointer before a drag operation begins, in pixels. 
        /// (a.k.a. SM_CXDRAG)
        /// </summary>
        DragWidth = 68,

        /// <summary>
        /// Height of a rectangle centered on a drag point to allow for limited movement of the mouse pointer before a drag operation begins. This value is in pixels. It allows the user to click and release the mouse button easily without unintentionally starting a drag operation.
        /// (a.k.a. SM_CYDRAG)
        /// </summary>
        DragHeight = 69,

        /// <summary>
        /// Nonzero if the user requires an application to present information visually in situations where it would otherwise present the information only in audible form; zero otherwise. 
        /// (a.k.a. SM_SHOWSOUNDS)
        /// </summary>
        ShowSounds = 70,

        /// <summary>
        /// Width of the default menu check-mark bitmap, in pixels.
        /// (a.k.a. SM_CXMENUCHECK)
        /// </summary>
        MenuCheckWidth = 71,

        /// <summary>
        /// Height of the default menu check-mark bitmap, in pixels.
        /// (a.k.a. SM_CYMENUCHECK)
        /// </summary>
        MenuCheckHeight = 72,

        /// <summary>
        /// Nonzero if the computer has a low-end (slow) processor; zero otherwise
        /// (a.k.a. SM_SLOWMACHINE)
        /// </summary>
        SlowMachine = 73,

        /// <summary>
        /// Nonzero if the system is enabled for Hebrew and Arabic languages, zero if not.
        /// (a.k.a. SM_MIDEASTENABLED)
        /// </summary>
        MidEastEnabled = 74,

        /// <summary>
        /// Nonzero if a mouse is installed; zero otherwise. This value is rarely zero, because of support for virtual mice and because some systems detect the presence of the port instead of the presence of a mouse.
        /// (a.k.a. SM_MOUSEPRESENT)
        /// </summary>
        MousePresent = 19,

        /// <summary>
        /// Windows 2000 (v5.0+) Coordinate of the top of the virtual screen
        /// (a.k.a. SM_XVIRTUALSCREEN)
        /// </summary>
        VirtualScreenXCoordinate = 76,

        /// <summary>
        /// Windows 2000 (v5.0+) Coordinate of the left of the virtual screen
        /// (a.k.a. SM_YVIRTUALSCREEN)
        /// </summary>
        VirtualScreenYCoordinate = 77,

        /// <summary>
        /// Windows 2000 (v5.0+) Width of the virtual screen
        /// (a.k.a. SM_CXVIRTUALSCREEN)
        /// </summary>
        VirtualScreenWidth = 78,

        /// <summary>
        /// Windows 2000 (v5.0+) Height of the virtual screen
        /// (a.k.a. SM_CYVIRTUALSCREEN)
        /// </summary>
        VirtualScreenHeight = 79,

        /// <summary>
        /// Number of display monitors on the desktop
        /// (a.k.a. SM_CMONITORS)
        /// </summary>
        Monitors = 80,

        /// <summary>
        /// Windows XP (v5.1+) Nonzero if all the display monitors have the same color format, zero otherwise. Note that two displays can have the same bit depth, but different color formats. For example, the red, green, and blue pixels can be encoded with different numbers of bits, or those bits can be located in different places in a pixel's color value. 
        /// (a.k.a. SM_SAMEDISPLAYFORMAT)
        /// </summary>
        SanmeDisplayFormat = 81,

        /// <summary>
        /// Windows XP (v5.1+) Nonzero if Input Method Manager/Input Method Editor features are enabled; zero otherwise
        /// (a.k.a. SM_IMMENABLED)
        /// </summary>
        ImmEnabled = 82,

        /// <summary>
        /// Windows XP (v5.1+) Width of the left and right edges of the focus rectangle drawn by DrawFocusRect. This value is in pixels. 
        /// (a.k.a. SM_CXFOCUSBORDER)
        /// </summary>
        FocusBorderWidth = 83,

        /// <summary>
        /// Windows XP (v5.1+) Height of the top and bottom edges of the focus rectangle drawn by DrawFocusRect. This value is in pixels. 
        /// (a.k.a. SM_CYFOCUSBORDER)
        /// </summary>
        FocusBorderHeight = 84,

        /// <summary>
        /// Nonzero if the current operating system is the Windows XP Tablet PC edition, zero if not.
        /// (a.k.a. SM_TABLETPC)
        /// </summary>
        TablePC = 86,

        /// <summary>
        /// Nonzero if the current operating system is the Windows XP, Media Center Edition, zero if not.
        /// (a.k.a. SM_MEDIACENTER)
        /// </summary>
        MediaCenter = 87,

        /// <summary>
        /// Metrics Other
        /// (a.k.a. SM_CMETRICS_OTHER)
        /// </summary>
        MetricsOther = 76,

        /// <summary>
        /// Metrics Windows 2000
        /// (a.k.a. SM_CMETRICS_2000)
        /// </summary>
        MetricsW2K = 83,

        /// <summary>
        /// Metrics Windows NT
        /// (a.k.a. SM_CMETRICS_NT)
        /// </summary>
        MetricsNT = 88,

        /// <summary>
        /// Metrics Windows Server 2003 R2
        /// </summary>
        MetricsServerR2 = 89,

        /// <summary>
        /// Windows XP (v5.1+) This system metric is used in a Terminal Services environment. If the calling process is associated with a Terminal Services client session, the return value is nonzero. If the calling process is associated with the Terminal Server console session, the return value is zero. The console session is not necessarily the physical console - see WTSGetActiveConsoleSessionId for more information. 
        /// (a.k.a. SM_REMOTESESSION)
        /// </summary>
        RemoteSession = 0x1000,

        /// <summary>
        /// Windows XP (v5.1+) Nonzero if the current session is shutting down; zero otherwise
        /// (a.k.a. SM_SHUTTINGDOWN)
        /// </summary>
        ShuttingDown = 0x2000,

        /// <summary>
        /// Windows XP (v5.1+) This system metric is used in a Terminal Services environment. Its value is nonzero if the current session is remotely controlled; zero otherwise
        /// (a.k.a. SM_REMOTECONTROL)
        /// </summary>
        RemoteControl = 0x2001
    }

    /// <summary>
    /// Contains values that indicate the type of session information to retrieve in a call to the WTSQuerySessionInformation function.
    /// (a.k.a. WTS_INFO_CLASS)
    /// </summary>
    public enum WtsInfoClass
    {
        /// <summary>
        /// A null-terminated string containing the name of the initial program that Terminal Services runs when the user logs on.
        /// (a.k.a. WTSInitialProgram)
        /// </summary>
        InitialProgram = 0,

        /// <summary>
        /// A null-terminated string containing the published name of the application the session is running.
        /// (a.k.a. WTSApplicationName)
        /// </summary>
        ApplicationName,

        /// <summary>
        /// A null-terminated string containing the default directory used when launching the initial program.
        /// (a.k.a. WTSWorkingDirectory)
        /// </summary>
        WorkingDirectory,

        /// <summary>
        /// Not used
        /// (a.k.a. WTSOEMId)
        /// </summary>
        OemId,

        /// <summary>
        /// ULONG value containing the session identifier.
        /// (a.k.a. WTSSessionId)
        /// </summary>
        SessionId,

        /// <summary>
        /// A null-terminated string containing the name of the user associated with the session.
        /// (a.k.a. WTSUserName)
        /// </summary>
        UserName,

        /// <summary>
        /// A null-terminated string containing the name of the Terminal Services session. 
        /// Note: Despite its name, specifying this type does not return the window station name. Rather, it returns the name of the Terminal Services session. Each Terminal Services session is associated with an interactive window station. Currently, since the only supported window station name for an interactive window station is "WinSta0", each session is associated with its own "WinSta0" window station. For more information, see Window Stations.
        /// (a.k.a. WTSWinStationName)
        /// </summary>
        WinStationName,

        /// <summary>
        /// A null-terminated string containing the name of the domain to which the logged-on user belongs.
        /// (a.k.a. WTSDomainName)
        /// </summary>
        DomainName,

        /// <summary>
        /// The session's current connection state. For more information, see WTS_CONNECTSTATE_CLASS.
        /// (a.k.a. WTSConnectState)
        /// </summary>
        ConnectState,

        /// <summary>
        /// A ULONG value containing the build number of the client.
        /// (a.k.a. WTSClientBuildNumber)
        /// </summary>
        ClientBuildNumber,

        /// <summary>
        /// A null-terminated string containing the name of the client.
        /// (a.k.a. WTSClientName)
        /// </summary>
        ClientName,

        /// <summary>
        /// A null-terminated string containing the directory in which the client is installed.
        /// (a.k.a. WTSClientDirectory)
        /// </summary>
        ClientDirectory,

        /// <summary>
        /// A USHORT client-specific product identifier.
        /// (a.k.a. WTSClientProductId)
        /// </summary>
        ClientProductId,

        /// <summary>
        /// A ULONG value containing a client-specific hardware identifier.
        /// (a.k.a. WTSClientHardwareId)
        /// </summary>
        ClientHardwareId,

        /// <summary>
        /// The network type and network address of the client. For more information, see  WTS_CLIENT_ADDRESS.
        /// (a.k.a. WTSClientAddress)
        /// </summary>
        ClientAddress,

        /// <summary>
        /// Information about the display resolution of the client. For more information, see WTS_CLIENT_DISPLAY.
        /// (a.k.a. WTSClientDisplay)
        /// </summary>
        ClientDisplay,

        /// <summary>
        /// A USHORT value specifying information about the protocol type for the session.
        /// (a.k.a. WTSClientProtocolType)
        /// </summary>
        ClientProtocolType
    }

    [Flags]
    public enum WtsEvent : uint
    {
        /// <summary>
        /// return no event
        /// (a.k.a. WTS_EVENT_NONE)
        /// </summary>
        None         = 0x00000000,

        /// <summary>
        /// new WinStation created
        /// (a.k.a. WTS_EVENT_CREATE)
        /// </summary>
        Create       = 0x00000001,

        /// <summary>
        /// existing WinStation deleted
        /// (a.k.a. WTS_EVENT_DELETE)
        /// </summary>
        Delete       = 0x00000002,

        /// <summary>
        /// existing WinStation renamed
        /// (a.k.a. WTS_EVENT_RENAME)
        /// </summary>
        Rename       = 0x00000004,

        /// <summary>
        /// WinStation connect to client
        /// (a.k.a. WTS_EVENT_CONNECT)
        /// </summary>
        Connect      = 0x00000008,

        /// <summary>
        /// WinStation logged on without client
        /// (a.k.a. WTS_EVENT_DISCONNECT)
        /// </summary>
        Disconnect   = 0x00000010,
        
        /// <summary>
        /// user logged on to existing WinStation
        /// (a.k.a. WTS_EVENT_LOGON)
        /// </summary>
        Logon        = 0x00000020,
        
        /// <summary>
        /// user logged off from existing WinStation
        /// (a.k.a. WTS_EVENT_LOGOFF)
        /// </summary>
        Logoff       = 0x00000040,
        
        /// <summary>
        /// WinStation state change
        /// (a.k.a. WTS_EVENT_STATECHANGE)
        /// </summary>
        StateChange  = 0x00000080,

        /// <summary>
        /// license state change
        /// (a.k.a. WTS_EVENT_LICENSE)
        /// </summary>
        License      = 0x00000100,

        /// <summary>
        /// wait for all event types
        /// (a.k.a. WTS_EVENT_ALL)
        /// </summary>
        All          = 0x7fffffff,
  
        /// <summary>
        /// unblock all waiters
        /// (a.k.a. WTS_EVENT_FLUSH)
        /// </summary>
        Flush        = 0x80000000
    }


    /// <summary>
    /// Contains the client network address of a Terminal Services session.
    /// (a.k.a. WTS_CLIENT_ADDRESS)
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct WtsClientAddress
    {
        public UInt32 AddressFamily; // AF_INET, AF_IPX, AF_NETBIOS, AF_UNSPEC
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public Byte[] Address;       // client network address
    }



    /// <summary>
    /// (a.k.a. WTS_CONNECTSTATE_CLASS)
    /// </summary>
    public enum WtsConnectStateClass : uint
    {
        /// <summary>
        /// A user is logged on to the WinStation. 
        /// (a.k.a. WTSActive)
        /// </summary>
        Active,

        /// <summary>
        /// The WinStation is connected to the client. 
        /// (a.k.a. WTSActive)
        /// </summary>
        Connected,

        /// <summary>
        /// The WinStation is in the process of connecting to the client. 
        /// (a.k.a. WTSActive)
        /// </summary>
        ConnectQuery,

        /// <summary>
        /// The WinStation is shadowing another WinStation. 
        /// (a.k.a. WTSActive)
        /// </summary>
        Shadow,

        /// <summary>
        /// The WinStation is active but the client is disconnected. 
        /// (a.k.a. WTSActive)
        /// </summary>
        Disconnected,

        /// <summary>
        /// The WinStation is waiting for a client to connect. 
        /// (a.k.a. WTSActive)
        /// </summary>
        Idle,

        /// <summary>
        /// The WinStation is listening for a connection. A listener session waits for requests for new client connections. No user is logged on a listener session. A listener session cannot be reset, shadowed, or changed to a regular client session. 
        /// (a.k.a. WTSActive)
        /// </summary>
        Listen,

        /// <summary>
        /// The WinStation is being reset. 
        /// (a.k.a. WTSActive)
        /// </summary>
        Reset,

        /// <summary>
        /// The WinStation is down due to an error. 
        /// (a.k.a. WTSActive)
        /// </summary>
        Down,

        /// <summary>
        /// The WinStation is initializing. 
        /// (a.k.a. WTSActive)
        /// </summary>
        Init
    }

    /// <summary>
    /// Contains information about a client session on a terminal server.
    /// (a.k.a. WTS_SESSION_INFO)
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct WtsSessionInfo
    {
        public UInt32 SessionID;
        [MarshalAs(UnmanagedType.LPTStr)]
        public String pWinStationName;
        public WtsConnectStateClass State;
    }

    [Flags]
    public enum VersionSuite : ushort
    {
        /// <summary>
        /// (a.k.a. VER_SUITE_SMALLBUSINESS)
        /// </summary>
        SmallBusiness = 0x0001,

        /// <summary>
        /// (a.k.a. VER_SUITE_ENTERPRISE)
        /// </summary>
        Enterprise = 0x0002,

        /// <summary>
        /// (a.k.a. VER_SUITE_BACKOFFICE)
        /// </summary>
        BackOffice = 0x0004,

        /// <summary>
        /// (a.k.a. VER_SUITE_COMMUNICATIONS)
        /// </summary>
        Communications = 0x0008,

        /// <summary>
        /// (a.k.a. VER_SUITE_TERMINAL)
        /// </summary>
        Terminal = 0x0010,

        /// <summary>
        /// (a.k.a. VER_SUITE_SMALLBUSINESS_RESTRICTED)
        /// </summary>
        SmallBusinessRestricted = 0x0020,

        /// <summary>
        /// (a.k.a. VER_SUITE_EMBEDDEDNT)
        /// </summary>
        EmbeddedNT = 0x0040,

        /// <summary>
        /// (a.k.a. VER_SUITE_DATACENTER)
        /// </summary>
        DataCenter = 0x0080,

        /// <summary>
        /// (a.k.a. VER_SUITE_SINGLEUSERTS)
        /// </summary>
        SingleUserTS = 0x0100,

        /// <summary>
        /// (a.k.a. VER_SUITE_PERSONAL)
        /// </summary>
        Personal = 0x0200,

        /// <summary>
        /// (a.k.a. VER_SUITE_BLADE)
        /// </summary>
        Blade = 0x0400,

        /// <summary>Embedded.</summary>
        EmbeddedRestricted = 0x800,
        /// <summary>Some appliance.</summary>
        SecurityAppliance = 0x1000,
        /// <summary>A storage server.</summary>
        StorageServer = 0x2000,
        /// <summary>A compute server.</summary>
        ComputeServer = 0x4000,
    }

    /// <summary>
    /// Defines the major version number of the Operating System.
    /// </summary>
    public enum WindowsMajorVersion : int
    {
        /// <summary>The Operating System is Windows NT 4.0</summary>
        WinNT4 = 4,
        /// <summary>The Operating System is Windows Server 2003 R2, Windows Server 2003, Windows XP, or Windows 2000.</summary>
        WinNT5 = 5,
        /// <summary>The Operating System is Windows Vista or Windows Server "Longhorn"</summary>
        Vista = 6,
    };

    /// <summary>
    /// Defines the minor version number of the Operating System.
    /// </summary>
    public enum WindowsMinorVersion : int
    {
        /// <summary>The Operating System is Windows Vista, Windows Server "Longhorn", Windows 2000, or Windows NT4.0</summary>
        WindowsVista_Server_2k_NT = 0,
        /// <summary>The Operating System is Windows XP</summary>
        WindowsXP = 1,
        /// <summary>The Operating System is Windows Server 2003 R2, Windows Server 2003, or Windows XP Professional x64 Edition.</summary>
        WindowsServer2003_x64 = 2,
    };

    /// <summary>
    /// The Windows product types (IE Workstation, Server, etc.)
    /// </summary>
    public enum ProductType : byte
    {
        /// <summary>Workstation</summary>
        NTWorkstation = 1,
        /// <summary>Domain Controller</summary>
        DomainController = 2,
        /// <summary>Server</summary>
        NTServer = 3,
    };

    /// <summary>
    /// Defines the different page protection values, as used by the CreateFileMapping Win32 API.
    /// </summary>
    [Flags]
    public enum PageProtection : uint
    {
        /// <summary>No access.</summary>
        NoAccess = 0x01,
        /// <summary>Read-only access.</summary>
        Readonly = 0x02,
        /// <summary>Read/Write access.</summary>
        ReadWrite = 0x04,
        /// <summary>Copy-on write access.</summary>
        WriteCopy = 0x08,
        /// <summary>Execute access.</summary>
        Execute = 0x10,
        /// <summary>Execute/Read access.</summary>
        ExecuteRead = 0x20,
        /// <summary>Execute/Read/Write access.</summary>
        ExecuteReadWrite = 0x40,
        /// <summary>Execute/Write/Copy access.</summary>
        ExecuteWriteCopy = 0x80,
        /// <summary>Execute/Write/Copy access.</summary>
    };

    /// <summary>
    /// Defines the various levels of access, as used by the MapViewOfFile Win32 API.
    /// </summary>
    [Flags]
    public enum FileMapAccess : uint
    {
        /// <summary>Combines DELETE, READ_CONTROL, WRITE_DAC, WRITE_OWNER, and SYNCHRONIZE access</summary>
        StandardRightsRequired = 0x000F0000,
        /// <summary>The ability to query.</summary>
        SectionQuery = 0x0001,
        /// <summary>A read/write view of the file is mapped.</summary>
        FileMapWrite = 0x0002,
        /// <summary>A read-only view of the file is mapped.</summary>
        FileMapRead = 0x0004,
        /// <summary>An executable view of the file is mapped.</summary>
        FileMapExecute = 0x0008,
        /// <summary>(Undocumented).</summary>
        FileMapExtendSize = 0x0010,
        /// <summary>An executable view of the file is mapped </summary>
        SECTION_ALL_ACCESS = (StandardRightsRequired | SectionQuery | FileMapWrite | FileMapRead | FileMapExecute | FileMapExtendSize),
    };

    [StructLayout(LayoutKind.Sequential)]
    public struct OSVersionInfo
    {
        public int dwOSVersionInfoSize;
        public int dwMajorVersion;
        public int dwMinorVersion;
        public int dwBuildNumber;
        public int dwPlatformId;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string szCSDVersion;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct OSVersionInfoEx
    {
        /// <summary>Size of this data structure, in bytes.</summary>        
        public int dwOSVersionInfoSize;
        /// <summary>Major version number of the operating system.</summary>
        /// <remarks>
        /// 4 = Windows NT4
        /// 5 = Windows Server 2003, Windows XP, or Windows 2000
        /// 6 = Windows Vista
        /// </remarks>
        public WindowsMajorVersion dwMajorVersion;
        /// <summary>Minor version number of the operating system</summary>
        /// <remarks>
        /// 0 = Windows Vista, Windows 2000, or Windows NT4
        /// 1 = Windows XP
        /// 2 = Windows Server 2003, Windows XP-x64
        /// </remarks>
        public WindowsMinorVersion dwMinorVersion;
        /// <summary>Build number of the operating system.</summary>
        public int dwBuildNumber;
        /// <summary>Operating system platform.</summary>
        public int dwPlatformId;
        /// <summary>Pointer to a null-terminated string, such as "Service Pack 3", that indicates the latest Service Pack installed on the system.</summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string szCSDVersion;
        /// <summary>Major version number of the latest Service Pack installed on the system.</summary>
        public ushort wServicePackMajor;
        /// <summary>Minor version number of the latest Service Pack installed on the system.</summary>
        public ushort wServicePackMinor;
        /// <summary>Bit flags that identify the product suites available on the system.</summary>
        public VersionSuite wSuiteMask;
        /// <summary>Additional information about the system.</summary>
        /// <remarks>
        /// 2 = The system is a domain controller.
        /// 3 = The system is a server.
        /// 1 = The OS is Windows Vista, Windows XP Professional/Home, Windows 2000 Professional, or Windows NT Workstation 4.0
        /// </remarks>
        public ProductType wProductType;
        /// <summary></summary>
        public byte wReserved;
    }

	/// <summary>UNC name.</summary>
	[StructLayout( LayoutKind.Sequential, CharSet = CharSet.Auto )]
	public struct UNIVERSAL_NAME_INFO
	{
		[MarshalAs( UnmanagedType.LPTStr )]
		public string lpUniversalName;
	}

	/// <summary>
	/// Type of share, for SHARE_INFO structs.
	/// </summary>
	[Flags]
	public enum ShareType
	{
		/// <summary>Disk share</summary>
		Disk = 0,
		/// <summary>Printer share</summary>
		Printer = 1,
		/// <summary>Device share</summary>
		Device = 2,
		/// <summary>IPC share</summary>
		IPC = 3,
		/// <summary>Special share</summary>
		Special = -2147483648, // 0x80000000,
	}

	/// <summary>Share information, NT, level 2/</summary>
	/// <remarks>
	/// Requires admin rights.
	/// </remarks>
	[StructLayout( LayoutKind.Sequential, CharSet = CharSet.Unicode )]
	public struct SHARE_INFO_2
	{
		[MarshalAs( UnmanagedType.LPWStr )]
		public string NetName;
		public ShareType ShareType;
		[MarshalAs( UnmanagedType.LPWStr )]
		public string Remark;
		public int Permissions;
		public int MaxUsers;
		public int CurrentUsers;
		[MarshalAs( UnmanagedType.LPWStr )]
		public string Path;
		[MarshalAs( UnmanagedType.LPWStr )]
		public string Password;
	}

	/// <summary>Share information, NT, level 1.</summary>
	/// <remarks>
	/// Fallback when caller does not have admin rights.
	/// </remarks>
	[StructLayout( LayoutKind.Sequential, CharSet = CharSet.Unicode )]
	public struct SHARE_INFO_1
	{
		[MarshalAs( UnmanagedType.LPWStr )]
		public string NetName;
		public ShareType ShareType;
		[MarshalAs( UnmanagedType.LPWStr )]
		public string Remark;
	}

	// Specifies how a window is to be shown.
	[Flags]
	public enum SW
	{
		/// <summary>Hide.</summary>
		HIDE = 0,

		/// <summary>Show normal.</summary>
		SHOWNORMAL = 1,

		/// <summary>Show Normal.</summary>
		NORMAL = 1,

		/// <summary>Show minimized.</summary>
		SHOWMINIMIZED = 2,

		/// <summary>Show maximized.</summary>
		SHOWMAXIMIZED = 3,

		/// <summary>Show maximized.</summary>
		MAXIMIZE = 3,

		/// <summary>Show active.</summary>
		SHOWNOACTIVATE = 4,

		/// <summary>Show.</summary>
		SHOW = 5,

		/// <summary>Show minimized.</summary>
		MINIMIZE = 6,

		/// <summary>Show minimized and not active.</summary>
		SHOWMINNOACTIVE = 7,

		/// <summary>Show not active.</summary>
		SHOWNA = 8,

		/// <summary>Restore window.</summary>
		RESTORE = 9,

		/// <summary>Show default.</summary>
		SHOWDEFAULT = 10,
	}

	/// <summary>
	/// Flags used with the CMINVOKECOMMANDINFOEX structure. 
	/// </summary>
	[Flags]
	public enum CMIC : uint
	{	
		HOTKEY = 0x00000020,		
		ICON = 0x00000010,		
		FLAG_NO_UI = 0x00000400,		
		UNICODE = 0x00004000,		
		NO_CONSOLE = 0x00008000,	
		ASYNCOK = 0x00100000,		
		NOZONECHECKS = 0x00800000,
		SHIFT_DOWN = 0x10000000,
		CONTROL_DOWN = 0x40000000,
		FLAG_LOG_USAGE = 0x04000000,
		PTINVOKE = 0x20000000
	}

	/// <summary>
	/// Flags specifying the information to return when calling IContextMenu::GetCommandString.
	/// </summary>
	[Flags]
	public enum GCS : uint
	{
		VERBA = 0,
		HELPTEXTA = 1,
		VALIDATEA = 2,
		VERBW = 4,
		HELPTEXTW = 5,
		VALIDATEW = 6
	}

    /// <summary>
    /// Defines the different SID accounts.
    /// </summary>
    public enum SidAccount
    {
        /// <summary>A user SID.</summary>
        SidTypeUser = 1,
        /// <summary>A group SID.</summary>
        SidTypeGroup,
        /// <summary>A domain SID.</summary>
        SidTypeDomain,
        /// <summary>An alias SID.</summary>
        SidTypeAlias,
        /// <summary>A SID for a well-known group.</summary>
        SidTypeWellKnownGroup,
        /// <summary>A SID for a deleted account.</summary>
        SidTypeDeletedAccount,
        /// <summary>A SID that is not valid.</summary>
        SidTypeInvalid,
        /// <summary>A SID of an unknown type.</summary>
        SidTypeUnknown,
        /// <summary>A SID for a computer.</summary>
        SidTypeComputer,
        /// <summary>A mandatory integraity label SID.</summary>
        SidTypeLabel,
    };

	/// <summary>
	/// Contains extended information about a shortcut menu command. 
	/// </summary>
	[StructLayout( LayoutKind.Sequential, CharSet = CharSet.Unicode )]
	public struct CMINVOKECOMMANDINFOEX
	{
		public int cbSize;
		public CMIC fMask;
		public IntPtr hwnd;
		public IntPtr lpVerb;
		[MarshalAs( UnmanagedType.LPStr )]
		public string lpParameters;
		[MarshalAs( UnmanagedType.LPStr )]
		public string lpDirectory;
		public SW nShow;
		public int dwHotKey;
		public IntPtr hIcon;
		[MarshalAs( UnmanagedType.LPStr )]
		public string lpTitle;
		public IntPtr lpVerbW;
		[MarshalAs( UnmanagedType.LPWStr )]
		public string lpParametersW;
		[MarshalAs( UnmanagedType.LPWStr )]
		public string lpDirectoryW;
		[MarshalAs( UnmanagedType.LPWStr )]
		public string lpTitleW;
		public POINT ptInvoke;
	}

	[Flags]
	public enum TrackPopupMenuFlags : uint
	{
		TPM_LEFTALIGN = 0x00000000,
		TPM_RIGHTBUTTON = 0x00000002,
		TPM_RETURNCMD = 0x00000100
	}

	// Specifies how the shortcut menu can be changed when calling IContextMenu::QueryContextMenu
	[Flags]
	public enum CMF : uint
	{
		NORMAL = 0x00000000,
		DEFAULTONLY = 0x00000001,
		VERBSONLY = 0x00000002,
		EXPLORE = 0x00000004,
		NOVERBS = 0x00000008,
		CANRENAME = 0x00000010,
		NODEFAULT = 0x00000020,
		INCLUDESTATIC = 0x00000040,
		EXTENDEDVERBS = 0x00000100,
		RESERVED = 0xffff0000
	}

	[StructLayout( LayoutKind.Explicit )]
	public struct STRRET
	{
		/// <summary>One of the STRRET_* values.</summary>
		[FieldOffset( 0 )]
		public UInt32 uType;

		/// <summary>Must be freed by caller of GetDisplayNameOf.</summary>
		[FieldOffset( 4 )]
		public IntPtr pOleStr;

		/// <summary>NOT USED.</summary>
		[FieldOffset( 4 )]
		public IntPtr pStr;

		/// <summary>Offset into SHITEMID.</summary>
		[FieldOffset( 4 )]
		public UInt32 uOffset;

		/// <summary>Buffer to fill in (ANSI).</summary>
		[FieldOffset( 4 )]
		public IntPtr cStr;
	}

    /// <summary>
    /// Defines the structure used by CFileDialog.
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct OPENFILENAME
    {
        public int lStructSize;
        public IntPtr hwndOwner;
        public int hInstance;
        [MarshalAs(UnmanagedType.LPTStr)]
        public string lpstrFilter;
        [MarshalAs(UnmanagedType.LPTStr)]
        public string lpstrCustomFilter;
        public int nMaxCustFilter;
        public int nFilterIndex;
        [MarshalAs(UnmanagedType.LPTStr)]
        public string lpstrFile;
        public int nMaxFile;
        [MarshalAs(UnmanagedType.LPTStr)]
        public string lpstrFileTitle;
        public int nMaxFileTitle;
        [MarshalAs(UnmanagedType.LPTStr)]
        public string lpstrInitialDir;
        [MarshalAs(UnmanagedType.LPTStr)]
        public string lpstrTitle;
        public int Flags;
        public short nFileOffset;
        public short nFileExtension;
        [MarshalAs(UnmanagedType.LPTStr)]
        public string lpstrDefExt;
        public int lCustData;
        public OFNHookProcDelegate lpfnHook;
        [MarshalAs(UnmanagedType.LPTStr)]
        public string lpTemplateName;
        //only if on nt 5.0 or higher
        public int pvReserved;
        public int dwReserved;
        public int FlagsEx;
    };

    [Flags]
    public enum OPENFILENAMEFlags : uint
    {
        /// <summary>Causes the read only check box to be selected initially.</summary>
        OFN_READONLY                 = 0x00000001,
        /// <summary>Causes the Save As dialog to generate a Message Box if the selected file already exists.</summary>
        OFN_OVERWRITEPROMPT          = 0x00000002,
        /// <summary>Hides the read only check box.</summary>
        OFN_HIDEREADONLY             = 0x00000004,
        /// <summary>Restores the current directory to its original value if the user changed the directory while searching for files.</summary>
        OFN_NOCHANGEDIR              = 0x00000008,
        /// <summary>Causes the dialog to display the help button.</summary>
        OFN_SHOWHELP                 = 0x00000010,
        /// <summary>Enables the hook function specified in the lpfnHook member.</summary>
        OFN_ENABLEHOOK               = 0x00000020,
        /// <summary>Indicates that the lpTemplateName member is a pointer to the name of a dialog tempplate resource in the module identified by the hInstance member.</summary>
        OFN_ENABLETEMPLATE           = 0x00000040,
        /// <summary>Indicates that the hInstance member identifies a data block that contains a preloaded dialog box template.</summary>
        OFN_ENABLETEMPLATEHANDLE     = 0x00000080,
        /// <summary>Specifies that the dialog allows invalid characters in the returned file name.</summary>
        OFN_NOVALIDATE               = 0x00000100,
        /// <summary>Specifies that the file name list box allows multiple selections.</summary>
        OFN_ALLOWMULTISELECT         = 0x00000200,
        /// <summary>Specifies that the user typed a file name extension that differs from the extension specified by lpstrDefExt.</summary>
        OFN_EXTENSIONDIFFERENT       = 0x00000400,
        /// <summary>Specifies that the user can type only valid paths and file names.</summary>
        OFN_PATHMUSTEXIST            = 0x00000800,
        /// <summary>Specifies that the user can type only names of existing files in the file name entry field.</summary>
        OFN_FILEMUSTEXIST            = 0x00001000,
        /// <summary>If the user specifies a file that does not exist, this flag causes the dialog to prompt the user for permission to create the file.</summary>    
        OFN_CREATEPROMPT             = 0x00002000,
        /// <summary>Specifies that if a call to OpenFil function fails because of a network sharing violation, the error is ignored and the dialog returns the selected file name.</summary>
        OFN_SHAREAWARE               = 0x00004000,
        /// <summary>Specifies that the returned file does not have the Read Only check box selected and is not in a write-protected directory.</summary>
        OFN_NOREADONLYRETURN         = 0x00008000,
        /// <summary>Specifies that the file is not created before the dialog box is closed. </summary>
        OFN_NOTESTFILECREATE         = 0x00010000,
        /// <summary>Hides and disables the Network button.</summary>
        OFN_NONETWORKBUTTON          = 0x00020000,
        /// <summary>For old-style dialog boxes, this flag causes the dialog box to use short file names (8.3 format).</summary>
        OFN_NOLONGNAMES              = 0x00040000,
        /// <summary>Indicates that any customizations made to the Open or Save As dialog box use the new Explorer-style customization methods.</summary>
        OFN_EXPLORER                 = 0x00080000,
        /// <summary>Directs the dialog box to return the path and file name of the selected shortcut (.LNK) file.</summary>
        OFN_NODEREFERENCELINKS       = 0x00100000,
        /// <summary>For old-style dialog boxes, this flag causes the dialog box to use long file names.</summary>
        OFN_LONGNAMES                = 0x00200000,
        /// <summary> Causes the dialog box to send CDN_INCLUDEITEM notification messages to your OFNHookProc hook procedure when the user opens a folder.</summary>
        OFN_ENABLEINCLUDENOTIFY      = 0x00400000,
        /// <summary>Enables the Explorer-style dialog box to be resized using either the mouse or the keyboard.</summary>
        OFN_ENABLESIZING             = 0x00800000,
    };

	[Flags]
	public enum SHGNO : uint
	{
		/// <summary>Default (display purpose).</summary>
		SHGDN_NORMAL = 0x0000,

		/// <summary>Displayed under a folder (relative).</summary>
		SHGDN_INFOLDER = 0x0001,

		/// <summary>For in-place editing.</summary>
		SHGDN_FOREDITING = 0x1000,

		/// <summary>UI friendly parsing name (remove ugly stuff).</summary>
		SHGDN_FORADDRESSBAR = 0x4000,

		/// <summary>Parsing name for ParseDisplayName().</summary>
		SHGDN_FORPARSING = 0x8000,
	}

	[Flags]
	public enum SHCONTF : uint
	{
		/// <summary>Only want folders enumerated (SFGAO_FOLDER).</summary>
		SHCONTF_FOLDERS = 0x0020,

		/// <summary>Include non folders.</summary>
		SHCONTF_NONFOLDERS = 0x0040,

		/// <summary>Show items normally hidden.</summary>
		SHCONTF_INCLUDEHIDDEN = 0x0080,

		/// <summary>Allow EnumObject() to return before validating enum.</summary>
		SHCONTF_INIT_ON_FIRST_NEXT = 0x0100,

		/// <summary>Hint that client is looking for printers.</summary>
		SHCONTF_NETPRINTERSRCH = 0x0200,

		/// <summary>Hint that client is looking sharable resources (remote shares).</summary>
		SHCONTF_SHAREABLE = 0x0400,

		/// <summary>Include all items with accessible storage and their ancestors.</summary>
		SHCONTF_STORAGE = 0x0800,
	}

	[Flags]
	public enum SFGAOF : uint
	{
		/// <summary>Objects can be copied (DROPEFFECT_COPY).</summary>
		SFGAO_CANCOPY = 0x1,

		/// <summary>Objects can be moved (DROPEFFECT_MOVE).</summary>
		SFGAO_CANMOVE = 0x2,

		/// <summary>Objects can be linked (DROPEFFECT_LINK).</summary>
		SFGAO_CANLINK = 0x4,

		/// <summary>Supports BindToObject(IID_IStorage).</summary>
		SFGAO_STORAGE = 0x00000008,

		/// <summary>Objects can be renamed.</summary>
		SFGAO_CANRENAME = 0x00000010,

		/// <summary>Objects can be deleted.</summary>
		SFGAO_CANDELETE = 0x00000020,

		/// <summary>Objects have property sheets.</summary>
		SFGAO_HASPROPSHEET = 0x00000040,

		/// <summary>Objects are drop target.</summary>
		SFGAO_DROPTARGET = 0x00000100,

		SFGAO_CAPABILITYMASK = 0x00000177,

		/// <summary>Object is encrypted (use alt color).</summary>
		SFGAO_ENCRYPTED = 0x00002000,

		/// <summary>'Slow' object.</summary>
		SFGAO_ISSLOW = 0x00004000,

		/// <summary>Ghosted icon.</summary>
		SFGAO_GHOSTED = 0x00008000,

		/// <summary>Shortcut (link).</summary>
		SFGAO_LINK = 0x00010000,

		/// <summary>Shared.</summary>
		SFGAO_SHARE = 0x00020000,

		/// <summary>Read-only.</summary>
		SFGAO_READONLY = 0x00040000,

		/// <summary>Hidden object.</summary>
		SFGAO_HIDDEN = 0x00080000,

		SFGAO_DISPLAYATTRMASK = 0x000FC000,

		/// <summary>May contain children with SFGAO_FILESYSTEM.</summary>
		SFGAO_FILESYSANCESTOR = 0x10000000,

		/// <summary>Support BindToObject(IID_IShellFolder).</summary>
		SFGAO_FOLDER = 0x20000000,

		/// <summary>Is a win32 file system object (file/folder/root).</summary>
		SFGAO_FILESYSTEM = 0x40000000,

		/// <summary>May contain children with SFGAO_FOLDER.</summary>
		SFGAO_HASSUBFOLDER = 0x80000000,

		SFGAO_CONTENTSMASK = 0x80000000,

		/// <summary>Invalidate cached information.</summary>
		SFGAO_VALIDATE = 0x01000000,

		/// <summary>Is this removeable media?</summary>
		SFGAO_REMOVABLE = 0x02000000,

		/// <summary>Object is compressed (use alt color).</summary>
		SFGAO_COMPRESSED = 0x04000000,

		/// <summary>Supports IShellFolder, but only implements CreateViewObject() (non-folder view).</summary>
		SFGAO_BROWSABLE = 0x08000000,

		/// <summary>Is a non-enumerated object.</summary>
		SFGAO_NONENUMERATED = 0x00100000,

		/// <summary>Should show bold in explorer tree.</summary>
		SFGAO_NEWCONTENT = 0x00200000,
				
		SFGAO_CANMONIKER = 0x00400000,

		/// <summary>Defunct.</summary>
		SFGAO_HASSTORAGE = 0x00400000,

		/// <summary>Supports BindToObject(IID_IStream).</summary>
		SFGAO_STREAM = 0x00400000,

		/// <summary>May contain children with SFGAO_STORAGE or SFGAO_STREAM.</summary>
		SFGAO_STORAGEANCESTOR = 0x00800000,

		/// <summary>For determining storage capabilities, i.e. for open/save semantics.</summary>
		SFGAO_STORAGECAPMASK = 0x70C50008,
	}

    /// <summary>
    /// Defines the different ODBC data source request flags.
    /// </summary>
    public enum RequestFlags : int
    {
        /// <summary>Add a user data source.</summary>
        ODBC_ADD_DSN                = 1,
        /// <summary>Configure a user data source.</summary>
        ODBC_CONFIG_DSN             = 2,
        /// <summary>Remove a user data source.</summary>
        ODBC_REMOVE_DSN             = 3,
        /// <summary>Add a system data source.</summary>
        ODBC_ADD_SYS_DSN            = 4,
        /// <summary>Configure a system data source.</summary>
        ODBC_CONFIG_SYS_DSN         = 5,
        /// <summary>Remove a system data source.</summary>
        ODBC_REMOVE_SYS_DSN         = 6,
        /// <summary>Remove a default data source.</summary>
        ODBC_REMOVE_DEFAULT_DSN     = 7
    };

    /// <summary>
    /// Defines the different sound flags used in PlaySound.
    /// </summary>
    public enum SoundFlags
    {
        /// <summary>play synchronously (default).</summary>
        SND_SYNC                    = 0x0000,
        /// <summary>play asynchronously (default).</summary>
        SND_ASYNC                   = 0x0001,
        /// <summary>silence (!default) if sound not found .</summary>
        SND_NODEFAULT               = 0x0002,
        /// <summary>pszSound points to a memory file.</summary>
        SND_MEMORY                  = 0x0004,
        /// <summary>loop the sound until next sndPlaySound .</summary>
        SND_LOOP                    = 0x0008,
        /// <summary>don't stop any currently playing sound.</summary>
        SND_NOSTOP                  = 0x0010,
        /// <summary>don't wait if the driver is busy .</summary>
        SND_NOWAIT                  = 0x00002000,
        /// <summary>name is a registry alias .</summary>
        SND_ALIAS                   = 0x00010000,
        /// <summary>alias is a predefined ID.</summary>
        SND_ALIAS_ID                = 0x00110000,
        /// <summary>name is file name .</summary>
        SND_FILENAME                = 0x00020000,
        /// <summary>name is resource name or atom .</summary>
        SND_RESOURCE                = 0x00040004
    }
	
	/// <summary>
	/// Enums for LogonUser method's LogonType parameter.
	/// </summary>
	public enum LogonType : int
	{
		/// <summary>
		/// This logon type is intended for users who will be interactively using the computer, such as a user being logged on  
		/// by a terminal server, remote shell, or similar process.
		/// This logon type has the additional expense of caching logon information for disconnected operations; 
		/// therefore, it is inappropriate for some client/server applications,
		/// such as a mail server.
		/// </summary>
		LOGON32_LOGON_INTERACTIVE = 2,

		/// <summary>
		/// This logon type is intended for high performance servers to authenticate plaintext passwords.

		/// The LogonUser function does not cache credentials for this logon type.
		/// </summary>
		LOGON32_LOGON_NETWORK = 3,

		/// <summary>
		/// This logon type is intended for batch servers, where processes may be executing on behalf of a user without 
		/// their direct intervention. This type is also for higher performance servers that process many plaintext
		/// authentication attempts at a time, such as mail or Web servers. 
		/// The LogonUser function does not cache credentials for this logon type.
		/// </summary>
		LOGON32_LOGON_BATCH = 4,

		/// <summary>
		/// Indicates a service-type logon. The account provided must have the service privilege enabled. 
		/// </summary>
		LOGON32_LOGON_SERVICE = 5,

		/// <summary>
		/// This logon type is for GINA DLLs that log on users who will be interactively using the computer. 
		/// This logon type can generate a unique audit record that shows when the workstation was unlocked. 
		/// </summary>
		LOGON32_LOGON_UNLOCK = 7,

		/// <summary>
		/// This logon type preserves the name and password in the authentication package, which allows the server to make 
		/// connections to other network servers while impersonating the client. A server can accept plaintext credentials 
		/// from a client, call LogonUser, verify that the user can access the system across the network, and still 
		/// communicate with other servers.
		/// NOTE: Windows NT:  This value is not supported. 
		/// </summary>
		LOGON32_LOGON_NETWORK_CLEARTEXT = 8,

		/// <summary>
		/// This logon type allows the caller to clone its current token and specify new credentials for outbound connections.
		/// The new logon session has the same local identifier but uses different credentials for other network connections. 
		/// NOTE: This logon type is supported only by the LOGON32_PROVIDER_WINNT50 logon provider.
		/// NOTE: Windows NT:  This value is not supported. 
		/// </summary>
		LOGON32_LOGON_NEW_CREDENTIALS = 9,
	}

	/// <summary>
	/// Provider parameter for LogonUser method.
	/// </summary>
	public enum LogonProvider : int
	{
		/// <summary>
		/// Use the standard logon provider for the system. 
		/// The default security provider is negotiate, unless you pass NULL for the domain name and the user name 
		/// is not in UPN format. In this case, the default provider is NTLM. 
		/// NOTE: Windows 2000/NT:   The default security provider is NTLM.
		/// </summary>
		LOGON32_PROVIDER_DEFAULT = 0,
	}

	/// <summary>
	/// Structure for process-related methods.
	/// </summary>
	[StructLayout( LayoutKind.Sequential, CharSet = CharSet.Auto )]
	public struct StartupInfo
	{
		public int cb;
		public String reserved;
		public String desktop;
		public String title;
		public int x;
		public int y;
		public int xSize;
		public int ySize;
		public int xCountChars;
		public int yCountChars;
		public int fillAttribute;
		public int flags;
		public UInt16 showWindow;
		public UInt16 reserved2;
		public byte reserved3;
		public IntPtr stdInput;
		public IntPtr stdOutput;
		public IntPtr stdError;
	}

	/// <summary>
	/// Structure for describing process information.
	/// </summary>
	public struct ProcessInformation
	{
		public IntPtr process;
		public IntPtr thread;
		public int processId;
		public int threadId;
	}
	
	[ComImport]
	[InterfaceType( ComInterfaceType.InterfaceIsIUnknown )]
	[Guid( "000214F2-0000-0000-C000-000000000046" )]
	public interface IEnumIDList
	{	
		/// <summary>
		/// Retrieves the specified number of item identifiers in the 
		/// enumeration sequence and advances the current position by 
		/// the number of items retrieved.		
		/// </summary>
		/// <param name="celt"></param>
		/// <param name="rgelt"></param>
		/// <param name="pceltFetched"></param>
		/// <returns></returns>
		[PreserveSig()]		
		uint Next (
			// Number of elements in the array pointed to by the rgelt parameter.			
			uint celt,

			// Address of an array of ITEMIDLIST pointers that receives the item 
			// identifiers. The implementation must allocate these item identifiers 
			// using the Shell's allocator (retrieved by the SHGetMalloc function). 
			// The calling application is responsible for freeing the item 
			// identifiers using the Shell's allocator.
			out IntPtr rgelt,

			// Address of a value that receives a count of the item identifiers 
			// actually returned in rgelt. The count can be smaller than the value 
			// specified in the celt parameter. This parameter can be NULL only 
			// if celt is one. 
			out IntPtr pceltFetched	);

		/// <summary>
		/// Skips over the specified number of elements in the enumeration sequence.  
		/// </summary>
		/// <param name="celt"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint Skip (
			// Number of item identifiers to skip.
			uint celt );
				
		/// <summary>
		/// Returns to the beginning of the enumeration sequence.  
		/// </summary>
		/// <returns></returns>
		[PreserveSig()]
		uint Reset();
		
		/// <summary>
		/// Creates a new item enumeration object with the same contents and state as the current one. 
		/// </summary>
		/// <param name="ppenum"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint Clone (
			// Address of a pointer to the new enumeration object. The calling 
			// application must eventually free the new object by calling its Release member function. 
			out IEnumIDList ppenum );
	}

	[ComImport(),
	InterfaceType( ComInterfaceType.InterfaceIsIUnknown ),
	GuidAttribute( "000214e4-0000-0000-c000-000000000046" )]
	public interface IContextMenu
	{
		[PreserveSig()]
		int QueryContextMenu (
			IntPtr hMenu,
			uint indexMenu,
			int idCmdFirst,
			int idCmdLast,
			CMF uFlags );

		/// <summary>
		/// Carries out the command associated with a shortcut menu item. 
		/// </summary>
		/// <param name="info"></param>
		/// <returns></returns>
		[PreserveSig()]
		Int32 InvokeCommand (
			ref CMINVOKECOMMANDINFOEX info );
		
		/// <summary>
		/// Retrieves information about a shortcut menu command, including the help string 
		/// and the language-independent, or canonical, name for the command
		/// </summary>
		/// <param name="idcmd"></param>
		/// <param name="uflags"></param>
		/// <param name="reserved"></param>
		/// <param name="commandstring"></param>
		/// <param name="cch"></param>
		/// <returns></returns>
		[PreserveSig()]
		Int32 GetCommandString (
			uint idcmd,
			GCS uflags,
			uint reserved,
			[MarshalAs( UnmanagedType.LPArray )]
            byte[] commandstring,
			int cch );
	}

	[ComImport]
	[InterfaceType( ComInterfaceType.InterfaceIsIUnknown )]
	[Guid( "000214E6-0000-0000-C000-000000000046" )]
	public interface IShellFolder
	{	
		/// <summary>
		/// Translates a file object's or folder's display name into an item
		/// identifier list.
		/// Return value: error code, if any
		/// </summary>
		/// <param name="hwnd"></param>
		/// <param name="pbc"></param>
		/// <param name="pszDisplayName"></param>
		/// <param name="pchEaten"></param>
		/// <param name="ppidl"></param>
		/// <param name="pdwAttributes"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint ParseDisplayName (
			// Optional window handle
			IntPtr hwnd,

			// Optional bind context that controls the parsing operation.
			// This parameter is normally set to NULL.
			IntPtr pbc,

			// Null-terminated UNICODE string with the display name.
			[In(), MarshalAs( UnmanagedType.LPWStr )] 
			string pszDisplayName,

			// Pointer to a ULONG value that receives the number of characters of the 
			// display name that was parsed.
			out uint pchEaten,

			// Pointer to an ITEMIDLIST pointer that receives the item identifier list for 
			// the object.
			out IntPtr ppidl,

			// Optional parameter that can be used to query for file attributes.
			// This can be values from the SFGAO enum.
			ref uint pdwAttributes );
		
		/// <summary>
		/// Allows a client to determine the contents of a folder by creating 
		/// an item identifier enumeration object and returning its IEnumIDList interface.
		/// Return value: error code, if any.
		/// </summary>
		/// <param name="hwnd"></param>
		/// <param name="grfFlags"></param>
		/// <param name="ppenumIDList"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint EnumObjects (
			// If user input is required to perform the enumeration, this window handle 
			// should be used by the enumeration object as the parent window to take user input.
			IntPtr hwnd,

			// Flags indicating which items to include in the enumeration. For a list 
			// of possible values, see the SHCONTF enum.
			SHCONTF grfFlags,

			// Address that receives a pointer to the IEnumIDList interface of the 
			// enumeration object created by this method.
			out IEnumIDList ppenumIDList );
		
		/// <summary>
		/// Retrieves an IShellFolder object for a subfolder.  Return value: error code, if any.
		/// </summary>
		/// <param name="pidl"></param>
		/// <param name="pbc"></param>
		/// <param name="riid"></param>
		/// <param name="ppv"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint BindToObject (
			// Address of an ITEMIDLIST structure (PIDL) that identifies the subfolder.
			IntPtr pidl,

			// Optional address of an IBindCtx interface on a bind context object to be 
			// used during this operation.
			IntPtr pbc,

			// Identifier of the interface to return.
			[In()]
			ref Guid riid,

			// Address that receives the interface pointer.			
			out IntPtr ppv );

		/// <summary>
		/// Requests a pointer to an object's storage interface. Return value: error code, if any.
		/// </summary>
		/// <param name="pidl"></param>
		/// <param name="pbc"></param>
		/// <param name="riid"></param>
		/// <param name="ppv"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint BindToStorage (
			// Address of an ITEMIDLIST structure that identifies the subfolder relative 
			// to its parent folder.
			IntPtr pidl,

			// Optional address of an IBindCtx interface on a bind context object to be 
			// used during this operation.
			IntPtr pbc,

			// Interface identifier (IID) of the requested storage interface.
			[In()]
			ref Guid riid,

			// Address that receives the interface pointer specified by riid.
			[MarshalAs( UnmanagedType.Interface )]
			out object ppv );
		
		/// <summary>
		/// Determines the relative order of two file objects or folders, given 
		/// their item identifier lists. Return value: If this method is 
		/// successful, the CODE field of the HRESULT contains one of the 
		/// following values (the code can be retrieved using the helper function
		/// GetHResultCode): Negative A
		/// negative return value indicates that the first item should precede
		/// the second (pidl1 less than pidl2).
		/// Positive A positive return value indicates that the first item should
		/// follow the second (pidl1 > pidl2).  Zero A return value of zero
		/// indicates that the two items are the same (pidl1 = pidl2). 
		/// </summary>
		/// <param name="lParam"></param>
		/// <param name="pidl1"></param>
		/// <param name="pidl2"></param>
		/// <returns></returns>
		[PreserveSig()]
		int CompareIDs (
			// Value that specifies how the comparison should be performed.  The lower 
			// Sixteen bits of lParam define the sorting rule.  The upper sixteen bits of 
			// lParam are used for flags that modify the sorting rule. values can be from 
			// the SHCIDS enum.
			int lParam,

			// Pointer to the first item's ITEMIDLIST structure.
			IntPtr pidl1,

			// Pointer to the second item's ITEMIDLIST structure.
			IntPtr pidl2 );

		/// <summary>
		/// Requests an object that can be used to obtain information from or interact
		/// with a folder object.  Return value: error code, if any.
		/// </summary>
		/// <param name="hwndOwner"></param>
		/// <param name="riid"></param>
		/// <param name="ppv"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint CreateViewObject (
			// Handle to the owner window.
			IntPtr hwndOwner,

			// Identifier of the requested interface.
			[In()]
			ref Guid riid,

			// Address of a pointer to the requested interface.
			[MarshalAs( UnmanagedType.Interface )]
			out object ppv );
		
		/// <summary>
		/// Retrieves the attributes of one or more file objects or subfolders. 
		/// Return value: error code, if any.
		/// </summary>
		/// <param name="cidl"></param>
		/// <param name="apidl"></param>
		/// <param name="rgfInOut"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint GetAttributesOf (
			// Number of file objects from which to retrieve attributes.
			int cidl,

			// Address of an array of pointers to ITEMIDLIST structures, each of which 
			// uniquely identifies a file object relative to the parent folder.
			[In(), MarshalAs( UnmanagedType.LPArray )] IntPtr[]
			apidl,

			// Address of a single ULONG value that, on entry, contains the attributes 
			// that the caller is requesting. On exit, this value contains the 
			// requested attributes that are common to all of the specified objects.
			// This value can be from the SFGAO enum.
			[MarshalAs( UnmanagedType.LPArray )] SFGAOF[]
			rgfInOut );
				
		/// <summary>
		/// Retrieves an OLE interface that can be used to carry out actions on the 
		/// specified file objects or folders. Return value: error code, if any.
		/// </summary>
		/// <param name="hwndOwner"></param>
		/// <param name="cidl"></param>
		/// <param name="apidl"></param>
		/// <param name="riid"></param>
		/// <param name="rgfReserved"></param>
		/// <param name="ppv"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint GetUIObjectOf (
			// Handle to the owner window that the client should specify if it displays 
			// a dialog box or message box.
			IntPtr hwndOwner,

			// Number of file objects or subfolders specified in the apidl parameter.
			int cidl,

			// Address of an array of pointers to ITEMIDLIST structures, each of which 
			// uniquely identifies a file object or subfolder relative to the parent folder.
			[In(), MarshalAs( UnmanagedType.LPArray )] IntPtr[]
			apidl,

			// Identifier of the COM interface object to return.
			[In()]
			ref Guid riid,

			// Reserved.
			IntPtr rgfReserved,

			// Pointer to the requested interface.
			[MarshalAs( UnmanagedType.Interface )]
			out object ppv );

		/// <summary>
		/// Retrieves the display name for the specified file object or subfolder. 
		/// Return value: error code, if any
		/// </summary>
		/// <param name="pidl"></param>
		/// <param name="uFlags"></param>
		/// <param name="pName"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint GetDisplayNameOf (
			// Address of an ITEMIDLIST structure (PIDL) that uniquely identifies the file 
			// object or subfolder relative to the parent folder.
			IntPtr pidl,

			// Flags used to request the type of display name to return. For a list of possible values.
			SHGNO uFlags,

			// Address of a STRRET structure in which to return the display name.
			out STRRET pName );
		
		/// <summary>
		/// Sets the display name of a file object or subfolder, changing the item
		/// identifier in the process.  Return value: error code, if any.
		/// </summary>
		/// <param name="hwnd"></param>
		/// <param name="pidl"></param>
		/// <param name="pszName"></param>
		/// <param name="uFlags"></param>
		/// <param name="ppidlOut"></param>
		/// <returns></returns>
		[PreserveSig()]
		uint SetNameOf (
			// Handle to the owner window of any dialog or message boxes that the client displays.
			IntPtr hwnd,

			// Pointer to an ITEMIDLIST structure that uniquely identifies the file object
			// or subfolder relative to the parent folder.
			IntPtr pidl,

			// Pointer to a null-terminated string that specifies the new display name.
			[In(), MarshalAs( UnmanagedType.LPWStr )] 
			string pszName,

			// Flags indicating the type of name specified by the lpszName parameter. For a list of possible
			// values, see the description of the SHGNO enum.
			SHGNO uFlags,

			// Address of a pointer to an ITEMIDLIST structure which receives the new ITEMIDLIST.
			out IntPtr ppidlOut );
	}

    // Use Naming Conventions to Indicate Risk (Chapter 8 � Code Access Security in Practice)
    // http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dnnetsec/html/THCMCh08.asp


    /// <summary>
    /// Safe.  This identifies code that poses no possible security threat.  It
    /// is harmless for any code, malicious or otherwise, to call.  An example is
    /// code that returns the current processor tick count.  Safe classes can be
    /// annotated with the SuppressUnmanagedCode attribute which turns off the
    /// code access security permission demand for full trust. 
    /// </summary>
    [System.Security.SuppressUnmanagedCodeSecurityAttribute]
    /*******************************************************************************************/
    internal static class SafeNativeMethods
    {
        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool LockWindowUpdate(int windowHandle);

        [DllImport(Constants.SHELL32, CharSet = CharSet.Auto)]
        internal extern static int ExtractIconEx(
            [MarshalAs(UnmanagedType.LPTStr)]	string lpszFile, int nIconIndex,
            IntPtr[] phIconLarge,
            IntPtr[] phIconSmall,
            int nIcons);

        [DllImport(Constants.USER32, CharSet = CharSet.Auto)]
        public static extern uint MessageBox(IntPtr hWnd, String text, String caption, uint type);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool MessageBeep(uint uType);

        [DllImport(Constants.USER32)]
        internal static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

        [DllImport(Constants.KERNEL32)]
        internal static extern uint GetLongPathName(string lpszShortPath, [Out] StringBuilder lpszLongPath, uint cchBuffer);

        [DllImport(Constants.KERNEL32, CharSet = CharSet.Auto)]
        internal static extern int GetShortPathName(
            [MarshalAs(UnmanagedType.LPTStr)]
            string lpszLongPath,
            [MarshalAs(UnmanagedType.LPTStr)]
            StringBuilder lpszShortPath, 
            uint cchBuffer);

        [DllImport(Constants.USER32, EntryPoint = "FindWindow")]
        internal static extern IntPtr FindWindowWin32(string className, string windowName);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool IsDialogMessage(IntPtr hDlg, IntPtr msg);

        [DllImport(Constants.KERNEL32)]
        internal static extern uint GetCurrentProcessId();

        [DllImport(Constants.KERNEL32)]
        internal static extern IntPtr GetCurrentProcess();

        [DllImport(Constants.USER32)]
        internal static extern IntPtr WindowFromPoint(POINT Point);

        [Obsolete("Use System.IO.DriveInfo.DriveType instead!")]
        [DllImport(Constants.KERNEL32)]
        internal static extern int GetDriveType(string drv);

        [DllImport(Constants.KERNEL32)]
        internal static extern int QueryPerformanceFrequency(out Int64 lpFrequency);

        [DllImport(Constants.KERNEL32)]
        internal static extern int QueryPerformanceCounter(out Int64 lpPerformanceCount);

        [DllImport(Constants.KERNEL32, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern UInt32 QueryDosDevice(string lpDeviceName, [Out] StringBuilder lpTargetPath, UInt32 ucchMax);

        [DllImport(Constants.KERNEL32, CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool DeviceIoControl(SafeFileHandle hDevice,
            UInt32 dwIoControlCode,
            IntPtr lpInBuffer,
            UInt32 nInBufferSize,
            [Out] IntPtr lpOutBuffer,
            UInt32 nOutBufferSize,
            ref UInt32 lpBytesReturned,
            IntPtr lpOverlapped);

        [DllImport(Constants.KERNEL32, SetLastError = true)]        
        public static extern bool VerifyVersionInfo([In] ref OSVersionInfoEx lpVersionInfo,
            uint dwTypeMask, ulong dwlConditionMask);

        [DllImport(Constants.KERNEL32, SetLastError = true)]        
        public static extern ulong VerSetConditionMask(ulong dwlConditionMask,
           TestTypeMask dwTypeBitMask, VersionConditionMask dwConditionMask);

        [DllImport(Constants.KERNEL32, CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool IsWow64Process(IntPtr hProcess, ref bool Wow64Process);

        [DllImport(Constants.USER32)]
        internal static extern short GetKeyState(int nVirtKey);

        [DllImport(Constants.SHLWAPI, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool PathIsNetworkPath([In] String pszPath1);

        [DllImport(Constants.MPR)]
        internal static extern int WNetGetConnection(string locName, StringBuilder remName, ref int length);

        [DllImport(Constants.USER32)]
        internal static extern IntPtr CopyIcon(IntPtr hIcon);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool PostMessage(
            IntPtr hWnd, // handle to destination window
            uint Msg, // message
            IntPtr wParam, // first message parameter
            IntPtr lParam // second message parameter
            );

        [DllImport(Constants.USER32)]
        internal static extern IntPtr SendMessage(IntPtr window, uint Message, IntPtr wParam, IntPtr lParam);

        [DllImport(Constants.USER32)]
        internal static extern int SendMessage(int hWnd, int Msg, int wParam, string lParam);

        [DllImport(Constants.USER32)]
        internal static extern int DestroyIcon(IntPtr hIcon);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool AttachThreadInput(int idAttach, int idAttachTo, [MarshalAs(UnmanagedType.Bool)]bool fAttach);

        [DllImport(Constants.USER32)]
        internal static extern IntPtr GetWindow(IntPtr window, uint cmd);

        [DllImport(Constants.USER32)]
        internal static extern IntPtr GetTopWindow(IntPtr window);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool BringWindowToTop(IntPtr window);

        [DllImport(Constants.USER32)]
        internal static extern int GetClassName(IntPtr window, [In][Out] StringBuilder text, int copyCount);

        [DllImport(Constants.USER32)]
        internal static extern IntPtr FindWindow(string className, string windowName);

        [DllImport(Constants.USER32)]
        internal static extern IntPtr FindWindowEx(IntPtr parent, IntPtr childAfter, string className, string windowName);

        [DllImport(Constants.USER32)]
        internal static extern IntPtr GetParent(IntPtr window);

        [DllImport(Constants.USER32)]
        internal static extern IntPtr GetDesktopWindow();

        [DllImport(Constants.USER32)]
        internal static extern IntPtr GetForegroundWindow();

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool AllowSetForegroundWindow(int processId);

        [DllImport(Constants.USER32)]
        internal static extern IntPtr GetActiveWindow();

        [DllImport(Constants.USER32)]
        internal static extern IntPtr GetLastActivePopup(IntPtr window);

        [DllImport(Constants.USER32)]
        internal static extern int GetWindowText(IntPtr window, [In][Out] StringBuilder text, int copyCount);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool SetWindowText(IntPtr window, [MarshalAs(UnmanagedType.LPTStr)] string text);

        [DllImport(Constants.USER32)]
        internal static extern int GetWindowTextLength(IntPtr window);

        [DllImport(Constants.USER32)]
        internal static extern int SetWindowLong(IntPtr window, int index, int val);

        [DllImport(Constants.USER32)]
        internal static extern int GetWindowLong(IntPtr window, int index);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool EnableWindow(IntPtr window, [MarshalAs(UnmanagedType.Bool)] bool bEnable);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool IsWindowEnabled(IntPtr window);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool IsWindowVisible(IntPtr window);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool EnumChildWindows(IntPtr window, EnumWindowsProc callback, IntPtr i);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool EnumThreadWindows(int threadId, EnumWindowsProc callback, IntPtr i);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool EnumWindows(EnumWindowsProc callback, IntPtr i);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern int GetWindowThreadProcessId(IntPtr window, ref int processId);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetWindowPlacement(IntPtr hwnd, out WINDOWPLACEMENT lpwndpl);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool SetWindowPlacement(IntPtr hwnd, ref WINDOWPLACEMENT lpwndpl);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool IsChild(IntPtr parent, IntPtr window);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool IsIconic(IntPtr window);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool IsZoomed(IntPtr window);

        [DllImport(Constants.USER32)]
        internal static extern int SetForegroundWindow(IntPtr window);

        [DllImport(Constants.USER32)]
        internal static extern IntPtr GetDC(IntPtr hwnd);

        [DllImport(Constants.USER32)]
        internal static extern IntPtr GetWindowDC(IntPtr hwnd);

        [DllImport(Constants.USER32)]
        internal static extern int ReleaseDC(IntPtr hwnd, IntPtr dc);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetWindowRect(IntPtr hwnd, ref Rect rectangle);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetClientRect(IntPtr hwnd, ref Rect rectangle);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetCursorPos(out Point position);

        /// <summary></summary>
        [DllImport(Constants.USER32)]
        internal static extern int SetParent(IntPtr hWndChild, IntPtr hWndParent);

        /// <summary></summary>
        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool ShowWindow(IntPtr hWnd, int cmd);

        /// <summary></summary>
        [DllImport(Constants.USER32)]
        internal static extern IntPtr SetFocus(IntPtr hWnd);

        /// <summary></summary>
        [DllImport(Constants.USER32, CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern IntPtr GetFocus();

        /// <summary></summary>
        [DllImport(Constants.USER32)]
        internal static extern int SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int x, int y, int cx, int cy, uint flags);

        /// <summary></summary>
        [DllImport(Constants.USER32)]
        internal static extern IntPtr GetNextDlgTabItem(IntPtr hDlg, IntPtr hCtrl, [MarshalAs(UnmanagedType.Bool)]bool bPrevious);

        /// <summary></summary>
        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool IsWindow(IntPtr hWnd);

        /// <summary></summary>
        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool MoveWindow(IntPtr hWnd, int x, int y, int w, int h, [MarshalAs(UnmanagedType.Bool)]bool bRepaint);

        /// <summary></summary>
        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool UpdateWindow(IntPtr hWnd);

        /// <summary></summary>
        [DllImport(Constants.USER32)]
        internal static extern IntPtr SetActiveWindow(IntPtr hWnd);

        [DllImport(Constants.USER32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool WinHelp(IntPtr hWndMain, string lpszHelp, uint uCommand, IntPtr dwData);

        [DllImport(Constants.USER32)]
        internal static extern int GetDlgItem(IntPtr hDlg, int nIDDlgItem);

        [DllImport(Constants.USER32)]
        internal static extern bool SetDlgItemText(IntPtr hDlg,
            int nIDDlgItem,
            [MarshalAs(UnmanagedType.LPTStr)]
            string lpString);

        [DllImport(Constants.USER32)]
        internal static extern int CreateWindowEx(uint dwExStyle, string lpClassName, string lpWindowName, uint dwStyle, int x, int y, int nWidth, int nHeight, IntPtr hWndParent, IntPtr hMenu, IntPtr hInstance, IntPtr lpParam);

        [DllImport(Constants.USER32)]
        internal static extern bool ScreenToClient(IntPtr hWnd, ref POINT lpPoint);

        [DllImport(Constants.USER32)]
        internal static extern bool DestroyWindow(IntPtr hwnd);

        [DllImport(Constants.USER32)]
        internal static extern bool CloseWindow(IntPtr hWnd);

        [DllImport(Constants.KERNEL32, SetLastError = true, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetDiskFreeSpaceEx(string lpDirectoryName,
            out ulong lpFreeBytesAvailable,
            out ulong lpTotalNumberOfBytes,
            out ulong lpTotalNumberOfFreeBytes);

        /// <summary>
        /// GetDIBits
        /// </summary>
        [DllImport(Constants.GDI32)]
        internal static extern int GetDIBits(IntPtr hdc, IntPtr hbmp, int uStartScan,
            int cScanLines, IntPtr lpvBits, IntPtr lpbmi, int uUsage);

        /// <summary>
        /// CreateCompatibleDC
        /// </summary>
        [DllImport(Constants.GDI32)]
        internal static extern IntPtr CreateCompatibleDC(
            IntPtr hdc);

        /// <summary>
        /// CreateDC
        /// </summary>
        [DllImport(Constants.GDI32, CharSet = CharSet.Auto)]
        internal static extern IntPtr CreateDC(
            [MarshalAs(UnmanagedType.LPTStr)]string lpDriverName,
            IntPtr lpDeviceName,
            IntPtr lpOutput,
            IntPtr lpInitData);

        /// <summary>
        /// DeleteDC
        /// </summary>
        [DllImport(Constants.GDI32)]
        internal static extern int DeleteDC(
            IntPtr hdc);

        /// <summary>
        /// WNetGetProviderName
        /// </summary>
        /// <param name="dwNetType">network type</param>
        /// <param name="lpProviderName">[out] buffer to receive provider name</param>
        /// <param name="lpBufferSize">size of buffer</param>
        /// <returns>zero for success</returns>
        [DllImport(Constants.MPR, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int WNetGetProviderName(int dwNetType,
            StringBuilder lpProviderName, ref int lpBufferSize);

        /// <summary>
        /// WNetOpenEnum
        /// </summary>
        [DllImport(Constants.MPR, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int WNetOpenEnum(uint dwScope, uint dwType, uint dwUsage,
            [MarshalAs(UnmanagedType.AsAny)][In] Object lpNetResource, out IntPtr lphEnum);

        /// <summary>
        /// WNetEnumResource
        /// </summary>
        [DllImport(Constants.MPR, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int WNetEnumResource(IntPtr hEnum, ref int lpcCount,
            IntPtr lpBuffer, ref int lpBufferSize);

        /// <summary>
        /// WNetCloseEnum
        /// </summary>
        [DllImport(Constants.MPR, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int WNetCloseEnum(IntPtr hEnum);

        [DllImport(Constants.GDI32)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool DeleteObject(IntPtr hObject);

        [DllImport(Constants.WININET)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal extern static bool InternetGetConnectedState(out int connectionDescription, int reservedValue);

        [DllImport(Constants.WINMM, SetLastError = true, CallingConvention = CallingConvention.Winapi)]
        internal static extern bool PlaySound(
            string pszSound,
            IntPtr hMod,
            SoundFlags fdwSound);

        [DllImport(Constants.COMDLG, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern bool GetSaveFileName(ref OPENFILENAME lpofn);

        [DllImport(Constants.COMDLG, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern bool GetOpenFileName(ref OPENFILENAME lpofn);

        [DllImport(Constants.COMDLG, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int CommDlgExtendedError();
    }

    /// <summary>
    /// Native.  This is potentially dangerous unmanaged code, but code that is protected
    /// with a full stack walking demand for the unmanaged code permission.  These are
    /// implicitly made by the interop layer unless they have been suppressed with the
    /// SupressUnmanagedCode attribute. 
    /// </summary>
    internal static class NativeMethods
    {
        [DllImport(Constants.SHELL32)]
        internal static extern System.IntPtr ShellExecute(System.IntPtr hwnd, string lpOperation, string lpFile,
            string lpParameter, string lpDirectory, int nShowCmd);

        [DllImport(Constants.SHELL32)]
        internal static extern IntPtr SHAppBarMessage(int message, ref APPBARDATA TaskbarInfo);

        [DllImport(Constants.USER32)]
        internal extern static IntPtr SetWindowsHookEx(int idHook, [MarshalAs(UnmanagedType.FunctionPtr)]HOOKPROC lpfn, IntPtr hMod, int dwThreadId);

        [DllImport(Constants.USER32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool ExitWindowsEx(ExitWindows uFlags, ShutdownReason dwReason);

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool AdjustTokenPrivileges(IntPtr TokenHandle,
           [MarshalAs(UnmanagedType.Bool)]bool DisableAllPrivileges,
           ref TOKEN_PRIVILEGES NewState,
           int BufferLength,
           ref TOKEN_PRIVILEGES PreviousState,
           ref int ReturnLength);

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool AdjustTokenPrivileges(IntPtr TokenHandle,            
            int DisableAllPrivileges,
            [MarshalAs(UnmanagedType.Struct)]
            ref TOKEN_PRIVILEGES_ARR NewState,
            int BufferLength,
            [MarshalAs(UnmanagedType.Struct)]
            ref TOKEN_PRIVILEGES_ARR PreviousState,
            ref int ReturnLength);

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool AdjustTokenPrivileges(IntPtr TokenHandle,
            int DisableAllPrivileges,
            [MarshalAs(UnmanagedType.Struct)]
            ref TOKEN_PRIVILEGES_ARR NewState,
            int BufferLength,            
            int PreviousState,
            int ReturnLength);

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool OpenProcessToken(IntPtr ProcessHandle,
            UInt32 DesiredAccess, 
            out IntPtr TokenHandle);

        [DllImport(Constants.ADVAPI32, CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool LookupPrivilegeValue(string lpSystemName, 
            string lpName,
            out LUID lpLuid);

        [DllImport(Constants.ADVAPI32, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern bool GetTokenInformation(IntPtr TokenHandle,
            TOKEN_INFORMATION_CLASS TokenInformationClass,
            IntPtr TokenInformation,
            uint TokenInformationLength,
            out uint ReturnLength);

        [DllImport(Constants.ADVAPI32, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int RegCloseKey(int hKey);

        [DllImport(Constants.ADVAPI32, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int RegOpenKeyEx(
            UIntPtr hKey,
            string subKey,
            uint options,
            int sam,
            out UIntPtr phkResult);

        [DllImport(Constants.ADVAPI32, CharSet = CharSet.Auto,SetLastError = true)]
        internal static extern int RegQueryValueEx(
            UIntPtr hKey,
            string lpValueName,
            int lpReserved,
            out uint lpType,
            System.Text.StringBuilder lpData,
            ref uint lpcbData);


        [DllImport(Constants.ADVAPI32, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int RegCreateKey(uint hKey, string lpSubKey, ref IntPtr phkResult);

        [DllImport(Constants.ADVAPI32, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern long RegOverridePredefKey(uint hkey, IntPtr hnewKey);

        [DllImport(Constants.ADVAPI32, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int RegLoadKey(uint hKey, string lpSubKey, string lpFile);

        [DllImport(Constants.ADVAPI32, CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int RegUnLoadKey(uint hKey, string lpSubKey);

        [DllImport(Constants.USER32)]
        internal extern static void UnhookWindowsHookEx(IntPtr hhk);

        [DllImport(Constants.USER32)]
        internal extern static IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport(Constants.KERNEL32)]
        internal static extern IntPtr LoadLibrary(string lpFileName);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool FreeLibrary(IntPtr hModule);

        [DllImport(Constants.KERNEL32)]
        internal static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport(Constants.OLE32)]
        internal static extern void CoFreeUnusedLibraries();

        [DllImport(Constants.SHELL32)]
        internal static extern int FindExecutable(string fileAndPath, string dir, StringBuilder strExe);

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal extern static bool LogonUser(
            String lpszUsername, String lpszDomain, String lpszPassword,
            int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

		[DllImport( Constants.ADVAPI32, SetLastError = true, CharSet = CharSet.Unicode )]
		internal static extern bool CreateProcessWithLogonW(
			String userName,
			String domain,
			String password,
			UInt32 logonFlags,
			String applicationName,
			String commandLine,
			UInt32 creationFlags,
			UInt32 environment,
			String currentDirectory,
			ref StartupInfo startupInfo,
			out ProcessInformation processInformation );
		
        [DllImport(Constants.KERNEL32, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal extern static bool CloseHandle(IntPtr handle);

        [DllImport(Constants.KERNEL32, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        internal static extern int FormatMessage(
            int dwFlags, ref IntPtr lpSource, int dwMessageId,
            int dwLanguageId, ref String lpBuffer, int nSize,
            IntPtr Arguments);

        [DllImport(Constants.KERNEL32, EntryPoint = "GetPrivateProfileString")]
        internal static extern int GetPrivateProfileString(string section,
            string key, string strDefault, StringBuilder returnedString, int size,
            string filePath);

        [DllImport(Constants.KERNEL32)]
        internal static extern int GetPrivateProfileInt(string lpAppName,
            string lpKeyName, int iDefault, string lpFileName);

        [DllImport(Constants.KERNEL32, EntryPoint = "WritePrivateProfileString")]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool WritePrivateProfileString(string lpAppName,
            string lpKeyName, string lpString, string lpFileName);

        [DllImport(Constants.KERNEL32, EntryPoint = "GetPrivateProfileSection")]
        internal static extern int GetPrivateProfileSection(string lpAppName,
            byte[] lpReturnedString, int nSize, string lpFileName);

        [DllImport(Constants.KERNEL32, EntryPoint = "WritePrivateProfileSection")]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool WritePrivateProfileSection(string lpAppName,
            byte[] data, string lpFileName);

        [DllImport(Constants.KERNEL32, EntryPoint = "GetPrivateProfileSectionNames")]
        internal static extern int GetPrivateProfileSectionNames(
            byte[] lpReturnedString, int nSize, string lpFileName);


        [DllImport(Constants.KERNEL32, SetLastError = true)]
        internal static extern IntPtr CreateMailslot(string name,
            uint maxMsgSize, uint readTimeout, IntPtr securityAttrs);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetMailslotInfo(IntPtr hSlot,
            IntPtr maxMsgSize, ref uint nextSize, ref uint msgCount, IntPtr readTimeout);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool ReadFile(IntPtr hSlot,
            [Out] byte[] lpBuffer, uint numBytesToRead,
            IntPtr lpNumBytesRead, [In] ref OVERLAPPED lpOverlapped);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        public static extern SafeFileHandle CreateFile(string lpFileName,
            FileAccess dwDesiredAccess,
            FileShare dwShareMode,
            IntPtr lpSecurityAttributes,
            CreationDisposition dwCreationDisposition,
            uint dwFlagsAndAttributes,
            IntPtr hTemplateFile);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool WriteFile(IntPtr hFile,
            byte[] lpBuffer,
            uint numBytesToWrite,
            out int numBytesWritten,
            [In] ref OVERLAPPED lpOverlapped);


        [DllImport(Constants.USER32, SetLastError = true)]
        internal static extern IntPtr GetProcessWindowStation();

        [DllImport(Constants.USER32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetUserObjectInformation
            (
            IntPtr hObj,
            int nIndex,
            IntPtr pvInfo,
            int nLength,
            out int lpnLengthNeeded
            );

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetOverlappedResult
            (
            IntPtr hFile,
            IntPtr lpOverlapped,
            out uint nNumberOfBytesTransferred,
            [MarshalAs(UnmanagedType.Bool)]Boolean bWait
            );

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        internal static extern IntPtr CreateNamedPipe
            (
            String lpName,                     // pipe name
            uint dwOpenMode,                 // pipe open mode
            uint dwPipeMode,                 // pipe-specific modes
            uint nMaxInstances,              // maximum number of instances
            uint nOutBufferSize,             // output buffer size
            uint nInBufferSize,              // input buffer size
            uint nDefaultTimeOut,            // time-out interval
            IntPtr lpSecurityAttributes
            );

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool ConnectNamedPipe
            (IntPtr hNamedPipe,             // handle to named pipe
            IntPtr lpOverlapped            // overlapped structure
            );

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool WaitNamedPipe
            (String lpNamedPipeName,
            uint nTimeOut);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool FlushFileBuffers(IntPtr hFile);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool DisconnectNamedPipe(IntPtr hNamedPipe);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool SetNamedPipeHandleState
            (IntPtr hNamedPipe,
            ref int lpMode,
            IntPtr lpMaxCollectionCount,
            IntPtr lpCollectDataTimeout);

        // TODO: should be using System.Threading.NativeOverlapped rather than declaring our own

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool CancelIo(IntPtr hFile);

        [DllImport(Constants.KERNEL32, EntryPoint = "RtlZeroMemory", SetLastError = false)]
        internal static extern void ZeroMemory(IntPtr Destination, int Length);

        [DllImport(Constants.NETAPI32, CharSet = CharSet.Unicode)]
        internal extern static int NetServerEnum(string serverName, int level,
                                                out IntPtr bufPtr, int prefMaxLen,
                                                out int entriesRead, out int totalEntries,
                                                long serverType, string domain,
                                                out int resume_handle);

        [DllImport(Constants.NETAPI32, CharSet = CharSet.Unicode)]
        internal extern static int NetApiBufferFree(IntPtr bufPtr);


        // Imports
        [DllImport(Constants.NETAPI32, CharSet = CharSet.Unicode)]
        internal extern static int NetGetDCName(
            string serverName,
            string domainName,
            out IntPtr bufPtr);

        [DllImport(Constants.NETAPI32, CharSet = CharSet.Unicode)]
        internal extern static int NetGetAnyDCName(
            string serverName,
            string domainName,
            out IntPtr bufPtr);

        [DllImport(Constants.NETAPI32, CharSet = CharSet.Unicode)]
        internal extern static int NetUserGetGroups(
            string serverName,
            string userName,
            int level,
            out IntPtr bufPtr,
            int prefMaxLen,
            out int entriesRead,
            out int totalEntries);

        [DllImport(Constants.NETAPI32, CharSet = CharSet.Unicode)]
        internal extern static int NetUserGetLocalGroups(
            string serverName,
            string userName,
            int level,
            int flags,
            out IntPtr bufPtr,
            int prefMaxLen,
            out int entriesRead,
            out int totalEntries);

        // Structures

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool InitializeSecurityDescriptor(
            IntPtr pSecurityDescriptor, // pointer to sd
            int dwRevision);         // revision must be SECURITY_DESCRIPTOR_REVISION (1)

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool SetSecurityDescriptorDacl(
            IntPtr pSecurityDescriptor, // pointer to sd
             [MarshalAs(UnmanagedType.Bool)]bool bDaclPresent,
            IntPtr pDacl,
             [MarshalAs(UnmanagedType.Bool)]bool bDaclDefaulted);

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool IsValidSecurityDescriptor(IntPtr pSecurityDescriptor);

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]        
        internal static extern bool LookupAccountSid(
            [In, MarshalAs(UnmanagedType.LPTStr)]
            string lpSystemName,
            IntPtr lpSid,
            StringBuilder lpName,
            ref int cchName,
            StringBuilder lpReferencedDomainName,
            ref uint cchReferencedDomainName,
            out SidAccount peUse);

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool LookupAccountName(
            [In, MarshalAs(UnmanagedType.LPTStr)]
            string lpSystemName,
            [In, MarshalAs(UnmanagedType.LPTStr)]
            string lpAccountName,
            IntPtr Sid,
            ref uint cbSid,
            StringBuilder ReferencedDomainName,
            ref uint cchReferencedDomainName,
            out SidAccount peUse);

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool ConvertSidToStringSid(
            IntPtr Sid,
            [In, Out, MarshalAs(UnmanagedType.LPTStr)]
            ref string StringSid);

        [DllImport(Constants.ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]        
        internal static extern bool ConvertStringSidToSid(
            string StringSid,
            ref IntPtr Sid);


        [DllImport(Constants.SHELL32)]
        internal static extern IntPtr SHGetFileInfo(string pszPath, int dwFileAttributes, ref SHFILEINFO psfi, int cbFileInfo, uint uFlags);

        [DllImport(Constants.SHELL32, CharSet = CharSet.Auto)]
        internal extern static System.IntPtr SHBrowseForFolder(ref BrowseInfo bi);

        [DllImport(Constants.SHELL32, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal extern static bool SHGetPathFromIDList(IntPtr pidl, [MarshalAs(UnmanagedType.LPTStr)] StringBuilder pszPath);

        [DllImport(Constants.SHELL32)]
        internal extern static int SHGetMalloc([MarshalAs(UnmanagedType.IUnknown)]out object shmalloc);
		
		[DllImport( Constants.SHELL32 )]
		internal static extern int SHGetDesktopFolder(
			ref IShellFolder ppshf );

		[DllImport( Constants.USER32 )]
		internal static extern IntPtr CreatePopupMenu();

		[DllImport( Constants.USER32 )]
		internal static extern int GetMenuItemCount(
			IntPtr hMenu );

		[DllImport( Constants.USER32, ExactSpelling = true, CharSet = CharSet.Auto )]
		internal static extern uint TrackPopupMenuEx(
			IntPtr hMenu,
			TrackPopupMenuFlags flags,
			int x,
			int y,
			IntPtr hWnd,
			IntPtr lptpm );
		
		[DllImport( Constants.USER32 )]
		internal static extern bool DeleteMenu(
			IntPtr hMenu,
			uint uPosition,
			uint uFlags );

		[DllImport( Constants.USER32 )]
		internal static extern int GetMenuString(
			IntPtr hMenu,
			uint uIDItem,
			[Out, MarshalAs( UnmanagedType.LPStr )] StringBuilder lpString,
			int nMaxCount,
			uint uFlag );

		[DllImport( Constants.USER32 )]
		internal static extern uint GetMenuState(
			IntPtr hMenu,
			uint uId,
			uint uFlags );
		
        [DllImport(Constants.KERNEL32, SetLastError = false)]
        internal static extern UInt32 WTSGetActiveConsoleSessionId();

        [DllImport(Constants.WTSAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool WTSWaitSystemEvent(IntPtr hServer, System.UInt32 EventMask, out System.UInt32 pEventFlags);

        [DllImport(Constants.WTSAPI32, SetLastError = true, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool WTSEnumerateSessions(IntPtr hServer, System.UInt32 Reserved, System.UInt32 Version, ref IntPtr ppBuffer, ref System.UInt32 pCount);

        [DllImport(Constants.WTSAPI32, SetLastError = false)]
        internal static extern void WTSFreeMemory(IntPtr memory);

        [DllImport(Constants.USER32, SetLastError = true)]
        internal static extern int GetSystemMetrics(SystemMetric systemMetric);

        [DllImport(Constants.WTSAPI32, SetLastError = true, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool WTSQuerySessionInformation(
            IntPtr hServer,
            UInt32 SessionID,
            WtsInfoClass WTSInfoClass,
            ref IntPtr ppBuffer,
            ref int pBytesReturned);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetVersionEx(ref OSVersionInfoEx osVersionInfo);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetVersion(ref OSVersionInfo osVersionInfo);
	
		/// <summary>Enumerate shares (NT).</summary>
		[DllImport(Constants.NETAPI32, CharSet = CharSet.Unicode)]
		internal static extern int NetShareEnum(
			string lpServerName,
			int dwLevel,
			out IntPtr lpBuffer,
			int dwPrefMaxLen,
			out int entriesRead,
			out int totalEntries,
			ref int hResume );

        [DllImport(Constants.NETAPI32, SetLastError = true, CharSet = CharSet.Auto)]
        internal static extern uint NetLocalGroupEnum(
            IntPtr ServerName,
            uint level,
            ref IntPtr siPtr,
            uint prefmaxlen,
            ref uint entriesread,
            ref uint totalentries,
            IntPtr resumeHandle);

        [DllImport(Constants.NETAPI32, SetLastError = true, CharSet = CharSet.Auto)]
        internal static extern uint NetLocalGroupGetMembers(
            IntPtr ServerName,
            IntPtr GrouprName,
            uint level,
            ref IntPtr siPtr,
            uint prefmaxlen,
            ref uint entriesread,
            ref uint totalentries,
            IntPtr resumeHandle);

		/// <summary>Get a UNC name</summary>
		[DllImport( Constants.MPR, CharSet = CharSet.Auto )]
		internal static extern int WNetGetUniversalName(
			string lpLocalPath,
			int dwInfoLevel,
			ref UNIVERSAL_NAME_INFO lpBuffer,
			ref int lpBufferSize );

		/// <summary>Get a UNC name</summary>
		[DllImport( Constants.MPR, CharSet = CharSet.Auto )]
		internal static extern int WNetGetUniversalName(
			string lpLocalPath,
			int dwInfoLevel,
			IntPtr lpBuffer,
			ref int lpBufferSize );

        [DllImport(Constants.ODBCCP32, SetLastError = true)]
        internal static extern bool SQLConfigDataSource(
            IntPtr hwndParent,
            RequestFlags fRequest, 
            string lpszDriver, 
            string lpszAttributes);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        internal static extern IntPtr CreateFileMapping(IntPtr hFile,
            IntPtr lpFileMappingAttributes, PageProtection flProtect,
            uint dwMaximumSizeHigh,
            uint dwMaximumSizeLow, string lpName);

        [DllImport(Constants.KERNEL32, SetLastError = true)]
        internal static extern IntPtr MapViewOfFile(IntPtr hFileMappingObject, FileMapAccess
            dwDesiredAccess, uint dwFileOffsetHigh, uint dwFileOffsetLow,
            uint dwNumberOfBytesToMap);

        [DllImport("msi.dll", CharSet = CharSet.Auto)]
        public static extern Msi.INSTALLSTATE MsiQueryProductState(String productCode);

        [DllImport("msi.dll", CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.U4)]
        public static extern Int32 MsiGetProductInfo(String productCode, String propertyName, [Out] System.Text.StringBuilder valueBuffer, [MarshalAs(UnmanagedType.U4)] ref Int32 bufferLength);
    }
	
    /// <summary>
    /// Unsafe.  This is potentially dangerous unmanaged code that has the security demand
    /// for the unmanaged code permission declaratively suppressed.  These methods are
    /// potentially dangerous.  Any caller of these methods must do a full security review
    /// to ensure that the usage is safe and protected because no stack walk is performed. 
    /// </summary>
    [System.Security.SuppressUnmanagedCodeSecurityAttribute]
    internal static class UnsafeNativeMethods
    {

    }
}