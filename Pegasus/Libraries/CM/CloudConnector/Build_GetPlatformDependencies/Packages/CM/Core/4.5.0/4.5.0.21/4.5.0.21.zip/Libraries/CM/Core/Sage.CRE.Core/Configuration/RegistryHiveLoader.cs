using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using Sage.PInvoke;

namespace Sage.Configuration
{
    /// <summary>
    /// Defines methods to load and unload certain registry keys.
    /// </summary>
    public static class RegistryLoadUnload
    {
        private static bool m_hasSetup = false;

        /// <summary>
        /// Reset the setup flag. This is the flag that keeps track of whether the process token has been modified.
        /// </summary>
        public static void ResetProcessTokenFlag()
        {
            m_hasSetup = false;
        }

        /// <summary>
        /// Tries to setup permissions to load/unload Registry hives.
        /// </summary>
        /// <returns>Returns true if successfully setup; otherwise, false.</returns>
        public static bool TrySetupLoadUnloadHives()
        {
            try
            {
                return SetupLoadUnloadHives();
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Setup permissions to load/unload Registry hives.
        /// </summary>
        /// <returns>Returns true if successfully setup; otherwise, false.</returns>
        public static bool SetupLoadUnloadHives()
        {
            return SetupProcessToken(false);
        }

        /// <summary>
        /// Setup permissions for the current process token in order to load/unload Registry hives.
        /// </summary>
        /// <param name="forceSetup">Specify whether to force setting up the process token.</param>
        /// <returns>Returns true if successfully setup; otherwise, false.</returns>
        public static bool SetupProcessToken(bool forceSetup)
        {
            // Only execute this if we have not already done so or if force is true.
            if (m_hasSetup == false ||
                forceSetup == true)
            {
                LUID RestoreLuid = new LUID();
                LUID BackupLuid = new LUID();
                IntPtr tokenHandle = IntPtr.Zero;
                uint accessVal = (uint)(SecurityConstants.TOKEN_ADJUST_PRIVILEGES | SecurityConstants.TOKEN_QUERY);

                // Get the token for the current processs.
                if (Macros.Failed(Advapi32.OpenProcessToken(Kernel32.GetCurrentProcess(), accessVal, out tokenHandle)))
                {
                    DumpLastError();
                    return false;
                }

                // Get the Restore privilege.
                if (Macros.Failed(Advapi32.LookupPrivilegeValue(null, SecurityConstants.SE_RESTORE_NAME, out RestoreLuid)))
                {
                    DumpLastError();
                    return false;
                }

                // Get the Backup privilege.
                if (Macros.Failed(Advapi32.LookupPrivilegeValue(null, SecurityConstants.SE_BACKUP_NAME, out BackupLuid)))
                {
                    DumpLastError();
                    return false;
                }

                // Specify the privileges we need for this maneuver.
                TOKEN_PRIVILEGES_ARR newState = new TOKEN_PRIVILEGES_ARR();
                newState.PrivilegeCount = 2;
                newState.Privileges = new LUID_AND_ATTRIBUTES[2];
                newState.Privileges[0] = new LUID_AND_ATTRIBUTES();
                newState.Privileges[0].Attributes = (int)SecurityConstants.SE_PRIVILEGE_ENABLED;
                newState.Privileges[0].Luid = RestoreLuid;
                newState.Privileges[1] = new LUID_AND_ATTRIBUTES();
                newState.Privileges[1].Attributes = (int)SecurityConstants.SE_PRIVILEGE_ENABLED;
                newState.Privileges[1].Luid = BackupLuid;

                // Try to adjust the token.
                if (Macros.Failed(Advapi32.AdjustTokenPrivileges(tokenHandle, 0, ref newState)))
                {
                    DumpLastError();
                    return false;
                }
            }

            m_hasSetup = true;
            return true;
        }

        private static void DumpLastError()
        {
#if DEBUG
            int errorCode = 0;

            if ((errorCode = System.Runtime.InteropServices.Marshal.GetLastWin32Error()) != 0)
            {
                DumpLastError(errorCode);
            }
#endif
        }

        private static void DumpLastError(int errorCode)
        {
            string message = Sage.PInvoke.Kernel32.GetErrorMessage(errorCode);
            Sage.Diagnostics.EventLogger.WriteMessage("Debug", message, Sage.Diagnostics.MessageType.Error);
        }

        /// <summary>
        /// Tries to load the Registry hive for the specified profile.
        /// </summary>
        /// <param name="profile">The profile to load.</param>        
        /// <returns>Returns true if the hive is successfully loaded; otherwise, false.</returns>
        public static bool TryLoadRegistryHive(UserProfile profile)
        {
            try
            {
                return LoadRegistryHive(profile);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Loads the Registry hive for the specified profile.
        /// </summary>
        /// <param name="profile">The profile to load.</param>        
        /// <returns>Returns true if the hive is successfully loaded; otherwise, false.</returns>
        public static bool LoadRegistryHive(UserProfile profile)
        {
            if (!SetupLoadUnloadHives())
                return false;

            string fullPathToHiveFile = System.IO.Path.Combine(profile.FullPathToProfileFolder, "ntuser.dat");

            if (!System.IO.File.Exists(fullPathToHiveFile))
                return false;

            int errorCode = Advapi32.RegLoadKey(RegistryConstants.HKEY_USERS, profile.Sid, fullPathToHiveFile);

            if (!Macros.CheckErrorSuccess(errorCode))
            {
                string errorMsg = Sage.PInvoke.Kernel32.GetErrorMessage(errorCode);
                System.Diagnostics.Debug.WriteLine(errorMsg);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Tries to unload the Registry hive for the specified profile.
        /// </summary>
        /// <param name="profile">The profile to unload.</param>
        /// <returns>Returns true if the hive is successfully unloaded; otherwise, false.</returns>
        public static bool TryUnloadRegistryHive(UserProfile profile)
        {
            try
            {
                return UnloadRegistryHive(profile);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Unloads the Registry hive for the specified profile.
        /// </summary>
        /// <param name="profile">The profile to unload.</param>
        /// <returns>Returns true if the hive is successfully unloaded; otherwise, false.</returns>
        public static bool UnloadRegistryHive(UserProfile profile)
        {
            if (!SetupLoadUnloadHives())
                return false;

            int errorCode = Advapi32.RegUnLoadKey(RegistryConstants.HKEY_USERS, profile.Sid);

            if (!Macros.CheckErrorSuccess(errorCode))
            {
                string errorMsg = Sage.PInvoke.Kernel32.GetErrorMessage(errorCode);
                System.Diagnostics.Debug.WriteLine(errorMsg);
                return false;
            }

            return true;
        }
    }
}
