﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sage.Utilities
{
  static public class Algorithm< T >
  {
    public static T Find( System.Collections.IList vList, Predicate< T > pfn )
    {
      if ( vList != null )
      {
        foreach( T oElement in vList )
        {
          if ( pfn( oElement ))
          {
            return oElement;
          }
        } 
      }
      return default( T );
    }
  }  
}
