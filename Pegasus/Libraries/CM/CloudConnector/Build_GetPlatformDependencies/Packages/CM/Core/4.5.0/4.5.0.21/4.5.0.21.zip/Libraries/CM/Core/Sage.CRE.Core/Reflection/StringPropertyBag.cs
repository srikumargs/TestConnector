using System;
using System.Collections.Specialized;

namespace Sage.Reflection
{
	/// <summary>
	/// Use this for generic string prop/value access
	/// </summary>
	public class StringPropertyBag : IStringProperty
	{
        private StringDictionary _container = new StringDictionary();

        /// <summary>
        /// Delegate to the underlying string colleection
        /// </summary>
        public virtual string this[string propName]
        {
            get
            {
                return _container[propName];
            }
            set
            {
                _container[propName] = value;
            }
        }
	}
}
