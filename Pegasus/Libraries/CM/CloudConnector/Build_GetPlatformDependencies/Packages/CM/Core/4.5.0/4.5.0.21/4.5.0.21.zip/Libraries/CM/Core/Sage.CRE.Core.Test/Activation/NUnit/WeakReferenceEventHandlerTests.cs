#if DEBUG
using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;
using Sage.Diagnostics;

namespace Sage.Activation.NUnit.Tests
{
    /// <summary>
    /// Invokes various members of the TypeBuilder class.
    /// </summary>
    [TestFixture]
    public class WeakReferenceEventHandlerTests
    {
        #region Public methods
        /// <summary>
        /// Tests WeakReferenceEventHandler
        /// </summary>
        [Test]
        public void TestEventHandler()
        {
            EventTarget.EventOccurredCount = 0;

            EventSource source = new EventSource();
            EventTarget target = new EventTarget();

            Assertion.AssertEquals(1, EventTarget.InstanceCount);

            WeakReferenceEventHandler<EventArgs>.Register(source, "EventOccurred", target.OnEventOccurred);
            source.FireEventOccurred();
            Assertion.AssertEquals(1, EventTarget.EventOccurredCount);

            source.FireEventOccurred();
            Assertion.AssertEquals(2, EventTarget.EventOccurredCount);

            target = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            Assertion.AssertEquals(0, EventTarget.InstanceCount);

            source.FireEventOccurred();
            source.FireEventOccurred();
            source.FireEventOccurred();
            source.FireEventOccurred();
            source.FireEventOccurred();
            Assertion.AssertEquals(2, EventTarget.EventOccurredCount);
        }

        /// <summary>
        /// Tests normal event registration (which uses strong reference)
        /// </summary>
        [Test]
        public void TestNormalEventHandler()
        {
            EventTarget.EventOccurredCount = 0;

            EventSource source = new EventSource();
            EventTarget target = new EventTarget();

            Assertion.AssertEquals(1, EventTarget.InstanceCount);

            //WeakReferenceEventHandler<EventArgs>.Register(source, "EventOccurred", target.OnEventOccurred);
            source.EventOccurred += new EventHandler<EventArgs>(target.OnEventOccurred);

            source.FireEventOccurred();
            Assertion.AssertEquals(1, EventTarget.EventOccurredCount);

            source.FireEventOccurred();
            Assertion.AssertEquals(2, EventTarget.EventOccurredCount);

            target = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            Assertion.AssertEquals(1, EventTarget.InstanceCount);

            source.FireEventOccurred();
            source.FireEventOccurred();
            source.FireEventOccurred();
            source.FireEventOccurred();
            source.FireEventOccurred();
            Assertion.AssertEquals(7, EventTarget.EventOccurredCount);

            source = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            Assertion.AssertEquals(0, EventTarget.InstanceCount);
        }

        /// <summary>
        /// Tests the null source.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNullSource()
        {
            EventSource source = new EventSource();

            using(EventTarget target = new EventTarget())
            {
                WeakReferenceEventHandler<EventArgs>.Register(null, "EventOccurred", target.OnEventOccurred);
            }
        }

        /// <summary>
        /// Tests the name of the null event.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNullEventName()
        {
            EventSource source = new EventSource();

            using(EventTarget target = new EventTarget())
            {
                WeakReferenceEventHandler<EventArgs>.Register(source, null, target.OnEventOccurred);
            }
        }

        /// <summary>
        /// Tests the name of the invalid event.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestInvalidEventName()
        {
            EventSource source = new EventSource();

            using(EventTarget target = new EventTarget())
            {
                WeakReferenceEventHandler<EventArgs>.Register(source, "Blah", target.OnEventOccurred);
            }
        }

        /// <summary>
        /// Tests the null event handler.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNullEventHandler()
        {
            EventSource source = new EventSource();

            using(EventTarget target = new EventTarget())
            {
                WeakReferenceEventHandler<EventArgs>.Register(source, "EventOccurred", null);
            }
        }
        #endregion
    }

    internal class EventSource
    {
        public event EventHandler<EventArgs> EventOccurred;
        public event EventHandler<EventArgs> GenericEventOccurred;

        public void FireEventOccurred()
        {
            if(EventOccurred != null)
            {
                EventOccurred(this, new EventArgs());
            }

            if(GenericEventOccurred != null)
            {
                GenericEventOccurred(this, new EventArgs());
            }
        }
    }

    internal class EventTarget : IDisposable
    {
        public EventTarget()
        {
            _instanceCount++;
        }

        ~EventTarget()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if(!_disposed)
            {
                _instanceCount--;

                _disposed = true;
            }
        }

        public static Int32 InstanceCount
        {
            get
            {
                return _instanceCount;
            }
            set
            {
                _instanceCount = value;
            }
        }

        public static Int32 EventOccurredCount
        {
            get
            {
                return _eventOccurredCount;
            }
            set
            {
                _eventOccurredCount = value;
            }
        }

        public void OnEventOccurred(object sender, EventArgs args)
        {
            _eventOccurredCount++;
        }

        private static Int32 _instanceCount;
        private static Int32 _eventOccurredCount;
        private bool _disposed;
    }
}
#endif