using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace Sage.Net
{
    /// <summary>
    /// Summary description for ServerEnumeration.
    /// </summary>
    internal class ServerEnumeration
    {
        public ServerEnumeration()
        {
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="domain">Name of the network domain from which to get 
        /// the list of servers</param>
        /// <param name="alServers">an array list that will be filled with Server 
        /// objects.</param>
        /// <returns>false if alServers is null.
        /// Will throw a System.ComponentModel.Win32Exception if an error is returned
        /// from one of the underlying Win32 WNet function calls.</returns>
        static public bool PopulateList(string domain, ArrayList alServers)
        {
            // 4/13/05 - #506112 - Changed this function to use the NetServerEnum api call
            //  instead of the WNetEnumResource api call.  Under Terminal Server on Windows
            // 2003 Server the WNet function would not return any servers; running the test 
            // directly on the Windows 2003 box (instead of remotely) it works correctly.
            // After researching the issue and not finding a resolution, the underlying 
            // implementation was changed to use the Net* api call.
            // The Net* api call has its own issues, as it doesn't seem to work with 
            // passing in another domain; it works fine when passing null as the server, 
            // which means to use the default domain, but to get servers on a different
            // domain it seems to require the primary domain controller (PDC) of the domain 
            // (in "\\machineName" format).  Because of this requirement, support for getting 
            // server names on a different domain is no longer supported.  It may be possible
            // to find the PDC of a domain, but I didn't happen across it in my limited searching.

            // 5/3/05 After consultation with Microsoft support it was determined that we need
            // to pass the network provider name to the NETRESOURCE structure.  This is only 
            // required for Terminal Services under Windows 2003 Server (but doesn't cause
            // any harm under other platforms).  Therefore we are adding the network provider
            // name as instructed, and going back to the original implementation that uses the
            // WNetEnumResources api.

            // For the NetServerEnum method use this:
            //return NetApi.ServerEnum(domain, alServers);

            // For the WnetEnumResources method use this:
            return mpr.EnumServers(domain, alServers);
        }

    }
}
