using System;

namespace Sage.Configuration
{
	/// <summary>
	/// Summary description for IPathResolver.
	/// </summary>
	public interface IPathResolver
	{
        /// <summary>
        /// Determine if a particular path is registered
        /// </summary>
        /// <param name="key">A key for the path</param>
        /// <returns>True if the path is registered, false if not</returns>
       bool IsRegistered(string key);
        

        /// <summary>
        /// Retrieve a registered path
        /// </summary>
        /// <param name="key">Key of a registered path</param>
        /// <returns>The registered path</returns>
        string GetRegisteredPath(string key);

        /// <summary>
        /// Resolves an URL that uses one of the encoded paths protocol to a file system reference.
        /// No guarantees are provided that the resolved path is valid in the file system.
        /// </summary>
        /// <remarks>
        /// A Paths URL has the form Protocol://context/path where "Protocol" is either registeredpath, tspath, specialpath, or registrypath and path is a path relative to one
        /// of the context folders and context is a key to a specific folder. 
        /// </remarks>
        /// <param name="url">Path to resolve.</param>
        /// <returns>A resolved path if a resolveable URL or the path unchanged otherwise</returns>
        string ResolveUrl( string url );

        /// <summary>
        /// Generate a registered path string from a URL
        /// </summary>
        /// <param name="url">A URL to transform</param>
        /// <returns>The URL reformated using the registered path syntax if applicable or else a the original URL is returned</returns>
        string RegisteredPathFromUrl( string url );
	}
}
