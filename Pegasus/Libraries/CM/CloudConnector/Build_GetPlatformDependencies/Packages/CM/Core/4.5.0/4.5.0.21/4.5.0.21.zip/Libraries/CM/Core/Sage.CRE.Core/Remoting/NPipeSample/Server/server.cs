using System;
using System.Collections;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using Sage.Remoting;

using TestLibrary;

public class Driver
{
//    private static TestObject LocalSetup()
//    {
//        TestObject test = new TestObject();
//        ChannelServices.RegisterChannel(new PipeChannel("MyPipe"));
//        RemotingServices.Marshal(test, "TestObject.rem");
//        return test;
//    }

    private static TestObject RemoteSetup()
    {
        TestObject test = new TestObject();
        
        Hashtable props = new Hashtable();
        props.Add("machine", Environment.MachineName);
        props.Add("pipe", "MyPipe");
        ChannelRegistrar server = new ChannelRegistrar();
        server.RegisterServer(ChannelType.NamedPipe, props);

        /*
        Hashtable dict = new Hashtable();
        dict.Add("machine", "PDLABCLIENT4");
        dict.Add("pipe", "Auto");
        ChannelRegistrar client = new ChannelRegistrar();
        client.RegisterClient(ChannelType.NamedPipe, dict);
        */

        // Same machine
        ChannelRegistrar client = new ChannelRegistrar();
        client.RegisterClient(ChannelType.NamedPipe);

        RemotingServices.Marshal(test, "TestObject.rem");
        return test;
    }

    public static void Main(string[] args)
    {

        TestObject test = null;
        try
        {
            //test = LocalSetup();
            test = RemoteSetup();


            string[] urls = ChannelServices.GetUrlsForObject(test);
            foreach (string s in urls)
            {
                Console.WriteLine("Url: {0}", s);
            }

            IChannel[] chans = ChannelServices.RegisteredChannels;
            foreach (IChannel chan in chans)
            {
                IChannelReceiver rec = chan as IChannelReceiver;
                if (rec != null)
                {
                    IChannelDataStore cds = (IChannelDataStore) rec.ChannelData;
                    if (cds != null)
                    {
                        foreach (string s in cds.ChannelUris)
                        {
                            Console.WriteLine("Uri: {0}", s);
                        }
                    }
                }
            }
        }
        catch(Exception e)
        {
            Console.WriteLine("Exception = " + e);
        }
		System.Console.Write("Hit <enter> to exit server...");
		System.Console.ReadLine();
        RemotingServices.Disconnect(test);
    }
}
