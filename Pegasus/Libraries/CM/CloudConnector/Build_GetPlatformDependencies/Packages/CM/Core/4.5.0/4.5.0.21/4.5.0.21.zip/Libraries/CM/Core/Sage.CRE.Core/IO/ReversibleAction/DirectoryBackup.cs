using System;
using System.Collections.Generic;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Backups one or more directories using the ReversibleAction pattern.
    /// The construction of a BackupDirectory object backups the specified directory.
    /// If the object is disposed without calling the Commit() method, then the original state of the directory is restored.
    /// 
    /// Typical usage:
    /// 
    /// using (DirectoryBackup dirBackup = new DirectoryBackup(@"C:\sourceDirectory"))
    ///     {
    ///         dirBackup.Forward();
    ///         
    ///         // do some code that might throw. If this code throws, we need to restore the directory
    /// 
    ///         dirBackup.Commit();
    ///     }
    /// </summary>
    public class DirectoryBackup : ReversibleActionBase
    {
        /// <summary>
        /// Backs up a single directory.
        /// </summary>
        /// <param name="directory">The directory that will be backed up.</param>
        public DirectoryBackup(string directory)
        {
            string destPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), _actionID);
            _directoriesToByBackedUp.Add(directory,destPath);

        }

        /// <summary>
        /// Backs up a set of directories.
        /// </summary>
        /// <param name="directories">A list of directories that will be backed up.</param>
        public DirectoryBackup(System.Collections.ObjectModel.ReadOnlyCollection<string> directories)
        {
            foreach (string dir in directories)
            {
                string destPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), _actionID);
                destPath = System.IO.Path.Combine(destPath, dir);
                _directoriesToByBackedUp.Add(dir, destPath);
            }

        }


        #region Protected methods
        /// <summary>
        /// Backs up the previously specified directories.
        /// </summary>
        public override void Forward()
        {
            base.Forward();
            _directoriesBackedUp.Clear();
            using (DirectoryCopy dirCopy = new DirectoryCopy(_directoriesToByBackedUp, false, false, true, true, true))
            {
                dirCopy.Forward();
                dirCopy.Commit();

                _directoriesBackedUp = _directoriesToByBackedUp;
            }
        }

        /// <summary>
        /// Deletes the back ups of the original directory.
        /// </summary>
        public override void Commit()
        {
            base.Commit();
            foreach (KeyValuePair<string, string> kvp in _directoriesBackedUp)
            {
                string dest = kvp.Value;
                if (System.IO.Directory.Exists(dest)) System.IO.Directory.Delete(dest, true);
            }
        }

        /// <summary>
        /// Restores the original state of the directory that was backed up.
        /// </summary>
        public override void Reverse()
        {
            base.Reverse();
            foreach (KeyValuePair<string, string> kvp in _directoriesBackedUp)
            {
                string src = System.IO.Path.Combine(kvp.Value,System.IO.Path.GetFileName(kvp.Key));
                string dest = System.IO.Path.GetDirectoryName(kvp.Key);

                string oldSrc = kvp.Key;
                string oldDest = kvp.Value;

                if (System.IO.Directory.Exists(oldSrc)) System.IO.Directory.Delete(oldSrc, true);
                using (DirectoryCopy dirCopy = new DirectoryCopy(src, dest, false, false, true, true, true))
                {
                    dirCopy.Forward();
                    dirCopy.Commit();
                }
                if (System.IO.Directory.Exists(oldDest)) System.IO.Directory.Delete(oldDest, true);

            }
            _directoriesBackedUp.Clear();
        }
        #endregion

        #region Private members
        private Dictionary<string,string> _directoriesToByBackedUp = new Dictionary<string,string>();
        private Dictionary<string, string> _directoriesBackedUp = new Dictionary<string, string>();
        private string _actionID = System.DateTime.Now.ToFileTimeUtc().ToString(System.Globalization.CultureInfo.InvariantCulture);
        #endregion
    }
}
