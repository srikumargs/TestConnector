#if DEBUG
using System;
using System.Runtime.InteropServices;
using NUnit.Framework;
using System.Xml;
using System.Xml.XPath;
using System.Text;

using Sage.Xml;


namespace Sage.Xml.NUnit
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class Test_XmlElementFinder
    {
        /// <summary>
        /// </summary>
        public Test_XmlElementFinder() {}

        /// <summary>
        /// 
        /// </summary>
        /// 
        [Test]
        public void TestElementFinder()
        {
            XmlElementFinder x = new XmlElementFinder("");
            string s = x.OuterText("");
            Assert.AreEqual(s, "");
            s =  x.InnerText("");
            Assert.AreEqual(s, "");

            s = x.OuterText("Foozle");
            Assert.AreEqual(s, "");
            s =  x.InnerText("Foozle");
            Assert.AreEqual(s, "");

            x.InputXml = "<Foo></Foo>";
            s = x.OuterText("Foozle");
            Assert.AreEqual(s, "");
            s =  x.InnerText("Foozle");
            Assert.AreEqual(s, "");

            x.InputXml = "<Foozle></Foozle>";
            s = x.OuterText("Foozle");
            Assert.AreEqual(s, "<Foozle></Foozle>");
            s =  x.InnerText("Foozle");
            Assert.AreEqual(s, "");

            x.InputXml = "<Foozle>Here is a bunch of text</Foozle>";
            s = x.OuterText("Foozle");
            Assert.AreEqual(s, "<Foozle>Here is a bunch of text</Foozle>");
            s =  x.InnerText("Foozle");
            Assert.AreEqual(s, "Here is a bunch of text");

            x.InputXml = "<Bar><Foozle>Here is a bunch of text</Foozle></Bar>";
            s = x.OuterText("Foozle");
            Assert.AreEqual(s, "<Foozle>Here is a bunch of text</Foozle>");
            s =  x.InnerText("Foozle");
            Assert.AreEqual(s, "Here is a bunch of text");

            x.InputXml = "<Foozle>Here is a bunch of text</Foozle>";
            Assert.IsTrue(x.ElementExists("Foozle"));
            Assert.AreEqual(x.ElementExists("Baz"), false);

            x.InputXml = "<Foozle MyAttrib='blah' />";
            Assert.IsTrue(x.ElementExists("Foozle"));
            Assert.AreEqual(x.ElementExists("Baz"), false);

            Assert.IsTrue(XmlElementFinder.ElementExists("<Foozle MyAttrib='blah' />", "Foozle"));
        }
    }
}

#endif // DEBUG