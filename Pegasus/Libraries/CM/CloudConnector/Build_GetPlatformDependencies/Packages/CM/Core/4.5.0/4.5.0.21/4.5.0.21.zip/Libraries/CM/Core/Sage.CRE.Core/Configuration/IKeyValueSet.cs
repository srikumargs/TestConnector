using System;
using System.Runtime.InteropServices;

namespace Sage.Configuration
{
	/// <summary>
	/// Interface for accessing a key/value set
	/// </summary>
    [ComVisible(false)]
    public interface IKeyValueSet
	{
        /// <summary>
        /// Get/Set the key name
        /// </summary>
        [ DispId( 1 ) ]
        string Key { get; set; }
        
        /// <summary>
        /// Get/set the key value
        /// </summary>
        [ DispId( 2 ) ]
        string Value { get; set; }
	}
}
