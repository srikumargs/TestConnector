using System;
using System.Collections;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Runtime.Remoting.Activation;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

using Sage.IO;
using Sage.Remoting;
using Sage.Xml;


namespace Sage.Activation
{
    /// <summary>
    /// class used to encapsulate CONFIG file access for factory types.
    /// </summary>
    [ ComVisible( false ) ]
    public class TypeFactory 
    {
        private TypeReader    _typeReader;
        private StringBuilder _baseBuilder;

        private const string  _baseLookupExpr       = "//TypeInstance[@TypeLookup='{0}']";
        private const string  _baseExpr             = "//TypeInstance";
        private const string  _assembly             = "/@Assembly";
        private const string  _qualifiedTypeName    = "/@QualifiedTypeName";
        private const string  _location             = "/@Location";
        private const string  _uri                  = "/@URI";
        private const string  _execEnv              = "/@ExecutionEnvironment";
        private const string  _codebase             = "/@Codebase";


        /// <summary>
        /// Use the template pattern to get a TypeReader instantiation
        /// </summary>
        public TypeFactory(TypeReader typeReader)
        {
            _typeReader = typeReader;
        }

        #region static methods

        /// <summary>
        /// Create a managed component and return
        /// </summary>
        /// <param name="assembly"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static object CreateDotNetComponent(string assembly, string type)
        {
            return CreateDotNetComponent( assembly, type, string.Empty, null );
        }

        /// <summary>
        /// Create a managed component and return
        /// </summary>
        /// <param name="assembly"></param>
        /// <param name="type"></param>
        /// <param name="ctorParameters">An array of parameters that should be passed to the constructor</param>
        /// <returns></returns>
        public static object CreateDotNetComponent(string assembly, string type, object[] ctorParameters)
        {
            return CreateDotNetComponent(assembly, type, string.Empty, ctorParameters);
        }

        /// <summary>
        /// Create and return a managed component
        /// </summary>
        /// <param name="assembly">The component's assembly</param>
        /// <param name="type">The component's type</param>
        /// <param name="codebase">The location of the component's assembly</param>
        /// <returns>The requested object</returns>
        public static object CreateDotNetComponent( string assembly, string type, string codebase )
        {
            return CreateDotNetComponent(assembly, type, codebase, null);
        }

        /// <summary>
        /// Create and return a managed component
        /// </summary>
        /// <param name="assembly">The component's assembly</param>
        /// <param name="type">The component's type</param>
        /// <param name="codebase">The location of the component's assembly</param>
        /// <param name="ctorParameters">An array of parameters that should be passed to the constructor</param>
        /// <returns>The requested object</returns>
        public static object CreateDotNetComponent(string assembly, string type, string codebase, object[] ctorParameters)
        {
            TypeFactory ti = new TypeFactory(new TypeReader(type, assembly, codebase));
            object retval = null;
            if (ctorParameters != null && ctorParameters.Length > 0)
            {
                retval = ti.GetLocalObject(ctorParameters);
            }
            else 
            {
                retval = ti.GetLocalObject(ctorParameters);
            }
            return retval;
        }

        /// <summary>
        /// Create a COM componment from a ProgID
        /// </summary>
        /// <param name="progId"></param>
        /// <returns></returns>
		public static object CreateCOMComponent(string progId)
		{
			TypeFactory ti = new TypeFactory(new TypeReader(progId));
			return ti.GetLocalObject();
		}

        /// <summary>
        /// Create either a managed or COM object
        /// </summary>
        /// <param name="objectInfoNode">An Xml node containing 
        /// info about the object to create</param>
        /// <returns>The object created</returns>
        public static object CreateObject(XmlNode objectInfoNode)
        {
			TypeFactory ti = new TypeFactory(TypeReaderFactory.Create(objectInfoNode));
			return ti.GetObject();
        }

        /// <summary>
        /// Create either a managed or COM object
        /// </summary>
        /// <param name="iterator">An XPath iterator with 'Current' positioned to an element with creation information</param>
        /// <returns>The object created</returns>
        public static object CreateObject(XPathNodeIterator iterator)
        {
			TypeFactory ti = new TypeFactory(TypeReaderFactory.Create(iterator));
			return ti.GetObject();
		}
        #endregion // statics


        #region Local Object Instantiation

        /// <summary>
        /// Object is late-bound created locally. Creates the
        /// first type instance found.
        /// </summary>
        /// <returns>The created object</returns>
        public object GetLocalObject()
        {
            return GetLocalObject(String.Empty);
        }
        
        /// <summary>
        /// Object is late-bound created locally
        /// </summary>
        /// <param name="typeLookup">a look-up string in the config file</param>
        /// <returns></returns>
        public object GetLocalObject(string typeLookup)
        {
            object obj = null;
            string typeString = string.Empty;
            try
            {
                buildBaseString(typeLookup);
                
                if (IsManagedType() == true)
                {
                    Assembly componentAssembly = loadAssembly();
                    typeString = getQualifiedTypeNameString();
                    obj = componentAssembly.CreateInstance(typeString);
                }
                else // try COM
                {
                    typeString = getQualifiedTypeNameString();
                    Type t = Type.GetTypeFromProgID(typeString);
                    obj = Activator.CreateInstance(t);
                }
            }
            catch (Exception e)
            {
                throwTypeFactoryException(typeLookup, typeString, e);
            }
            throwIfNullObject(typeLookup, typeString, obj);
            _baseBuilder = null;
            return obj;
        }

        /// <summary>
        /// Object is late-bound created locally
        /// </summary>
        /// <param name="ctorParams">a look-up string in the config file</param>
        /// <returns></returns>
        public object GetLocalObject(object[] ctorParams)
        {
            return GetLocalObject(String.Empty, ctorParams);
        }
        
        /// <summary>
        /// Object is late-bound created locally
        /// </summary>
        /// <param name="typeLookup">a look-up string in the config file</param>
        /// <param name="ctorParams">a look-up string in the config file</param>
        /// <returns></returns>
        public object GetLocalObject(string typeLookup, object[] ctorParams)
        {
            object obj = null;
            string typeString = string.Empty;
            try
            {
                buildBaseString(typeLookup);

                Assembly componentAssembly = loadAssembly();
                typeString = getQualifiedTypeNameString();
                obj = componentAssembly.CreateInstance(
                    typeString, true, BindingFlags.CreateInstance, null, ctorParams, null, null);
            }
            catch (Exception e)
            {
                throwTypeFactoryException(typeLookup, typeString, e);
            }
            throwIfNullObject(typeLookup, typeString, obj);
            _baseBuilder = null;
            return obj;
        }

        #endregion // local objects
        
        #region Remote Object Instatiation        
        /// <summary>
        /// Object is late-bound created remotely
        /// </summary>
        /// <returns>The first type instance object</returns>
        public object GetRemoteObject()
        {
            return GetRemoteObject(String.Empty, String.Empty);
        }

        /// <summary>
        /// Object is late-bound created remotely
        /// </summary>
        /// <param name="typeLookup"></param>
        /// <returns></returns>
        public object GetRemoteObject(string typeLookup)
        {
            return GetRemoteObject(typeLookup, String.Empty);
        }

        /// <summary>
        /// Object is late-bound created remotely
        /// </summary>
        /// <param name="ctorParams"></param>
        /// <returns>The first type instance object</returns>
        public object GetRemoteObject(object[] ctorParams)
        {
            return GetRemoteObject(String.Empty, String.Empty, ctorParams);
        }
        
        /// <summary>
        /// Object is late-bound created remotely
        /// </summary>
        /// <param name="typeLookup"></param>
        /// <param name="ctorParams"></param>
        /// <returns></returns>
        public object GetRemoteObject(string typeLookup, object[] ctorParams)
        {
            return GetRemoteObject(typeLookup, String.Empty, ctorParams);
        }


        /// <summary>
        /// Object is late-bound created remotely
        /// </summary>
        /// <param name="typeLookup"></param>
        /// <param name="server"></param>
        /// <returns></returns>
        public object GetRemoteObject(string typeLookup, string server)
        {
            object obj = null;
            string typeString = string.Empty;
            try
            {
                buildBaseString(typeLookup);

                Assembly componentAssembly = loadAssembly();
                string uri = getUriString(server);
                ChannelRegistrar reg = new ChannelRegistrar();
                reg.RegisterClient(uri);
                typeString = getQualifiedTypeNameString();
                Type remoteType = componentAssembly.GetType(typeString);
                obj = Activator.GetObject(remoteType, uri);
            }
            catch (Exception e)
            {
                throwTypeFactoryException(typeLookup, typeString, e);
            }
            throwIfNullObject(typeLookup, typeString, obj);
            _baseBuilder = null;
            return obj;
        }
        
        /// <summary>
        /// Object is late-bound created remotely
        /// </summary>
        /// <param name="typeLookup"></param>
        /// <param name="server"></param>
        /// <param name="ctorParams"></param>
        /// <returns></returns>
        public object GetRemoteObject(string typeLookup, string server, object[] ctorParams)
        {
            object obj = null;
            string typeString = string.Empty;
            try
            {
                buildBaseString(typeLookup);

                Assembly componentAssembly = loadAssembly();

                string uri = getUriString(server);
                ChannelRegistrar reg = new ChannelRegistrar();
                reg.RegisterClient(uri);
                
                typeString = getQualifiedTypeNameString();
                Type remoteType = componentAssembly.GetType(typeString);
                object[] activationAttributes = { new UrlAttribute(uri) };
                obj = Activator.CreateInstance(remoteType, ctorParams, activationAttributes);
            }
            catch (Exception e)
            {
                throwTypeFactoryException(typeLookup, typeString, e);
            }
            throwIfNullObject(typeLookup, typeString, obj);
            _baseBuilder = null;
            return obj;
        }

        #endregion // Remote Objects
        
        #region Local or Remote
        /// <summary>
        /// Gets the first type instance object
        /// </summary>
        /// <returns>The first type instance object</returns>
        public object GetObject()
        {
            return GetObject(String.Empty);
        }

        
        /// <summary>
        /// Get appropriate type information from the XML config file to create a 
        /// local or remote object using reflection to late bind.
        /// </summary>
        /// <param name="typeLookup">the non-qualified type or class name</param>
        /// <returns>an object instance</returns>
        public object GetObject(string typeLookup)
        {
            buildBaseString(typeLookup);
            
            object obj = null;

            if (getLocationString() == "remote")
            {
                obj = GetRemoteObject(typeLookup, String.Empty);
            }
            else 
            {
                obj = GetLocalObject(typeLookup);
            }
            return obj;
        }

        /// <summary>
        /// Get first type information from the XML config file to create a 
        /// local or remote object using reflection to late bind.
        /// </summary>
        /// <param name="ctorParams"></param>
        /// <returns>a late bound object</returns>
        public object GetObject(object[] ctorParams)
        {
            return GetObject(String.Empty, ctorParams);
        }

        
        /// <summary>
        /// Get appropriate type information from the XML config file to create a 
        /// local or remote object using reflection to late bind.
        /// </summary>
        /// <param name="typeLookup">the non-qualified type or class name</param>
        /// <param name="ctorParams"></param>
        /// <returns>an object instance</returns>
        public object GetObject(string typeLookup, object[] ctorParams)
        {
            buildBaseString(typeLookup);
            object obj = null;
            
            if (getLocationString() == "remote")
            {
                obj = GetRemoteObject(typeLookup, String.Empty, ctorParams);
            }
            else
            {
                obj = GetLocalObject(typeLookup, ctorParams);
            }
            return obj;
        }

        #endregion // local or remote

        #region private helpers

        /// <summary>
        /// Builds the base xpath query string that is re-used per object instantiation
        /// </summary>
        /// <param name="typeLookup"></param>
        private void buildBaseString(string typeLookup)
        {
            if (string.IsNullOrEmpty(typeLookup))
            {
                buildBaseString();
            }
            else
            {
                _baseBuilder = new StringBuilder();
                _baseBuilder.AppendFormat(_baseLookupExpr, typeLookup);
            }
        }

        /// <summary>
        /// Used when the typelookup is null
        /// </summary>
        private void buildBaseString()
        {
            if (_baseBuilder == null)
            {
                _baseBuilder = new StringBuilder();
                _baseBuilder.Append(_baseExpr);
            }
        }

        /// <summary>
        /// Get the namespace + type attribute from TypeReader
        /// </summary>
        /// <returns></returns>
        private string getQualifiedTypeNameString()
        {
            return _typeReader.SelectSingleNodeValue(_baseBuilder.ToString() + _qualifiedTypeName, true);
        }

        /// <summary>
        /// Get the location attribute from TypeReader
        /// </summary>
        /// <returns></returns>
        private string getLocationString()
        {
            return _typeReader.SelectSingleNodeValue(_baseBuilder.ToString() + _location, false);
        }

        /// <summary>
        /// Attempt to load the assembly using the type lookup
        /// </summary>
        /// <returns></returns>
        private Assembly loadAssembly()
        {
            //
            //  Get the name of the assembly from the type reader
            //
            string assemStr    = _typeReader.SelectSingleNodeValue(_baseBuilder.ToString() + _assembly, true);
            string codebaseKey = _typeReader.SelectSingleNodeValue(_baseBuilder.ToString() + _codebase, false);

            return AssemblyLoader.Load(assemStr, codebaseKey);
        }



        /// <summary>
        /// use the TypeReader to determine whether managed or unmanaged
        /// </summary>
        /// <returns></returns>
        private string getExecEnvString()
        {
            return _typeReader.SelectSingleNodeValue(_baseBuilder.ToString() + _execEnv, false);
        }
        
        /// <summary>
        /// get the uri string from the TypeReader
        /// </summary>
        /// <param name="server"></param>
        /// <returns></returns>
        private string getUriString(string server)
        {
            string uri = _typeReader.SelectSingleNodeValue(_baseBuilder.ToString() + _uri, false);
            if (!string.IsNullOrEmpty(server))
            {
                if (string.IsNullOrEmpty(uri) || uri == "none")
                {
                    throw new TypeFactoryException(new Exception(Strings.TryingToAssignServerNameToInvalidUri));
                }
                uri = Regex.Replace(uri, "//.*:", "//" + server + ":");
            }
            if (string.IsNullOrEmpty(uri) || uri == "none")
            {
                throw new TypeFactoryException(new Exception(Strings.URIIsEmptyStringOrNone));
            }
            return uri;
        }

        /// <summary>
        /// Is this type managed?
        /// </summary>
        /// <returns></returns>
        private bool IsManagedType()
        {
            return (string.IsNullOrEmpty(getExecEnvString()) || getExecEnvString() == "managed");
        }

        /// <summary>
        /// Helper to throw the appropriate exception based on whether a typelookup was passed in
        /// </summary>
        /// <param name="typeLookup"></param>
        /// <param name="typeString"></param>
        /// <param name="e"></param>
        private static void throwTypeFactoryException(string typeLookup, string typeString, Exception e)
        {
            if (typeLookup.Length == 0)
            {
                throw new TypeFactoryException(typeString, e);
            }
            else
            {
                throw new TypeFactoryException(typeLookup, e);
            }
        }

        /// <summary>
        /// If null object, throw appropriate exception
        /// </summary>
        /// <param name="typeLookup"></param>
        /// <param name="typeString"></param>
        /// <param name="obj"></param>
        private static void throwIfNullObject(string typeLookup, string typeString, object obj)
        {
            if (null == obj)
            {
                if (typeLookup.Length == 0)
                {
                    throw new TypeFactoryException(new NullReferenceException(string.Format(CultureInfo.InvariantCulture, Strings.IsNullFormat, typeString)));
                }
                else
                {
                    throw new TypeFactoryException(typeLookup, new NullReferenceException(string.Format(CultureInfo.InvariantCulture, Strings.IsNullFormat, typeString)));
                }
            }
        }
        
        #endregion // private helpers
       
    }
}
