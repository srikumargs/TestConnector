using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Runtime.InteropServices;
using System.IO;

using Sage.Diagnostics;
using Sage.CRE.LinkedSource;

namespace Sage.Activation
{
    /// <summary>
    /// Used to create a root navigator over the specified xml folder
    /// </summary>
    [ComVisible(false)]
    public static class XPathNavigatorFactory
    {
        /// <summary>
        /// Create an XPathNavigator for the specified folder
        /// </summary>
        /// <param name="folderPath">The path to the folder</param>
        /// <returns>An XPathNavigator containing the contents of the specified folder</returns>
        public static XPathNavigator CreateFromFolderPath(string folderPath)
        {
            return CreateFromFolderPath(folderPath, "*.xml", CryptoAlgorithmName.None, null, null);
        }

        /// <summary>
        /// Create an XPathNavigator for the specified folder
        /// </summary>
        /// <param name="folderPath">The path to the folder</param>
        /// <param name="fileSearchPattern">The file search pattern to use (e.g., "*.xml")</param>
        /// <param name="key">The encryption key to use to decrypt the contents;  null if no encrypted contents expected</param>
        /// <returns>An XPathNavigator containing the contents of the specified folder</returns>
        public static XPathNavigator CreateFromFolderPath(string folderPath, string fileSearchPattern, string cryptoAlgorithmName, byte[] key, byte[] iv)
        {
            ArgumentValidator.ValidateDirectoryExists(folderPath, "folderPath", _myTypeName + ".CreateFromFolderPath");
            ArgumentValidator.ValidateNonEmptyString(fileSearchPattern, "fileSearchPattern", _myTypeName + ".CreateFromFolderPath");

            string[] fileNames = Directory.GetFiles(folderPath, fileSearchPattern);

            XmlDocument document = new XmlDocument();
            XmlElement rootElement = document.CreateElement("XPathNavigatorFactory_Root");
            document.AppendChild(rootElement);

            foreach(string fileName in fileNames)
            {
                try
                {
                    XmlDocument currentDocument = new XmlDocument();

                    // if we were given a key, then we expect the contents to be encrypted;  otherwise we don't
                    if(key != null)
                    {
                        currentDocument = CryptoXmlSerializer.DecryptBinaryFileToXmlDocument(fileName, Cryptography.GetCryptoAlgorithm(cryptoAlgorithmName), key, iv);
                    }
                    else
                    {
                        currentDocument.Load(fileName);
                    }

                    document.DocumentElement.AppendChild(document.ImportNode(currentDocument.DocumentElement, true));
                }
                catch(Exception)
                {
                    // might be crap someone put in the folder
                }
            }

            return document.CreateNavigator();
        }

        private static String _myTypeName = typeof(XPathNavigatorFactory).FullName;
    }
}
