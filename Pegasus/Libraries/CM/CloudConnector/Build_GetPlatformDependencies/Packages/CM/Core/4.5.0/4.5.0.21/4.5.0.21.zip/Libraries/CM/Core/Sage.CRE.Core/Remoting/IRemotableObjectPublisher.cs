using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Sage.Remoting
{
    /// <summary>
    /// Interface implemented by a component which is created by RemotableObjectHost.  Specifically, those which use a config
    /// file to specify late-bound components whose lifetime should not be managed by the Remoting lease-based object lifetime
    /// infrastructure (i.e., ManualLifetimeManagement attribute is set to "true" in the config file).
    /// 
    /// Such components should implement this interface if they want to have control over the creation of the remotable object
    /// that will be provided to RemotingServices.Marshal.
    /// </summary>
    [ComVisible(false)]
    public interface IRemotableObjectPublisher
    {
        /// <summary>
        /// Called when the RemotableObjectHost tries to publicize the remotable object via RemotingServices.Marshal
        /// </summary>
        /// <param name="hostId">an identifier corresponding to the RemotableObjectHost ID</param>
        /// <param name="uri">the uri of the object that is going to be published</param>
        /// <returns></returns>
        object GetObject(string hostId, string uri);
    }
}
