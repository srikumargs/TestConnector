using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

using Sage.Configuration;
using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Static helper class which registers for the AssemblyResolve event and uses additional
    /// specified paths to attempt to resolve.
    /// </summary>
    public static class AssemblyResolver
    {
        #region Public methods
        /// <summary>
        /// Turns on AssemblyResolve handling (default is false)
        /// </summary>
        public static bool Enabled
        {
            get
            {
                bool result = false;

                lock(_lockObject)
                {
                    result = _enabled;
                }

                return result;
            }

            set
            {
                lock(_lockObject)
                {
                    if(_enabled != value)
                    {
                        VerboseTrace.WriteLine(null, "Setting enabled state={0}", value);

                        if(value)
                        {
                            AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(OnAssemblyResolve);
                        }
                        else
                        {
                            AppDomain.CurrentDomain.AssemblyResolve -= new ResolveEventHandler(OnAssemblyResolve);
                        }

                        _enabled = value;
                    }
                }
            }
        }

        /// <summary>
        /// Adds the specified path to the list of paths that should be searched.
        /// </summary>
        /// <param name="unresolvedUrl">a PathRegistrar-compatible url</param>
        public static void AddResolvePath(string unresolvedUrl)
        {
            ArgumentValidator.ValidateNonEmptyString(unresolvedUrl, "unresolvedUrl", _myTypeName + ".AddResolvePath");

            lock(_lockObject)
            {
                string folderPath = PathRegistrar.ResolveUrl(unresolvedUrl).ToLower(CultureInfo.InvariantCulture);
                InfoTrace.WriteLine(null, "Resolved '{0}' to '{1}'", unresolvedUrl, folderPath);
                if(!_additionalResolvePaths.Contains(folderPath))
                {
                    if(Directory.Exists(folderPath))
                    {
                        InfoTrace.WriteLine(null, "Adding '{0}'", folderPath);
                        _additionalResolvePaths.Add(folderPath);
                    }
                }
            }
        }

        /// <summary>
        /// Adds the specified paths to the list of paths that should be searched.
        /// </summary>
        /// <param name="pathNodeList">A list of XmlNode objects which each have an Url attribute is a PathRegistrar-compatible url.</param>
        public static void AddResolvePaths(XmlNodeList pathNodeList)
        {
            ArgumentValidator.ValidateNonNullReference(pathNodeList, "pathNodeList", _myTypeName + ".AddResolvePaths");

            lock(_lockObject)
            {
                foreach(XmlNode pathNode in pathNodeList)
                {
                    AddResolvePath(XmlNodeHelper.GetStringAttributeValue(pathNode, "Url"));
                }
            }
        }

        /// <summary>
        /// Adds the specified paths to the list of paths that should be searched.
        /// </summary>
        /// <param name="iterator">An XPathNodeIterator object which point to xml node(s) which each have an Url attribute is a PathRegistrar-compatible url.</param>
        public static void AddResolvePaths(XPathNodeIterator iterator)
        {
            ArgumentValidator.ValidateNonNullReference(iterator, "iterator", _myTypeName + ".AddResolvePaths");

            lock(_lockObject)
            {
                while(iterator.MoveNext())
                {
                    AddResolvePath(XmlNodeHelper.GetStringAttributeValue((iterator.Current.UnderlyingObject as XmlNode), "Url"));
                }
            }
        }

        /// <summary>
        /// Removes the specified path to the list of paths that should be searched.
        /// </summary>
        /// <param name="unresolvedUrl">a PathRegistrar-compatible url</param>
        public static void RemoveResolvePath(string unresolvedUrl)
        {
            lock(_lockObject)
            {
                string folderPath = PathRegistrar.ResolveUrl(unresolvedUrl).ToLower(CultureInfo.InvariantCulture);
                InfoTrace.WriteLine(null, "Resovlved '{0}' to '{1}'", unresolvedUrl, folderPath);
                if(!_additionalResolvePaths.Contains(folderPath))
                {
                    InfoTrace.WriteLine(null, "Removing '{0}'", folderPath);
                    _additionalResolvePaths.Remove(folderPath);
                }
            }
        }

        /// <summary>
        /// Removes all previously added paths.
        /// </summary>
        public static void ClearResolvePaths()
        {
            lock(_lockObject)
            {
                _additionalResolvePaths.Clear();
            }
        }
        #endregion

        #region Private methods
        private static Assembly OnAssemblyResolve(object sender, ResolveEventArgs args)
        {
            Assembly result = null;

            lock(_lockObject)
            {
                InfoTrace.WriteLine(CultureInfo.InvariantCulture, "Starting resolution attempt for '{0}'", args.Name);

                string fileName = args.Name;
                if(fileName.Contains(","))
                {
                    string[] fileNameParts = fileName.Split(',');
                    fileName = fileNameParts[0];
                }
                if(!fileName.EndsWith(".dll", StringComparison.InvariantCultureIgnoreCase))
                {
                    fileName += ".dll";
                }

                InfoTrace.WriteLine(CultureInfo.InvariantCulture, "Normalized '{0}' to '{1}'", args.Name, fileName);

                foreach(string folderPath in _additionalResolvePaths)
                {
                    string filePath = Path.Combine(folderPath, fileName);
                    if(File.Exists(filePath))
                    {
                        InfoTrace.WriteLine(CultureInfo.InvariantCulture, "Resolved '{0}' to '{1}'", fileName, filePath);
                        result = Assembly.LoadFile(filePath);
                        InfoTrace.WriteLine(null, "Loaded '{0}' assembly at '{1}'", fileName, result.FullName);
                        break;
                    }
                }

                InfoTrace.WriteLine(CultureInfo.InvariantCulture, "Finished resolution attempt for '{0}'", args.Name);
            }

            return result;
        }
        #endregion

        #region Private fields
        private static String _myTypeName = typeof(AssemblyResolver).FullName;
        private static object _lockObject = typeof(AssemblyResolver);
        private static bool _enabled; //= false; (automatically initialized by runtime)
        private static StringCollection _additionalResolvePaths = new StringCollection();
        #endregion
    }
}
