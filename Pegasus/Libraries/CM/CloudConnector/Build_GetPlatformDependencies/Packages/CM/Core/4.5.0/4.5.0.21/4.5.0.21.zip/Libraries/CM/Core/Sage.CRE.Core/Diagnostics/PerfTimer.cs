using System;
using System.Diagnostics;
using System.Collections;
using System.Runtime.InteropServices;
using System.Windows.Forms;


namespace Sage.Diagnostics
{
    /// <summary>
    /// Used for a simple performance timer
    /// </summary>
    [ComVisible(false)]
    public class PerfTimer
    {
        /// <summary>
        /// Support writing to the various output devices
        /// </summary>
        public enum OutputType
        {
            /// <summary></summary>
            Console,
            /// <summary></summary>
            Trace,
            /// <summary></summary>
            Debug
        }

        [System.Runtime.InteropServices.DllImport("Kernel32.dll")]
        private static extern int QueryPerformanceFrequency(out Int64 lpFrequency);

        [System.Runtime.InteropServices.DllImport("Kernel32.dll")]
        private static extern int QueryPerformanceCounter(out Int64 lpPerformanceCount);

        private Int64 _frequency, _start, _last, _interval, _total;
        private OutputType _outputType = OutputType.Console;
        
        /// <summary>
        /// default output is Console
        /// </summary>
        public PerfTimer() : this(OutputType.Console)
        {
        }

        /// <summary>
        /// Pass in the output type to write line to
        /// </summary>
        /// <param name="outputType"></param>
        public PerfTimer(OutputType outputType)
        {
            _outputType = outputType;
            QueryPerformanceFrequency(out _frequency);
        }
        /// <summary>
        /// Start - set the starting tick count
        /// </summary>
        public void Start()
        {
            Int64 tmp;
            QueryPerformanceCounter(out tmp);
            _last = _start = tmp;
        }

        /// <summary>
        /// The amount of time elapsed from start or lat interval call
        /// </summary>
        /// <param name="msg"></param>
        public void Interval(string msg)
        {
            reset();
            writeLine(string.Format(msg, calcSeconds(_interval)));
        }

        /// <summary>
        /// The total time from start
        /// </summary>
        /// <param name="msg"></param>
        public void Total(string msg)
        {
            reset();
            writeLine(string.Format(msg, calcSeconds(_total)));
        }

        /// <summary>
        /// return the raw time as a string in seconds
        /// </summary>
        public string TotalTime
        {
            get 
            { 
                reset();
                return calcSeconds(_total); 
            }
        }

        /// <summary>
        /// return the raw interval time as a string in seconds
        /// </summary>
        public string IntervalTime
        {
            get 
            { 
                reset();
                return calcSeconds(_interval);
            }
        }

        private string calcSeconds(Int64 val)
        {
            double tmp = (double) ((double)val/(double)_frequency);
            return tmp.ToString("N3");
        }

        private void reset()
        {
            Int64 tmp;
            QueryPerformanceCounter(out tmp);
            _interval = tmp - _last;
            _total = tmp - _start;
            _last = tmp;
        }

        private void writeLine(string msg)
        {
            if (_outputType == OutputType.Console)
            {
                Console.WriteLine(msg);
            }
            else if (_outputType == OutputType.Debug)
            {
                Debug.WriteLine(msg);
            }
            else if (_outputType == OutputType.Trace)
            {
                Trace.WriteLine(msg);
            }
        }
    }
    
}