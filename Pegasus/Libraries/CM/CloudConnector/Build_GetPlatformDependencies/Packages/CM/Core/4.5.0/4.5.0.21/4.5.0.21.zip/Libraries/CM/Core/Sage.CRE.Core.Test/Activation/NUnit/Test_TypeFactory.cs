#if DEBUG
using System;
using System.Collections.Specialized;
using System.Runtime.InteropServices;
using NUnit.Framework;
using System.Xml;
using System.Xml.XPath;
using System.Text;
using System.IO;

using Sage.Activation;
using Sage.Configuration;

namespace Sage.Activation.NUnit
{

    internal class MessagingConfigLocator
    {
        internal static string FactoriesPath
        {
            get
            {
                // TODO:  Fix this frank..
                return PathRegistrar.ResolveUrl(@"specialpath://librarymanager.SharedConfigLocation\CRE\Messaging\TargetFactories\");
            }
        }
    }
    
    internal interface IFoozle
    {
        void CheckInstance(string check);
    }

    internal class Foozle1 : IFoozle
    {
        public void CheckInstance(string check)
        {
            Assert.AreEqual(check, "Foozle1");
        }
    }
    internal class Foozle2 : IFoozle
    {
        public void CheckInstance(string check)
        {
            Assert.AreEqual(check, "Foozle2");
        }
    }

    internal class Foozle3 : IFoozle
    {
        public void CheckInstance(string check)
        {
            Assert.AreEqual(check, "Foozle3");
        }
    }


    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class Test_Codebase
    {
        /// <summary>
        /// 
        /// </summary>
        public Test_Codebase()
        {
            string sharedPath = Environment.GetEnvironmentVariable("TS_SHARED");
            string desktopPath = Environment.GetEnvironmentVariable("TS_SANDBOX");
            desktopPath += @"\Desktop";
            PathRegistrar.RegisterPath(@"Timberline.Shared", sharedPath);
            PathRegistrar.RegisterPath(@"Sage.Desktop", desktopPath);
        }

        /// <summary>
        /// 
        /// </summary>
        /// 
        [Test]
        public void FoozleFromDesktopCodebaseTest1()
        {
            string xml = "<TypeInstance QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Codebase='[registeredpath://Sage.Desktop]' Assembly='Sage.CRE.Core.dll' />";
            XPathNavigator nav = new XPathDocument(new StringReader(xml)).CreateNavigator();
            XPathNodeIterator iter = nav.Select("//TypeInstance");
            iter.MoveNext();
            IFoozle fooz = (IFoozle) TypeFactory.CreateObject(iter);
            fooz.CheckInstance("Foozle1");
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void FoozleFromDesktopCodebaseTest2()
        {
            string xml = "<TypeInstance QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Codebase='[registeredpath://Sage.Desktop]' Assembly='Sage.CRE.Core' />";
            XPathNavigator nav = new XPathDocument(new StringReader(xml)).CreateNavigator();
            XPathNodeIterator iter = nav.Select("//TypeInstance");
            iter.MoveNext();
            IFoozle fooz = (IFoozle) TypeFactory.CreateObject(iter);
            fooz.CheckInstance("Foozle1");
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void FoozleFromDesktopCodebaseTest3()
        {
            string xml = "<DynamicProperty Type='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' Codebase='[registeredpath://Sage.Desktop]' />";
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            IFoozle fooz = (IFoozle) TypeFactory.CreateObject(doc.FirstChild);
            fooz.CheckInstance("Foozle1");
        }

    }

	/// <summary>
	/// 
	/// </summary>
	[TestFixture]
	[ComVisible(false)]
	public class Test_TypeSchema
	{
		/// <summary>
		/// 
		/// </summary>
		[Test]
		public void TypeFactorySchemaIteratorTest()
		{
			string xml = "<TypeInstance QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' />";
			XPathNavigator nav = new XPathDocument(new StringReader(xml)).CreateNavigator();
			XPathNodeIterator iter = nav.Select("//TypeInstance");
			iter.MoveNext();
            TypeReader r = TypeReaderFactory.Create(iter);
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@Assembly",true), "Sage.CRE.Core.dll");
		}

		/// <summary>
		/// 
		/// </summary>
		[Test]
		public void TypeFactorySchemaNodeTest()
		{
			string xml = "<TypeInstance QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' />";
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(xml);
            TypeReader r = TypeReaderFactory.Create(doc.FirstChild);
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@Assembly",true), "Sage.CRE.Core.dll");
		}

		/// <summary>
		/// 
		/// </summary>
		[Test]
		public void ObjectFactorySchemaIteratorComTest()
		{
			string xml = "<DynamicProperty ProgID='Timberline.pjComServer.CustomLogTaskProvider' />";
			XPathNavigator nav = new XPathDocument(new StringReader(xml)).CreateNavigator();
			XPathNodeIterator iter = nav.Select("//DynamicProperty");
			iter.MoveNext();
            TypeReader r = TypeReaderFactory.Create(iter);
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@QualifiedTypeName", true), "Timberline.pjComServer.CustomLogTaskProvider");
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@ExecutionEnvironment", true), "unmanaged");
		}

		/// <summary>
		/// 
		/// </summary>
		[Test]
		public void ObjectFactorySchemaIteratorNetTest()
		{
			string xml = "<DynamicProperty Type='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' />";
			XPathNavigator nav = new XPathDocument(new StringReader(xml)).CreateNavigator();
			XPathNodeIterator iter = nav.Select("//DynamicProperty");
			iter.MoveNext();
            TypeReader r = TypeReaderFactory.Create(iter);
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@QualifiedTypeName", true), "Sage.Activation.NUnit.Foozle1");
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@ExecutionEnvironment", true), "managed");
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@Assembly", true), "Sage.CRE.Core.dll");
		}

		/// <summary>
		/// 
		/// </summary>
		[Test]
		public void ObjectFactorySchemaNodeComTest()
		{
			string xml = "<DynamicProperty ProgID='Timberline.pjComServer.CustomLogTaskProvider' />";
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(xml);
            TypeReader r = TypeReaderFactory.Create(doc.FirstChild);
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@QualifiedTypeName", true), "Timberline.pjComServer.CustomLogTaskProvider");
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@ExecutionEnvironment", true), "unmanaged");
		}
		/// <summary>
		/// 
		/// </summary>
		[Test]
		public void ObjectFactorySchemaNodeNetTest()
		{
			string xml = "<DynamicProperty Type='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' />";
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(xml);
            TypeReader r = TypeReaderFactory.Create(doc.FirstChild);
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@QualifiedTypeName", true), "Sage.Activation.NUnit.Foozle1");
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@ExecutionEnvironment", true), "managed");
			Assert.AreEqual(r.SelectSingleNodeValue("//TypeInstance/@Assembly", true), "Sage.CRE.Core.dll");
		}

		/// <summary>
		/// 
		/// </summary>
		[Test]
		public void CreateComTest()
		{
            // a com object out of mshtml.dll
            object o = TypeFactory.CreateCOMComponent("htmlfile");
            Assert.IsNotNull(o);
		}
	}

    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class Test_TypeFactoryReader
    {
        /// <summary>
        /// Make sure I can retrieve all the TypeFactorys
        /// </summary>
        [Test]
        public void TestInstanceArray()
        {
            TypeFactoryReader r = new TypeFactoryReader(MessagingConfigLocator.FactoriesPath);
            TypeFactory[] tis = r.TypeFactorys;
            foreach (TypeFactory ti in tis)
            {
                object o = ti.GetLocalObject();
                Console.WriteLine(o.GetType().Name);
            }
        }

        /// <summary>
        /// Make sure I can retrieve interface TypeFactorys
        /// </summary>
        [Test]
        public void TestInterfaceArray()
        {
            TypeFactoryReader r = new TypeFactoryReader(MessagingConfigLocator.FactoriesPath);
            TypeFactory[] tis = r.GetInterfaceImplementors("IMessageTargetFactory");
            foreach (TypeFactory ti in tis)
            {
                object o = ti.GetLocalObject();
                Console.WriteLine(o.GetType().Name);
            }
        }
        /// <summary>
        /// Make sure I can retrieve interface TypeFactorys
        /// </summary>
        [Test]
        public void TestNoInterfaceArray()
        {
            TypeFactoryReader r = new TypeFactoryReader(MessagingConfigLocator.FactoriesPath);
            TypeFactory[] tis = r.GetInterfaceImplementors("ICrappola");
            foreach (TypeFactory ti in tis)
            {
                object o = ti.GetLocalObject();
                Console.WriteLine(o.GetType().Name);
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class Test_TypeFactoryStatic
    {
        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void GetXPathObjectTest()
        {
            string xml = "<TypeInstance QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' />";
            XPathNavigator nav = new XPathDocument(new StringReader(xml)).CreateNavigator();
            XPathNodeIterator iter = nav.Select("//TypeInstance");
            iter.MoveNext();
            IFoozle fooz = (IFoozle) TypeFactory.CreateObject(iter);
            fooz.CheckInstance("Foozle1");
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void GetDocObjectTest()
        {
            string xml = "<TypeInstance QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' />";
            IFoozle fooz = (IFoozle) TypeFactory.CreateObject(createNode(xml));
            fooz.CheckInstance("Foozle1");
        }

        private XmlNode createNode(string xml)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            return doc.FirstChild;
        }

    }


    /// <summary>
    /// Test the Type Factory
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class Test_TypeFactoryActive
    {
        private string _filename1 = Path.GetTempFileName();
        private string _filename2 = Path.GetTempFileName();
        private string _filename3 = Path.GetTempFileName();
        private string _filename4 = Path.GetTempFileName();
        private string _filename5 = Path.GetTempFileName();
        private string _filename6 = Path.GetTempFileName();
        private string _filename7 = Path.GetTempFileName();

        private string _xml1 = "<?xml version='1.0' encoding='utf-8'?><Implements>" +
            "<TypeInstance TypeLookup='Foozle' Active='true' QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle' Active='false' QualifiedTypeName='Sage.Activation.NUnit.Foozle2' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle' Active='false' QualifiedTypeName='Sage.Activation.NUnit.Foozle3' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "</Implements>";

        private string _xml2 = "<?xml version='1.0' encoding='utf-8'?><Implements>" +
            "<TypeInstance TypeLookup='Foozle' Active='false' QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle' Active='true' QualifiedTypeName='Sage.Activation.NUnit.Foozle2' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle' Active='false' QualifiedTypeName='Sage.Activation.NUnit.Foozle3' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "</Implements>";

        private string _xml3 = "<?xml version='1.0' encoding='utf-8'?><Implements>" +
            "<TypeInstance TypeLookup='Foozle' Active='false' QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle' Active='false' QualifiedTypeName='Sage.Activation.NUnit.Foozle2' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle' Active='true' QualifiedTypeName='Sage.Activation.NUnit.Foozle3' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "</Implements>";

        private string _xml4 = "<?xml version='1.0' encoding='utf-8'?><Implements>" +
            "<TypeInstance TypeLookup='Foozle' Active='true' QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle' Active='true' QualifiedTypeName='Sage.Activation.NUnit.Foozle2' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle' Active='true' QualifiedTypeName='Sage.Activation.NUnit.Foozle3' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "</Implements>";

        private string _xml5 = "<?xml version='1.0' encoding='utf-8'?><Implements>" +
            "<TypeInstance TypeLookup='Foozle' Active='false' QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle' Active='false' QualifiedTypeName='Sage.Activation.NUnit.Foozle2' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle' Active='false' QualifiedTypeName='Sage.Activation.NUnit.Foozle3' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "</Implements>";

        private string _xml6 = "<?xml version='1.0' encoding='utf-8'?><Implements>" +
            "<TypeInstance TypeLookup='Foozle'  QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle'  QualifiedTypeName='Sage.Activation.NUnit.Foozle2' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle'  QualifiedTypeName='Sage.Activation.NUnit.Foozle3' Assembly='Sage.CRE.Core.dll' Location='local' URI='none' Regenerate='true' />" +
            "</Implements>";

        private string _xml7 = "<?xml version='1.0' encoding='utf-8'?><Implements>" +
            "<TypeInstance TypeLookup='Foozle'  QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle'  QualifiedTypeName='Sage.Activation.NUnit.Foozle2' Assembly='Sage.CRE.Core' Location='local' URI='none' Regenerate='true' />" +
            "<TypeInstance TypeLookup='Foozle'  QualifiedTypeName='Sage.Activation.NUnit.Foozle3' Assembly='Sage.CRE.Core' Location='local' URI='none' Regenerate='true' />" +
            "</Implements>";

        /// <summary>
        /// </summary>
        public Test_TypeFactoryActive() 
        {
        }

        /// <summary>
        /// 1st instance is active
        /// </summary>
        [Test]
        public void ActiveAttributeTest1()
        {
            DoActiveTest(_filename1, _xml1, "Foozle1");
        }

        /// <summary>
        /// 2nd instance is active
        /// </summary>
        [Test]
        public void ActiveAttributeTest2()
        {
            DoActiveTest(_filename2, _xml2, "Foozle2");
        }

        /// <summary>
        /// 3rd instance is active
        /// </summary>
        [Test]
        public void ActiveAttributeTest3()
        {
            DoActiveTest(_filename3, _xml3, "Foozle3");
        }

        /// <summary>
        /// All instances active - first should be returned
        /// </summary>
        [Test]
        public void ActiveAttributeTest4()
        {
            DoActiveTest(_filename4, _xml4, "Foozle1");
        }

        /// <summary>
        /// No instances active - first should be returned
        /// </summary>
        [Test]
        public void ActiveAttributeTest5()
        {
            DoActiveTest(_filename5, _xml5, "Foozle1");
        }

        /// <summary>
        /// No active attribute defined - first should be returned
        /// </summary>
        [Test]
        public void ActiveAttributeTest6()
        {
            DoActiveTest(_filename6, _xml6, "Foozle1");
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void ActiveAttributeTest7()
        {
            DoActiveTest(_filename7, _xml7, "Foozle1");
        }

        /// <summary>
        /// Test a minimal TypeFactory instantiation with a string
        /// </summary>
        [Test]
        public void ActiveAttributeTest8()
        {
            string xml = "<TypeInstance QualifiedTypeName='Sage.Activation.NUnit.Foozle1' Assembly='Sage.CRE.Core.dll' />";
            TypeFactory ti = new TypeFactory(TypeReaderFactory.Create(createNode(xml)));
            IFoozle fooz = (IFoozle) ti.GetLocalObject();
            fooz.CheckInstance("Foozle1");
        }

        private XmlNode createNode(string xml)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            return doc.FirstChild;
        }

        private void DoActiveTest(string filename, string xml, string expected)
        {
            BuildConfigFile(filename, xml);
            XPathDocument doc = new XPathDocument(filename);
            XPathNavigator nav = doc.CreateNavigator();
            TypeReader tr   = new TypeReader(nav);
            TypeFactory ti = new TypeFactory(tr);
            IFoozle fooz = (IFoozle) ti.GetLocalObject("Foozle");
            fooz.CheckInstance(expected);
            File.Delete(filename);
        }

        private void BuildConfigFile(string filename, string xml)
        {
            XmlTextWriter tw = new XmlTextWriter(filename, Encoding.UTF8);
            tw.WriteRaw(xml);
            tw.Close();
        }
    }
}
#endif