using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Xml;

#if !NO_SAGE_DIAGNOSTICS_REFERENCE
using Sage.Diagnostics;
#endif

// This source file resides in the "LinkedSource" source code folder in order to enable multiple assemblies
// to shared the implementation without requiring the Cryptography class to be exposed as a public
// type of any shared assembly.
//
// Requires:
//  - Sage.CRE.Core.dll (unless NO_SAGE_DIAGNOSTICS_REFERENCE is defined)
//  - %SAGE_SANDBOX%\Libraries\Sage\CRE\LinkedSource\Cryptography.cs
//  - %SAGE_SANDBOX%\Libraries\Sage\CRE\LinkedSource\CryptoSerializer.cs
namespace Sage.CRE.LinkedSource
{
    /// <summary>
    /// Class used to help perform encrypted serialization of Xml
    /// </summary>
    internal static class CryptoXmlSerializer
    {
        #region Public Methods
        /// <summary>
        /// Reads an Xml file, encrypts it, and writes the encrypted result to a binary file
        /// </summary>
        /// <param name="sourcePath">The file path to the source from which the unencrypted Xml should be read</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <param name="destinationPath">The file path to the destination where the encrypted result should be written</param>
        public static void EncryptXmlFileToBinaryFile(String sourcePath, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv, String destinationPath)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(key, "key", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlFileToBinaryFile");
            ArgumentValidator.ValidateFileExists(sourcePath, "sourcePath", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlFileToBinaryFile");
            ArgumentValidator.ValidateNonEmptyString(destinationPath, "destinationPath", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlFileToBinaryFile");
#endif

            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.PreserveWhitespace = true;
            xmlDocument.Load(sourcePath);
            EncryptXmlDocumentToBinaryFile(xmlDocument, cryptoAlgorithm, key, iv, destinationPath);
        }

        /// <summary>
        /// Reads an Xml file, encrypts it, and writes the encrypted result to a binary file
        /// </summary>
        /// <param name="sourcePath">The file path to the source from which the unencrypted Xml should be read</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The reference to the generated initialization vector for the symmetric algorithm used by this call</param>
        /// <param name="destinationPath">The file path to the destination where the encrypted result should be written</param>
        public static void EncryptXmlFileToBinaryFile(String sourcePath, CryptoAlgorithm cryptoAlgorithm, Byte[] key, out Byte[] iv, String destinationPath)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(key, "key", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlFileToBinaryFile");
            ArgumentValidator.ValidateFileExists(sourcePath, "sourcePath", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlFileToBinaryFile");
            ArgumentValidator.ValidateNonEmptyString(destinationPath, "destinationPath", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlFileToBinaryFile");
#endif

            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.PreserveWhitespace = true;
            xmlDocument.Load(sourcePath);
            EncryptXmlDocumentToBinaryFile(xmlDocument, cryptoAlgorithm, key, out iv, destinationPath);
        }

        /// <summary>
        /// Encrypts the provided XmlDocument and writes the encrypted result to a binary file
        /// </summary>
        /// <param name="sourceDocument">The Xml document whose contents are to be encrypted</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <param name="destinationPath">The file path to the destination where the encrypted result should be written</param>
        public static void EncryptXmlDocumentToBinaryFile(XmlDocument sourceDocument, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv, String destinationPath)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(key, "key", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlDocumentToBinaryFile");
            ArgumentValidator.ValidateNonNullReference(sourceDocument, "sourceDocument", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlDocumentToBinaryFile");
            ArgumentValidator.ValidateNonEmptyString(destinationPath, "destinationPath", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlDocumentToBinaryFile");
#endif

            CryptoSerializer.EncryptStringToBinaryFile(sourceDocument.InnerXml, cryptoAlgorithm, key, iv, destinationPath);
        }

        /// <summary>
        /// Encrypts the provided XmlDocument and writes the encrypted result to a binary file
        /// </summary>
        /// <param name="sourceDocument">The Xml document whose contents are to be encrypted</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The reference to the generated initialization vector for the symmetric algorithm used by this call</param>
        /// <param name="destinationPath">The file path to the destination where the encrypted result should be written</param>
        public static void EncryptXmlDocumentToBinaryFile(XmlDocument sourceDocument, CryptoAlgorithm cryptoAlgorithm, Byte[] key, out Byte[] iv, String destinationPath)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(key, "key", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlDocumentToBinaryFile");
            ArgumentValidator.ValidateNonNullReference(sourceDocument, "sourceDocument", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlDocumentToBinaryFile");
            ArgumentValidator.ValidateNonEmptyString(destinationPath, "destinationPath", typeof(CryptoXmlSerializer).FullName + ".EncryptXmlDocumentToBinaryFile");
#endif

            CryptoSerializer.EncryptStringToBinaryFile(sourceDocument.InnerXml, cryptoAlgorithm, key, out iv, destinationPath);
        }

        /// <summary>
        /// Reads a binary file, unencrypts it, and returns the contants as a XmlDocument object
        /// </summary>
        /// <param name="sourcePath">The file path to the source from which the encrypted contents should be read</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>An XmlDocument representation of the unencrypted contents</returns>
        public static XmlDocument DecryptBinaryFileToXmlDocument(String sourcePath, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(key, "key", typeof(CryptoXmlSerializer).FullName + ".DecryptBinaryFileToXmlDocument");
            ArgumentValidator.ValidateFileExists(sourcePath, "sourcePath", typeof(CryptoXmlSerializer).FullName + ".DecryptBinaryFileToXmlDocument");
#endif

            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.PreserveWhitespace = true;
            xmlDocument.LoadXml(CryptoSerializer.DecryptBinaryFileToString(sourcePath, cryptoAlgorithm, key, iv));
            return xmlDocument;
        }

        /// <summary>
        /// Reads a binary file, unencrypts it, and writes the unencrypted result to an Xml file
        /// </summary>
        /// <param name="key">The encryption key</param>
        /// <param name="sourcePath">The file path to the source from which the encrypted contents should be read</param>
        /// <param name="destinationPath">The file path to the destination where the unencrypted result should be written</param>
        /// <param name="cryptoAlgorithm"></param>
        /// <param name="iv"></param>
        public static void DecryptBinaryFileToXmlFile(String sourcePath, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv, String destinationPath)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(key, "key", typeof(CryptoXmlSerializer).FullName + ".DecryptBinaryFileToXmlFile");
            ArgumentValidator.ValidateFileExists(sourcePath, "sourcePath", typeof(CryptoXmlSerializer).FullName + ".DecryptBinaryFileToXmlFile");
            ArgumentValidator.ValidateNonEmptyString(destinationPath, "destinationPath", typeof(CryptoXmlSerializer).FullName + ".DecryptBinaryFileToXmlFile");
#endif

            DecryptBytesToXmlFile(CryptoSerializer.ReadBytesFromBinaryFile(sourcePath), cryptoAlgorithm, key, iv, destinationPath);
        }

        /// <summary>
        /// Unencrypts the provided encrypted bytes, and writes the result to an Xml file
        /// </summary>
        /// <param name="key">The encryption key</param>
        /// <param name="encryptedBytes">The bytes to decrypt</param>
        /// <param name="destinationPath">The file path to the destination where the unencrypted result should be written</param>
        /// <param name="cryptoAlgorithm"></param>
        /// <param name="iv"></param>
        public static void DecryptBytesToXmlFile(Byte[] encryptedBytes, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv, String destinationPath)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(key, "key", typeof(CryptoXmlSerializer).FullName + ".DecryptBytesToXmlFile");
            ArgumentValidator.ValidateNonNullReference(encryptedBytes, "encryptedBytes", typeof(CryptoXmlSerializer).FullName + ".DecryptBytesToXmlFile");
            ArgumentValidator.ValidateNonEmptyString(destinationPath, "destinationPath", typeof(CryptoXmlSerializer).FullName + ".DecryptBytesToXmlFile");
#endif

            WriteXmlStringToXmlFile(destinationPath, Cryptography.DecryptBytesToString(encryptedBytes, cryptoAlgorithm, key, iv));
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Writes provided Xml string to the specified Xml file
        /// </summary>
        /// <param name="destinationPath">The file path to the destination where the Xml should be written</param>
        /// <param name="xml">The Xml to write</param>
        private static void WriteXmlStringToXmlFile(String destinationPath, String xml)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonEmptyString(destinationPath, "destinationPath", typeof(CryptoXmlSerializer).FullName + ".WriteXmlStringToXmlFile");
            ArgumentValidator.ValidateNonEmptyString(xml, "xml", typeof(CryptoXmlSerializer).FullName + ".WriteXmlStringToXmlFile");
#endif

            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.PreserveWhitespace = true;
            xmlDocument.LoadXml(xml);
            xmlDocument.Save(destinationPath);
        }
        #endregion
    }
}
