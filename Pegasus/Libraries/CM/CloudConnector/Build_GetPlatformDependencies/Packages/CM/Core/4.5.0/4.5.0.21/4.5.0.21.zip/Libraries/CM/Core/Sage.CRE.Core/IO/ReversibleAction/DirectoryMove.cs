using System;
using System.Collections.Generic;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Moves (or renames) one or more directories using the ReversibleAction pattern.
    /// The construction of a DirectoryMove object moves the specified directory.
    /// If the object is disposed without calling the Commit() method, then the moved directory is restored to its original location and state.
    /// 
    /// Typical usage:
    /// 
    /// using (DirectoryMove dirMove = new DirectoryMove(@"C:\sourceDirectory",@"D:\destinationDirectory"))
    ///     {
    ///         dirMove.Forward();
    ///         
    ///         // do some code that might throw. If this code throws, we need to restore the moved to its original location and state.
    /// 
    ///         dirMove.Commit();
    ///     }
    /// </summary>
    public class DirectoryMove : ReversibleActionBase
    {

        /// <summary>
        /// Move a single directory.
        /// </summary>
        /// <param name="source">The directory to move.</param>
        /// <param name="destination">The location to place the moved directory.</param>
        public DirectoryMove(string source, string destination)
        {
            _directoriesToBeMoved.Add(source, destination);
        }

        /// <summary>
        /// Move a set of directories.
        /// </summary>
        /// <param name="sourcesAndDestinations">A dictionary of source and destination directories.</param>
        public DirectoryMove(Dictionary<string, string> sourcesAndDestinations)
        {
            _directoriesToBeMoved = sourcesAndDestinations;
        }


        #region Protected methods
        /// <summary>
        /// Moves the directories.
        /// </summary>
        public override void Forward()
        {
            base.Forward();
            foreach (KeyValuePair<string, string> kvp in _directoriesToBeMoved)
            {
                string src = kvp.Key;
                string dest = kvp.Value;
                
                System.IO.DirectoryInfo dirInfo = new System.IO.DirectoryInfo(src);
                dirInfo.MoveTo(dest);
                _directoriesMoved.Add(src, dest);
            }
        }

        /// <summary>
        /// Restores any moved directories.
        /// </summary>
        public override void Reverse()
        {
            base.Reverse();
            foreach (KeyValuePair<string,string> kvp in _directoriesMoved)
            {
                string src = kvp.Key;
                string dest = kvp.Value;
                
                System.IO.DirectoryInfo dirInfo = new System.IO.DirectoryInfo(dest);
                dirInfo.MoveTo(src);
            }
            _directoriesMoved.Clear();
        }
        #endregion

        #region Private members
        private Dictionary<string, string> _directoriesToBeMoved = new Dictionary<string, string>();
        private Dictionary<string, string> _directoriesMoved = new Dictionary<string, string>();
        #endregion

    }
}
