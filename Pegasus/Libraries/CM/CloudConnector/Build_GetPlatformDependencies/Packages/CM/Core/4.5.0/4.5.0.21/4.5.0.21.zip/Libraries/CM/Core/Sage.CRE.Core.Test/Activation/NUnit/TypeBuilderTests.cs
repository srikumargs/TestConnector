#if DEBUG
using System;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Reflection.Emit;
using NUnit.Framework;

using Sage.Activation;

namespace Sage.Activation.NUnit.Tests
{
    /// <summary>
    /// Invokes various members of the TypeBuilder class.
    /// </summary>
    [TestFixture]
    public class TypeBuilderTests
    {
        #region Public methods
        /// <summary>
        /// Tests Controller.DoStart
        /// </summary>
        [Test]
        public void CreateAndSaveDynamicType()
        {
            Sage.Activation.TypeBuilder typeBuilder = new TypeBuilder("NUnitTestAssembly.dll");
            typeBuilder.DefinePublicClassType("Foo");
            typeBuilder.DefinePublicInstanceConstructor();

            FieldBuilder value1FieldBuilder = typeBuilder.DefinePrivateInstanceField("_boolValue1", typeof(bool));
            typeBuilder.DefineProperty("BoolValue1", typeof(bool));
            typeBuilder.DefinePublicInstanceMethod("get_BoolValue1", Type.EmptyTypes, typeof(bool), new TypeBuilder.EmitMethodImplementationCallback(TypeBuilder.EmitSimpleGetMethodImplementation), new object[] { value1FieldBuilder });
            typeBuilder.DefinePublicInstanceMethod("set_BoolValue1", new Type[] { typeof(bool) }, null, new TypeBuilder.EmitMethodImplementationCallback(TypeBuilder.EmitSimpleSetMethodImplementation), new object[] { value1FieldBuilder });

            typeBuilder.DefinePropertyAndInstanceField("IntValue1", "_intValue1", typeof(int));
            typeBuilder.ApplyAttributeToProperty("IntValue1", typeof(AttributeUsageAttribute), new Type[] { typeof(AttributeTargets) }, new object[] { AttributeTargets.All });

            typeBuilder.CreateType();
            typeBuilder.SaveAssembly();

            object foo = TypeBuilder.CreateObject("Foo");
            Assertion.AssertEquals("Foo", foo.GetType().Name);

            object foo2 = TypeBuilder.CreateObject("Foo");
            Assertion.AssertEquals("Foo", foo2.GetType().Name);

            Assertion.Assert(foo.GetHashCode() != foo2.GetHashCode());
            Assertion.AssertSame(foo.GetType().Assembly, foo2.GetType().Assembly);

            Type reflectedType = foo.GetType();
            Assertion.AssertSame(reflectedType.BaseType, typeof(object));
            Assertion.Assert(reflectedType.GetMethod("get_BoolValue1") != null);
            Assertion.Assert(reflectedType.GetMethod("set_BoolValue1") != null);
            Assertion.Assert(reflectedType.GetMethod("get_IntValue1") != null);
            Assertion.Assert(reflectedType.GetMethod("set_IntValue1") != null);
            Assertion.Assert(reflectedType.GetField("_boolValue1", BindingFlags.NonPublic | BindingFlags.Instance) != null);
            Assertion.Assert(reflectedType.GetField("_intValue1", BindingFlags.NonPublic | BindingFlags.Instance) != null);
        }
        #endregion
    }
}
#endif