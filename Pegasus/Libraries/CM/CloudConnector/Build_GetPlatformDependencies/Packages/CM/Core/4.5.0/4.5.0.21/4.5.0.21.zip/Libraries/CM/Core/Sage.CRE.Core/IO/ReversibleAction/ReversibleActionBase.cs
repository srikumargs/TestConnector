using System;
using System.Collections.Generic;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Base class for Reversible Actions.
    /// </summary>
    public class ReversibleActionBase : IDisposable
    {
        #region Private members

        private bool _commited;
        private bool _executed;
        #endregion

        /// <summary>
        /// Move the action forward.
        /// </summary>
        public virtual void Forward()
        {
            System.Diagnostics.Debug.Assert(!_executed, StringsCustomerFacing.ReversibleFileSystemAction_InvalidToMoveForwardTwice_EmbeddedMessage);
            if (_executed) throw new System.IO.IOException(StringsCustomerFacing.ReversibleFileSystemAction_InvalidToMoveForwardTwice_EmbeddedMessage);
            _executed = true;
        }

        /// <summary>
        /// Reverse the action.
        /// </summary>
        public virtual void Reverse()
        {
            System.Diagnostics.Debug.Assert(_executed, StringsCustomerFacing.ReversibleFileSystemAction_InvalidToReverseWithoutForward_EmbeddedMessage);
            if (!_executed) throw new System.IO.IOException(StringsCustomerFacing.ReversibleFileSystemAction_InvalidToReverseWithoutForward_EmbeddedMessage);
            _executed = false;
        }

        /// <summary>
        /// Commit the action.
        /// </summary>
        public virtual void Commit()
        {
            System.Diagnostics.Debug.Assert(_executed, StringsCustomerFacing.ReversibleFileSystemAction_InvalidToCommitWithoutForward_EmbeddedMessage);
            if (!_executed) throw new System.IO.IOException(StringsCustomerFacing.ReversibleFileSystemAction_InvalidToCommitWithoutForward_EmbeddedMessage);
            _commited = true;
        }


        /// <summary>
        /// Dispose the action. If the action has not been Commited, it will be Reversed.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        /// <summary>
        /// Dispose the action.
        /// </summary>
        /// <param name="disposing">Should shared resources be disposed.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (!_commited) Reverse();
            }
        }
    }
}
