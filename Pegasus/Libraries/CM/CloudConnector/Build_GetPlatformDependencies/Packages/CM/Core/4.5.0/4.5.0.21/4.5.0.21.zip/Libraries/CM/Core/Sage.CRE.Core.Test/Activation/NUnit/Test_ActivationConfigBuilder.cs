#if DEBUG

using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Globalization;
using NUnit.Framework;

namespace Sage.Activation.NUnit
{
	/// <summary>
	/// Summary description for Test_ActivationConfigBuilder.
	/// </summary>
    [TestFixture]
    [ComVisible(false)]
	public class Test_ActivationConfigBuilder
	{
        /// <summary>
        /// Constructor
        /// </summary>
		public Test_ActivationConfigBuilder()
		{
		}

        /// <summary>
        /// Test the ComponentXmlMethod
        /// </summary>
        [Test]
        public void TestComponentXml()
        {
            string config = ActivationConfigBuilder.ComponentXml( this );
            if (this.GetType().Assembly.GlobalAssemblyCache)
            {
                Assert.IsTrue(config == string.Format(CultureInfo.InvariantCulture, "<Component ActivationType='DOT_NET' Assembly='{0}' Type='Sage.Activation.NUnit.Test_ActivationConfigBuilder' />", this.GetType().Assembly.FullName));
            }
            else
            {
                Assert.IsTrue(config == string.Format(CultureInfo.InvariantCulture, "<Component ActivationType='DOT_NET' Assembly='Sage.CRE.Core' Type='Sage.Activation.NUnit.Test_ActivationConfigBuilder' Codebase='[{0}]' />", Path.GetDirectoryName(this.GetType().Assembly.Location)));
            }
        }
	}
}

#endif
