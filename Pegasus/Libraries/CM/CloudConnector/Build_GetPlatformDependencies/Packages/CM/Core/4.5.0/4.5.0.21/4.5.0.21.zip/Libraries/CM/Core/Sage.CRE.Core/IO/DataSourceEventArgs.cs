using System;
using System.IO;
using Sage.Diagnostics;

namespace Sage.IO
{
	/// <summary>
	/// Arguments for data source event
	/// </summary>
	public class DataSourceEventArgs: EventArgs
	{
        // The ID of the data source that triggered the event
        private readonly string _dataSourceId = null;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataSourceId">The ID of the data source that triggered the event</param>
		public DataSourceEventArgs( string dataSourceId )
		{
            ArgumentValidator.ValidateNonEmptyString( dataSourceId, "dataSourceId", this.GetType().Name );
		    _dataSourceId = dataSourceId;	
		}

        /// <summary>
        /// Retrieve the ID of the data source that triggered the event
        /// </summary>
        public string DataSourceId
        {
            get{ return _dataSourceId; }
        }

	}

    /// <summary>
    /// Handler for data source events
    /// </summary>
    public delegate void DataSourceEventHandler( object sender, DataSourceEventArgs e );
}
