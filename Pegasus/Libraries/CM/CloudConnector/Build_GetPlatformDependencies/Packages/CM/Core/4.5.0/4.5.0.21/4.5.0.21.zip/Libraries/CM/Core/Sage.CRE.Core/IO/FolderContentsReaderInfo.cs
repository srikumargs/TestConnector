using System;
using System.Diagnostics;
using System.IO;
using Sage.Diagnostics;

namespace Sage.IO
{
    /// <summary>
    /// A helper class for providing info to the FolderContentsReader
    /// </summary>
    public sealed class FolderContentsReaderInfo
    {
        #region Fields

        // A path of the folder to read files from
        private string _folder = null;

        // An unencrypted file filter
        private string _unEncryptedFileFilter = "*.xml";

        // An encrypted file filter
        private string _encryptedFileFilter = "*.acx";

        // A Flag indicating if file streams should be cached or not.
        private bool _cacheFileStreams = true;

        // A flag indicating if the folder should be monitored for changes
        private bool _monitorFolderForChanges = false;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="folder">A folder containing files to read</param>
        public FolderContentsReaderInfo( string folder )
        {
            _folder = folder;
            ValidateFolder();   
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="folder">A folder containing files to read</param>
        /// <param name="cacheFileStreams">A flag indicating if file streams should be cached or not</param>
        /// <remarks>By default file streams are cached</remarks>
        public FolderContentsReaderInfo( string folder, bool cacheFileStreams )
        {
            _folder = folder;
            ValidateFolder(); 
            _cacheFileStreams = cacheFileStreams;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="folder">A folder containing files to read</param>
        /// <param name="cacheFileStreams">A flag indicating if file streams should be cached or not</param>
        /// <param name="monitorFolderForChanges">A flag indicating if the folder should be monitored for changes</param>
        public FolderContentsReaderInfo( string folder, bool cacheFileStreams, bool monitorFolderForChanges )
        {
            _folder = folder;
            ValidateFolder();
            _cacheFileStreams = cacheFileStreams;
            _monitorFolderForChanges = monitorFolderForChanges;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="folder">A folder containing files to read</param>
        /// <param name="cacheFileStreams">A flag indicating if file streams should be cached or not</param>
        /// <param name="unEncryptedFileFilter">A filter used to identify unencrypted files to process</param>
        /// <param name="encryptedFileFilter">A filter used to identify encrypted files to process</param>
        /// <remarks>Pass null for the unEncryptedFileFilter if all files should be encrypted or vice versa. 
        /// Passing null or "" for both filters, however, will result in an invalid argument exception</remarks>
        public FolderContentsReaderInfo( string folder, bool cacheFileStreams, string unEncryptedFileFilter, string encryptedFileFilter )
        {
            _folder = folder;
            ValidateFolder(); 
            _cacheFileStreams = cacheFileStreams;
            _unEncryptedFileFilter = unEncryptedFileFilter;
            _encryptedFileFilter = encryptedFileFilter;
            ValidateFilters();
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="folder">A folder containing files to read</param>
        /// <param name="cacheFileStreams">A flag indicating if file streams should be cached or not</param>
        /// <param name="monitorFolderForChanges">A flag indicating if the folder should be monitored for changes</param>
        /// <param name="unEncryptedFileFilter">A filter used to identify unencrypted files to process</param>
        /// <param name="encryptedFileFilter">A filter used to identify encrypted files to process</param>
        /// <remarks>Pass null for the unEncryptedFileFilter if all files should be encrypted or vice versa. 
        /// Passing null or "" for both filters, however, will result in an invalid argument exception</remarks>
        public FolderContentsReaderInfo( string folder, bool cacheFileStreams, bool monitorFolderForChanges, string unEncryptedFileFilter, string encryptedFileFilter )
        {
            _folder = folder;
            ValidateFolder(); 
            _cacheFileStreams = cacheFileStreams;
            _monitorFolderForChanges = monitorFolderForChanges;
            _unEncryptedFileFilter = unEncryptedFileFilter;
            _encryptedFileFilter = encryptedFileFilter;
            ValidateFilters();
        }

        /// <summary>
        /// Retrieve the config folder
        /// </summary>
        public string Folder
        {
            get
            { 
                ValidateFolder();
                return _folder; 
            }
        }

        /// <summary>
        /// Get/Set a Flag indicating if file streams should be cached or not. 
        /// </summary>
        /// <remarks>Default value = true</remarks>
        public bool CacheFileStreams
        {
            get{ return _cacheFileStreams; }
            set{ _cacheFileStreams = value; }
        
        }

        /// <summary>
        /// Get/Set the Unencrypted file filter
        /// </summary>
        /// <remarks>This filter is used to locate unencrypted configuration files. 
        /// The default value is "*.xml"</remarks>
        public string UnEncryptedFileFilter
        {
            get{ return _unEncryptedFileFilter; }
            set
            { 
                _unEncryptedFileFilter = value; 
                ValidateFilters();
            }
        }
        
        /// <summary>
        /// Get/Set the encrypted file filter
        /// </summary>
        /// <remarks>This filter is used to locate encrypted configuration files. 
        /// The default value is "*.acx"</remarks>
        public string EncryptedFileFilter
        {
            get{ return _encryptedFileFilter; }
            set
            { 
                _encryptedFileFilter = value;
                ValidateFilters();
            }
        }

        /// <summary>
        /// Get/Set a flag indicating if the folder should be monitored for changes
        /// </summary>
        /// <remarks>The default value is false</remarks>
        public bool MonitorFolderForChanges
        {
            get{ return _monitorFolderForChanges; }
            set{ _monitorFolderForChanges = value; }
        }

        /// <summary>
        /// Flag indicating if unencrypted files should be processed
        /// </summary>
        internal bool ProcessUnEncryptedFiles
        {
            get{ return ( _unEncryptedFileFilter != null && _unEncryptedFileFilter.Length > 0 ); }
        }

        /// <summary>
        /// Flag indicating id encrypted files should be processed
        /// </summary>
        internal bool ProcessEncryptedFiles
        {
            get{ return ( _encryptedFileFilter != null && _encryptedFileFilter.Length > 0 ); }
        }

        /// <summary>
        /// Make sure the provided folder is valid
        /// </summary>
        private void ValidateFolder()
        {
            ArgumentValidator.ValidateNonEmptyString( _folder, "folder", this.GetType().Name );
            if( !Directory.Exists( _folder ) )
            {
                string errorMessage = string.Format( Strings.InvalidFolderFormat, _folder );
                ThrowArgumentException( errorMessage, "folder" );
            }
        }

        /// <summary>
        /// Make sure both filters are not empty
        /// </summary>
        private void ValidateFilters()
        {
            if( (_unEncryptedFileFilter == null || _unEncryptedFileFilter.Length == 0 ) && ( _encryptedFileFilter == null || _encryptedFileFilter.Length == 0 ) )
            {
                string errorMessage = Strings.BothEncryptedAndUnencryptedFileFiltersNullOrEmpty;
                ThrowArgumentException( errorMessage, "fileFilter" );
            }
        }

        /// <summary>
        /// Throw an argument exception
        /// </summary>
        /// <param name="errorMessage">The message to throw</param>
        /// <param name="argName">The name of the invalid argument</param>
        private void ThrowArgumentException( string errorMessage, string argName )
        {
            Assertions.Assert( false, errorMessage );
            EventLogger.WriteMessage( this.GetType().Name, errorMessage, MessageType.Error );
            throw new ArgumentException( errorMessage, argName );
        }
    }

}
