﻿using System;
using System.ServiceModel;
using System.Reflection;
using System.ServiceModel.Security;
using Sage.Diagnostics;

namespace Sage.ServiceModel
{
    public class RetryClientBase<TInterface> : IDisposable
        where TInterface : class
    {
        public delegate TInterface CreationFunction();

        public RetryClientBase(CreationFunction realProxyCreationFunction)
        {
            _rawProxyCreationFunction = realProxyCreationFunction;
        }

        public Double ProxyRetryTimeout
        {
            get { return _proxyAquireTimeoutMilliseconds; }
            set { _proxyAquireTimeoutMilliseconds = value; }
        }

        /// <summary>
        /// Dispose to support the classes that derive from this and need IDisposeable 
        /// </summary>
        /// <remarks>
        /// This may need to be upgraded to a full dispose pattern
        /// </remarks>
        public void Dispose()
        {
            Close();
        }

        public void Close()
        {
            if (_rawProxy != null)
            {
                try
                {
                    // http://blogs.msdn.com/b/jjameson/archive/2010/03/18/avoiding-problems-with-the-using-statement-and-wcf-service-proxies.aspx
                    ICommunicationObject commObject = _rawProxy as ICommunicationObject;
                    if (commObject.State == CommunicationState.Faulted)
                    {
                        commObject.Abort();
                        _rawProxy = null;
                    }
                    else if (commObject.State != CommunicationState.Closed)
                    {
                        commObject.Close();
                        _rawProxy = null;
                    }
                }
                catch (Exception ex)
                {
                    TraceException(ex);
                }
                finally
                {
                    if (_rawProxy != null)
                    {
                        DestroyRawProxy();
                    }
                }
            }
        }

        public void Abort()
        {
            if (_rawProxy != null)
            {
                DestroyRawProxy();
            }
        }

        protected Object RetvalCallRawProxy(Delegate d)
        {
            Object result = null;

            Exception lastException = null;
            Boolean successfulInvocation = false;
            Exception exceptionToRethrow = null;
            TimeSpan timeoutTimeSpan = TimeSpan.FromMilliseconds(_proxyAquireTimeoutMilliseconds);
            ProgressiveBackoffHelper progressiveBackoffHelper = new ProgressiveBackoffHelper();

            do
            {
                try
                {
                    progressiveBackoffHelper.DelayIfNeeded(_proxyAquireTimeoutMilliseconds);
                    result = d.DynamicInvoke();
                    successfulInvocation = true;
                }
                catch (TargetInvocationException ex) // Invoke() always throws this type
                {
                    lastException = ex.InnerException;

                    TraceException(ex);

                    // not a communication exception, throw it
                    if ((ex.InnerException as CommunicationException) == null)
                    {
                        exceptionToRethrow = ex.InnerException;
                    }

                    // the service threw an exception unlikely to be resolved by retrying, throw it
                    if ((ex.InnerException as MessageSecurityException) != null ||
                        (ex.InnerException as SecurityNegotiationException) != null ||
                        (ex.InnerException as FaultException) != null ||
                        (ex.InnerException as EndpointNotFoundException) != null ||
                        (ex.InnerException as SecurityAccessDeniedException) != null)
                    {
                        exceptionToRethrow = ex.InnerException;
                    }

                    // destroy the inner channel
                    DestroyRawProxy();

                    if (exceptionToRethrow != null)
                    {
                        throw exceptionToRethrow;
                    }
                }
            }
            while (!successfulInvocation && (progressiveBackoffHelper.ElapsedTime < timeoutTimeSpan));

            if (!successfulInvocation && (progressiveBackoffHelper.ElapsedTime >= timeoutTimeSpan))
            {
                throw new CommunicationFailureException(String.Format("Failed to obtain non-faulted channel before timeout expiration of {0} milliseconds. See inner exception for last exception caught in create channel loop.", _proxyAquireTimeoutMilliseconds), lastException);
            }

            return result;
        }

        protected void VoidCallRawProxy(Delegate d)
        {
            Exception lastException = null;
            Boolean successfulInvocation = false;
            Exception exceptionToRethrow = null;
            TimeSpan timeoutTimeSpan = TimeSpan.FromMilliseconds(_proxyAquireTimeoutMilliseconds);
            ProgressiveBackoffHelper progressiveBackoffHelper = new ProgressiveBackoffHelper();

            do
            {
                try
                {
                    progressiveBackoffHelper.DelayIfNeeded(_proxyAquireTimeoutMilliseconds);
                    d.DynamicInvoke();
                    successfulInvocation = true;
                }
                catch (TargetInvocationException ex) // Invoke() always throws this type
                {
                    lastException = ex.InnerException;

                    TraceException(ex);

                    // not a communication exception, throw it
                    if ((ex.InnerException as CommunicationException) == null)
                    {
                        exceptionToRethrow = ex.InnerException;
                    }

                    // the service threw an exception unlikely to be resolved by retrying, throw it
                    if ((ex.InnerException as MessageSecurityException) != null ||
                        (ex.InnerException as SecurityNegotiationException) != null ||
                        (ex.InnerException as FaultException) != null ||
                        (ex.InnerException as EndpointNotFoundException) != null ||
                        (ex.InnerException as SecurityAccessDeniedException) != null)
                    {
                        exceptionToRethrow = ex.InnerException;
                    }

                    // destroy the inner channel
                    DestroyRawProxy();

                    if (exceptionToRethrow != null)
                    {
                        throw exceptionToRethrow;
                    }
                }
            }
            while (!successfulInvocation && (progressiveBackoffHelper.ElapsedTime < timeoutTimeSpan));

            if (!successfulInvocation && (progressiveBackoffHelper.ElapsedTime >= timeoutTimeSpan))
            {
                throw new CommunicationFailureException(String.Format("Failed to obtain non-faulted channel before timeout expiration of {0} milliseconds. See inner exception for last exception caught in create channel loop.", _proxyAquireTimeoutMilliseconds), lastException);
            }
        }

        protected TInterface RawProxy
        {
            get
            {
                if (_rawProxy == null)
                {
                    _rawProxy = (TInterface)_rawProxyCreationFunction.DynamicInvoke();
                }

                if ((_rawProxy as ICommunicationObject).State == CommunicationState.Faulted)
                {
                    DestroyRawProxy();
                    _rawProxy = (TInterface)_rawProxyCreationFunction.DynamicInvoke();
                }

                return _rawProxy;
            }
        }

        private void DestroyRawProxy()
        {
            try
            {
                (_rawProxy as ICommunicationObject).Abort();
            }
            catch (Exception ex)
            {
                TraceException(ex);
            }
            finally
            {
                _rawProxy = null;
            }
        }

        private void TraceException(Exception ex)
        {
            if (ex != null)
            {
                VerboseTrace.WriteLine(null, "{0}{1}", ex.ToString(), ex.InnerException != null ? "\n\nInner exception:" : String.Empty);
                TraceException(ex.InnerException);
            }
        }

        protected delegate void VoidMethodInvoker();
        protected delegate object RetvalMethodInvoker();
        private TInterface _rawProxy;
        private CreationFunction _rawProxyCreationFunction;
        private Double _proxyAquireTimeoutMilliseconds = 10000; // 10 seconds
    }
}
