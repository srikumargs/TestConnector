using System;
using System.Text;
using System.Diagnostics;
using System.Reflection;
using System.Globalization;
using System.Collections;

namespace Sage.Diagnostics
{
    /// <summary>
    /// A helper class which is used by multiple listeners to construct the final message that will be traced.
    /// </summary>
    [TraceListenerIgnoreType]
    internal sealed class TraceMessageHelper
    {
        #region Constructors
        /// <summary>
        /// Private default constructor to prevent instantiation of static class.
        /// </summary>
        private TraceMessageHelper()
        {}
        #endregion

        #region Public members
        /// <summary>
        /// Create the final trace message that contains additional contextual information.
        /// </summary>
        /// <param name="messageBuilder">an object that will be used to return the final trace message result</param>
        /// <param name="messageData">a string representation of the encoded message data (written by Sage.Diagnostics.TraceMesageDataWriter)</param>
        /// <param name="configData">the configuration data that contains the current flags and options state</param>
        /// <param name="stackTrace">the stack trace of the call</param>
        public static TraceMessage ComposeMessage(string messageData, ConfigSectionData configData, StackTrace stackTrace)
        {
            ArrayList ignoreStackTraceTypenames = null;
            TraceMessageComposer.Flags flags = TraceMessageComposer.Flags.None;
            Int32 oid = 0;
            String mc = String.Empty;

            TraceMessageDataReader reader = new TraceMessageDataReader(messageData);
            if(null != configData)
            {
                if(configData.ShowDate)
                {
                    flags &= TraceMessageComposer.Flags.ShowDate;
                }

                if(configData.ShowTime)
                {
                    flags &= TraceMessageComposer.Flags.ShowTime;
                }

                if(configData.Show24Hour)
                {
                    flags &= TraceMessageComposer.Flags.Show24Hour;
                }

                if(configData.ShowMilliseconds)
                {
                    flags &= TraceMessageComposer.Flags.ShowMilliseconds;
                }

                if(configData.ShowProcessId)
                {
                    flags &= TraceMessageComposer.Flags.ShowProcessId;
                }

                if(configData.ShowThreadId)
                {
                    flags &= TraceMessageComposer.Flags.ShowThreadId;
                }

                if(configData.ShowAppDomainId)
                {
                    flags &= TraceMessageComposer.Flags.ShowAppDomainId;
                }

                if(configData.ShowObjectId && reader.ContainsData("OID"))
                {
                    flags &= TraceMessageComposer.Flags.ShowObjectId;
                    oid = Convert.ToInt32(reader.GetData("OID"), CultureInfo.InvariantCulture);
                }

                if(configData.ShowMessageCategory && reader.ContainsData("MC"))
                {
                    flags &= TraceMessageComposer.Flags.ShowMessageCategory;
                    mc = reader.GetData("MC");
                }

                if(configData.ShowTypeName)
                {
                    flags &= TraceMessageComposer.Flags.ShowTypeName;
                }

                if(configData.ShowMemberName)
                {
                    flags &= TraceMessageComposer.Flags.ShowMemberName;
                }

                if(configData.ShowAssemblyName)
                {
                    flags &= TraceMessageComposer.Flags.ShowAssemblyName;
                }

                if(configData.ShowFileLocation)
                {
                    flags &= TraceMessageComposer.Flags.ShowFileLocation;
                }

                ignoreStackTraceTypenames = configData.StackTraceIgnoreTypenames;
            }

            return TraceMessageComposer.ComposeMessage(ignoreStackTraceTypenames, stackTrace, flags, oid, mc, reader.Message);
        }
        #endregion
    }
}