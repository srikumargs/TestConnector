using System;
using System.Runtime.InteropServices;


namespace Sage.Reflection
{
    /// <summary>
    /// Generic property accessor for string named property value pairs
    /// </summary>
    [ComVisible(false)]
    public interface IStringProperty
	{
        /// <summary>
        /// Used to access the underlying property collection
        /// </summary>
        string this[string propName] { set; get; }
	}
}
