using System;
using System.Diagnostics;
using System.Text;

namespace Sage.Diagnostics
{
    /// <summary>
    /// A <see cref="System.Diagnostics.TraceListener"/> derivative which writes output via the OutputDebugString API.
    /// </summary>
    /// <remarks>
    /// This class provides services to automatically add contextual details to messages written using
    /// System.Diagnostics.Trace.
    /// </remarks>
    [TraceListenerIgnoreType]
    internal sealed class DebugOutputWriterTraceListener : DefaultTraceListener
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the DebugOutputWriterTraceListener.
        /// </summary>
        public DebugOutputWriterTraceListener() : base()
        {
        }
        #endregion

        #region Public members
        /// <summary>
        /// Writes a message to the listener.
        /// </summary>
        /// <param name="message">The message to write to the OutputDebugString.</param>
        public override void Write(string message) 
        {   
            base.Write(ComposeMessage(message));
        }

        /// <summary>
        /// Writes the output to the OutputDebugString method followed by a carriage return and a line feed (\r\n).
        /// </summary>
        /// <param name="message">The message to write to the OutputDebugString.</param>
        public override void WriteLine(string message) 
        {   
            base.WriteLine(ComposeMessage(message));
        } 
        #endregion

        #region Private members
        private string ComposeMessage(string messageData) 
        {
            StringBuilder  messageBuilder = new StringBuilder();
            StackTrace     stackTrace     = null;

            ConfigSectionData data = (ConfigSectionData) System.Configuration.ConfigurationSettings.GetConfig(Name + "ConfigSection");

            // Only retrieve the stack trace if we are going to need it.
            if(null != data && (data.ShowTypeName || data.ShowMemberName || data.ShowMemberSignature || data.ShowFileLocation || data.ShowAssemblyName))
            {
                stackTrace = new StackTrace(data.ShowFileLocation); // only need to capture the file name, line number, and column number if ShowFileLocation is set
            }

            TraceMessage message = TraceMessageHelper.ComposeMessage(messageData, data, stackTrace);

            return message.FullMessage;
        }
        #endregion
    }
}