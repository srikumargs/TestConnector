#if DEBUG
using NUnit.Framework;
using System;
using System.Runtime.InteropServices;

namespace Sage.Diagnostics.NUnit
{
	/// <summary>
	/// Class for testing the ArgumentsValidator class
	/// </summary>
    [TestFixture]
    [ ComVisible( false ) ]
	public class ArgumentValidatorTests
	{
        static ArgumentValidatorTests()
        {
            //Sage.Configuration.LibraryManager.InitializeLibraries(
            //    System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory,
            //        Sage.Configuration.LibraryManager.LibraryManifestFolderName ) );
        }


        /// <summary>
        /// Constructor
        /// </summary>
		public ArgumentValidatorTests()
		{
			
		}

        /// <summary>
        /// Test passing a null reference to the ValidateNonNullReference method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentNullException) ) ]
        public void TestValidateNonNullReferenceWithNull()
        {
            ArgumentValidator.ValidateNonNullReference( null, "testArgument", "ArgumentsValidatorTest" );
        }

        /// <summary>
        /// Test passing a non-null reference to the ValidateNonNullReference method
        /// </summary>
        [Test]
        public void TestValidateNonNullReferenceWithNonNull()
        {
            string testArgument = "TheJoker";
            ArgumentValidator.ValidateNonNullReference( testArgument, "testArgument", "ArgumentsValidatorTest" );
        }

        /// <summary>
        /// Test passing a null string to the ValidateNonEmptyString method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentNullException) ) ]
        public void TestValidateNonEmptyStringWithNull()
        {
            ArgumentValidator.ValidateNonEmptyString( null, "testArgument", "ArgumentsValidatorTest" );
        }
        
        /// <summary>
        /// Test passing an empty string to the ValidateNonEmptyString method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentException) ) ]
        public void TestValidateNonEmptyStringWithEmpty()
        {
            string testArgument = string.Empty;
            ArgumentValidator.ValidateNonEmptyString( testArgument, "testArgument", "ArgumentsValidatorTest" );
        }

        /// <summary>
        /// Test passing an empty string to the ValidateNonEmptyString method
        /// </summary>
        [Test]
        public void TestValidateNonEmptyStringWithNonEmpty()
        {
            string testArgument = "TheJoker";
            ArgumentValidator.ValidateNonEmptyString( testArgument, "testArgument", "ArgumentsValidatorTest" );
        }

        /// <summary>
        /// Test passing an empty string to the validateMaxStringLength method
        /// </summary>
        [Test]
        public void TestMaxLengthStringWithNull()
        {
            ArgumentValidator.ValidateMaxStringLength( null, "testArgument", "ArgumentsValidatorTest", 9 );
        }

        /// <summary>
        /// Test passing a long string to the validateMaxStringLength method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentOutOfRangeException) ) ]
        public void TestMaxLengthStringWithLongString()
        {
            String testArgument = "12345678910";
            ArgumentValidator.ValidateMaxStringLength( testArgument, "testArgument", "ArgumentsValidatorTest", 9 );
        }
        
        /// <summary>
        /// Test passing a valid string to the validateMaxStringLength method
        /// </summary>
        [Test]
        public void TestMaxLengthStringWithValidString()
        {
            String testArgument = "123456789";
            ArgumentValidator.ValidateMaxStringLength( testArgument, "testArgument", "ArgumentsValidatorTest", 9 );
        }

        /// <summary>
        /// Test passing a low value to the ValidateMinIntegerValue method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentOutOfRangeException) ) ]
        public void TestMinIntegerValueWithLowValue()
        {
            int testArgument = 4;
            ArgumentValidator.ValidateMinIntegerValue( testArgument, "testArgument", "ArgumentsValidatorTest", 5 );
        }

        /// <summary>
        /// Test passing a valid value to the ValidateMinIntegerValue method
        /// </summary>
        [Test]
        public void TestMinIntegerValueWithValidValue()
        {
            int testArgument = 6;
            ArgumentValidator.ValidateMinIntegerValue( testArgument, "testArgument", "ArgumentsValidatorTest", 5 );
        }

        /// <summary>
        /// Test passing a high value to the ValidateMaxIntegerValue method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentOutOfRangeException) ) ]
        public void TestMaxIntegerValueWithHighValue()
        {
            int testArgument = 6;
            ArgumentValidator.ValidateMaxIntegerValue( testArgument, "testArgument", "ArgumentsValidatorTest", 5 );
        
        }

        /// <summary>
        /// Test passing a valid value to the ValidateMaxIntegerValue method
        /// </summary>
        [Test]
        public void TestMaxIntegerValueWithValidValue()
        {
            int testArgument = 3;
            ArgumentValidator.ValidateMaxIntegerValue( testArgument, "testArgument", "ArgumentsValidatorTest", 5 );
        
        }

        /// <summary>
        /// Test passing a low value to the ValidateIntegerRange method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentOutOfRangeException) ) ]
        public void TestIntegerRangeWithLowValue()
        {
            int testArgument = 3;
            ArgumentValidator.ValidateIntegerRange( testArgument, "testArgument", "ArgumentsValidatorTest", 5, 10 );
        }

        /// <summary>
        /// Test passing a high value to the ValidateIntegerRange method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentOutOfRangeException) ) ]
        public void TestIntegerRangeWithHighValue()
        {
            int testArgument = 11;
            ArgumentValidator.ValidateIntegerRange( testArgument, "testArgument", "ArgumentsValidatorTest", 5, 10 );
        }

        /// <summary>
        /// Test passing a valid value to the ValidateIntegerRange method
        /// </summary>
        [Test]
        public void TestIntegerRangeWithValidValue()
        {
            int testArgument = 8;
            ArgumentValidator.ValidateIntegerRange( testArgument, "testArgument", "ArgumentsValidatorTest", 5, 10 );
        }

        /// <summary>
        /// Test passing a valid value to the ValidateIsInstanceOfType method
        /// </summary>
        [Test]
        public void TestValidateIsInstanceOfTypeWithCorrectType()
        {
            ApplicationException exception = new ApplicationException();
            ArgumentValidator.ValidateIsInstanceOfType( exception, "testArgument", "ArgumentsValidatorTest", typeof( ApplicationException ) );
            ArgumentValidator.ValidateIsInstanceOfType( exception, "testArgument", "ArgumentsValidatorTest", typeof( Exception ) );
        }

        /// <summary>
        /// Test passing an invalid value to the ValidateIsInstanceOfType method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentException) ) ]
        public void TestValidateIsInstanceOfTypeWithIncorrectType()
        {
            ApplicationException exception = new ApplicationException();
            ArgumentValidator.ValidateIsInstanceOfType( exception, "testArgument", "ArgumentsValidatorTest", typeof( Enum ) );
        }

        /// <summary>
        /// Test passing a null value to the ValidateIsInstanceOfType method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentException) ) ]
        public void TestValidateIsInstanceOfTypeWithNull()
        {
            ArgumentValidator.ValidateIsInstanceOfType( null, "testArgument", "ArgumentsValidatorTest", typeof( Enum ) );
        }

        /// <summary>
        /// Test passing a valid value to the ValidateIsSubclassOfType method
        /// </summary>
        [Test]
        public void TestValidateIsSubclassOfTypeWithCorrectType()
        {
            ApplicationException exception = new ApplicationException();
            ArgumentValidator.ValidateIsSubclassOfType( exception.GetType(), "testArgument", "ArgumentsValidatorTest", typeof( Exception ) );
        }

        /// <summary>
        /// Test passing an invalid value to the ValidateIsSubclassOfType method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentException) ) ]
        public void TestValidateIsSubclassOfTypeWithIncorrectType()
        {
            ApplicationException exception = new ApplicationException();
            ArgumentValidator.ValidateIsSubclassOfType( exception.GetType(), "testArgument", "ArgumentsValidatorTest", typeof( ApplicationException ) );
        }

        /// <summary>
        /// Test passing a null value to the ValidateIsSubclassOfType method
        /// </summary>
        [Test]
        [ ExpectedException( typeof(ArgumentNullException) ) ]
        public void TestValidateIsSubclassOfTypeWithNull()
        {
            ArgumentValidator.ValidateIsSubclassOfType( null, "testArgument", "ArgumentsValidatorTest", typeof( Enum ) );
        }
    }
}

#endif // DEBUG