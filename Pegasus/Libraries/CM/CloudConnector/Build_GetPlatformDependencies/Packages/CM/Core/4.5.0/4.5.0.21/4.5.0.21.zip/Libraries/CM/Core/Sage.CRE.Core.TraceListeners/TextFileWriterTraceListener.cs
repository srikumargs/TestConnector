using System;
using System.Diagnostics;
using System.Text;
using System.IO;

namespace Sage.Diagnostics 
{
    /// <summary>
    /// A <see cref="System.Diagnostics.TraceListener"/> derivative which writes output to a textual log file.
    /// </summary>
    /// <remarks>
    /// This class provides services to automatically add contextual details to messages written using
    /// System.Diagnostics.Trace.
    /// </remarks>
    [TraceListenerIgnoreType]
    internal sealed class TextFileWriterTraceListener : TextWriterTraceListener 
    { 
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the TextFileWriterTraceListener class with the specified name, using the stream as the recipient of the debugging and tracing output.
        /// </summary>
        /// <param name="stream">A Stream that represents the stream the TextFileWriterTraceListener writes to.</param>
        /// <param name="name">The name of the new instance.</param>
        public TextFileWriterTraceListener(System.IO.Stream stream, string name) : base(stream, name) 
        {
        }

        /// <summary>
        /// Initializes a new instance of the TextFileWriterTraceListener class, using the stream as the recipient of the debugging and tracing output.
        /// </summary>
        /// <param name="stream">A Stream that represents the stream the TextFileWriterTraceListener writes to. </param>
        public TextFileWriterTraceListener(System.IO.Stream stream) : base(stream)
        {
        }

        /// <summary>
        /// Initializes a new instance of the TextFileWriterTraceListener class with the specified name, using the file as the recipient of the debugging and tracing output.
        /// </summary>
        /// <param name="fileName">The name of the file the TextFileWriterTraceListener writes to. </param>
        /// <param name="name">The name of the new instance. </param>
        public TextFileWriterTraceListener(string fileName, string name) : this(fileName) // intentionally call our own override rather than base(fileName, name)
        {
            this.Name = name;
        }

        /// <summary>
        /// Initializes a new instance of the TextFileWriterTraceListener class, using the file as the recipient of the debugging and tracing output.
        /// </summary>
        /// <param name="fileName">The name of the file the TextFileWriterTraceListener writes to.</param>
        public TextFileWriterTraceListener(string fileName) // do not call base(fileName) so that we can override the default construction behavior
        {
            // Override the default behavior that creates a munged log file name for subordinate app domains using the 
            // specified file name and a guid.  Instead, we create more meaningful names using the friendly name of the
            // current app domain.
            string fixedUpFileName = String.Format("{0}{1}[{2}#{3}]{4}", Path.GetDirectoryName(fileName), Path.GetFileNameWithoutExtension(fileName), AppDomain.CurrentDomain.SetupInformation.ApplicationName, AppDomain.CurrentDomain.FriendlyName, Path.GetExtension(fileName));
            string originalFixedUpFileName = fixedUpFileName;
            while(true)
            {
                try
                {
                    this.Writer = new StreamWriter(fixedUpFileName, true);
                    break;
                }
                catch(IOException)
                {
                    fixedUpFileName = string.Format("{0}-{1:d2}-{2:d2}-{3:d2}", originalFixedUpFileName, DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
                }
            }
        }

        /// <summary>
        /// Initializes a new instance of the TextFileWriterTraceListener class with the specified name, using the specified writer as recipient of the tracing or debugging output.
        /// </summary>
        /// <param name="writer">A TextWriter that receives the output from the TextFileWriterTraceListener. </param>
        /// <param name="name">The name of the new instance. </param>
        public TextFileWriterTraceListener(System.IO.TextWriter writer, string name) : base(writer, name)
        {
        }

        /// <summary>
        /// Initializes a new instance of the TextFileWriterTraceListener class using the specified writer as recipient of the tracing or debugging output.
        /// </summary>
        /// <param name="writer">A TextWriter that receives the output from the TextFileWriterTraceListener.</param>
        public TextFileWriterTraceListener(System.IO.TextWriter writer) : base(writer)
        {
        }
        #endregion

        #region Public members
        /// <summary>
        /// Writes a message to the listener.
        /// </summary>
        /// <param name="message">The message to write to the text file.</param>
        public override void Write(string message) 
        {
            base.Write(ComposeMessage(message));
        }

        /// <summary>
        /// Writes the output to the OutputDebugString method followed by a carriage return and a line feed (\r\n).
        /// </summary>
        /// <param name="message">The message to write to the text file.</param>
        public override void WriteLine(string message) 
        {
            base.WriteLine(ComposeMessage(message));
        } 
        #endregion

        #region Private members
        private string ComposeMessage(string messageData) 
        {
            StackTrace     stackTrace     = null;

            ConfigSectionData data = (ConfigSectionData) System.Configuration.ConfigurationSettings.GetConfig(Name + "ConfigSection");

            // Only retrieve the stack trace if we are going to need it.
            if(null != data && (data.ShowTypeName || data.ShowMemberName || data.ShowMemberSignature || data.ShowFileLocation || data.ShowAssemblyName))
            {
                stackTrace = new StackTrace(data.ShowFileLocation); // only need to capture the file name, line number, and column number if ShowFileLocation is set
            }

            TraceMessage message = TraceMessageHelper.ComposeMessage(messageData, data, stackTrace);

            return message.FullMessage;
        }
        #endregion
    }
}