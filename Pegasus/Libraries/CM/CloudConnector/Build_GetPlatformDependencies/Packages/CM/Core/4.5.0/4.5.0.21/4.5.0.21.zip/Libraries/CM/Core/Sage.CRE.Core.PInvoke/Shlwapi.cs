using System;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Sage.PInvoke
{
    /// <summary>
    /// Summary description for CShlwapi.
    /// </summary>
    public static class Shlwapi
    {
        public static bool PathIsNetworkPath([In] String pszPath1)
        {
            return PInvoke.SafeNativeMethods.PathIsNetworkPath(pszPath1);
        }

    }
}
