using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Xml.XPath;
using System.Collections.Specialized;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Net;

using Sage.Remoting;
using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Class for remoting configuration and unconfiguration
    /// </summary>
    [ComVisible(false)]
    public class RemotableObjectHost : MarshalByRefObject
    {
        /// <summary>
        /// Config flags
        /// </summary>
        [Flags]
        public enum ConfigFlags
        {
            /// <summary>
            /// Excercise no configure/unconfigure options
            /// </summary>
            /// <remarks>
            /// This is default value the runtime automatically initializes any OperatingMode instance to
            /// </remarks>
            None = 0,

            /// <summary>
            /// Configure/unconfigure the remoting channel
            /// </summary>
            /// <remarks>
            /// This is the first step in setting up a RemotableObjectHost.  This step must occur before all other steps.  This one must be undone after all the others.
            /// </remarks>
            RemotingChannel = 1,

            /// <summary>
            /// Configure/unconfigure the collection of remotable objects
            /// </summary>
            /// <remarks>
            /// This is the second step in setting up a RemotableObjectHost.  The RemotingChannel step must occur before this one.  This one must be undone before the RemotingChannel is.
            /// </remarks>
            ObjectCollection = 2,

            /// <summary>
            /// Configure/unconfigure the registered uri's
            /// </summary>
            /// <remarks>
            /// This is the third (and final) step in setting up a RemotableObjectHost.  All other steps must occur before this one.  This one must be undone before all the others.
            /// </remarks>
            UriRegistration = 4,

            /// <summary>
            /// Shortcut for all configure/unconfigure options
            /// </summary>
            All = (RemotingChannel | ObjectCollection | UriRegistration)
        }

        #region Constructors
        /// <summary>
        /// Disable the default constructor
        /// </summary>
        private RemotableObjectHost()
        {
        }

        /// <summary>
        /// cache the root node for the RemoteHost
        /// </summary>
        public RemotableObjectHost(XPathNavigator remotableObjectHostNavigator, string hostId)
        {
            _hostId = hostId;
            _remotableObjectHostNavigator = remotableObjectHostNavigator;

            CreateUrlWriter();
        }

        /// <summary>
        /// cache the root node for the RemoteHost
        /// </summary>
        public RemotableObjectHost(XPathNavigator remotableObjectHostNavigator)
            : this(remotableObjectHostNavigator, null)
        {
        }
        #endregion

        #region Public properties
        /// <summary>
        /// Gets the remotable object urls.
        /// </summary>
        /// <value>The remotable object urls.</value>
        public StringCollection RemotableObjectUrls
        {
            get
            {
                StringCollection result = new StringCollection();

                lock(_remotableObjects)
                {
                    foreach(RemotableObject o in _remotableObjects)
                    {
                        result.Add(o.Url);
                    }
                }

                return result;
            }
        }

        /// <summary>
        /// Gets the state of the current config.
        /// </summary>
        /// <value>The state of the current config.</value>
        public ConfigFlags CurrentConfigState
        {
            get
            {
                return _currentConfigState;
            }
        }
        #endregion

        #region Public methods
        /// <summary>
        /// force singleton lifetime to be infinite
        /// </summary>
        /// <returns></returns>
        public override object InitializeLifetimeService()
        {
            return null;
        }

        /// <summary>
        /// configure channels and register marshaled and unmarshaled objects
        /// </summary>
        public void Configure()
        {
            Configure(ConfigFlags.All);
        }

        /// <summary>
        /// configure channels and register marshaled and unmarshaled objects
        /// </summary>
        /// <param name="configFlags"></param>
        public void Configure(ConfigFlags configFlags)
        {
            Assertions.Assert(((configFlags | _currentConfigState) == (ConfigFlags.RemotingChannel | ConfigFlags.ObjectCollection | ConfigFlags.UriRegistration)) ||
                              ((configFlags | _currentConfigState) == (ConfigFlags.RemotingChannel | ConfigFlags.ObjectCollection)) ||
                              ((configFlags | _currentConfigState) == ConfigFlags.RemotingChannel) ||
                              ((configFlags | _currentConfigState) == ConfigFlags.None));

            if((_currentConfigState & ConfigFlags.RemotingChannel) == 0 && (configFlags & ConfigFlags.RemotingChannel) != 0)
            {
                ConfigureChannels();
                _currentConfigState |= ConfigFlags.RemotingChannel;
            }

            if((_currentConfigState & ConfigFlags.ObjectCollection) == 0 && (configFlags & ConfigFlags.ObjectCollection) != 0)
            {
                PopulateObjectCollection();
                _currentConfigState |= ConfigFlags.ObjectCollection;
            }


            if((_currentConfigState & ConfigFlags.UriRegistration) == 0 && (configFlags & ConfigFlags.UriRegistration) != 0)
            {
                RegisterObjects();
                _currentConfigState |= ConfigFlags.UriRegistration;
            }
        }

        /// <summary>
        /// Unconfigure channels and cleanup remotable objects
        /// </summary>
        public void UnConfigure()
        {
            UnConfigure(ConfigFlags.All);
        }

        /// <summary>
        /// Unconfigure channels and cleanup remotable objects
        /// </summary>
        /// <param name="configFlags"></param>
        public void UnConfigure(ConfigFlags configFlags)
        {
            Assertions.Assert(((~configFlags & _currentConfigState) == (ConfigFlags.RemotingChannel | ConfigFlags.ObjectCollection | ConfigFlags.UriRegistration)) ||
                              ((~configFlags & _currentConfigState) == (ConfigFlags.RemotingChannel | ConfigFlags.ObjectCollection)) ||
                              ((~configFlags & _currentConfigState) == ConfigFlags.RemotingChannel) ||
                              ((~configFlags & _currentConfigState) == ConfigFlags.None));

            if((_currentConfigState & ConfigFlags.UriRegistration) != 0 && (configFlags & ConfigFlags.UriRegistration) != 0)
            {
                UnRegisterObjects();
                _currentConfigState &= ~ConfigFlags.UriRegistration;
            }

            if((_currentConfigState & ConfigFlags.ObjectCollection) != 0 && (configFlags & ConfigFlags.ObjectCollection) != 0)
            {
                ClearObjectCollection();
                _currentConfigState &= ~ConfigFlags.ObjectCollection;
            }

            if((_currentConfigState & ConfigFlags.RemotingChannel) != 0 && (configFlags & ConfigFlags.RemotingChannel) != 0)
            {
                UnConfigureChannels();
                _currentConfigState &= ~ConfigFlags.RemotingChannel;
            }
        }
        #endregion

        #region Protected properties
        /// <summary>
        /// Gets the host id.
        /// </summary>
        /// <value>The host id.</value>
        protected string HostId
        {
            get
            {
                return _hostId;
            }
        }

        /// <summary>
        /// Gets the remotable object host navigator.
        /// </summary>
        /// <value>The remotable object host navigator.</value>
        protected XPathNavigator RemotableObjectHostNavigator
        {
            get
            {
                return _remotableObjectHostNavigator;
            }
        }

        /// <summary>
        /// Gets the URL writer.
        /// </summary>
        /// <value>The URL writer.</value>
        protected IUrlWriter UrlWriter
        {
            get
            {
                return _urlWriter;
            }
        }
        #endregion

        #region Protected methods
        /// <summary>
        /// Creates the URL writer.
        /// </summary>
        protected virtual void CreateUrlWriter()
        {
            XPathNodeIterator iter = _remotableObjectHostNavigator.SelectDescendants("TypeInstance", "", false);
            while(iter.MoveNext())
            {
                if(iter.Current.GetAttribute("TypeLookup", "") == "IUrlWriter")
                {
                    string type = iter.Current.GetAttribute("QualifiedTypeName", "");
                    string assem = iter.Current.GetAttribute("Assembly", "");
                    TypeFactory factory = new TypeFactory(new TypeReader(type, assem, string.Empty));
                    _urlWriter = (IUrlWriter) factory.GetLocalObject();
                    break;
                }
            }
        }


        /// <summary>
        /// Set up the Channels speced in the config
        /// </summary>
        protected virtual void ConfigureChannels()
        {
            XPathNodeIterator iter = _remotableObjectHostNavigator.SelectDescendants("Channel", "", false);
            while(iter.MoveNext())
            {
                string chanRef = iter.Current.GetAttribute("Ref", "");
                string chanName = iter.Current.GetAttribute("Name", "");
                string useHostId = iter.Current.GetAttribute("UseHostId", "");
                string port = iter.Current.GetAttribute("Port", "");
                string pipeName = iter.Current.GetAttribute("Pipe", "");
                string useMachineName = iter.Current.GetAttribute("UseMachineName", "");
                string isSecured = iter.Current.GetAttribute("IsSecured", "");
                string cryptoAlgorithmName = iter.Current.GetAttribute("CryptoAlgorithmName", "");
                string keyFileUrl = iter.Current.GetAttribute("KeyFileUrl", "");
                string keyAsBase64 = iter.Current.GetAttribute("KeyAsBase64", "");


                IChannel chan = ChannelServices.GetChannel(chanName);
                if(chan == null)
                {
                    if(chanRef == "tcp" && port.Length > 0)
                    {
                        if (!String.IsNullOrEmpty(cryptoAlgorithmName))
                        {
                            if (!String.IsNullOrEmpty(keyFileUrl))
                            {
                                ChannelRegistrar.RegisterEncryptedTcpServerWithClientCallbackChannel(chanName, Convert.ToInt32(port), null, cryptoAlgorithmName, Sage.Configuration.PathRegistrar.ResolveUrl(keyFileUrl));
                            }
                            else
                            {
                                ChannelRegistrar.RegisterEncryptedTcpServerWithClientCallbackChannel(chanName, Convert.ToInt32(port), null, cryptoAlgorithmName, Convert.FromBase64String(keyAsBase64));
                            }
                        }
                        else
                        {
                            ChannelRegistrar.RegisterTcpServerWithCallback(chanName, Convert.ToInt32(port), (isSecured == "true") ? true : false);
                        }
                    }
                    else if (chanRef == "pipe")
                    {
                        if (useHostId == "true")
                        {
                            pipeName = string.Format(pipeName, _hostId);
                        }

                        if (useMachineName == "true")
                        {
                            // Environment.MachineName is the same as the NetBIOS name of local computer (the COMPUTERNAME environment
                            // variable) not the DNS host name.  This value is always truncated to 15 characters.  Consequently, we
                            // cannot compare this against our DNS host name.  Dns.GetHostName() give us what we want.

                            ListDictionary clientPropBag = new ListDictionary();
                            clientPropBag.Add("machine", Dns.GetHostName());

                            ListDictionary serverPropBag = new ListDictionary();
                            serverPropBag.Add("machine", Dns.GetHostName());
                            serverPropBag.Add("name", chanName);
                            serverPropBag.Add("pipe", pipeName);

                            ChannelRegistrar.RegisterPipe(clientPropBag, serverPropBag);

                            VerboseTrace.WriteLine(this, "Registering Client/Server PipeChannel: machine={0}, channelname={1}, pipename={2}", Environment.MachineName, chanName, pipeName);
                        }
                        else
                        {
                            ListDictionary clientPropBag = new ListDictionary();

                            ListDictionary serverPropBag = new ListDictionary();
                            serverPropBag.Add("name", chanName);
                            serverPropBag.Add("pipe", pipeName);
                            ChannelRegistrar.RegisterPipe(clientPropBag, serverPropBag);

                            VerboseTrace.WriteLine(this, "Registering PipeChannel: channelname={0}, pipename={1}", chanName, pipeName);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Populates the object collection.
        /// </summary>
        protected virtual void PopulateObjectCollection()
        {
            PopulateObjectCollection("Wellknown", new RemotableObjectFactory(_remotableObjectHostNavigator, _hostId, _urlWriter));
        }

        /// <summary>
        /// Register the well-known server types
        /// </summary>
        protected virtual void PopulateObjectCollection(string element, RemotableObjectFactory factory)
        {
            XPathNodeIterator iter = _remotableObjectHostNavigator.SelectDescendants(element, "", false);

            lock(_remotableObjects)
            {
                while(iter.MoveNext())
                {
                    _remotableObjects.Add(factory.Create(iter.Current.Clone()));
                }
            }
        }

        /// <summary>
        /// Registers the objects.
        /// </summary>
        protected virtual void RegisterObjects()
        {
            lock(_remotableObjects)
            {
                foreach(RemotableObject obj in _remotableObjects)
                {
                    obj.Connect();
                    obj.Publish();
                }
            }
        }

        /// <summary>
        /// Uns the register objects.
        /// </summary>
        protected virtual void UnRegisterObjects()
        {
            lock(_remotableObjects)
            {
                foreach(RemotableObject obj in _remotableObjects)
                {
                    obj.UnPublish();
                    obj.Disconnect();
                }
            }
        }

        /// <summary>
        /// Disconnect an unpublish the well known types
        /// </summary>
        protected virtual void ClearObjectCollection()
        {
            lock(_remotableObjects)
            {
                foreach(object o in _remotableObjects)
                {
                    (o as IDisposable).Dispose();
                }

                _remotableObjects.Clear();
            }
        }

        /// <summary>
        /// Traces the channels.
        /// </summary>
        protected virtual void TraceChannels()
        {
            IChannel[] chans = ChannelServices.RegisteredChannels;
            foreach(IChannel chan in chans)
            {
                IChannelReceiver rec = chan as IChannelReceiver;
                if(rec != null)
                {
                    IChannelDataStore cds = (IChannelDataStore) rec.ChannelData;
                    if(cds != null)
                    {
                        foreach(string s in cds.ChannelUris)
                        {
                            VerboseTrace.WriteLine(this, "Channel Uri: {0}", s);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Tear down registered channels
        /// </summary>
        protected virtual void UnConfigureChannels()
        {
            ChannelRegistrar.UnregisterTcp();
            ChannelRegistrar.UnregisterPipe();
        }
        #endregion

        #region Private fields
        // Host Identifier
        private string _hostId;

        // Node for the Remote Host schema
        private XPathNavigator _remotableObjectHostNavigator;

        // Used for all url persistence under this remotable object host
        private IUrlWriter _urlWriter = new NullUrlWriter();

        // Container of all published objects
        private ArrayList _remotableObjects = new ArrayList();

        private ConfigFlags _currentConfigState; //= ConfigFlags.None; (automatically initialized by runtime)
        #endregion
    }
}
