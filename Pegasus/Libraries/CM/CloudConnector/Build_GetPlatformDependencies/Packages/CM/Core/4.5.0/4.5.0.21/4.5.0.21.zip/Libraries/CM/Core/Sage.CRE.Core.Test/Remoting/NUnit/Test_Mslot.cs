#if DEBUG
using System;
using System.Runtime.InteropServices;
using System.Threading;

using NUnit.Framework;


using Sage.Remoting;

namespace Sage.Remoting.NUnit
{
    /// <summary>
    /// Test the the mailsot wrapper
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class Test_MSlot
    {
        /// <summary>
        /// Test getting a mailsot msg
        /// </summary>
        [Test]
        public void GetLocalMailslotMsgTest()
        {
            MailSlotServer server = new MailSlotServer();
            server.CreateMailslot("foozle");

            MailSlotClient client = new MailSlotClient();
            client.CreateLocal("foozle");
            client.WriteSlot("This is my test");

            int size, count;
            Assert.IsTrue(server.IsMessagePending(out size, out count));
            Assert.AreEqual(1, count);
            string msg = server.GetMessage(size);
            Assert.AreEqual("This is my test", msg);

            client.Dispose();
            server.Dispose();
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void StartLocalServer()
        {
            MailSlotServer server = new MailSlotServer();
            server.CreateMailslot("XMACHINE");

            while (true)
            {
                int size, count;
                if (server.IsMessagePending(out size, out count))
                {
                    Assert.AreEqual(1, count);
                    string msg = server.GetMessage(size);
                    Assert.AreEqual("This is my test", msg);
                    Console.WriteLine("Got message: " + msg);
                    break;
                }
                else
                {
                    Thread.Sleep(100);
                }
            }

            server.Dispose();
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void StartLocalClient()
        {
            MailSlotClient client = new MailSlotClient();
            client.CreateLocal("XMACHINE");
            client.WriteSlot("This is my test");

            client.Dispose();
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void StartBroadcastClient()
        {
            MailSlotClient client = new MailSlotClient();
            client.CreateBroadcast("XMACHINE");
            client.WriteSlot("This is my test");

            client.Dispose();
        }

    }
}

#endif // DEBUG