using System;
using System.Collections.Generic;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Creates a file using the Reversible Action pattern.
    /// 
    /// </summary>
    public class FileCreate : ReversibleActionBase
    {
        /// <summary>
        /// Create a single file.
        /// </summary>
        /// <param name="fileName">The full name of the file to create.</param>
        public FileCreate(string fileName)
        {
            _filesToCreate.Add(fileName);
        }

        /// <summary>
        /// Creates a set of files.
        /// </summary>
        /// <param name="fileNames">The files to create.</param>
        public FileCreate(System.Collections.ObjectModel.Collection<string> fileNames)
        {
            _filesToCreate = fileNames;
        }

        #region Protected methods
        /// <summary>
        /// Create the file(s).
        /// </summary>
        public override void Forward()
        {
            base.Forward();
            _filesCreated.Clear();
            foreach (string filename in _filesToCreate)
            {
                System.IO.File.Create(filename).Close();
                _filesCreated.Add(filename);
            }
        }

        /// <summary>
        /// Undo the creation of the file(s).
        /// </summary>
        public override void Reverse()
        {
            base.Reverse();
            foreach (string filename in _filesCreated)
            {
                if (System.IO.File.Exists(filename)) System.IO.File.Delete(filename);
            }
            _filesCreated.Clear();
        }

        #endregion

        #region Private members
        private System.Collections.ObjectModel.Collection<string> _filesToCreate = new System.Collections.ObjectModel.Collection<string>();
        private System.Collections.ObjectModel.Collection<string> _filesCreated = new System.Collections.ObjectModel.Collection<string>();
        #endregion
    }
}
