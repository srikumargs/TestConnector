using System;
using System.Threading;

namespace Sage.Threading
{
    /// <summary>
    /// This interface is intended for the thread managed by an instance of a TheadManager
    /// The managed thead uses this interface to tell if someone has requested that the
    /// thead cancel itself.
    /// </summary>
    [System.Runtime.InteropServices.ComVisible(false)]
    public interface ICancelableThread
    {
        /// <summary>
        /// This method will return true if the thread has been asked to cancel.
        /// This method is intended to be called periodically by the managed thread
        /// to tell if the thead should teminate itself early.
        /// </summary>
        /// <returns></returns>
        bool HasThreadBeenAskedToCancel();
    }

	/// <summary>
    /// Use this class to invoke and cancel an operation in a thread.
    /// </summary>
    [System.Runtime.InteropServices.ComVisible(false)]
    [CLSCompliant(false)]
    public abstract class ThreadManager : ICancelableThread, IDisposable
	{
        /// <summary>
        /// The contained thread
        /// </summary>
        protected Thread _thread = null;
        
        // The _terminateThreadEvent field is shared between the main thread and
        // the validation thread.  Be sure to lock the object instance prior to using it.
        private ManualResetEvent _terminateThreadEvent = null;
        // _unstarted equals true if Thread.Start has never been called on the thread.
        // _unstarted = false does not mean that the thread is running, the thread may have stopped.
        private bool _unstarted = true;
        private bool _disposed = false;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Object">The object on which the operation method exists</param>
        public ThreadManager(object Object)
		{
            _terminateThreadEvent = new ManualResetEvent(false);
            CreateThread(Object);
        }

        /// <summary>
        /// Destructor
        /// </summary>
        ~ThreadManager()
        {
            Dispose(false);
        }

        /// <summary>
        /// This method must be overridden - it should create and initialize _thread
        /// </summary>
        /// <param name="Object"></param>
        protected abstract void CreateThread(object Object);

        /// <summary>
        /// Invoke the thread in a background thread.  Note: no thread will be
        /// started if one is already running.  This method returns immediately
        /// </summary>
        public void Invoke()
        {
            // don't start the thread if it's already running
            if (!ThreadRunning())
            {
                lock (_terminateThreadEvent)
                {
                    _terminateThreadEvent.Reset(); // initialze the terminateThreadEvent to not set
                }
                _thread.Start();
                _unstarted = false;
            }
            else
            {
                throw new InvalidOperationException("The thread is currently running, it cannot be invoked again.");
            }
        }

        /// <summary>
        /// Cancel the thread.  This method returns immediately.  However,
        /// canceling the process may take a few seconds.  Use the ThreadRunning 
        /// method to tell whether or not the thread has terminated.
        /// </summary>
        public void Cancel()
        {
            // only cancel the thread if it's running
            if (ThreadRunning())
            {
                lock(_terminateThreadEvent)
                {
                    _terminateThreadEvent.Set();
                }
            }
        }

        /// <summary>
        /// This method returns true if the thread is running and false if it is not.
        /// </summary>
        /// <returns>true if the thread is running, otherwise false</returns>
        public bool ThreadRunning()
        {
            bool running = true;
            // You cannot invoke Thread.Join on a thread that is in the ThreadState.Unstarted state.
            if (_unstarted)  //using a member flag rather than the thread flag Unstarted just in case the thread flags aren't updated right away.
            {
                running = false;
            }
            else if (_thread.Join(0))
            {
                running = false;
            }
            return running;
        }

        #region ICancelableThread Members

        /// <summary>
        /// If the thread should be terminated, i.e. the thread has been canceled,
        /// this method will return true.  Otherwise it will return false
        /// </summary>
        /// <returns>true if the thread should be canceled, otherwise false</returns>
        public bool HasThreadBeenAskedToCancel()
        {
            bool terminate = false;
            if (_terminateThreadEvent != null)
            {
                lock(_terminateThreadEvent)
                {
                    // If the _terminateThreadEvent has been set, terminate the operation.
                    terminate = _terminateThreadEvent.WaitOne(1, false);
                }
            }
            return terminate;
        }

        #endregion

        #region IDisposable Members

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            if (false == _disposed)
            {
                Dispose(true);
                _disposed = true;

                // Take yourself off the Finalization queue to prevent
                // finalization code for this object from executing a second time.
                GC.SuppressFinalize(this);
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Dispose managed code here.
            }
            // Dispose unmanaged resources here. (This object doesn't currently have any.)
        }


        #endregion
    }
}
