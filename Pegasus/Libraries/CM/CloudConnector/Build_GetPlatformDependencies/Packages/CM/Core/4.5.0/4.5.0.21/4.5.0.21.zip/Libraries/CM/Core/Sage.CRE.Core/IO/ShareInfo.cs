using System;
using System.IO;
using System.Collections;
using System.Runtime.InteropServices;
using System.Globalization;

using Sage.Diagnostics;
using Sage.PInvoke;

namespace Sage.IO
{	
	/// <summary>
	/// Maintains information about a local shared resource.
	/// </summary>
	public class ShareInfo
	{
		#region Private data		
		private string _server;
		private string _netName;
		private string _path;
		private ShareType _shareType;
		private string _remark;		
		#endregion

		#region Public methods
		/// <summary>
		/// Public constructor.
		/// </summary>
		/// <param name="server">Name of the computer that this share belongs to.</param>
		/// <param name="netName">Name of shared object.</param>
		/// <param name="path">Path to shared object.</param>
		/// <param name="shareType">Type of shared object.</param>
		/// <param name="remark">Optional comment about shared object.</param>
		public ShareInfo(
			string server,
			string netName,
			string path,
			ShareType shareType,
			string remark )
		{
			if( ShareType.Special == shareType && "IPC$" == netName )
			{
				shareType |= ShareType.IPC;
			}			
			_server = server;
			_netName = netName;
			_path = path;
			_shareType = shareType;
			_remark = remark;
		}

		/// <summary>
		/// Returns the path to this share (e.g., \\MyMachine\share).
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			if( string.IsNullOrEmpty( _server ) )
			{
				return string.Format(
					CultureInfo.InvariantCulture,
					@"\\{0}\{1}",
					Environment.MachineName,
					_netName );
			}
			else
				return string.Format(
					CultureInfo.InvariantCulture,
					@"\\{0}\{1}",
					_server,
					_netName );
		}

		/// <summary>
		/// Returns true if this share matches the local path.
		/// </summary>
		/// <param name="path"></param>
		/// <returns></returns>
		public bool MatchesPath(
			string path )
		{
			if( !IsFileSystem )
			{
				return false;
			}
			if( string.IsNullOrEmpty( path ) )
			{
				return true;
			}
			return path.ToLower().StartsWith( _path.ToLower() );
		}
		#endregion

		#region Public properties
		/// <summary>
		/// The name of the computer that this share belongs to.
		/// </summary>
		public string Server 
		{
			get
			{
				return _server;
			}
		}

		/// <summary>
		/// Name of shared object.
		/// </summary>
		public string NetName 
		{
			get
			{
				return _netName;
			}
		}

		/// <summary>
		/// Local path to shared object.
		/// </summary>
		public string Path 
		{
			get
			{
				return _path;
			}
		}

		/// <summary>
		/// Type of shared object.
		/// </summary>
		public ShareType ShareType 
		{
			get
			{
				return _shareType;
			}
		}

		/// <summary>
		/// Optional comment about shared object.
		/// </summary>
		public string Remark 
		{
			get
			{
				return _remark;
			}
		}

		/// <summary>
		/// Returns true if this is a file system share.
		/// </summary>
		public bool IsFileSystem 
		{
			get 
			{
				return _shareType == ShareType.Disk;
			}
		}

		/// <summary>
		/// Get the root of a disk-based share.
		/// </summary>
		public DirectoryInfo Root
		{
			get 
			{
				if( IsFileSystem )
				{
					if( string.IsNullOrEmpty( _server ) )
					{
						if( string.IsNullOrEmpty( _path ) )
						{
							return new DirectoryInfo( ToString() );
						}
						else
						{
							return new DirectoryInfo( _path );
						}
					}
					else
					{
						return new DirectoryInfo( ToString() );
					}
				}
				else
				{
					return null;
				}
			}
		}		
		#endregion

	}	// end class

}	// end namespace