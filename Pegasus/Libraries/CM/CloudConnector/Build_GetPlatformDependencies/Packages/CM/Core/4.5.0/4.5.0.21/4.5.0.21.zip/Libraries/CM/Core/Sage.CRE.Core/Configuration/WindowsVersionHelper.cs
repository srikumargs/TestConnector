using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using Sage.PInvoke;
using WinVerResx = Sage.Configuration.WindowsVersion;

namespace Sage.Configuration
{
    /// <summary>
    /// Defines a number of predominantly native functions used to evaluate the current Windows version.
    /// </summary>
    /// <remarks>
    /// Microsoft strongly advises against testing for specific OS versions. The preferred method is to use the 
    /// VerifyVersionInfo function to test the current OS against a number of minimum requirements, including major
    /// Windows version and/or service pack.
    /// 
    /// Generally speaking, try not to 
    /// </remarks>
    public class WindowsVersionHelper
    {
        /// <summary>
        /// Get a structure holding information about the current Windows OS.
        /// </summary>
        /// <returns>Returns an OS version structure.</returns>
        public static OSVersionInfoEx GetCurrentOsVersionInfo()
        {
            OSVersionInfoEx osvi = new OSVersionInfoEx();
            osvi.dwOSVersionInfoSize = Marshal.SizeOf(osvi);
            Kernel32.GetVersionEx(ref osvi);
            return osvi;
        }

        /// <summary>
        /// Get a dump of the Windows version.
        /// </summary>
        /// <returns>Returns a formatted string.</returns>
        public static string GetWindowsVersionDump()
        {
            OSVersionInfoEx currentOsInfo = GetCurrentOsVersionInfo();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Major OS value: {0}", currentOsInfo.dwMajorVersion);
            sb.AppendLine();
            sb.AppendFormat("Minor OS value: {0}", currentOsInfo.dwMinorVersion);
            sb.AppendLine();
            sb.AppendFormat("Build number: {0}", currentOsInfo.dwBuildNumber);
            sb.AppendLine();
            sb.AppendFormat("PlatformId: {0}", currentOsInfo.dwPlatformId);
            sb.AppendLine();
            sb.AppendFormat("Product type: {0}", currentOsInfo.wProductType);
            sb.AppendLine();
            sb.AppendFormat("Service Pack String: {0}", currentOsInfo.szCSDVersion);
            sb.AppendLine();
            sb.AppendFormat("Service Pack Major/Minor: {0}.{1}", currentOsInfo.wServicePackMajor, currentOsInfo.wServicePackMinor);
            return sb.ToString();
        }

        /// <summary>
        /// Defines a structure that holds Operating System requirements.
        /// </summary>
        public struct OsVersionRequirement
        {
            /// <summary>
            /// Major version
            /// </summary>
            public WindowsMajorVersion windowsMajor;
            /// <summary>
            /// Minor version
            /// </summary>
            public WindowsMinorVersion windowsMinor;
            /// <summary>
            /// Service pack major version
            /// </summary>
            public ushort servicePackMajor;
            /// <summary>
            /// Service pack minor version
            /// </summary>
            public ushort servicePackMinor;
        };

        #region Specific OS Test Functions

        /// <summary>
        /// Test to see if this is a Windows 2000 based OS.
        /// </summary>
        /// <returns>Returns true if this is Windows 2000; otherwise, false.</returns>
        public static bool IsWindows2000()
        {
            // Create an OS test. We want to find anything less than XP. (IE we want to find Windows 2000).
            WindowsVersionHelper.OsVersionRequirement requirement
                = new WindowsVersionHelper.OsVersionRequirement();

            requirement.windowsMajor = WindowsMajorVersion.WinNT5;
            requirement.windowsMinor = WindowsMinorVersion.WindowsXP;
            requirement.servicePackMajor = 2;
            requirement.servicePackMinor = 0;

            // Anything less than XP will be Windows 2000.
            return TestLessThanVersion(requirement);
        }

        /// <summary>
        /// Test to see if this is a Windows XP based OS.
        /// </summary>
        /// <returns>Returns true if this is Windows XP; otherwise, false.</returns>
        public static bool IsWindowsXP()
        {
            WindowsVersionHelper.OsVersionRequirement requirement
                = new WindowsVersionHelper.OsVersionRequirement();

            requirement.windowsMajor = WindowsMajorVersion.WinNT5;
            requirement.windowsMinor = WindowsMinorVersion.WindowsXP;
            requirement.servicePackMajor = 0;
            requirement.servicePackMinor = 0;

            // Anything greater than XP and less not Vista.
            return (TestGreaterThanEqualVersion(requirement) && !IsWindowsVista());
        }

        /// <summary>
        /// Test to see if this is a Windows 2003 based OS.
        /// </summary>
        /// <returns>Returns true if this is Windows 2003; otherwise, false.</returns>
        public static bool IsWindows2003()
        {
            WindowsVersionHelper.OsVersionRequirement requirement
                = new WindowsVersionHelper.OsVersionRequirement();

            requirement.windowsMajor = WindowsMajorVersion.WinNT5;
            requirement.windowsMinor = WindowsMinorVersion.WindowsServer2003_x64;
            requirement.servicePackMajor = 0;
            requirement.servicePackMinor = 0;

            // Test for 2003 and exclude XP (for potential x64 OSs) + Vista
            return (TestGreaterThanEqualVersion(requirement) && !IsWindowsXP() && !IsWindowsVista());
        }

        /// <summary>
        /// Test to see if this is a Windows Vista based OS.
        /// </summary>
        /// <returns>Returns true if this is Windows Vista; otherwise, false.</returns>
        public static bool IsWindowsVista()
        {
            WindowsVersionHelper.OsVersionRequirement requirement
                = new WindowsVersionHelper.OsVersionRequirement();

            requirement.windowsMajor = WindowsMajorVersion.Vista;
            requirement.windowsMinor = WindowsMinorVersion.WindowsVista_Server_2k_NT;
            requirement.servicePackMajor = 0;
            requirement.servicePackMinor = 0;

            // Test for 2003 and exclude XP (for potential x64 OSs)
            return TestGreaterThanEqualVersion(requirement);
        }

        /// <summary>
        /// Returns a flag indicating if the current operating system is 64-bit.
        /// </summary>
        /// <returns>Returns true if the current OS is 64-bit; otherwise, it's 32-bit.</returns>
        public static bool IsOperatingSystem64()
        {
            return (System.Runtime.InteropServices.Marshal.SizeOf(typeof(IntPtr)) == 8);

            /*
            OSVERSIONINFOEX osvix
                = WindowsVersionHelper.GetCurrentOsVersionInfo();

            if (osvix.dwMajorVersion == WindowsMajorVersion.WinNT5 &&
                osvix.dwMinorVersion
                        

            IntPtr pProcess = System.Diagnostics.Process.GetCurrentProcess().Handle;
            bool isWowProcess = false;

            try
            {
                isWowProcess = IsWow64Process(pProcess, ref isWowProcess);
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.ToString());
                isWowProcess = false;
            }

            return isWowProcess;
            return false;
            */
        }

        #endregion

        #region Private Generic OS Test Functions

        /// <summary>
        /// Create a native OSVERSIONINFOEX structure based on an OS requirement object.
        /// </summary>
        /// <param name="requirement">The OS requirement object.</param>
        /// <returns>Returns a native OSVERSIONINFOEX structure</returns>
        private static OSVersionInfoEx CreateOsVersionForTest(OsVersionRequirement requirement)
        {
            return CreateOsVersionForTest(requirement.windowsMajor, requirement.windowsMinor,
                requirement.servicePackMajor, requirement.servicePackMinor);
        }

        /// <summary>
        /// Create a native OSVERSIONINFOEX structure based on an a series of requirement parameters.
        /// </summary>
        /// <param name="windowsMajor">The required major Windows version.</param>
        /// <param name="windowsMinor">The required minor Windows version.</param>
        /// <param name="servicePackMajor">The required major service pack number.</param>
        /// <param name="servicePackMinor">The required minor service pack number.</param>
        /// <returns>Returns a native OSVERSIONINFOEX structure</returns>
        private static OSVersionInfoEx CreateOsVersionForTest(WindowsMajorVersion windowsMajor, WindowsMinorVersion windowsMinor,
            ushort servicePackMajor, ushort servicePackMinor)
        {
            OSVersionInfoEx osvi = new OSVersionInfoEx();

            // Initialize the structure
            osvi.dwOSVersionInfoSize = Marshal.SizeOf(osvi);
            osvi.dwMajorVersion = windowsMajor;
            osvi.dwMinorVersion = windowsMinor;
            osvi.wServicePackMajor = servicePackMajor;
            osvi.wServicePackMinor = servicePackMinor;

            return osvi;
        }

        /// <summary>
        /// Test an OS based on a requirement object, as well as a condition mask.
        /// </summary>
        /// <param name="requirement">The OS requirement.</param>
        /// <param name="conditionMask">The OS condition mask.</param>
        /// <returns>Returns true if the requirement is met; otherwise, false.</returns>
        private static bool TestVersion(OsVersionRequirement requirement, VersionConditionMask conditionMask)
        {
            return TestVersion(requirement.windowsMajor, requirement.windowsMinor, requirement.servicePackMajor,
                requirement.servicePackMinor, conditionMask);
        }

        /// <summary>
        /// Test an OS based on a series of requirement parameters, as well as a condition mask.
        /// </summary>
        /// <param name="windowsMajor">The required major Windows version.</param>
        /// <param name="windowsMinor">The required minor Windows version.</param>
        /// <param name="servicePackMajor">The required major service pack number.</param>
        /// <param name="servicePackMinor">The required minor service pack number.</param>
        /// <param name="conditionMask">The required condition mask.</param>
        /// <returns>Returns true if all input requirements are met; otherwise, false.</returns>
        private static bool TestVersion(WindowsMajorVersion windowsMajor, WindowsMinorVersion windowsMinor,
            ushort servicePackMajor, ushort servicePackMinor, VersionConditionMask conditionMask)
        {
            OSVersionInfoEx osvi = CreateOsVersionForTest(windowsMajor, windowsMinor, servicePackMajor, servicePackMinor);
            return TestVersion(osvi, conditionMask);
        }

        /// <summary>
        /// Test an OS based on a raw OSVERSIONINFOEX structure, as well as a condition mask.
        /// </summary>
        /// <param name="osvi">The native OSVERSIONINFOEX structure.</param>
        /// <param name="conditionMask">The required condition mask.</param>
        /// <returns>Returns true if all requirements are met; otherwise, false.</returns>
        private static bool TestVersion(OSVersionInfoEx osvi, VersionConditionMask conditionMask)
        {
            ulong dwlConditionMask = 0;
            
            dwlConditionMask = Kernel32.VerSetConditionMask(dwlConditionMask, TestTypeMask.MajorVersion, conditionMask);
            dwlConditionMask = Kernel32.VerSetConditionMask(dwlConditionMask, TestTypeMask.MinorVersion, conditionMask);
            dwlConditionMask = Kernel32.VerSetConditionMask(dwlConditionMask, TestTypeMask.ServicePackMajor, conditionMask);
            dwlConditionMask = Kernel32.VerSetConditionMask(dwlConditionMask, TestTypeMask.ServicePackMinor, conditionMask);
            uint typeMask = (uint)(TestTypeMask.MajorVersion | TestTypeMask.MinorVersion | TestTypeMask.ServicePackMajor | TestTypeMask.ServicePackMinor);

            return Kernel32.VerifyVersionInfo(ref osvi, typeMask, dwlConditionMask);
        }

        #endregion

        #region Test Greater/Less/Equal Functions

        /// <summary>
        /// Test the requirement against current OS.
        /// </summary>
        /// <param name="requirement">The OS requirement object.</param>
        /// <returns>Returns true if the current OS is greater than the requirements; otherwise, false.</returns>
        public static bool TestGreaterThanVersion(OsVersionRequirement requirement)
        {
            return TestVersion(requirement, VersionConditionMask.GreaterThan);
        }

        /// <summary>
        /// Test the requirement against current OS.
        /// </summary>
        /// <param name="requirement">The OS requirement object.</param>
        /// <returns>Returns true if the current OS is less than the requirements; otherwise, false.</returns>
        public static bool TestLessThanVersion(OsVersionRequirement requirement)
        {
            return TestVersion(requirement, VersionConditionMask.LessThan);
        }

        /// <summary>
        /// Test the requirement against current OS.
        /// </summary>
        /// <param name="requirement">The OS requirement object.</param>
        /// <returns>Returns true if the current OS is greater than or equal to the requirements; otherwise, false.</returns>
        public static bool TestGreaterThanEqualVersion(OsVersionRequirement requirement)
        {
            return TestVersion(requirement, VersionConditionMask.GreaterThanEqual);
        }

        /// <summary>
        /// Test the requirement against current OS.
        /// </summary>
        /// <param name="requirement">The OS requirement object.</param>
        /// <returns>Returns true if the current OS is equal to the requirements; otherwise, false.</returns>
        public static bool TestEqualVersion(OsVersionRequirement requirement)
        {
            return TestVersion(requirement, VersionConditionMask.Equal);
        }

        /// <summary>
        /// Test the requirement against current OS.
        /// </summary>
        /// <param name="requirement">The OS requirement object.</param>
        /// <returns>Returns true if the current OS is less than or equal to the requirements; otherwise, false.</returns>
        public static bool TestLessThanEqualVersion(OsVersionRequirement requirement)
        {
            return TestVersion(requirement, VersionConditionMask.LessThanEqual);
        }

        #endregion

        #region Windows Operating Systems String Functions

        /// <summary>
        /// Creates a string fully describing the current Operating System.
        /// </summary>
        /// <returns>Returns an OS version string.</returns>
        public static string GetWindowsVersionString()
        {
            string windowsVersion = "";

            // First, try to use the more modern call.
            OSVersionInfoEx osvix = new OSVersionInfoEx();
            osvix.dwOSVersionInfoSize = Marshal.SizeOf(osvix);
            bool status = Kernel32.GetVersionEx(ref osvix);

            // Dit it pass?
            if (!status)
            {
                // If not, then it must be the much older OS's.
                OSVersionInfoEx osvi = new OSVersionInfoEx();
                osvi.dwOSVersionInfoSize = Marshal.SizeOf(osvi);
                status = Kernel32.GetVersionEx(ref osvi);

                // If this should somehow fail, then we're in real trouble.
                if (status)
                {
                    windowsVersion = handleWindows9x(osvi);
                }
                else
                {
                    windowsVersion = WinVerResx.Unknown;
                }
            }
            else
            {
                // This is some version of NT on up.
                windowsVersion = handleWindowsNTx(osvix);
            }

            return windowsVersion;
        }

        /// <summary>
        /// Handle all flavors of Win9x.
        /// </summary>
        /// <param name="osvi">The OSVERSIONINFO structure.</param>
        /// <returns>Returns an OS version string.</returns>
        private static string handleWindows9x(OSVersionInfoEx osvi)
        {
            string osVersionStr = "";

            if (osvi.dwMajorVersion == (WindowsMajorVersion)4 &&
                osvi.dwMinorVersion == (WindowsMinorVersion)0)
            {
                osVersionStr = WinVerResx.Windows95;

                if (osvi.szCSDVersion[1] == 'B' ||
                    osvi.szCSDVersion[1] == 'C')
                {
                    osVersionStr += WinVerResx.OSR2;
                }
            }
            else if (osvi.dwMajorVersion == (WindowsMajorVersion)4 &&
                    osvi.dwMinorVersion == (WindowsMinorVersion)10)
            {
                osVersionStr = WinVerResx.Windows98;

                if (osvi.szCSDVersion[1] == 'A')
                {
                    osVersionStr += WinVerResx.Windows98SE;
                }
            }
            else if (osvi.dwMajorVersion == (WindowsMajorVersion)4 &&
           osvi.dwMinorVersion == (WindowsMinorVersion)90)
            {
                osVersionStr = WinVerResx.WindowsME;
            }
            else
            {
                osVersionStr = WinVerResx.Unknown;
            }

            return osVersionStr;
        }

        /// <summary>
        /// Handle all flavors of Windows NT.
        /// </summary>
        /// <param name="osvix">The OSVERSIONINFOEX structure.</param>
        /// <returns>Returns an OS version string.</returns>
        private static string handleWindowsNTx(OSVersionInfoEx osvix)
        {
            string osVersionStr = "";

            switch ((WindowsMajorVersion)osvix.dwMajorVersion)
            {
                case WindowsMajorVersion.WinNT4:
                    osVersionStr = handleWindowsNT4();
                    break;

                case WindowsMajorVersion.WinNT5:

                    osVersionStr = handleWindowsNT5(osvix);
                    break;

                case WindowsMajorVersion.Vista:
                    osVersionStr = handleWindowsVista(osvix);
                    break;
            }

            if (!string.IsNullOrEmpty(osvix.szCSDVersion))
                osVersionStr += string.Format(" + {0}", osvix.szCSDVersion);

            return osVersionStr;
        }

        /// <summary>
        /// Handle Windows NT4.
        /// </summary>
        /// <returns>Returns an OS version string.</returns>
        private static string handleWindowsNT4()
        {
            return WinVerResx.WindowsNT4;
        }

        /// <summary>
        /// Handle all flavors of NT5.
        /// </summary>
        /// <param name="osvix">The OSVERSIONINFOEX structure.</param>
        /// <returns>Returns an OS version string.</returns>
        private static string handleWindowsNT5(OSVersionInfoEx osvix)
        {
            switch ((WindowsMinorVersion)osvix.dwMinorVersion)
            {
                case WindowsMinorVersion.WindowsVista_Server_2k_NT:

                    switch ((ProductType)osvix.wProductType)
                    {
                        case ProductType.NTWorkstation:

                            return WinVerResx.Windows2000;

                        case ProductType.NTServer:

                            if ((VersionSuite)(osvix.wSuiteMask & VersionSuite.DataCenter) == VersionSuite.DataCenter)
                                return WinVerResx.Windows2000DCServer;
                            else if ((VersionSuite)(osvix.wSuiteMask & VersionSuite.Enterprise) == VersionSuite.Enterprise)
                                return WinVerResx.Windows2000DCAdvancedServer;
                            else if ((VersionSuite)(osvix.wSuiteMask & VersionSuite.SmallBusiness) == VersionSuite.SmallBusiness)
                                return WinVerResx.Windows2000SBServer;
                            else
                                return WinVerResx.Windows2000Server;

                        case ProductType.DomainController:

                            if ((VersionSuite)(osvix.wSuiteMask & VersionSuite.DataCenter) == VersionSuite.DataCenter)
                                return WinVerResx.Windows2000DCServerDomain;
                            else if ((VersionSuite)(osvix.wSuiteMask & VersionSuite.Enterprise) == VersionSuite.Enterprise)
                                return WinVerResx.Windows2000DCAdvancedServerDomain;
                            else if ((VersionSuite)(osvix.wSuiteMask & VersionSuite.SmallBusiness) == VersionSuite.SmallBusiness)
                                return WinVerResx.Windows2000SBServerDomain;
                            else
                                return WinVerResx.Windows2000ServerDomain;
                    }

                    break;

                case WindowsMinorVersion.WindowsXP:

                    if ((VersionSuite)(osvix.wSuiteMask & VersionSuite.Personal) == VersionSuite.Personal)
                        return WinVerResx.WindowsXPHome;
                    else
                        return WinVerResx.WindowsXPPro;

                case WindowsMinorVersion.WindowsServer2003_x64:

                    switch ((ProductType)osvix.wProductType)
                    {
                        case ProductType.NTWorkstation:
                            return WinVerResx.WindowsXPProX64;

                        case ProductType.NTServer:

                            if (User32.GetSystemMetrics(SystemMetric.MetricsServerR2) == 1)
                                return WinVerResx.WindowsServer2003R2;
                            else
                                return WinVerResx.WindowsServer2003;

                        case ProductType.DomainController:

                            if (User32.GetSystemMetrics(SystemMetric.MetricsServerR2) == 1)
                                return WinVerResx.WindowsServer2003R2Domain;
                            else
                                return WinVerResx.WindowsServer2003Domain;
                    }
                    break;
            }

            return WinVerResx.Unknown;
        }

        /// <summary>
        /// Handle all flavors of Vista.
        /// </summary>
        /// <param name="osvix">The OSVERSIONINFOEX structure.</param>
        /// <returns>Returns an OS version string.</returns>
        private static string handleWindowsVista(OSVersionInfoEx osvix)
        {
            switch ((ProductType)osvix.wProductType)
            {
                case ProductType.NTWorkstation:

                    if ((VersionSuite)(osvix.wSuiteMask & VersionSuite.Personal) == VersionSuite.Personal)
                    {
                        return WinVerResx.WindowsVistaHome;
                    }
                    else
                    {
                        return WinVerResx.WindowsVistaEntBus;
                    }

                case ProductType.NTServer:

                    return WinVerResx.WindowsServerLonghorn;
            }

            return WinVerResx.WindowsVistaUnknown;
        }

        #endregion
    }
}
