#if DEBUG
using System;
using System.Collections.Generic;
using System.Text;
using Sage.Net;
using NUnit.Framework;

namespace Sage.Net.Tests
{
    /// <summary>
    /// Performs tests for the net utilities class.
    /// </summary>
    [TestFixture]
    public class TestNetUtils
    {
        /// <summary>
        /// Execute all tests.
        /// </summary>
        public void ExecTests()
        {
            this.TestHostName();
            this.TestIPAddress();
            this.TestLocalHost();
            this.TestLocalHostAlt();
            this.TestLocalPath();
            this.TestUNCPath();
            this.TestLocalSubstPath();
            this.TestRemoteSubstPath();
        }

        /// <summary>
        /// Test to make sure localhost is accounted for.
        /// </summary>
        [Test]
        public void TestLocalHost()
        {
            string address = "localhost";
            Assert.IsFalse(NetUtils.IsRemoteAddress(address));
        }

        /// <summary>
        /// Test to make sure 127.0.0.1 is accounted for.
        /// </summary>
        [Test]
        public void TestLocalHostAlt()
        {
            string address = "127.0.0.1";
            Assert.IsFalse(NetUtils.IsRemoteAddress(address));
        }

        /// <summary>
        /// Test to make sure GetHostName works.
        /// </summary>
        [Test]
        public void TestHostName()
        {
            string address = System.Net.Dns.GetHostName();
            Assert.IsFalse(NetUtils.IsRemoteAddress(address));
        }

        /// <summary>
        /// Test to make sure IP addresses work.
        /// </summary>
        [Test]
        public void TestIPAddress()
        {
            // Just pick some IP address that cannot possibly be local.
            string address = "144.22.33.44";
            Assert.IsTrue(NetUtils.IsRemoteAddress(address));

            // Get the IP address for the current host.
            address = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList[0].ToString();
            Assert.IsFalse(NetUtils.IsRemoteAddress(address));
        }

        /// <summary>
        /// Test to make sure a local path works.
        /// </summary>
        [Test]
        public void TestLocalPath()
        {
            string address = @"C:\Program Files";
            Assert.IsFalse(NetUtils.IsRemoteAddress(address));
        }

        /// <summary>
        /// Test to make sure a UNC path works.
        /// </summary>
        [Test]
        public void TestUNCPath()
        {
            string address = @"\\SOMEREMOTEMACHINE\Shared";
            Assert.IsTrue(NetUtils.IsRemoteAddress(address));

            // Create a UNC path using the host name
            address = string.Format(@"\\{0}\CurrentSandbox\Assemblies", System.Net.Dns.GetHostName());
            Assert.IsFalse(NetUtils.IsRemoteAddress(address));
        }

        /// <summary>
        /// Test to make sure a local substitute path works.
        /// </summary>
        [Test]
        public void TestLocalSubstPath()
        {
            // Note: you must subst the S drive to your Sandbox.
            string address = @"S:";
            Assert.IsFalse(NetUtils.IsRemoteAddress(address));

            address = @"S:\";
            Assert.IsFalse(NetUtils.IsRemoteAddress(address));

            address = @"S:\Runtime Files\";
            Assert.IsFalse(NetUtils.IsRemoteAddress(address));

            address = @"S:\Runtime Files\Program Files";
            Assert.IsFalse(NetUtils.IsRemoteAddress(address));
        }

        /// <summary>
        /// Test to make sure a remote substitute path works.
        /// </summary>
        [Test]
        public void TestRemoteSubstPath()
        {
            // Note: you must subst. the T drive to a remote machine for this to work!
            string address = @"T:";
            Assert.IsTrue(NetUtils.IsRemoteAddress(address));

            address = @"T:\";
            Assert.IsTrue(NetUtils.IsRemoteAddress(address));

            address = @"T:\Runtime Files\";
            Assert.IsTrue(NetUtils.IsRemoteAddress(address));

            address = @"T:\Runtime Files\Program Files";
            Assert.IsTrue(NetUtils.IsRemoteAddress(address));
        }
    }
}
#endif
