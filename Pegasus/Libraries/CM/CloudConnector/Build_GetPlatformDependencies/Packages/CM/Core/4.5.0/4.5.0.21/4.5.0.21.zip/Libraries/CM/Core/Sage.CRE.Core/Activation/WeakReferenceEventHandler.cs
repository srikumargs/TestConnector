using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Globalization;

using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Provides a means for an object to register for an event using a "weak reference".
    /// </summary>
    /// <remarks>
    /// Using the default event support in .NET, the process of registering for an
    /// event introduces a "strong reference" between the event source and target.  I.e., the
    /// event source will keep the event target from being garbage collected even if you have
    /// released all of your explicit references to the target object instance.
    /// </remarks>
    /// <remarks>
    /// This class is designed to let the individual registering for the event make the decision
    /// of whether they want the event target to be tracked with a weak reference or a strong
    /// reference by the event source.  The event source need not do anything special to support
    /// weak reference event registrations (or even a mixture of weak and strong registrations
    /// to the same event).
    /// <para>
    /// This class currently only works for "standard event handler signatures".  The standard
    /// signature of an event handler delegate defines a method that does not have return a value,
    /// whose first parameter is of type Object and refers to the instance that raises the event,
    /// and whose second parameter is derived from type EventArgs and holds the event data.  It is
    /// technically possible to add support for any event handler signatures ... but at a cost
    /// of efficiency and complexity.  Therefore, this work has not been done until a justifiable
    /// use case is encountered.
    /// </para>
    /// </remarks>
    /// <example>
    /// The typical way you register for an event in .NET might look something like this:
    /// <code>
    /// this.SomethingHappened += new EventHandler&lt;EventArgs&gt;(_foo.OnSomthingHappened);
    /// </code>
    /// The equivalent "weak reference" way to do it is:
    /// <code>
    /// WeakReferenceEventHandler&lt;EventArgs&gt;.Register(this, "SomethingHappened", _foo.OnSomthingHappened);
    /// </code>
    /// or for a static event handler member you can do this:
    /// <code>
    /// WeakReferenceEventHandler&lt;EventArgs&gt;.Register(this, "SomethingHappened", Foo.StaticOnSomthingHappened);
    /// </code>
    /// </example>
    /// <typeparam name="TEventArgs">The type of the EventArgs parameter for the event handler.</typeparam>
    public sealed class WeakReferenceEventHandler<TEventArgs> where TEventArgs : EventArgs
    {
        #region Public methods
        /// <summary>
        /// Registers a target event handler for the speciified source event.
        /// </summary>
        /// <param name="source">The event source object instance.</param>
        /// <param name="sourceEventName">The name of the event on the source object.</param>
        /// <param name="targetEventHandler">The target method delegate that should be registered on the source object's named event.</param>
        public static void Register(Object source, String sourceEventName, EventHandler<TEventArgs> targetEventHandler)
        {
            ArgumentValidator.ValidateNonNullReference(source, "source", _myTypeName + ".Register");
            ArgumentValidator.ValidateNonEmptyString(sourceEventName, "sourceEventName", _myTypeName + ".Register");
            ArgumentValidator.ValidateNonNullReference(targetEventHandler, "targetEventHandler", _myTypeName + ".Register");

            EventInfo sourceEventInfo = source.GetType().GetEvent(sourceEventName);
            if(sourceEventInfo == null)
            {
                throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, Strings.UnableToFindEventNamedFormat, sourceEventName, source.GetType().FullName));
            }

            new WeakReferenceEventHandler<TEventArgs>(source, sourceEventInfo, targetEventHandler);
        }
        #endregion

        #region Private methods
        private WeakReferenceEventHandler(Object source, EventInfo sourceEventInfo, EventHandler<TEventArgs> targetEventHandler)
        {
            // keep a weak reference to the event source instance ... we don't want this object instance keeping the source alive
            _sourceWeakReference = new WeakReference(source);
            _sourceEventInfo = sourceEventInfo;

            // keep a weak-reference to the event target instance  ... we don't want this object instance keeping the target alive
            _targetWeakReference = new WeakReference(targetEventHandler.Target);
            _targetMethodInfo = targetEventHandler.Method;

            _eventHandler = Delegate.CreateDelegate(_sourceEventInfo.EventHandlerType, this, "Invoke");

            // Give the event source instance a strong-reference back to this WeakReferenceEventHandler instance.  Now
            // the source object instance will keep this WeakReferenceEventHandler object alive until we unregister the
            // event handler.
            _sourceEventInfo.AddEventHandler(source, _eventHandler);
            VerboseTrace.WriteLine(this, "WeakEventHandler added:  source={0}; sourceEventName={1}; handler={2}", _sourceWeakReference.Target.GetHashCode(), _sourceEventInfo.Name, this.GetHashCode());
        }

        private void Invoke(Object sender, TEventArgs e)
        {
            VerboseTrace.WriteLine(this, "Invoked:  source={0}; sourceEventName={1}; handler={2}", _sourceWeakReference.Target.GetHashCode(), _sourceEventInfo.Name, this.GetHashCode());
            object target = _targetWeakReference.Target;

            if(_targetMethodInfo.IsStatic || target != null)
            {
                // if the target is static or non-null then it is still callable
                _targetMethodInfo.Invoke(target, new object[] { sender, e });
            }
            else
            {
                // The target is null ... it has been garbage collected so we can now remove the strong reference
                // from the source to this instance.
                //
                // Notice that this design implies that the event source will maintain a strong reference to this
                // WeakReferenceEventHandler instance until the next time the event is fired after the target has
                // has been garbage collected.  Ideally, we might like to clean everything up as soon as the
                // target becomes eligible for garbage collection (i.e., the last strong reference is released) ...
                // rather than waiting until it actually is garbage collected.  Unfortunately, the runtime doesn't
                // provide us a good way to figure that out.
                _sourceEventInfo.RemoveEventHandler(_sourceWeakReference.Target, _eventHandler);
                _eventHandler = null;
                VerboseTrace.WriteLine(this, "WeakEventHandler removed:  source={0}; sourceEventName={1}; handler={2}", _sourceWeakReference.Target.GetHashCode(), _sourceEventInfo.Name, this.GetHashCode());
            }
        }
        #endregion

        #region Private fields
        private static String _myTypeName = typeof(WeakReferenceEventHandler<TEventArgs>).FullName;
        private WeakReference _sourceWeakReference;
        private EventInfo _sourceEventInfo;
        private WeakReference _targetWeakReference;
        private MethodInfo _targetMethodInfo;
        private Delegate _eventHandler;
        #endregion
    }
}
