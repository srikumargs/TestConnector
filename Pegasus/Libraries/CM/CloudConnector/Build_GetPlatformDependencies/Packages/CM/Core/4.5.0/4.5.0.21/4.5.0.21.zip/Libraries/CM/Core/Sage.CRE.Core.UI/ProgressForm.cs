using System;
using System.Windows.Forms;

namespace Sage.CRE.Core.UI
{
    public partial class ProgressForm : Form
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public ProgressForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 
        /// </summary>
        public new void Close()
        {
            MethodInvoker i = delegate()
            {
                Dispose();
            };

            if (this.InvokeRequired)
            {
                this.Invoke(i);
            }
            else
            {
                if (this.IsDisposed)
                {
                    // form has already been disposed, nothing to do
                    return;
                }

                if (!this.IsHandleCreated)
                {
                    // Background processing completed before the
                    // control's handle has been created. Do whatever it takes
                    // to indicate that a deferred update must occur (after the handle has
                    // been created).
                    return;
                }

                i();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="step"></param>
        /// <param name="value"></param>
        /// <param name="max"></param>
        public void ShowNormalProgressBar(Int32 step, Int32 value, Int32 max)
        {
            MethodInvoker i = delegate()
            {
                _label.Hide();
                _progressBar.Show();
                _progressBar.Style = ProgressBarStyle.Continuous;
                _progressBar.Step = step;
                _progressBar.Value = value;
                _progressBar.Maximum = max;
            };

            if (this.InvokeRequired)
            {
                this.Invoke(i);
            }
            else
            {
                if (this.IsDisposed)
                {
                    // form has already been disposed, nothing to do
                    return;
                }

                if (!this.IsHandleCreated)
                {
                    // Background processing completed before the
                    // control's handle has been created. Do whatever it takes
                    // to indicate that a deferred update must occur (after the handle has
                    // been created).
                    return;
                }

                i();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void ShowMarqueeProgressBar()
        {
            MethodInvoker i = delegate()
            {
                _label.Hide();
                _progressBar.Show();
                _progressBar.Style = ProgressBarStyle.Marquee;
            };

            if (this.InvokeRequired)
            {
                this.Invoke(i);
            }
            else
            {
                if (this.IsDisposed)
                {
                    // form has already been disposed, nothing to do
                    return;
                }

                if (!this.IsHandleCreated)
                {
                    // Background processing completed before the
                    // control's handle has been created. Do whatever it takes
                    // to indicate that a deferred update must occur (after the handle has
                    // been created).
                    return;
                }

                i();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void ShowLabelProgress()
        {
            MethodInvoker i = delegate()
            {
                _label.Show();
                _progressBar.Hide();
            };

            if (this.InvokeRequired)
            {
                this.Invoke(i);
            }
            else
            {
                if (this.IsDisposed)
                {
                    // form has already been disposed, nothing to do
                    return;
                }

                if (!this.IsHandleCreated)
                {
                    // Background processing completed before the
                    // control's handle has been created. Do whatever it takes
                    // to indicate that a deferred update must occur (after the handle has
                    // been created).
                    return;
                }

                i();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="formatString">(e.g., "Performing System Verification ({0} of {1} system checks)")</param>
        /// <param name="count">position {0} in the formatString</param>
        /// <param name="total">position {1} in the formatString</param>
        public void UpdateStatus(String formatString, Int32 count, Int32 total)
        {
            MethodInvoker i = delegate()
            {
                Text = String.Format(formatString, count, total);
                _progressBar.Value = count;
                _progressBar.Maximum = total;
                Update();
            };

            if (this.InvokeRequired)
            {
                this.BeginInvoke(i);
            }
            else
            {
                if (this.IsDisposed)
                {
                    // form has already been disposed, nothing to do
                    return;
                }

                if (!this.IsHandleCreated)
                {
                    // Background processing completed before the
                    // control's handle has been created. Do whatever it takes
                    // to indicate that a deferred update must occur (after the handle has
                    // been created).
                    return;
                }

                i();
            }
        }

        //protected override bool ShowWithoutActivation
        //{ get { return true; } }

        /// <summary>
        /// 
        /// </summary>
        public event EventHandler UserCancelled = delegate { };

        private void _cancelButton_Click(object sender, EventArgs e)
        {
            if (!_userHasCancelled)
            {
                _userHasCancelled = true;
                UserCancelled(this, new EventArgs());
            }
        }

        /// <summary>
        /// Blocks the current execution thread until the progress form has been created
        /// </summary>
        public void WaitUntilReady()
        {
            while (!this.IsHandleCreated)
            {
                System.Diagnostics.Trace.WriteLine("ProgressForm: !this.IsHandleCreated");

                System.Threading.Thread.Sleep(100);
            }
            System.Diagnostics.Trace.WriteLine("ProgressForm: this.IsHandleCreated");
        }


        private Boolean _userCanCancel;

        /// <summary>
        /// 
        /// </summary>
        public Boolean UserCanRequestCancel
        {
            get { return _userCanCancel; }
            set { _userCanCancel = value; }
        }

        private Boolean _userHasCancelled;

        /// <summary>
        /// 
        /// </summary>
        public Boolean UserHasRequestedCancel
        { get { return _userHasCancelled; } }

        private void ProgressForm_Load(object sender, EventArgs e)
        {
            if (!_userCanCancel)
            {
                this.Height -= _cancelButtonPanel.Height;
                _cancelButtonPanel.Hide();
            }
        }
    }
}