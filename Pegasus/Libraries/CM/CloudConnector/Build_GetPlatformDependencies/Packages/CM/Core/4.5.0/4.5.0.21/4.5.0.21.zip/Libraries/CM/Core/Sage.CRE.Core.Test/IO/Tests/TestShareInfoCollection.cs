using System;
using System.Data;
using System.IO;
using System.Diagnostics;

using Sage.Configuration;
using Sage.IO;
using Sage.PInvoke;

using NUnit.Framework;

namespace Sage.IO.Tests
{
	/// <summary>
	/// Class that tests ShareInfoCollection.
	/// </summary>
	[TestFixture]
	public class TestShareInfoCollection
	{
		/// <summary>
		/// Static constructor to initialize the LibraryManager prior to any other members or field
		/// initialization being JIT-compiled and used.
		/// </summary>
		/// <remarks>
		/// This is needed because, in theory, the only Sage assembly that can be successfully found
		/// may be Sage.CRE.LibraryManagement.dll until the LibraryManager is initialized.
		/// </remarks>
		static TestShareInfoCollection()
		{
            //LibraryManager.InitializeLibraries(
            //    Path.Combine( AppDomain.CurrentDomain.BaseDirectory, LibraryManager.LibraryManifestFolderName ) );
		}

		/// <summary>
		/// This test requires manual intervention, as the paths tested rely on the existence of certain
		/// folders and local shares.
		/// </summary>
		[Test, Category( "Manual" )]
		public void TestPathToUnc()
		{	
			// this path is not shared, thus should fail			
			string result = ShareInfoCollection.PathToUNC( @"d:\temp\alert.zip" );
			Assert.IsFalse( PathUtils.IsPathUNC( result ), "Path should not be UNC!" );

			// this path is shared			
			result = ShareInfoCollection.PathToUNC( @"c:\share\file.txt" );
			Assert.IsTrue( PathUtils.IsPathUNC( result ), "Path should be UNC!" );
			
			// this path is shared (mapped drive to network location)			
			result = ShareInfoCollection.PathToUNC( @"Z:\test.txt" );
			Assert.IsTrue( PathUtils.IsPathUNC( result ), "Path should be UNC!" );
		}

		/// <summary>
		/// Test the PathToUNC method with null input param.
		/// </summary>
		[Test, Category( "Acceptance" )]
		[ExpectedException(typeof(ArgumentNullException))]
		public void TestPathToUNCNullInput()
		{	
			ShareInfoCollection.PathToUNC( null );
		}

		/// <summary>
		/// Test the PathToUNC method with empty input param.
		/// </summary>
		[Test, Category( "Acceptance" )]
		[ExpectedException( typeof( ArgumentException ) )]
		public void TestPathToUNCEmptyInput()
		{
			ShareInfoCollection.PathToUNC( "" );
		}
		
		/// <summary>
		/// Test the PathToUNC method with an invalid path.
		/// </summary>
		[Test, Category( "Acceptance" )]		
		public void TestPathToUNCInvalidPath()
		{
			// if we pass in something bogus, should get same string back
			string result = ShareInfoCollection.PathToUNC( @"t:\fake" );
			Assert.AreEqual( @"t:\fake", result, "PathToUNC should have returned input string." );
		}
		
		/// <summary>
		/// This test requires manual intervention, as the paths tested rely on the existence of certain
		/// folders and local shares.
		/// </summary>
		[Test, Category( "Manual" )]
		public void TestGetShares()
		{
			TestGetShares( Environment.MachineName );

			// should also work with null, empty string
			TestGetShares( null );
			TestGetShares( "" );
		}

		private void TestGetShares(
			string server )
		{
			ShareInfoCollection shares = ShareInfoCollection.GetShares( Environment.MachineName );

			// not much I can assert on...I'll assume machine has some shares.
			Assert.IsNotNull( shares );
			Assert.Greater( shares.Count, 0, "No shares found!" );

			// now try to get shares of a remote machine...hope ORBFile1 exists forever...
			ShareInfoCollection sharesRemote = ShareInfoCollection.GetShares( "ORBFILE1" );

			// not much I can assert on...I'll assume machine has some shares.
			Assert.IsNotNull( sharesRemote );
			Assert.Greater( sharesRemote.Count, 0, "No remote shares found!" );
		}

		/// <summary>
		/// Test the IsValidFilePath method.
		/// </summary>
		[Test, Category( "Acceptance" )]
		public void TestIsValidFilePath()
		{
			Assert.IsFalse( ShareInfoCollection.IsValidFilePath( null ), "Null string is not valid path!" );
			Assert.IsFalse( ShareInfoCollection.IsValidFilePath( "" ), "Empty string is not valid path!" );
			Assert.IsFalse( ShareInfoCollection.IsValidFilePath( "c" ), "C is not valid path!" );
			Assert.IsFalse( ShareInfoCollection.IsValidFilePath( "c:" ), "c: is not valid path!" );
			Assert.IsFalse( ShareInfoCollection.IsValidFilePath( "^" ), "^ is not valid path!" );
			Assert.IsFalse( ShareInfoCollection.IsValidFilePath( "t%4" ), "t%4 is not valid path!" );
			Assert.IsTrue( ShareInfoCollection.IsValidFilePath( @"c:\" ), @"C:\ is a valid path!" );
			Assert.IsTrue( ShareInfoCollection.IsValidFilePath( @"Z:\" ), @"Z:\ is not valid path!" );
		}

		/// <summary>
		/// This test requires manual intervention, as the paths tested rely on the existence of certain
		/// folders and local shares.
		/// </summary>
		[Test, Category( "Manual" )]
		public void TestPathToShare()
		{
			ShareInfo si = ShareInfoCollection.PathToShare( @"d:\temp\alert.zip" );
			Assert.IsNull( si, "si should be null!" );

			si = ShareInfoCollection.PathToShare( @"c:\share\file.txt" );
			Assert.IsNotNull( si, "si should not be null!" );
			Assert.IsTrue( si.IsFileSystem, "Share should be of type FileSystem!" );
			Assert.AreEqual( "share", si.NetName, "NetName does not match!" );
			Assert.AreEqual( @"C:\share", si.Path, "Path does not match!" );
			Assert.AreEqual( @"C:\share", si.Root, "Root does not match!" );
			Assert.AreEqual( @"", si.Server, "Server does not match!" );
			Assert.AreEqual( ShareType.Disk, si.ShareType, "ShareType does not match!" );			
		}

		/// <summary>
		/// Test the PathToShare method with null input.
		/// </summary>
		[Test, Category( "Acceptance" )]
		[ExpectedException( typeof( ArgumentNullException ) )]
		public void TestPathToShareNullInput()
		{
			ShareInfo si = ShareInfoCollection.PathToShare( null );
		}

		/// <summary>
		/// Test the PathToShare method with empty input.
		/// </summary>
		[Test, Category( "Acceptance" )]
		[ExpectedException( typeof( ArgumentException ) )]
		public void TestPathToShareEmptyInput()
		{
			ShareInfo si = ShareInfoCollection.PathToShare( "" );
		}

	}	// end class

}	// end namespace