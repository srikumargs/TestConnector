using System;
using System.Collections.Generic;
using System.Text;

namespace Sage.PInvoke
{
    /// <summary>
    /// Defines common macros found in native code.
    /// </summary>
    public static class Macros
    {
        private static int m_errorSuccess = 0;

        /// <summary>
        /// Checks a standard Win32 return value for success.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>Returns true if the value indicates success; otherwise, false.</returns>
        public static bool Succeeded(int value)
        {
            return (value != 0);
        }

        /// <summary>
        /// Checks a standard Win32 return value for success.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>Returns true if the value indicates success; otherwise, false.</returns>
        public static bool Succeeded(bool value)
        {
            return (value == true);
        }

        /// <summary>
        /// Checks a standard Win32 return value for failure.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>Returns true if the value indicates failure; otherwise, false.</returns>
        public static bool Failed(int value)
        {
            return (value == 0);
        }

        /// <summary>
        /// Checks a standard Win32 return value for failure.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>Returns true if the value indicates failure; otherwise, false.</returns>
        public static bool Failed(bool value)
        {
            return (value == false);
        }

        /// <summary>
        /// Checks a Win32 value for ERROR_SUCCESS (zero).
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>Returns true if the value equals ERROR_SUCCESS; otherwise, false.</returns>
        public static bool CheckErrorSuccess(int value)
        {
            return (value == m_errorSuccess);
        }
    }
}
