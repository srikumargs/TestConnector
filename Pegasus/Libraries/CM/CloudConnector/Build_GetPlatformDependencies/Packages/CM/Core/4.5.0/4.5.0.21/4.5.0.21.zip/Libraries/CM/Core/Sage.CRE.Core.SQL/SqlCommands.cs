﻿using System;
using System.Collections.Generic;

namespace Sage.CRE.Core.SQL
{
    /// <summary>
    /// Statis SQL methods
    /// </summary>
    static public class SqlCommands
    {
        /// <summary>/nGO/n
        /// </summary>
        public readonly static string SqlCommandDelimiter = String.Format(System.Globalization.CultureInfo.InvariantCulture,"{0}GO{0}", System.Environment.NewLine);

        /// <summary>
        /// Returns the result of "SELECT @@VERSION" for the specified database.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        static public string GetServerVersionString(Sage.CRE.Core.SQL.SqlConnectionContext context)
        {
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(context.ConnectionString))
            {
                try
                {
                    connection.Open();

                    using (System.Data.SqlClient.SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = System.Data.CommandType.Text;
                        command.CommandTimeout = 0;
                        command.CommandText = "SELECT @@VERSION";

                        return (string)command.ExecuteScalar();
                    }
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        /// <summary>
        /// throws a very informative error has to why you can't connect to a database.
        /// </summary>
        /// <param name="context"></param>
        static public void EnsureDatabaseConnection(Sage.CRE.Core.SQL.SqlConnectionContext context)
        {
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(context.ConnectionString))
            {
                try
                {
                    connection.Open();
                    using (System.Data.SqlClient.SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = System.Data.CommandType.Text;
                        command.CommandText = @"SELECT  SERVERPROPERTY('productversion')";
                        command.CommandTimeout = (!String.IsNullOrEmpty(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT"))) ? System.Convert.ToInt32(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT")) : 60;

                        string versionString = (string)command.ExecuteScalar();
                    }

                }
                catch (System.Data.SqlClient.SqlException x)
                {
                    switch (x.Number)
                    {
                        case -1:
                        case 10061:
                        case 10060:
                        case 20476:
                            {
                                #region Can't connect
                                if (Sage.Net.NetUtils.IsRemoteAddress(context.DataSource.Host))
                                {
                                    #region Remote Host
                                    // I'm unable to reach the SQL Server via TCP
                                    // Let's test to see if we can ping the machine
                                    try
                                    {
                                        Sage.Net.NetUtils.PingMachine(context.DataSource.Host);
                                        throw new System.Exception(String.Format(StringsCustomerFacing.NoDatabaseConnection_PingWorks, context.DataSource.Host, context.DataSource.InstanceName, (context.DataSource.Port == 0) ? context.DataSource.Port : 1433), x);
                                    }
                                    catch (Sage.Net.PingException px)
                                    {
                                        throw new System.Exception(String.Format(StringsCustomerFacing.NoDatabaseConnection_NoPing), px);
                                    }
                                    #endregion
                                }
                                else
                                {
                                    #region Local Host
                                    string serviceName = "SQL Server (MSSQLSERVER)";
                                    if (!String.IsNullOrEmpty(context.DataSource.InstanceName))
                                    {
                                        serviceName = String.Format("SQL Server ({0})", context.DataSource.InstanceName);
                                    }

                                    System.ServiceProcess.ServiceController sql;
                                    try
                                    {
                                        sql = new System.ServiceProcess.ServiceController(serviceName, System.Environment.MachineName);
                                    }
                                    catch (System.Exception)
                                    {
                                        throw new System.Exception(String.Format(StringsCustomerFacing.InstanceNotInstalled, context.DataSource.InstanceName), x);
                                    }

                                    switch (sql.Status)
                                    {
                                        case System.ServiceProcess.ServiceControllerStatus.ContinuePending:
                                        case System.ServiceProcess.ServiceControllerStatus.StartPending:
                                            {
                                                throw new System.Exception(String.Format(StringsCustomerFacing.ServiceStarting), x);
                                            }
                                        case System.ServiceProcess.ServiceControllerStatus.Paused:
                                        case System.ServiceProcess.ServiceControllerStatus.PausePending:
                                            {
                                                sql.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Paused);
                                                sql.Continue();
                                                throw new System.Exception(String.Format(StringsCustomerFacing.ServicePaused), x);
                                            }
                                        case System.ServiceProcess.ServiceControllerStatus.Stopped:
                                        case System.ServiceProcess.ServiceControllerStatus.StopPending:
                                            {
                                                sql.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Stopped);
                                                sql.Start();
                                                throw new System.Exception(String.Format(StringsCustomerFacing.ServiceStopped), x);
                                            }
                                        case System.ServiceProcess.ServiceControllerStatus.Running:
                                            {
                                                // It's local, it's running, what could be wrong?
                                                if (String.IsNullOrEmpty(context.DataSource.InstanceName))
                                                {
                                                    throw new System.Exception(String.Format(StringsCustomerFacing.NoDatabaseConnection_LocalDefaultInstance, context.DataSource.InstanceName, (context.DataSource.Port == 0) ? context.DataSource.Port : 1433), x);
                                                }
                                                else
                                                {
                                                    string sqlBrowserServerName = "SQL Server Browser";

                                                    System.ServiceProcess.ServiceController sqlBrowserService;
                                                    try
                                                    {
                                                        sqlBrowserService = new System.ServiceProcess.ServiceController(sqlBrowserServerName, System.Environment.MachineName);
                                                    }
                                                    catch (System.Exception)
                                                    {
                                                        throw new System.Exception(String.Format(StringsCustomerFacing.SQLBroswerServiceNotInstalled), x);
                                                    }

                                                    switch (sqlBrowserService.Status)
                                                    {
                                                        case System.ServiceProcess.ServiceControllerStatus.ContinuePending:
                                                        case System.ServiceProcess.ServiceControllerStatus.StartPending:
                                                            {
                                                                throw new System.Exception(String.Format(StringsCustomerFacing.SQLBrowserServiceStarting), x);
                                                            }
                                                        case System.ServiceProcess.ServiceControllerStatus.Paused:
                                                        case System.ServiceProcess.ServiceControllerStatus.PausePending:
                                                            {
                                                                sqlBrowserService.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Paused);
                                                                sqlBrowserService.Continue();
                                                                throw new System.Exception(String.Format(StringsCustomerFacing.SQLBrowserServicePaused), x);
                                                            }
                                                        case System.ServiceProcess.ServiceControllerStatus.Stopped:
                                                        case System.ServiceProcess.ServiceControllerStatus.StopPending:
                                                            {
                                                                sqlBrowserService.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Stopped);
                                                                sqlBrowserService.Start();
                                                                throw new System.Exception(String.Format(StringsCustomerFacing.SQLBrowserServiceStopped), x);
                                                            }
                                                    }

                                                    throw new System.Exception(String.Format(StringsCustomerFacing.NoDatabaseConnection_LocalNamedInstance, context.DataSource.InstanceName), x);
                                                }
                                            }
                                        default:
                                            {
                                                throw;
                                            }
                                    }
                                    #endregion
                                }
                                #endregion
                            }
                        case 18456:
                            {
                                #region Bad Login
                                if (context.IntegratedSecurity)
                                {
                                    string userName = String.Format(@"{0}\{1}", System.Environment.UserDomainName, System.Environment.UserName);
                                    if (String.IsNullOrEmpty(System.Environment.UserDomainName)) userName = System.Environment.UserName;

                                    throw new System.Exception(String.Format(StringsCustomerFacing.NoDatabaseConnection_LocalNamedInstance, context.DataSource.InstanceName), x);
                                }
                                else
                                {
                                    throw new System.Exception(String.Format(StringsCustomerFacing.SQLLoginFailed, context.UserID), x);
                                }
                                #endregion
                            }
                        case 10054:
                            {
                                #region Stale connection pool
                                System.Data.SqlClient.SqlConnection.ClearAllPools();
                                throw new System.Exception(String.Format("SQL Server closed the active connection. This is usually an indication that SQL Server has been re-started. The Wizard has removed all stale connections from your database connection pool in an attempt to fix this error. Please try again."), x);
                                #endregion
                            }
                        default:
                            {
                                throw;
                            }
                    }
                }
                finally
                {
                    connection.Close();
                }
            }
        }



        /// <summary>
        /// Is the server configured for mixed mode security.
        /// </summary>
        /// <param name="context">The database in question.</param>
        /// <returns></returns>
        static public bool IsMixedModeSecurity(Sage.CRE.Core.SQL.SqlConnectionContext context)
        {
            bool result = false;

            Sage.CRE.Core.SQL.SqlConnectionContext masterContext = (Sage.CRE.Core.SQL.SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = "master";


            object rObject = Sage.CRE.Core.SQL.SqlCommands.SelectScalar(masterContext, @"
declare @SmoLoginMode int
exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', @SmoLoginMode OUTPUT

SELECT (case when @SmoLoginMode < 3 then @SmoLoginMode else 9 end) AS [LoginMode]
");


            if (rObject != null)
            {
                int r = (int)rObject;
                result = (r == 2);
            }
            return result;
        }
        
        /// <summary>
        /// Renames an existing database.
        /// </summary>
        /// <param name="context">The database to rename.</param>
        /// <param name="proposedName">The proposed new name for the database</param>
        /// <param name="dropConnections">Should we forcible drop existing connections and transactions</param>
        /// <returns></returns>
        static public int RenameDatabase(SqlConnectionContext context, string proposedName, bool dropConnections)
        {
            string sql = string.Format(@"ALTER DATABASE [{0}] MODIFY NAME = [{1}]", context.InitialCatalog, proposedName);
            if (dropConnections)
            {
                sql = String.Format(@"ALTER DATABASE [{0}] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE{1}{2}", context.InitialCatalog, SqlCommandDelimiter, sql);
            }

            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = "master";

            return ExecuteScriptNoTransaction(masterContext, sql, null);
        }



        /// <summary>
        /// Rename a database without dropping existing transactions within that database.
        /// </summary>
        /// <param name="context">The database to rename.</param>
        /// <param name="proposedName">The proposed name for the database.</param>
        /// <returns></returns>
        static public int RenameDatabase(SqlConnectionContext context, string proposedName)
        {

            return RenameDatabase(context, proposedName, false);
        }

        /// <summary>
        /// Is a database ready?
        /// </summary>
        /// <param name="context">The context for the server.</param>
        /// <param name="retryCount">How many retries (each one waits a second), before we admit failure.</param>
        /// <returns>If the database is ready.</returns>
        static public bool IsDatabaseReady(SqlConnectionContext context, int retryCount)
        {
            bool result = false;
            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = "master";
            string sql = String.Format("select * from sysdatabases where [name] = '{0}'", context.InitialCatalog);
            if (SelectDataTable(masterContext, sql).Rows.Count == 0) return false;

            string connectionString = context.ConnectionString;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                while (retryCount-- > 0)
                {
                    try
                    {
                        connection.Open();

                        result = true;
                        break;

                    }
                    catch (System.Data.SqlClient.SqlException)
                    {
                        System.Threading.Thread.Sleep(1000);
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }

            return result;
        }

        
        
        /// <summary>Returns whether athe specified datbase exists (or at least will accept connections from this user).
        /// </summary>
        /// <param name="context">The database in question.</param>
        /// <returns></returns>
        static public bool DatabaseExists(SqlConnectionContext context)
        {
            bool result = false;

            try
            {
                SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
                masterContext.InitialCatalog = "master";

                string sql = String.Format("select * from sysdatabases where [name] = '{0}'", context.InitialCatalog);
                if (SelectDataTable(masterContext, sql).Rows.Count == 0) return false;

                string connectionString = context.ConnectionString;
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        result = true;

                    }
                    catch (System.Data.SqlClient.SqlException x)
                    {
						System.Diagnostics.Debug.WriteLine(x.Message);
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            catch (System.Data.SqlClient.SqlException x)
            {
                System.Diagnostics.Debug.WriteLine(x.Message);
            }

            return result;
        }

        /// <summary>
        /// Returns a scalar value from the database.
        /// </summary>
        /// <param name="context">Teh database to execute the query against.</param>
        /// <param name="script">The command to execute.</param>
        /// <returns></returns>
        static public object SelectScalar(SqlConnectionContext context, string script)
        {
            object result = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(context.ConnectionString))
            {
                try
                {
                    connection.Open();

                    using (System.Data.SqlClient.SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandText = script;
                        command.CommandTimeout = (!String.IsNullOrEmpty(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT"))) ? System.Convert.ToInt32(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT")) : 60;

                        command.CommandType = System.Data.CommandType.Text;
                        result = command.ExecuteScalar();
                    }
                }
                finally
                {
                    connection.Close();
                }
            }

            return result;

        }



        /// <summary>Selects a datatable from the specified server\database using the specified Transact-SQL command
        /// </summary>
        /// <param name="context">The context of the database to execute the query against.</param>
        /// <param name="script">The Transact-SQL script that returns rows into the DataTable</param>
        /// <returns></returns>
        static public System.Data.DataTable SelectDataTable(SqlConnectionContext context, string script)
        {
            System.Data.DataTable result = new System.Data.DataTable();
            result.Locale = System.Globalization.CultureInfo.InvariantCulture;
            string connectionString = context.ConnectionString;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (System.Data.SqlClient.SqlCommand command = connection.CreateCommand())
                    {

                        command.CommandText = script;
                        command.CommandTimeout = (!String.IsNullOrEmpty(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT"))) ? System.Convert.ToInt32(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT")) : 60;

                        command.CommandType = System.Data.CommandType.Text;
                        using (System.Data.SqlClient.SqlDataAdapter adapter = new System.Data.SqlClient.SqlDataAdapter(command))
                        {
                            adapter.Fill(result);
                        }
                    }
                }
                finally
                {
                    connection.Close();
                }
            }

            return result;

        }

        /// <summary>Executes a scripts that doesn't return rows, without wrapping the script in an execution.
        /// This is usefull for DDL and database modification command (which cannot be within transaction), e.g. "ALTER DATABASE"
        /// </summary>
        /// <param name="context">The database context.</param>
        /// <param name="script">The Transact-SQL script (or command) to execute.</param>
        /// <returns>The number of row effected by the commands in the script.</returns>
        static public int ExecuteScriptNoTransaction(SqlConnectionContext context, string script)
        {
            return ExecuteScriptNoTransaction(context, script, null);
        }

        /// <summary>Executes a scripts that doesn't return rows, without wrapping the script in an execution.
        /// This is usefull for DDL and database modification command (which cannot be within transaction), e.g. "ALTER DATABASE"
        /// </summary>
        /// <param name="context">The database context.</param>
        /// <param name="script">The Transact-SQL script (or command) to execute.</param>
        /// <param name="updateProgress">The interface to use to update progress while executing the commands in the script</param>
        /// <returns>The number of row effected by the commands in the script.</returns>
        static public int ExecuteScriptNoTransaction(SqlConnectionContext context, string script, IExecuteScriptProgress updateProgress)
        {
            int result = 0;
            string connectionString = context.ConnectionString;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (System.Data.SqlClient.SqlCommand command = connection.CreateCommand())
                    {
                        string cleanScript = script.Replace("\r\n", System.Environment.NewLine);
                        cleanScript = cleanScript + System.Environment.NewLine;
                        string[] sqlCommands = cleanScript.Split(new string[] { SqlCommands.SqlCommandDelimiter }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (string sqlCommand in sqlCommands)
                        {
                            command.CommandType = System.Data.CommandType.Text;
                            command.CommandText = sqlCommand;
                            command.CommandTimeout = 0;

                            try
                            {
                                result += command.ExecuteNonQuery();
                            }
                            catch (System.Data.SqlClient.SqlException sqlCommandException)
                            {
                                Console.WriteLine(String.Format(System.Globalization.CultureInfo.InvariantCulture, "{0} : {1}", command.CommandText, sqlCommandException.Message));
                                throw;
                            }
                            finally
                            {
                                if (updateProgress != null)
                                {
                                    updateProgress.PerformStep();
                                }
                            }
                        }
                    }
                }
                finally
                {
                    connection.Close();
                }
            }

            return result;
        }


        /// <summary>
        /// Sets and extended property on the database called "DatabaseVersion" to the value sepcified.
        /// </summary>
        /// <param name="context">The database context.</param>
        /// <param name="major">The major version number.</param>
        /// <param name="minor">The minor version number.</param>
        public static void SetDatabaseVersionNumber(SqlConnectionContext context, int major, int minor)
        {
            SetDatabaseExtendedProperty(context, "DatabaseMajorVersion", major);
            SetDatabaseExtendedProperty(context, "DatabaseMinorVersion", minor);
        }

        /// <summary>
        /// Gets an extended property from the database called DatabaseMajorVersion.
        /// </summary>
        /// <param name="context">The database context.</param>
        /// <returns></returns>
        public static int GetDatabaseMajorVersionNumber(SqlConnectionContext context)
        {
            object vo = SqlCommands.SelectScalar(context, "SELECT [dbo].[GetDatabaseMajorVersion]()");
            if ((vo == null) || (vo == DBNull.Value)) return 0;
            return (int) vo;
        }

        /// <summary>
        /// Gets an extended property from the database called DatabaseMinorVersion.
        /// </summary>
        /// <param name="context">The database context.</param>
        /// <returns></returns>
        public static int GetDatabaseMinorVersionNumber(SqlConnectionContext context)
        {
            object vo = SqlCommands.SelectScalar(context, "SELECT [dbo].[GetDatabaseMinorVersion]()");
            if ((vo == null) || (vo == DBNull.Value)) return 0;
            return (int)vo;
        }


        /// <summary>
        /// Sets an extended property on the database to the value specified.
        /// </summary>
        /// <param name="context">The database context.</param>
        /// <param name="propertyName">The property name.</param>
        /// <param name="propertyValue">The properties value.</param>
        public static void SetDatabaseExtendedProperty(SqlConnectionContext context, string propertyName, string propertyValue)
        {
            string command = String.Format(@"
IF not exists (select * from sys.extended_properties where name = '{0}')
	EXEC sp_addextendedproperty @name=N'{0}', @value=N'{1}'
ELSE
	EXEC sp_updateextendedproperty @name=N'{0}', @value=N'{1}'
", propertyName, propertyValue);
            SqlCommands.ExecuteScriptNoTransaction(context, command, null);
        }

        /// <summary>
        /// Sets an extanded integer property on the the database to the value specified.
        /// </summary>
        /// <param name="context">the database context.</param>
        /// <param name="propertyName">The name of the property to set.</param>
        /// <param name="propertyValue">The integer value for the property.</param>
        public static void SetDatabaseExtendedProperty(SqlConnectionContext context, string propertyName, int propertyValue)
        {
            string command = String.Format(@"
IF not exists (select * from sys.extended_properties where name = '{0}')
	EXEC sp_addextendedproperty @name=N'{0}', @value={1}
ELSE
	EXEC sp_updateextendedproperty @name=N'{0}', @value={1}
", propertyName, propertyValue);
            SqlCommands.ExecuteScriptNoTransaction(context, command, null);
        }


        /// <summary>
        /// Sets the dataset name.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="dataSetName"></param>
        public static void SetDataSetName(SqlConnectionContext context, string dataSetName)
        {
            SetDatabaseExtendedProperty(context, "DataSetName", dataSetName);
        }


        /// <summary>
        /// Gets an extended property from the database.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public static string GetDatabaseExtendedProperty(SqlConnectionContext context, string propertyName)
        {
            string result = null;
            string command = String.Format(@"SELECT [value]
FROM fn_listextendedproperty(default, default, default, default, default, default, default)
where [name] = '{0}'", propertyName);
            using (System.Data.DataTable results = SelectDataTable(context, command))
            {
                if (results.Rows.Count == 1)
                {
                    result = results.Rows[0]["value"].ToString();
                }
            }
            return result;
        }



        /// <summary>Gets a list of any old database whose name starts with the databasePattern string.
        /// </summary>
        /// <param name="context">The context of the database.</param>
        /// <param name="databasePattern">The pattern to look for</param>
        /// <param name="keepCount">how many to keep.</param>
        static public System.Collections.ObjectModel.Collection<string> GetOldDatabases(SqlConnectionContext context, string databasePattern, int keepCount)
        {
            System.Collections.ObjectModel.Collection<string> result = new System.Collections.ObjectModel.Collection<string>();
            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = "master";

            string connectionString = masterContext.ConnectionString;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();


                    using (System.Data.DataTable targets = new System.Data.DataTable(@"Targets"))
                    {
                        targets.Locale = System.Globalization.CultureInfo.InvariantCulture;

                        using (System.Data.SqlClient.SqlCommand command = connection.CreateCommand())
                        {
                            string targetCommand = String.Format(System.Globalization.CultureInfo.InvariantCulture, @"SELECT * FROM sys.databases where name not in (select top {1} name from sys.databases where name like '{0}%' order by create_date desc) and name like '{0}%'", databasePattern, keepCount);

                            command.CommandText = targetCommand;
                            command.CommandTimeout = (!String.IsNullOrEmpty(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT"))) ? System.Convert.ToInt32(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT")) : 60;

                            command.CommandType = System.Data.CommandType.Text;
                            using (System.Data.SqlClient.SqlDataAdapter adapter = new System.Data.SqlClient.SqlDataAdapter(command))
                            {
                                adapter.Fill(targets);
                            }
                        }

                        connection.Close();

                        foreach (System.Data.DataRow row in targets.Rows)
                        {
                            string targetDatabase = row[@"name"].ToString();
                            result.Add(targetDatabase);
                        }
                    }
                }
                finally
                {
                    connection.Close();
                }

            }

            return result;
        }





        /// <summary>Deletes any old database whose name starts with the databasePattern string.
        /// </summary>
        /// <param name="context">The database context.</param>
        /// <param name="databasePattern"></param>
        /// <param name="keepCount"></param>
        static public System.Collections.ObjectModel.Collection<string> DeleteOldDatabases(SqlConnectionContext context, string databasePattern, int keepCount)
        {
            System.Collections.ObjectModel.Collection<string> deletedDatabases = new System.Collections.ObjectModel.Collection<string>();
            System.Collections.ObjectModel.Collection<string> candidates = GetOldDatabases(context, databasePattern, keepCount);
            foreach (string database in candidates)
            {
                SqlConnectionContext victimContext = (SqlConnectionContext)context.Clone();
                victimContext.InitialCatalog = database;
                if (DropDatabase(victimContext, true))
                {
                    deletedDatabases.Add(database);
                }
            }

            return deletedDatabases;
        }



        /// <summary>Creates a database login with an optional password
        /// </summary>
        /// <param name="context">The database server.</param>
        /// <param name="login">The login to create.</param>
        /// <param name="password">An optional password. Set to null for no password.</param>
        /// <param name="defaultDatabase">The default database for the new login.</param>
        #region Static Analysis Supressions
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "login")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Login")]
        #endregion
        static public void CreateLogin(SqlConnectionContext context, string login, string password, string defaultDatabase)
        {
            string command;
            if (!String.IsNullOrEmpty(password))
            {
                command = String.Format(System.Globalization.CultureInfo.InvariantCulture, @"IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'{0}') CREATE LOGIN [{0}] WITH PASSWORD=N'{1}', DEFAULT_DATABASE=[{2}]", login, password, defaultDatabase);
            }
            else
            {
                command = String.Format(System.Globalization.CultureInfo.InvariantCulture, @"IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'{0}') CREATE LOGIN [{0}] WITH DEFAULT_DATABASE=[{1}]", login, defaultDatabase);
            }

            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = "master";
            ExecuteScriptNoTransaction(masterContext, command, null);

        }



        /// <summary>Creates a new database
        /// </summary>
        /// <param name="context">The datbase server.</param>
        /// <param name="dataFile">The full file name of the MDF file to create.</param>
        /// <param name="logFile">The full file name of the LDF file to create.</param>
        static public void CreateDatabase(SqlConnectionContext context, string dataFile, string logFile)
        {
            string create = String.Format(System.Globalization.CultureInfo.InvariantCulture, @"CREATE DATABASE [{0}] ON PRIMARY ( NAME = N'{0}', FILENAME = N'{1}.mdf' ) LOG ON ( NAME = N'{0}_log', FILENAME = N'{2}_log.LDF' ) COLLATE Latin1_General_CI_AS", context.InitialCatalog, dataFile, logFile);

            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = "master";
            SqlCommands.ExecuteScriptNoTransaction(masterContext, create, null);
        }


        /// <summary>
        /// Sets the database into Simple mode recovery.
        /// </summary>
        /// <param name="context"></param>
        static public void SimpleModeRecovery(SqlConnectionContext context)
        {
            string simple = String.Format(@"ALTER DATABASE [{0}] SET RECOVERY SIMPLE", context.InitialCatalog);
            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = "master";
            SqlCommands.ExecuteScriptNoTransaction(masterContext, simple, null);
        }



        /// <summary>Drops an existing database.
        /// </summary>
        /// <param name="context">The datbase server.</param>
        /// <param name="force">Force the </param>
        static public bool DropDatabase(SqlConnectionContext context, bool force)
        {
            try
            {
                if (force) SingleUser(context);
                string dropDatabase = String.Format(System.Globalization.CultureInfo.InvariantCulture, @"DROP DATABASE [{0}]", context.InitialCatalog);
                SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
                masterContext.InitialCatalog = @"master";

                int rows = SqlCommands.ExecuteScriptNoTransaction(masterContext, dropDatabase, null);
            }
            catch
            {
                if (force) MultiUser(context);
                throw;
            }
            return true;
        }


        /// <summary>
        /// Gets the previous versions of a database.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
        static public System.Collections.Generic.List<string> GetPreviousDatabaseVersions(SqlConnectionContext context)
        {
            List<string> result = new List<string>();
            string versionCommand = String.Format(System.Globalization.CultureInfo.InvariantCulture, @"select [name] from sys.databases where name like '{0} v[0-9]%' order by create_date desc", context.InitialCatalog);

            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = @"master";

            System.Data.DataTable versions = SqlCommands.SelectDataTable(masterContext, versionCommand);
            foreach (System.Data.DataRow row in versions.Rows)
            {
                result.Add(row[@"name"].ToString());
            }

            return result;
        }



        /// <summary>Sets the specified database into single user mode.
        /// </summary>
        /// <param name="context">The datbase server.</param>
        static public void SingleUser(SqlConnectionContext context)
        {
            string singleUser = String.Format(System.Globalization.CultureInfo.InvariantCulture, @"ALTER DATABASE [{0}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE", context.InitialCatalog);

            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = @"master";

            SqlCommands.ExecuteScriptNoTransaction(masterContext, singleUser,null);
        }



        /// <summary>Set the specified database into multi user mode
        /// </summary>
        /// <param name="context"></param>
        #region Static Analysis Supressions
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Multi")]
        #endregion
        static public void MultiUser(SqlConnectionContext context)
        {
            string multiUser = String.Format(System.Globalization.CultureInfo.InvariantCulture, @"ALTER DATABASE [{0}] SET MULTI_USER", context.InitialCatalog);
            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = @"master";

            SqlCommands.ExecuteScriptNoTransaction(masterContext, multiUser, null);
        }



        /// <summary>Detach the database from the server.
        /// </summary>
        /// <param name="context">The datbase server.</param>
        /// <param name="force">If set to true, the database will be forced into single user mode before it is detached.</param>
        static public void DetachDatabase(SqlConnectionContext context, bool force)
        {
            try
            {
                if (force) SingleUser(context);
                string detachCommand = String.Format(System.Globalization.CultureInfo.InvariantCulture, @"EXEC sp_detach_db '{0}', 'true'", context.InitialCatalog.Replace(@"'",@"''"));

                SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
                masterContext.InitialCatalog = @"master";

                ExecuteScriptNoTransaction(masterContext, detachCommand, null);
            }
            catch
            {
                if (force) MultiUser(context);
                throw;
            }
        }



        /// <summary>Attaches a database from a given MDF and LDF file.
        /// </summary>
        /// <param name="context">The datbase server.</param>
        /// <param name="mdf">The full file name of the MDF file.</param>
        /// <param name="ldf">The full file name of the LDF file.</param>
        #region Static Analysis Supressions
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "mdf")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "ldf")]
        #endregion
        static public void AttachDatabase(SqlConnectionContext context, string mdf, string ldf)
        {
            string command;
            if (!String.IsNullOrEmpty(ldf))
            {
                command = String.Format(System.Globalization.CultureInfo.InvariantCulture, @"CREATE DATABASE [{0}] ON (FILENAME = '{1}'), (FILENAME ='{2}') FOR ATTACH", context.InitialCatalog, mdf, ldf);
            }
            else
            {
                command = String.Format(@"CREATE DATABASE [{0}] ON (FILENAME = '{1}') FOR ATTACH", context.InitialCatalog, mdf);
            }

            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = @"master";

            ExecuteScriptNoTransaction(masterContext, command, null);

            MultiUser(context);

        }



        /// <summary>Asks SQL server for the default locations for new MDF and LDF files.
        /// </summary>
        /// <param name="context">The datbase server.</param>
        /// <param name="data">The default directory for new MDF files.</param>
        /// <param name="log">The defaults directory for new LDF files.</param>
        #region Static Analysis Supressions
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "2#")]
        #endregion
        static public void GetDefaultFileLocations(SqlConnectionContext context, out string data, out string log)
        {
            data = String.Empty;
            log = String.Empty;

            string command = @"
declare @SmoDefaultFile nvarchar(512)
declare @SmoDefaultLog nvarchar(512)
exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultData', @SmoDefaultFile OUTPUT
exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultLog', @SmoDefaultLog OUTPUT

select @SmoDefaultFile [File], @SmoDefaultLog [Log]
";

            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = @"master";
            using (System.Data.DataTable files = SelectDataTable(masterContext, command))
            {
                if (files.Rows.Count == 1)
                {
                    System.Data.DataRow row = files.Rows[0];
                    if (!row.IsNull(0)) data = row[0].ToString();
                    if (!row.IsNull(1)) log = row[1].ToString();
                }
            }

            if ((String.IsNullOrEmpty(data)) || (String.IsNullOrEmpty(log)))
            {
                throw new System.Data.DataException(StringsCustomerFacing.DatabaseLibrary_SQLDefaults_MessageContent_YouMustDefineAValidDatabaseDefaultLocationInSQLServerManagmentStudio);
            }
        }

        /// <summary>
        /// Returns whether parameter sniffing has been disabled
        /// </summary>
        /// <param name="context">The database to test</param>
        /// <returns></returns>
        static public bool IsParameterSniffingDisabled(SqlConnectionContext context)
        {
            bool result = false;

            using (System.Data.DataTable results = SelectDataTable(context, "DBCC TRACESTATUS(4136)"))
            {
                if (results.Rows.Count == 1)
                {
                    short status = (short)results.Rows[0]["Status"];
                    result = (status == 1);
                }
            }

            return result;
        }

        /// <summary>
        /// Returns whether we have a database that has been migrated but is not finalized (i.e. 
        /// temporary indeces, sprocs, functions, etc. have not been torn out after migration was completed).
        /// If this is not migrated data, or if it is but finalize has properly been run, this method returns false.
        /// </summary>
        /// <param name="context">The database to test</param>
        /// <returns>true if this is a migrated database that was not finalized in the Data Migration Assistant, otherwise false</returns>
        static public Boolean IsUnfinalizedMigration(SqlConnectionContext context)
        {
            // If this is not a migrated database, don't continue.
            if (!MigrationInfoTableExists(context))
            {
                return false;
            }

            // If we are a migrated database, assume it's unfinalized until we determine for sure that it 
            // is in fact finalized
            Boolean isUnfinalizedMigration = true;

            // If we are a migrated database, ensure that the Migration State 
            // is set to "Finalized". If not, return true (this is an unfinalized migration)
            String query = @"SELECT VALUE FROM MIGRATION.MIGRATIONINFO WHERE Item = 'Migration State'";
            String value = null;

            using (System.Data.SqlClient.SqlConnection connection =
                    new System.Data.SqlClient.SqlConnection(context.ConnectionString))
            {
                try
                {
                    connection.Open();
                    using (System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(query, connection))
                    {
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            value = (String)result;

                            if (String.Compare(value, "Finalized", true) == 0)
                            {
                                isUnfinalizedMigration = false;
                            }
                        }
                    }
                }
                catch
                {
                    // If we get here, we have a migrated database that has an undetermined finalization 
                    // state, which is an error condition. Return true to prevent the database from being attached.
                    isUnfinalizedMigration = true;
                }
                finally
                {
                    connection.Close();
                }
            }

            return isUnfinalizedMigration;
        }

        /// <summary>
        /// Determines whether this is a migrated database by checking to see if the Migration.MigrationInfo
        /// table exists in the system.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        static private Boolean MigrationInfoTableExists(SqlConnectionContext context)
        {
            Boolean exists = false;
            String query = @"SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES 
                    WHERE TABLE_SCHEMA = 'Migration' AND TABLE_NAME = 'MigrationInfo'";

            using (System.Data.SqlClient.SqlConnection connection =
                    new System.Data.SqlClient.SqlConnection(context.ConnectionString))
            {
                try
                {
                    connection.Open();
                    using (System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(query, connection))
                    {
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            int count = (int)result;
                            if (count > 0)
                            {
                                exists = true;
                            }
                        }
                    }
                }
                catch
                {
                    // Erring on allowing the database attach to continue in the case where the attempt 
                    // to determine whether the migration table exists throws an exception.  If there is a connection
                    // problem, we won't get too much further anyway.
                    exists = false;
                }
                finally
                {
                    connection.Close();
                }
            }
            return exists;
        }

        /// <summary>
        /// Gets the data/time when the database was built.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        static public System.DateTime GetBuildDateTime(SqlConnectionContext context)
        {
            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = @"master";
            using (System.Data.DataTable rows = SelectDataTable(masterContext, String.Format(@"select create_date from sys.databases where [name] = '{0}'", context.InitialCatalog)))
            {
                return (System.DateTime)rows.Rows[0]["create_date"];
            }
        }


        /// <summary>
        /// Remove " WITH NOCHECK" from a file.
        /// </summary>
        /// <param name="filename"></param>
        public static void RemoveWithNoCheck(string filename)
        {
            using (System.IO.StreamReader sr = new System.IO.StreamReader(filename))
            {
                string contents = sr.ReadToEnd();
                sr.Close();

                contents = contents.Replace(" WITH NOCHECK", "");

                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(filename))
                {
                    sw.Write(contents);
                }
            }

        }

        /// <summary>
        /// Gets a list of database.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static List<string> GetDatabases(SqlConnectionContext context)
        {
            List<string> catalogs = new List<string>();

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(context.ConnectionString))
            {
                try
                {
                    connection.Open();
                    using (System.Data.SqlClient.SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = System.Data.CommandType.Text;
                        command.CommandText = "SELECT [name] FROM [sys].[databases]";
                        command.CommandTimeout = (!String.IsNullOrEmpty(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT"))) ? System.Convert.ToInt32(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT")) : 60;

                        using (System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader())
                        {
                            try
                            {
                                if (reader.HasRows)
                                {
                                    while (reader.Read())
                                    {
                                        catalogs.Add(reader.GetString(0));
                                    }
                                }
                            }
                            finally
                            {
                                reader.Close();
                            }
                        }
                    }
                }
                catch
                {
                }
                finally
                {
                    connection.Close();
                }
            }

            return catalogs;
        }

    }
}
