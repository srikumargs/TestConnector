using System;
using System.Collections;
using System.DirectoryServices;


namespace Sage.Net
{
    /// <summary>
    /// Summary description for GroupCollection.
    /// </summary>
    public class DomainCollection
      : CollectionBase
      , IDomainCollection
    {

        /// <summary>
        /// ctor
        /// </summary>
        public DomainCollection()
            : base()
        {
        }

        /// <summary>
        /// Indexer into the group collection
        /// </summary>
        public IDomain this[int index]
        {
            get
            {
                return (IDomain)_collection[index];
            }
        }

        /// <summary>
        /// Populates the domain collection
        /// </summary>
        public override void PopulateCollection()
        {
            _collection.Clear();

            try
            {
                DirectoryEntry de = new DirectoryEntry("WinNT:");
                de.Children.SchemaFilter.Add("domain");

                foreach (DirectoryEntry deIter in de.Children)
                {
                    _collection.Add(new Domain(deIter.Name));
                }
            }
            catch (Exception ex)
            {
                throw new NetworkException("Error retrieving domain list", ex);
            }
        }

    }
}
