using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Xml;
using System.Xml.XPath;

using Sage.Activation;

namespace TraceConfigTool
{
    public partial class TraceConfigControl : UserControl
    {
        #region Constructors
        public TraceConfigControl()
        {
            InitializeComponent();

            _traceSwitchesControl.Reset();
        }
        #endregion

        #region Public methods
        public void FileNew()
        {
            if(PromptForSaveIfDataChanged())
            {
                _dataChanged = false;
                _fileName = string.Empty;
                _debugOutputOptionsControl.Reset();
                _logFileOutputOptionsControl.Reset();

                _traceSwitchesControl.Reset();

                FireDataStateChanged(new DataStateChangedEventArgs(false, string.Empty));
            }
        }

        private bool PromptForSaveIfDataChanged()
        {
            bool result = true;

            if(DataChanged)
            {
                DialogResult dialogResult = MessageBox.Show(this.ParentForm, "Save changes?", "Trace Configuration Tool", MessageBoxButtons.YesNoCancel);
                switch(dialogResult)
                {
                    case DialogResult.Yes:
                        if(!string.IsNullOrEmpty(FileName))
                        {
                            if(FileSave() == DialogResult.OK)
                            {
                                result = true;
                            }
                        }
                        else
                        {
                            if(FileSaveAs() == DialogResult.OK)
                            {
                                result = true;
                            }
                        }
                        break;

                    case DialogResult.No:
                        result = true;
                        break;

                    case DialogResult.Cancel:
                        result = false;
                        break;
                }
            }

            return result;
        }

        public void FileOpen()
        {
            if(PromptForSaveIfDataChanged())
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Configuration Files (*.config;*.exe.config;*.dll.config)|*.config;*.exe.config;*.dll.config|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 0;
                openFileDialog.Title = "Open Configuration File";
                openFileDialog.AddExtension = true;
                openFileDialog.CheckFileExists = true;
                openFileDialog.CheckPathExists = true;
                openFileDialog.Multiselect = false;
                openFileDialog.ShowReadOnly = false;
                openFileDialog.ValidateNames = true;
                if(openFileDialog.ShowDialog(this.ParentForm) == DialogResult.OK)
                {
                    _fileName = openFileDialog.FileName;

                    XmlDocument document = new XmlDocument();
                    document.Load(_fileName);

                    _debugOutputOptionsControl.Reset(document);
                    _logFileOutputOptionsControl.Reset(document);

                    _traceSwitchesControl.Reset(document);

                    FireDataStateChanged(new DataStateChangedEventArgs(false, Path.GetFileName(openFileDialog.FileName)));
                }
            }
        }

        public DialogResult FileSave()
        {
            if(!string.IsNullOrEmpty(FileName))
            {
                PrivateFileSave();
            }
            else
            {
                FileSaveAs();
            }

            return DialogResult.OK;
        }

        public DialogResult FileSaveAs()
        {
            SaveFileDialog saveAsFileDialog = new SaveFileDialog();
            saveAsFileDialog.AddExtension = true;
            saveAsFileDialog.CheckFileExists = false;
            saveAsFileDialog.CheckPathExists = true;
            saveAsFileDialog.CreatePrompt = false;
            saveAsFileDialog.DefaultExt = ".exe.config";
            saveAsFileDialog.Filter = "Configuration Files (*.config;*.exe.config;*.dll.config)|*.config;*.exe.config;*.dll.config|All files (*.*)|*.*";
            saveAsFileDialog.OverwritePrompt = true;
            saveAsFileDialog.SupportMultiDottedExtensions = true;
            saveAsFileDialog.Title = "Save Configuration File As";
            DialogResult dialogResult = saveAsFileDialog.ShowDialog(this.ParentForm);
            if(dialogResult == DialogResult.OK)
            {
                _fileName = saveAsFileDialog.FileName;
                PrivateFileSave();
            }

            return dialogResult;
        }

        private string GenerateXmlToSave()
        {
            Stream stream = new MemoryStream();
            stream.Position = 0;
            XmlTextWriter xmlTextWriter = new XmlTextWriter(stream, Encoding.UTF8);
            
            xmlTextWriter.Formatting = Formatting.Indented;
            xmlTextWriter.WriteStartDocument(true);
            {
                xmlTextWriter.WriteStartElement("configuration");
                {
                    xmlTextWriter.WriteStartElement("configSections");
                    {
                        _debugOutputOptionsControl.WriteConfigSectionElement(xmlTextWriter);
                        _logFileOutputOptionsControl.WriteConfigSectionElement(xmlTextWriter);
                    }
                    xmlTextWriter.WriteEndElement(); // configSections

                    _debugOutputOptionsControl.WriteCustomConfigSectionElement(xmlTextWriter);
                    _logFileOutputOptionsControl.WriteCustomConfigSectionElement(xmlTextWriter);

                    xmlTextWriter.WriteStartElement("system.diagnostics");
                    {
                        xmlTextWriter.WriteStartElement("switches");
                        {
                            _traceSwitchesControl.WriteSwitchElements(xmlTextWriter);
                        }
                        xmlTextWriter.WriteEndElement(); // switches

                        xmlTextWriter.WriteStartElement("trace");
                        {
                            xmlTextWriter.WriteAttributeString("autoflush", "true");
                            xmlTextWriter.WriteAttributeString("indentsize", "4");

                            xmlTextWriter.WriteStartElement("listeners");
                            {
                                xmlTextWriter.WriteStartElement("remove");
                                {
                                    xmlTextWriter.WriteAttributeString("name", "Default");
                                }
                                xmlTextWriter.WriteEndElement(); // remove

                                _debugOutputOptionsControl.WriteAddListenerElement(xmlTextWriter);
                                _logFileOutputOptionsControl.WriteAddListenerElement(xmlTextWriter);
                            }
                            xmlTextWriter.WriteEndElement(); // lisenters
                        }
                        xmlTextWriter.WriteEndElement(); // trace
                    }
                    xmlTextWriter.WriteEndElement(); // system.diagnostics
                }
                xmlTextWriter.WriteEndElement(); // configuration
            }
            xmlTextWriter.WriteEndDocument();
            xmlTextWriter.Flush();

            stream.Position = 0;
            StreamReader streamReader = new StreamReader(stream, true);
            string result = streamReader.ReadToEnd();

            xmlTextWriter.Close();

            return result;
        }

        private void PrivateFileSave()
        {
            if(File.Exists(FileName))
            {
                FileAttributes fileAttributes = File.GetAttributes(FileName);
                if((fileAttributes & FileAttributes.ReadOnly) > 0)
                {
                    if(MessageBox.Show(this.ParentForm, "File is marked as read-only.  Overwrite?", "Trace Configuration Tool", MessageBoxButtons.YesNo) == DialogResult.No)
                    {
                        return;
                    }

                    File.SetAttributes(FileName, fileAttributes & ~FileAttributes.ReadOnly);
                }

                // The destination file already exists.  We would like to merge-in our changes to the existing file.
                XmlDocument existingDocument = new XmlDocument();
                try
                {
                    existingDocument.Load(FileName);
                }
                catch(Exception)
                {
                    // do nothing if we cannot load the document ... it already isn't valid xml;  make it valid by creating a root
                    existingDocument.AppendChild(existingDocument.CreateElement("configuration"));
                }

                // delete the nodes that we must overwrite from the existing document
                XPathNavigator existingDocumentNavigator = existingDocument.CreateNavigator();

                XPathNavigator navigator = existingDocumentNavigator.SelectSingleNode("//configuration/configSections/section[@name='DebugOutputWriterConfigSection']");
                if(navigator != null)
                {
                    navigator.DeleteSelf();
                }

                navigator = existingDocumentNavigator.SelectSingleNode("//configuration/configSections/section[@name='TextFileWriterConfigSection']");
                if(navigator != null)
                {
                    navigator.DeleteSelf();
                }

                navigator = existingDocumentNavigator.SelectSingleNode("//configuration/DebugOutputWriterConfigSection");
                if(navigator != null)
                {
                    navigator.DeleteSelf();
                }

                navigator = existingDocumentNavigator.SelectSingleNode("//configuration/TextFileWriterConfigSection");
                if(navigator != null)
                {
                    navigator.DeleteSelf();
                }

                navigator = existingDocumentNavigator.SelectSingleNode("//configuration/system.diagnostics/switches");
                if(navigator != null)
                {
                    navigator.DeleteSelf();
                }

                navigator = existingDocumentNavigator.SelectSingleNode("//configuration/system.diagnostics/trace");
                if(navigator != null)
                {
                    navigator.DeleteSelf();
                }

                navigator = existingDocumentNavigator.SelectSingleNode("//configuration/configSections");
                if(navigator == null)
                {
                    navigator = existingDocumentNavigator.SelectSingleNode("//configuration");
                    if(navigator.MoveToFirstChild())
                    {
                        navigator.InsertElementBefore(null, "configSections", null, null);
                    }
                    else
                    {
                        navigator.AppendChildElement(null, "configSections", null, null);
                    }
                }


                // create a document that contains just the trace config information
                XmlDocument traceConfigDocument = new XmlDocument();
                traceConfigDocument.LoadXml(GenerateXmlToSave());
                
                // creat a document that contains the original data from the existing document without any old trace config
                XmlDocument existingDocumentWithoutTraceConfigData = new XmlDocument();
                existingDocumentWithoutTraceConfigData.LoadXml((existingDocumentNavigator.UnderlyingObject as XmlDocument).InnerXml);

                // merge the two xml documents
                XmlDocument resultDocument = XmlMerge.Merge(existingDocumentWithoutTraceConfigData, traceConfigDocument, true);
                resultDocument.Save(FileName);
            }
            else
            {
                XmlDocument document = new XmlDocument();
                document.LoadXml(GenerateXmlToSave());
                document.Save(FileName);
            }

            FireDataStateChanged(new DataStateChangedEventArgs(false, Path.GetFileName(FileName)));
        }

        public void ScanAssemblyReferences()
        {
        }
        #endregion

        public event EventHandler DataStateChanged;


        private bool DataChanged
        {
            get
            {
                return _dataChanged;
            }
        }

        private string FileName
        {
            get
            {
                return _fileName;
            }
        }

        #region Private methods
        private void FireDataStateChanged(DataStateChangedEventArgs dataStateChangedEventArgs)
        {
            _dataChanged = dataStateChangedEventArgs.Dirty;

            if(DataStateChanged != null)
            {
                DataStateChanged(this, dataStateChangedEventArgs);
            }
        }

        private void _traceSwitchesControl_DataChanged(object s, EventArgs e)
        {
            FireDataStateChanged(new DataStateChangedEventArgs(true, Path.GetFileName(FileName)));
        }

        private void _debugOutputOptionsControl_DataChanged(object sender, EventArgs e)
        {
            FireDataStateChanged(new DataStateChangedEventArgs(true, Path.GetFileName(FileName)));
        }

        private void _logFileOutputOptionsControl_DataChanged(object sender, EventArgs e)
        {
            FireDataStateChanged(new DataStateChangedEventArgs(true, Path.GetFileName(FileName)));
        }
        #endregion

        #region Private fields
        private bool _dataChanged;
        private string _fileName;
        #endregion

        private void _resetButton_Click(object sender, EventArgs e)
        {
            _debugOutputOptionsControl.Reset();
            _logFileOutputOptionsControl.Reset();
        }

        private void _newToolStripButton_Click(object sender, EventArgs e)
        {
            FileNew();
        }

        private void _openToolStripButton_Click(object sender, EventArgs e)
        {
            FileOpen();
        }

        private void _saveToolStripButton_Click(object sender, EventArgs e)
        {
            FileSave();
        }

        private void _saveAsToolStripButton_Click(object sender, EventArgs e)
        {
            FileSaveAs();
        }
    }
}
