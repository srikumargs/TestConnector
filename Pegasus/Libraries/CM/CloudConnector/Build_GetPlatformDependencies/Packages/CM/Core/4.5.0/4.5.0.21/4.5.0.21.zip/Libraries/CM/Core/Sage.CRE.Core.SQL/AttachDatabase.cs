﻿using System;
using System.Collections.Generic;

namespace Sage.CRE.Core.SQL
{
    /// <summary>Attaches a database from a MDF/LDF file set using the Reversible Action pattern.
    /// The construction of a AttachDatabase object will attach the specified database from the specified files.
    /// If the object is disposed without calling the Commit() method, then the newly attached database will be detached.
    /// </summary>
    public class AttachDatabase : Sage.IO.ReversibleAction.ReversibleActionBase
    {

        /// <summary>
        /// Attaches a MDF/LDF file set to a database.
        /// The MDF and LDF files are first copied to the specified database server's default database file location.
        /// </summary>
        /// <param name="context">The database server that the MDF and LDF files will be attached to.</param>
        /// <param name="mdf">The MDF file to attach.</param>
        /// <param name="ldf">(Optional) The LDF file to attach.</param>
        /// <returns>True, if the attachment was successfull.</returns>
        static public bool Attach(SqlConnectionContext context, string mdf, string ldf)
        {
            // Clean up the file names
            bool result = false;
            mdf = System.Environment.ExpandEnvironmentVariables(mdf);
            ldf = System.Environment.ExpandEnvironmentVariables(ldf);

            mdf = mdf.ToUpper(System.Globalization.CultureInfo.CurrentUICulture);
            ldf = ldf.ToUpper(System.Globalization.CultureInfo.CurrentUICulture);

            // Find where SQL server wants its data files
            string dataLocation; string logLocation;
            SqlCommands.GetDefaultFileLocations(context, out dataLocation, out logLocation);


            // Figure out what the names of the MDF and LDF will be on the SQL server
            Dictionary<string, string> files = new Dictionary<string, string>();
            System.DateTime now = System.DateTime.Now;
            string copiedMDF = System.IO.Path.Combine(dataLocation, System.IO.Path.GetFileNameWithoutExtension(mdf)) + now.ToFileTimeUtc() + ".MDF";
            files.Add(mdf, copiedMDF);

            string copiedLDF = String.Empty;
            if (!String.IsNullOrEmpty(ldf))
            {
                copiedLDF = System.IO.Path.Combine(logLocation, System.IO.Path.GetFileNameWithoutExtension(ldf)) + now.ToFileTimeUtc() + ".LDF";
                files.Add(ldf, copiedLDF);
            }
            else
            {
                copiedLDF = System.IO.Path.Combine(logLocation, System.IO.Path.GetFileNameWithoutExtension(mdf)) + now.ToFileTimeUtc() + ".LDF";
            }

            // Copy the source MDF and LDF files to the SQL server
            using (Sage.IO.ReversibleAction.FileCopy fileCopy = new Sage.IO.ReversibleAction.FileCopy(files, true, false, false, false))
            {
                fileCopy.Forward();

                // Rename the existing database (if it exists)
                using (RenameDatabase rename = new RenameDatabase(context))
                {
                    rename.Forward();

                    // Attach the new database
                    using (AttachDatabase attach = new AttachDatabase(context, copiedMDF, copiedLDF))
                    {
                        attach.Forward();

                        while (!SqlCommands.DatabaseExists(context)) System.Threading.Thread.Sleep(1000);
                        result = true;
                        attach.Commit();
                    }

                    rename.Commit();
                }

                fileCopy.Commit();
            }
            System.Data.SqlClient.SqlConnection.ClearAllPools();

            return result;
        }



        #region Private members
        private SqlConnectionContext _context = new SqlConnectionContext();
        private string _mdf;
        private string _ldf;
        private bool _attached;
        #endregion

        /// <summary>Creates the AttachDatabase object
        /// </summary>
        /// <param name="context">The context of the datbase to create.</param>
        /// <param name="mdf"></param>
        /// <param name="ldf"></param>
        public AttachDatabase(SqlConnectionContext context, string mdf, string ldf)
        {
            _context = context;
            _mdf = mdf;
            _ldf = ldf;
        }


        /// <summary>Attaches the database.
        /// </summary>
        public override void Forward()
        {
            base.Forward();

            SqlCommands.AttachDatabase(_context, _mdf, _ldf);
            _attached = true;
            
        }



        /// <summary>Reverses the attachment of the database.
        /// </summary>
        public override void Reverse()
        {
            if (_attached)
            {
                SqlCommands.DetachDatabase(_context, true);
                _attached = false;
            }

            base.Reverse();
        }
    }
}
