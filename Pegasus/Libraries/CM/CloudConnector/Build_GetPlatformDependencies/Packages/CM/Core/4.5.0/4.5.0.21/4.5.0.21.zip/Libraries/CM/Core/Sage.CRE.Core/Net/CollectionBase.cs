using System;
using System.Collections;

namespace Sage.Net
{
    /// <summary>
    /// Summary description for CollectionBase.
    /// Contains common implementation for collections of servers, users 
    /// and groups.
    /// </summary>
    public abstract class CollectionBase
    {
        /// <summary>
        /// The actual collection of network items (servers, users, groups, etc).
        /// </summary>
        protected ArrayList _collection;

        /// <summary>
        /// ctor
        /// </summary>
        protected CollectionBase()
        {
            _Initialize();
        }

        private void _Initialize()
        {
            _collection = new ArrayList();
            _domain = Environment.UserDomainName;
        }

        /// <summary>
        /// Domain on which to look for network information
        /// </summary>
        protected internal string _domain;
        /// <summary>
        /// Accessor for the Domain on which to look for information
        /// </summary>
        // 
        public string Domain
        {
            get { return _domain; }
            set { _domain = value; }
        }

        /// <summary>
        /// Returns an enumerator to the server collection
        /// </summary>
        /// <returns></returns>
        public IEnumerator GetEnumerator()
        {
            return (IEnumerator)_collection.GetEnumerator();
        }

        /// <summary>
        /// Returns the number of servers in the collection
        /// </summary>
        public int Count
        {
            get { return _collection.Count; }
        }


        /// <summary>
        /// Populate the collection using the default (current user's) domain
        /// </summary>
        public void Populate()
        {
            PopulateCollection();
        }

        /// <summary>
        /// Populate the collection using the specified domain
        /// </summary>
        /// <param name="domain"></param>
        public void Populate(string domain)
        {
            _domain = domain;
            PopulateCollection();
        }

        /// <summary>
        /// Populates the collection
        /// </summary>
        abstract public void PopulateCollection();
    }
}
