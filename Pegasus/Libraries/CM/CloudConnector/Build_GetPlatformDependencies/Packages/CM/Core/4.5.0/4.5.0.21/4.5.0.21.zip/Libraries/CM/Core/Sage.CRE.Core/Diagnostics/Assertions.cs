using System;
using System.Diagnostics;
using System.Text;
using System.Runtime.InteropServices;

namespace Sage.Diagnostics
{
    internal enum WindowStationMode
    {
        /// <summary>
        /// The WindowStationMode is unknown (i.e., hasn't been evaluated yet)
        /// </summary>
        None            = 0,

        /// <summary>
        /// The process is attached to the interactive window station
        /// </summary>
        Interactive     = 1,

        /// <summary>
        /// The process is attached to a non-interactive window station
        /// </summary>
        NonInteractive  = 2
    }

    /// <summary>
    /// The Assertions class provides a thin wrapper over 
    /// the .Net framework's Debug.Assert capability.
    /// This class was created so that you could disable 
    /// interactive assertions within a debug build of the
    /// software. This cabability may be usefull for
    /// running unit test which test for negative conditions.
    /// </summary>
    [TraceListenerIgnoreTypeAttribute]
    public class Assertions
    {
        #region Fields

        /// <summary>
        /// A flag that indicates if interactive assertions should be enabled or not
        /// </summary>
        private static bool _enabled = true;

#if DEBUG // we don't need to bother including the code for if we don't have DEBUG defined
        /// <summary>
        /// A flag that indicates if the process can interact with the desktop
        /// </summary>
        private static WindowStationMode _windowStationMode; // = WindowStationMode.None;  (automatically initialized by runtime)
#endif

        #endregion

        #region Properties

        /// <summary>
        /// Get/Set whether interactive assertions should be enabled or not
        /// </summary>
        public static bool Enabled
        {
            get 
            {
                lock (typeof(Assertions))
                {
                    return _enabled;
                }
            }
            set 
            {
                lock (typeof(Assertions))
                {
                    _enabled = value;
                }
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Checks a condition and displays a message if the result is false
        /// </summary>
        /// <param name="condition">The condition to check</param>
        [Conditional("DEBUG")] // clients shouldn't bother including a call to this function if they don't have DEBUG defined
        public static void Assert(bool condition) 
        {
#if DEBUG // we don't need to bother including the code for the implementation of this method if we don't have DEBUG defined
            if (!condition)
            {
                if (Enabled && WindowStationMode.Interactive == WindowStationMode)
                {
                    Debug.Assert(condition);
                }

                ErrorTrace.WriteLine(null, Strings.AssertionFailed);
            }
#endif
        }

        /// <summary>
        /// Checks a condition and displays a message if the result is false
        /// </summary>
        /// <param name="condition">The condition to check</param>
        /// <param name="message">The Message to display</param>
        [Conditional("DEBUG")] // clients shouldn't bother including a call to this function if they don't have DEBUG defined
        public static void Assert(bool condition, string message) 
        {
#if DEBUG // we don't need to bother including the code for the implementation of this method if we don't have DEBUG defined
            if (!condition)
            {
                if (Enabled && WindowStationMode.Interactive == WindowStationMode)
                {
                    Debug.Assert(condition, message);
                }

                ErrorTrace.WriteLine(null, Strings.AssertionFailedFormat, message);
            }
#endif
        }

        /// <summary>
        /// Checks for a condition and displays both specified messages if the condition is false
        /// </summary>
        /// <param name="condition">The condition to check</param>
        /// <param name="message">The Message to display</param>
        /// <param name="detailMessage">A detailed message to display</param>
        [Conditional("DEBUG")] // clients shouldn't bother including a call to this function if they don't have DEBUG defined
        public static void Assert(bool condition, string message, string detailMessage)
        {
#if DEBUG // we don't need to bother including the code for the implementation of this method if we don't have DEBUG defined
            if (!condition)
            {
                if (Enabled && WindowStationMode.Interactive == WindowStationMode)
                {
                    Debug.Assert(condition, message, detailMessage);
                }

                ErrorTrace.WriteLine(null, Strings.AssertionFailed2Format, message, detailMessage);
            }
#endif
        }
        #endregion

        #region Private properties
#if DEBUG // we don't need to bother including the code for the implementation of this method if we don't have DEBUG defined
        /// <summary>
        /// Returns the WindowStationMode of the current process.  Some processes
        /// may not normally interact with the desktop (e.g., Windows Services).
        /// </summary>
        private static WindowStationMode WindowStationMode
        {
            get
            {
                if(WindowStationMode.None == _windowStationMode)
                {
                    IntPtr windowStation = IntPtr.Zero;
                    if(IntPtr.Zero == (windowStation = User32.GetProcessWindowStation()))
                    {
                        ErrorTrace.WriteLine(null, "Failed to GetProcessWindowStation();  last error = {0}", Marshal.GetLastWin32Error());

                        // something unexpected happened ... set the mode to NonInteractive so that we are not perpetually trying to 
                        // evaluate the WindowStationMode;
                        _windowStationMode = WindowStationMode.NonInteractive;
                    }
                    else
                    {
                        WinUser.USEROBJECTFLAGS userObjectFlags = new WinUser.USEROBJECTFLAGS();
                        IntPtr userObjectFlagsPointer = Marshal.AllocHGlobal(Marshal.SizeOf(userObjectFlags));
                        try
                        {
                            Marshal.StructureToPtr(userObjectFlags, userObjectFlagsPointer, false);
                        
                            int lengthNeeded = 0;
                            if(!User32.GetUserObjectInformation(windowStation, WinUser.UOI_FLAGS, userObjectFlagsPointer, Marshal.SizeOf(userObjectFlags), out lengthNeeded))
                            {
                                ErrorTrace.WriteLine(null, "Failed to GetUserObjectInformation();  last error = {0}", Marshal.GetLastWin32Error());

                                // something unexpected happened ... set the mode to NonInteractive so that we are not perpetually trying to 
                                // evaluate the WindowStationMode;
                                _windowStationMode = WindowStationMode.NonInteractive;
                            }
                            else
                            {
                                userObjectFlags = (WinUser.USEROBJECTFLAGS) Marshal.PtrToStructure(userObjectFlagsPointer, typeof(WinUser.USEROBJECTFLAGS));
                                if(WinUser.WSF_VISIBLE == (userObjectFlags.dwFlags & WinUser.WSF_VISIBLE))
                                {
                                    _windowStationMode = WindowStationMode.Interactive;
                                }
                                else
                                {
                                    _windowStationMode = WindowStationMode.NonInteractive;
                                }
                            }
                        }
                        finally
                        {
                            Marshal.FreeHGlobal(userObjectFlagsPointer);
                            userObjectFlagsPointer = IntPtr.Zero;
                        }
                    }
                }

                return _windowStationMode;
            }
        }
#endif
        #endregion
    }
}
