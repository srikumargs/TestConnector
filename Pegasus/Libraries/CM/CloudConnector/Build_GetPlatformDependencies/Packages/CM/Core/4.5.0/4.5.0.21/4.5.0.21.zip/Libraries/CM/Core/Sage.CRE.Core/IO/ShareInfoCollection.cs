using System;
using System.IO;
using System.Collections;
using System.Runtime.InteropServices;
using System.Globalization;
using System.Threading;

using Sage.Diagnostics;
using Sage.PInvoke;

namespace Sage.IO
{	
	/// <summary>
	/// A collection of shared objects on either a local or remote machine.  Unfortunately, the .NET Framework
	/// (ver. 2.0 as of this writing) does not support this functionality. When this object is constructed, 
	/// it will enumerate the shared objects on the specified machine.  You can then call methods to extract 
	/// the (cached) information.  If you choose to re-use an instance, call the Refresh method to get the 
	/// latest information on shares.
	/// </summary>
	public class ShareInfoCollection : ReadOnlyCollectionBase
	{
		#region Private Data
		private string _server;
		private static ShareInfoCollection _local = null;
		#endregion

		#region Constants
		/// <summary>No error</summary>
		protected const int NO_ERROR = 0;

		/// <summary>Access denied</summary>
		protected const int ERROR_ACCESS_DENIED = 5;

		/// <summary>More data available</summary>
		protected const int ERROR_MORE_DATA = 234;

		/// <summary>Not connected</summary>
		protected const int ERROR_NOT_CONNECTED = 2250;

		/// <summary>Level 1</summary>
		protected const int UNIVERSAL_NAME_INFO_LEVEL = 1;

		/// <summary>Preferred length of data to get back from NetShareEnum.</summary>
		protected const int preferredMaxLength = -1;
		#endregion
		
		/// <summary>
		/// Default constructor - retrieves share information for the local machine.
		/// </summary>
		public ShareInfoCollection()
		{
			_server = string.Empty;
			EnumerateShares( _server, this );
		}

		/// <summary>
		/// Constructor with server name - retrieves share information for the specified machine.
		/// </summary>
		/// <param name="server">Name of machine to retrieve share information for.</param>
		public ShareInfoCollection(
			string server )
		{
			_server = server;
			EnumerateShares( _server, this );
		}

		/// <summary>
		/// Re-populates collection based on current shares.
		/// </summary>
		public void Refresh()
		{
			EnumerateShares( _server, this );
		}

		/// <summary>
		/// Enumerates the shares on the specified system.  Only supported on Windows NT and above.
		/// </summary>
		/// <param name="server">The server name.</param>
		/// <param name="shares">The ShareInfoCollection.</param>
		protected static void EnumerateShares(
			string server,
			ShareInfoCollection shares )
		{
			// default level requires admin privileges
			int level = 2;

			int entriesRead = 0;
			int totalEntries = 0;
			int nRet = 0;
			int hResume = 0;
			IntPtr pBuffer = IntPtr.Zero;

			try 
			{
				nRet = PInvoke.NetApi.NetShareEnum(
					server,
					level,
					out pBuffer,
					preferredMaxLength, 
					out entriesRead,
					out totalEntries,
					ref hResume );

				if (ERROR_ACCESS_DENIED == nRet) 
				{
					//Need admin for level 2, drop to level 1
					level = 1;
					nRet = PInvoke.NetApi.NetShareEnum(
						server,
						level,
						out pBuffer,
						preferredMaxLength,
						out entriesRead,
						out totalEntries,
						ref hResume );
				}

				if( NO_ERROR == nRet && 
					entriesRead > 0 ) 
				{
					// need to be careful here - returned info depends on level we specified earlier
					Type t = ( 2 == level ) ? typeof( SHARE_INFO_2 ) : typeof( SHARE_INFO_1 );
					int offset = Marshal.SizeOf( t );

					for( int i = 0, lpItem = pBuffer.ToInt32(); i < entriesRead; i++, lpItem+=offset ) 
					{
						IntPtr pItem = new IntPtr( lpItem );
						if( 1 == level )
						{
							SHARE_INFO_1 si = ( SHARE_INFO_1 ) Marshal.PtrToStructure( pItem, t );
							shares.Add(
								si.NetName,
								string.Empty,
								si.ShareType,
								si.Remark );
						}
						else 
						{
							SHARE_INFO_2 si = ( SHARE_INFO_2 ) Marshal.PtrToStructure( pItem, t );
							shares.Add(
								si.NetName,
								si.Path,
								si.ShareType,
								si.Remark );
						}
					}
				}
			}
			finally
			{
				// Clean up buffer allocated by system
				if( IntPtr.Zero != pBuffer )
				{
					PInvoke.NetApi.NetApiBufferFree( pBuffer );
				}
			}
		}
		
		/// <summary>
		/// Returns true if file path is a valid local file-name of the form:
		/// X:\, where X is a drive letter from A-Z.
		/// </summary>
		/// <param name="fullFilePath">The filename to verify.</param>
		/// <returns>True if the supplied file name is valid; false otherwise.</returns>
		public static bool IsValidFilePath(
			string fullFilePath )
		{	
			if( string.IsNullOrEmpty( fullFilePath ) ||
				fullFilePath.Length < 3 )
			{
				return false;
			}
			char drive = char.ToUpper( fullFilePath[ 0 ] );
			if( 'A' > drive || drive > 'Z' )
			{
				return false;
			}
			else if( Path.VolumeSeparatorChar != fullFilePath[ 1 ] )
			{
				return false;
			}
			else if( Path.DirectorySeparatorChar != fullFilePath[ 2 ] )
			{
				return false;
			}
			else
			{
				return true;
			}
		}

		/// <summary>
		/// Returns the UNC path for a mapped drive or local share.
		/// </summary>
		/// <param name="fullFilePath">The path to map to UNC.</param>		
		/// <returns>The UNC path (if available).</returns>
		public static string PathToUNC(
			string fullFilePath )
		{
			ArgumentValidator.ValidateNonEmptyString( fullFilePath, "fullFilePath", "ShareInfoCollection.PathToUNC" );

			fullFilePath = Path.GetFullPath( fullFilePath );
			if( !IsValidFilePath( fullFilePath ) )
			{
				string msg = string.Format(
						Thread.CurrentThread.CurrentCulture,
						Strings.ErrMsgInvalidPath,
						fullFilePath );
				throw new ArgumentException( msg );		
			}

			int nRet;
			string uncPath = PathUtils.UNCPathFromMappedFolder(	fullFilePath, out nRet );

			switch( nRet )
			{
				case NO_ERROR:
					return uncPath;

				case ERROR_NOT_CONNECTED:
					//Local file-name
					ShareInfoCollection shi = LocalShares;
					if( null != shi )
					{
						ShareInfo share = shi[ fullFilePath ];
						if( null != share )
						{
							string path = share.Path;
							if( ! string.IsNullOrEmpty( path ) )
							{
								int index = path.Length;
								if( Path.DirectorySeparatorChar != path[ path.Length - 1 ] )
								{
									index++;
								}
								
								fullFilePath = index < fullFilePath.Length ? fullFilePath.Substring( index ) : string.Empty;
								
								fullFilePath = Path.Combine(share.ToString(), fullFilePath);
							}
						}
					}					
					return fullFilePath;

				default:			
					string msg = string.Format(
						Thread.CurrentThread.CurrentCulture,
						Strings.ErrMsgUnkRetVal,
						nRet );
					throw new ApplicationException( msg );
			}
		}

		/// <summary>
		/// Returns the local <see cref="ShareInfo"/> object with the best match
		/// to the specified path.
		/// </summary>
		/// <param name="fullFilePath">Full path to shared file.</param>
		/// <returns>Share information for provided shared file.</returns>
		public static ShareInfo PathToShare(
			string fullFilePath )
		{
			ArgumentValidator.ValidateNonNullReference( fullFilePath, "fullFilePath", "ShareInfoCollection.PathToShare" );

			fullFilePath = Path.GetFullPath( fullFilePath );

			if( !IsValidFilePath( fullFilePath ) )
			{
				return null;
			}

			ShareInfoCollection shi = LocalShares;
			if( null == shi )
			{
				return null;
			}
			else
			{
				return shi[ fullFilePath ];
			}
		}

		/// <summary>
		/// Return the local shares.
		/// </summary>
		public static ShareInfoCollection LocalShares
		{
			get
			{
				if( null == _local )
				{
					_local = new ShareInfoCollection();
				}
				return _local;
			}
		}

		/// <summary>
		/// Return the shares for a specified machine.
		/// </summary>
		/// <param name="server">Name of machine to get shared objects from.</param>
		/// <returns>Collection of information about shared objects on machine.</returns>
		public static ShareInfoCollection GetShares(
			string server )
		{
			//ArgumentValidator.ValidateNonEmptyString( server, "server", "ShareInfoCollection.GetShares" );

			return new ShareInfoCollection( server );
		}
		
		/// <summary>
		/// Add an object shared info to this collection.
		/// </summary>
		/// <param name="share">Shared info object.</param>
		protected void Add(
			ShareInfo share )
		{
			InnerList.Add( share );
		}
		
		/// <summary>
		///	Add an object shared info to this collection.
		/// </summary>
		/// <param name="netName">Name of shared object.</param>
		/// <param name="path">Path to shared object.</param>
		/// <param name="shareType">Type of shared object.</param>
		/// <param name="remark">Optional comment about shared object.</param>
		protected void Add(
			string netName,
			string path,
			ShareType shareType,
			string remark )
		{
			InnerList.Add( new ShareInfo(
				_server,
				netName,
				path,
				shareType,
				remark) );
		}
		
		#region Public Properties
		/// <summary>
		/// Returns the name of the server this collection represents.
		/// </summary>
		public string Server 
		{
			get
			{
				return _server;
			}
		}

		/// <summary>
		/// Returns the <see cref="ShareInfo"/> at the specified index.
		/// </summary>
		public ShareInfo this[int index] 
		{
			get
			{
				return ( ShareInfo )InnerList[ index ];
			}
		}

		/// <summary>
		/// Returns the <see cref="ShareInfo"/> object which matches a given local path.
		/// </summary>
		/// <param name="path">The path to match.</param>
		public ShareInfo this[ string path ] 
		{
			get 
			{
				if( string.IsNullOrEmpty( path ) )
				{
					return null;
				}
				
				path = Path.GetFullPath( path );

				if( !IsValidFilePath( path ) )
				{
					return null;
				}

				ShareInfo match = null;
				
				for( int i = 0; i < InnerList.Count; i++ ) 
				{
					ShareInfo s = ( ShareInfo ) InnerList[ i ];					
					if( s.IsFileSystem && 
						s.MatchesPath( path ) )
					{
						//Store first match
						if( null == match )
						{
							match = s;
						}
						// If this has a longer path, and this is a disk share or 
						// match is a special share, then this is a better match.
						else if( match.Path.Length < s.Path.Length )
						{
							if( ShareType.Disk == s.ShareType || 
								ShareType.Disk != match.ShareType )
							{
								match = s;
							}
						}
					}
				}

				return match;
			}
		}
		#endregion

		#region Implementation of ICollection
		/// <summary>
		/// Copy this collection to an array.
		/// </summary>
		/// <param name="array">Array to copy from.</param>
		/// <param name="index">Upper index of item to copy.</param>
		public void CopyTo(
			ShareInfo[] array,
			int index ) 
		{
			InnerList.CopyTo( array, index );
		}
		#endregion
	}
}