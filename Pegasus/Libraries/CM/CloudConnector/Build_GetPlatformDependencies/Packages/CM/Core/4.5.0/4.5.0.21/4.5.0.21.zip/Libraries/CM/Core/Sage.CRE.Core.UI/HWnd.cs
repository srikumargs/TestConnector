using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sage.CRE.Core.UI
{
    /// <summary>
    /// Class which implements IWin32Window and is useful for passing Win32 HWND handles to .NET methods which
    /// take an IWin32Window.
    /// </summary>
    public class HWnd : IWin32Window
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the HWnd class
        /// </summary>
        /// <param name="hwnd">the Win32 HWND handle</param>
        public HWnd(IntPtr hwnd)
        {
            _hwnd = hwnd;
        }
        #endregion

        #region Public properties
        /// <summary>
        /// Gets the handle to the window represented by the implementer.
        /// </summary>
        public IntPtr Handle
        {
            get
            {
                return _hwnd;
            }
        }
        #endregion

        #region Private fields
        private IntPtr _hwnd;
        #endregion
    }
}
