using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Runtime.CompilerServices;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Globalization;

using Sage.Diagnostics;

// TODO:  this class doesn't really belong necessarily in "Activation" ... but there is no good place for it
namespace Sage.Activation
{
    /// <summary>
    /// A simple EventArgs-derived generic to facilitate the usage of strongly-typed EventArgs in events without
    /// needing to create a new EventArgs type for each new event you define.
    /// </summary>
    /// <typeparam name="TValue"></typeparam>
    /// <seealso cref="System.EventArgs"/>
    public class SingleValueEventArgs<TValue> : EventArgs
    {
        #region Constructor
        /// <summary>
        /// Initializes a new instance of the SingleValueEventArgs class. 
        /// </summary>
        /// <param name="value">The value that should be exposed through the single Value property</param>
        public SingleValueEventArgs(TValue value)
        {
            _value = value;
        }
        #endregion

        #region Public properties
        /// <summary>
        /// Retrieves the value
        /// </summary>
        public TValue Value
        {
            get
            {
                return _value;
            }
        }
        #endregion

        #region Private fields
        private TValue _value;
        #endregion
    }

    /// <summary>
    /// A simple EventArgs class used to supply a String value to the receiver of the event.
    /// </summary>
    public sealed class StringEventArgs : SingleValueEventArgs<String>
    {
        #region Constructor
        /// <summary>
        /// Initializes a new instance of the StringEventArgs class. 
        /// </summary>
        /// <param name="value">The value that should be exposed through the single Value property</param>
        public StringEventArgs(String value)
            : base(value)
        {
        }
        #endregion
    }

    /// <summary>
    /// A simple EventArgs class used to supply an Int32 value to the receiver of the event.
    /// </summary>
    public sealed class Int32EventArgs : SingleValueEventArgs<Int32>
    {
        #region Constructor
        /// <summary>
        /// Initializes a new instance of the Int32EventArgs class. 
        /// </summary>
        /// <param name="value">The value that should be exposed through the single Value property</param>
        public Int32EventArgs(Int32 value)
            : base(value)
        {
        }
        #endregion
    }

    /// <summary>
    /// A simple EventArgs class used to supply a Boolean value to the receiver of the event.
    /// </summary>
    public sealed class BooleanEventArgs : SingleValueEventArgs<Boolean>
    {
        #region Constructor
        /// <summary>
        /// Initializes a new instance of the BooleanEventArgs class. 
        /// </summary>
        /// <param name="value">The value that should be exposed through the single Value property</param>
        public BooleanEventArgs(Boolean value)
            : base(value)
        {
        }
        #endregion
    }

    /// <summary>
    /// Structure used to pass a set of invocation parameters to the notification thread procedure
    /// </summary>
    internal struct DoNotifyThreadProcParameters
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the DoNotifyThreadProcParameters structure.
        /// </summary>
        /// <param name="delegateToInvoke">The delegate to invoke</param>
        /// <param name="args">Arguments to pass to the delegate</param>
        public DoNotifyThreadProcParameters(Delegate delegateToInvoke, Object[] args, MisbehavingDelegatesCallback callback)
        {
            ArgumentValidator.ValidateNonNullReference(delegateToInvoke, "delegateToInvoke", _myTypeName + ".DoNotifyThreadProcParameters");

            _delegateToInvoke = delegateToInvoke;
            _args = args;
            _callback = callback;
        }
        #endregion

        #region Public properties
        /// <summary>
        /// Retrieve the delegate to invoke
        /// </summary>
        public Delegate DelegateToInvoke
        {
            get
            {
                return _delegateToInvoke;
            }
        }

        /// <summary>
        /// Retrieve the arguments to pass to the delegate
        /// </summary>
        public Object[] Args
        {
            get
            {
                return _args;
            }
        }

        public MisbehavingDelegatesCallback Callback
        {
            get
            {
                return _callback;
            }
        }
        #endregion

        #region Private fields
        /// <summary>
        /// The delegate to invoke
        /// </summary>
        private readonly Delegate _delegateToInvoke;

        /// <summary>
        /// Arguments to pass to the delegate
        /// </summary>
        private readonly Object[] _args;
        private static String _myTypeName = typeof(DoNotifyThreadProcParameters).FullName;
        private readonly MisbehavingDelegatesCallback _callback;
        #endregion
    }

    public delegate void MisbehavingDelegatesCallback(ReadOnlyCollection<Delegate> delegates);

    /// <summary>
    /// Static class used to facilitate implementing fault isolation between event publishers and subscribers
    /// </summary>
    public static class EventsHelper
    {
        #region Public methods
        /// <summary>
        /// Invokes all delegates synchronously;  catches exceptions thrown by any single delegate in order to ensure that 
        /// all delegates get a chance to receive the event
        /// </summary>
        /// <param name="eventHandler">The delegates to be notified.</param>
        /// <param name="sender">The source of the event. </param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        public static void Notify(EventHandler eventHandler, Object sender, EventArgs e)
        {
            ArgumentValidator.ValidateNonNullReference(eventHandler, "eventHandler", _myTypeName + ".Notify");

            DoNotify(eventHandler, new object[] { sender, e }, null);
        }

        /// <summary>
        /// Invokes all delegates synchronously;  catches exceptions thrown by any single delegate in order to ensure that 
        /// all delegates get a chance to receive the event;  returns a collection of delegates which are "misbehaved" (i.e.,
        /// threw an exception).
        /// </summary>
        /// <remarks>
        /// Call EventsHelper.RemoveDelegatesFromEventHandler, passing it the misbehavingDelegates, in order to remove them from
        /// the eventHandler.
        /// </remarks>
        /// <param name="eventHandler">The delegates to be notified.</param>
        /// <param name="sender">The source of the event. </param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        /// <param name="misbehavingDelegates">A collection of delegates that threw an exception.</param>
        public static void Notify(EventHandler eventHandler, Object sender, EventArgs e, out ReadOnlyCollection<Delegate> misbehavingDelegates)
        {
            ArgumentValidator.ValidateNonNullReference(eventHandler, "eventHandler", _myTypeName + ".Notify");

            misbehavingDelegates = DoNotify(eventHandler, new object[] { sender, e }, null);
        }

        /// <summary>
        /// Invokes all delegates synchronously;  catches exceptions thrown by any single delegate in order to ensure that 
        /// all delegates get a chance to receive the event
        /// </summary>
        /// <typeparam name="TEventArgs">The type of the event data generated by the event.</typeparam>
        /// <param name="eventHandler">The delegates to be notified.</param>
        /// <param name="sender">The source of the event. </param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        public static void Notify<TEventArgs>(EventHandler<TEventArgs> eventHandler, Object sender, TEventArgs e) where TEventArgs : EventArgs
        {
            ArgumentValidator.ValidateNonNullReference(eventHandler, "eventHandler", _myTypeName + ".Notify");

            DoNotify(eventHandler, new object[] { sender, e }, null);
        }

        /// <summary>
        /// Invokes all delegates synchronously;  catches exceptions thrown by any single delegate in order to ensure that 
        /// all delegates get a chance to receive the event;  returns a collection of delegates which are "misbehaved" (i.e.,
        /// threw an exception).
        /// </summary>
        /// <remarks>
        /// Call EventsHelper.RemoveDelegatesFromEventHandler, passing it the misbehavingDelegates, in order to remove them from
        /// the eventHandler.
        /// </remarks>
        /// <typeparam name="TEventArgs">The type of the event data generated by the event.</typeparam>
        /// <param name="eventHandler">The delegates to be notified.</param>
        /// <param name="sender">The source of the event. </param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        /// <param name="misbehavingDelegates">A collection of delegates that threw an exception.</param>
        public static void Notify<TEventArgs>(EventHandler<TEventArgs> eventHandler, Object sender, TEventArgs e, out ReadOnlyCollection<Delegate> misbehavingDelegates) where TEventArgs : EventArgs
        {
            ArgumentValidator.ValidateNonNullReference(eventHandler, "eventHandler", _myTypeName + ".Notify");

            misbehavingDelegates = DoNotify(eventHandler, new object[] { sender, e }, null);
        }

        /// <summary>
        /// Invokes all delegates asynchronously;  catches exceptions thrown by any single delegate in order to ensure that 
        /// all delegates get a chance to receive the event
        /// </summary>
        /// <param name="eventHandler">The delegates to be notified.</param>
        /// <param name="sender">The source of the event. </param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        public static void AsynchronousNotify(EventHandler eventHandler, Object sender, EventArgs e)
        {
            ArgumentValidator.ValidateNonNullReference(eventHandler, "eventHandler", _myTypeName + ".AsynchronousNotify");

            Thread workerThread = new Thread(new ParameterizedThreadStart(DoNotifyThreadProc));
            workerThread.Start(new DoNotifyThreadProcParameters(eventHandler, new Object[] { sender, e }, null));
        }

        /// <summary>
        /// Invokes all delegates asynchronously;  catches exceptions thrown by any single delegate in order to ensure that 
        /// all delegates get a chance to receive the event
        /// </summary>
        /// <remarks>
        /// Call EventsHelper.RemoveDelegatesFromEventHandler, passing it the misbehavingDelegates, in order to remove them from
        /// the eventHandler.
        /// </remarks>
        /// <param name="eventHandler">The delegates to be notified.</param>
        /// <param name="sender">The source of the event. </param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        /// <param name="callback">A delegate which should be called when the EventsHelper encounters one or more "misbehaved" delegates
        /// (i.e., threw an exception).</param>
        public static void AsynchronousNotify(EventHandler eventHandler, Object sender, EventArgs e, MisbehavingDelegatesCallback callback)
        {
            ArgumentValidator.ValidateNonNullReference(eventHandler, "eventHandler", _myTypeName + ".AsynchronousNotify");

            Thread workerThread = new Thread(new ParameterizedThreadStart(DoNotifyThreadProc));
            workerThread.Start(new DoNotifyThreadProcParameters(eventHandler, new Object[] { sender, e }, callback));
        }

        /// <summary>
        /// Invokes all delegates asynchronously;  catches exceptions thrown by any single delegate in order to ensure that 
        /// all delegates get a chance to receive the event
        /// </summary>
        /// <typeparam name="TEventArgs">The type of the event data generated by the event.</typeparam>
        /// <param name="eventHandler">The delegates to be notified.</param>
        /// <param name="sender">The source of the event. </param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        public static void AsynchronousNotify<TEventArgs>(EventHandler<TEventArgs> eventHandler, Object sender, TEventArgs e) where TEventArgs : EventArgs
        {
            ArgumentValidator.ValidateNonNullReference(eventHandler, "eventHandler", _myTypeName + ".AsynchronousNotify");

            Thread workerThread = new Thread(new ParameterizedThreadStart(DoNotifyThreadProc));
            workerThread.Start(new DoNotifyThreadProcParameters(eventHandler, new Object[] { sender, e }, null));
        }

        /// <summary>
        /// Invokes all delegates asynchronously;  catches exceptions thrown by any single delegate in order to ensure that 
        /// all delegates get a chance to receive the event
        /// </summary>
        /// <remarks>
        /// Call EventsHelper.RemoveDelegatesFromEventHandler, passing it the misbehavingDelegates, in order to remove them from
        /// the eventHandler.
        /// </remarks>
        /// <typeparam name="TEventArgs">The type of the event data generated by the event.</typeparam>
        /// <param name="eventHandler">The delegates to be notified.</param>
        /// <param name="sender">The source of the event. </param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        /// <param name="callback">A delegate which should be called when the EventsHelper encounters one or more "misbehaved" delegates
        /// (i.e., threw an exception).</param>
        public static void AsynchronousNotify<TEventArgs>(EventHandler<TEventArgs> eventHandler, Object sender, TEventArgs e, MisbehavingDelegatesCallback callback) where TEventArgs : EventArgs
        {
            ArgumentValidator.ValidateNonNullReference(eventHandler, "eventHandler", _myTypeName + ".AsynchronousNotify");

            Thread workerThread = new Thread(new ParameterizedThreadStart(DoNotifyThreadProc));
            workerThread.Start(new DoNotifyThreadProcParameters(eventHandler, new Object[] { sender, e }, callback));
        }

        /// <summary>
        /// Removes the specified delegatesToRemove from the eventHandler provided.
        /// </summary>
        /// <param name="eventHandler">The EventHandler from which delegates should be removed.</param>
        /// <param name="delegatesToRemove">The delegates to remove from the EventHandler.</param>
        public static void RemoveDelegatesFromEventHandler(ref EventHandler eventHandler, ReadOnlyCollection<Delegate> delegatesToRemove)
        {
            if (eventHandler != null)
            {
                foreach (Delegate current in delegatesToRemove)
                {
                    eventHandler = (EventHandler)Delegate.Remove(eventHandler, current);
                }
            }
        }

        /// <summary>
        /// Removes the specified delegatesToRemove from the eventHandler provided.
        /// </summary>
        /// <typeparam name="TEventArgs">The type of the event data generated by the event.</typeparam>
        /// <param name="eventHandler">The EventHandler from which delegates should be removed.</param>
        /// <param name="delegatesToRemove">The delegates to remove from the EventHandler.</param>
        public static void RemoveDelegatesFromEventHandler<TEventArgs>(ref EventHandler<TEventArgs> eventHandler, ReadOnlyCollection<Delegate> delegatesToRemove) where TEventArgs : EventArgs
        {
            if (eventHandler != null)
            {
                foreach (Delegate current in delegatesToRemove)
                {
                    eventHandler = (EventHandler<TEventArgs>)Delegate.Remove(eventHandler, current);
                }
            }
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Fire the event on all delegates in the invocation list
        /// </summary>
        /// <param name="delegateToInvoke">The delegate to invoke</param>
        /// <param name="args">Parameters to be used when invoking the delegate</param>
        private static ReadOnlyCollection<Delegate> DoNotify(Delegate delegateToInvoke, Object[] args, MisbehavingDelegatesCallback callback)
        {
            Assertions.Assert(delegateToInvoke != null, "delegateToNull is null");

            List<Delegate> misbhavingDelegates = new List<Delegate>();
            Delegate[] delegateMethods = delegateToInvoke.GetInvocationList();
            foreach(Delegate currentDelegate in delegateMethods)
            {
                if (!InvokeDelegate(currentDelegate, args))
                {
                    misbhavingDelegates.Add(currentDelegate);
                    WarningTrace.WriteLine(null, "Added '{0}' on '{1}' to misbhavingDelegates collection (count={2}).", currentDelegate.Method.Name, currentDelegate.Method.DeclaringType.FullName, misbhavingDelegates.Count);
                }
            }

            if (misbhavingDelegates.Count > 0 && callback != null)
            {
                WarningTrace.WriteLine(null, "Invoking MisbehavingDelegatesCallback with {0} delegate(s).", misbhavingDelegates.Count);
                ISynchronizeInvoke synchronizeInvoker = callback.Target as ISynchronizeInvoke;
                if (synchronizeInvoker != null && synchronizeInvoker.InvokeRequired)
                {
                    synchronizeInvoker.Invoke(callback, new Object[] { misbhavingDelegates.AsReadOnly() });
                }
                else
                {
                    callback.DynamicInvoke(misbhavingDelegates.AsReadOnly());
                }
            }

            return misbhavingDelegates.AsReadOnly();
        }

        /// <summary>
        /// Fire the event on all delegates in the invocation list
        /// </summary>
        /// <param name="threadParameters">Parameters to be used when invoking the delegate</param>
        private static void DoNotifyThreadProc(Object threadParameters)
        {
            Assertions.Assert(threadParameters != null, "threadParameters is null");

            DoNotifyThreadProcParameters notifyParameters = (DoNotifyThreadProcParameters) threadParameters;
            DoNotify(notifyParameters.DelegateToInvoke, notifyParameters.Args, notifyParameters.Callback);
        }

        /// <summary>
        /// Invoke a delegate
        /// </summary>
        /// <param name="delegateToInvoke">The delegate to invoke</param>
        /// <param name="args">Parameters to be used when invoking the delegate</param>
        /// <remarks>
        /// If something goes wrong, this method will just log it.  The purpose of this method is to prevent a delegate from being able to
        /// adversely affect either the caller or any other delegates that are registered for the event.
        /// </remarks>
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "The purpose of this method is to do fault isoltion between event subscribers.  We must catch Exception")]
        private static Boolean InvokeDelegate(Delegate delegateToInvoke, Object[] args)
        {
            Boolean result = false;
            Assertions.Assert(delegateToInvoke != null, "delegateToInvoke is null");

            try
            {
                // If the delegate advertises that it has thread affinity (by implementing ISynchronizeInvoke)
                // then use that interface.  Otherwise simply assume that it is safe to invoke from the
                // current thread.
                ISynchronizeInvoke synchronizeInvoker = delegateToInvoke.Target as ISynchronizeInvoke;
                if (synchronizeInvoker != null && synchronizeInvoker.InvokeRequired)
                {
                    synchronizeInvoker.Invoke(delegateToInvoke, args);
                }
                else
                {
                    delegateToInvoke.DynamicInvoke(args);
                }
                result = true;
            }
            catch(Exception ex)
            {
                EventLogger.WriteMessage("EventsHelper", String.Format(CultureInfo.CurrentCulture, "Exception occurred while invoking delegate:  {0}", ex.ToString()), MessageType.Error);
            }

            return result;
        }
        #endregion

        private static String _myTypeName = typeof(EventsHelper).FullName;
    }
}
