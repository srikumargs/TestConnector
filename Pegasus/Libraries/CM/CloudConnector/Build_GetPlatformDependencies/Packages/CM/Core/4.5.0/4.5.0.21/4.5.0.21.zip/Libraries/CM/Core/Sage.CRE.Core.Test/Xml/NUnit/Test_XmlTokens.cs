#if DEBUG
using System;
using System.Runtime.InteropServices;
using NUnit.Framework;

namespace Sage.Xml.NUnit
{

    /// <summary>
    /// Tests the IMessageBoard interface through the catalog.  Make sure caching works.
    /// </summary>
    /// 

    [TestFixture]
    [ComVisible(false)]
    public class Test_XmlTokens
    {
        /// <summary>
        /// Test a normal string is not modified
        /// </summary>
        [Test]
        public void NormalXmlString()
        {
            const string s = "Some string text value";
            Assert.AreEqual(XmlStringEscape.Escape(s), s);
        }
        /// <summary>
        /// Test angle brackets get converted
        /// </summary>
        [Test]
        public void AngleBracketTest()
        {
            const string s = "<MyNode>Some string text value</MyNode>";
            const string r = "&lt;MyNode&gt;Some string text value&lt;/MyNode&gt;";
            Assert.AreEqual(XmlStringEscape.Escape(s), r);
            Assert.AreEqual(XmlStringEscape.UnEscape(r), s);
        }
        /// <summary>
        /// Test converted angle brackets do not get modified
        /// </summary>
        [Test]
        public void AngleBracketReentryTest()
        {
            const string r = "&lt;MyNode&gt;Some string text value&lt;/MyNode&gt;";
            const string s = "<MyNode>Some string text value</MyNode>";
            Assert.AreEqual(XmlStringEscape.Escape(r), r);
            Assert.AreEqual(XmlStringEscape.UnEscape(r), s);
        }
        /// <summary>
        /// Test empty string doesn't blow
        /// </summary>
        [Test]
        public void EmptyTest()
        {
            const string r = "";
            Assert.AreEqual(XmlStringEscape.Escape(r), r);
            Assert.AreEqual(XmlStringEscape.UnEscape(r), r);
        }
        /// <summary>
        /// Test a string with all replaceable tokens
        /// </summary>
        [Test]
        public void AllTokensTest()
        {
            const string s = "<>&'<>&'";
            const string r = "&lt;&gt;&amp;&apos;&lt;&gt;&amp;&apos;";
            Assert.AreEqual(XmlStringEscape.Escape(s), r);
            Assert.AreEqual(XmlStringEscape.UnEscape(r), s);
        }
        /// <summary>
        /// Test all replaced tokens are unmodified
        /// </summary>
        [Test]
        public void AllTokensReentryTest()
        {
            const string r = "&lt;&gt;&amp;&apos;&lt;&gt;&amp;&apos;";
            const string s = "<>&'<>&'";
            Assert.AreEqual(XmlStringEscape.Escape(r), r);
            Assert.AreEqual(XmlStringEscape.UnEscape(r), s);
        }
    }
}
#endif // DEBUG