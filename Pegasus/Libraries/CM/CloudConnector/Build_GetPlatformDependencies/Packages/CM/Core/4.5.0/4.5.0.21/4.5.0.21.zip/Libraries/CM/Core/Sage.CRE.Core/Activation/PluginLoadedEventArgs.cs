using System;
using System.Runtime.InteropServices;

namespace Sage.Activation
{
	/// <summary>
	/// Event arguments for the Plugin loaded event
	/// </summary>
	/// 
    [ComVisible(false)]
	public class PluginLoadedEventArgs: EventArgs
	{
        // The plugin that was loaded
        private readonly object _plugin; //= null; (automatically initialized by runtime)

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="plugin">The plugin that was loaded</param>
		public PluginLoadedEventArgs( object plugin )
		{
			_plugin = plugin;
		}

        /// <summary>
        /// Retrieve the name of the component
        /// </summary>
        public string Name
        {
            get{ return ((IPluginComponent)_plugin).Name; }
        }

        /// <summary>
        /// Retrieve the plugin component
        /// </summary>
        public object Plugin
        {
            get{ return _plugin; }
        }
	}

    /// <summary>
    /// Delegate for the plugin loaded event
    /// </summary>
    [ComVisible(false)]
    public delegate void PluginLoadedEventHandler( object sender, PluginLoadedEventArgs args );
}
