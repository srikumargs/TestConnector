namespace TraceConfigTool
{
    partial class TraceConfigControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._outputOptionsHeaderPanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this._outputOptionsHeaderLabel = new System.Windows.Forms.Label();
            this._resetButton = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this._newToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._saveAsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._outputOptionsPanel = new System.Windows.Forms.Panel();
            this._outputOptionsTabControl = new System.Windows.Forms.TabControl();
            this._debugOutputOptionsTabPage = new System.Windows.Forms.TabPage();
            this._debugOutputOptionsControl = new TraceConfigTool.OutputOptionsControl();
            this._logFileOutputOptionsTabPage = new System.Windows.Forms.TabPage();
            this._logFileOutputOptionsControl = new TraceConfigTool.OutputOptionsControl();
            this._splitter = new System.Windows.Forms.Splitter();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this._traceSwitchesControl = new TraceConfigTool.TraceSwitchesControl();
            this._outputOptionsHeaderPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this._outputOptionsPanel.SuspendLayout();
            this._outputOptionsTabControl.SuspendLayout();
            this._debugOutputOptionsTabPage.SuspendLayout();
            this._logFileOutputOptionsTabPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // _outputOptionsHeaderPanel
            // 
            this._outputOptionsHeaderPanel.BackColor = System.Drawing.SystemColors.Control;
            this._outputOptionsHeaderPanel.Controls.Add(this.panel1);
            this._outputOptionsHeaderPanel.Controls.Add(this.toolStrip1);
            this._outputOptionsHeaderPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this._outputOptionsHeaderPanel.Location = new System.Drawing.Point(0, 0);
            this._outputOptionsHeaderPanel.Margin = new System.Windows.Forms.Padding(2);
            this._outputOptionsHeaderPanel.Name = "_outputOptionsHeaderPanel";
            this._outputOptionsHeaderPanel.Size = new System.Drawing.Size(451, 54);
            this._outputOptionsHeaderPanel.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this._outputOptionsHeaderLabel);
            this.panel1.Controls.Add(this._resetButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(3);
            this.panel1.Size = new System.Drawing.Size(451, 29);
            this.panel1.TabIndex = 4;
            // 
            // _outputOptionsHeaderLabel
            // 
            this._outputOptionsHeaderLabel.BackColor = System.Drawing.Color.Transparent;
            this._outputOptionsHeaderLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._outputOptionsHeaderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._outputOptionsHeaderLabel.ForeColor = System.Drawing.SystemColors.Window;
            this._outputOptionsHeaderLabel.Location = new System.Drawing.Point(3, 3);
            this._outputOptionsHeaderLabel.Name = "_outputOptionsHeaderLabel";
            this._outputOptionsHeaderLabel.Size = new System.Drawing.Size(370, 23);
            this._outputOptionsHeaderLabel.TabIndex = 6;
            this._outputOptionsHeaderLabel.Text = "Output Options";
            this._outputOptionsHeaderLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _resetButton
            // 
            this._resetButton.BackColor = System.Drawing.SystemColors.Control;
            this._resetButton.Dock = System.Windows.Forms.DockStyle.Right;
            this._resetButton.Location = new System.Drawing.Point(373, 3);
            this._resetButton.Name = "_resetButton";
            this._resetButton.Size = new System.Drawing.Size(75, 23);
            this._resetButton.TabIndex = 0;
            this._resetButton.Text = "&Reset";
            this.toolTip1.SetToolTip(this._resetButton, "Reset all output options to default values.");
            this._resetButton.UseVisualStyleBackColor = false;
            this._resetButton.Click += new System.EventHandler(this._resetButton_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._newToolStripButton,
            this._openToolStripButton,
            this._saveToolStripButton,
            this._saveAsToolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(451, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // _newToolStripButton
            // 
            this._newToolStripButton.Image = global::TraceConfigTool.Properties.Resources.NewDocument;
            this._newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this._newToolStripButton.Name = "_newToolStripButton";
            this._newToolStripButton.Size = new System.Drawing.Size(48, 22);
            this._newToolStripButton.Text = "&New";
            this._newToolStripButton.Click += new System.EventHandler(this._newToolStripButton_Click);
            // 
            // _openToolStripButton
            // 
            this._openToolStripButton.Image = global::TraceConfigTool.Properties.Resources.Open;
            this._openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this._openToolStripButton.Name = "_openToolStripButton";
            this._openToolStripButton.Size = new System.Drawing.Size(65, 22);
            this._openToolStripButton.Text = "&Open...";
            this._openToolStripButton.Click += new System.EventHandler(this._openToolStripButton_Click);
            // 
            // _saveToolStripButton
            // 
            this._saveToolStripButton.Image = global::TraceConfigTool.Properties.Resources.Save;
            this._saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this._saveToolStripButton.Name = "_saveToolStripButton";
            this._saveToolStripButton.Size = new System.Drawing.Size(51, 22);
            this._saveToolStripButton.Text = "&Save";
            this._saveToolStripButton.Click += new System.EventHandler(this._saveToolStripButton_Click);
            // 
            // _saveAsToolStripButton
            // 
            this._saveAsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._saveAsToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this._saveAsToolStripButton.Name = "_saveAsToolStripButton";
            this._saveAsToolStripButton.Size = new System.Drawing.Size(62, 22);
            this._saveAsToolStripButton.Text = "Save &As...";
            this._saveAsToolStripButton.Click += new System.EventHandler(this._saveAsToolStripButton_Click);
            // 
            // _outputOptionsPanel
            // 
            this._outputOptionsPanel.Controls.Add(this._outputOptionsTabControl);
            this._outputOptionsPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this._outputOptionsPanel.Location = new System.Drawing.Point(0, 54);
            this._outputOptionsPanel.Name = "_outputOptionsPanel";
            this._outputOptionsPanel.Padding = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this._outputOptionsPanel.Size = new System.Drawing.Size(451, 300);
            this._outputOptionsPanel.TabIndex = 6;
            // 
            // _outputOptionsTabControl
            // 
            this._outputOptionsTabControl.Controls.Add(this._debugOutputOptionsTabPage);
            this._outputOptionsTabControl.Controls.Add(this._logFileOutputOptionsTabPage);
            this._outputOptionsTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this._outputOptionsTabControl.Location = new System.Drawing.Point(3, 3);
            this._outputOptionsTabControl.Multiline = true;
            this._outputOptionsTabControl.Name = "_outputOptionsTabControl";
            this._outputOptionsTabControl.SelectedIndex = 0;
            this._outputOptionsTabControl.Size = new System.Drawing.Size(445, 297);
            this._outputOptionsTabControl.TabIndex = 0;
            // 
            // _debugOutputOptionsTabPage
            // 
            this._debugOutputOptionsTabPage.Controls.Add(this._debugOutputOptionsControl);
            this._debugOutputOptionsTabPage.Location = new System.Drawing.Point(4, 22);
            this._debugOutputOptionsTabPage.Name = "_debugOutputOptionsTabPage";
            this._debugOutputOptionsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this._debugOutputOptionsTabPage.Size = new System.Drawing.Size(437, 271);
            this._debugOutputOptionsTabPage.TabIndex = 0;
            this._debugOutputOptionsTabPage.Text = "Debug Output Options";
            this._debugOutputOptionsTabPage.UseVisualStyleBackColor = true;
            // 
            // _debugOutputOptionsControl
            // 
            this._debugOutputOptionsControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this._debugOutputOptionsControl.Location = new System.Drawing.Point(3, 3);
            this._debugOutputOptionsControl.Name = "_debugOutputOptionsControl";
            this._debugOutputOptionsControl.OutputType = TraceConfigTool.OutputType.DebugOutput;
            this._debugOutputOptionsControl.Size = new System.Drawing.Size(431, 265);
            this._debugOutputOptionsControl.TabIndex = 0;
            this._debugOutputOptionsControl.DataChanged += new System.EventHandler(this._debugOutputOptionsControl_DataChanged);
            // 
            // _logFileOutputOptionsTabPage
            // 
            this._logFileOutputOptionsTabPage.Controls.Add(this._logFileOutputOptionsControl);
            this._logFileOutputOptionsTabPage.Location = new System.Drawing.Point(4, 22);
            this._logFileOutputOptionsTabPage.Name = "_logFileOutputOptionsTabPage";
            this._logFileOutputOptionsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this._logFileOutputOptionsTabPage.Size = new System.Drawing.Size(437, 271);
            this._logFileOutputOptionsTabPage.TabIndex = 1;
            this._logFileOutputOptionsTabPage.Text = "Log File Ouptut Options";
            this._logFileOutputOptionsTabPage.UseVisualStyleBackColor = true;
            // 
            // _logFileOutputOptionsControl
            // 
            this._logFileOutputOptionsControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this._logFileOutputOptionsControl.Location = new System.Drawing.Point(3, 3);
            this._logFileOutputOptionsControl.Name = "_logFileOutputOptionsControl";
            this._logFileOutputOptionsControl.OutputType = TraceConfigTool.OutputType.LogFile;
            this._logFileOutputOptionsControl.Size = new System.Drawing.Size(431, 265);
            this._logFileOutputOptionsControl.TabIndex = 0;
            this._logFileOutputOptionsControl.DataChanged += new System.EventHandler(this._logFileOutputOptionsControl_DataChanged);
            // 
            // _splitter
            // 
            this._splitter.Dock = System.Windows.Forms.DockStyle.Top;
            this._splitter.Location = new System.Drawing.Point(0, 354);
            this._splitter.MinSize = 150;
            this._splitter.Name = "_splitter";
            this._splitter.Size = new System.Drawing.Size(451, 3);
            this._splitter.TabIndex = 7;
            this._splitter.TabStop = false;
            // 
            // _traceSwitchesControl
            // 
            this._traceSwitchesControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this._traceSwitchesControl.Location = new System.Drawing.Point(0, 357);
            this._traceSwitchesControl.Name = "_traceSwitchesControl";
            this._traceSwitchesControl.Size = new System.Drawing.Size(451, 240);
            this._traceSwitchesControl.TabIndex = 8;
            this._traceSwitchesControl.DataChanged += new System.EventHandler(this._traceSwitchesControl_DataChanged);
            // 
            // TraceConfigControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this._traceSwitchesControl);
            this.Controls.Add(this._splitter);
            this.Controls.Add(this._outputOptionsPanel);
            this.Controls.Add(this._outputOptionsHeaderPanel);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "TraceConfigControl";
            this.Size = new System.Drawing.Size(451, 597);
            this._outputOptionsHeaderPanel.ResumeLayout(false);
            this._outputOptionsHeaderPanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this._outputOptionsPanel.ResumeLayout(false);
            this._outputOptionsTabControl.ResumeLayout(false);
            this._debugOutputOptionsTabPage.ResumeLayout(false);
            this._logFileOutputOptionsTabPage.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel _outputOptionsHeaderPanel;
        private System.Windows.Forms.Panel _outputOptionsPanel;
        private System.Windows.Forms.Splitter _splitter;
        private System.Windows.Forms.TabControl _outputOptionsTabControl;
        private System.Windows.Forms.TabPage _debugOutputOptionsTabPage;
        private System.Windows.Forms.TabPage _logFileOutputOptionsTabPage;
        private OutputOptionsControl _debugOutputOptionsControl;
        private OutputOptionsControl _logFileOutputOptionsControl;
        private TraceSwitchesControl _traceSwitchesControl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label _outputOptionsHeaderLabel;
        private System.Windows.Forms.Button _resetButton;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripButton _newToolStripButton;
        private System.Windows.Forms.ToolStripButton _openToolStripButton;
        private System.Windows.Forms.ToolStripButton _saveToolStripButton;
        private System.Windows.Forms.ToolStripButton _saveAsToolStripButton;
    }
}
