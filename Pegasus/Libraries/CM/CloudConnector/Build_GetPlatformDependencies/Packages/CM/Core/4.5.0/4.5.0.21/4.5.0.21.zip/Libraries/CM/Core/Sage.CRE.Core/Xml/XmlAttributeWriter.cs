using System;
using System.Xml;
using System.Xml.XPath;


namespace Sage.Xml
{
    /// <summary>
    /// Helper class for writing Xml attributes in well formed fragments.  Typically
    /// this is useful for attribute-normal form.  i.e.  All values are written
    /// as element attributes
    /// </summary>
    public sealed class XmlAttributeWriter
    {
        private XmlDocument _doc = new XmlDocument();

        /// <summary>
        /// Hidden
        /// </summary>
        private XmlAttributeWriter() {}

        /// <summary>
        /// Create the document from the string
        /// </summary>
        /// <param name="xml"></param>
        public XmlAttributeWriter(string xml)
        {
            _doc.LoadXml(xml);
        }

        /// <summary>
        /// Insert or Update the attribute value - the expression should evaluate to the 
        /// element node you wish to insert or update to
        /// </summary>
        /// <param name="elementExpr">evaluates to the owning element</param>
        /// <param name="attr">attribute name</param>
        /// <param name="newVal">attribute value</param>
        public void WriteAttribute(string elementExpr, string attr, string newVal)
        {
            XmlNode node = _doc.SelectSingleNode(elementExpr);
            if (node != null && node.NodeType == XmlNodeType.Element)
            {
                XmlAttributeCollection attrs = node.Attributes;
                if (attrs != null)
                {
                    XmlNode attrNode = attrs.GetNamedItem(attr, "");
                    if (attrNode != null)
                    {
                        attrNode.Value = newVal;
                        attrs.SetNamedItem(attrNode);
                    }
                    else
                    {
                        attrNode = _doc.CreateAttribute(attr);
                        attrNode.Value = newVal;
                        attrs.Append((XmlAttribute)attrNode);
                    }
                }
            }
        }


        /// <summary>
        /// Create an empty child element and append it to the element as
        /// evaluated in the given xpath expression.  Subsequently, you
        /// may call WriteAttribute with the new element expressed in the
        /// Parent Element Expression
        /// </summary>
        /// <param name="parentElementExpr"></param>
        /// <param name="elementName"></param>
        /// <returns>true if created, else false if exists</returns>
        public bool CreateElement(string parentElementExpr, string elementName)
        {
            bool created = false;
            XmlNode node = _doc.SelectSingleNode(parentElementExpr);
            if (node != null && node.NodeType == XmlNodeType.Element)
            {
                XmlNode child = _doc.SelectSingleNode(parentElementExpr + "/" + elementName);
                if (child == null)
                {
                    XmlElement elem = _doc.CreateElement(elementName);
                    if (elem != null)
                    {
                        created = true;
                        node.AppendChild(elem);
                    }
                }
            }
            return created;
        }


        /// <summary>
        /// Return the document as string
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return _doc.OuterXml;
        }
    }
}
