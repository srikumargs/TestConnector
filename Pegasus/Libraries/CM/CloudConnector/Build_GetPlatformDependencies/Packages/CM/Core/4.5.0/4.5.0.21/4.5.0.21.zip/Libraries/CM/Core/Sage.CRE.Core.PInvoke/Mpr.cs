using System;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Sage.PInvoke
{
    /// <summary>
    /// Summary description for CMpr.
    /// </summary>
    public static class Mpr
    {
        public static int WNetGetConnection(string locName, System.Text.StringBuilder remName, ref int length)
        {
            return PInvoke.SafeNativeMethods.WNetGetConnection(locName, remName, ref length);
        }
        public static int WNetGetProviderName(int dwNetType,
            System.Text.StringBuilder lpProviderName, ref int lpBufferSize)
        {
            return PInvoke.SafeNativeMethods.WNetGetProviderName(dwNetType,
                lpProviderName, ref lpBufferSize);
        }

        /// <summary>
        /// WNetOpenEnum
        /// </summary>
        public static int WNetOpenEnum(uint dwScope, uint dwType, uint dwUsage,
            [MarshalAs(UnmanagedType.AsAny)][In] Object lpNetResource, out IntPtr lphEnum)
        {
            return PInvoke.SafeNativeMethods.WNetOpenEnum(dwScope, dwType, dwUsage, lpNetResource, out lphEnum);
        }

        /// <summary>
        /// WNetEnumResource
        /// </summary>
        public static int WNetEnumResource(IntPtr hEnum, ref int lpcCount,
            IntPtr lpBuffer, ref int lpBufferSize)
        {
            return PInvoke.SafeNativeMethods.WNetEnumResource(hEnum, ref lpcCount,
                                                lpBuffer, ref lpBufferSize);
        }

        /// <summary>
        /// WNetCloseEnum
        /// </summary>
        public static int WNetCloseEnum(IntPtr hEnum)
        {
            return PInvoke.SafeNativeMethods.WNetCloseEnum(hEnum);
        }

		/// <summary>
		/// WNetGetUniversalName
		/// </summary>
		public static int WNetGetUniversalName(
			string lpLocalPath,
			int dwInfoLevel,
			ref UNIVERSAL_NAME_INFO lpBuffer,
			ref int lpBufferSize )
		{
			return PInvoke.NativeMethods.WNetGetUniversalName(
				lpLocalPath,
				dwInfoLevel,
				ref lpBuffer,
				ref lpBufferSize );
		}

		/// <summary>
		/// WNetGetUniversalName
		/// </summary>
		public static int WNetGetUniversalName(
			string lpLocalPath,
			int dwInfoLevel,
			IntPtr lpBuffer,
			ref int lpBufferSize )
		{
			return PInvoke.NativeMethods.WNetGetUniversalName(
				lpLocalPath,
				dwInfoLevel,
				lpBuffer,
				ref lpBufferSize );
		}
    }
}
