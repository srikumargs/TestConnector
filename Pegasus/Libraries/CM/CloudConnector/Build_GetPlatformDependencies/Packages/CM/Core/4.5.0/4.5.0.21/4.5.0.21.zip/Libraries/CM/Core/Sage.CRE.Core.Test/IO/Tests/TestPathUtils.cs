using System;
using System.Data;
using System.IO;
using System.Diagnostics;

using Sage.Configuration;

using NUnit.Framework;

namespace Sage.IO.Tests
{
	/// <summary>
	/// Class that tests PathUtils.
	/// </summary>
	[TestFixture]
	public class TestPathUtils
	{
		/// <summary>
		/// Static constructor to initialize the LibraryManager prior to any other members or field
		/// initialization being JIT-compiled and used.
		/// </summary>
		/// <remarks>
		/// This is needed because, in theory, the only Sage assembly that can be successfully found
		/// may be Sage.CRE.LibraryManagement.dll until the LibraryManager is initialized.
		/// </remarks>
		static TestPathUtils()
		{
            //LibraryManager.InitializeLibraries(
            //    Path.Combine( AppDomain.CurrentDomain.BaseDirectory, LibraryManager.LibraryManifestFolderName ) );
		}

		/// <summary>
		/// This test requires manual intervention, as the paths tested rely on the existence of certain
		/// folders and local shares.
		/// </summary>
		[Test, Category( "Manual" )]
		public void TestGetUNCPathFromFullFilePath()
		{
			// this path is not shared, thus should fail			
			string result = PathUtils.GetUNCPathForFilePath( @"d:\temp\alert.zip" );
			Assert.IsFalse( PathUtils.IsPathUNC( result ), "Path should not be UNC!" );

			// this path is shared			
			result = PathUtils.GetUNCPathForFilePath( @"c:\share\file.txt" );
			Assert.IsTrue( PathUtils.IsPathUNC( result ), "Path should be UNC!" );
			
			// this path is shared (mapped drive to network location)			
			result = PathUtils.GetUNCPathForFilePath( @"Z:\test.txt" );
			Assert.IsTrue( PathUtils.IsPathUNC( result ), "Path should be UNC!" );
		}

		/// <summary>
		/// This test requires manual intervention, as the paths tested rely on the existence of certain
		/// folders and local shares.
		/// </summary>
		[Test, Category( "Manual" )]
		public void TestUNCPathFromMappedFolder()
		{	
			string result = PathUtils.UNCPathFromMappedFolder( @"z:\" );
			Assert.IsTrue( PathUtils.IsPathUNC( result ), "Path should be UNC!" );

			result = PathUtils.UNCPathFromMappedFolder( @"C:\" );
			Assert.IsFalse( PathUtils.IsPathUNC( result ), "Path should not be UNC!" );

			result = PathUtils.UNCPathFromMappedFolder( @"C:\temp" );
			Assert.IsFalse( PathUtils.IsPathUNC( result ), "Path should not be UNC!" );
		}
	}
}