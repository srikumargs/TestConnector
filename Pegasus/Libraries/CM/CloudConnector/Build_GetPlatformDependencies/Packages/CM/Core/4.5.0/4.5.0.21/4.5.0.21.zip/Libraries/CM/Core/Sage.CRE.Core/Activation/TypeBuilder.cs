using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Reflection;
using System.Reflection.Emit;

using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Defines and creates new instances of classes during runtime.
    /// </summary>
    /// <remarks>
    /// TypeBuilder is a helper class which builds upon System.Reflection.Emit.TypeBuilder to facilitate the creation of dynamic classes in the runtime.
    /// TypeBuilder provides a set of routines that are used to define classes, add methods and fields, and create the class inside the runtime.
    /// </remarks>
    /// <example>
    /// The following code sample demonstrates how to build a dynamic type using TypeBuilder.
    /// <code>
    /// // Construct the dynamic type
    /// Sage.Activation.TypeBuilder typeBuilder = new Sage.Activation.TypeBuilder();
    /// typeBuilder.DefinePublicClassType("MyDynamicType");
    /// typeBuilder.DefinePublicInstanceConstructor();
    /// typeBuilder.DefinePropertyAndInstanceField("SomeIntValue", "_someIntValue", typeof(int));
    /// typeBuilder.CreateType();
    /// 
    /// // Create an instance of the dynamic type
    /// object myObject = TypeBuilder.CreateObject("MyDynamicType");
    /// 
    /// // Make calls on the dynamic type instance
    /// myObject.GetType().InvokeMember("SomeIntValue", BindingFlags.Public | BindingFlags.Instance | BindingFlags.SetProperty, null, myObject, new object[] { 1234 });
    /// int result = (int) myObject.GetType().InvokeMember("SomeIntValue", BindingFlags.Public | BindingFlags.Instance | BindingFlags.GetProperty, null, myObject, new object[] { });
    /// Sage.Diagnositics.Assertions.Assert(result == 1234);
    /// </code>
    /// </example>
    public class TypeBuilder
    {
        #region Constructors
        /// <summary>
        /// Constructs a TypeBuilder.
        /// </summary>
        public TypeBuilder() : this(null)
        {
        }

        /// <summary>
        /// Constructs a TypeBuilder which can be used to save a dynamically created assembly to disk.
        /// </summary>
        /// <param name="assemblyFileName">The name of the file to which the dynamic module should be saved.</param>
        public TypeBuilder(string assemblyFileName)
        {
            _assemblyFileName = assemblyFileName;

            AssemblyName assemblyName = new AssemblyName();
            assemblyName.Name = "Sage.DynamicAssembly." + Guid.NewGuid().ToString();

            if(!string.IsNullOrEmpty(assemblyFileName))
            {
                // if a name was provided for the assembly, then use it for the module because we will be saving the assembly to disk later on
                _assemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.RunAndSave);
                _moduleBuilder = _assemblyBuilder.DefineDynamicModule(assemblyName.Name, _assemblyFileName, true);
            }
            else
            {
                _assemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
                _moduleBuilder = _assemblyBuilder.DefineDynamicModule(assemblyName.Name, true);
            }
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Begins construction of a public class type with the specified name. 
        /// </summary>
        /// <param name="name">The full path of the type. name cannot contain embedded nulls. </param>
        public void DefinePublicClassType(string name)
        {
            Assertions.Assert(!DefiningType);

            DefinePublicClassType(name, typeof(object), Type.EmptyTypes);
        }

        /// <summary>
        /// Begins construction of a public class type given the type name, attributes, the type that the defined type extends, and the interfaces that the defined type implements. 
        /// </summary>
        /// <param name="name">The full path of the type. name cannot contain embedded nulls. </param>
        /// <param name="parentType">The type that the defined type extends. </param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the type implements.</param>
        public void DefinePublicClassType(string name, Type parentType, Type[] interfaceTypesToImplement)
        {
            Assertions.Assert(!DefiningType);

            DefineClassType(name, TypeAttributes.Public, parentType, interfaceTypesToImplement);
        }

        /// <summary>
        /// Begins construction of a class type given the type name, attributes, the type that the defined type extends, and the interfaces that the defined type implements. 
        /// </summary>
        /// <param name="name">The full path of the type. name cannot contain embedded nulls. </param>
        /// <param name="typeAttributes">The attributes to be associated with the type. </param>
        /// <param name="parentType">The type that the defined type extends. </param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the type implements.</param>
        public void DefineClassType(string name, TypeAttributes typeAttributes, Type parentType, Type[] interfaceTypesToImplement)
        {
            Assertions.Assert(!DefiningType);

            DefineType(name, typeAttributes | TypeAttributes.Class, parentType, interfaceTypesToImplement);
        }

        /// <summary>
        /// Begins construction of a type given the type name, attributes, the type that the defined type extends, and the interfaces that the defined type implements.
        /// </summary>
        /// <param name="name">The full path of the type. name cannot contain embedded nulls. </param>
        /// <param name="typeAttributes">The attributes to be associated with the type. </param>
        /// <param name="parentType">The type that the defined type extends. </param>
        /// <param name="interfaceTypesToImplement">The list of interfaces that the type implements.</param>
        public void DefineType(string name, TypeAttributes typeAttributes, Type parentType, Type[] interfaceTypesToImplement)
        {
            Assertions.Assert(!DefiningType);

            lock(_proxyTypeMap.SyncRoot)
            {
                Assertions.Assert(!_proxyTypeMap.ContainsKey(name));

                // define the new type
                _typeBuilder = _moduleBuilder.DefineType(name, typeAttributes, parentType, interfaceTypesToImplement);
                _propertyBuilders = new Hashtable();
            }
        }

        /// <summary> </summary>
        public delegate void EmitImplementationCallback(ILGenerator implementationIL, object[] data);
        /// <summary> </summary>
        public delegate void EmitMethodImplementationCallback( MethodBuilder methodBuilder, Type[] parameterTypes, ILGenerator implementationIL, object[] data );
        /// <summary> </summary>
        public delegate void EmitMethodImplementationWithMethodInfoCallback( MethodBuilder methodBuilder, MethodInfo methodInfo, Type[] parameterTypes, ILGenerator implementationIL, object[] data );

        /// <summary>
        /// Adds a new public default constructor to the type.
        /// </summary>
        /// <returns>The defined constructor. </returns>
        public ConstructorBuilder DefinePublicInstanceConstructor()
        {
            Assertions.Assert(DefiningType);

            return DefinePublicInstanceConstructor(Type.EmptyTypes, null, null);
        }

        /// <summary>
        /// Adds a new public default constructor to the type with a signature matching to the parameter types specified.
        /// </summary>
        /// <param name="parameterTypes">The types of the parameters of the constructor.</param>
        /// <returns>The defined constructor. </returns>
        public ConstructorBuilder DefinePublicInstanceConstructor(Type[] parameterTypes)
        {
            Assertions.Assert(DefiningType);

            return DefinePublicInstanceConstructor(parameterTypes, null, null);
        }

        /// <summary>
        /// Defines the public instance constructor.
        /// </summary>
        /// <param name="parameterTypes">The parameter types.</param>
        /// <param name="emitImplementationCallback">The emit implementation callback.</param>
        /// <returns></returns>
        public ConstructorBuilder DefinePublicInstanceConstructor(Type[] parameterTypes, EmitImplementationCallback emitImplementationCallback)
        {
            Assertions.Assert(DefiningType);

            return DefinePublicInstanceConstructor(parameterTypes, emitImplementationCallback, null);
        }

        /// <summary>
        /// Defines the public instance constructor.
        /// </summary>
        /// <param name="parameterTypes">The parameter types.</param>
        /// <param name="emitImplementationCallback">The emit implementation callback.</param>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        public ConstructorBuilder DefinePublicInstanceConstructor(Type[] parameterTypes, EmitImplementationCallback emitImplementationCallback, object[] data)
        {
            Assertions.Assert(DefiningType);

            return DefineConstructor(MethodAttributes.Public, CallingConventions.HasThis, parameterTypes, emitImplementationCallback, data);
        }

        /// <summary>
        /// Adds a new constructor to the type, with the given attributes and signature. 
        /// </summary>
        /// <param name="methodAttributes">The attributes of the constructor.</param>
        /// <param name="callingConventions">The calling convention of the constructor.</param>
        /// <param name="parameterTypes">The types of the parameters of the constructor.</param>
        /// <param name="emitImplementationCallback"></param>
        /// <param name="data"></param>
        /// <returns>The defined constructor. </returns>
        public ConstructorBuilder DefineConstructor(MethodAttributes methodAttributes, CallingConventions callingConventions, Type[] parameterTypes, EmitImplementationCallback emitImplementationCallback, object[] data)
        {
            Assertions.Assert(DefiningType);

            ConstructorBuilder constructorBuilder =  _typeBuilder.DefineConstructor(methodAttributes, callingConventions, parameterTypes);

            Type parentType = _typeBuilder.BaseType;

            ConstructorInfo parentConstructorInfo;

            if(parentType != null && parentType != typeof(object))
            {
                parentConstructorInfo = parentType.GetConstructor(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, Type.EmptyTypes, null);
            }
            else
            {
                parentConstructorInfo = typeof(Object).GetConstructor(new Type[0]);
            }

            ILGenerator constructorIL = constructorBuilder.GetILGenerator();

            // Load "this"
            constructorIL.Emit(OpCodes.Ldarg_0);
            // Call the parent constructor
            constructorIL.Emit(OpCodes.Call, parentConstructorInfo);

            // delegate
            if(emitImplementationCallback != null)
            {
                emitImplementationCallback(constructorIL, data);
            }
            
            // Constructor return
            constructorIL.Emit(OpCodes.Ret);

            return constructorBuilder;
        }

        /// <summary>
        /// Adds a new private instances field to the type, with the given name and field type. 
        /// </summary>
        /// <param name="name">The name of the field. fieldName cannot contain embedded nulls. </param>
        /// <param name="type">The type of the field </param>
        /// <returns>The defined field. </returns>
        public FieldBuilder DefinePrivateInstanceField(string name, Type type)
        {
            Assertions.Assert(DefiningType);

            return DefineField(name, type, FieldAttributes.Private);
        }

        /// <summary>
        /// Adds a new field to the type, with the given name, attributes and field type. 
        /// </summary>
        /// <param name="name">The name of the field. fieldName cannot contain embedded nulls. </param>
        /// <param name="type">The type of the field </param>
        /// <param name="fieldAttributes">The attributes of the field. </param>
        /// <returns>The defined field. </returns>
        public FieldBuilder DefineField(string name, Type type, FieldAttributes fieldAttributes)
        {
            Assertions.Assert(DefiningType);

            return _typeBuilder.DefineField(name, type, fieldAttributes);
        }

        /// <summary>
        /// Applies the attribute to property.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        /// <param name="attributeType">Type of the attribute.</param>
        /// <param name="attributeConstructorParameterTypes">The attribute constructor parameter types.</param>
        /// <param name="attributeConstructorArguments">The attribute constructor arguments.</param>
        public void ApplyAttributeToProperty(string propertyName, Type attributeType, Type[] attributeConstructorParameterTypes, object[] attributeConstructorArguments)
        {
            Assertions.Assert(DefiningType);
            Assertions.Assert(_propertyBuilders.ContainsKey(propertyName));

            PropertyBuilder propertyBuilder = (PropertyBuilder) _propertyBuilders[propertyName];

            ConstructorInfo constructorInfo = attributeType.GetConstructor(attributeConstructorParameterTypes);
            CustomAttributeBuilder customAttributeBuilder = new CustomAttributeBuilder(constructorInfo, attributeConstructorArguments);
            propertyBuilder.SetCustomAttribute(customAttributeBuilder);
        }

        /// <summary>
        /// Defines the property and instance field.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        /// <param name="fieldName">Name of the field.</param>
        /// <param name="type">The type.</param>
        public void DefinePropertyAndInstanceField(string propertyName, string fieldName, Type type)
        {
            Assertions.Assert(DefiningType);
            Assertions.Assert(!_propertyBuilders.ContainsKey(propertyName));

            FieldBuilder fieldBuilder = DefinePrivateInstanceField(fieldName, type);
            DefineProperty(propertyName, type);
            DefinePublicInstanceMethod("get_" + propertyName, Type.EmptyTypes, type, new TypeBuilder.EmitMethodImplementationCallback(EmitSimpleGetMethodImplementation), new object[] { fieldBuilder });
            DefinePublicInstanceMethod("set_" + propertyName, new Type[] { type }, null, new TypeBuilder.EmitMethodImplementationCallback(EmitSimpleSetMethodImplementation), new object[] { fieldBuilder });
        }

        /// <summary>
        /// Adds a new property to the type, with the given name and return type 
        /// </summary>
        /// <param name="name">The name of the property. name cannot contain embedded nulls. </param>
        /// <param name="type">The return type of the property.</param>
        public void DefineProperty(string name, Type type)
        {
            Assertions.Assert(DefiningType);
            Assertions.Assert(!_propertyBuilders.ContainsKey(name));

            DefineProperty(name, PropertyAttributes.None, type);
        }

        /// <summary>
        /// Adds a new property to the type, with the given name, property attributes, and return type 
        /// </summary>
        /// <param name="name">The name of the property. name cannot contain embedded nulls. </param>
        /// <param name="propertyAttributes">The attributes of the property. </param>
        /// <param name="type">The return type of the property.</param>
        public void DefineProperty(string name, PropertyAttributes propertyAttributes, Type type)
        {
            Assertions.Assert(DefiningType);
            Assertions.Assert(!_propertyBuilders.ContainsKey(name));

            _propertyBuilders[name] = _typeBuilder.DefineProperty(name, propertyAttributes, type, null);
        }

        /// <summary>
        /// Defines the public instance method.
        /// </summary>
        /// <param name="methodInfo">The method info.</param>
        /// <param name="emitMethodImplementationWithMethodInfoCallback">The emit method implementation with method info callback.</param>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        public MethodBuilder DefinePublicInstanceMethod(MethodInfo methodInfo, EmitMethodImplementationWithMethodInfoCallback emitMethodImplementationWithMethodInfoCallback, object[] data)
        {
            Assertions.Assert(DefiningType);

            MethodAttributes methodAttributes = MethodAttributes.Public | MethodAttributes.Virtual;

            return DefineMethod(methodInfo, methodAttributes, CallingConventions.HasThis, emitMethodImplementationWithMethodInfoCallback, data);
        }

        /// <summary>
        /// Defines the public instance method.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="parameterTypes">The parameter types.</param>
        /// <param name="returnType">Type of the return.</param>
        /// <param name="emitMethodImplementationCallback">The emit method implementation callback.</param>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        public MethodBuilder DefinePublicInstanceMethod(string name, Type[] parameterTypes, Type returnType, EmitMethodImplementationCallback emitMethodImplementationCallback, object[] data)
        {
            Assertions.Assert(DefiningType);

            MethodAttributes methodAttributes = MethodAttributes.Public | MethodAttributes.Virtual;

            return DefineMethod(name, methodAttributes, CallingConventions.HasThis, parameterTypes, returnType, emitMethodImplementationCallback, data);
        }

        /// <summary>
        /// Defines the method.
        /// </summary>
        /// <param name="methodInfo">The method info.</param>
        /// <param name="methodAttributes">The method attributes.</param>
        /// <param name="callingConventions">The calling conventions.</param>
        /// <param name="emitMethodImplementationWithMethodInfoCallback">The emit method implementation with method info callback.</param>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        public MethodBuilder DefineMethod(MethodInfo methodInfo, MethodAttributes methodAttributes, CallingConventions callingConventions, EmitMethodImplementationWithMethodInfoCallback emitMethodImplementationWithMethodInfoCallback, object[] data)
        {
            ParameterInfo[] parameterInfo = methodInfo.GetParameters();

            System.Type[] parameterTypes = new System.Type[parameterInfo.Length];

            for(int i = 0 ; i < parameterInfo.Length ; i++)
            {
                parameterTypes[i] = parameterInfo[i].ParameterType;
            }

            MethodBuilder methodBuilder = PrivateDefineMethod(methodInfo.Name, methodAttributes, callingConventions, parameterTypes, methodInfo.ReturnType);

            ILGenerator ilGenerator = methodBuilder.GetILGenerator();

            if(emitMethodImplementationWithMethodInfoCallback != null)
            {
                emitMethodImplementationWithMethodInfoCallback(methodBuilder, methodInfo, parameterTypes, ilGenerator, data);
            }

            return methodBuilder;
        }

        /// <summary>
        /// Defines the method.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="methodAttributes">The method attributes.</param>
        /// <param name="callingConventions">The calling conventions.</param>
        /// <param name="parameterTypes">The parameter types.</param>
        /// <param name="returnType">Type of the return.</param>
        /// <param name="emitMethodImplementationCallback">The emit method implementation callback.</param>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        public MethodBuilder DefineMethod(string name, MethodAttributes methodAttributes, CallingConventions callingConventions, Type[] parameterTypes, Type returnType, EmitMethodImplementationCallback emitMethodImplementationCallback, object[] data)
        {
            MethodBuilder methodBuilder = PrivateDefineMethod(name, methodAttributes, callingConventions, parameterTypes, returnType);

            ILGenerator ilGenerator = methodBuilder.GetILGenerator();

            if(emitMethodImplementationCallback != null)
            {
                emitMethodImplementationCallback(methodBuilder, parameterTypes, ilGenerator, data);
            }

            return methodBuilder;
        }

        /// <summary>
        /// Creates a Type object for the type previously defined using DefineType.
        /// </summary>
        public void CreateType()
        {
            Assertions.Assert(DefiningType);

            lock(_proxyTypeMap.SyncRoot)
            {
                Assertions.Assert(!_proxyTypeMap.ContainsKey(_typeBuilder.Name));

                // finished defining the type ... call CreateType() to indicate we are done
                Type emittedType = _typeBuilder.CreateType();
                _proxyTypeMap.Add(_typeBuilder.Name, emittedType);
            }

            _typeBuilder = null;
            _propertyBuilders.Clear();
            _propertyBuilders = null;
        }

        /// <summary>
        /// Saves this dynamic assembly to disk. 
        /// </summary>
        public void SaveAssembly()
        {
            Assertions.Assert(!DefiningType);
            Assertions.Assert(!_assemblySaved);
            Assertions.Assert(!string.IsNullOrEmpty(_assemblyFileName));

            // if a name was provided for the assembly, then use it and save the assembly to disk
            if(!string.IsNullOrEmpty(_assemblyFileName))
            {
                _assemblyBuilder.Save(_assemblyFileName);
                _assemblySaved = true;
            }
        }

        /// <summary>
        /// Gets the Type object with the specified name that was previously constructor via using the TypeBuilder.
        /// </summary>
        /// <param name="typeName">The full name of the type. </param>
        /// <returns>A Type object that represents the specified class, or a null reference (Nothing in Visual Basic) if the class is not found. </returns>
        public static Type GetType(string typeName)
        {
            Type result = null;

            lock(_proxyTypeMap.SyncRoot)
            {
                if(_proxyTypeMap.ContainsKey(typeName))
                {
                    result = (Type) _proxyTypeMap[typeName];
                }
            }

            return result;
        }

        /// <summary>
        /// Creates an instance of the specified type using the defaykt constructor.
        /// </summary>
        /// <param name="typeName">The name of the type of object to create. </param>
        /// <returns>A reference to the newly created object. </returns>
        public static object CreateObject(string typeName)
        {
            return CreateObject(typeName, new object[] { });
        }

        /// <summary>
        /// Creates an instance of the specified type using the constructor that best matches the specified parameters. 
        /// </summary>
        /// <param name="typeName">The name of the type of object to create. </param>
        /// <param name="arguments">An array of arguments that match in number, order, and type the parameters of the constructor to invoke. If args is an empty array or a null reference (Nothing in Visual Basic), the constructor that takes no parameters (the default constructor) is invoked. </param>
        /// <returns>A reference to the newly created object. </returns>
        public static object CreateObject(string typeName, object[] arguments)
        {
            // look up the generatedProxyTypeName if we have already created the dynamic assembly for this type
            Type emittedType = null;
            lock(_proxyTypeMap.SyncRoot)
            {
                Assertions.Assert(_proxyTypeMap.ContainsKey(typeName));

                emittedType = (Type) _proxyTypeMap[typeName];
            }

            return Activator.CreateInstance(emittedType, arguments);
        }

        /// <summary>
        /// Converts a Value type to a correspondent OpCode
        /// </summary>
        /// <param name="valueType">the value type to be converted</param>
        /// <returns>the corresponding OpCode</returns>
        public static OpCode ConvertTypeToOpCode(Type valueType)
        {
            // if the type is an enum, then figure out its base type and call recursively
            if(valueType.IsEnum)
            {
                System.Enum baseType = (System.Enum) Activator.CreateInstance(valueType);
                TypeCode code = baseType.GetTypeCode();

                switch(code)
                {
                    case TypeCode.Byte:
                        valueType = typeof(Byte);
                        break;
                    case TypeCode.Int16:
                        valueType = typeof(Int16);
                        break;
                    case TypeCode.Int32:
                        valueType = typeof(Int32);
                        break;
                    case TypeCode.Int64:
                        valueType = typeof(Int64);
                        break;
                }

                return ConvertTypeToOpCode(valueType);
            }

            lock(_opCodeTypeMap.SyncRoot)
            {
                if(_opCodeTypeMap.Count == 0)
                {
                    _opCodeTypeMap.Add(typeof(Byte), OpCodes.Ldind_U1);
                    _opCodeTypeMap.Add(typeof(SByte), OpCodes.Ldind_I1);
                    _opCodeTypeMap.Add(typeof(Char), OpCodes.Ldind_U2);
                    _opCodeTypeMap.Add(typeof(Boolean), OpCodes.Ldind_I1);
                    _opCodeTypeMap.Add(typeof(Int16), OpCodes.Ldind_I2);
                    _opCodeTypeMap.Add(typeof(Int32), OpCodes.Ldind_I4);
                    _opCodeTypeMap.Add(typeof(Int64), OpCodes.Ldind_I8);
                    _opCodeTypeMap.Add(typeof(Double), OpCodes.Ldind_R8);
                    _opCodeTypeMap.Add(typeof(Single), OpCodes.Ldind_R4);
                    _opCodeTypeMap.Add(typeof(UInt16), OpCodes.Ldind_U2);
                    _opCodeTypeMap.Add(typeof(UInt32), OpCodes.Ldind_U4);
                    _opCodeTypeMap.Add(typeof(UInt64), OpCodes.Ldind_I8);
                }
            }

            if(!_opCodeTypeMap.ContainsKey(valueType))
            {
                throw new ArgumentException("Type " + valueType + " could not be converted to an OpCode");
            }

            return (OpCode) _opCodeTypeMap[valueType];
        }

        /// <summary>
        /// Emits the simple get method implementation.
        /// </summary>
        /// <param name="methodBuilder">The method builder.</param>
        /// <param name="parameterTypes">The parameter types.</param>
        /// <param name="generator">The generator.</param>
        /// <param name="data">The data.</param>
        public static void EmitSimpleGetMethodImplementation(MethodBuilder methodBuilder, Type[] parameterTypes, ILGenerator generator, object[] data)
        {
            Assertions.Assert(data.Length == 1);
            Assertions.Assert(data[0] is FieldBuilder);

            FieldBuilder fieldBuilder = (FieldBuilder) data[0];

            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Ldfld, fieldBuilder);
            generator.Emit(OpCodes.Ret);
        }

        /// <summary>
        /// Emits the simple set method implementation.
        /// </summary>
        /// <param name="methodBuilder">The method builder.</param>
        /// <param name="parameterTypes">The parameter types.</param>
        /// <param name="generator">The generator.</param>
        /// <param name="data">The data.</param>
        public static void EmitSimpleSetMethodImplementation(MethodBuilder methodBuilder, Type[] parameterTypes, ILGenerator generator, object[] data)
        {
            Assertions.Assert(data.Length == 1);
            Assertions.Assert(data[0] is FieldBuilder);

            FieldBuilder fieldBuilder = (FieldBuilder) data[0];

            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Ldarg_1);
            generator.Emit(OpCodes.Stfld, fieldBuilder);
            generator.Emit(OpCodes.Ret);
        }
        #endregion
        
        #region Private properties
        private bool DefiningType
        {
            get
            {
                return (_typeBuilder != null);
            }
        }
        #endregion

        #region Private methods
        private MethodBuilder PrivateDefineMethod(string name, MethodAttributes methodAttributes, CallingConventions callingConventions, Type[] parameterTypes, Type returnType)
        {
            Assertions.Assert(DefiningType);

            if(name.StartsWith("set_") || name.StartsWith("get_"))
            {
                methodAttributes = MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.Virtual;
            }

            MethodBuilder methodBuilder = _typeBuilder.DefineMethod(name, methodAttributes, callingConventions, returnType, parameterTypes);

            if(name.StartsWith("set_") || name.StartsWith("get_"))
            {
                foreach(DictionaryEntry dictionaryEntry in _propertyBuilders)
                {
                    PropertyBuilder propertyBuilder = (PropertyBuilder) dictionaryEntry.Value;

                    if(propertyBuilder == null)
                    {
                        break;
                    }

                    if(!propertyBuilder.Name.Equals(name.Substring(4)))
                    {
                        continue;
                    }

                    if(name.StartsWith("set_"))
                    {
                        propertyBuilder.SetSetMethod(methodBuilder);
                        break;
                    }
                    else
                    {
                        propertyBuilder.SetGetMethod(methodBuilder);
                        break;
                    }
                }
            }

            return methodBuilder;
        }
        #endregion

        #region Private fields
        private static Hashtable _proxyTypeMap = new Hashtable();
        private static Hashtable _opCodeTypeMap = new Hashtable();
        private string _assemblyFileName;                                   // = null; (automatically initialized by runtime)
        private bool _assemblySaved;                                        // = false; (automatically intiialized by runtime)
        private AssemblyBuilder _assemblyBuilder;                           // = null; (automatically initialized by runtime)
        private ModuleBuilder _moduleBuilder;                               // = null; (automatically initialized by runtime)
        private global::System.Reflection.Emit.TypeBuilder _typeBuilder;    // = null; (automatically initialized by runtime)
        private Hashtable _propertyBuilders;                                // = null; (automatically initialized by runtime)
        #endregion
    }
}
