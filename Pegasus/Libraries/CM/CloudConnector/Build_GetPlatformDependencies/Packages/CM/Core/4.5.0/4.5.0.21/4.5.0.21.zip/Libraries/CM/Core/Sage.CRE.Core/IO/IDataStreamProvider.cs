using System;
using System.Collections;
using System.IO;

namespace Sage.IO
{
	/// <summary>
	/// Interface for components that provide one or more data streams.
	/// </summary>
	public interface IDataStreamProvider
	{
        /// <summary>
        /// Read all currently available data streams
        /// </summary>
	    void Read();

        /// <summary>
        /// Read a specific data stream
        /// </summary>
        Stream ReadDataStream( string dataSourceId );

        /// <summary>
        /// Clear the stream cache
        /// </summary>
        void ClearStreamCache();

        /// <summary>
        /// Retrieve a collection of cached data source ids
        /// </summary>
        ICollection CachedDataSourceIds{ get; }

        /// <summary>
        /// Retrieve a collection of cached data streams
        /// </summary>
        ICollection CachedDataStreams{ get; }

        /// <summary>
        /// Retrieve a specific data stream from the stream cache
        /// </summary>
        Stream GetCachedDataStream( string dataSourceId );

        /// <summary>
        /// Remove a specific data stream from the stream cache
        /// </summary>
        /// <param name="dataSourceId">The ID of the data source whose stream should be removed</param>
        void RemoveCachedDataStream( string dataSourceId );

        /// <summary>
        /// Event fired before data is read
        /// </summary>
        event BeforeDataReadEventHandler BeforeDataRead;

        /// <summary>
        /// Event fired when a file is read
        /// </summary>
        event DataReadEventHandler DataRead;

        /// <summary>
        /// Event fired when a new data source is detected.
        /// </summary>
        event DataSourceEventHandler DataSourceAdded;

        /// <summary>
        /// Event fired when a data source is deleted
        /// </summary>
        event DataSourceEventHandler DataSourceDeleted;
	}
}
