using System;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.InteropServices;
using Sage.CM.Core.LinkedSource;
using System.Text;
using System.Collections.Generic;
using System.Collections;

namespace Sage.Diagnostics
{
    /// <summary>
    /// A static helper class used to provide the functionality of managing a collection of trace switches
    /// and formatting trace output for Sage.CRE.Core.TraceListeners.
    /// </summary>
    [TraceListenerIgnoreType]
    [ComVisible(false)]
    internal static class TraceUtils
    {
        #region Constructors
        /// <remarks>
        /// Static default constructor to do one-time instantiation of static class.
        /// </remarks>
        static TraceUtils()
        {
            try
            {
                // As a security measure, we only are going to write trace output if the Sage.CRE.Core.TraceListeners
                // assembly exists, has the same version as our version, and has the same public key as our
                // public key.

                Assembly traceListenersAssembly = Assembly.Load(LibraryConstants.LibraryAssemblyFullName("Sage.CRE.Core.TraceListeners"));

                byte[] traceListenersAssemblyPublicKeyToken = traceListenersAssembly.GetName().GetPublicKeyToken();
                Version traceListenerAssemblyVersion = traceListenersAssembly.GetName().Version;
                byte[] myAssemblyPublicKeyToken = Assembly.GetExecutingAssembly().GetName().GetPublicKeyToken();
                Version myAssemblyVersion = Assembly.GetExecutingAssembly().GetName().Version;

                if (myAssemblyVersion.CompareTo(traceListenerAssemblyVersion) == 0 &&
                    Convert.ToBase64String(traceListenersAssemblyPublicKeyToken, 0, traceListenersAssemblyPublicKeyToken.Length) == Convert.ToBase64String(myAssemblyPublicKeyToken, 0, myAssemblyPublicKeyToken.Length))
                {
                    Type[] traceListenersAssemblyTypes = traceListenersAssembly.GetTypes();
                    StringCollection traceListenerAssemblyTypeNames = new StringCollection();
                    foreach (Type type in traceListenersAssemblyTypes)
                    {
                        if (type.IsSubclassOf(typeof(TraceListener)))
                        {
                            traceListenerAssemblyTypeNames.Add(type.FullName);
                        }
                    }

                    foreach (TraceListener traceListener in Trace.Listeners)
                    {
                        if (traceListenerAssemblyTypeNames.Contains(traceListener.GetType().FullName))
                        {
                            _customTraceListenersPresent = true;
                        }
                    }
                }
            }
            catch (Exception)
            {
                // eat any failure to get the trace lisetners ... if we cannot do it, then we won't output the trace message
            }
        }
        #endregion

        #region Public members
        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        public static void EnableTraceLogging(Boolean enable, String logFilePath)
        {
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            if(enable && _programmaticallyConfiguredTraceLogger != null)
            {
                throw new InvalidOperationException(Strings.InvalidStateTraceLoggingIsAlreadyEnabled);
            }

            if(!enable && _programmaticallyConfiguredTraceLogger == null)
            {
                throw new InvalidOperationException(Strings.InvalidStateTraceLoggingIsAlreadyDisabled);
            }

            if(enable)
            {
                _programmaticallyConfiguredTraceLogger = new TextWriterTraceListener(logFilePath);
            }
            else
            {
                lock(_programmaticallyConfiguredTraceLogger)
                {
                    _programmaticallyConfiguredTraceLogger.Dispose();
                    _programmaticallyConfiguredTraceLogger = null;
                }
            }
#endif
        }

        /// <summary>
        /// Formats a message with the proprietary markup that enable the rich context output in the custom trace listeners.
        /// </summary>
        /// <param name="caller">the "this" pointer of the calling object (or null if called from a static member)</param>
        /// <param name="messageCategory">a string representing the message category</param>
        /// <param name="message">the message to write</param>
        /// <remarks>
        /// While messageCategory could technically be any string.  The standard conventions used are:
        ///    ERR - error
        ///    WRN - warning
        ///    INF - info
        ///    VRB - verbose
        /// </remarks>
        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        public static void WriteLine(object caller, string messageCategory, string message)
        {
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            if(_programmaticallyConfiguredTraceLogger != null)
            {
                lock(_programmaticallyConfiguredTraceLogger)
                {
                    _programmaticallyConfiguredTraceLogger.WriteLine(message);
                    _programmaticallyConfiguredTraceLogger.Flush();
                }
            }

            if(!_customTraceListenersPresent)
            {
                // If we have any problem getting the encryptor then just silently bail out ... it means that there
                // is something wrong with the Sage.CRE.Core.TraceListeners assembly.
                return;
            }


            string traceMessage = string.Empty;
            lock(_traceMessageDataWriter) // the static _traceMessageDataWriter is potentially shared across multiple threads, synchronize access to it
            {
                _traceMessageDataWriter.Clear();
                _traceMessageDataWriter.Message = message;

                // OID: object identifier
                if(caller == null)
                {
                    // We have no caller ... probably called from a static method.
                    _traceMessageDataWriter.AddData("OID", 0);
                }
                else if(caller.GetType().GetCustomAttributes(typeof(TraceListenerIgnoreTypeAttribute), false).Length == 1)
                {
                    // If the caller instance that we have has the TraceListenerIgnoreType custom attribute,
                    // then we don't know what the correct object ID to report should be (because the type
                    // that we are going to report is not the type of the caller, but the type of some caller
                    // of the caller).  In order to avoid presenting misleading information in the trace we
                    // simply catch this condition and refuse to output an OID for this call (since we cannot
                    // determine what is the correct one).
                    _traceMessageDataWriter.AddData("OID", -1);
                }
                else
                {
                    // We have a caller object and it does not have TraceListenerIgnoreType custom attribute.
                    _traceMessageDataWriter.AddData("OID", caller.GetHashCode());
                }

                // MC: message category
                _traceMessageDataWriter.AddData("MC", messageCategory);

                traceMessage = _traceMessageDataWriter.ToString();
            }

            // finally, output the message
            System.Diagnostics.Trace.WriteLine(traceMessage);
#endif
        }
        #endregion

        #region Private fields
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
        private static TraceMessageDataWriter  _traceMessageDataWriter = new TraceMessageDataWriter();
        private static bool                    _customTraceListenersPresent; //= false; (automatically initialized by runtime)
        private static TextWriterTraceListener _programmaticallyConfiguredTraceLogger; //= null; (automatically initialized by runtime)
#endif
        #endregion
    }

    /// <summary>
    /// An assembly-level error trace static helper.
    /// </summary>
    /// <remarks>
    /// All output will be disabled if TRACE is not defined.  TRACE is typically defined, by default, for both
    /// debug and release configurations.
    ///
    /// All of the static WriteLine() methods of this class have been carefully designed so as to minimize the
    /// amount of machine cycles that are "wasted" if indeed the particular trace switch is not currently on.
    /// There is a delicate balance here between readability, reuse, and performance.
    ///
    /// It is recommended that all callers of the WriteLine methods of this class do as little work
    /// as possible in their calls to ErrorTrace.WriteLine().  This includes deferring all string.Format()-ing
    /// to the internal function.
    ///
    ///   E.g., 
    ///
    ///   callers should do a    ErrorTrace.WriteLine(this, "Value 1:{0}; Value 2:{1}", val1, val2);
    ///   instead of doing a     ErrorTrace.WriteLine(this, string.Format("Value 1:{0}; Value 2:{1}", val1, val2));
    ///
    /// Both calls are valid, but the second one will always spend cycles doing the string.Format() even if the
    /// trace switch is not currently on.
    /// </remarks>
    [TraceListenerIgnoreType]
    [ComVisible(false)]
    public static class ErrorTrace
    {
        #region Public members
        /// <summary>
        /// Writes the specified message to the Trace output if the assembly-level trace switch is set to TraceError, TraceWarning, TraceInfo, or TraceVerbose.
        /// </summary>
        /// <param name="caller">the "this" pointer of the calling object (or null if called from a static member)</param>
        /// <param name="messageToFormat">a string containing zero or more format items -- the message to write to the Trace output</param>
        /// <param name="list">an Object array containing zero or more objects to format</param>
        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        public static void WriteLine(object caller, string messageToFormat, params object[] list)
        {
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            if(TracingConfiguration.GetTraceSwitch(Assembly.GetCallingAssembly().GetName().Name).TraceError)
            {
                try
                {
                    // for efficiency, don't call string.Format if we don't have to (i.e., if no replaceable param value were supplied)
                    if(list.Length > 0)
                    {
                        TraceUtils.WriteLine(caller, MESSAGE_CATEGORY, string.Format(CultureInfo.InvariantCulture, messageToFormat, list));
                    }
                    else
                    {
                        TraceUtils.WriteLine(caller, MESSAGE_CATEGORY, messageToFormat);
                    }
                }
                catch(FormatException)
                {
                    // Catch any exception while trying to write a trace message and prevent it from changing the control
                    // flow of the production code.  This can heppen, for example, if the caller supplied an invalid
                    // messageToFormat (e.g., one that contains literal "{" and "}" characters that do not match up
                    // with replaceable parameters).
                    try
                    {
                        string message = string.Format(CultureInfo.InvariantCulture, Strings.FormatExceptionFailureOccurredDuringOutputTraceFormat, messageToFormat);
                        TraceUtils.WriteLine(caller, ErrorTrace.MESSAGE_CATEGORY, message);
                        Assertions.Assert(false, message); 
                    }
                    catch(Exception e)
                    {
                        // Catch any exception while trying to write a trace message and prevent it from changing the control
                        // flow of the production code.
                        Assertions.Assert(false, e.Message); 
                    }
                }
                catch(Exception e)
                {
                    // Catch any exception while trying to write a trace message and prevent it from changing the control
                    // flow of the production code.
                    Assertions.Assert(false, e.Message); 
                }
            }
#endif
        }

        /// <summary>
        /// Writes the specified message to the Trace output if the assembly-level trace switch is set to TraceError, TraceWarning, TraceInfo, or TraceVerbose.
        /// </summary>
        /// <param name="caller">the "this" pointer of the calling object (or null if called from a static member)</param>
        /// <param name="messageToFormat">a string containing zero or more format items -- the message to write to the Trace output</param>
        /// <param name="list">an Object array containing zero or more objects to format</param>
        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        public static void WriteException(object caller, Exception ex)
        {
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            if (TracingConfiguration.GetTraceSwitch(Assembly.GetCallingAssembly().GetName().Name).TraceError)
            {
                try
                {
                    // for efficiency, don't call string.Format if we don't have to (i.e., if no replaceable param value were supplied)
                    if (ex != null)
                    {
                        TraceUtils.WriteLine(caller, MESSAGE_CATEGORY, ExceptionAsString(ex));
                    }
                    else
                    {
                        TraceUtils.WriteLine(caller, MESSAGE_CATEGORY, "ex is null");
                    }
                }
                catch (FormatException)
                {
                    // Catch any exception while trying to write a trace message and prevent it from changing the control
                    // flow of the production code.  This can heppen, for example, if the caller supplied an invalid
                    // messageToFormat (e.g., one that contains literal "{" and "}" characters that do not match up
                    // with replaceable parameters).
                    try
                    {
                        string message = string.Format(CultureInfo.InvariantCulture, Strings.FormatExceptionFailureOccurredDuringOutputTraceFormat, "<no message>");
                        TraceUtils.WriteLine(caller, ErrorTrace.MESSAGE_CATEGORY, message);
                        Assertions.Assert(false, message);
                    }
                    catch (Exception e)
                    {
                        // Catch any exception while trying to write a trace message and prevent it from changing the control
                        // flow of the production code.
                        Assertions.Assert(false, e.Message);
                    }
                }
                catch (Exception e)
                {
                    // Catch any exception while trying to write a trace message and prevent it from changing the control
                    // flow of the production code.
                    Assertions.Assert(false, e.Message);
                }
            }
#endif
        }
        #endregion

        private static String ExceptionAsString(Exception ex)
        {
            String result = String.Empty;
            if (ex != null)
            {
                result = String.Format(CultureInfo.InvariantCulture, "{0}{1}", ex.ToString(), ex.InnerException != null ? String.Format("\n\nInner exception:{0}", ExceptionAsString(ex.InnerException)) : String.Empty);
            }
            return result;
        }

        #region Internal fields
        internal const string MESSAGE_CATEGORY = "ERR";
        #endregion
    }

    /// <summary>
    /// An assembly-level warning trace static helper.
    /// </summary>
    /// <remarks>
    /// All output will be disabled if TRACE is not defined.  TRACE is typically defined, by default, for both
    /// debug and release configurations.
    ///
    /// All of the static WriteLine() methods of this class have been carefully designed so as to minimize the
    /// amount of machine cycles that are "wasted" if indeed the particular trace switch is not currently on.
    /// There is a delicate balance here between readability, reuse, and performance.
    ///
    /// It is recommended that all callers of the WriteLine methods of this class do as little work
    /// as possible in their calls to WarningTrace.WriteLine().  This includes deferring all string.Format()-ing
    /// to the internal function.
    ///
    ///   E.g., 
    ///
    ///   callers should do a    WarningTrace.WriteLine(this, "Value 1:{0}; Value 2:{1}", val1, val2);
    ///   instead of doing a     WarningTrace.WriteLine(this, string.Format("Value 1:{0}; Value 2:{1}", val1, val2));
    ///
    /// Both calls are valid, but the second one will always spend cycles doing the string.Format() even if the
    /// trace switch is not currently on.
    /// </remarks>
    [TraceListenerIgnoreType]
    [ComVisible(false)]
    public static class WarningTrace
    {
        #region Public members
        /// <summary>
        /// Writes the specified message to the Trace output if the assembly-level trace switch is set to TraceWarning, TraceInfo, or TraceVerbose.
        /// </summary>
        /// <param name="caller">the "this" pointer of the calling object (or null if called from a static member)</param>
        /// <param name="messageToFormat">a string containing zero or more format items -- the message to write to the Trace output</param>
        /// <param name="list">an Object array containing zero or more objects to format</param>
        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        public static void WriteLine(object caller, string messageToFormat, params object[] list)
        {
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            if(TracingConfiguration.GetTraceSwitch(Assembly.GetCallingAssembly().GetName().Name).TraceWarning)
            {
                try
                {
                    // for efficiency, don't call string.Format if we don't have to (i.e., if no replaceable param value were supplied)
                    if(list.Length > 0)
                    {
                        TraceUtils.WriteLine(caller, MESSAGE_CATEGORY, string.Format(CultureInfo.InvariantCulture, messageToFormat, list));
                    }
                    else
                    {
                        TraceUtils.WriteLine(caller, MESSAGE_CATEGORY, messageToFormat);
                    }
                }
                catch(FormatException)
                {
                    // Catch any exception while trying to write a trace message and prevent it from changing the control
                    // flow of the production code.  This can heppen, for example, if the caller supplied an invalid
                    // messageToFormat (e.g., one that contains literal "{" and "}" characters that do not match up
                    // with replaceable parameters).
                    try
                    {
                        string message = string.Format(CultureInfo.InvariantCulture, Strings.FormatExceptionFailureOccurredDuringOutputTraceFormat, messageToFormat);
                        TraceUtils.WriteLine(caller, ErrorTrace.MESSAGE_CATEGORY, message);
                        Assertions.Assert(false, message); 
                    }
                    catch(Exception e)
                    {
                        // Catch any exception while trying to write a trace message and prevent it from changing the control
                        // flow of the production code.
                        Assertions.Assert(false, e.Message); 
                    }
                }
                catch(Exception e)
                {
                    // Catch any exception while trying to write a trace message and prevent it from changing the control
                    // flow of the production code.
                    Assertions.Assert(false, e.Message); 
                }
            }
#endif
        }
        #endregion

        #region Private fields
        private const string MESSAGE_CATEGORY = "WRN";
        #endregion
    }

    /// <summary>
    /// An assembly-level info trace static helper.
    /// </summary>
    /// <remarks>
    /// All output will be disabled if TRACE is not defined.  TRACE is typically defined, by default, for both
    /// debug and release configurations.
    ///
    /// All of the static WriteLine() methods of this class have been carefully designed so as to minimize the
    /// amount of machine cycles that are "wasted" if indeed the particular trace switch is not currently on.
    /// There is a delicate balance here between readability, reuse, and performance.
    ///
    /// It is recommended that all callers of the WriteLine methods of this class do as little work
    /// as possible in their calls to InfoTrace.WriteLine().  This includes deferring all string.Format()-ing
    /// to the internal function.
    ///
    ///   E.g., 
    ///
    ///   callers should do a    InfoTrace.WriteLine(this, "Value 1:{0}; Value 2:{1}", val1, val2);
    ///   instead of doing a     InfoTrace.WriteLine(this, string.Format("Value 1:{0}; Value 2:{1}", val1, val2));
    ///
    /// Both calls are valid, but the second one will always spend cycles doing the string.Format() even if the
    /// trace switch is not currently on.
    /// </remarks>
    [TraceListenerIgnoreType]
    [ComVisible(false)]
    public static class InfoTrace
    {
        #region Public members
        /// <summary>
        /// Writes the specified message to the Trace output if the assembly-level trace switch is set to TraceInfo or TraceVerbose.
        /// </summary>
        /// <param name="caller">the "this" pointer of the calling object (or null if called from a static member)</param>
        /// <param name="messageToFormat">a string containing zero or more format items -- the message to write to the Trace output</param>
        /// <param name="list">an Object array containing zero or more objects to format</param>
        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        public static void WriteLine(object caller, string messageToFormat, params object[] list)
        {
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            if(TracingConfiguration.GetTraceSwitch(Assembly.GetCallingAssembly().GetName().Name).TraceInfo)
            {
                try
                {
                    // for efficiency, don't call string.Format if we don't have to (i.e., if no replaceable param value were supplied)
                    if(list.Length > 0)
                    {
                        TraceUtils.WriteLine(caller, MESSAGE_CATEGORY, string.Format(CultureInfo.InvariantCulture, messageToFormat, list));
                    }
                    else
                    {
                        TraceUtils.WriteLine(caller, MESSAGE_CATEGORY, messageToFormat);
                    }
                }
                catch(FormatException)
                {
                    // Catch any exception while trying to write a trace message and prevent it from changing the control
                    // flow of the production code.  This can heppen, for example, if the caller supplied an invalid
                    // messageToFormat (e.g., one that contains literal "{" and "}" characters that do not match up
                    // with replaceable parameters).
                    try
                    {
                        string message = string.Format(CultureInfo.InvariantCulture, Strings.FormatExceptionFailureOccurredDuringOutputTraceFormat, messageToFormat);
                        TraceUtils.WriteLine(caller, ErrorTrace.MESSAGE_CATEGORY, message);
                        Assertions.Assert(false, message); 
                    }
                    catch(Exception e)
                    {
                        // Catch any exception while trying to write a trace message and prevent it from changing the control
                        // flow of the production code.
                        Assertions.Assert(false, e.Message); 
                    }
                }
                catch(Exception e)
                {
                    // Catch any exception while trying to write a trace message and prevent it from changing the control
                    // flow of the production code.
                    Assertions.Assert(false, e.Message); 
                }
            }
#endif
        }
        #endregion

        #region Private fields
        private const string MESSAGE_CATEGORY = "INF";
        #endregion
    }

    /// <summary>
    /// An assembly-level verbose trace static helper.
    /// </summary>
    /// <remarks>
    /// All output will be disabled if TRACE is not defined.  TRACE is typically defined, by default, for both
    /// debug and release configurations.
    ///
    /// All of the static WriteLine() methods of this class have been carefully designed so as to minimize the
    /// amount of machine cycles that are "wasted" if indeed the particular trace switch is not currently on.
    /// There is a delicate balance here between readability, reuse, and performance.
    ///
    /// It is recommended that all callers of the WriteLine methods of this class do as little work
    /// as possible in their calls to VerboseTrace.WriteLine().  This includes deferring all string.Format()-ing
    /// to the internal function.
    ///
    ///   E.g., 
    ///
    ///   callers should do a    VerboseTrace.WriteLine(this, "Value 1:{0}; Value 2:{1}", val1, val2);
    ///   instead of doing a     VerboseTrace.WriteLine(this, string.Format("Value 1:{0}; Value 2:{1}", val1, val2));
    ///
    /// Both calls are valid, but the second one will always spend cycles doing the string.Format() even if the
    /// trace switch is not currently on.
    /// </remarks>
    [TraceListenerIgnoreType]
    [ComVisible(false)]
    public static class VerboseTrace
    {
        #region Public members
        /// <summary>
        /// Writes the specified message to the Trace output if the assembly-level trace switch is set to TraceVerbose.
        /// </summary>
        /// <param name="caller">the "this" pointer of the calling object (or null if called from a static member)</param>
        /// <param name="messageToFormat">a string containing zero or more format items -- the message to write to the Trace output</param>
        /// <param name="list">an Object array containing zero or more objects to format</param>
        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        public static void WriteLine(object caller, string messageToFormat, params object[] list)
        {
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            if(TracingConfiguration.GetTraceSwitch(Assembly.GetCallingAssembly().GetName().Name).TraceVerbose)
            {
                try
                {
                    // for efficiency, don't call string.Format if we don't have to (i.e., if no replaceable param value were supplied)
                    if(list.Length > 0)
                    {
                        TraceUtils.WriteLine(caller, MESSAGE_CATEGORY, string.Format(CultureInfo.InvariantCulture, messageToFormat, list));
                    }
                    else
                    {
                        TraceUtils.WriteLine(caller, MESSAGE_CATEGORY, messageToFormat);
                    }
                }
                catch(FormatException)
                {
                    // Catch any exception while trying to write a trace message and prevent it from changing the control
                    // flow of the production code.  This can heppen, for example, if the caller supplied an invalid
                    // messageToFormat (e.g., one that contains literal "{" and "}" characters that do not match up
                    // with replaceable parameters).
                    try
                    {
                        string message = string.Format(CultureInfo.InvariantCulture, Strings.FormatExceptionFailureOccurredDuringOutputTraceFormat, messageToFormat);
                        TraceUtils.WriteLine(caller, ErrorTrace.MESSAGE_CATEGORY, message);
                        Assertions.Assert(false, message); 
                    }
                    catch(Exception e)
                    {
                        // Catch any exception while trying to write a trace message and prevent it from changing the control
                        // flow of the production code.
                        Assertions.Assert(false, e.Message); 
                    }
                }
                catch(Exception e)
                {
                    // Catch any exception while trying to write a trace message and prevent it from changing the control
                    // flow of the production code.
                    Assertions.Assert(false, e.Message); 
                }
            }
#endif
        }
        #endregion

        #region Private fields
        private const string MESSAGE_CATEGORY = "VRB";
        #endregion
    }


    [TraceListenerIgnoreType]
    [ComVisible(false)]
    public sealed class TraceMessage
    {
        public TraceMessage(String fullMessage, String typeName, String memberName, Int32 processId, Int32 threadId, Int32 appDomainId, Int32 objectId)
        {
            FullMessage = fullMessage;
            TypeName = typeName;
            MemberName = memberName;
            ProcessId = processId;
            ThreadId = threadId;
            AppDomainId = appDomainId;
            ObjectId = objectId;
        }

        public String FullMessage { get; private set; }
        public String TypeName { get; private set; }
        public String MemberName { get; private set; }
        public Int32 ProcessId { get; private set; }
        public Int32 ThreadId { get; private set; }
        public Int32 AppDomainId { get; private set; }
        public Int32 ObjectId { get; private set; }
    }

    /// <summary>
    /// 
    /// </summary>
    [TraceListenerIgnoreType]
    [ComVisible(false)]
    public static class TraceMessageComposer
    {
        [Flags]
        public enum Flags
        {
            None = 0x0000,
            ShowDate = 0x0001,
            ShowTime = 0x0002,
            Show24Hour = 0x0004,
            ShowMilliseconds = 0x0008,
            ShowProcessId = 0x0010,
            ShowThreadId = 0x0020,
            ShowAppDomainId = 0x0040,
            ShowObjectId = 0x0080,
            ShowMessageCategory = 0x0100,
            ShowTypeName = 0x0200,
            ShowMemberName = 0x0400,
            ShowMemberSignature = 0x0800,
            ShowAssemblyName = 0x1000,
            ShowFileLocation = 0x2000
        }

        /// <summary>
        /// Create the final trace message that contains additional contextual information.
        /// </summary>
        /// <param name="messageData">a string representation of the encoded message data (written by Sage.Diagnostics.TraceMesageDataWriter)</param>
        /// <param name="configData">the configuration data that contains the current flags and options state</param>
        /// <param name="stackTrace">the stack trace of the call</param>
        public static TraceMessage ComposeMessage(ArrayList stackTraceIgnoreTypenames, StackTrace stackTrace, Flags flags, Int32 oid, String mc, String messageToFormat, params Object[] list)
        {
            StringBuilder messageBuilder = new StringBuilder();

            String retTypeName = String.Empty;
            String retMemberName = String.Empty;
            Int32 retProcessId = 0;
            Int32 retThreadId = 0;
            Int32 retAppDomainId = 0;
            Int32 retObjectId = 0;

            StackFrame stackFrame = null;
            MethodBase stackFrameMethod = null;

            if (null != stackTrace)
            {
                string typeName;
                int frameIndex = 0;
                bool foundNonIgnoredType = false;
                Type traceListenerIgnoreTypeAttributeType = typeof(Sage.Diagnostics.TraceListenerIgnoreTypeAttribute);
                do
                {
                    frameIndex++;
                    stackFrame = stackTrace.GetFrame(frameIndex);
                    stackFrameMethod = stackFrame.GetMethod();
                    typeName = stackFrameMethod.ReflectedType.FullName;
                    if (!stackTraceIgnoreTypenames.Contains(typeName) && (0 == stackFrameMethod.ReflectedType.GetCustomAttributes(traceListenerIgnoreTypeAttributeType, false).Length))
                    {
                        foundNonIgnoredType = true;
                    }
                } while (!foundNonIgnoredType && frameIndex < (stackTrace.FrameCount - 1));

                if (!foundNonIgnoredType)
                {
                    stackFrame = null;
                    stackFrameMethod = null;
                }
            }

            retProcessId = System.Diagnostics.Process.GetCurrentProcess().Id;
            retThreadId = System.Threading.Thread.CurrentThread.ManagedThreadId;
            retAppDomainId = AppDomain.CurrentDomain.Id;
            retObjectId = oid;
            if (stackFrameMethod != null)
            {
                retTypeName = stackFrameMethod.ReflectedType.FullName;
                retMemberName = stackFrameMethod.Name;
            }


            if (flags != Flags.None)
            {
                // output current date
                DateTime now = DateTime.Now;
                if ((flags & Flags.ShowDate) != Flags.None)
                {
                    messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "{0} ", now.ToString("d"));
                }

                // output current time (in either 12 or 24 hour formatl with or without milliseconds
                if ((flags & Flags.ShowTime) != Flags.None)
                {
                    if ((flags & Flags.Show24Hour) != Flags.None)
                    {
                        messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "{0}", now.ToString("HH:mm:ss"));
                    }
                    else
                    {
                        messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "{0}", now.ToString("hh:mm:ss"));
                    }

                    if ((flags & Flags.ShowMilliseconds) != Flags.None)
                    {
                        messageBuilder.AppendFormat(CultureInfo.InvariantCulture, ".{0:d3}", now.Millisecond.ToString());
                    }
                    if ((flags & Flags.Show24Hour) == Flags.None)
                    {
                        messageBuilder.AppendFormat(CultureInfo.InvariantCulture, " {0}", (now.Hour >= 12) ? "PM" : "AM");
                    }
                    messageBuilder.Append(" ");
                }

                // output current process id
                if ((flags & Flags.ShowProcessId) != Flags.None)
                {
                    // "p" is for Process Id!
                    messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "p:{0,-6} ", retProcessId);
                }

                // output current thread id
                if ((flags & Flags.ShowThreadId) != Flags.None)
                {
                    // "t" is for Thread Id!
                    messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "t:{0,-6} ", retThreadId);
                }

                // output current AppDomain id
                if ((flags & Flags.ShowAppDomainId) != Flags.None)
                {
                    // "a" is for AppDomain!
                    messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "a:{0,-6} ", retAppDomainId);
                }

                // output object instance id
                if ((flags & Flags.ShowObjectId) != Flags.None)
                {
                    // "o" is for Object Instance Id!
                    messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "o:{0,-10} ", retObjectId, CultureInfo.InvariantCulture);
                }

                // output message category
                if ((flags & Flags.ShowMessageCategory) != Flags.None)
                {
                    messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "[{0}] ", mc);
                }

                // output caller type name
                if (stackFrameMethod != null)
                {
                    if ((flags & Flags.ShowTypeName) != Flags.None)
                    {
                        if ((flags & Flags.ShowMemberName) != Flags.None)
                        {
                            messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "{0}.", retTypeName);
                        }
                        else
                        {
                            messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "{0} ", retTypeName);
                        }
                    }
                }

                // output caller member name
                if (null != stackFrameMethod)
                {
                    if ((flags & Flags.ShowMemberName) != Flags.None)
                    {
                        messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "{0}(", retMemberName);

                        // output parameter types and names
                        if ((flags & Flags.ShowMemberSignature) != Flags.None && null != stackFrameMethod)
                        {
                            StringBuilder memberSignatureBuilder = new StringBuilder();

                            ParameterInfo[] parameters = stackFrameMethod.GetParameters();
                            int parameterIndex = 0;
                            while (parameterIndex < parameters.Length)
                            {
                                messageBuilder.AppendFormat(CultureInfo.InvariantCulture, "{0} {1}", parameters[parameterIndex].ParameterType.Name, parameters[parameterIndex].Name);
                                parameterIndex++;
                                if (parameterIndex != parameters.Length)
                                {
                                    memberSignatureBuilder.Append(", ");
                                }
                            }

                            messageBuilder.Append(memberSignatureBuilder.ToString());
                        }

                        messageBuilder.Append("): ");
                    }
                }
            }


            // output the actual message
            if (list != null)
            {
                try
                {
                    messageBuilder.AppendFormat(messageToFormat, list);
                }
                catch (FormatException)
                {
                    // Catch any exception while trying to write a LogStore message and prevent it from changing the control
                    // flow of the code.  This can heppen, for example, if the caller supplied an invalid
                    // messageToFormat (e.g., one that contains literal "{" and "}" characters that do not match up
                    // with replaceable parameters).
                    String formatExceptionMessage = String.Format(CultureInfo.InvariantCulture, "FormatException failure occurred during TraceMessageComposer.ComposeMessage() with messageToFormat='{0}'", messageToFormat);
                    System.Diagnostics.Trace.WriteLine(formatExceptionMessage);
                }
            }
            else
            {
                messageBuilder.Append(messageToFormat);
            }


            if (flags != Flags.None)
            {
                bool outputAssemblyName = ((flags & Flags.ShowAssemblyName) != Flags.None && null != stackFrameMethod);
                bool outputFileLocation = ((flags & Flags.ShowFileLocation) != Flags.None && null != stackFrame && null != stackFrame.GetFileName());
                if (outputAssemblyName || outputFileLocation)
                {
                    messageBuilder.Append(" [");

                    // output the assembly name
                    if (outputAssemblyName)
                    {
                        messageBuilder.Append(stackFrameMethod.ReflectedType.Assembly.GetName().Name);
                    }

                    // output the file and line number
                    if (outputFileLocation)
                    {
                        if (outputAssemblyName)
                        {
                            messageBuilder.Append(", ");
                        }
                        messageBuilder.AppendFormat("{0}({1})", stackFrame.GetFileName(), stackFrame.GetFileLineNumber());
                    }

                    messageBuilder.Append("]");
                }
            }

            return new TraceMessage(messageBuilder.ToString(), retTypeName, retMemberName, retProcessId, retThreadId, retAppDomainId, retObjectId);
        }
    }
}