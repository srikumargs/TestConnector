#if DEBUG
using System;
using Microsoft.Win32;
using System.IO;
using System.Text;
using NUnit.Framework;

namespace Sage.Configuration.Tests
{
    /// <summary>
    /// Test the TimberlineRegistry 
    /// </summary>
    [TestFixture]
    public class TestTimberlineRegistry
    {
        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void SetKeyTest()
        {
            RegistryHelper reg = new RegistryHelper(RegistryHive.LocalMachine, @"SOFTWARE\Timberline\Remoting\XXX");
            reg.SetKeyValue("foo", "bar");
            reg.SetKeyValue("foo2", "bar2");
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void SetGetKeyTest()
        {
            RegistryHelper reg = new RegistryHelper(RegistryHive.LocalMachine, @"SOFTWARE\Timberline\Remoting\XXX");
            reg.SetKeyValue("foo3", "bar3");
            Assert.AreEqual(reg.GetKeyValue("foo3"), "bar3");
            reg.DeleteKeyValue("foo3");
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void DeleteKeyTest()
        {
            RegistryHelper reg = new RegistryHelper(RegistryHive.LocalMachine, @"SOFTWARE\Timberline\Remoting\XXX");
            reg.DeleteKeyValue("foo2");
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void DeleteSubTreeTest()
        {
            RegistryHelper reg = new RegistryHelper(RegistryHive.LocalMachine, @"SOFTWARE\Timberline\Remoting\XXX");
            reg.DeleteKeyTree();
        }
    }
}

#endif // DEBUG