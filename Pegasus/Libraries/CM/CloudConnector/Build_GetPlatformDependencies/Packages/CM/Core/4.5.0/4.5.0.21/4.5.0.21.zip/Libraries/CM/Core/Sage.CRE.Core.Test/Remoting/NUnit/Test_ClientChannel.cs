#if DEBUG
using System;
using System.Collections.Specialized;
using System.Runtime.InteropServices;
using NUnit.Framework;

using Sage.Remoting;

namespace Sage.Remoting.NUnit
{
    /// <summary>
    /// Test the the client channel
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class Test_ClientChannel
    {
        /// <summary>
        /// Test no tcp clients registered yet.
        /// </summary>
        [Test]
        public void TcpClientTest()
        {
            ChannelRegistrar reg = new ChannelRegistrar();
            reg.RegisterClient("tcp:\\localhost\foozle.rem");
            reg.RegisterClient("tcp:\\localhost\foozle.rem");
            ChannelRegistrar.UnregisterTcp();
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TcpServerTest()
        {
            ListDictionary propBag = new ListDictionary();
            propBag.Add("name", "RTS2");
            propBag.Add("port", 9876);
            ChannelRegistrar chanReg = new ChannelRegistrar();
            chanReg.RegisterServer(ChannelType.Tcp, propBag);
        }
        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void FreePortTest()
        {
            int port = ChannelRegistrar.GetFreePort(9001, 9999);
            Assert.AreEqual(port, 9001);

            ListDictionary propBag = new ListDictionary();
            propBag.Add("name", "foo");
            propBag.Add("port", port);
            ChannelRegistrar chanReg = new ChannelRegistrar();
            chanReg.RegisterServer(ChannelType.Tcp, propBag);

            port = ChannelRegistrar.GetFreePort(9001, 9999);
            Assert.AreEqual(port, 9002);

        }

        /// <summary>
        /// Test no tcp clients registered yet.
        /// </summary>
        [Test]
        public void PipeClientTest()
        {
            ChannelRegistrar reg = new ChannelRegistrar();
            ChannelRegistrar.RegisterPipe();
            reg.RegisterClient("pipe:\\localhost\foozle.rem");
            reg.RegisterClient("pipe:\\localhost\foozle.rem");
            ChannelRegistrar.UnregisterPipe();
        }
    }
}

#endif // DEBUG