using System;
using System.Runtime.InteropServices;

namespace Sage.Configuration
{
    /// <summary>
    /// Interface for interacting with a set of keyed values
    /// </summary>
    [ComVisible(false)]
    public interface IKeyedValues
    {
        /// <summary>
        /// Retrieve a value from a set of keyed values
        /// </summary>
        /// <param name="dataPath">Identifies the location of the key value set within the set of data</param>
        /// <param name="key">The name of a key within the set of data</param>
        /// <returns>The data value stored for the provided key</returns>
        [DispId(1)]
        string GetValue( string dataPath, string key );

        /// <summary>
        /// Add or update a value in a set of keyed values
        /// </summary>
        /// <param name="dataPath">Identifies the location of the key value set within the set of data</param>
        /// <param name="key">The name of a key within the set of data</param>
        /// <param name="dataValue">The data value to store under the provided key</param>
        [DispId(2)]
        void SetValue( string dataPath, string key, string dataValue );

        /// <summary>
        /// Retrieve all key value sets located at a particular location within a set of data
        /// </summary>
        /// <param name="dataPath">Identifies the location of the key value set within the set of data</param>
        /// <returns>all key value sets located at a particular location within a set of data</returns>
        [DispId(3)]
        IKeyValueSet[] GetAllKeyValueSets( string dataPath );

        /// <summary>
        /// Add or update one or more values in a set of keyed values
        /// </summary>
        /// <param name="dataPath">Identifies the location of the key value set within the set of data</param>
        /// <param name="newValues">A collection of Keys and values to set</param>
        [DispId(4)]
        void SetKeyValues( string dataPath, IKeyValueSet[] newValues );

        /// <summary>
        /// Creates a new key at a particular location within a set of data
        /// </summary>
        /// <param name="dataPath">Identifies the location of the key value set within the set of data</param>
        /// <param name="key">The name of the key to create</param>
        [DispId(5)]
        void CreateKey( string dataPath, string key );

        /// <summary>
        /// Remove a key from a particular location within a set of data
        /// </summary>
        /// <param name="dataPath">Identifies the location of the key value set within the set of data</param>
        /// <param name="key">The name of the key to remove</param>
        [DispId(6)]
        void RemoveKey( string dataPath, string key );

        /// <summary>
        /// Determine if a specific key exists in a particular location within a set of data
        /// </summary>
        /// <param name="dataPath">Identifies the location of the key value set within the set of data</param>
        /// <param name="key">The name of the key in question</param>
        /// <returns>True if the key exists, false if not</returns>
        [DispId(7)]
        bool Contains( string dataPath, string key );

        /// <summary>
        /// Given a data path, retrieve an array of strings corresponding with the names of the key values.
        /// </summary>
        /// <param name="dataPath"></param>
        /// <returns>Returns an array of strings.</returns>
        [DispId(8)]
        string[] GetKeyValuesNames( string dataPath );

        /// <summary>
        /// Export the current data to the specified full path export file. The resultant data is understood to be in XML format.
        /// </summary>
        /// <param name="fullPathExportFile">Specify the full path export file.</param>
        /// <returns>Returns true if exported successfully; otherwise, false.</returns>
        [DispId(9)]
        bool Export( string fullPathExportFile );

        /// <summary>
        /// Given a data path, retrieve a list of Key names for the specified data path.
        /// </summary>
        /// <param name="dataPath">The data path used to find all key names.</param>
        /// <returns>Returns an array of strings.</returns>
        [DispId(10)]
        string[] GetKeyNames( string dataPath );
    }
}
