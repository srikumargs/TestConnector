using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;

using Sage.Xml;

namespace Sage.Activation
{
	/// <summary>
	/// Convert from one factory schema to the schema expected by TypeFactory
	/// </summary>
	[ComVisible(false)]
	public class TypeSchema
	{
		/// <summary>
		/// Convert the factory schema to the TypeFactory schema
		/// </summary>
		/// <param name="typeIter"></param>
		/// <returns></returns>
		public virtual TypeReader Normalize(XPathNodeIterator typeIter)
		{
			TypeReader tr = null;
			XPathNodeIterator navIter = typeIter.Clone();
			XPathNavigator nav = navIter.Current;

			if (nav.Name == "TypeInstance")
			{
				XmlTextWriter w = new XmlTextWriter(new MemoryStream(), Encoding.UTF8);
				w.WriteStartElement("TypeInstance");
				if (nav.MoveToFirstAttribute())
				{
					w.WriteAttributeString(nav.LocalName, nav.Value);
					while (nav.MoveToNextAttribute() == true)
					{
						w.WriteAttributeString(nav.LocalName, nav.Value);
					}
				}
				w.WriteEndElement();
				w.Flush();
				w.BaseStream.Position = 0;
				tr = new TypeReader(w.BaseStream);
				w.Close();
			}
			return tr;
		}

		/// <summary>
		/// Convert the factory schema to the TypeInstance schema
		/// </summary>
		/// <param name="typeNode"></param>
		/// <returns></returns>
		public virtual TypeReader Normalize(XmlNode typeNode)
		{
			TypeReader tr = null;
            if (typeNode.Name == "TypeInstance")
            {
                XPathNavigator nav = typeNode.CreateNavigator();
                XPathNodeIterator iter = nav.Select(".");
                iter.MoveNext();
                tr = this.Normalize(iter);
            }
			return tr;
		}
	}


	/// <summary>
	/// Convert from one ObjectFactory schema to the schema expected by TypeInstance
	/// </summary>
	[ComVisible(false)]
	public class ObjectFactorySchema : TypeSchema
	{
		private readonly string comFormat = 
            @"<TypeInstance ExecutionEnvironment='{0}' QualifiedTypeName='{1}' />";
        private readonly string netFormat = 
            @"<TypeInstance ExecutionEnvironment='{0}' QualifiedTypeName='{1}' Assembly='{2}' />";
        private readonly string netFormat2 = 
            @"<TypeInstance ExecutionEnvironment='{0}' QualifiedTypeName='{1}' Assembly='{2}' Codebase='{3}' />";

		/// <summary>
		/// Convert the ObjectFactory schema to the TypeInstance schema
		/// </summary>
		/// <param name="typeIter"></param>
		/// <returns></returns>
		public override TypeReader Normalize(XPathNodeIterator typeIter)
		{
			TypeReader tr = base.Normalize(typeIter);
			if (tr == null)
			{
				StringBuilder sb = new StringBuilder();
				if (XPathHelper.AttributeExists(typeIter, "ProgID") == true)
				{
					sb.AppendFormat(comFormat, "unmanaged", 
						XPathHelper.GetRequiredAttribute(typeIter, "ProgID")); 
				}
				else if (XPathHelper.AttributeExists(typeIter, "Assembly") == true && 
						 XPathHelper.AttributeExists(typeIter, "Type") == true)
				{
                    if (XPathHelper.AttributeExists(typeIter, "Codebase") == true)
                    {
                        sb.AppendFormat(netFormat2, "managed", 
                            XPathHelper.GetRequiredAttribute(typeIter, "Type"), 
                            XPathHelper.GetRequiredAttribute(typeIter, "Assembly"),
                            XPathHelper.GetRequiredAttribute(typeIter, "Codebase"));
                    }
                    else
                    {
                        sb.AppendFormat(netFormat, "managed", 
                            XPathHelper.GetRequiredAttribute(typeIter, "Type"), 
                            XPathHelper.GetRequiredAttribute(typeIter, "Assembly")); 
                    }
                }
				tr = new TypeReader(new StringReader(sb.ToString()));
			}
			return tr;
		}

		/// <summary>
		/// Convert the ObjectFactory schema to the TypeInstance schema
		/// </summary>
		/// <param name="typeNode"></param>
		/// <returns></returns>
		public override TypeReader Normalize(XmlNode typeNode)
		{
			TypeReader tr = base.Normalize(typeNode);
			if (tr == null)
			{
                // try COM, then .NET
                XmlAttribute attr = typeNode.Attributes["ProgID"];
                if (attr == null)
                {
                    attr = typeNode.Attributes["Type"];
                }
                if (attr != null)
                {
                    XPathNodeIterator iter = typeNode.CreateNavigator().Select(".");
                    iter.MoveNext();
                    tr = Normalize(iter);
                }
			}
			return tr;
		}
	}

	/// <summary>
	/// Convert from one ObjectFactory schema to the schema expected by TypeInstance
	/// </summary>
	[ComVisible(false)]
	public static class TypeReaderFactory 
	{
		/// <summary>
		/// Return a type reader after any ObjectFactory schema transformations
		/// </summary>
		/// <param name="typeIter"></param>
		/// <returns></returns>
		public static TypeReader Create(XPathNodeIterator typeIter)
		{
			ObjectFactorySchema ofs =  new ObjectFactorySchema();
			return ofs.Normalize(typeIter);
		}

        /// <summary>
        /// Return a type reader after any ObjectFactory schema transformations
        /// </summary>
        /// <param name="typeNode"></param>
		/// <returns></returns>
		public static TypeReader Create(XmlNode typeNode)
		{
			ObjectFactorySchema ofs =  new ObjectFactorySchema();
			return ofs.Normalize(typeNode);
		}
	}
}