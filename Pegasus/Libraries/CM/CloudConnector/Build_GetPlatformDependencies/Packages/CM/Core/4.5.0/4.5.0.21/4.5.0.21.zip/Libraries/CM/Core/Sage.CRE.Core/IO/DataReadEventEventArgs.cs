using System;
using System.IO;

namespace Sage.IO
{
    /// <summary>
    /// Event arguments for a data read event
    /// </summary>
    public class DataReadEventArgs: DataSourceEventArgs
    {
        #region Fields

        // The stream read from the data source
        private readonly Stream _dataStream = null;

        // The number of bytes in the data stream
        private readonly int   _streamSize = 0;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataSourceId">The ID of the source providing the data</param>
        /// <param name="dataStream">The stream read from the data source</param>
        /// <param name="streamSize">The number of bytes in the stream</param>
        public DataReadEventArgs( string dataSourceId, Stream dataStream, int streamSize ): base( dataSourceId )
        {
            _dataStream = dataStream;
            _streamSize = streamSize;
        }

        /// <summary>
        /// Retrieve the stream read from the file
        /// </summary>
        public Stream DataStream
        {
            get{ return _dataStream; }
        }

        /// <summary>
        /// Retrieve the number of bytes in the stream
        /// </summary>
        public int StreamSize
        {
            get{ return _streamSize; }
        }
    }

    /// <summary>
    /// Handler for File read events
    /// </summary>
    public delegate void DataReadEventHandler( object sender, DataReadEventArgs e );
}
