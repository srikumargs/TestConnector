﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sage.Net
{
    public class PingException : System.Net.NetworkInformation.PingException
    {
        public PingException(System.Net.NetworkInformation.IPStatus reply)
            : base(String.Empty)
        {

            _Status = reply;
            switch (reply)
            {
                case System.Net.NetworkInformation.IPStatus.BadDestination:
                    {
                        _Message = StringsCustomerFacing.Ping_BadDestination;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.BadHeader:
                    {
                        _Message = StringsCustomerFacing.Ping_BadHeader;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.BadOption:
                    {
                        _Message = StringsCustomerFacing.Ping_BadOption;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.BadRoute:
                    {
                        _Message = StringsCustomerFacing.Ping_BadRoute;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.DestinationHostUnreachable:
                    {
                        _Message = StringsCustomerFacing.Ping_DestinationHostUnreachable;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.DestinationNetworkUnreachable:
                    {
                        _Message = StringsCustomerFacing.Ping_DestinationNetworkUnreachable;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.DestinationPortUnreachable:
                    {
                        _Message = StringsCustomerFacing.Ping_DestinationPortUnreachable;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.DestinationProhibited:
                    {
                        _Message = StringsCustomerFacing.Ping_DestinationProhibited;
                        break;
                    }
                //case System.Net.NetworkInformation.IPStatus.DestinationProtocolUnreachable: // !CDP! enum 11004 appears twice. I think this is a defect from Microsoft.
                //    {
                //      _Message = StringsCustomerFacing.Ping_DestinationProtocolUnreachable;
                //      break;
                //    }
                case System.Net.NetworkInformation.IPStatus.DestinationScopeMismatch:
                    {
                        _Message = StringsCustomerFacing.Ping_DestinationScopeMismatch;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.DestinationUnreachable:
                    {
                        _Message = StringsCustomerFacing.Ping_DestinationUnreachable;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.HardwareError:
                    {
                        _Message = StringsCustomerFacing.Ping_HardwareError;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.IcmpError:
                    {
                        _Message = StringsCustomerFacing.Ping_IcmpError;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.NoResources:
                    {
                        _Message = StringsCustomerFacing.Ping_NoResources;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.PacketTooBig:
                    {
                        _Message = StringsCustomerFacing.Ping_PacketTooBig;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.ParameterProblem:
                    {
                        _Message = StringsCustomerFacing.Ping_ParameterProblem;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.SourceQuench:
                    {
                        _Message = StringsCustomerFacing.Ping_SourceQuench;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.Success:
                    {
                        // !CDP! - WTF!
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.TimedOut:
                    {
                        _Message = StringsCustomerFacing.Ping_TimedOut;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.TimeExceeded:
                    {
                        _Message = StringsCustomerFacing.Ping_TimeExceeded;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.TtlExpired:
                    {
                        _Message = StringsCustomerFacing.Ping_TtlExpired;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.TtlReassemblyTimeExceeded:
                    {
                        _Message = StringsCustomerFacing.Ping_TtlReassemblyTimeExceeded;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.Unknown:
                    {
                        _Message = StringsCustomerFacing.Ping_Unknown;
                        break;
                    }
                case System.Net.NetworkInformation.IPStatus.UnrecognizedNextHeader:
                    {
                        _Message = StringsCustomerFacing.Ping_UnrecognizedNextHeader;
                        break;
                    }
                default:
                    {
                        _Message = StringsCustomerFacing.Ping_DefaultFailure;
                        break;
                    }
            }
        }

        public override System.String Message
        {
            get
            {
                return _Message;
            }
        }

        public System.Net.NetworkInformation.IPStatus Status
        {
            get
            {
                return _Status;
            }
        }


        private System.String _Message;
        private System.Net.NetworkInformation.IPStatus _Status;


    }
}
