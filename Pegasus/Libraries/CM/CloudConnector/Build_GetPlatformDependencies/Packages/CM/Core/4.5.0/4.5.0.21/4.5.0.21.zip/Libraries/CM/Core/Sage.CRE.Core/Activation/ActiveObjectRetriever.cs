using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Xml;

using Sage.Remoting;

namespace Sage.Activation
{
	/// <summary>
	/// Retrieve resource objects from a named pipe channel
	/// </summary>
    [ ComVisible(false) ]
	public class ActiveObjectRetriever: IActiveObjectRetriever
	{
        /// <summary>
        /// Constructor
        /// </summary>
		public ActiveObjectRetriever()
		{
		}

        /// <summary>
        /// Retrieve an object from a named pipe channel
        /// </summary>
        /// <param name="uri">The uri of the object</param>
        /// <param name="targetAssembly">The assembly containing type information for the target object</param>
        /// <param name="targetType">The fully qualified type of the target object</param>
        /// <returns>The requested object</returns>
        public object GetActiveObject( string uri, string targetAssembly, string targetType )
        {
            IUrlReader reader = new DataStoreUrlReader();
            string url = reader.GetUrl(uri);
            TypeFactory factory = new TypeFactory(new TypeReader(targetType, targetAssembly, string.Empty, url));
            return factory.GetRemoteObject();
        }
	}
}
