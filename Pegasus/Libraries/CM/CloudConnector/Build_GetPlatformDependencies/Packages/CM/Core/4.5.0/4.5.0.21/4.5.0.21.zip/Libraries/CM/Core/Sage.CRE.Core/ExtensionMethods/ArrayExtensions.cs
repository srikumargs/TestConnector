using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using Sage.Diagnostics;

namespace Sage.ExtensionMethods
{
    public static class ArrayExtensions
    {
        public static U[] ConvertAll<T, U>(this T[] array, Converter<T, U> converter)
        {
            ArgumentValidator.ValidateNonNullReference(array, "array", "ArrayExtensions.ConvertAll<>");
            IEnumerable<T> enumerable = array;
            return enumerable.ConvertAll(converter).ToArray();
        }

        public static T[] SkipWhile<T>(this T[] array, Predicate<T> match)
        {
            ArgumentValidator.ValidateNonNullReference(array, "array", "ArrayExtensions.SkipWhile<>");
            ArgumentValidator.ValidateNonNullReference(match, "match", "ArrayExtensions.SkipWhile<>");
            Func<T, bool> func = (t) =>
                                {
                                    return match(t);
                                };
            return array.SkipWhile(func).ToArray();
        }

        public static T[] Take<T>(this T[] array, int count)
        {
            ArgumentValidator.ValidateNonNullReference(array, "array", "ArrayExtensions.Take<>");
            ArgumentValidator.ValidateMinIntegerValue(count, "count", "ArrayExtensions.Take<>", 0);
            IEnumerable<T> enumerable = array;
            return enumerable.Take(count).ToArray();
        }

        public static T[] TakeWhile<T>(this T[] array, Predicate<T> match)
        {
            ArgumentValidator.ValidateNonNullReference(array, "array", "ArrayExtensions.TakeWhile<>");
            ArgumentValidator.ValidateNonNullReference(match, "match", "ArrayExtensions.TakeWhile<>");
            Func<T, bool> func = (t) =>
                                {
                                    return match(t);
                                };
            return array.TakeWhile(func).ToArray();
        }

        public static T[] Skip<T>(this T[] array, int count)
        {
            ArgumentValidator.ValidateNonNullReference(array, "array", "ArrayExtensions.Skip<>");
            ArgumentValidator.ValidateMinIntegerValue(count, "count", "ArrayExtensions.Skip<>", 0);
            IEnumerable<T> enumerable = array;
            return enumerable.Skip(count).ToArray();
        }

        public static T[] Repeat<T>(T element, int count)
        {
            ArgumentValidator.ValidateMinIntegerValue(count, "count", "ArrayExtensions.Repeat<>", 1);
            return Enumerable.Repeat<T>(element, count).ToArray();
        }

        public static T[] Concat<T>(this T[] first, T[] second)
        {
            ArgumentValidator.ValidateNonNullReference(first, "first", "ArrayExtensions.Concat<>");
            ArgumentValidator.ValidateNonNullReference(second, "second", "ArrayExtensions.Concat<>");
            IEnumerable<T> enumerable = first;
            return enumerable.Concat(second).ToArray();
        }

        public static T[] Reverse<T>(this T[] array)
        {
            ArgumentValidator.ValidateNonNullReference(array, "array", "ArrayExtensions.Reverse<>");
            IEnumerable<T> enumerable = array;
            return enumerable.Reverse().ToArray();
        }

        public static T[] Union<T>(this T[] array1, T[] array2) where T : IEquatable<T>
        {
            ArgumentValidator.ValidateNonNullReference(array1, "array1", "ArrayExtensions.Union<>");
            ArgumentValidator.ValidateNonNullReference(array2, "array2", "ArrayExtensions.Union<>");
            IEnumerable<T> enumerable1 = array1;
            return enumerable1.Union(array2).ToArray();
        }

        public static T[] Complement<T>(this T[] array1, T[] array2) where T : IEquatable<T>
        {
            ArgumentValidator.ValidateNonNullReference(array1, "array1", "ArrayExtensions.Complement<>");
            ArgumentValidator.ValidateNonNullReference(array2, "array2", "ArrayExtensions.Complement<>");
            IEnumerable<T> enumerable1 = array1;
            return enumerable1.Complement(array2).ToArray();
        }

        public static T[] Except<T>(this T[] array1, T[] array2) where T : IEquatable<T>
        {
            ArgumentValidator.ValidateNonNullReference(array1, "array1", "ArrayExtensions.Except<>");
            ArgumentValidator.ValidateNonNullReference(array2, "array2", "ArrayExtensions.Except<>");
            IEnumerable<T> enumerable1 = array1;
            return enumerable1.Except(array2).ToArray();
        }

        public static T[] Intersect<T>(this T[] array1, T[] array2) where T : IEquatable<T>
        {
            ArgumentValidator.ValidateNonNullReference(array1, "array1", "ArrayExtensions.Interscet<>");
            ArgumentValidator.ValidateNonNullReference(array2, "array2", "ArrayExtensions.Interscet<>");
            IEnumerable<T> enumerable1 = array1;
            return enumerable1.Intersect(array2).ToArray();
        }

        public static T[] Distinct<T>(this T[] array)
        {
            ArgumentValidator.ValidateNonNullReference(array, "array", "ArrayExtensions.Distinct<>");
            IEnumerable<T> enumerable = array;
            return enumerable.Distinct().ToArray();
        }

        public static T[] Sort<T>(this T[] array)
        {
            ArgumentValidator.ValidateNonNullReference(array, "array", "ArrayExtensions.Sort<>");
            IEnumerable<T> enumerable = array;
            return enumerable.Sort().ToArray();
        }

        public static T[] Where<T>(this T[] array, Predicate<T> match)
        {
            ArgumentValidator.ValidateNonNullReference(array, "array", "ArrayExtensions.Where<>");
            ArgumentValidator.ValidateNonNullReference(match, "match", "ArrayExtensions.Where<>");
            Func<T, bool> func = (t) =>
                                {
                                    return match(t);
                                };
            IEnumerable<T> enumerable = array;
            return enumerable.Where(func).ToArray();
        }
    }
}