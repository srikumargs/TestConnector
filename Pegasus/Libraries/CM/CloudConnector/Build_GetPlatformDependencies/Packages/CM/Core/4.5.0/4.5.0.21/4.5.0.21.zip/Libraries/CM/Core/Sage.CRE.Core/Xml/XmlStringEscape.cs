using System;
using System.Runtime.InteropServices;
using System.Text;

using Sage.Diagnostics;

namespace Sage.Xml
{
    /// <summary>
    /// Deal with predefined entities by converting back and forth
    /// </summary>
    [ComVisible(false)]
    public interface IXmlStringEscape
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="nodeValue"></param>
        /// <returns></returns>
        string Escape(string nodeValue);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="nodeValue"></param>
        /// <returns></returns>
        string UnEscape(string nodeValue);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="nodeValue"></param>
        /// <returns></returns>
        string CDataWrap(string nodeValue);
    }


    /// <summary>
    /// Com compatible version
    /// </summary>
    [ComVisible(false)]
    public class XmlStringEscapeEx : IXmlStringEscape
    {
        /// <summary>
        /// Transform the node value to a parsable string
        /// </summary>
        /// <param name="nodeValue">The value string that may have tokens imbedded</param>
        /// <returns>the string with the tokens transformed</returns>
        public string Escape(string nodeValue)
        {
            return XmlStringEscape.Escape(nodeValue);
        }
        /// <summary>
        /// Convert the predefined entities back to their string values
        /// </summary>
        /// <param name="nodeValue"></param>
        /// <returns></returns>
        public string UnEscape(string nodeValue)
        {
            return XmlStringEscape.UnEscape(nodeValue);
        }

        /// <summary>
        /// wrap the string in a CDATA Section
        /// </summary>
        /// <returns></returns>
        public string CDataWrap(string nodeValue)
        {
            return XmlStringEscape.CDataWrap(nodeValue);
        }

    }


    /// <summary>
    /// Helper class that transforms XML node values by stripping out tokens and
    /// using the escape strings instead.
    /// </summary>
    /// <remarks>
    /// This must be applied to node values only, otherwise element and attribute
    /// taggs, etc. will get transformed as well!
    /// </remarks>
    [ComVisible(false)]
    public class XmlStringEscape
    {
        #region Static methods

        internal struct Tokens
        {
            public Tokens(string x, string t)
            {
                xml = x;
                token = t;
            }
            public string xml;
            public string token;
        }

        static Tokens[] tokenTable = new Tokens[] 
        {
            new Tokens("&", "&amp;"), 
            new Tokens("\"", "&quot;"), 
            new Tokens("'", "&apos;"), 
            new Tokens("<", "&lt;"), 
            new Tokens(">", "&gt;") 
        };

        static Tokens AMPER = new Tokens("&", "&amp;");

        /// <summary>
        /// Transform the node value to a parsable string
        /// </summary>
        /// <param name="nodeValue">The value string that may have tokens imbedded</param>
        /// <returns>the string with the tokens transformed</returns>
        public static string Escape(string nodeValue)
        {
            ArgumentValidator.ValidateNonNullReference(nodeValue, "nodeValue", "XmlStringEscape.Escape");

            // explode the string
            char[] chars = nodeValue.ToCharArray();

            // new string to build up
            string newString = String.Empty;
            for(int i = 0 ; i < chars.Length ; i++)
            {
                // Is this an apersand that needs to be replaced or
                // part of an entity?
                if(chars[i] == '&')
                {
                    bool bFound = false;
                    string substring = nodeValue.Substring(i);
                    foreach(Tokens t in tokenTable)
                    {
                        if(substring.StartsWith(t.token) == true)
                        {
                            bFound = true;
                            break;
                        }
                    }
                    if(bFound == false)
                    {
                        newString += AMPER.token;
                    }
                    else
                    {
                        newString += chars[i];
                    }
                }
                else
                {
                    newString += chars[i];
                }
            }
            // Ok, now do the replacement from the table, minus the
            // ampersand which we previously handled
            StringBuilder tmp = new StringBuilder(newString);
            foreach(Tokens t in tokenTable)
            {
                if(t.xml != AMPER.xml)
                {
                    tmp.Replace(t.xml, t.token);
                }
            }
            return tmp.ToString();
        }

        /// <summary>
        /// Convert the predefined entities back to their string values
        /// </summary>
        /// <param name="nodeValue"></param>
        /// <returns></returns>
        public static string UnEscape(string nodeValue)
        {
            ArgumentValidator.ValidateNonNullReference(nodeValue, "nodeValue", "XmlStringEscape.UnEscape");

            foreach(Tokens t in tokenTable)
            {
                nodeValue = nodeValue.Replace(t.token, t.xml);
            }
            return nodeValue;
        }


        /// <summary>
        /// wrap the string in a CDATA Section
        /// </summary>
        /// <returns></returns>
        public static string CDataWrap(string s)
        {
            return string.Format("<![CDATA[{0}]]>", s);
        }
        #endregion
    }
}