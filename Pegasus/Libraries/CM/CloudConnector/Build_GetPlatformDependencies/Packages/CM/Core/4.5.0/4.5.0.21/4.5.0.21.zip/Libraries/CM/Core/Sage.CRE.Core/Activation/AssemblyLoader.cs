using System;
using System.Collections;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Runtime.Remoting.Activation;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;

using Sage.Configuration;
using Sage.Xml;
using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Enum used to determine how to activate an object
    /// </summary>
    [ ComVisible( false ) ]
    public enum ActivationType
    {
        /// <summary>
        /// Activate through COM
        /// </summary>
        COM,

        /// <summary>
        /// Activate through .NET
        /// </summary>
        DOT_NET
    }


    /// <summary>
    /// Helper class allows strongly typed query methods over XmlNode for activation
    /// </summary>
    [ ComVisible( false ) ]
    public static class ActivationTypeNode
    {
        /// <summary>
        /// The name of the 'Assembly' attribute
        /// </summary>
        public const string ASSEMBLY_ATTRIBUTE = "Assembly";

        /// <summary>
        /// The name of the 'Type' attribute
        /// </summary>
        public const string TYPE_ATTRIBUTE = "Type";

        /// <summary>
        /// The name of the 'ProgID' attribute
        /// </summary>
        public const string PROGID_ATTRIBUTE = "ProgID";

        /// <summary>
        /// The name of the 'Codebase' attribute
        /// </summary>
        public const string CODEBASE_ATTRIBUTE = "Codebase";
        
        /// <summary>
        /// The name of the 'ActivationType' attribute
        /// </summary>
        public const string ACTIVATION_TYPE_ATTRIBUTE = "ActivationType";

        /// <summary>
        /// Retrieve the Assembly attribute from an Xml node
        /// </summary>
        /// <param name="objectInfoNode">An Xml node containing 
        /// an Assembly attribute</param>
        /// <returns>The value of the assembly attribute</returns>
        public static string GetAssemblyAttributeValue( XmlNode objectInfoNode )
        {
            if( objectInfoNode.Attributes.GetNamedItem( ASSEMBLY_ATTRIBUTE ) == null )
            {
                throw new TypeFactoryException(new ArgumentException( Strings.NoAssemblyAttributeFoundInXmlNode, "objectInfoNode" ));
            }

            return objectInfoNode.Attributes.GetNamedItem( ASSEMBLY_ATTRIBUTE ).Value;
        }

        /// <summary>
        /// Retrieve the value of a ProgID attribute
        /// </summary>
        /// <param name="objectInfoNode">Xml containing a 
        /// ProgID attribute</param>
        /// <returns>The value of the ProgID attribute</returns>
        public static string GetProgIDAttributeValue( XmlNode objectInfoNode )
        {
            if( objectInfoNode.Attributes.GetNamedItem( PROGID_ATTRIBUTE ) == null )
            {
                throw new TypeFactoryException(new ArgumentException( Strings.NoProgIDNodeFoundInXmlNode, "objectInfoNode" ));
            }

            return objectInfoNode.Attributes.GetNamedItem( PROGID_ATTRIBUTE ).Value;
        }

        /// <summary>
        /// Retrieve the value of the Type attribute from an 
        /// Xml node
        /// </summary>
        /// <param name="objectInfoNode">An Xml node containing a 
        /// Type attribute</param>
        /// <returns>The value of the Type attribute</returns>
        public static string GetTypeAttributeValue( XmlNode objectInfoNode )
        {
            if( objectInfoNode.Attributes.GetNamedItem( TYPE_ATTRIBUTE ) == null )
            {
                throw new TypeFactoryException(new ArgumentException( Strings.NoTypeAttributeFoundInXmlNode, "objectInfoNode" ));
            }

            return objectInfoNode.Attributes.GetNamedItem( TYPE_ATTRIBUTE ).Value;
        }

        /// <summary>
        /// Retrieve the value of the codebase attribute from an 
        /// Xml node
        /// </summary>
        /// <param name="objectInfoNode">An Xml node containing a 
        /// Type attribute</param>
        /// <returns>The value of the Type attribute</returns>
        public static string GetCodebaseAttributeValue( XmlNode objectInfoNode )
        {
            string retval = string.Empty;
            if( objectInfoNode.Attributes.GetNamedItem( CODEBASE_ATTRIBUTE ) != null )
            {
                retval = objectInfoNode.Attributes.GetNamedItem( CODEBASE_ATTRIBUTE ).Value;
            }

            return retval;
        }

        /// <summary>
        /// Determine if an object uses COM based activation 
        /// </summary>
        /// <param name="objectInfoNode">Xml containing an 
        /// object's activation type</param>
        /// <returns>True if the object uses COM based activation, 
        /// false if not</returns>
        public static bool UsesACOMBasedActivation( XmlNode objectInfoNode )
        {
            return GetActivationType( objectInfoNode ) == ActivationType.COM;
        }

        /// <summary>
        /// Retrive an object's activation type from Xml
        /// </summary>
        /// <param name="objectInfoNode">Xml containing an 
        /// object's activation type</param>
        /// <returns>The activation type</returns>
        public static ActivationType GetActivationType( XmlNode objectInfoNode )
        {
            if( objectInfoNode.Attributes.GetNamedItem( ACTIVATION_TYPE_ATTRIBUTE ) == null )
            {
                throw new TypeFactoryException(new ArgumentException( Strings.NoActivationTypeAttributeFoundInXmlNode, "objectInfoNode"));
            }

            return (ActivationType)Enum.Parse( typeof( ActivationType ), objectInfoNode.Attributes.GetNamedItem( ACTIVATION_TYPE_ATTRIBUTE ).Value, true );
        }
    }

    /// <summary>
    /// Pulled out to eliminate code dupe
    /// </summary>
    [ ComVisible( false ) ]
    public static class AssemblyLoader
    {
        /// <summary>
        /// Keep a static cache of loaded Assemblies to speed up late bound activations
        /// </summary>
        private static Hashtable _loadedAssemblies = new Hashtable(StringComparer.InvariantCultureIgnoreCase);

        /// <summary>
        /// Cache anything that has been loaded to date
        /// </summary>
        static AssemblyLoader()
        {
            AppDomain.CurrentDomain.AssemblyLoad += new AssemblyLoadEventHandler(OnAssemblyLoaded);

            lock (_loadedAssemblies)
            {
                string assemblyLocation = string.Empty;
                foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    try
                    {
                        assemblyLocation = assembly.Location;
                    }
                    catch(Exception)
                    {
                        // If the assembly is actually a System.Reflection.Emit.AssemblyBuilder, then it is possible that
                        // the Location property may throw an exception.
                        assemblyLocation = string.Empty;
                    }

                    InfoTrace.WriteLine(null, "assembly FullName={0} Location={1}", assembly.FullName, assemblyLocation);
                    if(!_loadedAssemblies.ContainsKey(assembly.GetName().Name))
                    {
                        _loadedAssemblies.Add(assembly.GetName().Name, assembly);
                    }
                    else
                    {
                        // This case was observed to occur during an install of a component with a custom installer class
                        // which used the AssemblyLoader class.
                        //
                        // It is suspected that we could get in this state if an AppDomain has explicitly done an
                        // Assembly.LoadFrom of an assembly of the same name from multiple file locations.
                        string message = string.Format(CultureInfo.InvariantCulture, "Skipping adding assembly with Name={0} to _loadedAssemblies;  already exists", assembly.GetName().Name);
                        Assertions.Assert(false, message);
                    }
                }
            }
        }

        /// <summary>
        /// Load algorithm for late-bound assemblies loading
        /// 1.  Check in-memory cache
        /// 2.  Check resolved codebase with and without file extensions.  
        ///     explicit paths or registered paths can be used
        /// 3.  If ends in extension, try Assembly.LoadFrom directly
        /// 4.  Try Assembly.Load.
        /// </summary>
        /// <param name="assemStr"></param>
        /// <param name="codebaseKey"></param>
        /// <returns></returns>
        public static Assembly Load(string assemStr, string codebaseKey)
        {
            //
            // First check any cached loaded assemblies
            //
            assemStr = assemStr.ToUpper(CultureInfo.InvariantCulture);
            Assembly componentAssembly = getLoadedAssembly(GetAssemblyNameWithoutExtension(assemStr));
            if (componentAssembly != null)
            {
                return componentAssembly;
            }
            //
            // Is there a codebase attribute?  If so, check to see if the file extension exists or 
            // append if not.
            //
            string codebasePath = AssemblyLoader.ExpandCodebaseKey(codebaseKey);
            if (codebasePath.Length > 0)
            {
                if (assemStr.EndsWith("DLL") || assemStr.EndsWith("EXE"))
                {
                    string fullPath = codebasePath + @"\" + assemStr;
                    if (loadFrom(fullPath, out componentAssembly) == false)
                    {
                        throw new TypeFactoryException(new FileNotFoundException(fullPath + " cannot be found to load"));
                    }
                }
                else
                {
                    string fullPath = codebasePath + @"\" + assemStr + ".dll";
                    if (loadFrom(fullPath, out componentAssembly) == false)
                    {
                        fullPath = codebasePath + @"\" + assemStr + ".exe";
                        if (loadFrom(fullPath, out componentAssembly) == false)
                        {
                            throw new TypeFactoryException(new FileNotFoundException(assemStr + " dll or exe cannot be found to load"));
                        }
                    }
                }
            }
            //
            // No Codebase attribute, but ends in dll or exe - try LoadFrom
            //
            else if (assemStr.EndsWith("DLL") || assemStr.EndsWith("EXE")) 
            {
                string fullPath = AssemblyFullPath(assemStr);
                if (loadFrom(fullPath, out componentAssembly) == false)
                {
                    throw new TypeFactoryException(new FileNotFoundException(fullPath + " cannot be found to load"));
                }
            }
            //
            // Just try to load using normal probing policies
            //
            else
            {
                componentAssembly = Assembly.Load(assemStr);
            }
            return componentAssembly;
        }

        /// <summary>
        /// Retrieve the name of an assembly file without a file extension
        /// </summary>
        /// <param name="assemblyName">The file name of an assembly</param>
        /// <returns>The name of an assembly file without a file extension</returns>
        /// <remarks>The method is used instead of Path.GetFileNameWithoutExtension 
        /// because that method will strip off the end of a valid assembly name that 
        /// contains the extension charater but no file extension. 
        /// For example, "Sage.Messaging" would be stripped to just Sage. </remarks>
        private static string GetAssemblyNameWithoutExtension( string assemblyName )
        {
            string retval = assemblyName;
            string extension = Path.GetExtension( assemblyName );
            if( string.Compare( extension, ".dll", true, CultureInfo.InvariantCulture ) == 0 || string.Compare( extension, ".exe", true, CultureInfo.InvariantCulture ) == 0 )
            {
                retval = Path.GetFileNameWithoutExtension(assemblyName);
            }
            return retval;
        }


        /// <summary>
        /// The Codebase key can either be empty, a fully qualified path or a registered path
        /// </summary>
        /// <param name="codebaseKey"></param>
        /// <returns></returns>
        public static string ExpandCodebaseKey(string codebaseKey)
        {
            string expandedCodebasePath = string.Empty;
            if (codebaseKey.Length > 0)
            {
                expandedCodebasePath = codebaseKey;
                if (codebaseKey.Length > 2 && codebaseKey[0] == '[' && codebaseKey[codebaseKey.Length-1] == ']')
                {
                    codebaseKey = codebaseKey.Substring(1, codebaseKey.Length-2);
                    expandedCodebasePath = PathRegistrar.ResolveUrl(codebaseKey);
                }
                if (!Directory.Exists(expandedCodebasePath))
                {
                    throw new TypeFactoryException(new FileNotFoundException("Directory " + expandedCodebasePath + " does not exist."));
                }
            }
            return expandedCodebasePath;
        }

        /// <summary>
        /// Update the loaded assemblies cache whenever a new assembly is loaded
        /// </summary>
        private static void OnAssemblyLoaded(object sender, AssemblyLoadEventArgs args)
        {
            lock (_loadedAssemblies)
            {
                //
                // David loads the multiple in-memory assemblies from a stream with the same name
                //
                if (!_loadedAssemblies.ContainsKey(args.LoadedAssembly.GetName().Name))
                {
                    _loadedAssemblies.Add(args.LoadedAssembly.GetName().Name, args.LoadedAssembly);
                }
            }
        }


        /// <summary>
        /// Verify file exists and attempt to Load assembly if it does
        /// </summary>
        /// <param name="fullPath"></param>
        /// <param name="component"></param>
        /// <returns></returns>
        private static bool loadFrom(string fullPath, out Assembly component)
        {
            bool result = false;
            component = null;
            if (File.Exists(fullPath) == true)
            {
                // process the Library Manifests from this assembly's location
                //LibraryManager.InitializeLibraries(LibraryManager.LibraryManifestLocationForBinary(fullPath));

                // load the assembly
                component = Assembly.LoadFrom(fullPath);
                result = true;
            }
            return result;
        }

        /// <summary>
        /// Checks if the assembly is already loaded into the current app domain.   If it
        /// is it return the assembly
        /// </summary>
        /// <param name="assemblyName">Name of the assembly to search for for example "TSDESKTOPTASKS"</param>
        /// <returns>The Assembly if found in the current App Domain, else null</returns>
        private static Assembly getLoadedAssembly(string assemblyName)
        {
            Assembly loadedAssembly = null;
            lock (_loadedAssemblies)
            {
                if (_loadedAssemblies.Contains(assemblyName))
                {
                    loadedAssembly = (Assembly)_loadedAssemblies[assemblyName];
                }
            }
            return loadedAssembly;
        }

        /// <summary>
        /// Find the path of the passed in assembly
        /// Note: this method was copied in part from Sage.Configuration.Paths.AssemblyFullPath (Sage.STO.Core). The
        /// Sage.STO.Core method is not being used because it contains CRE dependencies with are not applicable in this context.
        /// </summary>
        /// <param name="assemblyFile">The name of the assembly file to find</param>
        /// <returns>The path to the assembly file</returns>
        private static string AssemblyFullPath(string assemblyFile)
        {
            string fullAssemblyPath = Path.GetDirectoryName(Assembly.GetCallingAssembly().Location) + @"\" + assemblyFile;
            if(!File.Exists(fullAssemblyPath))
            {
                fullAssemblyPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\" + assemblyFile;
                if(!File.Exists(fullAssemblyPath))
                {
                    fullAssemblyPath = AppDomain.CurrentDomain.BaseDirectory + @"\" + assemblyFile;
                    if(!File.Exists(fullAssemblyPath))
                    {
                        fullAssemblyPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase.Remove(0, 8)) + @"\" + assemblyFile;
                        if(!File.Exists(fullAssemblyPath))
                        {
                            throw new FileNotFoundException(string.Format(Strings.UnableToFindFormat, assemblyFile));
                        }
                    }
                }
            }
            return fullAssemblyPath;
        }
    }
}
