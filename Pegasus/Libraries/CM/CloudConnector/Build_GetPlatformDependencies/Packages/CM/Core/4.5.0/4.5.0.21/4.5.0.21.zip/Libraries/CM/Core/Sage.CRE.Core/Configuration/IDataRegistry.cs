using System;
using System.Runtime.InteropServices;

namespace Sage.Configuration
{

	/// <summary>
	/// Interface for interacting with the Data Registry
	/// </summary>
    [ComVisible(false)]
    public interface IDataRegistry
	{
        /// <summary>
        /// Create or open a keyed value set
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>Interface to the keyed value set</returns>
        /// <remarks>If the keyed value set already exists this method will simply return an interface to it. If it does not exist it will create it</remarks>
        [ DispId( 1 ) ]
        IKeyedValues CreateKeyedValueSet( DataScope scope, string location, string name );

        /// <summary>
        /// Create a open an encrypted keyed value set 
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>Interface to the keyed value set</returns>
        /// <remarks>If the keyed value set already exists this method will simply return an interface to it. If it does not exist it will create it</remarks>
        [ DispId( 2 ) ]
        IKeyedValues CreateEncryptedKeyedValueSet( DataScope scope, string location, string name );
        
        /// <summary>
        /// Open an existing keyed value set
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>Interface to the keyed value set</returns>
        /// <remarks>An error is throw if you attemtp to open a keyed value set that doesn't exist</remarks>
        [ DispId( 3 ) ]
        IKeyedValues OpenKeyedValueSet( DataScope scope, string location, string name );
        
        /// <summary>
        /// Remove a keyed value set 
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        [ DispId( 4 ) ]
        void RemoveKeyedValueSet( DataScope scope, string location, string name );
        
        /// <summary>
        /// Determine if the data registry contains a particular keyed value set.
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>True if the keyed value set exists, false if not</returns>
        [ DispId( 5 ) ]
        bool ContainsKeyedValueSet( DataScope scope, string location, string name );
        
        /// <summary>
        /// Remove all data sets from a particular location within the data registry
        /// </summary>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        [ DispId( 6 ) ]
        void RemoveAllData( string location );
	}
}
