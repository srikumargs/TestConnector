using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Reflection;
using System.IO;

// TODO: extract to Sage.Xml (Sage.CRE.Core)

namespace TraceConfigTool
{
    /// <summary>
    /// Merges two <see cref="XmlNode"/> objects.
    /// </summary>
    internal static class XmlMerge
    {
        static XmlMerge()
        {
            _xslTransform = new XslTransform();
            _xslTransform.Load(new XmlTextReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("TraceConfigTool.merge.xslt")), null, null);

            // Dummy input document for the merge stylesheet.
            _transformInput = new XPathDocument(new StringReader(String.Format(
              @"<?xml version='1.0'?>
                <merge xmlns='http://informatik.hu-berlin.de/merge'>
                    <file1>mem://{0}</file1>
                    <file2>mem://{1}</file2>
                </merge>", FirstTag, SecondTag)));
        }

        /// <summary>
        /// Merges the first XML with the second.
        /// </summary>
        /// <param name="first">First XML.</param>
        /// <param name="second">Second XML.</param>
        /// <param name="replace">If set to <see langword="true"/> replaces 
        /// text values from <paramref name="first"/> with the ones in 
        /// <paramref name="second"/> if nodes are equal.</param>
        /// <returns>The merged XML.</returns>
        public static XmlDocument Merge(IXPathNavigable first, IXPathNavigable second, bool replace)
        {
            // Holds the merged results.
            StringBuilder stringBuilder = new StringBuilder();
            XmlTextWriter textWriter = new XmlTextWriter(new StringWriterWithEncoding(stringBuilder, Encoding.UTF8));
            textWriter.Formatting = Formatting.None;

            // Specify whether second node replaces text from first one.
            XsltArgumentList arguments = new XsltArgumentList();
            arguments.AddParam("replace", String.Empty, replace);

            textWriter.WriteStartDocument(true);
            _xslTransform.Transform(_transformInput, arguments, textWriter, new XmlNodeResolver(first, second));
            textWriter.WriteEndDocument();
            textWriter.Flush();

            XmlDocument result = new XmlDocument();
            result.LoadXml(stringBuilder.ToString());

            return result;
        }

        #region Private fields
        private const string FirstTag = "first";
        private const string SecondTag = "second";
        private static XslTransform _xslTransform;
        private static IXPathNavigable _transformInput;
        #endregion

        private class StringWriterWithEncoding : StringWriter
        {
            #region Constructors
            public StringWriterWithEncoding(StringBuilder stringBuilder, Encoding encoding) : base(stringBuilder)
            {
                _encoding = encoding;
            }
            #endregion

            #region Public properties
            public override Encoding Encoding
            {
                get
                {
                    return _encoding;
                }
            }
            #endregion

            #region Private fields
            private Encoding _encoding;
            #endregion
        }

        /// <summary>
        /// Resolves the dummy URL locations to the parameters received.
        /// </summary>
        private class XmlNodeResolver : XmlResolver
        {
            #region Constructors
            public XmlNodeResolver(IXPathNavigable first, IXPathNavigable second)
            {
                _first = first;
                _second = second;
            }
            #endregion

            #region Public methods
            public override object GetEntity(Uri absoluteUri, string role, Type ofObjectToReturn)
            {
                if(absoluteUri.Authority == FirstTag)
                {
                    return _first.CreateNavigator();
                }
                else if(absoluteUri.Authority == SecondTag)
                {
                    return _second.CreateNavigator();
                }

                return null;
            }
            #endregion

            #region Public properties
            public override System.Net.ICredentials Credentials
            {
                set
                {
                }
            }
            #endregion

            #region Private fields
            private IXPathNavigable _first;
            private IXPathNavigable _second;
            #endregion
        }
    }
}
