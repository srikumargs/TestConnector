using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Collections;
using System.Globalization;

namespace Sage.Activation
{

    /// <summary>
    /// Throw a TypeReader specific exception
    /// </summary>
    [ ComVisible( false ) ]
    public class TypeReaderException : ApplicationException
    {
        /// <summary>
        /// set the exception message in the ctor
        /// </summary>
        /// <param name="msg">exception message</param>
        public TypeReaderException(string msg) : base(msg) {}

        /// <summary>
        /// Set the message plus the inner exception that we caught.
        /// </summary>
        /// <param name="msg">exception message</param>
        /// <param name="inner">inner exception we caught</param>
        public TypeReaderException(string msg, Exception inner) : base(msg, inner) {}
    }

    /// <summary>
    /// Object wrapper that allows access to any xml config stream 
    /// </summary>
    [ ComVisible( false ) ]
    public class TypeReader
    {
        private XPathNavigator _nav;

        private const string UNMANAGED_SCHEMA          = @"<TypeInstance QualifiedTypeName='{0}' ExecutionEnvironment='unmanaged'/>";
        private const string MANAGED_SCHEMA            = @"<TypeInstance QualifiedTypeName='{0}' Assembly='{1}' Codebase='{2}' ExecutionEnvironment='managed'/>";
        private const string MANAGED_URI_SCHEMA        = @"<TypeInstance QualifiedTypeName='{0}' Assembly='{1}' ExecutionEnvironment='managed' Codebase='{2}' URI='{3}'/>";
        private const string MANAGED_REMOTE_URI_SCHEMA = @"<TypeInstance QualifiedTypeName='{0}' Assembly='{1}' ExecutionEnvironment='managed' Codebase='{2}' URI='{3}' Location='{4}'/>";
        private const string TYPE_LOOKUP_XPATH         = "//TypeInstance[@TypeLookup='{0}']";

        /// <summary>
        /// Force a ctor
        /// </summary>
        private TypeReader() {}


        /// <summary>
        /// Pass in a valid TextReader
        /// </summary>
        /// <param name="xmlText"></param>
        public TypeReader(TextReader xmlText)
        {
            try 
            {
				_nav = new XPathDocument(xmlText).CreateNavigator(); 

            }
            catch (Exception e)
            {
                throw new TypeReaderException(Strings.CannotExecuteTypeReaderConstructor + e.Message, e); 
            }
        }

		/// <summary>
		/// Pass in a valid XML stream
		/// </summary>
		/// <param name="xmlStream"></param>
		public TypeReader(Stream xmlStream)
		{
			try 
			{
				_nav = new XPathDocument(xmlStream).CreateNavigator(); 

			}
			catch (Exception e)
			{
				throw new TypeReaderException(Strings.CannotExecuteTypeReaderConstructor + e.Message, e); 
			}
		}

		/// <summary>
		/// Pass in a valid XML Reader 
		/// </summary>
		/// <param name="xmlReader"></param>
		public TypeReader(XmlReader xmlReader)
		{
			try 
			{
				_nav = new XPathDocument(xmlReader).CreateNavigator(); 

			}
			catch (Exception e)
			{
				throw new TypeReaderException(Strings.CannotExecuteTypeReaderConstructor + e.Message, e); 
			}
		}

		/// <summary>
		/// Create the approriate type instance schema for COM and pass to TextReader ctor
		/// </summary>
		/// <param name="progId"></param>
        public TypeReader(string progId) :
            this(new StringReader(string.Format(CultureInfo.InvariantCulture, UNMANAGED_SCHEMA, progId)))
        {
        }

        /// <summary>
        /// Create the approriate type instance schema for .NET and pass to TextReader ctor
        /// </summary>
        /// <param name="type"></param>
		/// <param name="assem"></param>
		/// <param name="codebase">The location of the component assembly</param>
        public TypeReader(string type, string assem, string codebase ) :
            this(new StringReader(string.Format(CultureInfo.InvariantCulture, MANAGED_SCHEMA, type, assem, codebase)))
        {
        }

        /// <summary>
        /// Create the approriate type instance schema for .NET and pass to TextReader ctor
        /// </summary>
        /// <param name="type"></param>
        /// <param name="assem"></param>
        /// <param name="codebase">The location of the component assembly</param>
        /// <param name="uri"></param>
        public TypeReader(string type, string assem, string codebase, string uri ) :
            this(new StringReader(string.Format(CultureInfo.InvariantCulture, MANAGED_URI_SCHEMA, type, assem, codebase, uri)))
        {
        }

        /// <summary>
        /// Create the approriate type instance schema for .NET and pass to TextReader ctor
        /// </summary>
        /// <param name="type"></param>
        /// <param name="assem"></param>
        /// <param name="codebase">The location of the component assembly</param>
        /// <param name="uri"></param>
        /// <param name="location"></param>
        public TypeReader(string type, string assem, string codebase, string uri, string location ) :
            this(new StringReader(string.Format(CultureInfo.InvariantCulture, MANAGED_REMOTE_URI_SCHEMA, type, assem, codebase, uri, location)))
        {
        }

        /// <summary>
        /// Pass in a valid navigator instead of a file
        /// </summary>
        /// <param name="nav"></param>
        public TypeReader(XPathNavigator nav)
        {
            _nav = nav;
        }

        /// <summary>
        /// is there a type lookup in this type reader that matches the string
        /// passed in?
        /// </summary>
        /// <param name="typeLookup">a type lookup attribute value</param>
        /// <returns>true if the Xpath expression evaluates, else false</returns>
        public bool IsValidTypeLookup(string typeLookup)
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendFormat(TYPE_LOOKUP_XPATH, typeLookup);
            return IsValidExpression(strBuilder.ToString());
        }

        /// <summary>
        /// Does the XPath expression evaluate to a node?
        /// </summary>
        /// <param name="expr">An XPath expression</param>
        /// <returns>true if the Xpath expression evaluates, else false</returns>
        public bool IsValidExpression(string expr)
        {
            XPathNodeIterator iter = _nav.Select(expr.ToString());
            return iter.MoveNext() ? true : false;
        }


        /// <summary>
        /// Returns the node value of the evaluated XPath expression
        /// </summary>
        /// <param name="expr">An XPath expression intended to evaluate to a single node</param>
        /// <param name="throwExceptionIfNotFound">is an unfound value an error or not</param>
        /// <returns>The node value as string or empty if exceptions not thrown</returns>
        public string SelectSingleNodeValue(string expr, bool throwExceptionIfNotFound)
        {
            XPathNodeIterator iter = _nav.Select(expr);
            if (iter.MoveNext())
            {
                return iter.Current.Value;
            }
            else if (throwExceptionIfNotFound == true)
            {
                throw new TypeReaderException(Strings.ConfigReaderCannotEvaluateExpression + expr);
            }
            else
            {
                return String.Empty;
            }
        }
    }

    /// <summary>
    /// Uses a DOM to enumerate a collection of TypeFactory tags
    /// </summary>
    [ ComVisible( false ) ]
    public class TypeFactoryReader : TypeReader
    {
        private XmlDocument _xml = new XmlDocument();

        /// <summary>
        /// Initializes a new instance of the TypeFactoryReader class. 
        /// </summary>
        public TypeFactoryReader(string configFileAndPath) : base(new XPathDocument(configFileAndPath).CreateNavigator())
        {
            try 
            {
                _xml.Load(configFileAndPath);
            }
            catch (Exception e)
            {
                throw new TypeReaderException(Strings.CannotExecuteTypeFactoryReaderConstructor + e.Message, e); 
            }
        }

        /// <summary>
        /// Initializes a new instance of the TypeFactoryReader class. 
        /// </summary>
        /// <param name="node"></param>
        public TypeFactoryReader(XmlNode node) : base(node.CreateNavigator())
        {
            try 
            {
                _xml.LoadXml(node.OuterXml);
            }
            catch (Exception e)
            {
                throw new TypeReaderException(Strings.CannotExecuteTypeFactoryReaderConstructor + e.Message, e); 
            }
        }

        /// <summary>
        /// Initializes a new instance of the TypeFactoryReader class. 
        /// </summary>
        /// <param name="navigator"></param>
        public TypeFactoryReader(XPathNavigator navigator)
            : base(navigator)
        {
            try
            {
                _xml.LoadXml(navigator.OuterXml);
            }
            catch (Exception e)
            {
                throw new TypeReaderException(Strings.CannotExecuteTypeFactoryReaderConstructor + e.Message, e);
            }
        }

        /// <summary>
        /// Return an array of TypeFactorys
        /// </summary>
        public TypeFactory[] TypeFactorys
        {
            get
            {
                return BuildArray("//TypeInstance");
            }
        }

        /// <summary>
        /// Search for specific implementors
        /// </summary>
        /// <param name="ifaceName"></param>
        /// <returns></returns>
        public TypeFactory[] GetInterfaceImplementors(string ifaceName)
        {
            string expr = string.Format(CultureInfo.InvariantCulture, "//Implements[@interface='{0}']/TypeInstance", ifaceName);
            return BuildArray(expr);
        }

        /// <summary>
        /// Return a hashtable of (type lookup name, TypeFactory)
        /// </summary>
        /// <returns></returns>
        public Hashtable TypeFactoriesByTypeLookup
        {
            get
            {
                Hashtable result = new Hashtable();
                XmlNodeList nodes = _xml.SelectNodes("//TypeInstance[@TypeLookup]");
                foreach(XmlNode node in nodes)
                {
                    result[node.Attributes["TypeLookup"].Value] = new TypeFactory(TypeReaderFactory.Create(node));
                }
                return result;
            }
        }

        /// <summary>
        /// WorkHorse  for building the array
        /// </summary>
        /// <param name="expr"></param>
        /// <returns></returns>
        private TypeFactory[] BuildArray(string expr)
        {
            ArrayList instances = new ArrayList();
            XmlNodeList nodes = _xml.SelectNodes(expr);
            foreach (XmlNode node in nodes)
            {
                instances.Add(new TypeFactory(TypeReaderFactory.Create(node)));
            }
            TypeFactory[] array = new TypeFactory[instances.Count];
            instances.CopyTo(array);
            return array;
        }
    }
}