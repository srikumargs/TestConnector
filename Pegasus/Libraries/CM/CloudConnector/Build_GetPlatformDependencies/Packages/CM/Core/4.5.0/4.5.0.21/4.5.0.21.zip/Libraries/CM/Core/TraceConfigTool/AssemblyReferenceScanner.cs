using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;

using Sage.Activation;
using Sage.CRE.LinkedSource;

// TODO: extract to Sage.Activation (Sage.CRE.Core)

namespace TraceConfigTool
{
    /// <summary>
    /// 
    /// </summary>
    /// <remarks>
    /// This interface was created solely to enable scanner classes to have both a static method and an instance
    /// method called "Scan" which have identical signatures.
    /// </remarks>
    internal interface IAssemblyReferenceScanner
    {
        ArrayList Scan(string targetAssemblyPath);
    }


    /// <summary>
    /// 
    /// </summary>
    /// <remarks>
    /// This class implements the IAssemblyReferenceScanner interface so that we can have both a static method and an instance
    /// method called "Scan" which have identical signatures.
    /// </remarks>
    internal class TimberlineAssemblyReferenceScanner : MarshalByRefObject, IAssemblyReferenceScanner
    {
        public override object InitializeLifetimeService()
        {
            return null;
        }

        public static ArrayList ScanInIsolatedAppDomain(string targetAssemblyPath)
        {
            ArrayList result = null;
            using (IsolatedAppDomainHelper appDomainHelper = new IsolatedAppDomainHelper("TimberlineAssemblyReferenceScanner"))
            {
                object target = appDomainHelper.CreateInstanceAndUnwrap(typeof(TimberlineAssemblyReferenceScanner));
                result = (target as IAssemblyReferenceScanner).Scan(targetAssemblyPath);
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// This method was created so that we could implement ScanInIsolatedAppDomain ... which requires a target instace.  Otherwise, 
        /// this class would simply be declared static.
        /// </remarks>
        /// <param name="targetAssemblyPath"></param>
        /// <returns></returns>
        ArrayList IAssemblyReferenceScanner.Scan(string targetAssemblyPath)
        {
            return TimberlineAssemblyReferenceScanner.Scan(targetAssemblyPath);
        }

        public static ArrayList Scan(string targetAssemblyPath)
        {
            AssemblyResolver.AddResolvePath(Directory.GetParent(targetAssemblyPath).FullName);
            AssemblyResolver.AddResolvePath(Environment.GetEnvironmentVariable("TS_SHARED"));
            AssemblyResolver.AddResolvePath(Environment.GetEnvironmentVariable("TS_ACCOUNTING"));
            AssemblyResolver.AddResolvePath(Environment.GetEnvironmentVariable("TS_ESTIMATING"));
            AssemblyResolver.AddResolvePath(Path.Combine(Environment.GetEnvironmentVariable("TS_SANDBOX"), "Desktop"));
            AssemblyResolver.Enabled = true;

            ArrayList assemblyReferencesInfo = AssemblyReferenceScanner.Scan(targetAssemblyPath);
            int foundAssemblyCount = assemblyReferencesInfo.Count;

            AssemblyReferenceInfo[] assemblyReferencesInfoAsArray = (AssemblyReferenceInfo[]) assemblyReferencesInfo.ToArray(typeof(AssemblyReferenceInfo));
            AssemblyReferenceInfo[] thirdPartyAssemblies = Array.FindAll(assemblyReferencesInfoAsArray, new Predicate<AssemblyReferenceInfo>(Is3rdPartyAssembly));

            foreach(AssemblyReferenceInfo info in thirdPartyAssemblies)
            {
                assemblyReferencesInfo.Remove(info);
            }

            int non3rdPartyAssemblyCount = assemblyReferencesInfo.Count;

            return assemblyReferencesInfo;
        }

        private static bool Is3rdPartyAssembly(AssemblyReferenceInfo info)
        {
            byte[] assemblyPublicKeyToken = info.AssemblyName.GetPublicKeyToken();
            byte[] myAssemblyPublicKeyToken = Assembly.GetExecutingAssembly().GetName().GetPublicKeyToken();

            return (Convert.ToBase64String(assemblyPublicKeyToken, 0, assemblyPublicKeyToken.Length) != Convert.ToBase64String(myAssemblyPublicKeyToken, 0, myAssemblyPublicKeyToken.Length));
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <remarks>
    /// This class implements the IAssemblyReferenceScanner interface so that we can have both a static method and an instance
    /// method called "Scan" which have identical signatures.
    /// </remarks>
    internal class AssemblyReferenceScanner : MarshalByRefObject, IAssemblyReferenceScanner
    {
        public override object InitializeLifetimeService()
        {
            return null;
        }

        public static ArrayList ScanInIsolatedAppDomain(string targetAssemblyPath)
        {
            ArrayList result = null;
            using (IsolatedAppDomainHelper appDomainHelper = new IsolatedAppDomainHelper("AssemblyReferenceScanner"))
            {
                object target = appDomainHelper.CreateInstanceAndUnwrap(typeof(AssemblyReferenceScanner));
                result = (target as IAssemblyReferenceScanner).Scan(targetAssemblyPath);
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// This method was created so that we could implement ScanInIsolatedAppDomain ... which requires a target instace.  Otherwise, 
        /// this class would simply be declared static.
        /// </remarks>
        /// <param name="targetAssemblyPath"></param>
        /// <returns></returns>
        ArrayList IAssemblyReferenceScanner.Scan(string targetAssemblyPath)
        {
            return AssemblyReferenceScanner.Scan(targetAssemblyPath);
        }

        public static ArrayList Scan(string targetAssemblyPath)
        {
            ArrayList result = new ArrayList();   // ArrayList of Info objects
            ArrayList listFound = new ArrayList(); // list of Assembly names to avoid dups and an endless loop
            Stack stack = new Stack(); // stack of Assembly Info objects
            AssemblyReferenceInfo info = null;
            int level = 0;

            // store root assembly (level 0) directly into results list
            Assembly assembly = Assembly.LoadFrom(targetAssemblyPath);
            info = new AssemblyReferenceInfo(assembly.GetName(), level);
            result.Add(info);

            // seed level 1 assemblies onto Stack
            AssemblyName[] assemblyName = assembly.GetReferencedAssemblies();
            ++level;
            for(int i = assemblyName.Length - 1 ; i >= 0 ; --i) // store level 1 Assemblies "right-to-left"
            {
                listFound.Add(assemblyName[i].ToString()); // record we've hit the assembly
                info = new AssemblyReferenceInfo(assemblyName[i], level);
                stack.Push(info);
            }

            // do a preorder, non-recursive traversal to store all remaining assemblies
            while(stack.Count > 0)
            {
                info = (AssemblyReferenceInfo) stack.Pop(); // get next assembly info
                result.Add(info); // store it to results ArrayList

                ++level;

                Assembly childAssembly = null;
                try
                {
                    childAssembly = Assembly.Load(info.AssemblyName);
                }
                catch(Exception)
                {
                    // eat all exceptions that might occur when trying to load the assembly
                }

                if(childAssembly != null)
                {
                    AssemblyName[] subChildAssemblyName = childAssembly.GetReferencedAssemblies();
                    for(int i = subChildAssemblyName.Length - 1 ; i >= 0 ; --i) // "right-to-left" = preorder traversal
                    {
                        if(!listFound.Contains(subChildAssemblyName[i].ToString()))
                        {
                            listFound.Add(subChildAssemblyName[i].ToString());
                            AssemblyReferenceInfo subChildInfo = new AssemblyReferenceInfo(subChildAssemblyName[i], level);
                            stack.Push(subChildInfo);
                        }
                    }
                }
            }

            return result;
        }
    }

    [Serializable]
    internal class AssemblyReferenceInfo
    {
        #region Constructors
        public AssemblyReferenceInfo(AssemblyName assemblyName, int level)
        {
            _assemblyName = assemblyName;
            _level = level;
        }
        #endregion

        #region Public properties
        public AssemblyName AssemblyName
        {
            get
            {
                return _assemblyName;
            }
        }

        public int Level
        {
            get
            {
                return _level;
            }
        }
        #endregion

        #region Private fields
        private AssemblyName _assemblyName;
        private int _level;
        #endregion
    }
}
