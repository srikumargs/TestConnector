namespace TraceConfigTool
{
    partial class OutputOptionsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._outputOptionsPropertyGrid = new System.Windows.Forms.PropertyGrid();
            this._enabledCheckBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // _outputOptionsPropertyGrid
            // 
            this._outputOptionsPropertyGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this._outputOptionsPropertyGrid.Enabled = false;
            this._outputOptionsPropertyGrid.Location = new System.Drawing.Point(0, 17);
            this._outputOptionsPropertyGrid.Name = "_outputOptionsPropertyGrid";
            this._outputOptionsPropertyGrid.Size = new System.Drawing.Size(255, 184);
            this._outputOptionsPropertyGrid.TabIndex = 3;
            this._outputOptionsPropertyGrid.PropertyValueChanged += new System.Windows.Forms.PropertyValueChangedEventHandler(this._outputOptionsPropertyGrid_PropertyValueChanged);
            // 
            // _enabledCheckBox
            // 
            this._enabledCheckBox.AutoSize = true;
            this._enabledCheckBox.Dock = System.Windows.Forms.DockStyle.Top;
            this._enabledCheckBox.Location = new System.Drawing.Point(0, 0);
            this._enabledCheckBox.Name = "_enabledCheckBox";
            this._enabledCheckBox.Size = new System.Drawing.Size(255, 17);
            this._enabledCheckBox.TabIndex = 2;
            this._enabledCheckBox.Text = "Enabled";
            this._enabledCheckBox.UseVisualStyleBackColor = true;
            this._enabledCheckBox.CheckStateChanged += new System.EventHandler(this._enabledCheckBox_CheckStateChanged);
            // 
            // OutputOptionsControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._outputOptionsPropertyGrid);
            this.Controls.Add(this._enabledCheckBox);
            this.Name = "OutputOptionsControl";
            this.Size = new System.Drawing.Size(255, 201);
            this.Load += new System.EventHandler(this.OutputOptionsControl_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PropertyGrid _outputOptionsPropertyGrid;
        private System.Windows.Forms.CheckBox _enabledCheckBox;
    }
}
