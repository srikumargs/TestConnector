﻿#if DEBUG

using System;
using System.IO;
using NUnit.Framework;

using Sage.Configuration;

namespace Sage.Configuration.Tests
{
    /// <summary>
    /// Class used for testing the xml data store
    /// </summary>
    [TestFixture]
    public class TestPerUserMRU
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TestPerUserMRU()
        {

        }

        private string FileSystemLocation
        {
            get { return string.Format(@"{0}\DataStoreFileSystemTest\", LibraryManager.SharedConfigLocation, DataRegistry.FileExtension); }
        }

        /// <summary>
        /// Test creating a Per user MRU (most recently used)
        /// </summary>
        [Test]
        public void TestCreatePerUserMRU()
        {
            PerUserMRU w = new PerUserMRU("PerUserMRU");
            w.List.Add("One");
            w.List.Add("Two");

            w.Last = "One";

            w.Write();

            PerUserMRU r = new PerUserMRU("PerUserMRU");
            r.Read();

            Assert.IsTrue(w.Last == r.Last);

            Assert.IsTrue(w.List.Count == r.List.Count);

            Cleanup();
        }

        /// <summary>
        /// Cleanup test data
        /// </summary>
        private void Cleanup()
        {
            DataRegistry.RemoveAllData("DataStoreTest");
            Assert.IsTrue(!Directory.Exists(string.Format(@"{0}\DataStoreTest", LibraryManager.SharedConfigLocation)));

            if (Directory.Exists(FileSystemLocation))
                Directory.Delete(FileSystemLocation, true);

            Assert.IsTrue(!Directory.Exists(FileSystemLocation));
        }
    }
}
#endif
