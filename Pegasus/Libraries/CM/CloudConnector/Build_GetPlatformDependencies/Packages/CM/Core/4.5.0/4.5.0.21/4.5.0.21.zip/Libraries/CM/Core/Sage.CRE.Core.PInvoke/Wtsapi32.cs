using System;
using System.Collections.Generic;
using System.Text;

namespace Sage.PInvoke
{
    public static class Wtsapi32
    {
        /// <summary>
        /// Specifies the current server
        /// </summary>
        public const Int32 WTS_CURRENT_SERVER_HANDLE = 0;

        /// <summary>
        /// Specifies the current session (SessionId)
        /// </summary>
        public static UInt32 WTS_CURRENT_SESSION
        {
            get
            {
                UInt32 result;
                unchecked
                {
                    result = (UInt32) (-1);
                }
                return result;
            }
        }

        public static bool WTSWaitSystemEvent(IntPtr hServer, System.UInt32 EventMask, out System.UInt32 pEventFlags)
        {
            return NativeMethods.WTSWaitSystemEvent(hServer, EventMask, out pEventFlags);
        }

        public static bool WTSEnumerateSessions(IntPtr hServer, System.UInt32 Reserved, System.UInt32 Version, ref IntPtr ppBuffer, ref System.UInt32 pCount)
        {
            return NativeMethods.WTSEnumerateSessions(hServer, Reserved, Version, ref ppBuffer, ref pCount);
        }

        /// <summary>
        /// The WTSQuerySessionInformation function retrieves session information for the specified 
        /// session on the specified terminal server. 
        /// It can be used to query session information on local and remote terminal servers.
        /// http://msdn.microsoft.com/library/default.asp?url=/library/en-us/termserv/termserv/wtsquerysessioninformation.asp
        /// </summary>
        /// <param name="hServer">Handle to a terminal server. Specify a handle opened by the WTSOpenServer function, 
        /// or specify WTS_CURRENT_SERVER_HANDLE to indicate the terminal server on which your application is running.</param>
        /// <param name="SessionID">A Terminal Services session identifier. To indicate the session in which the calling application is running 
        /// (or the current session) specify WTS_CURRENT_SESSION. Only specify WTS_CURRENT_SESSION when obtaining session information on the 
        /// local server. If it is specified when querying session information on a remote server, the returned session 
        /// information will be inconsistent. Do not use the returned data in this situation.</param>
        /// <param name="WTSInfoClass">Specifies the type of information to retrieve. This parameter can be one of the values from the WTSInfoClass enumeration type. </param>
        /// <param name="ppBuffer">Pointer to a variable that receives a pointer to the requested information. The format and contents of the data depend on the information class specified in the WTSInfoClass parameter. 
        /// To free the returned buffer, call the <see cref="WTSFreeMemory"/> function. </param>
        /// <param name="pBytesReturned">Pointer to a variable that receives the size, in bytes, of the data returned in ppBuffer.</param>
        /// <returns>If the function succeeds, the return value is a nonzero value.
        /// If the function fails, the return value is zero. To get extended error information, call GetLastError.
        /// </returns>
        public static bool WTSQuerySessionInformation(IntPtr hServer, UInt32 SessionID, WtsInfoClass WTSInfoClass, ref IntPtr ppBuffer, ref int pBytesReturned)
        {
            return NativeMethods.WTSQuerySessionInformation(hServer, SessionID, WTSInfoClass, ref ppBuffer, ref pBytesReturned);
        }

        /// <summary>
        /// The WTSFreeMemory function frees memory allocated by a Terminal Services function.
        /// </summary>
        /// <param name="memory">Pointer to the memory to free.</param>
        public static void WTSFreeMemory(IntPtr memory)
        {
            NativeMethods.WTSFreeMemory(memory);
        }

    }
}
