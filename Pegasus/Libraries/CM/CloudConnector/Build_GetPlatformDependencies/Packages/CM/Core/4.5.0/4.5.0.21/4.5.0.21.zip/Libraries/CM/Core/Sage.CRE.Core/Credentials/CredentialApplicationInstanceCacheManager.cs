﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sage.Credentials
{
    public static class CredentialApplicationInstanceCacheManager
    {
        /// <summary>
        /// Stores the specified credentials in the application instance cache.
        /// </summary>
        /// <param name="target">The target name for the credentials.</param>
        /// <param name="credential">The credentials to store.</param>
        /// <exception cref="ArgumentNullException">
        /// <para>
        ///   <paramref name="target"/> is <see langword="null" />.
        /// </para>
        /// <para>
        ///   -or-
        /// </para>
        /// <para>
        ///   <paramref name="credential"/> is <see langword="null" />.
        /// </para>
        /// </exception>
        /// <exception cref="ArgumentException"><paramref name="target"/> is an empty string ("").</exception>
        /// <exception cref="CredentialException">An error occurred storing the credentials.</exception>
        /// <remarks>
        /// <para>
        ///   If the credential manager already contains credentials for the specified <paramref name="target"/>, they
        ///   will be overwritten; this can even overwrite credentials that were stored by another application. Therefore 
        ///   it is strongly recommended that you prefix the target name to ensure uniqueness, e.g. using the
        ///   form "Company_ApplicationName_www.example.com".
        /// </para>
        /// </remarks>
        public static void StoreCredential(String target, SecureCredentials credential)
        {
            if (target == null)
            {
                throw new ArgumentNullException("target");
            }
            if (target.Length == 0)
            {
                throw new ArgumentException("The credential target may not be an empty string.", "target");
            }
            if (credential == null)
            {
                throw new ArgumentNullException("credential");
            }

            lock (_cache)
            {
                _cache[target] = new SecureCredentials()
                {
                    UserName = credential.UserName,
                    Password = credential.Password.Copy()
                };
            }
        }

        /// <summary>
        /// Tries to get the credentials for the specified target from the application instance credential cache.
        /// </summary>
        /// <param name="target">The target for the credentials, typically a server name.</param>
        /// <returns>The credentials that were found in the application instance cache; otherwise, <see langword="null" />.</returns>
        /// <remarks>
        /// <para>
        ///   This function will only check the the application instance credential cache; the operating system's credential store
        ///   is not checked. To retrieve credentials from the operating system's store, use <see cref="CredentialStoreManager"/>.
        /// </para>
        /// </remarks>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is <see langword="null" />.</exception>
        /// <exception cref="ArgumentException"><paramref name="target"/> is an empty string ("").</exception>
        public static SecureCredentials RetrieveCredential(string target)
        {
            if (target == null)
            {
                throw new ArgumentNullException("target");
            }
            if (target.Length == 0)
            {
                throw new ArgumentException("The credential target may not be an empty string.", "target");
            }

            Boolean found = false;
            SecureCredentials result = null;
            lock (_cache)
            {
                found = _cache.TryGetValue(target, out result);
            }

            if (found)
            {
                return new SecureCredentials() { UserName = result.UserName, Password = result.Password.Copy() };
            }

            return null;
        }

        /// <summary>
        /// Deletes the credentials for the specified target.
        /// </summary>
        /// <param name="target">The name of the target for which to delete the credentials.</param>
        /// <returns><see langword="true"/> if the credential was deleted from the application instance cache; <see langword="false"/> if no credentials for the specified target could be found
        /// in either store.</returns>
        /// <remarks>
        /// <para>
        ///   The credentials for the specified target will be removed from the application instance credential cache
        /// </para>
        /// </remarks>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is <see langword="null" />.</exception>
        /// <exception cref="ArgumentException"><paramref name="target"/> is an empty string ("").</exception>
        /// <exception cref="CredentialException">An error occurred deleting the credentials from the operating system's credential store.</exception>
        public static bool DeleteCredential(string target)
        {
            if (target == null)
            {
                throw new ArgumentNullException("target");
            }
            if (target.Length == 0)
            {
                throw new ArgumentException("The credential target may not be an empty string.", "target");
            }

            bool result = false;
            lock (_cache)
            {
                SecureCredentials creds = null;
                result = _cache.TryGetValue(target, out creds);
                if (result)
                {
                     _cache.Remove(target);
                     creds.Dispose();
                }
            }

            return result;
        }

        private static readonly Dictionary<string, SecureCredentials> _cache = new Dictionary<string, SecureCredentials>();
    }

}
