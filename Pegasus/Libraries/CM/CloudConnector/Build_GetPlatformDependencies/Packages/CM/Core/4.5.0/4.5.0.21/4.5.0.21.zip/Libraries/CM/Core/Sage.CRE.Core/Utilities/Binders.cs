﻿/// <summary>a collection of classes that allow you to adapt a function taking X + Y parameters to an event/delegate that takes X parameters and supplying Y parameters at Binder construction time.</summary>
/// <example> This sample shows a pattern for using the Binder with standard EventHandler delegates
/// <code>
/// using System;
/// using System.Drawing;
/// using System.Windows.Forms;
/// using Sage.Utilities.Binders;
/// 
/// class Sample
/// {
///   using EventBinder = VoidBinder3rd< object, EventArgs, Color >;
///   
///   Button _btnColorBlue;
///   Control _btnColorRed;  
///   
///   private void _OnColorSelected( object sender, EventArgs args, Color color )
///   {
///     Control oControl = ( Control )sender;
///     oControl.BackColor = color;
///   }
///   
///   private void Initialize( )
///   {
///     _btnColorBlue.Clicked += new EventHandler( new EventBinder( _OnColorSelected, Color.Blue ).ExposedFunction );
///     _btnColorRed.Clicked += new EventHandler( new EventBinder( _OnColorSelected, Color.Red ).ExposedFunction );    
///   }
/// }  
/// </code></example>
namespace Sage.Utilities.Binders
{
  /// <summary>Generic Adapter class that allows you to adapt a function that takes 1 parameters to an event/delegate that takes no parameters and supplying the 1st parameter at construction time</sumamry>
  /// <seealso cref="Sage.Utilities.Binders">
  public class VoidBinder1st< _A >
  {
    public delegate void ExposedFunctionDelegate( );
    public delegate void BoundFunctionDelegate( _A argA );

    private BoundFunctionDelegate _pfn;
    private _A _argA;

    public VoidBinder1st( BoundFunctionDelegate pfn, _A argA )
    {
      _pfn = pfn;
      _argA = argA;
    }

    public void ExposedFunction( )
    {
      _pfn( _argA );
    }
  }
  
  /// <summary>Generic Adapter class that allows you to adapt a function that takes 2 parameters to an event/delegate that takes one parameters and supplying the 2nd parameter at construction time</sumamry>
  /// <seealso cref="Sage.Utilities.Binders">  
  public class Binder2nd< _RET, _A, _B >
  {
    public delegate _RET ExposedFunctionDelegate( _A argA );
    public delegate _RET BoundFunctionDelegate( _A argA, _B argB );      
    
    private BoundFunctionDelegate _pfn;
    private _B                    _argB;
    
    public Binder2nd( BoundFunctionDelegate pfn, _B argB )
    {
      _pfn = pfn;
      _argB = argB;
    }
    
    public _RET ExposedFunction( _A argA )
    {
      return _pfn( argA, _argB );
    }
  }

  /// <summary>Generic Adapter class that allows you to adapt a function that takes 3 parameters to an event/delegate that takes two parameters and supplying the 3rd parameter at construction time</sumamry>
  /// <seealso cref="Sage.Utilities.Binders">
  public class VoidBinder2nd<_A, _B>
  {
	  public delegate void ExposedFunctionDelegate( _A argA );
	  public delegate void BoundFunctionDelegate( _A argA, _B argB );

	  private BoundFunctionDelegate _pfn;
	  private _B _argB;

	  public VoidBinder2nd( BoundFunctionDelegate pfn, _B argB )
	  {
		  _pfn = pfn;
		  _argB = argB;
	  }

	  public void ExposedFunction( _A argA )
	  {
		  _pfn( argA, _argB );
	  }
  }

  /// <summary>Generic Adapter class that allows you to adapt a function that takes 2 parameters to an event/delegate that takes no parameters and supplying the 1st and 2nd parameter at construction time</sumamry>
  /// <seealso cref="Sage.Utilities.Binders">
  public class VoidBinder2nd_X<_A, _B>
  {
	  public delegate void ExposedFunctionDelegate();
	  public delegate void BoundFunctionDelegate( _A argA, _B argB );

	  private BoundFunctionDelegate _pfn;
	  private _A _argA;
	  private _B _argB;

	  public VoidBinder2nd_X( BoundFunctionDelegate pfn, _A argA, _B argB )
	  {
		  _pfn = pfn;
		  _argA = argA;
		  _argB = argB;
	  }

	  public void ExposedFunction()
	  {
		  _pfn( _argA, _argB );
	  }
  }
	  
  /// <summary>Generic Adapter class that allows you to adapt a function that takes 3 parameters to an event/delegate that takes two parameters and supplying the 3rd parameter at construction time</sumamry>
  /// <seealso cref="Sage.Utilities.Binders">  
  public class Binder3rd< _RET, _A, _B, _C >
  {
    public delegate _RET ExposedFunctionDelegate( _A argA, _B argB );
    public delegate _RET BoundFunctionDelegate( _A argA, _B argB, _C argC );      
    
    private BoundFunctionDelegate _pfn;
    private _C                    _argC;
    
    public Binder3rd( BoundFunctionDelegate pfn, _C argC )
    {
      _pfn = pfn;
      _argC = argC;
    }
    
    public _RET ExposedFunction( _A argA, _B argB )
    {
      return _pfn( argA, argB, _argC );
    }
  }  

  /// <summary>Generic Adapter class that allows you to adapt a function that takes 3 parameters to an event/delegate that takes two parameters and supplying the 3rd parameter at construction time</sumamry>
  /// <seealso cref="Sage.Utilities.Binders">
  public class VoidBinder3rd< _A, _B, _C >
  {
    public delegate void ExposedFunctionDelegate( _A argA, _B argB );
    public delegate void BoundFunctionDelegate( _A argA, _B argB, _C argC );      
    
    private BoundFunctionDelegate _pfn;
    private _C                    _argC;
    
    public VoidBinder3rd( BoundFunctionDelegate pfn, _C argC )
    {
      _pfn = pfn;
      _argC = argC;
    }
    
    public void ExposedFunction( _A argA, _B argB )
    {
      _pfn( argA, argB, _argC );
    }
  }

  /// <summary>Generic Adapter class that allows you to adapt a function that takes no parameters to an event/delegate that takes two parameters</sumamry>
  /// <seealso cref="Sage.Utilities.Binders">
  public class VoidDebinder1st2nd< _A, _B >
  {
    public delegate void ExposedFunctionDelegate( _A argA, _B argB );
    public delegate void   BoundFunctionDelegate( );      
    
    private BoundFunctionDelegate _pfn;
    
    public VoidDebinder1st2nd( BoundFunctionDelegate pfn )
    {
      _pfn = pfn;
    }
    
    public void ExposedFunction( _A argA, _B argB )
    {
      _pfn( );
    }
  }    
  
  /// <summary>Generic Adapter class that allows you to adapt a function that takes no parameters to an event/delegate that takes two parameters</sumamry>
  /// <seealso cref="Sage.Utilities.Binders">
  public class VoidDebinder1st2nd< _A, _B, _C >
  {
    public delegate void ExposedFunctionDelegate( _A argA, _B argB );
    public delegate _C   BoundFunctionDelegate( );      
    
    private BoundFunctionDelegate _pfn;
    
    public VoidDebinder1st2nd( BoundFunctionDelegate pfn )
    {
      _pfn = pfn;
    }
    
    public void ExposedFunction( _A argA, _B argB )
    {
      _pfn( );
    }
  }  
}
