using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Channels;
using Sage.ExtensionMethods;
using Sage.Diagnostics;

namespace Sage.ServiceModel
{
    /// <summary>
    /// Helper class used to implement a concrete subscription service for a specific callback interface
    /// </summary>
    /// <typeparam name="TCallbackInterface"></typeparam>
    [BindingRequirement(TransactionFlowEnabled = true)]
    public abstract class SubscriptionManager<TCallbackInterface>
        where TCallbackInterface : class
    {
        static SubscriptionManager()
        {
            _subscribers = new Dictionary<String, List<TCallbackInterface>>();
            String[] methods = GetOperations();
            Action<String> insert = (methodName) =>
            {
                _subscribers.Add(methodName, new List<TCallbackInterface>());
            };
            methods.ForEach(insert);
        }

        /// <summary>
        /// Initiate the duplex communication with the subscription service. A conversation with the service must begin with this method call.
        /// </summary>
        public void Connect()
        { }

        /// <summary>
        /// Subscribes the caller to the specific event named.  Use String.Empty or null to subscribe to all operations in the callback contract.
        /// </summary>
        /// <remarks>
        /// Note that the caller can subscribe to all events and then unsubscribe from a particular one.
        /// </remarks>
        /// <param name="eventOperation"></param>
        public void Subscribe(String eventOperation)
        {
            try
            {
                lock (_syncRoot)
                {
                    TCallbackInterface subscriber = OperationContext.Current.GetCallbackChannel<TCallbackInterface>();
                    if (String.IsNullOrEmpty(eventOperation) == false)
                    {
                        AddSubscriber(subscriber, eventOperation);
                    }
                    else
                    {
                        String[] methods = GetOperations();
                        Action<String> addTransient = (methodName) =>
                        {
                            AddSubscriber(subscriber, methodName);
                        };
                        methods.ForEach(addTransient);
                    }
                }
            }
            catch (Exception ex)
            {
                // don't let any unintended exception escape the WCF service boundary; should use explicit FaultContract
                // to send error to client
                ErrorTrace.WriteException(this, ex);
            }
        }

        /// <summary>
        /// Simple keep-alive operation
        /// </summary>
        public void KeepAlive()
        { }

        /// <summary>
        /// Unsubscribes the caller from the specific event named.  Use String.Empty or null to unsubscribe to all operations in the callback contract.
        /// </summary>
        /// <param name="eventOperation"></param>
        public void Unsubscribe(String eventOperation)
        {
            try
            {
                lock (_syncRoot)
                {
                    TCallbackInterface subscriber = OperationContext.Current.GetCallbackChannel<TCallbackInterface>();
                    if (String.IsNullOrEmpty(eventOperation) == false)
                    {
                        RemoveSubscriber(subscriber, eventOperation);
                    }
                    else
                    {
                        String[] methods = GetOperations();
                        Action<String> removeTransient = (methodName) =>
                        {
                            RemoveSubscriber(subscriber, methodName);
                        };
                        methods.ForEach(removeTransient);
                    }
                }
            }
            catch (Exception ex)
            {
                // don't let any unintended exception escape the WCF service boundary; should use explicit FaultContract
                // to send error to client
                ErrorTrace.WriteException(this, ex);
            }
        }

        /// <summary>
        /// Terminate the duplex communication with the subscription service. A conversation with the service should end with this method call.
        /// </summary>
        public void Disconnect()
        {
            Unsubscribe(null);
        }

        internal static TCallbackInterface[] GetSubscriberList(String eventOperation)
        {
            lock (_syncRoot)
            {
                Debug.Assert(_subscribers.ContainsKey(eventOperation));
                if (_subscribers.ContainsKey(eventOperation))
                {
                    List<TCallbackInterface> list = _subscribers[eventOperation];
                    RemoveDeadSubscribers(list);
                    return list.ToArray();
                }
                return new TCallbackInterface[] { };
            }
        }

        private static String[] GetOperations()
        {
            MethodInfo[] methods = typeof(TCallbackInterface).GetMethods(BindingFlags.Public | BindingFlags.FlattenHierarchy | BindingFlags.Instance);
            List<String> operations = new List<String>(methods.Length);

            Action<MethodInfo> add = (method) =>
            {
                Debug.Assert(!operations.Contains(method.Name));
                operations.Add(method.Name);
            };
            methods.ForEach(add);
            return operations.ToArray();
        }

        private static void RemoveDeadSubscribers(List<TCallbackInterface> list)
        {
            List<TCallbackInterface> subscribersToRemove = new List<TCallbackInterface>();
            foreach (TCallbackInterface t in list)
            {
                if (((ICommunicationObject)t).State != CommunicationState.Opened)
                {
                    subscribersToRemove.Add(t);
                }
            }

            foreach (TCallbackInterface t in subscribersToRemove)
            {
                list.Remove(t);
            }
        }

        private static void AddSubscriber(TCallbackInterface subscriber, String eventOperation)
        {
            lock (_syncRoot)
            {
                List<TCallbackInterface> list = _subscribers[eventOperation];
                if (!list.Contains(subscriber))
                {
                    list.Add(subscriber);
                }
            }
        }

        private static void RemoveSubscriber(TCallbackInterface subscriber, String eventOperation)
        {
            lock (_syncRoot)
            {
                List<TCallbackInterface> list = _subscribers[eventOperation];
                if (list.Contains(subscriber))
                {
                    list.Remove(subscriber);
                }
            }
        }

        private static readonly Object _syncRoot = new Object();
        private static Dictionary<String, List<TCallbackInterface>> _subscribers;
    }
}