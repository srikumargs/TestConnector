using System;
using System.Runtime.InteropServices;

namespace Sage.Diagnostics
{


   /// <summary>
   /// Specifies the runtime requirements of an assembly
   /// </summary>
   /// <remarks>
   /// These values can be uses in bitwise combinations
   /// </remarks>
   [ Serializable, Flags ]
   public enum AssemblyRequirements
   {
      /// <summary>
      /// No specific requirements
      /// </summary>
      None = 0 /*0x0000*/, 

      /// <summary>
      /// This assembly must be added to the Global Assembly Cache
      /// </summary>
      MustBeInGAC = 1 /*0x0001*/, 

      /// <summary>
      /// This assembly must be registered for COM interop.
      /// </summary>
      /// <remarks>
      /// <para>When registering for COM, the codebase flag should always be used</para>
      /// <para>A type library should also both exist and be registered for this assembly</para>
      /// </remarks>
      MustBeRegisteredForCOM = 2 /*0x0002*/ 

   }

   /// <summary>
   /// Specifies the build configuration of an asembly
   /// </summary>
   [ Serializable ]
   public enum AssemblyConfiguration
   {
      /// <summary>
      /// Debug build of the assembly
      /// </summary>
      Debug,

      /// <summary>
      /// This assembly must be added to the Global Assembly Cache
      /// </summary>
      Release = 1 

   }


	/// <summary>
	/// This attribute can be applied to assemblies to indicate their current configuration or runtime requirments
	/// </summary>
   [ AttributeUsage( AttributeTargets.Assembly ) ]
   [ ComVisible( false ) ]
	public sealed class AssemblyConfigurationAttribute: Attribute
	{
      #region Fields

      /// <summary>
      /// One or more flags that indicate the runtime requirements of the assembly
      /// </summary>
      private readonly AssemblyRequirements _flags = AssemblyRequirements.None;

      /// <summary>
      /// Specifies the current build configuraation of the assembly
      /// </summary>
      private readonly AssemblyConfiguration _configuration = AssemblyConfiguration.Release;

      #endregion

      /// <summary>
      /// Default Constructor
      /// </summary>
      /// <remarks>Use this constructor if you have no specific runtime requirments</remarks>
      public AssemblyConfigurationAttribute()
      {
#if DEBUG
         _configuration = AssemblyConfiguration.Debug;
#else
         _configuration = AssemblyConfiguration.Release;
#endif
      }

      /// <summary>
      /// Constructor
      /// </summary>
      /// <param name="flags">Bitwise concatinate flags to specify the assemblies runtime requirements</param>
		public AssemblyConfigurationAttribute( AssemblyRequirements flags )
		{
		   _flags = flags;
#if DEBUG
         _configuration = AssemblyConfiguration.Debug;
#else
         _configuration = AssemblyConfiguration.Release;
#endif
		}

      /// <summary>
      /// Retrieve the assemblies build configuration
      /// </summary>
      public AssemblyConfiguration Configuration
      {
         get{ return _configuration; }
      }

      /// <summary>
      /// Retrieve the runtime requirements
      /// </summary>
      public AssemblyRequirements Requirements
      {
         get{ return _flags; }
      }
	}
}
