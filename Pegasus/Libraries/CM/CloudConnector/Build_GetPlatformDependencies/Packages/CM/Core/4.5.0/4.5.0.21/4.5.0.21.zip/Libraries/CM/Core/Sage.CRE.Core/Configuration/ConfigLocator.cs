using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using Sage.Diagnostics;

namespace Sage.Configuration
{
	/// <summary>
	/// Summary description for ConfigLocator.
	/// </summary>
	public class ConfigLocator
	{
        // The base path where application config files are located
        private static string _baseConfigPath = null;

        // The base path where any version Independent config files are located
        private static string _baseVersionIndependentPath = null;

        // The folder the application is located in.
        private static string _applicationFolder = null;

		// The folder for the Application resources
		private static string _resourceFolder = null;

		private static bool _probingPathInitialized = false;

		// The applications current Language ID
		private static int _langId = 1033;

		static ConfigLocator()
		{
			_applicationFolder = null;
		}

        /// <summary>
        /// Set/Get the base path where application config files are located
        /// </summary>
        public static string BaseConfigPath
        {
            get
			{ 
				return _baseConfigPath; 
			}
            set
			{ 
				_baseConfigPath = value; 
			}
        }

        /// <summary>
        /// Set/Get the base path where any version Independent config files are located
        /// </summary>
        public static string BaseVersionIndependentPath
        {
            get
			{ 
				return _baseVersionIndependentPath; 
			}
            set
			{ 
				_baseVersionIndependentPath = value; 
			}
        }

        /// <summary>
        /// Get/Set the folder the application is located in
        /// </summary>
        public static string ApplicationFolder
        {
            get
			{ 
				return _applicationFolder; 
			}
            set
			{
				_applicationFolder = PathRegistrar.ResolveUrl( value );
				Assertions.Assert( Directory.Exists( _applicationFolder ) );
			}
        }

		/// <summary>
		/// Get/Set the folder containing application resources
		/// </summary>
		public static string ResourceFolder
		{
			get
			{ 
				string retval = null;
				if( _resourceFolder != null )
				{
					retval = _resourceFolder;
				}
				else
				{
					retval = _applicationFolder;
				}

				Assertions.Assert( retval != null );
				return retval;
			}
			set
			{ 
				_resourceFolder = PathRegistrar.ResolveUrl( value ); 
				UpdateAssemblyProbingPath();
			}
		}

		/// <summary>
		/// Determine the appropriate configuration folder to use for the application
		/// </summary>
		/// <returns>Full path the the application configuration file</returns>
		public static string ConfigurationFolder
		{
			get
			{
				string retval = null;
				string configurationFolder = Path.Combine( ResourceFolder, "Configuration");
				DirectoryInfo info = new DirectoryInfo( configurationFolder );
				if( info.GetDirectories().Length == 2 )
				{
					foreach( DirectoryInfo subfolder in info.GetDirectories() )
					{
						if( string.Compare( subfolder.Name, "Default", true ) != 0 )
						{
							retval = Path.Combine( configurationFolder, subfolder.Name );
							break;
						} 
					}
				}
				else
				{
					retval = Path.Combine( configurationFolder, "Default" );
				}

				return  retval;
			}

		}

		/// <summary>
		/// Get/Set the applications language identifier
		/// </summary>
		public static int LangId
		{
			set{ _langId = value; }
			get{ return _langId; }
		}

		/// <summary>
		/// Update the assembly probing path to locate assemblies in the Resource folder
		/// </summary>
		private static void UpdateAssemblyProbingPath()
		{
			if( !_probingPathInitialized && Directory.Exists( _resourceFolder ) )
			{
				_probingPathInitialized = true;
				AppDomain.CurrentDomain.AssemblyResolve +=new ResolveEventHandler(ResolveAssembly); 
			}
		}

        /// <summary>
        /// Hide the instance constructor
        /// </summary>
		private ConfigLocator(){}

		/// <summary>
		/// Attempt to resolve an assembly from the resource folder
		/// </summary>
		/// <returns>The requested assembly or null</returns>
		private static Assembly ResolveAssembly(object sender, ResolveEventArgs args)
		{
			Assembly retval = null;
			string fullName = Path.Combine( _resourceFolder, args.Name );
			if( File.Exists( fullName ) )
			{
				retval = Assembly.LoadFile( fullName );
			}
			return retval;
		}
	}
}
