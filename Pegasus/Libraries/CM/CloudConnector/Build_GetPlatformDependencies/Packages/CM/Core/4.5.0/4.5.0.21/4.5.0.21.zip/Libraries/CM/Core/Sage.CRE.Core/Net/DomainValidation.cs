using System;
using System.DirectoryServices;

namespace Sage.Net
{
    /// <summary>
    /// Summary description for DomainValidation.
    /// </summary>
    public class DomainValidation
      : IDomainValidation
    {
        /// <summary>
        /// ctor
        /// </summary>
        public DomainValidation()
        {
        }

        /// <summary>
        /// Checks to see if the specified domain exists on the network
        /// </summary>
        /// <param name="domainName">name of the domain </param>
        /// <returns>true if the domain was found</returns>
        public bool Validate(string domainName)
        {
            bool bValid = false;

            try
            {
                /* this method (and others similar to it) did not correctly validate domains
                string str = @"WinNT://" + domainName + ",domain";
                DirectoryEntry de = new DirectoryEntry( str );
                string s = de.Name;  // this will trigger an exception for non-existent domains
                */

                // get a collection of domains
                IDomainCollection domains = new DomainCollection();
                domains.Populate();

                // iterate the collection to check for existence
                foreach (IDomain d in domains)
                {
                    if (d.Name.CompareTo(domainName) == 0)
                    {
                        bValid = true;
                        break;
                    }
                }
            }
            catch (Exception /* ex */ )
            {
                bValid = false;
            }
            finally
            {
                string strTemp = (bValid) ? "" : "not ";
                ErrorMessage = string.Format("{0} was {1}found on the network.", domainName, strTemp);
            }

            return bValid;
        }

        private string errorMessage = string.Empty;
        /// <summary>
        /// The error message string for a validation failure
        /// </summary>
        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }

    }
}
