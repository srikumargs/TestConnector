using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using Sage.Diagnostics;
using System.Text;

namespace Sage.ExtensionMethods
{
    public static class CollectionExtensions
    {
        public static void ForEach<T>(this IEnumerable<T> collection, Action<T> action)
        {
            ArgumentValidator.ValidateNonNullReference(collection, "collection", "CollectionExtensions.ForEach<>");
            ArgumentValidator.ValidateNonNullReference(action, "action", "CollectionExtensions.ForEach<>");
            foreach (T item in collection)
            {
                action(item);
            }
        }

        public static IEnumerable<U> ConvertAll<T, U>(this IEnumerable<T> collection, Converter<T, U> converter)
        {
            ArgumentValidator.ValidateNonNullReference(collection, "collection", "CollectionExtensions.ConvertAll<>");
            ArgumentValidator.ValidateNonNullReference(converter, "converter", "CollectionExtensions.ConvertAll<>");
            foreach (T item in collection)
            {
                yield return converter(item);
            }
        }

        public static IEnumerable<T> Complement<T>(this IEnumerable<T> collection1, IEnumerable<T> collection2)
        {
            ArgumentValidator.ValidateNonNullReference(collection1, "collection1", "CollectionExtensions.Complement<>");
            ArgumentValidator.ValidateNonNullReference(collection2, "collection2", "CollectionExtensions.Complement<>");
            foreach (T item in collection1)
            {
                if (collection2.Contains(item) == false)
                {
                    yield return item;
                }
            }
        }

        public static IEnumerable<T> Except<T>(IEnumerable<T> collection1, IEnumerable<T> collection2) where T : IEquatable<T>
        {
            IEnumerable<T> complement1 = Complement(collection1, collection2);
            IEnumerable<T> complement2 = Complement(collection2, collection1);
            return complement1.Union(complement2);
        }

        public static IEnumerable<T> Sort<T>(this IEnumerable<T> collection)
        {
            ArgumentValidator.ValidateNonNullReference(collection, "collection", "CollectionExtensions.Sort<>");
            List<T> list = new List<T>(collection);
            list.Sort();

            foreach (T item in list)
            {
                yield return item;
            }
        }

        public static IEnumerable<T> Sort<T>(this IEnumerable<T> collection, Comparison<T> comparison)
        {
            ArgumentValidator.ValidateNonNullReference(collection, "collection", "CollectionExtensions.Sort<>");
            List<T> list = new List<T>(collection);
            list.Sort(comparison);

            foreach (T item in list)
            {
                yield return item;
            }
        }

        public static IEnumerable<T> Sort<T>(this IEnumerable<T> collection, IComparer<T> comparer)
        {
            ArgumentValidator.ValidateNonNullReference(collection, "collection", "CollectionExtensions.Sort<>");
            List<T> list = new List<T>(collection);
            list.Sort(comparer);

            foreach (T item in list)
            {
                yield return item;
            }
        }

        public static int FindIndex<T>(this IEnumerable<T> collection, T value) where T : IEquatable<T>
        {
            ArgumentValidator.ValidateNonNullReference(collection, "collection", "CollectionExtensions.FindIndex<>");
            using (IEnumerator<T> iterator = collection.GetEnumerator())
            {
                int index = 0;

                while (iterator.MoveNext())
                {
                    if (iterator.Current.Equals(value) == false)
                    {
                        index++;
                    }
                    else
                    {
                        return index;
                    }
                }
                return -1;
            }
        }

        public static String AsStringRepresentation<T>(this IEnumerable<T> collection)
        {
            StringBuilder b = new StringBuilder();
            b.Append("[");
            if (collection != null)
            {
                Int32 count = collection.Count();
                for (Int32 i = 0; i < count; i++)
                {
                    b.Append(collection.ElementAt(i).ToString());

                    // append a ", " if there is going to be at least one more element
                    if (i < (count - 1))
                    {
                        b.Append(", ");
                    }
                }
            }
            b.Append("]");
            return b.ToString();
        }

        public static U[] UnsafeToArray<T, U>(this IEnumerable collection, Converter<T, U> converter)
        {
            ArgumentValidator.ValidateNonNullReference(collection, "collection", "CollectionExtensions.UnsafeToArray<>");
            ArgumentValidator.ValidateNonNullReference(converter, "converter", "CollectionExtensions.UnsafeToArray<>");
            return collection.UnsafeToArray<T>().ConvertAll(converter);
        }

        public static T[] UnsafeToArray<T>(this IEnumerable collection)
        {
            ArgumentValidator.ValidateNonNullReference(collection, "collection", "CollectionExtensions.UnsafeToArray<>");
            return CollectionExtensions.UnsafeToArray<T>(collection);
        }
    }
}