using System;
using System.Configuration;
using System.Xml;

namespace Sage.Diagnostics
{
    /// <summary>
    /// A configuration section handler for Sage.Diagnostics.LogWriterTraceListener and 
    /// Sage.Diagnostics.DebugOutputWriterTraceListener.
    /// </summary>
    /// <remarks>
    /// This class creates the custom ConfigSectionData object which handles data reloading when the
    /// config file changes during runtime.
    /// </remarks>
    public sealed class ConfigurationSectionHandler : IConfigurationSectionHandler
    {
        #region Public members
        /// <summary>
        /// Parse the XML of the configuration section.  The returned object is added to the configuration collection and is accessed by GetConfig.
        /// </summary>
        /// <param name="parent">The configuration settings in a corresponding parent configuration section. </param>
        /// <param name="configContext">An HttpConfigurationContext when Create is called from the ASP.NET configuration system. Otherwise, this parameter is reserved and is a null reference (Nothing in Visual Basic). </param>
        /// <param name="section">The XmlNode that contains the configuration information from the configuration file. Provides direct access to the XML contents of the configuration section. </param>
        /// <returns>A configuration object.</returns>
        public object Create(object parent, object configContext, XmlNode section)
        {
            return new ConfigSectionData(section);
        }
        #endregion
    }
}