﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Sage.ServiceModel
{
    /// <summary>
    /// Provides a mechanism for doing progressive fallback (typicaly during retry operations)
    /// </summary>
    public sealed class ProgressiveBackoffHelper
    {
        /// <summary>
        /// Initializes a new instance of the ProgressiveBackoffHelper class. 
        /// </summary>
        public ProgressiveBackoffHelper()
        { Reset(); }

        /// <summary>
        /// reset the helper so that a new of series of DelayIfNeeded() calls can be attempted
        /// </summary>
        public void Reset()
        {
            _retryCount = 0;
            _startDateTime = DateTime.UtcNow;
        }

        /// <summary>
        /// The amount of time that has elapsed since last Reset
        /// </summary>
        public TimeSpan ElapsedTime
        { get { return (DateTime.UtcNow - _startDateTime); } }

        /// <summary>
        /// Provide progressive fallback intended for client-side retry logic.
        /// </summary>
        /// <param name="timeout"></param>
        /// <remarks>
        /// Delay a time related to the retry count with a progressively longer delay, or the remaining time until timeout
        /// </remarks>
        public void DelayIfNeeded(double timeout)
        {
            // don't introduce any delay the first time in ... optomistically assume the operation will work
            if (_retryCount > 0)
            {
                // find the proposed sleep time
                Int32 backoffInterval = ChooseBackoffInterval();

                // compute the sleep time to use; find the time until time out, if the time is not greater then zero, we are out of time.
                Int32 timeUntilTimeout = ComputeRemainingTimeUntilTimeout(timeout);

                // we need to limit the actual timeToSleep used by the time remaining until timeout. 
                Int32 timeToSleep = Math.Min(backoffInterval, timeUntilTimeout);

                // now actually do sleep
                Thread.Sleep(timeToSleep);
            }

            _retryCount++;
        }

        /// <summary>
        /// Compute proposed wait before retry based on the retry count, using truncated exponential back off
        /// </summary>
        /// <remarks>
        /// <returns>Proposed wait before retry.</returns>
        /// Retry counts of zero or less will result in a zero.
        /// Designed to not throw an exception except in case of catastrophic issue, such as out of memory etc.
        /// </remarks>
        private Int32 ChooseBackoffInterval()
        {
            Int32 result = 0;

            if (_retryCount > 0)
            {
                //setup a random object if needed. Must not use Int32.MinValue to seed it, or will get an exception.
                //If we got that value try again...
                if (_random == null)
                {
                    Int32 ticks;
                    do
                    {
                        ticks = (Int32)DateTime.UtcNow.Ticks;
                    } while (ticks == Int32.MinValue);
                    _random = new Random(ticks);
                }

                // now find the proposed retry time.
                // limit maxRetryToUse to low 5 bits, to line up with what left shift will use.
                Int32 maxRetryToUse = TRUNCATE_AT_RETRY_COUNT & 0x001F;
                Int32 powerOfTwoToUse = Math.Min(_retryCount, maxRetryToUse);
                Int32 maxRetryTime = 1 << powerOfTwoToUse;
                result = _random.Next(maxRetryTime);
            }

            return result;
        }

        private Int32 ComputeRemainingTimeUntilTimeout(double timeout)
        {
            TimeSpan elapsedTime = ElapsedTime;
            TimeSpan timeOutInterval = TimeSpan.FromMilliseconds(timeout);
            Int32 result = (Int32)(timeOutInterval - elapsedTime).TotalMilliseconds;
            return Math.Max(result, 0);
        }

        // Random for use by ChooseBackoffInterval. If use is thread safe may want to make this static.
        private Random _random;

        // Used to truncate/limit the upper bound of the back off. Bounded at 0 and 31 inclusive.
        // Low 5 bits used, others ignored.
        // (limit retry to 11, resulting in up to 2 seconds of delay max roughly.)
        private const Int32 TRUNCATE_AT_RETRY_COUNT = 11;

        // tracks time since last Reset() (used to compute whether timeout has elapsed
        private DateTime _startDateTime;

        // retry count, max delay is exponential based on retry count
        private Int32 _retryCount;
    }
}
