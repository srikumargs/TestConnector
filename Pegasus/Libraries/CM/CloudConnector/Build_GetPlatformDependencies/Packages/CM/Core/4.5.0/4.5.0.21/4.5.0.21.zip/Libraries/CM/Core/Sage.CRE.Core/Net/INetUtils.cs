using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Sage.Net
{
    /// <summary>
    /// Defines a COM callable interface for various network related utilities.
    /// </summary>
    [ComVisible(false)]
    public interface INetUtils
    {
        /// <summary>
        /// Test the specified address to determine whether it's remote or not.
        /// </summary>
        /// <param name="address">The address to test. This can be an IP address, a hostname, or even a UNC path.</param>
        /// <returns>Returns true if the address is remote; otherwise, false.</returns>
        bool IsRemoteAddress(string address);

        /// <summary>
        /// Parse the IP address and determine if it's the loopback device.
        /// </summary>
        /// <param name="address">The IP address to test.</param>
        /// <returns>Returns true if the IP address is the loopback device; otherwise, false.</returns>
        bool IsLoopbackAddress(string address);

        /// <summary>
        /// Test the specified string to determine if it's a valid IP address.
        /// </summary>
        /// <param name="address">The IP address to test.</param>
        /// <returns>Returns true if it's a valid IP address; otherwise, false.</returns>
        bool IsIPAddress(string address);
    }
}
