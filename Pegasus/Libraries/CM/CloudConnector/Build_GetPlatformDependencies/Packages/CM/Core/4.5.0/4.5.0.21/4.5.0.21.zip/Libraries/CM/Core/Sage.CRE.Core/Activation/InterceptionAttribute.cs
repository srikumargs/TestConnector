using System;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Activation;
using System.Reflection;
using System.Security.Permissions;

namespace Sage.Interception
{
    /// ***************************************************
    /// <summary>
    /// Marks a class as using interception
    /// </summary>
    /// ***************************************************
    [ ComVisible( false ) ]
    [ AttributeUsage( AttributeTargets.Class ) ]
    public abstract class InterceptionAttribute : ContextAttribute
    {
        /// ***************************************************
        /// <summary>
        /// Default Constructor.
        /// </summary>
        /// ***************************************************
        protected InterceptionAttribute(string name) : base(name) {}

        /// ***************************************************
        /// <summary>
        /// Derived class needs to create the ContextProperty
        /// </summary>
        /// ***************************************************
        protected abstract IContextProperty ContextProperty
        {
            get;
        }

        /// *************************************************
        /// <summary>
        /// This is how we inject ourselves into the new call 
        /// context message sink chain
        /// </summary>
        /// <param name="msg">T</param>
        /// **************************************************
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.Infrastructure)]
        public override void GetPropertiesForNewContext(IConstructionCallMessage msg)
        {
            //msg.ContextProperties.Add(Interceptor.CreateInterceptor("FieldChangeAspect"));
            msg.ContextProperties.Add(ContextProperty);
        }
    }
}
