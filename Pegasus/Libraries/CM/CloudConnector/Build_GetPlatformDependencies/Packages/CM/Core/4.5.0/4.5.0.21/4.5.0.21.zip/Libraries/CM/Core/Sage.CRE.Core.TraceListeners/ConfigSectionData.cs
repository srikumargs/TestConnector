using System;
using System.Xml;
using System.Diagnostics;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
using System.Collections;

namespace Sage.Diagnostics
{
    /// <summary>
    /// 
    /// </summary>
    /// <remarks>
    /// Normally, any change to our configuration settings requires that the application be stopped and restarted.
    /// We can overcome this by adding a bit of extra functionality to our custom section handler.  It is possible
    /// to create a custom section handler that detects when the config file is changed.  If this happens, we can
    /// refresh our settings values by re-reading the custom section from the file.
    /// 
    /// Note that we cannot change the behavior of the existing .NET section handlers.  This means that any use of
    /// sections such as &gt;appSettings&lt; or &gt;system.runtime.remoting&lt; will not be affected.  However, we
    /// can make our own custom sections refresh automatically when the underlying configuration file is changed.
    /// 
    /// The secret lies in the fact that the .NET Framework caches the object returned from the Create method of
    /// our section handler.  In our ConfigurationSectionHandler, we parsed the XML in the handler and
    /// then used the data to load the ConfigSectionData object.  Once the ConfigSectionData object
    /// was loaded with data, the data became static and unchanging.
    /// 
    /// To support automatic updating of the data, the XML parsing code is relocated into the data object itself.
    /// Since it is the data object that is cached by the .NET Framework, it is the only object that remains in
    /// memory.  If the data object itself parses the XML, then it can also detect when the underlying file is
    /// changed and can re-read the XML if needed.
    /// </remarks>
    internal sealed class ConfigSectionData
    {
        #region Constructors
        public ConfigSectionData(XmlNode section)
        {
            _ignoreStackTraceTypeNames = new System.Collections.ArrayList();

            try
            {
                ParseXml(section);
            }
            catch(Exception)
            {
                // In order to avoid an infinite recursion situation, LoadConfig should NOT do anything that would
                // cause itself to get called recursively ... this includes writing to the Trace.
                //ErrorTrace.WriteLine(e.Message);
#if DEBUG
                // log an event instead (but only do it in DEBUG configuration).  As this is all stuff to support
                // debug output, fail silently in release mode
                EventLogger.WriteMessage("Sage.CRE.Core.TraceListeners", string.Format(CultureInfo.InvariantCulture, "Failed to parse config data in: '{0}'", AppDomain.CurrentDomain.SetupInformation.ConfigurationFile), MessageType.Error, false);
#endif
            }
            finally
            {
                // regardless of whether or not we successfully loaded the expected configuration file data we 
                // set our state to "loaded" so we don't attempt to do it again (unless the FileSystemWatcher
                // detects another change)
                _configLoaded = true;
            }
            
            SetupFileWatcher();
        }
        #endregion

        #region Public properties
        /// <summary>
        /// Indicates whether date information should be shown.
        /// </summary>
        public bool ShowDate
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }

                return _showDate;
            }
        }

        /// <summary>
        /// Indicates whether time information should be shown.
        /// </summary>
        public bool ShowTime
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }

                return _showTime;
            }
        }

        /// <summary>
        /// Indicates whether time milliseconds information should be shown.
        /// </summary>
        /// <remarks>
        /// This property has no effect unless ShowTime is true.
        /// </remarks>
        public bool ShowMilliseconds
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }

                return _showMilliseconds;
            }
        }

        /// <summary>
        /// Indicates whether time should be shown in 24-hour format.
        /// </summary>
        /// <remarks>
        /// This property has no effect unless ShowTime is true.
        /// </remarks>
        public bool Show24Hour
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }

                return _show24Hour;
            }
        }

        /// <summary>
        /// Indicates whether process ID should be shown.
        /// </summary>
        public bool ShowProcessId
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }

                return _showProcessId;
            }
        }

        /// <summary>
        /// Indicates whether thread ID should be shown.
        /// </summary>
        public bool ShowThreadId
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }

                return _showThreadId;
            }
        }

        /// <summary>
        /// Indicates whether object ID should be shown.
        /// </summary>
        public bool ShowObjectId
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }

                return _showObjectId;
            }
        }

        /// <summary>
        /// Indicates whether the message category should be shown.
        /// </summary>
        public bool ShowMessageCategory
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }
            
                return _showMessageCategory;
            }
        }

        /// <summary>
        /// Indicates whether the trace caller's type should be shown.
        /// </summary>
        public bool ShowTypeName
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }
            
                return _showTypeName;
            }
        }

        /// <summary>
        /// Indicates whether the trace caller's member context should be shown.
        /// </summary>
        public bool ShowMemberName
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }
            
                return _showMemberName;
            }
        }

        /// <summary>
        /// Indicates whether the parameter signature of the trace caller's member context should be shown.
        /// </summary>
        /// <remarks>
        /// This property has no effect unless ShowMemberName is true.
        /// </remarks>
        public bool ShowMemberSignature
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }
            
                return _showMemberSignature;
            }
        }

        /// <summary>
        /// Indicates whether the assembly name of the trace caller's context should be shown.
        /// </summary>
        public bool ShowAssemblyName
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }
            
                return _showAssemblyName;
            }
        }

        /// <summary>
        /// Indicates whether the file location the trace caller's context should be shown.
        /// </summary>
        public bool ShowFileLocation
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }
            
                return _showFileLocation;
            }
        }

        /// <summary>
        /// Indicates whether the id of the current AppDomain should be shown.
        /// </summary>
        public bool ShowAppDomainId
        {
            get
            {
                if(!_configLoaded)
                {
                    LoadConfig();
                }

                return _showAppDomainId;
            }
        }

        /// <summary>
        /// Indicates whether the specified type name is among those that the StackTrace should ignore.
        /// </summary>
        /// <param name="typeName">the name of the type to test</param>
        /// <returns>true if the StackTrace should ignore this type; otherwise false</returns>
        public bool IsStackTraceIgnoreTypeName(string typeName)
        {
            return _ignoreStackTraceTypeNames.Contains(typeName);
        }

        /// <summary>
        /// 
        /// </summary>
        public ArrayList StackTraceIgnoreTypenames
        { get { return _ignoreStackTraceTypeNames; } }

        #endregion

        #region Private members
        private void ParseXml(XmlNode sectionNode)
        {
            _rootXMLNodeName = (sectionNode as XmlElement).Name;

            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showDate", ref _showDate);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showTime", ref _showTime);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showMilliseconds", ref _showMilliseconds);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "show24Hour", ref _show24Hour);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showProcessId", ref _showProcessId);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showThreadId", ref _showThreadId);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showObjectId", ref _showObjectId);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showMessageCategory", ref _showMessageCategory);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showTypeName", ref _showTypeName);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showMemberName", ref _showMemberName);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showMemberSignature", ref _showMemberSignature);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showAssemblyName", ref _showAssemblyName);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showFileLocation", ref _showFileLocation);
            XmlNodeHelper.GetOptionalBoolAttributeValue(sectionNode, "showAppDomainId", ref _showAppDomainId);

            _ignoreStackTraceTypeNames.Clear();

            // autoamtically exclude the well-known types that should always be ignored
            _ignoreStackTraceTypeNames.Add("System.Diagnostics.Trace");
            _ignoreStackTraceTypeNames.Add("System.Diagnostics.TraceInternal");
            
            // read in the types specified to be ignore in the config file
            XmlNodeList ignoreTypeNodes = sectionNode.SelectNodes("./StackTraceIgnoreTypes/IgnoreType");
            if(null != ignoreTypeNodes)
            {
                foreach(XmlNode ignoreTypeNode in ignoreTypeNodes)
                {
                    _ignoreStackTraceTypeNames.Add(ignoreTypeNode.InnerText);
                }
            }
        }

        private void SetupFileWatcher()
        {
            try
            {
                if(File.Exists(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile))
                {
                    FileInfo configFileInfo = new FileInfo(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);

                    lock(typeof(ConfigSectionData))
                    {
                        if(_configFileWatcher == null)
                        {
                            _configFileWatcher                         = new FileSystemWatcher();
                            _configFileWatcher.Path                    = configFileInfo.DirectoryName;
                            _configFileWatcher.Filter                  = configFileInfo.Name;
                            _configFileWatcher.IncludeSubdirectories   = false;
                            _configFileWatcher.NotifyFilter            = NotifyFilters.LastWrite;
                            _configFileWatcher.InternalBufferSize      = 4096; // For efficiency, set buffer size to the minimum allowed.  Since we have filtered down to a single file we shouldn't need a large buffer.
                            _configFileWatcher.EnableRaisingEvents     = true;
                        }
                        else
                        {
                            Assertions.Assert(_configFileWatcher.Path == configFileInfo.DirectoryName, string.Format(CultureInfo.InvariantCulture, "_configFileWatcher.Path '{0}' != configFileInfo.DirectoryName '{1}'", _configFileWatcher.Path, configFileInfo.DirectoryName));
                            Assertions.Assert(_configFileWatcher.Filter == configFileInfo.Name, string.Format(CultureInfo.InvariantCulture, "_configFileWatcher.Filter '{0}' != configFileInfo.Name '{1}'", _configFileWatcher.Filter, configFileInfo.Name));
                        }
                     
                        _configFileWatcher.Changed += new FileSystemEventHandler(OnChanged);
                    }
                }
            }
            catch(Exception)
            {
                // In order to avoid an infinite recursion situation, SetupFileWatcher should NOT do anything that would
                // cause itself to get called recursively ... this includes writing to the Trace.
                //ErrorTrace.WriteLine(e.Message);
#if DEBUG
                // log an event instead (but only do it in DEBUG configuration).  As this is all stuff to support
                // debug output, fail silently in release mode
                EventLogger.WriteMessage("Sage.CRE.Core.TraceListeners", string.Format(CultureInfo.InvariantCulture, "Failed to setup FileSystemWatcher on config file: '{0}'", AppDomain.CurrentDomain.SetupInformation.ConfigurationFile), MessageType.Error, false);
#endif
            }
        }

        private void OnChanged(object source, FileSystemEventArgs args)
        {
            // The FileSystemWatcher component will often raise several events for a single change to a file.
            // If we re-read the file on each event, we could easily end up re-reading the file several
            // times for a single change to the file.  Instead set isDataValid and check on every property
            // access.
         
            _configLoaded = false;
        }

        private void LoadConfig()
        {
            try
            {
                if(File.Exists(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile))
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);

                    XmlNodeList nodes = doc.GetElementsByTagName(_rootXMLNodeName);
                    if(0 < nodes.Count)
                    {
                        ParseXml(nodes[0]);
                    }
                }
            }
            catch(Exception)
            {
                // In order to avoid an infinite recursion situation, LoadConfig should NOT do anything that would
                // cause itself to get called recursively ... this includes writing to the Trace.
                //ErrorTrace.WriteLine(e.Message);
#if DEBUG
                // log an event instead (but only do it in DEBUG configuration).  As this is all stuff to support
                // debug output, fail silently in release mode
                EventLogger.WriteMessage("Sage.CRE.Core.TraceListeners", string.Format(CultureInfo.InvariantCulture, "Failed to parse config data in: '{0}'", AppDomain.CurrentDomain.SetupInformation.ConfigurationFile), MessageType.Error, false);
#endif
            }
            finally
            {
                // regardless of whether or not we successfully loaded the expected configuration file data we 
                // set our state to "loaded" so we don't attempt to do it again (unless the FileSystemWatcher
                // detects another change)
                _configLoaded = true;
            }
        }
        #endregion

        #region Private fields
        private bool                            _configLoaded;              // = false; (automatically initialized by runtime)
        private bool                            _showDate;                  // = false; (automatically initialized by runtime)
        private bool                            _showTime;                  // = false; (automatically initialized by runtime)
        private bool                            _showMilliseconds;          // = false; (automatically initialized by runtime)
        private bool                            _show24Hour;                // = false; (automatically initialized by runtime)
        private bool                            _showProcessId;             // = false; (automatically initialized by runtime)
        private bool                            _showThreadId;              // = false; (automatically initialized by runtime)
        private bool                            _showObjectId;              // = false; (automatically initialized by runtime)
        private bool                            _showMessageCategory;       // = false; (automatically initialized by runtime)
        private bool                            _showTypeName;              // = false; (automatically initialized by runtime)
        private bool                            _showMemberName;            // = false; (automatically initialized by runtime)
        private bool                            _showMemberSignature;       // = false; (automatically initialized by runtime)
        private bool                            _showAssemblyName;          // = false; (automatically initialized by runtime)
        private bool                            _showFileLocation;          // = false; (automatically initialized by runtime)
        private bool                            _showAppDomainId;           // = false; (automatically initialized by runtime)
        private string                          _rootXMLNodeName;           // = null; (automatically initialized by runtime)
        private System.Collections.ArrayList    _ignoreStackTraceTypeNames; // = null; (automatically initialized by runtime)
        private static FileSystemWatcher        _configFileWatcher;         // = null; (automatically initialized by runtime)
        #endregion
    }
}