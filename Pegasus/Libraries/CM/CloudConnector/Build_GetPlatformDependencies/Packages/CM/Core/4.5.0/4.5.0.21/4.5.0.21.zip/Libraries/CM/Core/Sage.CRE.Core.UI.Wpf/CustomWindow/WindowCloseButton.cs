﻿using System;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace Sage.CRE.Core.UI.Wpf.CustomWindow
{
    public class WindowCloseButton : WindowButton
    {
        Brush _backgroundDefaultValue;

        public override Brush BackgroundDefaultValue
        {
            get { return _backgroundDefaultValue; }
        }

        public WindowCloseButton()
        {
            this.Width = 43;
            
            // open resource where in XAML are defined some required stuff such as icons and colors
            //Stream resourceStream = Application.GetResourceStream(new Uri("pack://application:,,,/Sage.CRE.Core.UI.Wpf;component/ButtonIcons.xaml")).Stream;
            //ResourceDictionary resourceDictionary = (ResourceDictionary)XamlReader.Load(resourceStream);
            Uri resourceLocater =
                new System.Uri("/Sage.CRE.Core.UI.Wpf;component/CustomWindow/ButtonIcons.xaml",
                    UriKind.Relative);
            ResourceDictionary resourceDictionary = (ResourceDictionary)Application.LoadComponent(resourceLocater);


            //
            // Background
            this.Background = (Brush)resourceDictionary["RedButtonBackground"];
            _backgroundDefaultValue = (Brush)resourceDictionary["RedButtonBackground"];
            
            //
            // Foreground (represents a backgroundcolor when Mouse is over)
            this.Foreground = (Brush)resourceDictionary["RedButtonMouseOverBackground"];
            
            // set icon
            this.Content = resourceDictionary["WindowButtonCloseIcon"];

            // radius
            this.CornerRadius = new CornerRadius(0, 0, 3, 0);
        }
    }
}
