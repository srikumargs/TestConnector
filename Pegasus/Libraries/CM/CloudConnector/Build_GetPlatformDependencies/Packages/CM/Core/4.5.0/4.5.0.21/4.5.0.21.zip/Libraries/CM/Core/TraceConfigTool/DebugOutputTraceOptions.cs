using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Xml;

namespace TraceConfigTool
{
    public class DebugOutputTraceOptions : TraceOptions
    {
        public DebugOutputTraceOptions(XmlNode customConfigSection)
            : base(customConfigSection)
        {
            ShowTime = true;
            ShowMessageCategory = true;
        }
    }
}
