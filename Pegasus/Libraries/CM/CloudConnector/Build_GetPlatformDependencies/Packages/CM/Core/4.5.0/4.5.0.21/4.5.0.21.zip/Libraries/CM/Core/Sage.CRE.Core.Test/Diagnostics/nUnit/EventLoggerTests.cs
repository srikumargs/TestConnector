#if DEBUG
using NUnit.Framework;
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Reflection;

namespace Sage.Diagnostics.NUnit
{
	/// <summary>
	/// Class used to test the EventLogger
	/// </summary>
    [TestFixture]
    [ ComVisible( false ) ]
	public class EventLoggerTests
	{

        static EventLoggerTests()
        {
            //Sage.Configuration.LibraryManager.InitializeLibraries(
            //    System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory,
            //        Sage.Configuration.LibraryManager.LibraryManifestFolderName ) );
        }

        /// <summary>
        /// Constructor
        /// </summary>
		public EventLoggerTests()
		{
			
		}

        /// <summary>
        /// Test the write message method on an instance of the Event logger
        /// </summary>
        [Test]
        public void TestWriteMessageInstance()
        {
            IEventLogger log = new EventLogger();
            log.WriteMessage( Assembly.GetExecutingAssembly().GetName().Name, "This is an instance Information test", MessageType.Information );
            log.WriteMessage( Assembly.GetExecutingAssembly().GetName().Name, "This is an instance warning test", MessageType.Warning);
            log.WriteMessage( Assembly.GetExecutingAssembly().GetName().Name, "This is an instance error test", MessageType.Error);
            log.WriteMessage("Desktop", "Another Message that should be in 'Desktop' source", MessageType.Information);
        }

        /// <summary>
        /// Test the static write message method 
        /// </summary>
        [Test]
        public void TestWriteMessageStatic()
        {
            EventLogger.WriteMessage( Assembly.GetExecutingAssembly().GetName().Name, "This is a static Information test", MessageType.Information);
            EventLogger.WriteMessage( Assembly.GetExecutingAssembly().GetName().Name, "This is a static warning test", MessageType.Warning);
            EventLogger.WriteMessage( Assembly.GetExecutingAssembly().GetName().Name, "This is a static error test", MessageType.Error);
            EventLogger.WriteMessage("Desktop", "Another Message that should be in 'Desktop' source", MessageType.Information);
        }
	}

    /// <summary>
    /// Test migration of sources.
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class EventLoggerMigration
    {
        const string OldLogName = "Sage Migration Test";
        const string NoMigrateSource = "No Migrate Source";
        const string OldMigrateSource = "Sage.Migrate Source";
        const string NewMigrateSource = "Migrate Source";

        /// <summary></summary>
        [TestFixtureSetUp]
        public void SetUp()
        {
            if (EventLog.Exists(OldLogName))
            {
                EventLog.Delete(OldLogName);
            }
        }

        /// <summary></summary>
        [TestFixtureTearDown]
        public void TearDown()
        {
            if (EventLog.Exists(OldLogName))
            {
                EventLog.Delete(OldLogName);
            }
        }

        /// <summary></summary>
        [Test]
        public void NoSourceMigration()
        {
            const string msg = "This is a no migrate log source unit test.";

            if (EventLog.SourceExists(NoMigrateSource))
            {
                EventLog.DeleteEventSource(NoMigrateSource);
            }
            EventLog.CreateEventSource(NoMigrateSource, OldLogName);
            using (EventLog log = new EventLog(OldLogName, ".", NoMigrateSource))
            {
                log.WriteEntry(msg);
            }
            EventLogger.WriteMessage(NoMigrateSource, msg, MessageType.Error);
            Assert.AreEqual(OldLogName, EventLog.LogNameFromSourceName(NoMigrateSource, "."));
        }

        /// <summary></summary>
        [Test]
        public void MigrateSource()
        {
            const string msg = "This is a migrate log source test.";

            if (EventLog.SourceExists(OldMigrateSource))
            {
                EventLog.DeleteEventSource(OldMigrateSource);
            }
            if (EventLog.SourceExists(NewMigrateSource))
            {
                EventLog.DeleteEventSource(NewMigrateSource);
            }
            EventLog.CreateEventSource(OldMigrateSource, OldLogName);
            using (EventLog log = new EventLog(OldLogName, ".", OldMigrateSource))
            {
                log.WriteEntry(msg);
            }
            EventLogger.WriteMessage(NewMigrateSource, msg, MessageType.Error);
            Assert.AreEqual(EventLogger.LogName, EventLog.LogNameFromSourceName(OldMigrateSource, "."));
        }
    }
}

#endif // DEBUG