using System;
using System.Runtime.InteropServices;

namespace Sage.Configuration
{
    /// <summary>
    /// Class for managing a data table key value set
    /// </summary>
    [ComVisible(false)]
    public class DataStoreKeyValueSet : IKeyValueSet
    {
        // The key name
        private string _key = null;

        // The data value
        private string _dataValue = null;

        /// <summary>
        /// Constructor
        /// </summary>
        public DataStoreKeyValueSet()
        {
        
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="key">The name of the data key</param>
        /// <param name="dataValue">The value of the data key</param>
        public DataStoreKeyValueSet( string key, string dataValue )
        {
            _key = key;
            _dataValue = dataValue;
        }

        /// <summary>
        /// Get/Set the key name
        /// </summary>
        public string Key
        {
            get{ return _key; }
            set{ _key = value; }
        }

        /// <summary>
        /// Get/set the key value
        /// </summary>
        public string Value
        {
            get{ return _dataValue; }
            set{ _dataValue = value; }
        }
    }
}
