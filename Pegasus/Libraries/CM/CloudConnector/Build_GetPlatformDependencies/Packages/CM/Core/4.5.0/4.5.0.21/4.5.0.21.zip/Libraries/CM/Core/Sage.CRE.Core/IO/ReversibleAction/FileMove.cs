using System;
using System.Collections.Generic;
using System.IO;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Moves (or renames) one or more files using the ReversibleAction pattern.
    /// The construction of a FileMove object moves the specified files.
    /// If the object is disposed without calling the Commit() method, then the file move is reversed.
    /// 
    /// Typical usage:
    /// 
    /// using (FileMove fileMove = new FileDelete(@"C:\srcFile.txt",@"C:\destFile.txt"))
    /// {
    ///     fileMove.Commit();
    ///     
    ///     // execute some code that might throw. If the code throws, we need to restore the original file.
    /// 
    ///     fileMove.Commit();
    /// }
    /// </summary>
    public class FileMove : ReversibleActionBase
    {
        /// <summary>
        /// Moves (or renames) a single file.
        /// </summary>
        /// <param name="source">The filename of the source file.</param>
        /// <param name="destination">The filename of the destination file.</param>
        public FileMove(string source, string destination)
            : this(source, destination, false)
        { }

        /// <summary>
        /// Moves (or renames) a single file.
        /// </summary>
        /// <param name="source">The filename of the source file.</param>
        /// <param name="destination">The filename of the destination file.</param>
        /// <param name="allowMissingSource">true if missing source file should be permitted without error (i.e., skip move step)</param>
        public FileMove(string source, string destination, bool allowMissingSource)
        {
            _allowMissingSource = allowMissingSource;
            _filesToBeMoved.Add(source, destination);
        }

        /// <summary>
        /// Moves (or renames) a set of files.
        /// </summary>
        /// <param name="sourcesAndDestinations"></param>
        public FileMove(Dictionary<string, string> sourcesAndDestinations)
            : this(sourcesAndDestinations, false)
        { }

        /// <summary>
        /// Moves (or renames) a set of files.
        /// </summary>
        /// <param name="sourcesAndDestinations"></param>
        /// <param name="allowMissingSource">true if missing source file should be permitted without error (i.e., skip move step)</param>
        public FileMove(Dictionary<string, string> sourcesAndDestinations, bool allowMissingSource)
        {
            _allowMissingSource = allowMissingSource;
            _filesToBeMoved = sourcesAndDestinations;
        }


        #region Protected methods
        /// <summary>
        /// Move the files.
        /// </summary>
        public override void Forward()
        {
            base.Forward();
            foreach (KeyValuePair<string, string> kvp in _filesToBeMoved)
            {
                string src = kvp.Key;
                string dest = kvp.Value;

                if (!_allowMissingSource || (_allowMissingSource && File.Exists(src)))
                {
                    System.IO.FileInfo fileInfo = new System.IO.FileInfo(src);
                    fileInfo.MoveTo(dest);
                    _filesMoved.Add(src, dest);
                }
            }
        }

        /// <summary>
        /// Restore the files.
        /// </summary>
        public override void Reverse()
        {
            base.Reverse();
            foreach (KeyValuePair<string, string> kvp in _filesMoved)
            {
                string src = kvp.Key;
                string dest = kvp.Value;

                System.IO.FileInfo fileInfo = new System.IO.FileInfo(dest);
                fileInfo.MoveTo(src);
            }
            _filesMoved.Clear();
        }
        #endregion

        #region Private members
        private bool _allowMissingSource; //= false; (automatically initialized by runtime)
        private Dictionary<string, string> _filesToBeMoved = new Dictionary<string, string>();
        private Dictionary<string, string> _filesMoved = new Dictionary<string, string>();
        #endregion

    }
}
