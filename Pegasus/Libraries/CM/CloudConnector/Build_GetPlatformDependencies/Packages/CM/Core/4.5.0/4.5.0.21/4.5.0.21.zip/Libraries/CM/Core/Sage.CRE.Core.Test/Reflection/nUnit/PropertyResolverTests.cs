#if DEBUG
using NUnit.Framework;
using System;
using System.Runtime.InteropServices;


namespace Sage.Reflection.nUnit
{
	/// <summary>
	/// Summary description for PropertyResolverTests.
	/// </summary>
	[TestFixture]
    [ ComVisible( false ) ]
	public class PropertyResolverTests
	{
        /// <summary>
        /// Constructor
        /// </summary>
		public PropertyResolverTests()
		{
			
		}

        /// <summary>
        /// Test the default constructor
        /// </summary>
        [Test]
        public void TestCreation()
        {
            IPropertyResolver resolver = new PropertyResolver();
        }

        /// <summary>
        /// Test the constructor with passing in a type instance
        /// </summary>
        [Test]
        public void TestCreationWithType()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver( testClass );
        }

        /// <summary>
        /// Test the constructor with passing in a null type
        /// </summary>
        [ ExpectedException( typeof(ArgumentNullException) ) ]
        [Test]
        public void TestCreateWithNullType()
        {
            INamedProperty resolver = new PropertyResolver( null );
        }

        /// <summary>
        /// Test the constructor passing in a type instance 
        /// and the expose privates flag
        /// </summary>
        [Test]
        public void TestCreateWithTypeAndFlag()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver( testClass, true );
        }

        /// <summary>
        /// Test the constructor passing a null type instance 
        /// and the expose privates flag
        /// </summary>
        [ ExpectedException( typeof(ArgumentNullException) ) ]
        [Test]
        public void TestCreateWithNullTypeAndFlag()
        {
            IPropertyResolver resolver = new PropertyResolver( null, true );
        }

        /// <summary>
        /// Test setting the TypeInstance property on the IPropertyResolver interface
        /// </summary>
        [Test]
        public void TestSetTypeInstance()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            IPropertyResolver resolver = new PropertyResolver();
            resolver.TypeInstance = testClass;
        }

        /// <summary>
        /// Test setting the TypeInstance property on the IPropertyResolver 
        /// interface with a null type
        /// </summary>
        [ ExpectedException( typeof(ArgumentNullException) ) ]
        [Test]
        public void TestSetTypeInstanceWithNullType()
        {
            IPropertyResolver resolver = new PropertyResolver();
            resolver.TypeInstance = null;
        }

        /// <summary>
        /// Test setting and retrieving the ExposePrivateProperties flag
        /// </summary>
        [Test]
        public void TestSetAndGetExposePrivateProperties()
        {
            IPropertyResolver resolver = new PropertyResolver();
            bool flag = resolver.ExposePrivateProperties;
            Assert.IsTrue( flag == false );
            resolver.ExposePrivateProperties = true;
            flag = resolver.ExposePrivateProperties;
            Assert.IsTrue( flag == true );
        }

        /// <summary>
        /// Test HasProperty on a public property
        /// </summary>
        [Test]
        public void TestHasPublicProperty()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver( testClass );
            bool result = resolver.HasProperty( "NumberVal" );
            Assert.IsTrue( result == true );
            result = resolver.HasProperty( "StringVal" );
            Assert.IsTrue( result == true );
            result = resolver.HasProperty( "Joker" );
            Assert.IsTrue( result == false );
            result = resolver.HasProperty( "PrivateNumberVal" );
            Assert.IsTrue( result == false );
            result = resolver.HasProperty( "PrivateStringVal" );
            Assert.IsTrue( result == false );
        }

        /// <summary>
        /// Test HasProperty on public and Private properties
        /// </summary>
        [Test]
        public void TestHasPrivateProperty()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver( testClass, true );
            bool result = resolver.HasProperty( "NumberVal" );
            Assert.IsTrue( result == true );
            result = resolver.HasProperty( "StringVal" );
            Assert.IsTrue( result == true );
            result = resolver.HasProperty( "TheJoker" );
            Assert.IsTrue( result == false );
            result = resolver.HasProperty( "PrivateNumberVal" );
            Assert.IsTrue( result == true );
            result = resolver.HasProperty( "PrivateStringVal" );
            Assert.IsTrue( result == true );
        }

        /// <summary>
        /// Test HasProperty with out setting a type instance
        /// </summary>
        [ ExpectedException( typeof(InvalidOperationException) ) ]
        [Test]
        public void TestHasPropertyWithNoTypeInstance()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver();
            bool result = resolver.HasProperty( "NumberVal" );
        }

        /// <summary>
        /// Test retrieving property values
        /// </summary>
        [Test]
        public void TestGetPropertyValue()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver( testClass, true );
            int numberResult = (int)resolver.GetPropertyValue( "NumberVal" );
            Assert.IsTrue( numberResult == 7 );
            string stringResult = (string)resolver.GetPropertyValue( "StringVal" );
            Assert.IsTrue( stringResult == "TheJoker" );
            numberResult = (int)resolver.GetPropertyValue( "PrivateNumberVal" );
            Assert.IsTrue( numberResult == 7 );
            stringResult = (string)resolver.GetPropertyValue( "PrivateStringVal" );
            Assert.IsTrue( stringResult == "TheJoker" );
        }

        /// <summary>
        /// Test GetPropertyValue passing in an invalid property
        /// </summary>
        [ ExpectedException( typeof(ArgumentException) ) ]
        [Test]
        public void TestGetPropertyValueWithInvalidProperty()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver( testClass );
            object result = resolver.GetPropertyValue( "TheJoker" );
        }

        /// <summary>
        /// Test GetPropertyValue with out setting a type instance
        /// </summary>
        [ ExpectedException( typeof(InvalidOperationException) ) ]
        [Test]
        public void TestGetPropertyValueWithNoTypeInstance()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver();
            object result = resolver.GetPropertyValue( "TheJoker" );
        }

        /// <summary>
        /// Test setting a property value
        /// </summary>
        [Test]
        public void TestSetPropertyValue()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver( testClass, true );
            object propValue = 10;
            resolver.SetPropertyValue( "NumberVal", propValue );
            int numberResult = (int)resolver.GetPropertyValue( "NumberVal" );
            Assert.IsTrue( numberResult == 10 );
            propValue = "Catwoman";
            resolver.SetPropertyValue( "StringVal", propValue );
            string stringResult = (string)resolver.GetPropertyValue( "StringVal" );
            Assert.IsTrue( stringResult == "Catwoman" );
            propValue = 17;
            resolver.SetPropertyValue( "PrivateNumberVal", propValue );
            numberResult = (int)resolver.GetPropertyValue( "PrivateNumberVal" );
            Assert.IsTrue( numberResult == 17 );
            propValue = "ClayFace";
            resolver.SetPropertyValue( "PrivateStringVal", propValue );
            stringResult = (string)resolver.GetPropertyValue( "PrivateStringVal" );
            Assert.IsTrue( stringResult == "ClayFace" );
        }

        /// <summary>
        /// Test SetPropertyValue passing in an invalid property
        /// </summary>
        [ ExpectedException( typeof(ArgumentException) ) ]
        [Test]
        public void TestSetPropertyValueWithInvalidProperty()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver( testClass );
            object propValue = "MyValue";
            resolver.SetPropertyValue( "TheJoker", propValue );
        }

        /// <summary>
        /// Test SetPropertyValue with out setting a type instance
        /// </summary>
        [ ExpectedException( typeof(InvalidOperationException) ) ]
        [Test]
        public void TestSetPropertyValueWithNoTypeInstance()
        {
            PropertyResolverTestClass testClass = new PropertyResolverTestClass();
            INamedProperty resolver = new PropertyResolver();
            object propValue = "MyValue";
            resolver.SetPropertyValue( "StringVal", propValue );
        }
	}
}

#endif // DEBUG