using System;
using System.Collections.Generic;
using System.Text;
using System.Security;

using Sage.IO;
using Sage.Configuration;

namespace Sage.Configuration.Internal
{
    /// <summary>
    /// This path class contains information needed to resolve special paths
    /// </summary>
    internal sealed class SpecialPathUrlResolver : IUrlResolver
    {
        #region private fields
        /// <summary>
        /// Prefix of encoded special OS system folders or enviornment variable based paths
        /// </summary>
        private const string SpecialPathUrlPrefix = "specialpath://";
        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        public SpecialPathUrlResolver()
        {
        }

        #region IUrlResolver Members

        /// <summary>
        /// Determine if this is a special url
        /// </summary>
        /// <param name="url">Url to examine</param>
        /// <returns>True if the url is a special url, otherwise false</returns>
        public bool CanResolveUrl(string url)
        {
            string temp = url.ToLower();
            if (temp.StartsWith(SpecialPathUrlPrefix))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Resolves an URL that uses the special path protocol to a file system reference.
        /// No guarantees are provided that the resolved path is valid in the file system.
        /// </summary>
        /// <remarks>
        /// A Paths URL has the form specialpath://context/path where path is a path relative to 
        /// one of the context folders and context is a key to a specific folder. 
        /// </remarks>
        /// <param name="url">Url to resolve.</param>
        /// <returns>A resolved path if the provide url is a valid special path otherwise the path unchanged</returns>
        public string ResolveUrl(string url)
        {
            string retval = url;

            int prefixSize = SpecialPathUrlPrefix.Length;
            string[] parts = url.Substring(prefixSize).Split(new char[] { '/', '\\' }, 2);

            string spec = null;
            if (parts.Length == 2)
            {
                spec = parts[1];
            }

            string[] contexts = parts[0].Split(new char[] { '.' }, 2);
            if (contexts.Length == 2 && contexts[0].ToLower() == "librarymanager")
            {
                switch (contexts[1].ToLower())
                {
                    case "sharedlibrarieslocation":
                        retval = System.IO.Path.Combine(LibraryManager.SharedLibrariesLocation, PathUtils.Normalize(spec));
                        break;
                    case "sharedconfiglocation":
                        retval = System.IO.Path.Combine(LibraryManager.SharedConfigLocation, PathUtils.Normalize(spec));
                        break;
                    case "shareddocumentslocation":
                        retval = System.IO.Path.Combine(LibraryManager.SharedDocumentsLocation, PathUtils.Normalize(spec));
                        break;
                    case "userconfiglocation":
                        retval = System.IO.Path.Combine(LibraryManager.UserConfigLocation, PathUtils.Normalize(spec));
                        break;
                    case "mydocumentslocation":
                        retval = System.IO.Path.Combine(LibraryManager.MyDocumentsLocation, PathUtils.Normalize(spec));
                        break;
                    default:
                        throw new ArgumentException(Strings.SpecifiedFolderKeyInvalid, contexts[1]);
                }
            }
            else if (contexts.Length == 2 && contexts[0].ToLower() == "system")
            {
                try
                {
                    Environment.SpecialFolder sf;
                    sf = (Environment.SpecialFolder)Enum.Parse(typeof(Environment.SpecialFolder), contexts[1], true);
                    switch (sf)
                    {
                        case Environment.SpecialFolder.CommonProgramFiles:
                            Sage.Diagnostics.Assertions.Assert(false, Strings.UseLMSharedLibrariesLocation);
                            break;
                        case Environment.SpecialFolder.CommonApplicationData:
                            Sage.Diagnostics.Assertions.Assert(false, Strings.UseLMSharedConfigLocation);
                            break;
                        case Environment.SpecialFolder.ApplicationData:
                            Sage.Diagnostics.Assertions.Assert(false, Strings.UseLMUserConfigLocation);
                            break;
                        case Environment.SpecialFolder.MyDocuments:
                            Sage.Diagnostics.Assertions.Assert(false, Strings.UseLMSharedMyDocumentsLocation);
                            break;
                        default:
                            // not one of the paths handled by the LibraryManager
                            break;
                    }
                    retval = System.IO.Path.Combine(Environment.GetFolderPath(sf), PathUtils.Normalize(spec));
                }
                catch (ArgumentException)
                {
                    throw new ArgumentException(Strings.SpecifiedFolderKeyInvalid, contexts[1]);
                }
            }
            else if (contexts.Length == 2 && contexts[0].ToLower() == "environment")
            {
                try
                {
                    string ev = Environment.GetEnvironmentVariable(contexts[1]);
                    if (ev != null)
                    {
                        // Allow environment variables to contain encoded urls.
                        ev = PathRegistrar.ResolveUrl(ev.Trim());
                        // Require that environment variables contain valid paths to ensure
                        // we don't create bogus paths from variable that don't contain
                        // a path component.
                        ev = PathUtils.Normalize(ev);
                        if (ev.Length > 0 && PathUtils.IsAccessibleDirectory(ev))
                        {
                            retval = PathUtils.Combine(ev, PathUtils.Normalize(spec));
                        }
                    }
                }
                // Stack overflow is possible when resolving a circular path specification.
                catch (StackOverflowException)
                { }
                // These next two are possible from GetEnvironmentVariable
                catch (ArgumentNullException)
                { }
                catch (SecurityException)
                { }
            }

            return PathUtils.StripTrailingSlash(retval);
        }

        /// <summary>
        /// This property equals true if the path object can encode urls
        /// </summary>
        public Boolean CanEncodeUrl
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Generate an encoded url (i.e. specialpath://context/path) from an url
        /// </summary>
        /// <param name="url">A url to encode</param>
        /// <returns>The encoded url if the method is able to encode it, otherwise the original url is returned</returns>
        public string EncodeUrl(string url)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
