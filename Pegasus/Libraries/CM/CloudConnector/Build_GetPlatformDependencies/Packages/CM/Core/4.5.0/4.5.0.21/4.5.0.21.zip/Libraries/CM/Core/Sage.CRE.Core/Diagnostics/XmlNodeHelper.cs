using System;
using System.Xml;
using System.Configuration;
using System.Runtime.InteropServices;
using System.Globalization;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Provides static methods to facilitate retrieving data from an XmlNode.
    /// </summary>
    [ComVisible(false)]
    public sealed class XmlNodeHelper
    {
        #region Constructors
        /// <summary>
        /// Private default constructor to prevent instantiation of static class.
        /// </summary>
        private XmlNodeHelper()
        {}
        #endregion

        #region Public members
        /// <summary>
        /// Retrieves the value of a named attribute in the specified node as an integer.
        /// </summary>
        /// <param name="node">The element node to retrieve the attribute value from</param>
        /// <param name="attributeName">The name of the attribute value to retrieve</param>
        /// <returns>The value of the named attribute</returns>
        public static Int32 GetInt32AttributeValue(XmlNode node, string attributeName)
        {
            ArgumentValidator.ValidateNonNullReference(node, "node", typeof(XmlNodeHelper) + ".GetInt32AttributeValue");
            ArgumentValidator.ValidateNonEmptyString(attributeName, "attributeName", typeof(XmlNodeHelper) + ".GetInt32AttributeValue");

            Int32 result = 0;
            if(!GetOptionalInt32AttributeValue(node, attributeName, ref result))
            {
                throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, Strings.AttributeNotFoundInFormat, attributeName, node.Value));
            }

            return result;
        }

        /// <summary>
        /// Retrieves the value of an optional named attribute in the specified node as an integer.
        /// </summary>
        /// <param name="node">The element node to retrieve the attribute value from</param>
        /// <param name="attributeName">The name of the attribute value to retrieve</param>
        /// <param name="result">The value of the named attribute</param>
        /// <returns>true if the named attribute was found;  otherwise false</returns>
        public static bool GetOptionalInt32AttributeValue(XmlNode node, string attributeName, ref Int32 result)
        {
            ArgumentValidator.ValidateNonNullReference(node, "node", typeof(XmlNodeHelper) + ".GetOptionalInt32AttributeValue");
            ArgumentValidator.ValidateNonEmptyString(attributeName, "attributeName", typeof(XmlNodeHelper) + ".GetOptionalInt32AttributeValue");

            XmlNode attributeNode = node.Attributes.GetNamedItem(attributeName);
            if(attributeNode != null)
            {
                result = Convert.ToInt32(attributeNode.Value);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Retrieves the value of a named attribute in the specified node as an integere (and validates that it is in range).
        /// </summary>
        /// <param name="node">The element node to retrieve the attribute value from</param>
        /// <param name="attributeName">The name of the attribute value to retrieve</param>
        /// <param name="enumType">The type of the enum which the attribute value should be in range with</param>
        /// <returns>The value of the named attribute</returns>
        public static Int32 GetEnumAttributeValue(XmlNode node, string attributeName, Type enumType)
        {
            ArgumentValidator.ValidateNonNullReference(node, "node", typeof(XmlNodeHelper) + ".GetEnumAttributeValue");
            ArgumentValidator.ValidateNonEmptyString(attributeName, "attributeName", typeof(XmlNodeHelper) + ".GetEnumAttributeValue");
            ArgumentValidator.ValidateIsSubclassOfType(enumType, "enumType", typeof(XmlNodeHelper) + ".GetEnumAttributeValue", typeof(Enum));

            Int32 result = 0;
            if(!GetOptionalEnumAttributeValue(node, attributeName, enumType, ref result))
            {
                throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, Strings.AttributeNotFoundInFormat, attributeName, node.Value));
            }

            return result;
        }

        /// <summary>
        /// Retrieves the value of an optional named attribute in the specified node as an integere (and validates that it is in range).
        /// </summary>
        /// <param name="node">The element node to retrieve the attribute value from</param>
        /// <param name="attributeName">The name of the attribute value to retrieve</param>
        /// <param name="enumType">The type of the enum which the attribute value should be in range with</param>
        /// <param name="result">The value of the named attribute</param>
        /// <returns>true if the named attribute was found;  otherwise false</returns>
        public static bool GetOptionalEnumAttributeValue(XmlNode node, string attributeName, Type enumType, ref int result)
        {
            ArgumentValidator.ValidateNonNullReference(node, "node", typeof(XmlNodeHelper) + ".GetOptionalEnumAttributeValue");
            ArgumentValidator.ValidateNonEmptyString(attributeName, "attributeName", typeof(XmlNodeHelper) + ".GetOptionalEnumAttributeValue");
            ArgumentValidator.ValidateIsSubclassOfType(enumType, "enumType", typeof(XmlNodeHelper) + ".GetOptionalEnumAttributeValue", typeof(Enum));

            XmlNode attributeNode = node.Attributes.GetNamedItem(attributeName);
            if(attributeNode != null)
            {
                if(Enum.IsDefined(enumType, attributeNode.Value))
                {
                    result = (int) Enum.Parse(enumType, attributeNode.Value);
                    return true;
                }
                else
                {
                    throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, Strings.InvalidValueForEnumTypeFormat, attributeNode.Value, enumType.ToString()));
                }
            }

            return false;
        }

        /// <summary>
        /// Retrieves the value of a named attribute in the specified node as a string.
        /// </summary>
        /// <param name="node">The element node to retrieve the attribute value from</param>
        /// <param name="attributeName">The name of the attribute value to retrieve</param>
        /// <returns>The value of the named attribute</returns>
        public static string GetStringAttributeValue(XmlNode node, string attributeName)
        {
            ArgumentValidator.ValidateNonNullReference(node, "node", typeof(XmlNodeHelper) + ".GetStringAttributeValue");
            ArgumentValidator.ValidateNonEmptyString(attributeName, "attributeName", typeof(XmlNodeHelper) + ".GetStringAttributeValue");

            string result = null;
            if(!GetOptionalStringAttributeValue(node, attributeName, ref result))
            {
                throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, Strings.AttributeNotFoundInFormat, attributeName, node.Value));
            }

            return result;
        }

        /// <summary>
        /// Retrieves the value of an optional named attribute in the specified node as a string.
        /// </summary>
        /// <param name="node">The element node to retrieve the attribute value from</param>
        /// <param name="attributeName">The name of the attribute value to retrieve</param>
        /// <param name="result">The value of the named attribute</param>
        /// <returns>true if the named attribute was found;  otherwise false</returns>
        public static bool GetOptionalStringAttributeValue(XmlNode node, string attributeName, ref string result)
        {
            ArgumentValidator.ValidateNonNullReference(node, "node", typeof(XmlNodeHelper) + ".GetOptionalStringAttributeValue");
            ArgumentValidator.ValidateNonEmptyString(attributeName, "attributeName", typeof(XmlNodeHelper) + ".GetOptionalStringAttributeValue");

            XmlNode attributeNode = node.Attributes.GetNamedItem(attributeName);
            if(attributeNode != null)
            {
                result = attributeNode.Value;
                return true;
            }

            return false;
        }

        /// <summary>
        /// Retrieves the value of a named attribute in the specified node as a bool.
        /// </summary>
        /// <param name="node">The element node to retrieve the attribute value from</param>
        /// <param name="attributeName">The name of the attribute value to retrieve</param>
        /// <returns>The value of the named attribute</returns>
        public static bool GetBoolAttributeValue(XmlNode node, string attributeName)
        {
            ArgumentValidator.ValidateNonNullReference(node, "node", typeof(XmlNodeHelper) + ".GetBoolAttributeValue");
            ArgumentValidator.ValidateNonEmptyString(attributeName, "attributeName", typeof(XmlNodeHelper) + ".GetBoolAttributeValue");

            bool result = false;
            if(!GetOptionalBoolAttributeValue(node, attributeName, ref result))
            {
                throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, Strings.AttributeNotFoundInFormat, attributeName, node.Value));
            }

            return result;
        }

        /// <summary>
        /// Retrieves the value of an optional named attribute in the specified node as a bool.
        /// </summary>
        /// <param name="node">The element node to retrieve the attribute value from</param>
        /// <param name="attributeName">The name of the attribute value to retrieve</param>
        /// <param name="result">The value of the named attribute</param>
        /// <returns>true if the named attribute was found;  otherwise false</returns>
        public static bool GetOptionalBoolAttributeValue(XmlNode node, string attributeName, ref bool result)
        {
            ArgumentValidator.ValidateNonNullReference(node, "node", typeof(XmlNodeHelper) + ".GetOptionalBoolAttributeValue");
            ArgumentValidator.ValidateNonEmptyString(attributeName, "attributeName", typeof(XmlNodeHelper) + ".GetOptionalBoolAttributeValue");

            XmlNode attributeNode = node.Attributes.GetNamedItem(attributeName);
            if(attributeNode != null)
            {
                result = (0 == String.Compare("true", attributeNode.Value.ToLower(), true, CultureInfo.InvariantCulture));
                return true;
            }

            return false;
        }

        #endregion
    }
}
