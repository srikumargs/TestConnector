using System;
using System.Xml;
using System.Diagnostics;

using Sage.Reflection;
using Sage.Diagnostics;

namespace Sage.Xml
{
	/// <summary>
	/// Summary description for XmlAsNamedProperties.
	/// </summary>
	public class XmlAsNamedProperties: INamedProperty
	{
		/// <summary>
		/// Default element name for the root node.
		/// </summary>
		public static readonly string DEFAULT_PROPERTIES_ELEMENT = "Properties";

		/// <summary>
		/// field for the root node name, set to the default value.
		/// </summary>
		private string _rootNodeName = DEFAULT_PROPERTIES_ELEMENT;

		/// <summary>
		/// The xml document object
		/// </summary>
		private XmlDocument _XmlDoc = null;

		/// <summary>
		/// Cache the properties node of the current extended xml.
		/// </summary>
		private XmlNode _propertiesNode = null;
		
		/// <summary>
		/// Constructor that uses the default properties element for the root node name.
		/// </summary>
		public XmlAsNamedProperties()
		{
		}

		/// <summary>
		/// Constructor allowing the client o provide the name.
		/// </summary>
		/// <param name="rootNodeName"></param>
		public XmlAsNamedProperties(string rootNodeName)
		{
			_rootNodeName = rootNodeName;
		}

		/// <summary>
		/// Provide the name of the Root node.
		/// </summary>
		public string RootNodeName
		{
			get
			{
				return _rootNodeName;
			}
		}

		/// <summary>
		/// Provide the internal xml document
		/// </summary>
		private XmlDocument XmlDoc
		{
			get
			{
				if( _XmlDoc == null )
				{
					_XmlDoc = new XmlDocument();
				}
				return _XmlDoc;
			}
		}

		/// <summary>
		/// Look up the XmlNode for the properties of this message
		/// </summary>
		private XmlNode PropertiesXmlNode
		{
			get
			{
				if( _propertiesNode == null )
				{
					_propertiesNode = XmlDoc.CreateElement(RootNodeName);
					XmlDoc.AppendChild(_propertiesNode);
				}
				return _propertiesNode;
			}
		}

		/// <summary>
		/// Look up the requested property value
		/// </summary>
		/// <param name="propName">name of the property</param>
		/// <returns>the value of the property</returns>
		public object GetPropertyValue(string propName)
		{
			if( propName == null )
			{
				throw new ArgumentNullException(Strings.MustProvideANonNull, "propName");
			}
			else if( propName == string.Empty )
			{
				throw new ArgumentException(Strings.MustProvideANonEmptyString, "propName");
			}


			if( HasProperty(propName) )
			{
				return XmlHelper.GetRequiredAttribute(PropertiesXmlNode, propName);
			}
			else
			{
				throw new ArgumentException(Strings.NoSuchProperty, "propName");
			}
		}

		/// <summary>
		/// Set the value of the requested property.
		/// </summary>
		/// <param name="propName">name of the property</param>
		/// <param name="val">value of the property (must be a string)</param>
		public void SetPropertyValue(string propName, object val)
		{
			Assertions.Assert( val is string, Strings.PropertyValueMustBeString ); 

			XmlNode prop = PropertiesXmlNode.Attributes.GetNamedItem(propName);
			if (prop == null)
			{
				XmlAttribute newProp = XmlDoc.CreateAttribute(propName);
				PropertiesXmlNode.Attributes.Append(newProp);
				prop = newProp;
			}
			prop.Value = (string)val;
		}

		/// <summary>
		/// Check to see if a particular property exists.
		/// </summary>
		/// <param name="propName">the name of the property to check</param>
		/// <returns></returns>
		public bool HasProperty(string propName)
		{
			XmlNode xmlProps = PropertiesXmlNode;
			return ( xmlProps != null && XmlHelper.AttributeExists(xmlProps, propName) );
		}

		/// <summary>
		/// Provide the XML as a string
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			return XmlDoc.OuterXml;
		}

		/// <summary>
		/// Provide the xml as a string
		/// </summary>
		public string Xml
		{
			get
			{
				return ToString();
			}
			set
			{
				XmlDoc.LoadXml(value);
				if( XmlDoc.DocumentElement.Name != RootNodeName )
				{
					throw new ArgumentException(string.Format(Strings.RootElementMustBeNamedFormat, RootNodeName), "value");
				}
				else
				{
					_propertiesNode = XmlDoc.DocumentElement;
				}
			}
		}

	}
}
