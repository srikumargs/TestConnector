using System;
using System.Runtime.Remoting.Messaging;

namespace TestLibrary
{
    public class TestObject : MarshalByRefObject
    {
        public int foo = 0;

        public String Ping()
        {
            foo = foo + 1;
            Console.WriteLine("ping test object..." + foo);
            return("this is the result of a ping! " + foo);            
        }

        [OneWay]
        public void OneWayMethod(String s)
        {
            Console.WriteLine("OneWayMethod {0}", s);

            if (s.StartsWith("BatchEnd"))
            {
                Console.WriteLine("OneWayMethod {0}", s);
            }
        }

        public void RegularMethod(String s)
        {
            if (s.StartsWith("BatchEnd"))
            {
                Console.WriteLine("RegularMethod {0}", s);
            }
        }

        public String AsyncMethod(String s)
        {
            Console.WriteLine("AsyncMethod {0}", s);

            if (s.StartsWith("BatchEnd"))
            {
                Console.WriteLine("AsyncMethod {0}", s);
            }

            return s;
        }

        public String CallMe(CallbackObject cb)
        {
            Console.WriteLine("Trying to make callback...");
            String result = cb.Callback();
            Console.WriteLine("done with callback...");
            return result;
        }
    }

    public class CallbackObject : MarshalByRefObject
    {
        public String Callback()
        {
            Console.WriteLine("Callback received!");
            return("Result from callback!");
        }
    }
}

