using System;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Sage.PInvoke
{
    /// <summary>
    /// Summary description for CWininet.
    /// </summary>
    public static class Wininet
    {
        public static bool InternetGetConnectedState(out int connectionDescription, int reservedValue)
        {
            return PInvoke.SafeNativeMethods.InternetGetConnectedState(out connectionDescription, reservedValue);
        }
    }
}
