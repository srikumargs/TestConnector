using System;
using System.Collections.Generic;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Deletes one or more directories using the ReversibleAction pattern.
    /// The construction of a DirectoryDelete object deletes the specified directory.
    /// If the object is disposed without calling the Commit() method, then the deleted directory create is restored.
    /// 
    /// Typical usage:
    /// 
    /// using (DirectoryDelete dirDelete = new DirectoryDelete(@"C:\sourceDirectory"))
    ///     {
    ///         dirDelete.Forward();
    ///         
    ///         // do some code that might throw. If this code throws, we need to restore the deleted directory.
    /// 
    ///         dirDelete.Commit();
    ///     }
    /// </summary>
    public class DirectoryDelete : ReversibleActionBase
    {
        /// <summary>
        /// Deletes a single directory.
        /// </summary>
        /// <param name="directory">The directory to delete.</param>
        public DirectoryDelete(string directory)
        {
            _directoriesToBeDeleted.Add(directory);
        }

        /// <summary>
        /// Deletes a set of directories.
        /// </summary>
        /// <param name="directories">A list of directories to delete.</param>
        public DirectoryDelete(System.Collections.ObjectModel.Collection<string> directories)
        {
            _directoriesToBeDeleted = directories;
        }

        #region Protected methods
        /// <summary>
        /// Deletes the previously specified directories.
        /// </summary>
        public override void Forward()
        {
            base.Forward();
            foreach (string dir in _directoriesToBeDeleted)
            {
                string renamedDir = System.IO.Path.Combine(System.IO.Path.GetTempPath(),String.Format(System.Globalization.CultureInfo.InvariantCulture,StringsNoTran.ReversibleFileSystemAction_TempObjectCatenationFormat_Internal, dir, _actionID));
                _directoriesDeleted.Add(dir, renamedDir);
            }

            moveDirs = new DirectoryMove(_directoriesDeleted);
            moveDirs.Forward();
        }

        /// <summary>
        /// Restores any deleted directories.
        /// </summary>
        public override void Reverse()
        {
            base.Reverse();
            if (moveDirs != null) moveDirs.Dispose();
        }

        /// <summary>
        /// Permanently deletes the directories.
        /// </summary>
        public override void Commit()
        {
            base.Commit();
            moveDirs.Commit();
            foreach (KeyValuePair<string, string> kvp in _directoriesDeleted)
            {
                string dest = kvp.Value;
                if (System.IO.Directory.Exists(dest)) System.IO.Directory.Delete(dest, true);
            }
            moveDirs.Dispose();
            moveDirs = null;
        }
        #endregion

        #region Private members
        private System.Collections.ObjectModel.Collection<string> _directoriesToBeDeleted = new System.Collections.ObjectModel.Collection<string>();
        private Dictionary<string, string> _directoriesDeleted = new Dictionary<string, string>();
        private string _actionID = System.DateTime.Now.ToFileTimeUtc().ToString(System.Globalization.CultureInfo.InvariantCulture);
        private DirectoryMove moveDirs;
        #endregion


    }
}
