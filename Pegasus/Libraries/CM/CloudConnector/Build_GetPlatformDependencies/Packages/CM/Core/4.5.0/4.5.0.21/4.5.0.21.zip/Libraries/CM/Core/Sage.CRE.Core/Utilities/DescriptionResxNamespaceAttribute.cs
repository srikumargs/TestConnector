using System;
using System.Collections.Generic;
using System.Text;

namespace Sage.Utilities
{
    /// <summary>
    /// Used with an Enum to indicate that UI-usable text values can be retrieved from
    /// a resx file with the indicated namespace.
    /// </summary>
    [AttributeUsage( AttributeTargets.Enum )]
    public class DescriptionResxNamespaceAttribute : System.Attribute
    {
        private string _resxNamespace;

        /// <summary>
        /// ctor
        /// </summary>
        public DescriptionResxNamespaceAttribute( String resxNamespace )
        {
            this._resxNamespace = resxNamespace;
        }

        /// <summary>
        /// Gets the RESX namespace.
        /// </summary>
        /// <value>The RESX namespace.</value>
        public String ResxNamespace
        {
            get { return _resxNamespace; }
        }
    }
}
