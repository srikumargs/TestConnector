﻿using System;

namespace Waf.BookLibrary.Library.Applications.Services
{
    public interface IEmailService
    {
        void CreateNewEmail(string toEmailAddress);
    }
}
