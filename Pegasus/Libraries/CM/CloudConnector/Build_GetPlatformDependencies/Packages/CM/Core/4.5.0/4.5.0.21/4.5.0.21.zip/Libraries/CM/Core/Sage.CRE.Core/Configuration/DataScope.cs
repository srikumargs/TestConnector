using System;
using System.Runtime.InteropServices;

namespace Sage.Configuration
{
    /// <summary>
    /// Enumerate the available scopes of stored data
    /// </summary>
    [ComVisible(false)]
    public enum DataScope
    {
        /// <summary>
        /// Stores data visible to all users on a machine
        /// </summary>
        AllUsers,

        /// <summary>
        /// Store data visible to the current user only
        /// </summary>
        CurrentUser,

        /// <summary>
        /// Store data on the server for a roaming user profile
        /// </summary>
        RoamingUser,

		/// <summary>
		/// Store data on the file system.
		/// </summary>
		FileSystem
    }
}
