#if DEBUG
using System;
using System.Runtime.InteropServices;
using NUnit.Framework;
using System.Xml;
using System.Xml.XPath;
using System.Text;

using Sage.Configuration;
using Sage.Remoting;

namespace Sage.Remoting.NUnit
{
    /// <summary>
    /// subclass for testing
    /// </summary>
    [ ComVisible( false ) ]
    public class MarshalByRefBaseSubclass : MarshalByRefBase
    {
    }

    /// <summary>
    /// Test Marshal By Ref
    /// </summary>
    [TestFixture]
    [ComVisible(false)]
    public class Test_MarshalByRefBase
    {
        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestObjectUriDefault()
        {
            MarshalByRefBaseSubclass sub = new MarshalByRefBaseSubclass();
            Assert.AreEqual("MarshalByRefBaseSubclass", sub.ObjectUri);
        }
    }
}

#endif // DEBUG