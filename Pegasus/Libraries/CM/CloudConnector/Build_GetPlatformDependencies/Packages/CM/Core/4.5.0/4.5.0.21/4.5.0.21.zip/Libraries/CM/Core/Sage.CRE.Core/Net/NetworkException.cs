using System;
using System.Runtime.Serialization;

namespace Sage.Net
{
    /// <summary>
    /// Summary info for tsNetworkException
    /// </summary>
    [Serializable()]
    public class NetworkException : ApplicationException, ISerializable
    {
        /// <summary>
        /// default ctor
        /// </summary>
        public NetworkException()
        {
        }

        /// <summary>
        /// ctor with message
        /// </summary>
        /// <param name="message">exception message string</param>
        public NetworkException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// ctor with message and inner exception
        /// </summary>
        /// <param name="message">exception message string</param>
        /// <param name="inner">inner exception</param>
        public NetworkException(string message, Exception inner)
            : base(message, inner)
        {
        }

    }
}
