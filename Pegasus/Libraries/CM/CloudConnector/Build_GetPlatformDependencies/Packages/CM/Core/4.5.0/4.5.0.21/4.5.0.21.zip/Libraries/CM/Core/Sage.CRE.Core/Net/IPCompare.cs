using System;
using System.Collections.Generic;
using System.Text;

namespace Sage.Net
{
    /// <summary>
    /// Provides a way to compare 2 addresses (IP or hostname) for equality or a single one for local host.
    /// </summary>
    public class IPCompare
    {
        /// <summary>
        /// Compare the specified address (IP or hostname) with the current host name and determine if they're equal.
        /// </summary>
        /// <param name="address">The IP or hostname.</param>
        /// <returns>Returns true if the address is equal to the host name; otherwise, false.</returns>
        public static bool IsLocalAddress(string address)
        {
            // Eliminate localhost before we even begin.
            if (string.IsNullOrEmpty(address) ||
                string.Compare(address, "localhost", true, System.Globalization.CultureInfo.CurrentCulture) == 0)
            {
                return true;
            }

            // Eliminate the loopback device before we even begin.
            if (NetUtils.IsLoopbackAddress(address))
                return true;

            // Perform a comparison.
            return Compare(address, System.Net.Dns.GetHostName());
        }

        /// <summary>
        /// Compare 2 addresses to determine equality.
        /// </summary>
        /// <param name="address1">The first IP or hostname.</param>
        /// <param name="address2">The second IP or hostname.</param>
        /// <returns>Returns true if the 2 are equal; otherwise, false.</returns>
        public static bool Compare(string address1, string address2)
        {
            // Check our inputs...
            if (string.IsNullOrEmpty(address1) ||
                string.IsNullOrEmpty(address2))
            {
                // We're returning true because if 1 address is null, then it certainly cannot be remote.
                return true;
            }

            // Before diving into any logic, perform a simple string comparison.
            else if (string.Compare(address1, address2, true, System.Globalization.CultureInfo.CurrentCulture) == 0)
            {
                return true;
            }

            // Encode both and compare the results.
            return encodeAddress(address1) == encodeAddress(address2);
        }

        /// <summary>
        /// Encodes the address string.
        /// </summary>
        /// <param name="address">The IP or hostname.</param>
        /// <returns>Returns an encoded integer.</returns>
        private static int encodeAddress(string address)
        {
            System.Net.IPAddress ipAddress = null;

            // Check to see if it looks like a file system path.
            if (Sage.IO.PathUtils.IsPath(address))
            {
                if (Sage.IO.PathUtils.IsPathToSubstDrive(address))
                {
                    // Get the path.
                    address = Sage.IO.PathUtils.GetPathFromSubstDrive(address);                    
                }

                // Now get the server name.
                address = Sage.IO.PathUtils.ServerNameFromPath(address);
            }

            // Try to parse it. If it fails, we'll make one last attempt.
            if (!NetUtils.IsIPAddress(address, out ipAddress))
            {
                try
                {
                    // If we reach here, assume it's a host, get the entry, and extract the IP address.
                    System.Net.IPHostEntry entry = System.Net.Dns.GetHostEntry(address);

                    if (entry.AddressList != null &&
                        entry.AddressList.Length > 0)
                    {
                        // Get the address from the 1st item in the list.
                        ipAddress = entry.AddressList[0];
                    }
                }
                catch
                {
                    // A failure occurred. There's nothing more we can do...
                    return 0;
                }
            }

            if (ipAddress != null &&
                ipAddress.GetAddressBytes() != null)
            {
                // Note: found this method to be much better than coming up with an byte shifting scheme.
                return ipAddress.GetHashCode();
            }
            else
            {
                return 0;
            }
        }
    }
}
