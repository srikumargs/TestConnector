﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Net;
using System.Net.Sockets;

namespace Sage.CRE.Core.SQL
{
    /// <summary>
    /// Infomration about a SQL server found on the network.
    /// </summary>
    public class SqlServerInfo
    {
        /// <summary>
        /// The minimum version of MS SQL Server required by our product.
        /// </summary>
        public const System.String MinimumRequiredSQLServerVersion = @"10.0.2531.0";


        /// <summary>Enumerates the valid SQL servers on the network using UDP.
        /// </summary>
        /// <returns>A possibly incomplete list of valid SQL servers on the network.</returns>
        static public List<SqlServerInfo> EnumerationServers()
        {
            return EnumerationServers(MinimumRequiredSQLServerVersion);
        }

        /// <summary>Enumerates the SQL servers on the network.
        /// Note that this method cannot always return the complete list.
        /// It relies of UDP to contact SQL servers on port 1434.
        /// </summary>
        /// <param name="minimumVersion">The minimum required version of SQL Server.</param>
        /// <returns>A list of SqlServerInfo objects describing Sql Servers on this network.</returns>
        static public List<SqlServerInfo> EnumerationServers(string minimumVersion)
        {
            List<SqlServerInfo> result = new List<SqlServerInfo>();

            System.Data.Sql.SqlDataSourceEnumerator servers = System.Data.Sql.SqlDataSourceEnumerator.Instance;
            System.Data.DataTable table = servers.GetDataSources();
            foreach (System.Data.DataRow row in table.Rows)
            {
                SqlServerInfo info = new SqlServerInfo();
                info._ServerName = (string)row["ServerName"];
                if (!row.IsNull("InstanceName")) info._InstanceName = (string)row["InstanceName"];
                if (!row.IsNull("IsClustered")) info._IsClustered = ((string)row["IsClustered"] == "Yes");
                if (!row.IsNull("Version"))
                {
                    info._Version = (string)row["Version"];

                    if (ValidVersion(minimumVersion, info.Version))
                    {
                        result.Add(info);
                    }
                }
            }

            return result;
        }

        /// <summary>Gets the name of the server.
        /// </summary>
        /// <value>The name of the server.</value>
        public string ServerName
        {
            get
            {
                return _ServerName;
            }
        }

        /// <summary>Gets the name of the instance.
        /// </summary>
        /// <value>The name of the instance.</value>
        public string InstanceName
        {
            get
            {
                return _InstanceName;
            }
        }

        /// <summary>Gets a value indicating whether this instance is clustered.
        /// </summary>
        /// <value>
        /// 	<see langword="true"/> if this instance is clustered; otherwise, <see langword="false"/>.
        /// </value>
        public bool IsClustered
        {
            get
            {
                return _IsClustered;
            }
        }

        /// <summary>Gets the version.
        /// </summary>
        /// <value>The version.</value>
        public string Version
        {
            get
            {
                return _Version;
            }
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
        /// </returns>
        public override string ToString()
        {
            if (String.IsNullOrEmpty(this.InstanceName) || this.InstanceName == "MSSQLSERVER")
                return this.ServerName;
            else
                return String.Format(@"{0}\{1}",this.ServerName,this.InstanceName);
        }


        #region Private Method
        static private int[] IntArray(string version)
        {
            string[] parts = version.Split(new char[] { '.' });
            int[] intParts = { 0, 0, 0, 0 };
            try
            {
                intParts[0] = parts.Count() > 0 ? System.Convert.ToInt32(parts[0]) : 0;
                intParts[1] = parts.Count() > 1 ? System.Convert.ToInt32(parts[1]) : 0;
                intParts[2] = parts.Count() > 2 ? System.Convert.ToInt32(parts[2]) : 0;
                intParts[3] = parts.Count() > 3 ? System.Convert.ToInt32(parts[3]) : 0;
            }
            catch (FormatException)
            {
                // Couldn't convert one of the value to an int.
            }

            return intParts;
        }

        static private bool ValidVersion(string min, string actual)
        {

            int[] databaseVersionParts = IntArray(actual);

            int[] requiredParts = IntArray(min);

            if (databaseVersionParts[0] > requiredParts[0]) return true; // major version is greater
            if (databaseVersionParts[0] < requiredParts[0]) return false; // major version is lesser

            if (databaseVersionParts[1] > requiredParts[1]) return true;
            if (databaseVersionParts[1] < requiredParts[1]) return false;

            if (databaseVersionParts[2] > requiredParts[2]) return true;
            if (databaseVersionParts[2] < requiredParts[2]) return false;

            if (databaseVersionParts[3] >= requiredParts[3]) return true;
            return false;
        }

        private SqlServerInfo()
        {

        }

        #endregion

        #region Private members
        private string _ServerName;
        private string _InstanceName;
        private bool _IsClustered;
        private string _Version = "00.00.00.00";
        #endregion


    }
}
