using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Summary description for QueryPerfTimer.
    /// </summary>
    [ComVisible(false)]
    public class QueryPerfTimer
    {
        [System.Runtime.InteropServices.DllImport("Kernel32.dll")]
        private static extern int QueryPerformanceFrequency(ref Int64 lpFrequency);

        [System.Runtime.InteropServices.DllImport("Kernel32.dll")]
        private static extern int QueryPerformanceCounter(ref Int64 lpPerformanceCount);

        private Int64 _TimerFreq;
        private Int64 _TimerStartCount;
        private Int64 _LastCount;

        /// <summary>
        /// 
        /// </summary>
        public QueryPerfTimer()
        {
            Reset();
        }

        /// <summary>
        /// 
        /// </summary>
        public double Interval_us
        {
            get
            {
                QueryPerformanceCounter(ref _LastCount);
                Int64 Count = _LastCount;
                Count -= _TimerStartCount;
                return (double)Count / (double)_TimerFreq * 1000000.0;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Interval
        {
            get
            {
                double t1 = Interval_us;
                Int64 c1 = _LastCount;
                StringBuilder s1 = new StringBuilder();
                if (t1 < 1000)
                    s1.AppendFormat("{0:F3} us", t1);
                else if (t1 < 1000000)
                    s1.AppendFormat("{0:F3} ms", t1 * 0.001);
                else
                    s1.AppendFormat("{0:F3} s", t1 * 0.000001);
                double t2 = Interval_us;
                Int64 c2 = _LastCount;
                _TimerStartCount += (c2-c1);		//Adjust the counter to take account of time spent here
                return s1.ToString();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void Reset()
        {
            QueryPerformanceFrequency(ref _TimerFreq);
            QueryPerformanceCounter(ref _TimerStartCount);
        }

        /// <summary>
        /// Display elapsed time after reset.
        /// Displays time as either us, ms or s.
        /// </summary>
        public void Trace()
        {
            Trace(string.Empty);
        }

        /// <summary>
        /// Display elapsed time after reset.
        /// </summary>
        /// <param name="msg">msg to display before displaying time</param>
        public void Trace(string msg)
        {
            System.Diagnostics.Trace.WriteLine(string.Format("{0} Time = {1}", msg, Interval));
        }
    }
}
