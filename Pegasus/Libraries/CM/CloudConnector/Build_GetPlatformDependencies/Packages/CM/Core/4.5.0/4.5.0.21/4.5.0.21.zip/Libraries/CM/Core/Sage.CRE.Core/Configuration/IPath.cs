using System;
using System.Collections.Generic;
using System.Text;

namespace Sage.Configuration
{
    /// <summary>
    /// Objects containing information needed to resolve paths implement IPath
    /// </summary>
    public interface IUrlResolver
    {
        /// <summary>
        /// Determine if this url can be resolved (i.e. is it a known type of url)
        /// </summary>
        /// <param name="url">Url to examine</param>
        /// <returns>True if the object can resolve the url, otherwise false</returns>
        Boolean CanResolveUrl(string url);

        /// <summary>
        /// Resolves an URL that uses one of the encoded paths protocol to a file system reference.
        /// No guarantees are provided that the resolved path is valid in the file system.
        /// </summary>
        /// <remarks>
        /// A Paths URL has the form Protocol://context/path 
        /// </remarks>
        /// <param name="url">Url to resolve.</param>
        /// <returns>A resolved path if the path can be resolved otherwise the path unchanged </returns>
        string ResolveUrl(string url);

        /// <summary>
        /// This property equals true if the path object can encode urls
        /// </summary>
        Boolean CanEncodeUrl {get;}

        /// <summary>
        /// Generate an encoded url (i.e. Protocol://context/path) from an url
        /// </summary>
        /// <param name="url">A url to encode</param>
        /// <returns>The encoded url if the method is able to encode it, otherwise the original url is returned</returns>
        string EncodeUrl(string url);
    }
}
