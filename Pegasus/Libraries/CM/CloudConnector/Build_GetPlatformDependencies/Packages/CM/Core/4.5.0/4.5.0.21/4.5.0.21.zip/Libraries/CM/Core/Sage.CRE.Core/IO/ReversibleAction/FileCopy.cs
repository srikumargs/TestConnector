using System;
using System.Collections.Generic;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Copy one or more files using the ReversibleAction pattern.
    /// The construction of a CopyFile object copies the specified files.
    /// If the object is disposed without calling the Commit() method, then the file copy is reversed.
    /// 
    /// Typical usage:
    /// 
    /// using (FileCopy fileCopy = new FileCopy(@"C:\srcFile.txt",@"D:\srcFile.txt"))
    /// {
    ///     fileCopy.Forward();
    ///     
    ///     // execute some code that might throw. If the code throws, we need to reverse the file copy.
    /// 
    ///     fileCopy.Commit();
    /// }
    /// </summary>
    public class FileCopy : ReversibleActionBase
    {

        /// <summary>
        /// Copies a single file.
        /// The file's security attributes are not copied.
        /// The file's file attributes are not copied.
        /// The file's auditing (Creation, LastAccess, LastWrite, etc.) fields are not copied.
        /// </summary>
        /// <param name="source">The file to be copied.</param>
        /// <param name="destination">The name of the newly created file.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1805:DoNotInitializeUnnecessarily")]
        public FileCopy(string source, string destination)
        {
            _filesToBeCopied.Add(source, destination);
            _overwriteFiles = false;
            _copyACL = false;
            _copyAttributes = false;
            _copyAuditFields = false;
        }

        /// <summary>
        /// Copies a single file.
        /// </summary>
        /// <param name="source">The file to be copied.</param>
        /// <param name="destination">The name of the newly created file.</param>
        /// <param name="overwriteFiles">Overwrite the destination file if it exists?</param>
        /// <param name="copyACL">Copy the security attributes (Access Control Lists)?</param>
        /// <param name="copyAttributes">Copy the files attributes?</param>
        /// <param name="copyAuditFields">Copy the files audit (Creation, LastAccess, LastWrite, etc.) fields?</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "ACL")]
        public FileCopy(string source, string destination, bool overwriteFiles, bool copyACL, bool copyAttributes, bool copyAuditFields)
        {
            _filesToBeCopied.Add(source, destination);
            _overwriteFiles = overwriteFiles;
            _copyACL = copyACL;
            _copyAttributes = copyAttributes;
            _copyAuditFields = copyAuditFields;
        }

        /// <summary>
        /// Copies a set of files.
        /// The file's security attributes are not copied.
        /// The file's file attributes are not copied.
        /// The file's auditing (Creation, LastAccess, LastWrite, etc.) fields are not copied.
        /// </summary>
        /// <param name="sourcesAndDestinations">A dictionary of source to destination file names.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1805:DoNotInitializeUnnecessarily")]
        public FileCopy(Dictionary<string, string> sourcesAndDestinations)
        {
            _filesToBeCopied = sourcesAndDestinations;
            _overwriteFiles = false;
            _copyACL = false;
            _copyAttributes = false;
            _copyAuditFields = false;
        }
        
        /// <summary>
        /// Copies a set of files.
        /// </summary>
        /// <param name="sourcesAndDestinations">A dictionary of source to destination file names.</param>
        /// <param name="overwriteFiles">Overwrite the destination file if it exists?</param>
        /// <param name="copyACL">Copy the security attributes (Access Control Lists)?</param>
        /// <param name="copyAttributes">Copy the files attributes?</param>
        /// <param name="copyAuditFields">Copy the files audit (Creation, LastAccess, LastWrite, etc.) fields?</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "ACL")]
        public FileCopy(Dictionary<string, string> sourcesAndDestinations, bool overwriteFiles, bool copyACL, bool copyAttributes, bool copyAuditFields)
        {
            _filesToBeCopied = sourcesAndDestinations;
            _overwriteFiles = overwriteFiles;
            _copyACL = copyACL;
            _copyAttributes = copyAttributes;
            _copyAuditFields = copyAuditFields;
        }




        #region Protected methods
        /// <summary>
        /// Copies the previously specified files.
        /// </summary>
        public override void Forward()
        {
            base.Forward();
            foreach (KeyValuePair<string, string> kvp in _filesToBeCopied)
            {
                string src = kvp.Key;
                string dest = kvp.Value;

                System.IO.FileInfo srcFileInfo = new System.IO.FileInfo(src);
                
                System.IO.File.Copy(srcFileInfo.FullName, dest, _overwriteFiles);
                System.IO.FileInfo destFileInfo = new System.IO.FileInfo(dest);

                if (_copyACL)
                {
                    destFileInfo.SetAccessControl(srcFileInfo.GetAccessControl());
                }

                if (_copyAttributes)
                {
                    destFileInfo.Attributes = srcFileInfo.Attributes;
                }

                if (_copyAuditFields)
                {
                    destFileInfo.CreationTimeUtc = srcFileInfo.CreationTimeUtc;
                    destFileInfo.LastAccessTimeUtc = srcFileInfo.LastAccessTimeUtc;
                    destFileInfo.LastWriteTimeUtc = srcFileInfo.LastWriteTimeUtc;
                }

                _filesCopied.Add(src, dest);
            }
        }

        /// <summary>
        /// Restores the original source files.
        /// </summary>
        public override void Reverse()
        {
            base.Reverse();
            foreach (KeyValuePair<string, string> kvp in _filesCopied)
            {
                string dest = kvp.Value;
                if (System.IO.File.Exists(dest)) System.IO.File.Delete(dest);
            }
            _filesCopied.Clear();
        }
        #endregion

        #region Private members
        private Dictionary<string, string> _filesToBeCopied = new Dictionary<string, string>();
        private Dictionary<string, string> _filesCopied = new Dictionary<string, string>();

        private bool _overwriteFiles;
        private bool _copyACL;
        private bool _copyAttributes;
        private bool _copyAuditFields;
        #endregion

    }
}
