using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace Sage.IO
{
    /// <summary>
    /// The event handler called when a string has been added.
    /// </summary>
    /// <param name="sender">The object sender.</param>
    /// <param name="e">The string write event data.</param>
    public delegate void StringWrittenHandler(object sender, StringWrittenEventArgs e);

    /// <summary>
    /// Defines an abstract object that supports Write and WriteLine methods.
    /// </summary>
    public interface IStringWriter
    {
        /// <summary>
        /// The event that's raised when a string has been written.
        /// </summary>
        event StringWrittenHandler StringWritten;

        /// <summary>
        /// Terminates the current line and add a new one.
        /// </summary>
        void WriteLine();

        /// <summary>
        /// Write the string to the current line and add a new one.
        /// </summary>
        /// <param name="line">The line to add to the existing ones.</param>
        void WriteLine(string line);

        /// <summary>
        /// Wrtie the formatted string to the current line and add a new one.
        /// </summary>
        /// <param name="format">A formatted string.</param>
        /// <param name="arg">An array of zero or more arguments.</param>
        void WriteLine(string format, params object[] arg);
    }

    /// <summary>
    /// Defines an abstract object that supports Write and WriteLine methods, as well as access to the underlying string buffer.
    /// </summary>
    public interface IBufferedStringWriter : IStringWriter
    {
        /// <summary>
        /// The event that's raised when the strings have been cleared.
        /// </summary>
        event EventHandler StringsCleared;

        /// <summary>
        /// Get the total number of string lines/entries.
        /// </summary>
        int Count { get; }

        /// <summary>
        /// Clears out all stored string data.
        /// </summary>
        void Clear();

        /// <summary>
        /// Get the string buffer.
        /// </summary>
        /// <returns>Returns the Read-Only string buffer.</returns>
        System.Collections.ObjectModel.ReadOnlyCollection<string> Buffer { get; }
    }

    /// <summary>
    /// Defines an object that implements the string writer methods. This object is intended to be used for derivation purposes, as it
    /// implements all of the required methods/properties, but also provides overrides for classes to handle the methods in specific ways.
    /// </summary>
    public class StandardStringWriter : IStringWriter
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        public StandardStringWriter()
        { }          
    
        #region IStringWriter Members

        /// <summary>
        /// The event that's raised when a string has been written.
        /// </summary>
        public event StringWrittenHandler StringWritten;

        /// <summary>
        /// Terminates the current line and add a new one.
        /// </summary>
        public void  WriteLine()
        {
 	        this.DoWriteLine();
            this.FireStringWritten("");
        }

        /// <summary>
        /// Write the string to the current line and add a new one.
        /// </summary>
        /// <param name="line">The line to add to the existing ones.</param>
        public void WriteLine(string line)
        {
 	        this.DoWriteLine(line);
            this.FireStringWritten(line);
        }

        /// <summary>
        /// Wrtie the formatted string to the current line and add a new one.
        /// </summary>
        /// <param name="format">A formatted string.</param>
        /// <param name="arg">An array of zero or more arguments.</param>
        public void WriteLine(string format, params object[] arg)
        {
            this.DoWriteLine(format, arg);
            this.FireStringWritten(string.Format(format, arg));
        }

        /// <summary>
        /// Fire an event to all listeners that a string has been written.
        /// </summary>
        /// <param name="value">The string that was written.</param>
        protected void FireStringWritten(string value)
        {
            if (this.StringWritten != null)
            {
                this.StringWritten(this, new StringWrittenEventArgs(value + Environment.NewLine));
            }
        }

        /// <summary>
        /// Override to perform additional functionality when the specified WriteLine is called.
        /// </summary>
        protected virtual void DoWriteLine()
        { }

        /// <summary>
        /// Override to perform additional functionality when the specified WriteLine is called.
        /// </summary>
        protected virtual void DoWriteLine(string line)
        { }

        /// <summary>
        /// Override to perform additional functionality when the specified WriteLine is called.
        /// </summary>
        protected virtual void DoWriteLine(string format, params object[] arg)
        { }

        #endregion
    }
    
    /// <summary>
    /// Defines an IStringWriter object that stores the string data. This also exposes string change events as well.
    /// </summary>
    public class BufferedStringWriter : StandardStringWriter, IBufferedStringWriter
    {
        // The internal string buffer.
        private List<string> m_strings = new List<string>();

        /// <summary>
        /// The event that's raised when the strings have been cleared.
        /// </summary>
        public event EventHandler StringsCleared;

        /// <summary>
        /// Constructor. This should be called if no existing collection exists.
        /// </summary>
        public BufferedStringWriter()            
        { }

        /// <summary>
        /// Constructor. This should be called to pass along an existing collection.
        /// Note: Newlines are automatically added to the end of each line.
        /// </summary>
        /// <param name="collection">An existing Collection object.</param>
        public BufferedStringWriter(System.Collections.ICollection collection)
            : this(collection, true)
        { }

        /// <summary>
        /// Constructor. This should be called to pass along an existing collection.
        /// </summary>
        /// <param name="collection">An existing Collection object.</param>
        /// <param name="appendNewlines">Specify whether to append Newlines to each item in the collection.</param>
        public BufferedStringWriter(System.Collections.ICollection collection, bool appendNewlines)
        {
            if (collection != null)
            {
                foreach (object obj in collection)
                {
                    string temp = obj.ToString();

                    if (!string.IsNullOrEmpty(temp))
                    {
                        if (appendNewlines)
                        {
                            temp += Environment.NewLine;
                        }

                        this.m_strings.Add(temp);
                    }
                }
            }
        }

        /// <summary>
        /// Constructor. This should be called to pass along an existing generic collection.
        /// Note: Newlines are automatically added to the end of each line.
        /// </summary>
        /// <param name="collection">An existing generic Collection object.</param>
        public BufferedStringWriter(ICollection<string> collection)
            : this(collection, true)
        { }

        /// <summary>
        /// Constructor. This should be called to pass along an existing generic collection.
        /// </summary>
        /// <param name="collection">An existing generic Collection object.</param>
        /// <param name="appendNewlines">Specify whether to append Newlines to each item in the collection.</param>
        public BufferedStringWriter(ICollection<string> collection, bool appendNewlines)
        {
            if (collection != null)
            {
                foreach (object obj in collection)
                {
                    string temp = obj.ToString();

                    if (!string.IsNullOrEmpty(temp))
                    {
                        if (appendNewlines)
                        {
                            temp += Environment.NewLine;
                        }

                        this.m_strings.Add(temp);
                    }
                }
            }
        }

        /// <summary>
        /// Constructor. This should be called to pass along an existing StringBuilder.
        /// </summary>
        /// <param name="strings">An existing StringCollection object.</param>
        public BufferedStringWriter(StringBuilder strings)
        {
            if (strings != null)
            {
                string[] tempArr = strings.ToString().Split(Environment.NewLine.ToCharArray());

                if (tempArr != null)
                {
                    foreach (string line in tempArr)
                    {
                        // In this case, we do need to add in the Newline since we split on it!
                        this.m_strings.Add(line + Environment.NewLine);
                    }
                }
            }
        }

        #region IBufferedStringWriter Members

        /// <summary>
        /// Get the string buffer.
        /// </summary>
        /// <returns>Returns the Read-Only string buffer.</returns>
        public System.Collections.ObjectModel.ReadOnlyCollection<string> Buffer
        {
            get { return this.m_strings.AsReadOnly(); }
        }

        /// <summary>
        /// Get the line count.
        /// </summary>
        public int Count
        {
            get { return this.m_strings.Count; }
        }

        /// <summary>
        /// Clears out all lines.
        /// </summary>
        public void Clear()
        {
            this.m_strings.Clear();

            // Notify listeners.
            if (this.StringsCleared != null)
            {
                this.StringsCleared(this, EventArgs.Empty);
            }

            this.DoClear();
        }

        /// <summary>
        /// Override this method to perform functionality after the buffer is cleared.
        /// </summary>
        protected virtual void DoClear()
        { }

        /// <summary>
        /// Terminates the current line and add a new one.
        /// </summary>
        protected override void DoWriteLine()
        {
            this.m_strings.Add(Environment.NewLine);
        }

        /// <summary>
        /// Write the string to the current line and add a new one.
        /// </summary>
        /// <param name="line">The line to add to the existing ones.</param>
        protected override void DoWriteLine(string line)
        {
            this.m_strings.Add(line + Environment.NewLine);
        }

        /// <summary>
        /// Wrtie the formatted string to the current line and add a new one.
        /// </summary>
        /// <param name="format">A formatted string.</param>
        /// <param name="arg">An array of zero or more arguments.</param>
        protected override void DoWriteLine(string format, params object[] arg)
        {
            this.m_strings.Add(string.Format(format, arg) + Environment.NewLine);            
        }        
        #endregion
    }

    /// <summary>
    /// Defines a string writer object that simply passes the strings on to the Console.
    /// </summary>
    public class ConsoleStringWriter : StandardStringWriter
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        public ConsoleStringWriter()
        { }

        /// <summary>
        /// Constructor. This should be called when an existing collection exists.
        /// </summary>
        /// <param name="collection">An existing Collection object.</param>
        public ConsoleStringWriter(System.Collections.ICollection collection)
        {
            foreach (object obj in collection)
            {
                Console.WriteLine(obj.ToString());
            }
        }

        /// <summary>
        /// Constructor. This should be called when an existing collection exists.
        /// </summary>
        /// <param name="collection">An existing generic Collection object.</param>
        public ConsoleStringWriter(ICollection<string> collection)
        {
            foreach (string line in collection)
            {
                Console.WriteLine(line);
            }
        }

        /// <summary>
        /// Constructor. This should be called when an existing StringBuilder exists.
        /// </summary>
        /// <param name="strings">The excis</param>
        public ConsoleStringWriter(StringBuilder strings)
        {
            string[] tempArr = strings.ToString().Split(Environment.NewLine.ToCharArray());

            if (tempArr != null)
            {
                foreach (string line in tempArr)
                {
                    Console.WriteLine(line);
                }
            }
        }

        /// <summary>
        /// Writes a NewLine to the Console.
        /// </summary>
        protected override void DoWriteLine()
        {
            Console.WriteLine();
        }

        /// <summary>
        /// Writes the specified string to the Console.
        /// </summary>
        /// <param name="line">The text to write to the Console.</param>
        protected override void DoWriteLine(string line)
        {
            Console.WriteLine(line);
        }

        /// <summary>
        /// Writes the specified formatted string to the Console.
        /// </summary>
        /// <param name="format">The formatted string.</param>
        /// <param name="arg">The format argument(s).</param>
        protected override void DoWriteLine(string format, params object[] arg)
        {
            Console.WriteLine(format, arg);
        }
    }

    /// <summary>
    /// The string written event data.
    /// </summary>
    public class StringWrittenEventArgs : System.EventArgs
    {
        private string m_stringValue;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="stringValue">The string that was written.</param>
        public StringWrittenEventArgs(string stringValue)
        {
            this.m_stringValue = stringValue;
        }

        /// <summary>
        /// Get the string that was added.
        /// </summary>
        public string Value
        {
            get { return this.m_stringValue; }
        }
    }
}
