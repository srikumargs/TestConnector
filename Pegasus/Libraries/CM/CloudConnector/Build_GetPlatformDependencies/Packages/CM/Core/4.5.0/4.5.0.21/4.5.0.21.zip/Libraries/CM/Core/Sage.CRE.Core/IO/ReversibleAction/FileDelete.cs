using System;
using System.Collections.Generic;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Delete one or more files using the ReversibleAction pattern.
    /// The construction of a FileDelete object copies the specified files.
    /// If the object is disposed without calling the Commit() method, then the file copy is reversed.
    /// 
    /// Typical usage:
    /// 
    /// using (FileDelete fileDelete = new FileDelete(@"C:\srcFile.txt"))
    /// {
    ///     fileDelete.Forward();
    ///     
    ///     // execute some code that might throw. If the code throws, we need to restore the original file.
    /// 
    ///     fileDelete.Commit();
    /// }
    /// </summary>
    public class FileDelete : ReversibleActionBase
    {
        /// <summary>
        /// Deletes a file.
        /// </summary>
        /// <param name="file"></param>
        public FileDelete(string file)
        {
            _filesToBeDeleted.Add(file);
        }

        /// <summary>
        /// Deletes a set of files.
        /// </summary>
        /// <param name="files">A list of files to delete.</param>
        public FileDelete(System.Collections.ObjectModel.Collection<string> files)
        {
            _filesToBeDeleted = files;
        }

        #region Protected methods
        /// <summary>
        /// Delete the file(s).
        /// </summary>
        public override void Forward()
        {
            base.Forward();
            foreach (string file in _filesToBeDeleted)
            {
                string renamedFile = System.IO.Path.Combine(System.IO.Path.GetTempPath(),String.Format(System.Globalization.CultureInfo.InvariantCulture,StringsNoTran.ReversibleFileSystemAction_TempObjectCatenationFormat_Internal, file, _actionID));
                if (System.IO.File.Exists(file))
                {
                    _filesDeleted.Add(file, renamedFile);
                }
            }

            moveFiles = new FileMove(_filesDeleted);
            moveFiles.Forward();
        }

        /// <summary>
        /// Undo the deletion of the file(s).
        /// </summary>
        public override void Reverse()
        {
            base.Reverse();
            moveFiles.Dispose();
        }

        /// <summary>
        /// Permenantly delete the file(s).
        /// </summary>
        public override void Commit()
        {
            base.Commit();
            moveFiles.Commit();
            foreach (KeyValuePair<string, string> kvp in _filesDeleted)
            {
                string dest = kvp.Value;
                if (System.IO.File.Exists(dest)) System.IO.File.Delete(dest);
            }
        }
        #endregion

        #region Private members
        private System.Collections.ObjectModel.Collection<string> _filesToBeDeleted = new System.Collections.ObjectModel.Collection<string>();
        private Dictionary<string, string> _filesDeleted = new Dictionary<string, string>();
        private string _actionID = System.DateTime.Now.ToFileTimeUtc().ToString(System.Globalization.CultureInfo.InvariantCulture);
        private FileMove moveFiles;
        #endregion

    }
}
