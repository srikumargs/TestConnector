using System;
using System.Collections;
using System.Collections.Specialized;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Channels.Ipc;
using System.Globalization;
using System.Security.Principal;
using System.Security.AccessControl;
using Sage.Diagnostics;

namespace Sage.Remoting
{

    /// <summary>
    /// Used to specify a supported channel types
    /// </summary>
    public enum ChannelType
    {
        /// <summary>
        /// The channel type is invalid
        /// </summary>
        /// <remarks>
        /// This is default value the runtime automatically initializes any ChannelType instance to
        /// </remarks>
        None = 0,

        /// <summary>
        /// A named pipe channel
        /// </summary>
        NamedPipe,

        /// <summary>
        /// A TCP channel
        /// </summary>
        Tcp,

        Ipc
    }

    /// <summary>
    /// This class facilitates the registration of client remoting channels for remote callbacks.
    /// OPtionally, you can register a server channel for callbacks.
    /// </summary>
    [ComVisible(false)]
    public sealed class ChannelRegistrar
    {
        private static ChannelList _serverChannelList = new ServerChannelList();
        private static ChannelList _clientChannelList = new ClientChannelList();

        private const string TcpSubStr = "tcp";
        private const string PipeSubStr = "pipe";
        private const string IpcSubStr = "ipc";

        #region static methods
        /// <summary>
        /// Explicitly register a pipe client channel if none registered yet.
        /// </summary>
        public static void RegisterPipe()
        {
            ChannelRegistrar r = new ChannelRegistrar();
            r.RegisterClient(ChannelType.NamedPipe);
            r.RegisterServer(ChannelType.NamedPipe);
        }

        /// <summary>
        /// This is the general case where we want to reg a named pipe
        /// </summary>
        /// <param name="pipeName"></param>
        public static void RegisterPipe(string pipeName)
        {
            ChannelRegistrar r = new ChannelRegistrar();
            r.RegisterClient(ChannelType.NamedPipe);
            ListDictionary propBag = new ListDictionary();
            propBag.Add("pipe", pipeName);
            r.RegisterServer(ChannelType.NamedPipe, propBag);
        }

        /// <summary>
        /// Fine tune the pipe registration
        /// </summary>
        /// <param name="clientPropBag"></param>
        /// <param name="serverPropBag"></param>
        public static void RegisterPipe(IDictionary clientPropBag, IDictionary serverPropBag)
        {
            ChannelRegistrar r = new ChannelRegistrar();
            r.RegisterClient(ChannelType.NamedPipe, clientPropBag);
            r.RegisterServer(ChannelType.NamedPipe, serverPropBag);
        }

        /// <summary>
        /// Us this for inter machine communication that needs callbacks
        /// </summary>
        public static void RegisterClientAndCallbackPipe()
        {
            // Environment.MachineName is the same as the NetBIOS name of local computer (the COMPUTERNAME environment
            // variable) not the DNS host name.  This value is always truncated to 15 characters.  Consequently, we
            // cannot compare this against our DNS host name.  Dns.GetHostName() give us what we want.

            ChannelRegistrar r = new ChannelRegistrar();
            r.RegisterClient(ChannelType.NamedPipe);
            ListDictionary propBag = new ListDictionary();
            propBag.Add("pipe", "Auto");
            propBag.Add("machine", Dns.GetHostName());
            r.RegisterServer(ChannelType.NamedPipe, propBag);
        }

        /// <summary>
        /// Explicitly unregister the named pipe client channel
        /// </summary>
        public static void UnregisterPipe()
        {
            ChannelRegistrar r = new ChannelRegistrar();
            r.Unregister(ChannelType.NamedPipe);
        }

        /// <summary>
        /// Explicitly unregister the tcp client channel
        /// </summary>
        public static void UnregisterTcp()
        {
            ChannelRegistrar r = new ChannelRegistrar();
            r.Unregister(ChannelType.Tcp);
        }

        public static void UnregisterIpc()
        {
            ChannelRegistrar r = new ChannelRegistrar();
            r.Unregister(ChannelType.Ipc);
        }

        /// <summary>
        /// Find the first free (unused) port in a range
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <returns></returns>
        public static int GetFreePort(int min, int max)
        {
            int port = 0;
            Assertions.Assert(min <= max);

            for (int p = min; p <= max; p++)
            {
                Socket s = new Socket(AddressFamily.InterNetwork,
                    SocketType.Stream,
                    ProtocolType.Tcp);
                try
                {
                    s.Bind(new IPEndPoint(IPAddress.Any, p));
                    s.Close();
                    port = p;
                    break;
                }
                catch (SocketException ex)
                {
                    // EADDRINUSE?
                    if (ex.ErrorCode == 10048)
                        continue;
                    else
                        throw;
                }
            }
            Assertions.Assert(port != 0);
            if (port == 0)
            {
                throw new SocketException(10048);
            }
            return port;
        }


        /// <summary>
        /// Use this from servers that publish objects on the tcp channel
        /// and need callback availability on marshaled objects like marshaled targets
        /// </summary>
        /// <param name="channelName"></param>
        /// <param name="portNum"></param>
        public static void RegisterTcpServerWithCallback(string channelName, int portNum)
        {
            RegisterTcpServerWithCallback(channelName, portNum, false);
        }

        /// <summary>
        /// Registers the TCP server with callback.
        /// </summary>
        /// <param name="channelName">Name of the channel.</param>
        /// <param name="portNum">The port num.</param>
        /// <param name="secure">if set to <c>true</c> [secure].</param>
        public static void RegisterTcpServerWithCallback(string channelName, int portNum, bool secure)
        {
            ListDictionary propBag = new ListDictionary();
            propBag.Add("name", channelName);
            propBag.Add("port", portNum);
            propBag.Add("secure", Convert.ToString(secure));
            ChannelRegistrar chanReg = new ChannelRegistrar();
            chanReg.RegisterServer(ChannelType.Tcp, propBag);

            RegisterTcpClient(secure);
        }

        public static void RegisterEncryptedTcpServerWithClientCallbackChannel(String serverChannelName, Int32 serverPortNumber, IDictionary clientChannelProperties, String cryptoAlgorithmName, Byte[] key)
        {
            ListDictionary propBag = new ListDictionary();
            propBag.Add("name", serverChannelName);
            propBag.Add("port", serverPortNumber);
            propBag.Add("secure", Convert.ToString(false));
            propBag.Add("cryptoAlgorithmName", cryptoAlgorithmName);
            propBag.Add("keyAsBase64", Convert.ToBase64String(key));
            ChannelRegistrar chanReg = new ChannelRegistrar();
            chanReg.RegisterServer(ChannelType.Tcp, propBag);

            RegisterEncryptedTcpClient(cryptoAlgorithmName, key);
        }
        
        public static void RegisterEncryptedTcpServerWithClientCallbackChannel(String serverChannelName, Int32 serverPortNumber, IDictionary clientChannelProperties, String cryptoAlgorithmName, String keyFilePath)
        {
            ListDictionary propBag = new ListDictionary();
            propBag.Add("name", serverChannelName);
            propBag.Add("port", serverPortNumber);
            propBag.Add("secure", Convert.ToString(false));
            propBag.Add("cryptoAlgorithmName", cryptoAlgorithmName);
            propBag.Add("keyFilePath", keyFilePath);
            ChannelRegistrar chanReg = new ChannelRegistrar();
            chanReg.RegisterServer(ChannelType.Tcp, propBag);

            RegisterEncryptedTcpClient(cryptoAlgorithmName, keyFilePath);
        }

        public static void RegisterEncryptedIpcServer(String serverPortName, String cryptoAlgorithmName, Byte[] key)
        {
            ListDictionary propBag = new ListDictionary();
            propBag.Add("name", serverPortName);
            propBag.Add("portName", serverPortName);
            propBag.Add("cryptoAlgorithmName", cryptoAlgorithmName);
            propBag.Add("keyAsBase64", Convert.ToBase64String(key));
            ChannelRegistrar chanReg = new ChannelRegistrar();
            chanReg.RegisterServer(ChannelType.Ipc, propBag);
        }
        
        public static void RegisterEncryptedIpcServer(String serverPortName, String cryptoAlgorithmName, String keyFilePath)
        {
            ListDictionary propBag = new ListDictionary();
            propBag.Add("name", serverPortName);
            propBag.Add("portName", serverPortName);
            propBag.Add("cryptoAlgorithmName", cryptoAlgorithmName);
            propBag.Add("keyFilePath", keyFilePath);
            ChannelRegistrar chanReg = new ChannelRegistrar();
            chanReg.RegisterServer(ChannelType.Ipc, propBag);
        }


        /// <summary>
        /// Registers the TCP client.
        /// </summary>
        public static void RegisterTcpClient()
        {
            RegisterTcpClient(false);
        }

        /// <summary>
        /// Registers the TCP client.
        /// </summary>
        /// <param name="secure">if set to <c>true</c> [secure].</param>
        public static void RegisterTcpClient(bool secure)
        {
            ListDictionary propBag = new ListDictionary();
            propBag.Add("secure", Convert.ToString(secure));

            // register call back channel
            ChannelRegistrar chanReg = new ChannelRegistrar();
            chanReg.RegisterClient(ChannelType.Tcp, propBag);
        }

        public static void RegisterEncryptedTcpClient(String cryptoAlgorithmName, Byte[] key)
        {
            ListDictionary propBag = new ListDictionary();
            propBag.Add("cryptoAlgorithmName", cryptoAlgorithmName);
            propBag.Add("keyAsBase64", Convert.ToBase64String(key));

            // register call back channel
            ChannelRegistrar chanReg = new ChannelRegistrar();
            chanReg.RegisterClient(ChannelType.Tcp, propBag);
        }
        
        public static void RegisterEncryptedTcpClient(String cryptoAlgorithmName, String keyFilePath)
        {
            ListDictionary propBag = new ListDictionary();
            propBag.Add("cryptoAlgorithmName", cryptoAlgorithmName);
            propBag.Add("keyFilePath", keyFilePath);

            // register call back channel
            ChannelRegistrar chanReg = new ChannelRegistrar();
            chanReg.RegisterClient(ChannelType.Tcp, propBag);
        }

        #endregion // static methods

        #region public methods
        /// <summary>
        /// Register the given channel type if not already registered
        /// </summary>
        /// <param name="url">the url to activate - will indicate channel type</param>
        public void RegisterClient(string url)
        {
            IDictionary propBag = null;
            ChannelKey channelKey = CreateChannelKeyAndProperties(url, out propBag);
            RegisterClient(channelKey.Type, propBag);
        }

        /// <summary>
        /// Register the given channel type if not already registered
        /// </summary>
        /// <param name="channelType">the channel type</param>
        public void RegisterClient(ChannelType channelType)
        {
            DoRegister(ChannelRegistrar.CreateChannelKey(channelType), _clientChannelList, null);
        }

        /// <summary>
        /// Register the given channel type if not already registered
        /// </summary>
        /// <param name="channelType">the channel type</param>
        /// <param name="propBag"></param>
        public void RegisterClient(ChannelType channelType, IDictionary propBag)
        {
            DoRegister(ChannelRegistrar.CreateChannelKey(channelType, propBag), _clientChannelList, propBag);
        }

        /// <summary>
        /// Register a callback (server) channel for  events and running targets
        /// </summary>
        /// <param name="channelType"></param>
        public void RegisterServer(ChannelType channelType)
        {
            DoRegister(ChannelRegistrar.CreateChannelKey(channelType), _serverChannelList, null);
        }

        /// <summary>
        /// Register a server channel for events and running targets
        /// </summary>
        /// <param name="channelType"></param>
        /// <param name="propBag"></param>
        public void RegisterServer(ChannelType channelType, IDictionary propBag)
        {
            DoRegister(ChannelRegistrar.CreateChannelKey(channelType, propBag), _serverChannelList, propBag);
        }

        /// <summary>
        /// Unregister the underlying client channel if registered
        /// </summary>
        /// <param name="url"></param>
        public void UnregisterClient(string url)
        {
            IDictionary propBag = null;
            ChannelKey channelKey = CreateChannelKeyAndProperties(url, out propBag);
            DoUnregister(channelKey, _clientChannelList);
        }
        #endregion // public methods

        #region internal helpers
        /// <summary>
        /// Factory method to create a ChannelKey from a channel type
        /// </summary>
        /// <param name="channelType"></param>
        /// <returns></returns>
        internal static ChannelKey CreateChannelKey(ChannelType channelType)
        {
            return ChannelRegistrar.CreateChannelKey(channelType, null);
        }

        /// <summary>
        /// Factory method to create a ChannelKey from a channel type using the supplied additional properties
        /// </summary>
        /// <param name="channelType"></param>
        /// <param name="propBag"></param>
        /// <returns></returns>
        internal static ChannelKey CreateChannelKey(ChannelType channelType, IDictionary propBag)
        {
            ChannelKey result = null;
            if (propBag == null)
            {
                result = new ChannelKey(channelType);
            }
            else
            {
                if (channelType == ChannelType.NamedPipe)
                {
                    string pipe = string.Empty;
                    if (propBag.Contains("pipe"))
                    {
                        pipe = (string)propBag["pipe"];
                    }
                    result = new ChannelKey(channelType, string.Format(CultureInfo.InvariantCulture, "pipe:{0}", pipe));
                }
                else if (channelType == ChannelType.Tcp)
                {
                    string machineName = string.Empty;
                    if (propBag.Contains("machineName"))
                    {
                        machineName = (string)propBag["machineName"];
                    }
                    string port = string.Empty;
                    if (propBag.Contains("port"))
                    {
                        port = Convert.ToString((int)propBag["port"]);
                    }
                    result = new ChannelKey(channelType, string.Format(CultureInfo.InvariantCulture, "tcp:{0}:{1}:secure={2}", machineName, port, (propBag.Contains("secure")) ? (string)propBag["secure"] : "false"));
                }
                else if (channelType == ChannelType.Ipc)
                {
                    string portName = string.Empty;
                    if (propBag.Contains("portName"))
                    {
                        portName = (string)propBag["portName"];
                    }
                    result = new ChannelKey(channelType, string.Format(CultureInfo.InvariantCulture, "ipc:{0}", portName));
                }
            }

            return result;
        }

        /// <summary>
        /// Factory method to create a ChannelKey and properties from an url
        /// </summary>
        /// <param name="url"></param>
        /// <param name="propBag"></param>
        /// <returns></returns>
        internal static ChannelKey CreateChannelKeyAndProperties(string url, out IDictionary propBag)
        {
            propBag = new ListDictionary();
            string[] splitStrings = url.Split('/');
            if (splitStrings == null || splitStrings.Length < 3)
            {
                throw new NotSupportedException(Strings.ClientRemotingChannelRegistrationFailed + url);
            }

            ChannelType channelType = ChannelType.None;
            if (splitStrings[0].ToLower().StartsWith(TcpSubStr) == true)
            {
                channelType = ChannelType.Tcp;
                string[] machineAndPort = splitStrings[2].Split(':');
                if (machineAndPort == null || machineAndPort.Length < 2)
                {
                    throw new NotSupportedException(Strings.ClientRemotingChannelRegistrationFailed + url);
                }
                propBag["machineName"] = machineAndPort[0];
                propBag["port"] = Convert.ToInt32(machineAndPort[1]);
            }
            else if (splitStrings[0].ToLower().StartsWith(PipeSubStr) == true)
            {
                channelType = ChannelType.NamedPipe;
                propBag["name"] = splitStrings[2];
                propBag["pipe"] = splitStrings[2];
            }
            else if (splitStrings[0].ToLower().StartsWith(IpcSubStr) == true)
            {
                channelType = ChannelType.Ipc;
                propBag["portName"] = splitStrings[2];
            }
            else
            {
                throw new NotSupportedException(Strings.ClientRemotingChannelRegistrationFailed + url);
            }

            return CreateChannelKey(channelType, propBag);
        }

        /// <summary>
        /// Unregister the channel specified by the channel key
        /// </summary>
        /// <param name="channelKey"></param>
        internal void UnregisterClient(ChannelKey channelKey)
        {
            DoUnregister(channelKey, _clientChannelList);
        }
        #endregion

        #region Private helpers
        /// <summary>
        /// registration helper uses channel list polymorphically
        /// </summary>
        /// <param name="channelKey"></param>
        /// <param name="channelList"></param>
        /// <param name="propBag"></param>
        private void DoRegister(ChannelKey channelKey, ChannelList channelList, IDictionary propBag)
        {
            lock (channelList)
            {
                IChannel channel = channelList.MakeChannel(channelKey, propBag);
                if (channel != null)
                {
                    InfoTrace.WriteLine(this, "Registering channel with ChannelServices '{0}' in Appdomain '{1}'", channel.ChannelName, AppDomain.CurrentDomain.FriendlyName);
                    if (propBag != null && propBag.Contains("secure"))
                    {
                        ChannelServices.RegisterChannel(channel, Convert.ToBoolean(propBag["secure"]));
                    }
                    else
                    {
                        ChannelServices.RegisterChannel(channel);
                    }
                    channelList.AddChannel(channelKey, channel);
                }
            }
        }

        /// <summary>
        /// Unregister the underlying client channel if registered
        /// </summary>
        /// <param name="channelType"></param>
        private void Unregister(ChannelType channelType)
        {
            DoUnregister(channelType, _clientChannelList);
            DoUnregister(channelType, _serverChannelList);
        }


        /// <summary>
        /// un-registration helper uses channel list polymorphically
        /// </summary>
        /// <param name="channelKey"></param>
        /// <param name="channelList"></param>
        private void DoUnregister(ChannelKey channelKey, ChannelList channelList)
        {
            lock (channelList)
            {
                IChannel channel = channelList.GetChannel(channelKey);
                if (channel != null)
                {
                    InfoTrace.WriteLine(this, "Unregistering channel with ChannelServices '{0}' in AppDomain '{1}'", channel.ChannelName, AppDomain.CurrentDomain.FriendlyName);
                    ChannelServices.UnregisterChannel(channel);
                    channelList.RemoveChannel(channel);
                }
            }
        }

        /// <summary>
        /// un-registration helper uses channel list polymorphically
        /// </summary>
        /// <param name="channelType"></param>
        /// <param name="channelList"></param>
        private void DoUnregister(ChannelType channelType, ChannelList channelList)
        {
            lock (channelList)
            {
                IChannel[] channels = channelList.GetChannelsForType(channelType);
                foreach (IChannel channel in channels)
                {
                    InfoTrace.WriteLine(this, "Unregistering channel with ChannelServices '{0}' in AppDomain '{1}'", channel.ChannelName, AppDomain.CurrentDomain.FriendlyName);
                    ChannelServices.UnregisterChannel(channel);
                    channelList.RemoveChannel(channel);
                }

                if (channelType == ChannelType.NamedPipe)
                {
                    PipeConnectionPoolManager.Cleanup();
                }
            }
        }
        #endregion // private helpers
    }

    /// <summary>
    /// A specialization of the ChannelRegistrar which allows code to register and unregister a channel in different locations.
    /// A request to Unregister will actually only cause a real unregistration with ChannelServices if the count goes to zero.
    /// </summary>
    [ComVisible(false)]
    public sealed class CountedChannelRegistrar
    {
        #region public methods
        /// <summary>
        /// Registers a client channel in a ref counted manner.  Calls should be balanced with
        /// an equal number of calls to RefCountedUnregisterClient.
        /// </summary>
        /// <param name="url"></param>
        public static void RegisterClient(string url)
        {
            IDictionary propBag = null;
            ChannelKey channelKey = ChannelRegistrar.CreateChannelKeyAndProperties(url, out propBag);

            lock (_clientChannelRegistrationCounts.SyncRoot)
            {
                // Search of prior registrations for this channel.  Increment if it exists
                // or add it if it does not.
                if (_clientChannelRegistrationCounts.ContainsKey(channelKey))
                {
                    int count = (int)_clientChannelRegistrationCounts[channelKey];
                    VerboseTrace.WriteLine(null, "channel '{0}' exists in AppDomain '{1}', incrementing count to {2}", channelKey.ToString(), AppDomain.CurrentDomain.FriendlyName, count + 1);
                    _clientChannelRegistrationCounts[channelKey] = count + 1;
                }
                else
                {
                    VerboseTrace.WriteLine(null, "creating channel '{0}' in AppDomain '{1}'", channelKey.ToString(), AppDomain.CurrentDomain.FriendlyName);
                    ChannelRegistrar r = new ChannelRegistrar();
                    r.RegisterClient(channelKey.Type, propBag);
                    _clientChannelRegistrationCounts[channelKey] = 1;
                }
            }
        }

        /// <summary>
        /// Unregisters a client channel in a ref counted manner.  Calls should be balanced with
        /// an equal number of calls to RefCountedUnregisterClient.
        /// </summary>
        /// <param name="url"></param>
        public static void UnregisterClient(string url)
        {
            IDictionary propBag = null;
            ChannelKey channelKey = ChannelRegistrar.CreateChannelKeyAndProperties(url, out propBag);

            lock (_clientChannelRegistrationCounts.SyncRoot)
            {
                // Search of prior registrations for this channel.  Decrement it if it exists
                // and there is another registration outstanding, or remove it otherwise.
                if (_clientChannelRegistrationCounts.ContainsKey(channelKey))
                {
                    int count = (int)_clientChannelRegistrationCounts[channelKey];
                    if (count == 1)
                    {
                        VerboseTrace.WriteLine(null, "removing channel '{0}' in AppDomain '{1}'", channelKey.ToString(), AppDomain.CurrentDomain.FriendlyName);
                        ChannelRegistrar r = new ChannelRegistrar();
                        r.UnregisterClient(channelKey);
                        _clientChannelRegistrationCounts.Remove(channelKey);
                    }
                    else
                    {
                        VerboseTrace.WriteLine(null, "channel '{0}' in AppDomain '{1}' has count > 1, decrementing count to {2}", channelKey.ToString(), AppDomain.CurrentDomain.FriendlyName, count - 1);
                        _clientChannelRegistrationCounts[channelKey] = count - 1;
                    }
                }
                else
                {
                    Assertions.Assert(false, string.Format(CultureInfo.InvariantCulture, Strings.InvalidUsageAttemptingToUnregisterNotRegisteredFormat, channelKey.ToString()));
                }
            }
        }
        #endregion

        #region Private fields
        private static Hashtable _clientChannelRegistrationCounts = new Hashtable();
        #endregion
    }

    /// <summary>
    /// This class is used as a channel container and factory
    /// </summary>
    internal abstract class ChannelList
    {
        protected ListDictionary _channelList = new ListDictionary();

        /// <summary>
        /// Add a channel to the underlying collection
        /// </summary>
        /// <param name="channelKey"></param>
        /// <param name="channel"></param>
        internal void AddChannel(ChannelKey channelKey, IChannel channel)
        {
            _channelList[channelKey] = channel;
        }

        /// <summary>
        /// Remove a channel from the underlying collection
        /// </summary>
        /// <param name="channelToRemove"></param>
        internal void RemoveChannel(IChannel channelToRemove)
        {
            foreach (DictionaryEntry entry in _channelList)
            {
                if (entry.Value == channelToRemove)
                {
                    _channelList.Remove(entry.Key);
                    break;
                }
            }
        }

        /// <summary>
        /// Get a channel from the underlying collection (can be null if a match doesn't exist)
        /// </summary>
        /// <param name="channelKey"></param>
        /// <returns></returns>
        internal IChannel GetChannel(ChannelKey channelKey)
        {
            IChannel result = null;

            // test to see if the requested channel is an "anonymous channel" ... if so,
            // then any channel with the requisite ChannelType will suffice
            if (channelKey.IsAnonymousChannel)
            {
                foreach (DictionaryEntry entry in _channelList)
                {
                    if ((entry.Key as ChannelKey).Type == channelKey.Type)
                    {
                        result = (IChannel)entry.Value;
                        break;
                    }
                }
            }
            else
            {
                result = (IChannel)_channelList[channelKey];
            }

            return result;
        }

        /// <summary>
        /// Gets an array of all registered channels matching the specified type
        /// </summary>
        /// <param name="channelType"></param>
        /// <returns></returns>
        internal IChannel[] GetChannelsForType(ChannelType channelType)
        {
            ArrayList result = new ArrayList();

            foreach (DictionaryEntry entry in _channelList)
            {
                if ((entry.Key as ChannelKey).Type == channelType)
                {
                    result.Add(entry.Value);
                }
            }

            return (IChannel[])result.ToArray(typeof(IChannel));
        }

        /// <summary>
        /// Force an override of the factory method
        /// </summary>
        /// <param name="channelKey"></param>
        /// <param name="propBag"></param>
        /// <returns></returns>
        internal abstract IChannel MakeChannel(ChannelKey channelKey, IDictionary propBag);
    }

    /// <summary>
    /// Wrap a collection of client channels
    /// </summary>
    internal class ClientChannelList : ChannelList
    {
        /// <summary>
        /// Override to make a tcp or named-pipe channel
        /// </summary>
        /// <param name="channelKey"></param>
        /// <param name="propBag"></param>
        /// <returns></returns>
        internal override IChannel MakeChannel(ChannelKey channelKey, IDictionary propBag)
        {
            VerboseTrace.WriteLine(this, "MakeChannel '{0}' in AppDomain '{1}'", channelKey.ToString(), AppDomain.CurrentDomain.FriendlyName);

            IChannel channel = null;
            if (GetChannel(channelKey) == null)
            {
                if (channelKey.Type == ChannelType.NamedPipe)
                {
                    channel = (propBag == null) ? new PipeClientChannel() : new PipeClientChannel(propBag, null);
                }
                else if (channelKey.Type == ChannelType.Tcp)
                {
                    BinaryClientFormatterSinkProvider binaryFormatter = new BinaryClientFormatterSinkProvider();
                    if (propBag.Contains("cryptoAlgorithmName"))
                    {
                        if (propBag.Contains("keyFilePath"))
                        {
                            binaryFormatter.Next = new EncryptionClientSinkProvider(propBag["cryptoAlgorithmName"].ToString(), propBag["keyFilePath"].ToString());
                        }
                        else
                        {
                            binaryFormatter.Next = new EncryptionClientSinkProvider(propBag["cryptoAlgorithmName"].ToString(), Convert.FromBase64String(propBag["keyAsBase64"].ToString()));
                        }
                    }

                    if (propBag == null)
                    {
                        propBag = new ListDictionary();
                        propBag.Add("port", 0);
                    }
                    channel = new TcpClientChannel(propBag, binaryFormatter);
                }
            }
            return channel;
        }
    }

    /// <summary>
    /// Wrap a collection of server callback channels
    /// </summary>
    internal class ServerChannelList : ChannelList
    {
        /// <summary>
        /// Override to make a PipeServerChannel - Tcp Channel callback
        /// already handled by client channel created with port 0
        /// </summary>
        /// <param name="channelKey"></param>
        /// <param name="propBag"></param>
        /// <returns></returns>
        internal override IChannel MakeChannel(ChannelKey channelKey, IDictionary propBag)
        {
            VerboseTrace.WriteLine(this, "MakeChannel '{0}' in AppDomain '{1}'", channelKey.ToString(), AppDomain.CurrentDomain.FriendlyName);

            IChannel channel = null;
            if (GetChannel(channelKey) == null)
            {
                if (channelKey.Type == ChannelType.NamedPipe)
                {
                    channel = (propBag == null) ? new PipeServerChannel("Auto") : new PipeServerChannel(propBag, null);
                }
                else if (channelKey.Type == ChannelType.Tcp)
                {
                    BinaryServerFormatterSinkProvider binaryFormatter = new BinaryServerFormatterSinkProvider();
                    binaryFormatter.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;

                    IServerChannelSinkProvider sinkProvider = null;
                    if (propBag.Contains("cryptoAlgorithmName"))
                    {
                        EncryptionServerSinkProvider encryptionSinkProvider = null;
                        if (propBag.Contains("keyFilePath"))
                        {
                            encryptionSinkProvider = new EncryptionServerSinkProvider(propBag["cryptoAlgorithmName"].ToString(), propBag["keyFilePath"].ToString());
                        }
                        else
                        {
                            encryptionSinkProvider = new EncryptionServerSinkProvider(propBag["cryptoAlgorithmName"].ToString(), Convert.FromBase64String(propBag["keyAsBase64"].ToString()));
                        }

                        encryptionSinkProvider.Next = binaryFormatter;

                        sinkProvider = encryptionSinkProvider;
                    }
                    else
                    {
                        sinkProvider = binaryFormatter;
                    }

                    if (propBag == null)
                    {
                        propBag = new ListDictionary();
                        propBag.Add("port", 9999);
                    }
                    channel = new TcpServerChannel(propBag, sinkProvider);
                }
                else if (channelKey.Type == ChannelType.Ipc)
                {
                    BinaryServerFormatterSinkProvider binaryFormatter = new BinaryServerFormatterSinkProvider();
                    binaryFormatter.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;

                    IServerChannelSinkProvider sinkProvider = null;
                    if (propBag.Contains("cryptoAlgorithmName"))
                    {
                        EncryptionServerSinkProvider encryptionSinkProvider = null;
                        if (propBag.Contains("keyFilePath"))
                        {
                            encryptionSinkProvider = new EncryptionServerSinkProvider(propBag["cryptoAlgorithmName"].ToString(), propBag["keyFilePath"].ToString());
                        }
                        else
                        {
                            encryptionSinkProvider = new EncryptionServerSinkProvider(propBag["cryptoAlgorithmName"].ToString(), Convert.FromBase64String(propBag["keyAsBase64"].ToString()));
                        }

                        encryptionSinkProvider.Next = binaryFormatter;

                        sinkProvider = encryptionSinkProvider;
                    }
                    else
                    {
                        sinkProvider = binaryFormatter;
                    }

                    // Disallow access from off machine
                    DiscretionaryAcl dacl = new DiscretionaryAcl(false, false, 1);
                    SecurityIdentifier authenticatedUserSid = new SecurityIdentifier(WellKnownSidType.AuthenticatedUserSid, null);
                    dacl.AddAccess(AccessControlType.Allow, authenticatedUserSid, -1, InheritanceFlags.None, PropagationFlags.None);
                    CommonSecurityDescriptor securityDescriptor = new CommonSecurityDescriptor(false, false, ControlFlags.GroupDefaulted | ControlFlags.OwnerDefaulted | ControlFlags.DiscretionaryAclPresent, null, null, null, dacl);

                    channel = new IpcServerChannel(propBag, sinkProvider, securityDescriptor);
                }
            }
            return channel;
        }
    }

    /// <summary>
    /// A reference type class that is used as the ChannelList key.  This class creates a unique key by
    /// combining the channel type and an identifier string which is a representation of a real communications
    /// resource that must be created/opened (e.g., a named pipe name, a TCP machine/port).
    /// </summary>
    internal class ChannelKey
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the ChannelKey class.
        /// </summary>
        /// <param name="channelType"></param>
        public ChannelKey(ChannelType channelType)
            : this(channelType, AnonymousChannelId)
        { }

        /// <summary>
        /// Initializes a new instance of the ChannelKey class.
        /// </summary>
        /// <param name="channelType"></param>
        /// <param name="id"></param>
        public ChannelKey(ChannelType channelType, string id)
        {
            _channelType = channelType;
            _id = id;
        }
        #endregion

        #region Public properties
        /// <summary>
        /// The ChannelType of this key
        /// </summary>
        public ChannelType Type
        {
            get
            {
                return _channelType;
            }
        }

        /// <summary>
        /// Whether this channel is an "anonymous channel" (i.e., a channel that was provided no specific identifier)
        /// </summary>
        public bool IsAnonymousChannel
        {
            get
            {
                return (_id == AnonymousChannelId);
            }
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Returns a String that represents the current Object.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "Type={0}, ID={1}", Type.ToString(), _id);
        }

        /// <summary>
        /// Serves as a hash function for a particular type, suitable for use in hashing algorithms and data structures like a hash table.
        /// </summary>
        /// <returns></returns>
        /// <remarks>Overridden to return the same hash code for objects which have the same field values.</remarks>
        public override int GetHashCode()
        {
            return this.ToString().GetHashCode();
        }

        /// <summary>
        /// Determines whether two Object instances are equal.
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        /// <remarks>Overridden to return true if two object instances have the same field values.</remarks>
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }
            return (this.ToString() == ((ChannelKey)obj).ToString());
        }
        #endregion

        #region Private fields
        private const string AnonymousChannelId = "_anonymous";
        private ChannelType _channelType;       //= ChannelType.None; (automatically initialized by runtime)
        private string _id;                //= null; (automatically initialized by runtime)
        #endregion
    }
}
