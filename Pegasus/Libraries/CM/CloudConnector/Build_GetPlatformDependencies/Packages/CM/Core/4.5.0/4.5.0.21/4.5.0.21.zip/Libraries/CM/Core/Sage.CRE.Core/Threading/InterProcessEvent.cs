using System;
using System.Runtime.InteropServices;

using Sage.Diagnostics;

namespace Sage.Threading
{
    /// <summary>
    /// Provides a simplistic synchronization mechanism that can be used between two processes running on the local machine.
    /// </summary>
    /// <remarks>
    /// InterProcessEvent allows two processes to communicate with each other by signalling.  Typically, this communication concerns
    /// a task which one process must complete before another process can proceed.
    /// 
    /// When a process begins an activity that must complete before another proces proceeds, it calls Reset to put InterProcessEvent
    /// in the nonsignaled state.  This process can be thought of as controlling the InterProcessEvent.  The process that calls Wait
    /// on a the InterProcessEvent (using the same name) will block, awaiting the signal.  When the controlling process completes
    /// the activity, it calls Set to signal that the waiting process can proceed.
    /// 
    /// Once it has been signaled, InterProcessEvent remains signaled until it is manually reset, or disposed by the controller process.
    /// That is, calls to Wait or WaitAndCallbackWhenReset return immediately.
    /// </remarks>
    [ComVisible(false)]
    public interface IInterProcessEvent
    {
        /// <summary>
        /// Sets the state of the specified event to signaled.
        /// </summary>
        /// <param name="name">
        /// The name of the inter-proces event.
        /// 
        /// The name is limited to MAX_PATH characters and can contain any character except the backslash path-separator character (\).
        /// 
        /// Name comparison is case sensitive. 
        /// </param>
        /// <param name="millisecondsTimeout">The number of milliseconds to wait, or Timeout.Infinite (-1) to wait indefinitely.</param>
        /// <returns>true if the function succeeds; otherwise, false.</returns>
        bool Set(System.String name, System.Int32 millisecondsTimeout);

        /// <summary>
        /// Sets the state of the specified event to nonsignaled.
        /// </summary>
        /// <remarks>
        /// Should only be called by process which called Set.
        /// </remarks>
        void Reset();

        /// <summary>
        /// Blocks the current thread until the named event receives a signal.
        /// </summary>
        /// <param name="name">
        /// The name of the inter-proces event.
        /// 
        /// The name is limited to MAX_PATH characters and can contain any character except the backslash path-separator character (\).
        /// 
        /// Name comparison is case sensitive. 
        /// </param>
        /// <param name="millisecondsTimeout">The number of milliseconds to wait, or Timeout.Infinite (-1) to wait indefinitely.</param>
        /// <returns>true if the function succeeds (the event was signalled before the timeout elapsed); otherwise, false.</returns>
        bool Wait(System.String name, System.Int32 millisecondsTimeout);

        /// <summary>
        /// Blocks the current thread until the named event receives a signal.  Calls back into events object when the event returns to non-signalled state.
        /// </summary>
        /// <param name="name">
        /// The name of the inter-proces event.
        /// 
        /// The name is limited to MAX_PATH characters and can contain any character except the backslash path-separator character (\).
        /// 
        /// Name comparison is case sensitive. 
        /// </param>
        /// <param name="millisecondsTimeout">The number of milliseconds to wait, or Timeout.Infinite (-1) to wait indefinitely.</param>
        /// <param name="events"></param>
        /// <returns>true if the function succeeds (the event was signalled before the timeout elapsed); otherwise, false.</returns>
        bool WaitAndCallbackWhenReset(System.String name, System.Int32 millisecondsTimeout, IInterProcessEventEvents events);

        /// <summary>
        /// The interval (in milliseconds) to sleep while spinning during an attempt to Set (default 50 milliseconds). 
        /// </summary>
        System.Int32 SetterSleepInterval
        {get; set;}

        /// <summary>
        /// The interval (in milliseconds) to sleep while spinning during an attempt to Wait (default 100 milliseconds).
        /// </summary>
        System.Int32 WaiterSleepInterval
        {get; set;}

        /// <summary>
        /// The interval (in milliseconds) to periodically check for event reset (default 500 milliseconds).
        /// </summary>
        System.Int32 WaiterTimerInterval
        {get; set;}
    }


    /// <summary>
    /// 
    /// </summary>
    [ComVisible(false)]
    public interface IInterProcessEventEvents
    {
        /// <summary>
        /// Called when an event handle has been reset
        /// </summary>
        /// <param name="name">The name of the inter-proces event.</param>
        void OnResetEvent(string name);
    }


    /// <summary>
    /// Provides a simplistic synchronization mechanism that can be used between two processes running on the local machine.
    /// </summary>
    /// <remarks>
    /// InterProcessEvent allows two processes to communicate with each other by signalling.  Typically, this communication concerns
    /// a task which one process must complete before another process can proceed.
    /// 
    /// When a process begins an activity that must complete before another proces proceeds, it calls Reset to put InterProcessEvent
    /// in the nonsignaled state.  This process can be thought of as controlling the InterProcessEvent.  The process that calls Wait
    /// on a the InterProcessEvent (using the same name) will block, awaiting the signal.  When the controlling process completes
    /// the activity, it calls Set to signal that the waiting process can proceed.
    /// 
    /// Once it has been signaled, InterProcessEvent remains signaled until it is manually reset, or disposed by the controller process.
    /// That is, calls to Wait or WaitAndCallbackWhenReset return immediately.
    /// </remarks>
    [ComVisible(false)]
    public sealed class InterProcessEvent : IDisposable, IInterProcessEvent
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the InterProcessEvent class.
        /// </summary>
        public InterProcessEvent()
        {}
        #endregion

        #region IDisposable implementation
        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            VerboseTrace.WriteLine(this, "Invoked");

            lock(this)
            {
                if(!_disposed)
                {
                    Cleanup(true);
                    _disposed = true;

                    // Take yourself off the finalization queue to prevent
                    // finalization from executing a second time.
                    GC.SuppressFinalize(this);
                }
            }
        }

        private void Cleanup(bool disposeManagedResources)
        {
            VerboseTrace.WriteLine(this, "Invoked:  disposeManagedResources={0}", disposeManagedResources);

            if(disposeManagedResources)
            {
                // dispose any managed resources here

                _name = null;

                if(null != _timer)
                {
                    _timer.Stop();
                    (_timer as IDisposable).Dispose();
                    _timer = null;
                }

                _events = null;
            }

            // dispose any unmanaged resources here
            if(IntPtr.Zero != _mutex)
            {
                VerboseTrace.WriteLine(this, "Closing mutex ({0})", _mutex);
				PInvokeCore.UnsafeNativeMethods.CloseHandle( _mutex );
                VerboseTrace.WriteLine(this, "Mutex ({0}) closed", _mutex);
                _mutex = IntPtr.Zero;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        ~InterProcessEvent()
        {
            // Destructor will run only if Dispose() is never called.
            Cleanup(false);
        }
        #endregion

        #region Public members
        /// <summary>
        /// Sets the state of the specified event to signaled.
        /// </summary>
        /// <param name="name">
        /// The name of the inter-proces event.
        /// 
        /// The name is limited to MAX_PATH characters and can contain any character except the backslash path-separator character (\).
        /// 
        /// Name comparison is case sensitive. 
        /// </param>
        /// <param name="millisecondsTimeout">The number of milliseconds to wait, or Timeout.Infinite (-1) to wait indefinitely.</param>
        /// <returns>true if the function succeeds; otherwise, false.</returns>
        public bool Set(string name, System.Int32 millisecondsTimeout)
        {
            VerboseTrace.WriteLine(this, "Invoked:  name={0}, millisecondsTimeout={1}", name, millisecondsTimeout);

            VerifyNotDisposed();

            ArgumentValidator.ValidateNonEmptyString(name, "name", _myTypeName); 

            if(IntPtr.Zero != _mutex)
            {
                throw new ApplicationException("Invalid state:  Set has already been called.");
            }


            bool result = false;

            _name = name;
            long timeoutInTicks = millisecondsTimeout * 10000; // there are 10000 "ticks" (i.e., 100-ns intervals) per 1-ms
            long startTime = System.DateTime.Now.Ticks;
            while(true)
            {
                // Using PInvoke to create Mutex rather than using System.Threading.Mutex so that we can pass in a NullDacl as
                // the security attributes.  This is needed for clients where the process doing the Set is running under a different
                // account then the process doing the Wait.
				_mutex = PInvokeCore.UnsafeNativeMethods.CreateMutex( Sage.Remoting.SecurityAttributesBuilder.NullDacl, false, _name );
                if(IntPtr.Zero != _mutex)
                {
					if( PInvokeCore.Win32Error.ERROR_ALREADY_EXISTS == System.Runtime.InteropServices.Marshal.GetLastWin32Error() )
                    {
                        // we connected to the mutex created by someone else;  the event is not considered to be signalled yet
						PInvokeCore.UnsafeNativeMethods.CloseHandle( _mutex );
                        _mutex = IntPtr.Zero;
                    }
                    else
                    {
                        // we successfully created the mutex, therefore the event is now considered to be signalled
                        result = true;
                        break;
                    }
                }


                if(-1 != millisecondsTimeout && timeoutInTicks < (System.DateTime.Now.Ticks - startTime))
                {
                    // the timeout has elapsed ... stop trying to signal the event
                    break;
                }

                // pause and then try again to create the mutex
                System.Threading.Thread.Sleep(_setterSleepIntervalMilliseconds);
            }

            GC.KeepAlive(this); // prevent any possibility of "this" being finalized (and unmanaged handles being closed) until after PInvoke call(s) complete

            return result;
        }

        /// <summary>
        /// Sets the state of the specified event to nonsignaled.
        /// </summary>
        /// <remarks>
        /// Should only be called by process which called Set.
        /// </remarks>
        public void Reset()
        {
            VerboseTrace.WriteLine(this, "Invoked");

            VerifyNotDisposed();

            if(IntPtr.Zero != _mutex)
            {
                VerboseTrace.WriteLine(this, "Closing mutex ({0})", _mutex);
				PInvokeCore.UnsafeNativeMethods.CloseHandle( _mutex );
                VerboseTrace.WriteLine(this, "Mutex ({0}) closed", _mutex);
                _mutex = IntPtr.Zero;
            }

            GC.KeepAlive(this); // prevent any possibility of "this" being finalized (and unmanaged handles being closed) until after PInvoke call(s) complete
        }

        /// <summary>
        /// Blocks the current thread until the named event receives a signal.
        /// </summary>
        /// <param name="name">
        /// The name of the inter-proces event.
        /// 
        /// The name is limited to MAX_PATH characters and can contain any character except the backslash path-separator character (\).
        /// 
        /// Name comparison is case sensitive. 
        /// </param>
        /// <param name="millisecondsTimeout">The number of milliseconds to wait, or Timeout.Infinite (-1) to wait indefinitely.</param>
        /// <returns>true if the function succeeds (the event was signalled before the timeout elapsed); otherwise, false.</returns>
        public bool Wait(string name, System.Int32 millisecondsTimeout)
        {
            return WaitAndCallbackWhenReset(name, millisecondsTimeout, null);
        }

        /// <summary>
        /// Blocks the current thread until the named event receives a signal.  Calls back into events object when the event returns to non-signalled state.
        /// </summary>
        /// <param name="name">
        /// The name of the inter-proces event.
        /// 
        /// The name is limited to MAX_PATH characters and can contain any character except the backslash path-separator character (\).
        /// 
        /// Name comparison is case sensitive. 
        /// </param>
        /// <param name="millisecondsTimeout">The number of milliseconds to wait, or Timeout.Infinite (-1) to wait indefinitely.</param>
        /// <param name="events"></param>
        /// <returns>true if the function succeeds (the event was signalled before the timeout elapsed); otherwise, false.</returns>
        public bool WaitAndCallbackWhenReset(string name, System.Int32 millisecondsTimeout, IInterProcessEventEvents events)
        {
            VerboseTrace.WriteLine(this, "Invoked:  name={0}, millisecondsTimeout={1}, events={2}", name, millisecondsTimeout, events);

            VerifyNotDisposed();

            ArgumentValidator.ValidateNonEmptyString(name, "name", _myTypeName); 

            if(IntPtr.Zero != _mutex)
            {
                throw new ApplicationException("Invalid state:  attempting to perform a wait in the event controller process.  Controllers should only call Set and Reset.");
            }


            bool result = false;

            _name = name;
            long timeoutInTicks = millisecondsTimeout * 10000; // there are 10000 "ticks" (i.e., 100-ns intervals) per 1-ms
            long startTime = System.DateTime.Now.Ticks;
            bool createdNew;
            while(true)
            {
                createdNew = false;

                // Using PInvoke to create Mutex rather than using System.Threading.Mutex so that we can pass in a NullDacl as
                // the security attributes.  This is needed for clients where the process doing the Set is running under a different
                // account then the process doing the Wait.
				IntPtr serviceHostReadyMutex = PInvokeCore.UnsafeNativeMethods.CreateMutex( Sage.Remoting.SecurityAttributesBuilder.NullDacl, false, _name );
                if(IntPtr.Zero != serviceHostReadyMutex)
                {
					if( PInvokeCore.Win32Error.ERROR_ALREADY_EXISTS != System.Runtime.InteropServices.Marshal.GetLastWin32Error() )
                    {
                        // we created the mutex, therefore the event is not yet considered to be signalled
                        createdNew = true;
                    }

                    // we know what we needed to know, let go of the mutex immediately
					PInvokeCore.UnsafeNativeMethods.CloseHandle( serviceHostReadyMutex );
                    serviceHostReadyMutex = IntPtr.Zero;
                }

                if(false == createdNew)
                {
                    // we did not create the mutex, therefore the event is now signalled;  we can stop waiting
                    result = true;
                    break;
                }
                timeoutInTicks -= _waiterSleepIntervalMilliseconds * 10000;  // there are 10000 "ticks" (i.e., 100-ns intervals) per 1-ms
                if(-1 != millisecondsTimeout && 0 >= timeoutInTicks)
                {
                    // the timeout has elapsed ... stop waiting for the event to be signalled
                    break;
                }

                // give the controller process another chance to create the mutex
                System.Threading.Thread.Sleep(_waiterSleepIntervalMilliseconds);
            }

            // if the event is currently signalled and the client supllied a callback interface, then set up a timer
            // so that the client will get notified when the event is reset
            if(result && null != events)
            {
                _events = events;
                _timer = new System.Timers.Timer();
                _timer.Interval = _waiterTimerIntervalMilliseconds;
                _timer.AutoReset = true;
                _timer.Elapsed += new System.Timers.ElapsedEventHandler(OnTimerElapsed);
                _timer.Start();
            }

            GC.KeepAlive(this); // prevent any possibility of "this" being finalized (and unmanaged handles being closed) until after PInvoke call(s) complete

            return result;
        }

        /// <summary>
        /// The interval (in milliseconds) to sleep while spinning during an attempt to Set (default 50 milliseconds). 
        /// </summary>
        public System.Int32 SetterSleepInterval
        {
            get
            {
                VerifyNotDisposed();
                return _setterSleepIntervalMilliseconds;
            }
            
            set
            {
                VerifyNotDisposed();
                _setterSleepIntervalMilliseconds = value;
            }
        }

        /// <summary>
        /// The interval (in milliseconds) to sleep while spinning during an attempt to Wait (default 100 milliseconds).
        /// </summary>
        public System.Int32 WaiterSleepInterval
        {
            get
            {
                VerifyNotDisposed();
                return _waiterSleepIntervalMilliseconds;
            }
            
            set
            {
                VerifyNotDisposed();
                _waiterSleepIntervalMilliseconds = value;
            }
        }

        /// <summary>
        /// The interval (in milliseconds) to periodically check for event reset (default 500 milliseconds).
        /// </summary>
        public System.Int32 WaiterTimerInterval
        {
            get
            {
                VerifyNotDisposed();
                return _waiterTimerIntervalMilliseconds;
            }
            
            set
            {
                VerifyNotDisposed();
                _waiterTimerIntervalMilliseconds = value;
            }
        }
        #endregion

        #region Private members
        private void VerifyNotDisposed()
        {
            if(_disposed)
            {
                throw new ObjectDisposedException(_myTypeName);
            }
        }
        
        private void OnTimerElapsed(object sender,System.Timers.ElapsedEventArgs e)
        {
            VerboseTrace.WriteLine(this, "Invoked");

            VerifyNotDisposed();

            // periodically check to see when we are able to create the mutex again

            bool createdNew = false;

            // Using PInvoke to create Mutex rather than using System.Threading.Mutex so that we can pass in a NullDacl as
            // the security attributes.  This is needed for clients where the process doing the Set is running under a different
            // account then the process doing the Wait.
			IntPtr serviceHostReadyMutex = PInvokeCore.UnsafeNativeMethods.CreateMutex( Sage.Remoting.SecurityAttributesBuilder.NullDacl, false, _name );
            if(IntPtr.Zero != serviceHostReadyMutex)
            {
				if( PInvokeCore.Win32Error.ERROR_ALREADY_EXISTS != System.Runtime.InteropServices.Marshal.GetLastWin32Error() )
                {
                    // we created the mutex, therefore the event has returned to non-signalled
                    createdNew = true;
                }

                // we know what we needed to know, let go of the mutex immediately
				PInvokeCore.UnsafeNativeMethods.CloseHandle( serviceHostReadyMutex );
                serviceHostReadyMutex = IntPtr.Zero;
            }

            if(createdNew)
            {
                // we created it;  this means that event is no longer signalled
                _timer.Stop();
                (_timer as IDisposable).Dispose();
                _timer = null;

                // notify client that the event has been reset
                if(null != _events)
                {
                    try
                    {
                        VerboseTrace.WriteLine(this, "Before OnResetEvent:  _name={0}", _name);
                        _events.OnResetEvent(_name);
                        VerboseTrace.WriteLine(this, "After OnResetEvent:  _name={0}", _name);
                    }
                    catch(Exception ex)
                    {
                        ErrorTrace.WriteLine(this, ex.Message);
                        throw;
                    }
                }
            }

            GC.KeepAlive(this); // prevent any possibility of "this" being finalized (and unmanaged handles being closed) until after PInvoke call(s) complete
        }
        #endregion

        #region Private fields
        private static String _myTypeName = typeof(InterProcessEvent).FullName;
        private bool                        _disposed;                          // = false; (automatically initialized by runtime)
        private string                      _name;                              // = null; (automatically initialized by runtime)
        private System.Timers.Timer         _timer;                             // = null; (automatically initialized by runtime)
        private IInterProcessEventEvents    _events;                            // = null; (automatically initialized by runtime)
        private IntPtr                      _mutex;                             // = IntPtr.Zero; (automatically initialized by runtime)
        private int                         _setterSleepIntervalMilliseconds    = 50;
        private int                         _waiterSleepIntervalMilliseconds    = 100;
        private int                         _waiterTimerIntervalMilliseconds    = 500;
        #endregion
    }
}
