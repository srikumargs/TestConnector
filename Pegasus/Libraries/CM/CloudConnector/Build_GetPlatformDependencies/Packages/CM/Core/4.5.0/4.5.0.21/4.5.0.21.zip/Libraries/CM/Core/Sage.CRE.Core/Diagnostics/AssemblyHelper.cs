using System;
using System.Reflection;
using System.Runtime.InteropServices;

namespace tsSVManagedHelper
{
	/// <summary>
	/// This interface provides simple .NET functionality accessible to non-.NET clients.
	/// </summary>	
    [ComVisible(false)]
    public interface IAssemblyHelper
	{
		/// <summary>
		/// Get physical location of assembly in GAC.
		/// </summary>
		/// <param name="ShortAssemblyName">The short name of the assembly (i.e., CrystalDecisions.CrystalReports.Engine)</param>
		/// <param name="AssemblyLocation">Physical location of assembly.</param>		
		void GetAssemblyLocationInGAC( String ShortAssemblyName, out String AssemblyLocation );
	}

	/// <summary>
	/// This class provides an implementation of IAssemblyHelper.
	/// </summary>
    [ComVisible(false)]
    public class CAssemblyHelper : IAssemblyHelper
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public CAssemblyHelper()
		{
		}

		/// <summary>
		/// Get physical location of assembly in GAC.
		/// </summary>
		/// <param name="ShortAssemblyName">The short name of the assembly (i.e., CrystalDecisions.CrystalReports.Engine)</param>
		/// <param name="AssemblyLocation">Physical location of assembly.</param>		
		public void GetAssemblyLocationInGAC( String ShortAssemblyName, out String AssemblyLocation )
		{			
			AssemblyLocation = Assembly.LoadWithPartialName( ShortAssemblyName ).Location;
		}
	}
}
