using System;
using System.Xml.XPath;

namespace Sage.Xml
{
	/// <summary>
	/// Provide methods to make working with XPath easier
	/// </summary>
	public class XPathHelper
	{

        private static string EMPTY_NAMESPACE = "";

        /// <summary>
        /// Hide the default constructor
        /// </summary>
		private XPathHelper()
		{
			
		}

        /// <summary>
        /// Retrieve an attribute from the current element in an iterator
        /// </summary>
        /// <param name="inIterator">An XPathNode iterator posistion to an element</param>
        /// <param name="attributeName">The name of the attribute to recieve</param>
        /// <returns>The attributes value as a string</returns>
        /// <exception cref="XPathException"/>
        public static string GetRequiredAttribute( XPathNodeIterator inIterator, string attributeName )
        {
            // Clone so as not to mutate iterator
            XPathNodeIterator iterator = inIterator.Clone();
            if (iterator.Current.MoveToAttribute( attributeName, EMPTY_NAMESPACE ) == false)
            {
                throw new XPathException( string.Format( Strings.UnableToFindXmlAttributeFormat, attributeName), null  );
            }
            return iterator.Current.Value;
        }

        /// <summary>
        /// Determine is a particular attribute exists
        /// </summary>
        /// <param name="inIterator">An XPathNodeIterator positioned on an element</param>
        /// <param name="attributeName">The name of an attribute</param>
        /// <returns>True if the attribute exist, flase if not</returns>
        public static bool AttributeExists( XPathNodeIterator inIterator, string attributeName )
        {
            // Clone so as not to mutate iterator
            XPathNodeIterator iterator = inIterator.Clone();
            return iterator.Current.MoveToAttribute( attributeName, EMPTY_NAMESPACE );
        }
	}
}
