using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Globalization;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Exception base class that automatically writes to the debug output trace.
    /// Use this class as a base class for custom exceptions.
    /// </summary>
    [ComVisible(false)]
    [Serializable]
    [TraceListenerIgnoreTypeAttribute]
    public class TracingBaseException : ApplicationException
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the TracingBaseException class.
        /// </summary>
        protected TracingBaseException()
        {
            Trace(string.Empty);
        }

        /// <summary>
        /// Initializes a new instance of the TracingBaseException class with a specified error message.
        /// </summary>
        /// <param name="message">A message that describes the error.</param>
        protected TracingBaseException(string message) : base(message)
        {
            Trace(message);
        }

        /// <summary>
        /// Initializes a new instance of the TracingBaseException class with serialized data.
        /// </summary>
        /// <param name="info">The object that holds the serialized object data.</param>
        /// <param name="context">The contextual information about the source or destination.</param>
        protected TracingBaseException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            Trace(string.Format(CultureInfo.InvariantCulture, "info={0}\ncontext={1}", info.ToString(), context.ToString()));
        }

        /// <summary>
        /// Initializes a new instance of the TracingBaseException class with a specified error message and a reference to the inner exception that is the cause of this exception.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        /// <param name="innerException">The exception that is the cause of the current exception. If the innerException parameter is not a null reference, the current exception is raised in a catch block that handles the inner exception.</param>
        protected TracingBaseException(string message, Exception innerException) : base(message, innerException)
        {
            Trace(string.Format(CultureInfo.InvariantCulture, "message={0}\ninnerException={1}", message, innerException.ToString()));
        }
        #endregion

        #region Protected methods
        /// <summary>
        /// Writes a message to the verbose trace.
        /// </summary>
        /// <param name="message">The message to output to the trace.</param>
        protected void Trace(string message)
        {
            VerboseTrace.WriteLine(this, message);
        }
        #endregion
    }
}
