using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Xml;

using Sage.Diagnostics;

namespace TraceConfigTool
{
    public class TraceOptions
    {
        public TraceOptions(XmlNode node)
        {
            if(node != null)
            {
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showDate", ref _showDate);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showTime", ref _showTime);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showMilliseconds", ref _showMilliseconds);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "show24Hour", ref _show24Hour);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showProcessId", ref _showProcessId);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showThreadId", ref _showThreadId);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showObjectId", ref _showObjectId);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showTypeName", ref _showTypeName);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showMessageCategory", ref _showMessageCategory);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showMemberName", ref _showMemberName);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showMemberSignature", ref _showMemberSignature);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showAssemblyName", ref _showAssemblyName);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showFileLocation", ref _showFileLocation);
                XmlNodeHelper.GetOptionalBoolAttributeValue(node, "showAppDomainId", ref _showAppDomainId);
            }
        }

        public virtual void WriteOptionsAttributes(XmlTextWriter xmlTextWriter)
        {
            xmlTextWriter.WriteAttributeString("showDate", _showDate.ToString());
            xmlTextWriter.WriteAttributeString("showTime", _showTime.ToString());
            xmlTextWriter.WriteAttributeString("showMilliseconds", _showMilliseconds.ToString());
            xmlTextWriter.WriteAttributeString("show24Hour", _show24Hour.ToString());
            xmlTextWriter.WriteAttributeString("showProcessId", _showProcessId.ToString());
            xmlTextWriter.WriteAttributeString("showThreadId", _showThreadId.ToString());
            xmlTextWriter.WriteAttributeString("showObjectId", _showObjectId.ToString());
            xmlTextWriter.WriteAttributeString("showTypeName", _showTypeName.ToString());
            xmlTextWriter.WriteAttributeString("showMessageCategory", _showMessageCategory.ToString());
            xmlTextWriter.WriteAttributeString("showMemberName", _showMemberName.ToString());
            xmlTextWriter.WriteAttributeString("showMemberSignature", _showMemberSignature.ToString());
            xmlTextWriter.WriteAttributeString("showAssemblyName", _showAssemblyName.ToString());
            xmlTextWriter.WriteAttributeString("showFileLocation", _showFileLocation.ToString());
            xmlTextWriter.WriteAttributeString("showAppDomainId", _showAppDomainId.ToString());
        }

        public virtual void WriteAddListnerElementAttributes(XmlTextWriter xmlTextWriter)
        {
        }

        [Category("Date and Time")]
        [DisplayName("Show Date")]
        [Description("Enables output of the date of the trace call.")]
        public bool ShowDate
        {
            get
            {
                return _showDate;
            }
            set
            {
                _showDate = value;
            }
        }

        [Category("Date and Time")]
        [DisplayName("Show Time")]
        [Description("Enables output of the time of the trace call.")]
        public bool ShowTime
        {
            get
            {
                return _showTime;
            }
            set
            {
                _showTime = value;
            }
        }

        [Category("Date and Time")]
        [DisplayName("Show Milliseconds")]
        [Description("Enables output of the milliseconds part of the time of the trace call.")]
        public bool ShowMilliseconds
        {
            get
            {
                return _showMilliseconds;
            }
            set
            {
                _showMilliseconds = value;
            }
        }

        [Category("Date and Time")]
        [DisplayName("Use 24-Hour Clock for Time Output")]
        [Description("Controls whether the time should be output in 24-hour format.\n\nThis property has no effect unless 'Show Time' is true.")]
        public bool Show24Hour
        {
            get
            {
                return _show24Hour;
            }
            set
            {
                _show24Hour = value;
            }
        }

        [Category("Execution Context")]
        [DisplayName("Show Process ID")]
        [Description("Enables output of the process identifier.\n\nValue can be identified in the output by the 'p:' prefix.")]
        public bool ShowProcessId
        {
            get
            {
                return _showProcessId;
            }
            set
            {
                _showProcessId = value;
            }
        }

        [Category("Execution Context")]
        [DisplayName("Show Thread ID")]
        [Description("Enables output of the thread identifier.\n\nValue can be identified in the output by the 't:' prefix.")]
        public bool ShowThreadId
        {
            get
            {
                return _showThreadId;
            }
            set
            {
                _showThreadId = value;
            }
        }

        [Category("Trace Caller Detail")]
        [DisplayName("Show Caller's Object ID")]
        [Description("Enables output of the object identifier (i.e., GetHashCode() result) of the trace caller.\n\nThe value can be '0' if the trace was called from a static method or '-1' if the calling object instance could not be determined.  Value can be identified in the output by the 'o:' prefix.")]
        public bool ShowObjectId
        {
            get
            {
                return _showObjectId;
            }
            set
            {
                _showObjectId = value;
            }
        }

        [Category("General")]
        [DisplayName("Show Message Category")]
        [Description("Enables output of the message category.\n\nThe output uses the following convention:  '[ERR]' for 'Error', '[WRN]' for 'Warning', '[INF]' for Information, and '[VRB]' for verbose.")]
        public bool ShowMessageCategory
        {
            get
            {
                return _showMessageCategory;
            }
            set
            {
                _showMessageCategory = value;
            }
        }

        [Category("Trace Caller Detail")]
        [DisplayName("Show Caller's Type Name")]
        [Description("Enables output of the type name of the trace caller.")]
        public bool ShowTypeName
        {
            get
            {
                return _showTypeName;
            }
            set
            {
                _showTypeName = value;
            }
        }

        [Category("Trace Caller Detail")]
        [DisplayName("Show Caller's Member Name")]
        [Description("Enables output of member name of the trace caller.")]
        public bool ShowMemberName
        {
            get
            {
                return _showMemberName;
            }
            set
            {
                _showMemberName = value;
            }
        }

        [Category("Trace Caller Detail")]
        [DisplayName("Show Caller's Member Signature")]
        [Description("Enables output of the member signature of the trace caller.  This property has no effect unless 'Show Member Name' is true.")]
        public bool ShowMemberSignature
        {
            get
            {
                return _showMemberSignature;
            }
            set
            {
                _showMemberSignature = value;
            }
        }

        [Category("Trace Caller Detail")]
        [DisplayName("Show Caller's Assembly Name")]
        [Description("Enables output of the assembly name of the trace caller.")]
        public bool ShowAssemblyName
        {
            get
            {
                return _showAssemblyName;
            }
            set
            {
                _showAssemblyName = value;
            }
        }

        [Category("Trace Caller Detail")]
        [DisplayName("Show Caller's File Location")]
        [Description("Enables output of the file location (i.e., source file name and line number) of the trace caller.")]
        public bool ShowFileLocation
        {
            get
            {
                return _showFileLocation;
            }
            set
            {
                _showFileLocation = value;
            }
        }

        [Category("Execution Context")]
        [DisplayName("Show Application Domain ID")]
        [Description("Enables output of the current AppDomain identifier.\n\nValue can be identified in the output by the 'a:' prefix.")]
        public bool ShowAppDomainId
        {
            get
            {
                return _showAppDomainId;
            }
            set
            {
                _showAppDomainId = value;
            }
        }

        #region Private fields
        private bool _showDate;                  // = false; (automatically initialized by runtime)
        private bool _showTime;                  // = false; (automatically initialized by runtime)
        private bool _showMilliseconds;          // = false; (automatically initialized by runtime)
        private bool _show24Hour;                // = false; (automatically initialized by runtime)
        private bool _showProcessId;             // = false; (automatically initialized by runtime)
        private bool _showThreadId;              // = false; (automatically initialized by runtime)
        private bool _showObjectId;              // = false; (automatically initialized by runtime)
        private bool _showMessageCategory;       // = false; (automatically initialized by runtime)
        private bool _showTypeName;              // = false; (automatically initialized by runtime)
        private bool _showMemberName;            // = false; (automatically initialized by runtime)
        private bool _showMemberSignature;       // = false; (automatically initialized by runtime)
        private bool _showAssemblyName;          // = false; (automatically initialized by runtime)
        private bool _showFileLocation;          // = false; (automatically initialized by runtime)
        private bool _showAppDomainId;           // = false; (automatically initialized by runtime)
        #endregion
    }
}
