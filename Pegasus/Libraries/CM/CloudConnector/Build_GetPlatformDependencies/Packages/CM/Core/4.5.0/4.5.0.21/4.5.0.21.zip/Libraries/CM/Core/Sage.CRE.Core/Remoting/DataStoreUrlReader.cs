using System;
using System.Runtime.InteropServices;
using Sage.Configuration;
using Sage.Diagnostics;

namespace Sage.Remoting
{

    /// <summary>
    /// Use to read remote or local url values
    /// </summary>
    public class DataStoreUrlReader : DataStoreUrlReaderWriterBase, IUrlReader
    {
        /// <summary>
        /// Use the null factory
        /// </summary>
        public DataStoreUrlReader() : base() {}

        /// <summary>
        /// Set the factory in the ctor
        /// </summary>
        /// <param name="formatter"></param>
        public DataStoreUrlReader(IFormatter formatter) : base(formatter) {}


        /// <summary>
        /// Retrieve the URL for a remote resource
        /// </summary>
        /// <param name="inUri">The identifier of the desired resource</param>
        /// <returns>The URL for the requested resource</returns>
        public string GetUrl( string inUri )
        {
            string uri = inUri;
            if (this.Formatter != null)
            {
                uri = this.Formatter.Format(inUri);
            }

            string retval = string.Empty;
            IKeyedValues dataSet = DataRegistry.CreateKeyedValueSet( DataScope.AllUsers, DataStoreApplication, DataStoreTable );
            if( dataSet.Contains( DataStorePath, uri ) )
            {
                retval = dataSet.GetValue( DataStorePath, uri );
            }
            if( (retval == null || retval.Length == 0) && uri != null )
            {
                EventLogger.WriteMessage( "DataStoreUrlReader", string.Format( Strings.EmptyURLForFormat, uri), MessageType.Error );
            }
            return retval;
        }
    }
}
