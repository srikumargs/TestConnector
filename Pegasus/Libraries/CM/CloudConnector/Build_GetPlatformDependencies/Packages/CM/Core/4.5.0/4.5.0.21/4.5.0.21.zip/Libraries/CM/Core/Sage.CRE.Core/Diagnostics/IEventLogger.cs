using System;
using System.Runtime.InteropServices;

namespace Sage.Diagnostics
{
    
    
    /// <summary>
    /// Message Type
    /// </summary>
    [ ComVisible( false ) ]
    public enum MessageType
    {
        /// <summary>
        /// Informational
        /// </summary>
        Information,

        /// <summary>
        /// Warning
        /// </summary>
        Warning,

        /// <summary>
        /// Error
        /// </summary>
        Error
    }

	/// <summary>
	/// Summary description for Class1.
	/// </summary>
    [ComVisible(false)]
    public interface IEventLogger
	{
	
        /// <summary>
        /// Write a message in the Event Log
        /// </summary>
        /// <param name="source">The source of the messsage</param>
        /// <param name="message">The message text</param>
        /// <param name="type">The type of the message</param>
        void WriteMessage( string source, string message, MessageType type );
	}
}
