using System;
using System.Collections.Generic;
using System.Text;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Use this base class to implement an ExceptionHandler class which uses a ReportError callback 
    /// to report the error to the user.
    /// </summary>
    /// <remarks>
    /// To use this base class do the following:
    /// 1) Implement a class derived from ReportExceptionHandler
    /// 2) In your constructor call AddHandledException for all exception types your exception handler
    /// will handle.  For those exception that should be reported to the end user, set Action equal to Delegate
    /// and pass ReportException as the CustomHandler
    /// 3) Override TranslateExceptionToErrorInfo. In this method, populate the passed in ErrorInfo object
    /// with user consumable strings.
    /// 4) If you want your exception handler to handle some instances of a particular type of exception (e.g.,
    /// SqlExceptions with error codes equal to 1, 2, and 4) override CanHandleException.  Return true when
    /// you encounter an exception you want to handle.  If you want the exception reported to the end user, 
    /// set the Action to Delegate and set CustomHandler equal to ReportException.
    /// </remarks>
    abstract public class ReportErrorExceptionHandler : ExceptionHandler, IReportErrorExceptionHandler
    {
        #region private fields
        private ReportError _reportError;
        private String _caption;
        #endregion

        #region IReportErrorExceptionHandler Members
        /// <summary>
        /// Call this method to handle the exception
        /// </summary>
        /// <param name="e">The exception to handle</param>
        /// <param name="caption">Provide a caption for the error.  If a message box is used to display the error, caption is displayed in the message box's title bar.</param>
        /// <param name="reportError">The ReportError callback to call to report the error to the end-user</param>
        /// <returns>True if the exception was handled</returns>
        public bool HandleException(Exception e, String caption, ReportError reportError)
        {
            _reportError = reportError;
            _caption = caption;
            return base.HandleException(e);
        }
        #endregion

        /// <summary>
        /// A custom handler implementation that translates exceptions into an ErrorInfo object,
        /// and then calls the ReportError callback to report the error to the end-user
        /// </summary>
        /// <param name="e"></param>
        virtual protected void ReportException(Exception e)
        {
            ExceptionErrorInfo errorInfo = new ExceptionErrorInfo(_caption);
            TranslateExceptionToErrorInfo(e, ref errorInfo);
            if (!string.IsNullOrEmpty(errorInfo.ErrorSummary))
            {
                if (_reportError != null)
                {
                    _reportError(errorInfo);
                }
            }
        }

        /// <summary>
        /// This method should translates the provided exception into an ErrorInfo object.
        /// ErrorInfo objects contain user consumable strings.
        /// </summary>
        /// <param name="e">The exception to translate</param>
        /// <param name="errorInfo">The error info object to populate</param>
        abstract protected void TranslateExceptionToErrorInfo(Exception e, ref ExceptionErrorInfo errorInfo);


        /// <summary>
        /// Call this method to extract a report handler out of the exception's Data collection and call handle
        /// </summary>
        /// <param name="e">The exception to check</param>
        /// <param name="dataCollectionKey">The Data collection key to use, to look for the exception</param>
        /// <param name="caption">The caption to use when reporting out the error</param>
        /// <param name="reportError">The reportError callback to use when reporting out the error</param>
        /// <returns>True if the exception was handled, otherwise false</returns>
        public static bool HandleException(Exception e, String dataCollectionKey, String caption, ReportError reportError)
        {
            Boolean handled = false;
            if (e.Data.Contains(dataCollectionKey))
            {
                IReportErrorExceptionHandler handler = e.Data[dataCollectionKey] as IReportErrorExceptionHandler;
                handled = handler.HandleException(e, caption, reportError);
            }
            else if (e.InnerException != null)
            {
                handled = ReportErrorExceptionHandler.HandleException(e.InnerException, dataCollectionKey, caption, reportError);
            }
            return handled;
        }
    }
}
