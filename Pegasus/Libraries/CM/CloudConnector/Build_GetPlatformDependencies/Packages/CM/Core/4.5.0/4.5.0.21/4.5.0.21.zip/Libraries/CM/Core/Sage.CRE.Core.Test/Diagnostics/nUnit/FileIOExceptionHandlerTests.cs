#if DEBUG
using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace Sage.Diagnostics.NUnit
{
    /// <summary>
    /// Test
    /// </summary>
    [TestFixture]
    public class FileIOExceptionHandlerTests
    {
        // NOTE: the 'real' runtime location of this file is the GAC, however NUNIT
        // won't load files from the GAC, so to test this in NUNIT load it from
        // <sandbox>\assemblies.

        static FileIOExceptionHandlerTests()
        {
            //Sage.Configuration.LibraryManager.InitializeLibraries(
            //    System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory,
            //        Sage.Configuration.LibraryManager.LibraryManifestFolderName ) );
        }


        /// <summary>SetUp</summary>
        [SetUp]
        [SuppressMessage( "Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requires method be an instance method." )]
        public void SetUp()
        {
        }

        private String TestMessageString
        {
            get { return "an application exception"; }
        }

        /// <summary></summary>
        [SuppressMessage( "Microsoft.Performance", "CA1822:MarkMembersAsStatic" )]
        [Test, Category("Manual")]
        public void DirectoryNotFoundExceptionTest()
        {
            String msg = TestMessageString;

            try
            {
                // this should toss a PathNotFoundException
                FileAttributes attribs = File.GetAttributes( @"C:\test\azazyuyu\r$e_(zjyq)6e3g5\abc.123" );
            }
            catch (Exception ex)
            {
                Sage.Diagnostics.ReportError rptErr = new Sage.Diagnostics.ReportError(ErrMsgHandler);
                Sage.Diagnostics.FileIOExceptionHandler fieh = new FileIOExceptionHandler( "my error summary - this task had a problem");
                String caption = "My message box caption";
                fieh.HandleException( ex, caption, rptErr);
            }
        }

        /// <summary></summary>
        [SuppressMessage( "Microsoft.Performance", "CA1822:MarkMembersAsStatic" )]
        [Test, Category( "Manual" )]
        public void PathTooLongExceptionTest()
        {
            String msg = TestMessageString;

            try
            {
                // this should toss a PathTooLongException
                String path = String.Format(
                    @"C:\aaaaaaaaaa\bbbbbbbbbb\cccccccccc\dddddddddd\eeeeeeeeee\ffffffffff\gggggggggg\hhhhhhhhhh\iiiiiiiiii\kkkkkkkkkkk\llllllllll\mmmmmmmmmmm\nnnnnnnnnn\oooooooooo\qqqqqqqqqq\rrrrrrrrrrr\ssssssssss\tttttttttt\uuuuuuuuuu\vvvvvvvvvv\wwwwwwwwww\yyyyyyyyy\zzzzzzzzzz\1111111111\222.txt" );
                FileAttributes attribs = File.GetAttributes( path );
            }
            catch( Exception ex )
            {
                Sage.Diagnostics.ReportError rptErr = new Sage.Diagnostics.ReportError( ErrMsgHandler );
                Sage.Diagnostics.FileIOExceptionHandler fieh = new FileIOExceptionHandler( "my error summary - this task had a problem" );
                String caption = "My message box caption";
                fieh.HandleException( ex, caption, rptErr );
            }
        }

        private void ErrMsgHandler( ExceptionErrorInfo info )
        {
            String msg = String.Format("Exception caught:{0}Summary:{0}{1}{0}{0}Details:{0}{2}",
                Environment.NewLine, info.ErrorSummary, info.ErrorDetails);
            MessageBox.Show(msg, info.ErrorCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }



    }   // class
}   // namespace


#endif