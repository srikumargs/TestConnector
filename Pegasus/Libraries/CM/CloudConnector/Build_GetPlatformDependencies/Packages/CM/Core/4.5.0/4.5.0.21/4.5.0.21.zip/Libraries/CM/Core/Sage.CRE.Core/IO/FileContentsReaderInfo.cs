using System;
using System.Diagnostics;
using System.IO;
using Sage.Diagnostics;

namespace Sage.IO
{

    /// <summary>
    /// A helper class for providing info to the FileContentsReader
    /// </summary>
    public sealed class FileContentsReaderInfo
    {
        #region Fields

        // A path of the file to read
        private string _file = null;

        // A Flag indicating if file stream should be cached or not.
        private bool _cacheFileStream = true;

        // An unencrypted file extension
        private string _unEncryptedFileExtension = ".xml";

        // An encrypted file extension
        private string _encryptedFileExtension = ".acx";

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="file">A file to read</param>
        public FileContentsReaderInfo( string file )
        {
            _file = file;
            ValidateFile();   
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="file">A file to read</param>
        /// <param name="cacheFileStream">A flag indicating if the file stream should be cached or not</param>
        /// <remarks>By default file stream is cached</remarks>
        public FileContentsReaderInfo( string file, bool cacheFileStream )
        {
            _file = file;
            ValidateFile(); 
            _cacheFileStream = cacheFileStream;
        }

        
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="file">A file to read</param>
        /// <param name="cacheFileStream">A flag indicating if the file stream should be cached or not</param>
        /// <param name="unEncryptedFileExtension">An extension used to identify unencrypted files</param>
        /// <param name="encryptedFileExtension">An extension used to identify encrypted files</param>
        /// <remarks>Pass null for the unEncryptedFileExtension if all files should be encrypted or vice versa. 
        /// Passing null or "" for both extensions, however, will result in an invalid argument exception</remarks>
        public FileContentsReaderInfo( string file, bool cacheFileStream, string unEncryptedFileExtension, string encryptedFileExtension )
        {
            _file = file;
            ValidateFile(); 
            _cacheFileStream = cacheFileStream;
            _unEncryptedFileExtension = unEncryptedFileExtension;
            _encryptedFileExtension = encryptedFileExtension;
            ValidateExtensions();
        }

        /// <summary>
        /// Retrieve the config folder
        /// </summary>
        public string TargetFile
        {
            get
            { 
                ValidateFile();
                return _file; 
            }
        }

        /// <summary>
        /// Get/Set a Flag indicating if the file stream should be cached or not. 
        /// </summary>
        /// <remarks>Default value = true</remarks>
        public bool CacheFileStream
        {
            get{ return _cacheFileStream; }
            set{ _cacheFileStream = value; }
        
        }

        /// <summary>
        /// Get/Set the Unencrypted file extension
        /// </summary>
        /// <remarks>This extension is used to identify unencrypted files. 
        /// The default value is ".xml"</remarks>
        public string UnEncryptedFileExtension
        {
            get{ return _unEncryptedFileExtension; }
            set
            { 
                _unEncryptedFileExtension = value; 
                ValidateExtensions();
            }
        }
        
        /// <summary>
        /// Get/Set the encrypted file extension
        /// </summary>
        /// <remarks>This extension is used to identify encrypted files. 
        /// The default value is ".acx"</remarks>
        public string EncryptedFileExtension
        {
            get{ return _encryptedFileExtension; }
            set
            { 
                _encryptedFileExtension = value;
                ValidateExtensions();
            }
        }

        /// <summary>
        /// Flag indicating if unencrypted files should be processed
        /// </summary>
        internal bool ProcessUnEncryptedFiles
        {
            get{ return ( _unEncryptedFileExtension != null && _unEncryptedFileExtension.Length > 0 ); }
        }

        /// <summary>
        /// Flag indicating id encrypted files should be processed
        /// </summary>
        internal bool ProcessEncryptedFiles
        {
            get{ return ( _encryptedFileExtension != null && _encryptedFileExtension.Length > 0 ); }
        }

        /// <summary>
        /// Make sure the provided file is valid
        /// </summary>
        private void ValidateFile()
        {
            ArgumentValidator.ValidateNonEmptyString( _file, "file", this.GetType().Name );
            if( !File.Exists( _file ) )
            {
                string errorMessage = string.Format( Strings.InvalidFileFormat, _file );
                ThrowArgumentException( errorMessage, "file" );
            }
        }

        /// <summary>
        /// Make sure both filters are not empty
        /// </summary>
        private void ValidateExtensions()
        {
            if( (_unEncryptedFileExtension == null || _unEncryptedFileExtension.Length == 0 ) && ( _encryptedFileExtension == null || _encryptedFileExtension.Length == 0 ) )
            {
                string errorMessage = Strings.BothEncryptedAndUnencryptedFileExtensionsNullOrEmpty;
                ThrowArgumentException( errorMessage, "fileExtension" );
            }
        }

        /// <summary>
        /// Throw an argument exception
        /// </summary>
        /// <param name="errorMessage">The message to throw</param>
        /// <param name="argName">The name of the invalid argument</param>
        private void ThrowArgumentException( string errorMessage, string argName )
        {
            Assertions.Assert( false, errorMessage );
            EventLogger.WriteMessage( this.GetType().Name, errorMessage, MessageType.Error );
            throw new ArgumentException( errorMessage, argName );
        }
    }
}
