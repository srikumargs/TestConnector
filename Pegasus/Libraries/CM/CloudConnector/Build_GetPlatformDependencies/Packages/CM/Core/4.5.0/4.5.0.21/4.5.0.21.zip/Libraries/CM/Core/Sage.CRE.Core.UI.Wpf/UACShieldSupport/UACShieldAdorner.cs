﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;
using System.Windows;
using System.Windows.Documents;

namespace Sage.CRE.Core.UI.Wpf.UACShieldSupport
{
    /// <summary>
    /// Provides an adorner to display the provided shield icon
    /// </summary>
    public class UACShieldAdorner : Adorner
    {
        #region Constructors
        /// <summary>
        /// Creates an instance of the <see cref="UACShieldAdorner"/> class
        /// </summary>
        /// <param name="adornedElement">The <see cref="FrameworkElement"/>to adorn.
        /// Typically this will be an instance of the <see cref="UACShieldButton"/>class</param>
        /// <param name="shieldImage"></param>
        public UACShieldAdorner(FrameworkElement adornedElement, ImageSource shieldImage)
            : base(adornedElement)
        {
            _adornedElement = adornedElement;
            _shieldImageSource = shieldImage;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Overrides <see cref="Adorner.OnRender"/>to draw the shield image
        /// at a given size and location.
        /// </summary>
        /// <param name="drawingContext"></param>
        /// <remarks>
        /// The size of the rectangle to use to display the image is determined here
        /// instead of once in the constructor so that it will automaticaly
        /// resize as its hosting element resizes.
        /// </remarks>
        protected override void OnRender(DrawingContext drawingContext)
        {
            double maxHeight = _adornedElement.ActualHeight - 4;
            double imageHeight;
            double yOffset;
            Rect rect;

            base.OnRender(drawingContext);
            if (_adornedElement.Visibility == Visibility.Visible && maxHeight > 0)
            {
                imageHeight = Math.Min(maxHeight, _shieldImageSource.Height);
                yOffset = (_adornedElement.ActualHeight - imageHeight) / 2.0;
                rect = new Rect(2, yOffset,
                    (_shieldImageSource.Width * imageHeight) / _shieldImageSource.Height, imageHeight);
                drawingContext.DrawImage(_shieldImageSource, rect);
            }
        }
        #endregion

        #region Fields
        private ImageSource _shieldImageSource;
        private FrameworkElement _adornedElement;
        #endregion
    }
}
