using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security;
using System.Threading;
using System.Text;
using System.ComponentModel;

namespace Sage.Remoting
{

    /// <summary>
    /// This class builds SecurityAttribute IntPtrs to be used with API's that can use
    /// them
    /// </summary>
    public class SecurityAttributesBuilder
    {
        [DllImport("advapi32", SetLastError = true), SuppressUnmanagedCodeSecurityAttribute]
        static extern bool InitializeSecurityDescriptor(
            IntPtr pSecurityDescriptor, // pointer to sd
            int dwRevision);         // revision must be SECURITY_DESCRIPTOR_REVISION (1)

        [DllImport("advapi32", SetLastError = true), SuppressUnmanagedCodeSecurityAttribute]
        static extern bool SetSecurityDescriptorDacl(
            IntPtr pSecurityDescriptor, // pointer to sd
            bool bDaclPresent,
            IntPtr pDacl,
            bool bDaclDefaulted);

        [DllImport("advapi32", SetLastError = true), SuppressUnmanagedCodeSecurityAttribute]
        static extern bool IsValidSecurityDescriptor(IntPtr pSecurityDescriptor);

        [DllImport("advapi32", SetLastError = true), SuppressUnmanagedCodeSecurityAttribute]
        static extern bool
            ConvertStringSecurityDescriptorToSecurityDescriptor(
            [In] string StringSecurityDescriptor,
            [In] uint StringSDRevision,
            [Out] out IntPtr SecurityDescriptor,
            [Out] out int SecurityDescriptorSize
        );

        /// <summary>
        /// We use this Security attribute in the case where we want access to the named pipe or
        /// mailslot or CreateFile from any account.  
        /// For instance, NT services typically run under Local System which
        /// is a different user profile than the current user.  The DACL needs to be set to NULL
        /// in order to allow access from diff account profiles
        /// </summary>
        public static IntPtr NullDacl
        {
            get
            {
                if (_nullDacl == IntPtr.Zero)
                {
                    IntPtr securityDescriptorPtr = IntPtr.Zero;

                    try
                    {
                        securityDescriptorPtr = CreateSdWithNullDacl();
                        _nullDacl = CreateSaWithSd(securityDescriptorPtr, false);
                    }
                    finally
                    {
                        // Free unmanaged memory
                        if (_nullDacl == IntPtr.Zero && securityDescriptorPtr != IntPtr.Zero)
                        {
                            Marshal.FreeHGlobal(securityDescriptorPtr);
                            securityDescriptorPtr = IntPtr.Zero;
                        }
                    }
                }

                return _nullDacl;
            }
        }

        /// <summary>
        /// Gets the allow anonymous read write access security attributes.
        /// </summary>
        /// <value>The allow anonymous read write access security attributes.</value>
        public static IntPtr AllowAnonymousReadWriteAccessSecurityAttributes
        {
            get
            {
                if (_allowEveryoneAndAnonymousSecurityAttributes == IntPtr.Zero)
                {
                    IntPtr securityDescriptorPtr = IntPtr.Zero;
                    int securityDescriptorSize = 0;

                    try
                    {
                        // Grant GENERIC_ALL to LOCAL SYSTEM (a.k.a "SY")
                        // Grant GENERIC_READ | GENERIC_WRITE to Everyone (a.k.a. "WD")
                        // Grant GENERIC_READ | GENERIC_WRITE to ANONYMOUS LOGON (a.k.a. "AN"; however, not supported on W2K, so using "S-1-5-7" instead)
                        string stringSecurityDescriptor = "D:(A;;GA;;;SY)(A;;GRGW;;;WD)(A;;GRGW;;;S-1-5-7)";

                        // If OS is Vista, then we must also setup Mandatory Integrity Control (MIC) in
                        // order to allow anonymous clients to have read/write access.  If we dont' do this,
                        // then only read access will be allowed.
                        if (Environment.OSVersion.Version.Major >= 6)
                        {
                            // ML - Mandatory Label Ace
                            // NW - No Write Up
                            // S-1-16-0 - SID for untrusted or anonymous level
                            stringSecurityDescriptor += "S:(ML;;NW;;;S-1-16-0)";
                        }

                        //Convert string SD to SD
                        securityDescriptorPtr = ConvertStringSDtoSD(stringSecurityDescriptor, out securityDescriptorSize);
                        _allowEveryoneAndAnonymousSecurityAttributes = CreateSaWithSd(securityDescriptorPtr, true);
                    }
                    finally
                    {
                        // Free unmanaged memory
                        if (_allowEveryoneAndAnonymousSecurityAttributes == IntPtr.Zero && securityDescriptorPtr != IntPtr.Zero)
                        {
                            Marshal.FreeHGlobal(securityDescriptorPtr);
                            securityDescriptorPtr = IntPtr.Zero;
                        }
                    }
                }

                return _allowEveryoneAndAnonymousSecurityAttributes;
            }
        }

        private const UInt32 SDDL_REVISION_1 = 1;

        private static IntPtr ConvertStringSDtoSD(string stringSecurityDescriptor, out int securityDescriptorSize)
        {
            IntPtr result = IntPtr.Zero;

            if (!ConvertStringSecurityDescriptorToSecurityDescriptor(stringSecurityDescriptor, SDDL_REVISION_1, out result, out securityDescriptorSize))
            {
                throw new Win32Exception(Marshal.GetLastWin32Error(), Strings.ConvertStringSecurityDescriptorToSecurityDescriptoFailed);
            }

            return result;
        }

        private static IntPtr CreateSaWithSd(IntPtr pSd, bool inheritHandle)
        {
            Debug.Assert(pSd != IntPtr.Zero);
            IntPtr retval = IntPtr.Zero;

            SECURITY_ATTRIBUTES sa = new SECURITY_ATTRIBUTES();
            sa.pSecurityDescriptor = pSd;
            sa.bInheritHandle = inheritHandle;
            sa.nLength = Marshal.SizeOf(sa);
            IntPtr pSa = Marshal.AllocHGlobal(Marshal.SizeOf(sa));
            Marshal.StructureToPtr(sa, pSa, true);
            retval = pSa;

            return retval;
        }

        private static IntPtr CreateSdWithNullDacl()
        {
            IntPtr result = IntPtr.Zero;
            IntPtr pSd = IntPtr.Zero;
            try
            {
                SECURITY_DESCRIPTOR sd = new SECURITY_DESCRIPTOR();
                pSd = Marshal.AllocHGlobal(Marshal.SizeOf(sd));
                Marshal.StructureToPtr(sd, pSd, true);

                // Initialize SD with revision level 1 (mandatory)
                if (InitializeSecurityDescriptor(pSd, 1))
                {
                    // set NULL DACL in SD, this sets "everyone" access privileges
                    if (SetSecurityDescriptorDacl(pSd, true, IntPtr.Zero, true))
                    {
                        Debug.Assert(IsValidSecurityDescriptor(pSd));

                        result = pSd;
                    }
                    else
                    {
                        throw new Win32Exception(Marshal.GetLastWin32Error(), Strings.SetSecurityDescriptorDaclFailed);
                    }
                }
                else
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error(), Strings.InitializeSecurityDescriptorFailed);
                }
            }
            finally
            {
                if (result == IntPtr.Zero && pSd != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(pSd);
                    pSd = IntPtr.Zero;
                }
            }

            return result;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct SECURITY_DESCRIPTOR
        {
            public byte Revision;
            public byte Sbz1;
            public ushort Control;
            public uint Owner;
            public uint Group;
            public uint Sacl;
            public uint Dacl;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct SECURITY_ATTRIBUTES
        {
            internal int nLength;
            internal IntPtr pSecurityDescriptor;
            internal bool bInheritHandle;
        }

        private static IntPtr _nullDacl; //= IntPtr.Zero; (automatically initialized by runtime)
        private static IntPtr _allowEveryoneAndAnonymousSecurityAttributes; //= IntPtr.Zero; (automatically initialized by runtime)
    }
}
