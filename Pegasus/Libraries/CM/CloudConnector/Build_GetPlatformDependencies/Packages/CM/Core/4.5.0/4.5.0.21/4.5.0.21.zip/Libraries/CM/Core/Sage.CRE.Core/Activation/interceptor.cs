using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Activation;
using System.Collections;
using System.Collections.Specialized;
using System.Security.Permissions;

using Sage.Activation;

namespace Sage.Interception
{

	/// <summary>
	/// The interception base class that does the plumbing work.
    /// Users derive and override Preprocess and Postprocess
    /// method calls
	/// </summary>
	[ ComVisible( false ) ]
    public abstract class Interceptor : IMessageSink, IContextProperty, IContributeObjectSink
    {
        // next in the sink chain
        private IMessageSink _nextSink;

        /*  FC:  Fix factory when needed
        /// <summary>
        /// Factory method that takes the name of the type-lookup for
        /// the derived Interceptor
        /// </summary>
        /// <param name="interceptorName"></param>
        /// <returns></returns>
        public static Interceptor CreateInterceptor(string interceptorName)
        {
            return (Interceptor) TypeFactory.GetLocalObject(interceptorName);
        }
        */

        /// <summary>
        /// Part of the interceptor plumbing.  Runtime calls this so
        /// that the IMessageSink can be inserted properly in the chain
        /// </summary>
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.Infrastructure)]
        IMessageSink IContributeObjectSink.GetObjectSink(MarshalByRefObject obj, IMessageSink nextSink)
        {
            _nextSink = nextSink;
            return this;
	    }

        /// <summary>
        /// We need to create a new context for interception to work
        /// </summary>
        /// <param name="newCtx"></param>
        /// <returns></returns>
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.Infrastructure)]
        bool IContextProperty.IsNewContextOK(Context newCtx)
        {
		    return true;
	    }

        /// <summary>
        /// Not implemented.
        /// </summary>
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.Infrastructure)]
	    void IContextProperty.Freeze(Context newContext)
        {
	    }

        /// <summary>
        /// Delegate to a required override
        /// </summary>
        string IContextProperty.Name
        {
            [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.Infrastructure)]
            get
            {
                return AspectName;
            }
	    }
    
        /// <summary>
        /// Delegate to a required override
        /// </summary>
        protected abstract string AspectName
        {
            get;
        }

        /// <summary>
        /// Runtime calls this when it wants the next sink in the chain
        /// </summary>
        IMessageSink IMessageSink.NextSink
        {
            [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.Infrastructure)]
            get
            {
                return _nextSink;
            }
        }
        /// <summary>
        /// The method that gets called by the runtime.  We sandwich
        /// our pre and post processing virtual calls here.
        /// </summary>
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.Infrastructure)]
        IMessage IMessageSink.SyncProcessMessage(IMessage msg)
        {
            PreProcess(msg);
            IMessage returnMethod = _nextSink.SyncProcessMessage(msg);
            IMethodReturnMessage retMsg = returnMethod as IMethodReturnMessage;
            if (retMsg != null)
            {
                if (retMsg.Exception != null)
                    HandleException(retMsg.Exception);
            }
            PostProcess(msg, returnMethod);
            return returnMethod;
        }
        
        /// <summary>
        /// Currently not supported
        /// </summary>
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.Infrastructure)]
        IMessageCtrl IMessageSink.AsyncProcessMessage(IMessage msg, IMessageSink replySink)
        {
    	    throw new InvalidOperationException() ;
        }
        
        /// <summary>
        /// Override to do some meaningful Pre-method invocvation
        /// processing
        /// </summary>
        /// <param name="msg"></param>
        protected virtual void PreProcess(IMessage msg) {}
        
        /// <summary>
        /// Override to do some meaningful Post-method invocvation
        /// processing - including exception handling.
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="msgReturn"></param>
        protected virtual void PostProcess(IMessage msg, IMessage msgReturn) {}
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        protected virtual void HandleException(Exception e)
        {
            throw e;
        }
    }
}
