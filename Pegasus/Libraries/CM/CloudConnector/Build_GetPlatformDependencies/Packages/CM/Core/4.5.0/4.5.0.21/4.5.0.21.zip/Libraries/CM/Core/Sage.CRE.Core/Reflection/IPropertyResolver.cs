using System;
using System.Runtime.InteropServices;

namespace Sage.Reflection
{
	/// <summary>
	/// Summary description for IPropertyResolver.
	/// </summary>
	[ ComVisible( false ) ]
	public interface IPropertyResolver
	{
        /// <summary>
        /// Set the type instance to resolve properties on
        /// </summary>
        object TypeInstance{ set; }

        /// <summary>
        /// Set/Get a flag indicating if private properties should be exposed.
        /// </summary>
        /// <remarks>The default value of the property is false</remarks>
        bool ExposePrivateProperties{ set; get; }
	}
}
