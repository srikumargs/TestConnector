using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Text;
using System.Xml;
#if !CORE_INSTALL
using Sage.Diagnostics;
#endif

namespace Sage.Configuration.Internal
{
	/// <summary>
	/// Summary description for DataTable.
	/// </summary>
	internal class KeyedValueSet : IKeyedValues
	{
        // The scope of the data set
        private readonly DataScope _scope;

        // The path within the data store to use
        private readonly string _path = null; 

        // Stream to use for writable opperations
        private Stream _writableFileStream = null;

        // Hide the def ctor
        private KeyedValueSet() {}

        /// <summary>
        /// Constructor
        /// </summary>
		internal KeyedValueSet( string path, DataScope scope )
		{
		    _path = path.ToLower();	
            _scope = scope;
		}

        /// <summary>
        /// Retrieve a value from a Data Table
        /// </summary>
        /// <param name="dataPath">Identifies the location of the data within the data table</param>
        /// <param name="key">The name of a key within the data table</param>
        /// <returns>The data value stored for the provided key</returns>
        public string GetValue(string dataPath, string key)
        {
            string retval = string.Empty;
            dataPath = formatDataPath( dataPath );
            XmlDocument dataTable = OpenReadOnlyDataTable();
            XmlNode dataTarget = dataTable.SelectSingleNode( KeyedDataPath( dataPath, key ) );
            if( dataTarget != null )
            {
                XmlAttribute valueAttribute = (XmlAttribute)dataTarget.Attributes.GetNamedItem( "Value" );
                if( valueAttribute != null )
                {
                    retval = valueAttribute.Value;
                }
            }
            return retval;
        }

        /// <summary>
        /// Set a value in a Data Table
        /// </summary>
        /// <param name="dataPath">Identifies the location of the data within the data table</param>
        /// <param name="key">The name of a key within the data table</param>
        /// <param name="dataValue">The data value to store under the provided key</param>
        public void SetValue( string dataPath, string key, string dataValue )
        {
            try
            {
                dataPath = formatDataPath( dataPath );
                XmlDocument dataTable = OpenWritableDataTable();
                XmlNode dataTarget = dataTable.SelectSingleNode( KeyedDataPath( dataPath, key ) );
                if( dataTarget == null )
                {
                    dataTarget = dataTable.SelectSingleNode( dataPath );
                    if( dataTarget == null )
                    {
                        BuildDataPath( dataTable, dataPath );
                        dataTarget = dataTable.SelectSingleNode( dataPath );
                    }
                    if( dataTarget == null )
                    {
                        throw new ArgumentException( Strings.FailedToBuildDataPath, "dataPath" );
                    }
                    XmlElement newElement = dataTable.CreateElement( "Key" );
                    dataTarget.AppendChild( newElement );
                    dataTarget = newElement;
                    XmlAttribute keyNameAttribute = dataTable.CreateAttribute( "Name" );
                    keyNameAttribute.Value = key;
                    dataTarget.Attributes.Append( keyNameAttribute );
                }
                XmlAttribute valueAttribute = (XmlAttribute)dataTarget.Attributes.GetNamedItem( "Value" );
                if( valueAttribute == null )
                {
                    valueAttribute = dataTable.CreateAttribute( "Value" );
                    dataTarget.Attributes.Append( valueAttribute );
                }
                valueAttribute.Value = dataValue;
                UpdateDataTable( dataTable );
            }
            catch( Exception error )
            {
                throw error;
            }
            finally
            {
                CloseWritableFileStream();
            }
        }

        /// <summary>
        /// Given a data path, retrieve an array of strings corresponding with the names of the key value sets.
        /// </summary>
        /// <param name="dataPath">The data path used to find the names of the key value sets.</param>
        /// <returns>Returns an array of strings.</returns>
        public string[] GetKeyValuesNames(string dataPath)
        {
            dataPath = formatDataPath(dataPath);
            XmlDocument dataTable = OpenReadOnlyDataTable();
            XmlNodeList dataTargets = dataTable.SelectNodes(KeysDataPath(dataPath));
            System.Collections.Generic.List<string> names = new System.Collections.Generic.List<string>();

            if (dataTargets != null)
            {                
                for (int index = 0; index < dataTargets.Count; index++)
                {
                    XmlNode key = dataTargets[index];

                    if (!names.Contains(key.ParentNode.Name))
                        names.Add(key.ParentNode.Name);
                }
            }

            return names.ToArray();
        }

        /// <summary>
        /// Given a data path, retrieve a list of Key names for the specified data path.
        /// </summary>
        /// <param name="dataPath">The data path used to find all key names.</param>
        /// <returns>Returns an array of strings.</returns>
        public string[] GetKeyNames(string dataPath)
        {
            dataPath = formatDataPath(dataPath);
            XmlDocument dataTable = OpenReadOnlyDataTable();
            XmlNodeList dataTargets = dataTable.SelectNodes(KeysDataPath(dataPath));
            System.Collections.Generic.List<string> names = new System.Collections.Generic.List<string>();

            if (dataTargets != null)
            {
                for (int index = 0; index < dataTargets.Count; index++)
                {
                    XmlNode key = dataTargets[index];
                    string name = key.Attributes["Name"].Value;

                    if (!names.Contains(name))
                        names.Add(name);
                }
            }

            return names.ToArray();
        }

        /// <summary>
        /// Export the current data to the specified full path export file. The resultant data is understood to be in XML format.
        /// </summary>
        /// <param name="fullPathExportFile">Specify the full path export file.</param>
        /// <returns>Returns true if exported successfully; otherwise, false.</returns>
        public bool Export(string fullPathExportFile)
        {
            XmlDocument dataTable = OpenReadOnlyDataTable();

            try
            {
                if (dataTable != null)
                {
                    dataTable.Save(fullPathExportFile);
                    return true;
                }

                return false;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.ToString());
                return false;
            }
        }

        /// <summary>
        /// Retrieve all key value sets located at a particular location within a data table
        /// </summary>
        /// <param name="dataPath">Identifies the location of the data within the data table</param>
        /// <returns>all key value sets located at a particular location within a data table</returns>
        public IKeyValueSet[] GetAllKeyValueSets(string dataPath)
        {
            dataPath = formatDataPath( dataPath );
            IKeyValueSet[] retval = null;
            XmlDocument dataTable = OpenReadOnlyDataTable();
            XmlNodeList dataTargets = dataTable.SelectNodes( KeysDataPath( dataPath ) );
            if( dataTargets != null )
            {
                retval = new DataStoreKeyValueSet[ dataTargets.Count ];
                for( int index = 0; index < dataTargets.Count; index++ )
                {
                    XmlNode key = dataTargets[index];
                    string keyName = string.Empty;
                    string keyValue = string.Empty;
                    if( key.Attributes.GetNamedItem( "Name" ) != null )
                    {
                        keyName = key.Attributes.GetNamedItem("Name").Value;
                    }
                    if( key.Attributes.GetNamedItem("Value") != null )
                    {
                        keyValue = key.Attributes.GetNamedItem("Value").Value;
                    }
                    retval[index] = new DataStoreKeyValueSet( keyName, keyValue );
                }
            }
            else
            {
                retval = new DataStoreKeyValueSet[0];
            }

            return retval;
        }

        /// <summary>
        /// Set one or more values in a data table
        /// </summary>
        /// <param name="dataPath">Identifies the location of the data within the data table</param>
        /// <param name="newValues">A collection of Keys and values to set</param>
        public void SetKeyValues(string dataPath, IKeyValueSet[] newValues)
        {
            try
            {
                dataPath = formatDataPath( dataPath );
                XmlDocument dataTable = OpenWritableDataTable();
                XmlNode dataTarget = dataTable.SelectSingleNode( dataPath );
                if( dataTarget == null )
                {
                    BuildDataPath( dataTable, dataPath );
                    dataTarget = dataTable.SelectSingleNode( dataPath );
                    if( dataTarget == null )
                    {
                        throw new ArgumentException( Strings.FailedToBuildDataPath, "dataPath" );
                    }
                }
                foreach( IKeyValueSet valueSet in newValues )
                {
                    if( valueSet.Key != null && valueSet.Key.Length > 0 )
                    {
                        XmlNode newKey = dataTable.SelectSingleNode( KeyedDataPath( dataPath, valueSet.Key ) );
                        if( newKey == null )
                        {
                            newKey = dataTable.CreateElement( "Key" );
                            XmlAttribute newKeyName = dataTable.CreateAttribute( "Name" );
                            newKeyName.Value = valueSet.Key;
                            newKey.Attributes.Append( newKeyName );
                            dataTarget.AppendChild( newKey );

                        }
                        XmlAttribute newKeyValue = dataTable.CreateAttribute( "Value" );
                        newKeyValue.Value = valueSet.Value;
                        newKey.Attributes.Append( newKeyValue );
                    }
                }
                UpdateDataTable( dataTable );
            }
            catch( Exception error )
            {
                throw error;
            }
            finally
            {
                CloseWritableFileStream();
            }
        }

        /// <summary>
        /// Creates a new key at a particular location within a data table
        /// </summary>
        /// <param name="dataPath">Identifies the location of the data within the data table</param>
        /// <param name="key">The name of the key to create</param>
        public void CreateKey(string dataPath, string key)
        {
            try
            {
                dataPath = formatDataPath( dataPath );
                XmlDocument dataTable = OpenWritableDataTable();
                XmlNode dataTarget = dataTable.SelectSingleNode( KeyedDataPath( dataPath, key ) );
                if( dataTarget == null )
                {
                    dataTarget = dataTable.SelectSingleNode( dataPath );
                    if( dataTarget == null )
                    {
                        BuildDataPath( dataTable, dataPath );
                        dataTarget = dataTable.SelectSingleNode( dataPath );
                    }
                    if( dataTarget == null )
                    {
                        throw new ArgumentException( Strings.FailedToBuildDataPath, "dataPath" );
                    }
                    XmlElement newElement = dataTable.CreateElement( "Key" );
                    dataTarget.AppendChild( newElement );
                    dataTarget = newElement;
                    XmlAttribute keyNameAttribute = dataTable.CreateAttribute( "Name" );
                    keyNameAttribute.Value = key;
                    dataTarget.Attributes.Append( keyNameAttribute );
                }
                XmlAttribute valueAttribute = (XmlAttribute)dataTarget.Attributes.GetNamedItem( "Value" );
                if( valueAttribute == null )
                {
                    valueAttribute = dataTable.CreateAttribute( "Value" );
                    dataTarget.Attributes.Append( valueAttribute );
                }

                UpdateDataTable( dataTable );
            }
            catch( Exception error )
            {
                throw error;
            }
            finally
            {
                CloseWritableFileStream();
            }
        }

        /// <summary>
        /// Remove a key from a particular location within a data table
        /// </summary>
        /// <param name="dataPath">Identifies the location of the data within the data table</param>
        /// <param name="key">The name of the key to remove</param>
        public void RemoveKey(string dataPath, string key)
        {
            try
            {
                dataPath = formatDataPath( dataPath );
                XmlDocument dataTable = OpenWritableDataTable();
                XmlNode dataTarget = dataTable.SelectSingleNode( KeyedDataPath( dataPath, key ) );
                if( dataTarget != null )
                {
                    dataTarget.ParentNode.RemoveChild( dataTarget );
                    UpdateDataTable( dataTable );
                }
            }
            catch( Exception error )
            {
                throw error;
            }
            finally
            {
                CloseWritableFileStream();
            }
        }

        /// <summary>
        /// Determine if a specific key exists in a particular location within a data table
        /// </summary>
        /// <param name="dataPath">Identifies the location of the data within the data table</param>
        /// <param name="key">The name of the key in question</param>
        /// <returns>True if the key exists, false if not</returns>
        public bool Contains(string dataPath, string key)
        {
            dataPath = formatDataPath( dataPath );
            bool retval = false;
            XmlDocument dataTable = OpenReadOnlyDataTable();
            XmlNode dataTarget = dataTable.SelectSingleNode( KeyedDataPath( dataPath, key ) );
            if( dataTarget != null )
            {
                retval = true;
            }
            return retval;
        }

        /// <summary>
        /// Open the xml file representing the data table in a readonly mode
        /// </summary>
        private XmlDocument OpenReadOnlyDataTable()
        {
            XmlDocument dataTable = new XmlDocument();
            Stream stream = ReadDataTableStream();
            dataTable.Load( stream );
            return dataTable;
        }

        /// <summary>
        /// Open a data table with a write lock.
        /// </summary>
        /// <returns>An Xml document representation of the table</returns>
        private XmlDocument OpenWritableDataTable()
        {
            XmlDocument dataTable = new XmlDocument();
            OpenWritableStream();
            dataTable.Load( GetReadWriteStreamData() );
            return dataTable;
        }

        /// <summary>
        /// Open a read/write stream
        /// </summary>
        private void OpenWritableStream()
        {
            if( _scope == DataScope.AllUsers || _scope == DataScope.FileSystem )
            {
                _writableFileStream = DataRegistry.GetPersistenceStream( _scope, _path );
            }
            else
            { 
                _writableFileStream = ReadStorageStream();
            }
        }

        /// <summary>
        /// Retrieve an unencrypted stream of data the suppots both reads and writes
        /// </summary>
        /// <returns></returns>
        private Stream GetReadWriteStreamData()
        {
            Stream retval = _writableFileStream;

            if( Path.GetExtension( _path )== DataRegistry.EncryptedFileExtension )
            {
                byte[] bytes = null;
                BinaryReader reader = new BinaryReader( _writableFileStream );
                bytes = reader.ReadBytes( (int)_writableFileStream.Length );
                bytes = CryptoHelper.TransformBytes( bytes, CryptoHelper.EncryptionAction.Decrypt );

                retval= new MemoryStream( bytes, 0, bytes.Length );
            }
            return retval;
        }

        /// <summary>
        /// Update the data table's file
        /// </summary>
        /// <param name="dataTable">The data table to update</param>
        private void UpdateDataTable( XmlDocument dataTable )
        {
            try
            {
                // Get the output stream
                Stream stream = PreparedOutputStream();
                
                // Write the data
                BinaryWriter writer = new BinaryWriter( stream );
                writer.Write( ConvertDataTableToBytes(  dataTable.OuterXml ) );

                // Truncate the file since we are in read/write mode
                long newSize = stream.Position;
                stream.SetLength( newSize );

                // Complete the write and unlock the file
                writer.Close();
                stream.Close();
                stream = null;
                _writableFileStream = null;
            }
            catch( Exception error )
            {
                throw error;
            }
            finally
            {
                CloseWritableFileStream();
            }
        }

        /// <summary>
        /// Close a writable file stream
        /// </summary>
        private void CloseWritableFileStream()
        {
            if( _writableFileStream != null )
            {
                _writableFileStream.Close();
                _writableFileStream = null;
            }
        }

        /// <summary>
        /// Retrieve an output stream prepared for writing
        /// </summary>
        /// <returns>The prepared stream</returns>
        private Stream PreparedOutputStream()
        {
            Stream retval = null;
            if( _scope == DataScope.AllUsers || _scope == DataScope.FileSystem )
            {
                _writableFileStream.Position = 0;
                retval = _writableFileStream;
            }
            else
            {
                retval = DataRegistry.GetPersistenceStream( _scope, _path );
            }
            return retval;
        }

        /// <summary>
        /// Build up a data path
        /// </summary>
        /// <param name="dataTable">The data table to build the data path in</param>
        /// <param name="dataPath">The data path to build</param>
        /// <remarks>Called recusivly</remarks>
        private void BuildDataPath( XmlDocument dataTable, string dataPath )
        {
            int index = dataPath.LastIndexOf( @"/" );
            if( index > 0 && index < dataPath.Length -1 )
            {
                string newNodeName = dataPath.Substring( index + 1 );
                string newDataPath = dataPath.Substring( 0, index );
                if( dataTable.SelectSingleNode( newDataPath ) == null )
                {
                    BuildDataPath( dataTable, newDataPath );
                }
                XmlNode parentNode = dataTable.SelectSingleNode( newDataPath );
                if( parentNode != null )
                {
                    XmlElement newElement = dataTable.CreateElement( newNodeName );
                    parentNode.AppendChild( newElement );
                }
                else
                {
                    throw new ArgumentException( Strings.InvalidDataPath, "dataPath" );
                }
            }
        }

        /// <summary>
        /// Read a stream of data from isolated storage
        /// </summary>
        /// <returns>The data stream read</returns>
        private Stream ReadStorageStream()
        {
            byte[] bytes = ReadStorageBytes();
            if( Path.GetExtension( _path )== DataRegistry.EncryptedFileExtension )
            {
                bytes = CryptoHelper.TransformBytes( bytes, CryptoHelper.EncryptionAction.Decrypt );
            }
            return new MemoryStream( bytes, 0, bytes.Length );
        }

        /// <summary>
        /// Read a stream of bytes from the data table file
        /// </summary>
        /// <returns>The retrieved stream of bytes</returns>
        private Stream ReadFileStream()
        {
            byte[] bytes = ReadBytes();
            if( Path.GetExtension( _path )== DataRegistry.EncryptedFileExtension )
            {
                bytes = CryptoHelper.TransformBytes( bytes, CryptoHelper.EncryptionAction.Decrypt );
            }
            return new MemoryStream( bytes, 0, bytes.Length );
        }

        /// <summary>
        /// Read a stream of bytes from a file
        /// </summary>
        /// <returns>The bytes read from a file</returns>
        private byte[] ReadStorageBytes()
        {
            byte[] bytes = null;
            IsolatedStorageFileStream stream =  new IsolatedStorageFileStream(_path, FileMode.OpenOrCreate, DataRegistry.GetStorageFile(_scope));
            BinaryReader reader = new BinaryReader( stream );
            bytes = reader.ReadBytes( (int)stream.Length );
            reader.Close();
            stream.Close();
            return bytes;
        }

        /// <summary>
        /// Read a stream of bytes from a file
        /// </summary>
        /// <returns>The bytes read from a file</returns>
        private byte[] ReadBytes()
        {
            byte[] bytes = null;
            FileStream stream = null;
            int attempts = 0;
            while( attempts < 60 && ( stream == null ) )
            {
                attempts++;
                try
                {
                    stream = new FileStream( _path, FileMode.Open, FileAccess.Read );
                }
                catch( Exception error )
                {
                    if( attempts == 60 )
                    {
#if !CORE_INSTALL
                        EventLogger.WriteMessage( "KeyedValueSet", error.Message, MessageType.Error ); 
#endif
                        throw error;
                    }
                    System.Threading.Thread.Sleep( 50 );
                }
            }

            BinaryReader reader = new BinaryReader( stream );
            bytes = reader.ReadBytes( (int)stream.Length );
            reader.Close();
            stream.Close();
            return bytes;
        }

        /// <summary>
        /// Read in a data table stream
        /// </summary>
        /// <returns>A data table stream</returns>
        private Stream ReadDataTableStream()
        {
            Stream retval = null;
            if( _scope == DataScope.AllUsers || _scope == DataScope.FileSystem )
            {
                retval = ReadFileStream();
            }
            else
            { 
                retval = ReadStorageStream();
            }
            return retval;
        }

        /// <summary>
        /// Convert a data table to a set of set of bytes
        /// </summary>
        /// <param name="dataTableXml">An xml representation of the data table</param>
        /// <returns>a set of bytes representing a data table</returns>
        /// <remarks>Will encrypt the bytes if required</remarks>
        private byte[] ConvertDataTableToBytes( string dataTableXml )

        {
            byte [] bytes = new Byte[ dataTableXml.Length * 2];
            int size = Encoding.UTF8.GetBytes( dataTableXml.ToCharArray(), 0, dataTableXml.Length, bytes, 0);
            byte [] trimedBytes = new Byte[size];
            Array.Copy(bytes,0, trimedBytes,0,size);
            if( Path.GetExtension( _path ) == DataRegistry.EncryptedFileExtension )
            {
                trimedBytes = CryptoHelper.TransformBytes(trimedBytes, CryptoHelper.EncryptionAction.Encrypt);
            }
            return trimedBytes;
        }

        /// <summary>
        /// Format a provided data path for internal processing
        /// </summary>
        /// <param name="dataPath"></param>
        /// <returns></returns>
        private string formatDataPath( string dataPath )
        {
            return string.Format( @"//Root/{0}", dataPath.Replace( @"\", @"/" ) );
        }

        /// <summary>
        /// Append the datapath for a specific key
        /// </summary>
        /// <param name="dataPath">The dataPath to append to</param>
        /// <param name="keyName">The name of the key</param>
        /// <returns>The dataPath with a key specific expression appended</returns>
        private string KeyedDataPath( string dataPath, string keyName )
        {
            return string.Format( "{0}/Key[@Name=\"{1}\"]", dataPath, keyName );
        }

        /// <summary>
        /// Build a dataPath for locating all keys
        /// </summary>
        /// <param name="dataPath">The base dataPath</param>
        /// <returns>A dataPath for locating all keys</returns>
        private string KeysDataPath( string dataPath )
        {
            return string.Format( "{0}/Key", dataPath );   
        }
       
	}
}
