﻿using System;

namespace Sage.CRE.Core.SQL
{
    /// <summary>Renames a database using the ReversibleAction pattern.
    /// </summary>
    public class RenameDatabase : Sage.IO.ReversibleAction.ReversibleActionBase
    {
        #region Private members
        private SqlConnectionContext _context = null;
        private string _originalName = String.Empty;
        private string _newName = String.Empty;
        private bool _databaseExisted = false;
        #endregion



        /// <summary>Constructs a DatabaseRename object.
        /// </summary>
        /// <param name="context">The database to rename.</param>
        public RenameDatabase(SqlConnectionContext context)
        {
            _context = context;
            _originalName = _context.InitialCatalog;


            if (String.IsNullOrEmpty(_newName))
            {
                _newName = SuggestName(_context);
            }
        }
        


        /// <summary>Constructs a database rename object that will rename the database to the specified name.
        /// </summary>
        /// <param name="context">The original name of the database.</param>
        /// <param name="newName">The new name of the database.</param>
        public RenameDatabase(SqlConnectionContext context, string newName)
        {
            _context = context;
            _originalName = context.InitialCatalog;
            _newName = newName;


            if (String.IsNullOrEmpty(_newName))
            {
                _newName = SuggestName(_context);
            }
        }



        /// <summary>Renames the database.
        /// </summary>
        public override void Forward()
        {
            base.Forward();

            if (!String.IsNullOrEmpty(_newName))
            {
                if (SqlCommands.DatabaseExists(_context))
                {
                    _databaseExisted = true;
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                    SqlCommands.SingleUser(_context);
                    SqlCommands.IsDatabaseReady(_context, 60);

                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                    string commandText = String.Format(System.Globalization.CultureInfo.InvariantCulture, "ALTER DATABASE [{0}] MODIFY NAME = [{1}]", _originalName, _newName);

                    SqlConnectionContext masterContext = (SqlConnectionContext)_context.Clone();
                    masterContext.InitialCatalog = "master";

                    SqlCommands.ExecuteScriptNoTransaction(masterContext, commandText, null);
                    SqlConnectionContext newContext = (SqlConnectionContext)_context.Clone();
                    newContext.InitialCatalog = _newName;
                    SqlCommands.IsDatabaseReady(newContext, 60);

                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                    SqlCommands.MultiUser(newContext);
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                    SqlCommands.IsDatabaseReady(newContext, 60);

                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                    SqlCommands.IsDatabaseReady(newContext, 60);
                }
            }
            
        }



        /// <summary>Reversing the renaming of the database.
        /// </summary>
        public override void Reverse()
        {

            if (_databaseExisted)
            {
                try
                {
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                    SqlConnectionContext newContext = (SqlConnectionContext)_context.Clone();
                    newContext.InitialCatalog = _newName;
                    SqlCommands.SingleUser(newContext);

                    string commandText = String.Format(System.Globalization.CultureInfo.InvariantCulture, "ALTER DATABASE [{0}] MODIFY NAME = [{1}]", _newName, _originalName);
                    SqlConnectionContext masterContext = (SqlConnectionContext)_context.Clone();
                    masterContext.InitialCatalog = "master";

                    SqlCommands.ExecuteScriptNoTransaction(masterContext, commandText, null);
                    SqlCommands.MultiUser(_context);
                }
                catch
                {
                    SqlConnectionContext newContext = (SqlConnectionContext)_context.Clone();
                    newContext.InitialCatalog = _newName;
                    SqlCommands.MultiUser(newContext);

                    throw;
                }
            }

            base.Reverse();

        }



        /// <summary>Suggest a name for the rename process.
        /// </summary>
        /// <returns></returns>
        private string SuggestName(SqlConnectionContext context)
        {
            String result = String.Empty;

            SqlConnectionContext masterContext = (SqlConnectionContext)context.Clone();
            masterContext.InitialCatalog = "master";

            string connectionString = masterContext.ConnectionString;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (System.Data.SqlClient.SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = System.Data.CommandType.Text;

                        string targetCommand = String.Format(System.Globalization.CultureInfo.InvariantCulture, "SELECT [create_date] FROM sys.databases WHERE [name] = '{0}'", _originalName.Replace("'","''"));

                        command.CommandText = targetCommand;
                        command.CommandTimeout = (!String.IsNullOrEmpty(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT"))) ? System.Convert.ToInt32(System.Environment.GetEnvironmentVariable("STE_SQLCOMMANDTIMEOUT")) : System.Int32.MaxValue;;

                        object r = command.ExecuteScalar();
                        if (r != null)
                        {

                            DateTime create_date = (DateTime)r;
                            result = String.Format(System.Globalization.CultureInfo.InvariantCulture, "{0} - {1}", _originalName, create_date.ToString("u", System.Globalization.CultureInfo.InvariantCulture));
                            result = ReplaceNTFSReserved(result);
                            if (result.EndsWith("Z",StringComparison.OrdinalIgnoreCase)) result = result.Remove(result.Length - 1, 1);
                        }
                    }
                }

                finally
                {
                    connection.Close();
                }
            }

            return result;
        }



        /// <summary>Removed characters reserved by NTFS.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        static private string ReplaceNTFSReserved(string input)
        {
            char[] illegals = System.IO.Path.GetInvalidFileNameChars();
            foreach (char illegal in illegals)
            {
                input = input.Replace(illegal, '_');
            }
            return input;
        }
    }
}
