using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;

namespace Sage.IO.ReversibleAction.Tests
{
    /// <summary>
    /// Unit tests for basic reversible file system actions.
    /// </summary>
    [TestFixture]
    public class BasicOperations
    {

        /// <summary>
        /// Tests backing up a directory and restoring the orginal directory from a backup.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode",Justification="Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic",Justification="NUnit requirement.")]
        [Test]
        public void DirectoryBackupTest()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryBackupTest01");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            Assert.IsFalse(System.IO.File.Exists(dirName));

            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                string fileName = "TestFile01";
                string fileNamePath = System.IO.Path.Combine(dirName, fileName);

                Assert.IsFalse(System.IO.File.Exists(fileNamePath));
                using (FileCreate fileCreate = new FileCreate(fileNamePath))
                {
                    fileCreate.Forward();

                    Assert.IsTrue(System.IO.File.Exists(fileNamePath));

                    string fileName02 = "TestFile02";
                    string filePath02 = System.IO.Path.Combine(dirName, fileName02);

                    Assert.IsFalse(System.IO.File.Exists(filePath02));
                    using (DirectoryBackup dirBackup = new DirectoryBackup(dirName))
                    {
                        dirBackup.Forward();

                        Assert.IsFalse(System.IO.File.Exists(filePath02));
                        using (FileCreate fileCreate02 = new FileCreate(filePath02))
                        {
                            fileCreate02.Forward();
                            Assert.IsTrue(System.IO.File.Exists(filePath02));

                            fileCreate02.Commit(); // we don't want to rollback the filecreate
                        }
                        Assert.IsTrue(System.IO.File.Exists(filePath02));
                    }

                    Assert.IsFalse(System.IO.File.Exists(filePath02));

                }
                Assert.IsFalse(System.IO.File.Exists(fileNamePath));

                Assert.IsTrue(System.IO.Directory.Exists(dirName));
            }

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }

        /// <summary>
        /// Tests copying a directory.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode",Justification="Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requirement.")]
        [Test]
        public void DirectoryCopyTest()
        {

            string srcDirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryCopyTest01");
            if (System.IO.Directory.Exists(srcDirName)) System.IO.Directory.Delete(srcDirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(srcDirName));
            Assert.IsFalse(System.IO.File.Exists(srcDirName));
            using (DirectoryCreate dirCreate = new DirectoryCreate(srcDirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(srcDirName));

                string fileName = "TestFile01";
                string srcFilePath = System.IO.Path.Combine(srcDirName, fileName);

                Assert.IsFalse(System.IO.File.Exists(srcFilePath));
                using (FileCreate fileCreate = new FileCreate(System.IO.Path.Combine(srcDirName, fileName)))
                {
                    fileCreate.Forward();

                    Assert.IsTrue(System.IO.File.Exists(srcFilePath));
                    string destDirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryCopyTest02");
                    if (System.IO.Directory.Exists(destDirName)) System.IO.Directory.Delete(destDirName, true);

                    using (DirectoryCreate destDirCreate = new DirectoryCreate(destDirName))
                    {
                        destDirCreate.Forward();

                        using (DirectoryCopy dirCopy = new DirectoryCopy(srcDirName, destDirName))
                        {
                            dirCopy.Forward();

                            string copiedFileName = System.IO.Path.Combine(System.IO.Path.Combine(destDirName, System.IO.Path.GetFileName(srcDirName)), fileName);
                            Assert.IsTrue(System.IO.File.Exists(copiedFileName));
                        }
                    }
                    Assert.IsTrue(System.IO.File.Exists(srcFilePath));
                }
                Assert.IsFalse(System.IO.File.Exists(srcFilePath));

                Assert.IsTrue(System.IO.Directory.Exists(srcDirName));
            }
            Assert.IsFalse(System.IO.Directory.Exists(srcDirName));
        }

        /// <summary>
        /// Tests creating a directory.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification="Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification="NUnit requirement.")]
        [Test]
        public void DirectoryCreateTest()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryCreateTest01");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            Assert.IsFalse(System.IO.File.Exists(dirName));

            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(dirName));

            }

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }

        /// <summary>
        /// Tests deleting a directory.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requirement.")]
        [Test]
        public void DirectoryDeleteTest()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryDeleteTest01");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            Assert.IsFalse(System.IO.File.Exists(dirName));

            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(dirName));

                using (DirectoryDelete dirDelete = new DirectoryDelete(dirName))
                {
                    dirDelete.Forward();
                    Assert.IsFalse(System.IO.Directory.Exists(dirName));


                }

                Assert.IsTrue(System.IO.Directory.Exists(dirName));
            }

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }

        /// <summary>
        /// Tests moving a directory.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requirement.")]
        [Test]
        public void DirectoryMoveTest()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DirectoryMoveTest01");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            Assert.IsFalse(System.IO.File.Exists(dirName));

            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(dirName));

                string dirName02 = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "TestDir02");
                if (System.IO.Directory.Exists(dirName02)) System.IO.Directory.Delete(dirName02, true);

                Assert.IsFalse(System.IO.Directory.Exists(dirName02));

                using (DirectoryMove dirMove = new DirectoryMove(dirName, dirName02))
                {
                    dirMove.Forward();
                    Assert.IsTrue(System.IO.Directory.Exists(dirName02));
                }
                Assert.IsFalse(System.IO.Directory.Exists(dirName02));
            }
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }

        /// <summary>
        /// Tests backing up a file.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requirement.")]
        [Test]
        public void FileBackupTest()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "FileBackupTest01");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            Assert.IsFalse(System.IO.File.Exists(dirName));

            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(dirName));

                string fileName = "TestFile01";
                string filePath = System.IO.Path.Combine(dirName, fileName);
                Assert.IsFalse(System.IO.File.Exists(filePath));
                using (FileCreate fileCreate = new FileCreate(filePath))
                {
                    fileCreate.Forward();
                    Assert.IsTrue(System.IO.File.Exists(filePath));

                    using (FileBackup fileBackup = new FileBackup(filePath))
                    {
                        fileBackup.Forward();
                        Assert.IsTrue(System.IO.File.Exists(filePath));

                        System.IO.File.Delete(filePath);

                        Assert.IsFalse(System.IO.File.Exists(filePath));

                    }
                    Assert.IsTrue(System.IO.File.Exists(filePath));
                }
                Assert.IsFalse(System.IO.File.Exists(filePath));
            }
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }

        /// <summary>
        /// Tests copying a file.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requirement.")]
        [Test]
        public void FileCopyTest()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "FileCopyTest01");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            Assert.IsFalse(System.IO.File.Exists(dirName));

            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(dirName));

                string fileName = "TestFile01";
                string filePath = System.IO.Path.Combine(dirName, fileName);

                string fileName02 = "TestFile02";
                string filePath02 = System.IO.Path.Combine(dirName, fileName02);

                Assert.IsFalse(System.IO.File.Exists(filePath));
                Assert.IsFalse(System.IO.File.Exists(filePath02));
                using (FileCreate fileCreate = new FileCreate(filePath))
                {
                    fileCreate.Forward();
                    Assert.IsTrue(System.IO.File.Exists(filePath));

                    using (FileCopy fileCopy = new FileCopy(filePath, filePath02))
                    {
                        fileCopy.Forward();

                        Assert.IsTrue(System.IO.File.Exists(filePath));
                        Assert.IsTrue(System.IO.File.Exists(filePath02));
                    }

                    Assert.IsFalse(System.IO.File.Exists(filePath02));
                    
                    Assert.IsTrue(System.IO.File.Exists(filePath));
                }
                Assert.IsFalse(System.IO.File.Exists(filePath));
            }
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }

        /// <summary>
        /// Tests creating a file.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requirement.")]
        [Test]
        public void FileCreateTest()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "FileCreateTest01");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            Assert.IsFalse(System.IO.File.Exists(dirName));

            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(dirName));

                string fileName = "TestFile01";
                string filePath = System.IO.Path.Combine(dirName, fileName);

                Assert.IsFalse(System.IO.File.Exists(filePath));
                using (FileCreate fileCreate = new FileCreate(filePath))
                {
                    fileCreate.Forward();
                    Assert.IsTrue(System.IO.File.Exists(filePath));
                }
                Assert.IsFalse(System.IO.File.Exists(filePath));
            }
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }

        /// <summary>
        /// Tests deleting a file.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requirement.")]
        [Test]
        public void FileDeleteTest()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "FileDeleteTest01");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            Assert.IsFalse(System.IO.File.Exists(dirName));

            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(dirName));

                string fileName = "TestFile01";
                string filePath = System.IO.Path.Combine(dirName, fileName);

                Assert.IsFalse(System.IO.File.Exists(filePath));
                using (FileCreate fileCreate = new FileCreate(filePath))
                {
                    fileCreate.Forward();
                    Assert.IsTrue(System.IO.File.Exists(filePath));

                    using (FileDelete fileDelete = new FileDelete(filePath))
                    {
                        fileDelete.Forward();
                        Assert.IsFalse(System.IO.File.Exists(filePath));
                    }
                    Assert.IsTrue(System.IO.File.Exists(filePath));
                }
                Assert.IsFalse(System.IO.File.Exists(filePath));
            }
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }

        /// <summary>
        /// Tests moving a file.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Sage.Sandbox.Tools.FxCopRules.Internationalization", "SNI005:NoStringsEmbeddedInCode", Justification = "Not applicable to unit tests.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requirement.")]
        [Test]
        public void FileMoveTest()
        {
            string dirName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "FileMoveTest01");
            if (System.IO.Directory.Exists(dirName)) System.IO.Directory.Delete(dirName, true);

            Assert.IsFalse(System.IO.Directory.Exists(dirName));
            Assert.IsFalse(System.IO.File.Exists(dirName));

            using (DirectoryCreate dirCreate = new DirectoryCreate(dirName))
            {
                dirCreate.Forward();
                Assert.IsTrue(System.IO.Directory.Exists(dirName));

                string fileName = "TestFile01";
                string filePath = System.IO.Path.Combine(dirName, fileName);

                string fileName02 = "TestFile02";
                string filePath02 = System.IO.Path.Combine(dirName, fileName02);

                Assert.IsFalse(System.IO.File.Exists(filePath));
                Assert.IsFalse(System.IO.File.Exists(filePath02));
                using (FileCreate fileCreate = new FileCreate(filePath))
                {
                    fileCreate.Forward();
                    Assert.IsTrue(System.IO.File.Exists(filePath));

                    using (FileMove fileMove = new FileMove(filePath, filePath02))
                    {
                        fileMove.Forward();
                        Assert.IsFalse(System.IO.File.Exists(filePath));
                        Assert.IsTrue(System.IO.File.Exists(filePath02));
                    }

                    Assert.IsFalse(System.IO.File.Exists(filePath02));

                    Assert.IsTrue(System.IO.File.Exists(filePath));
                }
                Assert.IsFalse(System.IO.File.Exists(filePath));
            }
            Assert.IsFalse(System.IO.Directory.Exists(dirName));
        }
    }
}
