using System;
using System.Diagnostics;
using System.Xml;
using System.Configuration;
using System.Runtime.InteropServices;
using System.Globalization;
using System.IO;
using System.Threading;

namespace Sage.Diagnostics
{
    /// <summary>
    /// A <see cref="System.Diagnostics.TraceSwitch"/> which adds auto-updating behavior.  Changes made
    /// to the switch value in your application configuration file will be observed while your application
    /// is running.
    /// </summary>
    [ComVisible(false)]
    public sealed class AutoUpdatingTraceSwitch : TraceSwitch
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the AutoUpdatingTraceSwitch class.
        /// </summary>
        /// <param name="displayName">A name for the switch.</param>
        /// <param name="description">A description of the switch.</param>
        public AutoUpdatingTraceSwitch(string displayName, string description)
            : base(displayName, description)
        {
            SetupFileWatcher();
        }

        internal AutoUpdatingTraceSwitch(string displayName, string description, TraceLevel traceLevel)
            : base(displayName, description, Convert.ToString((Int32)traceLevel))
        {
            SetupFileWatcher();
        }
        #endregion

        #region Public properties
        // Must use the "new" inheritance qualifier for TraceError, TraceWarning, TraceInfo, TraceVerbose, and Level.
        // Because System.Diagnostics.TraceSwitch does not declare them as virtual.

        /// <summary>
        /// Gets a value indicating whether the Level is set to Error, Warning, Info, or Verbose.
        /// </summary>
        public new bool TraceError
        {
            get
            {
                if (!_configLoaded)
                {
                    LoadConfig();
                }

                return base.TraceError;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the Level is set to Warning, Info, or Verbose.
        /// </summary>
        public new bool TraceWarning
        {
            get
            {
                if (!_configLoaded)
                {
                    LoadConfig();
                }

                return base.TraceWarning;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the Level is set to Info or Verbose.
        /// </summary>
        public new bool TraceInfo
        {
            get
            {
                if (!_configLoaded)
                {
                    LoadConfig();
                }

                return base.TraceInfo;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the Level is set to Verbose.
        /// </summary>
        public new bool TraceVerbose
        {
            get
            {
                if (!_configLoaded)
                {
                    LoadConfig();
                }

                return base.TraceVerbose;
            }
        }

        /// <summary>
        /// Gets the trace level that specifies the messages to output for tracing and debugging.
        /// </summary>
        public new TraceLevel Level
        {
            get
            {
                if (!_configLoaded)
                {
                    LoadConfig();
                }

                return base.Level;
            }
        }
        #endregion

        #region Private members
        private void SetupFileWatcher()
        {
            try
            {
                if (File.Exists(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile))
                {
                    FileInfo configFileInfo = new FileInfo(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);

                    if (_configFileWatcher == null)
                    {
                        _configFileWatcher = new FileSystemWatcher();
                        _configFileWatcher.Path = configFileInfo.DirectoryName;
                        _configFileWatcher.Filter = configFileInfo.Name;
                        _configFileWatcher.IncludeSubdirectories = false;
                        _configFileWatcher.NotifyFilter = NotifyFilters.LastWrite;
                        _configFileWatcher.InternalBufferSize = 4096; // For efficiency, set buffer size to the minimum allowed.  Since we have filtered down to a single file we shouldn't need a large buffer.
                        _configFileWatcher.EnableRaisingEvents = true;
                    }
                    else
                    {
                        Assertions.Assert(_configFileWatcher.Path == configFileInfo.DirectoryName, string.Format(CultureInfo.InvariantCulture, "_configFileWatcher.Path '{0}' != configFileInfo.DirectoryName '{1}'", _configFileWatcher.Path, configFileInfo.DirectoryName));
                        Assertions.Assert(_configFileWatcher.Filter == configFileInfo.Name, string.Format(CultureInfo.InvariantCulture, "_configFileWatcher.Filter '{0}' != configFileInfo.Name '{1}'", _configFileWatcher.Filter, configFileInfo.Name));
                    }

                    _configFileWatcher.Changed += new FileSystemEventHandler(OnChanged);
                }
            }
            catch (Exception)
            {
                // In order to avoid an infinite recursion situation, SetupFileWatcher should NOT do anything that would
                // cause itself to get called recursively ... this includes writing to the Trace.
                //ErrorTrace.WriteLine(e.Message);
#if DEBUG
                // log an event instead (but only do it in DEBUG configuration).  As this is all stuff to support
                // debug output, fail silently in release mode
                EventLogger.WriteMessage("Sage.CRE.Core", string.Format(Thread.CurrentThread.CurrentCulture, Strings.FailedToSetupFileSystemWatcherErrorFormat, AppDomain.CurrentDomain.SetupInformation.ConfigurationFile), MessageType.Error, false);
#endif
            }
        }

        private void LoadConfig()
        {
            try
            {
                if (File.Exists(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile))
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
                    XmlNode switchesNode = doc.SelectSingleNode("/configuration/system.diagnostics/switches");
                    if (null != switchesNode)
                    {
                        // first check to see if there is a Global trace switch set ... this is the default
                        XmlNode node = switchesNode.SelectSingleNode("//add[@name='GlobalDefault']");
                        if (node != null)
                        {
                            int traceLevel = XmlNodeHelper.GetInt32AttributeValue(node, "value");
                            SwitchSetting = traceLevel;
                        }

                        // now, override the default with our specific switch setting (if it exists)
                        node = switchesNode.SelectSingleNode(string.Format(CultureInfo.InvariantCulture, "//add[@name='{0}']", DisplayName));
                        if (node != null)
                        {
                            int traceLevel = XmlNodeHelper.GetInt32AttributeValue(node, "value");
                            SwitchSetting = traceLevel;
                        }
                    }
                }
            }
            catch (Exception)
            {
                // In order to avoid an infinite recursion situation, LoadConfig should NOT do anything that would
                // cause itself to get called recursively ... this includes writing to the Trace.
                //ErrorTrace.WriteLine(e.Message);
#if DEBUG
                // log an event instead (but only do it in DEBUG configuration).  As this is all stuff to support
                // debug output, fail silently in release mode
                EventLogger.WriteMessage("Sage.CRE.Core", string.Format(CultureInfo.InvariantCulture, Strings.FailedToParseConfigDataFormat, AppDomain.CurrentDomain.SetupInformation.ConfigurationFile), MessageType.Error, false);
#endif
            }
            finally
            {
                // regardless of whether or not we successfully loaded the expected configuration file data we
                // set our state to "loaded" so we don't attempt to do it again (unless the FileSystemWatcher
                // detects another change)
                _configLoaded = true;
            }
        }

        private void OnChanged(object source, FileSystemEventArgs args)
        {
            // The FileSystemWatcher component will often raise several events for a single change to a file.
            // If we re-read the file on each event, we could easily end up re-reading the file several
            // times for a single change to the file.  Instead set isDataValid and check on every property
            // access.

            _configLoaded = false;
        }
        #endregion

        #region Private fields
        private bool _configLoaded;      // = false; (automatically initialized by runtime)
        private static FileSystemWatcher _configFileWatcher; // = null; (automatically initialized by runtime)
        #endregion
    }
}
