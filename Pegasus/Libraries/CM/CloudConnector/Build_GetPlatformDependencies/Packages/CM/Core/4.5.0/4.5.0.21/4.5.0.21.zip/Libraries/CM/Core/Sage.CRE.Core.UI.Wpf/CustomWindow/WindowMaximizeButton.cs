﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.IO;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Controls;
using System.Globalization;

namespace Sage.CRE.Core.UI.Wpf.CustomWindow
{
    public class WindowMaximizeButton : WindowButton
    {
        public WindowMaximizeButton()
        {
            // open resource where in XAML are defined icons and colors
            //Stream resourceStream = Application.GetResourceStream(new Uri("pack://application:,,,/Sage.CRE.Core.UI.Wpf;component/ButtonIcons.xaml")).Stream;
            //ResourceDictionary resourceDictionary = (ResourceDictionary)XamlReader.Load(resourceStream);
            Uri resourceLocater =
                new System.Uri("/Sage.CRE.Core.UI.Wpf;component/CustomWindow/ButtonIcons.xaml",
                    UriKind.Relative);
            ResourceDictionary resourceDictionary = (ResourceDictionary)Application.LoadComponent(resourceLocater);

            this.Content = resourceDictionary["WindowButtonMaximizeIcon"];
            this.ContentDisabled = resourceDictionary["WindowButtonMaximizeIconDisabled"];
        }
    }
}
