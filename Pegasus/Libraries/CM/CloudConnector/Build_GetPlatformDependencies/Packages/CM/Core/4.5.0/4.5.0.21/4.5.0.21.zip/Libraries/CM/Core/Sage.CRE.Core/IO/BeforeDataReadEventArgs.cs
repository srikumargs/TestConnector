using System;
using System.IO;

namespace Sage.IO
{
	/// <summary>
	/// Event arguments for an event that fires before a data read
	/// </summary>
	public class BeforeDataReadEventArgs: DataSourceEventArgs
	{

        // A flag indicating if this data source should not be read
        private bool _skipThisDataSource = false;

        // A flag indicating if all remaining data reads should be canceled
        private bool _cancelAllRemainingDataSourceReads = false;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataSourceId">The ID of the data source about to be read</param>
		public BeforeDataReadEventArgs( string dataSourceId ): base( dataSourceId )
		{
			
		}

        /// <summary>
        /// Get/Set a flag indicating if this data source should not be read
        /// </summary>
        public bool SkipThisDataSource
        {
            get{ return _skipThisDataSource; }
            set{ _skipThisDataSource = value; }
        }

        /// <summary>
        /// Get/Set a flag indicating is all remaining data source reads should be canceled
        /// </summary>
        public bool CancelAllRemainingDataSourceReads
        {
            get{ return _cancelAllRemainingDataSourceReads; }
            set{ _cancelAllRemainingDataSourceReads = value; }
        }
	}

    /// <summary>
    /// Handler for Before data read events
    /// </summary>
    public delegate void BeforeDataReadEventHandler( object sender, BeforeDataReadEventArgs e );
}
