#if DEBUG
using NUnit.Framework;
using System;
using System.Runtime.InteropServices;

namespace Sage.Diagnostics.NUnit
{
    /// <summary>
    /// Test the assembly version functionality
    /// </summary>
    public class AssemblyVersionTest
    {
        static AssemblyVersionTest()
        {
            //Sage.Configuration.LibraryManager.InitializeLibraries(
            //    System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory,
            //        Sage.Configuration.LibraryManager.LibraryManifestFolderName ) );
        }



        /// <summary>
        /// Check the System assembly version
        /// </summary>
        [Test]
        public void SystemClrVersion()
        {
            Version v = AssemblyVersionInfo.GetReferencedAssemblyVersion("System");
            Assert.AreEqual(v, AssemblyVersionInfo.ClrOneDotOne);
            Assert.IsTrue(v > AssemblyVersionInfo.ClrOneDotZero);
        }
    }
}

#endif // DEBUG