﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Collections.ObjectModel;
using Sage.Configuration;
using Sage.Diagnostics;

namespace Sage.Plugins
{
    public static class AssemblyPluginConfigurationReader
    {
        /// <summary>
        /// Reads XML files in the specified configuration path and return a list of the assembly 
        /// assemblies declared in those files.
        /// </summary>
        /// <returns></returns>
        public static ReadOnlyCollection<String> GetAssemblyNames(String configurationFileFolderPath)
        {
            List<String> result = new List<String>();

            if (Directory.Exists(configurationFileFolderPath))
            {
                foreach (String fileName in Directory.GetFiles(configurationFileFolderPath, Internal.Constants.XmlFileSpec, SearchOption.AllDirectories))
                {
                    XPathNavigator documentNavigator = null;
                    try
                    {
                        documentNavigator = new XPathDocument(fileName, XmlSpace.Default).CreateNavigator();
                    }
                    catch (Exception ex)
                    {
                        WarningTrace.WriteLine(null, Internal.Strings.AssemblyConfigurationSchemaErrorFormat, Path.GetFileName(fileName), ex.Message);
                    }

                    XPathNodeIterator iterator = documentNavigator.Select(Internal.Constants.AssemblyExpression);
                    while (iterator.MoveNext())
                    {
                        String codebase = iterator.Current.GetAttribute(Internal.Constants.CodebaseAttribute, String.Empty);
                        String name = iterator.Current.GetAttribute("Name", String.Empty);
                        if (!String.IsNullOrEmpty(name))
                        {
                            result.Add(name);
                        }
                        else if (!String.IsNullOrEmpty(codebase))
                        {
                            String resolvedCodebase = PathRegistrar.ResolveUrl(codebase);
                            result.Add(resolvedCodebase);
                            LibraryManager.AddSupplementaryResolveDirectory(Path.GetDirectoryName(resolvedCodebase));
                        }
                    }
                }
            }
            return result.AsReadOnly();
        }
    }
}
