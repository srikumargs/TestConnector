﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Reflection;
using System.Collections.Specialized;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Helper class to dynamically launch an internal debug-only method.  Useful when wanting to isolate such code
    /// in a separate, non-shipping, debug-only assembly.
    /// </summary>
    public static class InternalDebugOnlyHelper
    {
        /// <summary>
        /// Invoke a static method on the specified class.
        /// </summary>
        /// <param name="assemblyName">The name of the assembly</param>
        /// <param name="typeName">The namespace-qualified type name to invoke</param>
        /// <param name="methodName">The name of the method to invoke</param>
        /// <param name="args">Any arguments to pass to method</param>
        [Conditional("DEBUG")]
        public static void InvokeStaticMethod(String assemblyName, String typeName, String methodName, Object[] args)
        {
            try
            {
                // As a security measure, we only are going to load the internal debug-only functionality only if the
                // internal debug-only assembly exists, has the same version as the version as that of the caller,
                // and has the same public key as that of the caller.

                Assembly internalDebugOnlyAssembly = Assembly.Load(assemblyName);

                Byte[] internalDebugOnlyAssemblyPublicKeyToken = internalDebugOnlyAssembly.GetName().GetPublicKeyToken();
                Version internalDebugOnlyAssemblyVersion = internalDebugOnlyAssembly.GetName().Version;
                Byte[] callingAssemblyPublicKeyToken = Assembly.GetCallingAssembly().GetName().GetPublicKeyToken();
                Version callingAssemblyVersion = Assembly.GetCallingAssembly().GetName().Version;

                if (callingAssemblyVersion.CompareTo(internalDebugOnlyAssemblyVersion) == 0 &&
                    Convert.ToBase64String(internalDebugOnlyAssemblyPublicKeyToken, 0, internalDebugOnlyAssemblyPublicKeyToken.Length) == Convert.ToBase64String(callingAssemblyPublicKeyToken, 0, callingAssemblyPublicKeyToken.Length))
                {
                    Type missingFeatureHandlerFormType = internalDebugOnlyAssembly.GetType(typeName);
                    missingFeatureHandlerFormType.InvokeMember(methodName, BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static, null, null, args);
                }
            }
            catch (Exception)
            {
                // eat any failure to internal debug-only method
            }
        }
    }
}
