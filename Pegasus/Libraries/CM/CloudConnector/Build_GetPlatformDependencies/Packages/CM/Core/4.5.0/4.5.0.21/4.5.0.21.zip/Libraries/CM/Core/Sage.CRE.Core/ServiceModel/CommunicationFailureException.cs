﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Sage.ServiceModel
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public sealed class CommunicationFailureException : Exception
    {
        #region Construction

        /// <summary>
        /// Construct an instance of the ConnectionFailureException class
        /// </summary>
        /// <param name="errorMessage">ErrorMessage</param>
        /// <param name="innerException">An inner exception</param>
        public CommunicationFailureException(String errorMessage, Exception innerException)
            : base(errorMessage, innerException)
        { }

        /// <summary>
        /// Serialization Constructor
        /// </summary>
        /// <param name="si">Serialization Info</param>
        /// <param name="sc">Streaming Context</param>
        private CommunicationFailureException(SerializationInfo si, StreamingContext sc)
            : base(si, sc)
        { }

        #endregion
    }
}
