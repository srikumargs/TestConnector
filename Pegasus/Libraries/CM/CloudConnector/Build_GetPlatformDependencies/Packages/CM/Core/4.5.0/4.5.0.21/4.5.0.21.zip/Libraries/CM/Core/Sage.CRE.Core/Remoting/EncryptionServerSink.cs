using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Messaging;
using System.IO;

using Sage.CRE.LinkedSource;

namespace Sage.Remoting
{
    internal sealed class EncryptionServerSink : BaseChannelSinkWithProperties, IServerChannelSink
    {
        public EncryptionServerSink(IServerChannelSink nextChannelSink, CryptoAlgorithm cryptoAlgorithm, Byte[] encryptionKey)
        {
            _nextChannelSink = nextChannelSink;
            _cryptography = new Cryptography(cryptoAlgorithm);
            _encryptionKey = encryptionKey;
        }

        #region IServerChannelSink Members
        public void AsyncProcessResponse(IServerResponseChannelSinkStack sinkStack, Object state, IMessage msg, ITransportHeaders headers, Stream stream)
        {
            Boolean isEncrypted = (Boolean)state;
            stream = EncryptIfNecessary(headers, stream, isEncrypted);

            sinkStack.AsyncProcessResponse(msg, headers, stream);
        }

        public Stream GetResponseStream(IServerResponseChannelSinkStack sinkStack, Object state, IMessage msg, ITransportHeaders headers)
        { return null; }

        public IServerChannelSink NextChannelSink
        { get { return _nextChannelSink; } }

        public ServerProcessing ProcessMessage(IServerChannelSinkStack sinkStack, IMessage requestMsg, ITransportHeaders requestHeaders, Stream requestStream, out IMessage responseMsg, out ITransportHeaders responseHeaders, out Stream responseStream)
        {
            Boolean isEncrypted;

            requestStream = DecryptIfNecessary(requestHeaders, requestStream, out isEncrypted);

            sinkStack.Push(this, isEncrypted);
            ServerProcessing serverProcessing = _nextChannelSink.ProcessMessage(sinkStack, requestMsg, requestHeaders, requestStream, out responseMsg, out responseHeaders, out responseStream);

            responseStream = EncryptIfNecessary(responseHeaders, responseStream, isEncrypted);

            return serverProcessing;
        }
        #endregion

        #region Private methods
        private Stream EncryptIfNecessary(ITransportHeaders headers, Stream stream, Boolean isEncrypted)
        {
            Stream result = stream;

            if (isEncrypted)
            {
                Byte[] iv;

                result = _cryptography.EncryptStream(stream, _encryptionKey, out iv);

                headers["X-Encrypt"] = Boolean.TrueString;
                headers["X-EncryptIV"] = Convert.ToBase64String(iv);
            }

            return result;
        }

        private Stream DecryptIfNecessary(ITransportHeaders headers, Stream stream, out Boolean isEncrypted)
        {
            Stream result = stream;

            isEncrypted = false;
            if (headers["X-Encrypt"] != null && Boolean.Parse((String)headers["X-Encrypt"]))
            {
                isEncrypted = true;

                Byte[] iv = Convert.FromBase64String((String)headers["X-EncryptIV"]);
                result = _cryptography.DecryptStream(stream, _encryptionKey, iv);
            }

            return result;
        }
        #endregion

        #region Private fields
        private readonly IServerChannelSink _nextChannelSink;
        private readonly Byte[] _encryptionKey;
        private readonly Cryptography _cryptography;
        #endregion
    }
}
