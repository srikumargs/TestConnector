using System;

namespace Sage.Diagnostics
{
 
    /// <summary>
    /// COM Interop Attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Assembly)]
	public class COMInteropAttribute : System.Attribute
	{
        private bool _codeBase = false;

        /// <summary>
        /// Default Constructor
        /// </summary>
		public COMInteropAttribute()
		{
		}

        /// <summary>
        /// True if the assembly should be registered with the codebase flag.
        /// </summary>
        public bool Codebase 
        {
            get { return  _codeBase; }
            set { _codeBase = value; }
        }
	}
}
