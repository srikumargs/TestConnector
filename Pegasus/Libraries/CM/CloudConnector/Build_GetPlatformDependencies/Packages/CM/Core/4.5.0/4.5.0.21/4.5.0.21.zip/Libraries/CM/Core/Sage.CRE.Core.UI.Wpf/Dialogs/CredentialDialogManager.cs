﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Security;
using Sage.Credentials;

namespace Sage.CRE.Core.UI.Wpf.Dialogs
{
    public class CredentialDialogManager
    {
        public class DisplayOptions
        {
            public Boolean ShowSaveCheckBox { get; set; }

            /// <summary>
            /// Gets or sets a value that indicates whether the dialog should be displayed even when saved credentials exist for the 
            /// specified target.
            /// </summary>
            /// <value>
            /// <see langword="true" /> if the dialog is displayed even when saved credentials exist; otherwise, <see langword="false" />.
            /// The default value is <see langword="false" />.
            /// </value>
            /// <remarks>
            /// <para>
            ///   This property applies only when the <see cref="ShowSaveCheckBox"/> property is <see langword="true" />.
            /// </para>
            /// <para>
            ///   Note that even if this property is <see langword="true" />, if the proper credentials exist in the 
            ///   application instance credentials cache the dialog will not be displayed.
            /// </para>
            /// </remarks>
            public Boolean ShowUIForRetrievedCredentials { get; set; }

            public Boolean? PrefillSaveCheckboxValue { get; set; }
        }

        public enum PersistenceStore
        {
            None = 0,

            CredentialStore,

            /// <summary>
            ///   The application instance credential cache stores credentials in memory while an application is running. When the
            ///   application exits, this cache is not persisted.
            /// </summary>
            ApplicationInstanceCache,
        }

        public class Result : IDisposable
        {
            public Boolean UserCancelled { get; set; }
            public Boolean CredentialsLoadedFromPersistence { get; set; }
            public Boolean CredsValidated { get; set; }
            public SecureCredentials Credentials { get; set; }
            public Boolean IsSaveChecked { get; set; }
            public Boolean UIDisplayed { get; set; }

            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }

            private void Dispose(Boolean disposing)
            {
                if (disposing)
                {
                    if (Credentials != null)
                    {
                        Credentials.Dispose();
                        Credentials = null;
                    }
                }
            }
        }

        public class ValidCredsFunctionResult
        {
            public Boolean IsValid { get; set; }
            public Boolean SkipRepromptOnInvalid { get; set; }
            public String InvalidMessageToDisplay { get; set; }
            public Boolean SkipInvalidMessageDisplay { get; set; }
        }

        public static Result PromptForCredentials(
            Object owner,
            String windowTitle,
            String mainInstruction,
            String content,
            Func<Object, String, SecureString, ValidCredsFunctionResult> validCredsFunction)
        {
            return PromptForStoredCredentials(owner, windowTitle, mainInstruction, content, validCredsFunction, new DisplayOptions() { ShowSaveCheckBox = false }, PersistenceStore.None, String.Empty);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="owner"></param>
        /// <param name="windowTitle"></param>
        /// <param name="mainInstruction"></param>
        /// <param name="content"></param>
        /// <param name="displayOptions"></param>
        /// <param name="persistenceStore"></param>
        /// <param name="storageTarget">
        /// The target for the credentials. The default value is an empty string ("").
        /// Credentials are stored on a per user, not on a per application basis. To ensure that credentials stored by different 
        /// applications do not conflict, you should prefix the target with an application-specific identifer, e.g. 
        /// "Company_Application_target".
        /// </param>
        /// <param name="validCredsFunction"></param>
        /// <returns></returns>
        public static Result PromptForStoredCredentials(
            Object owner,
            String windowTitle,
            String mainInstruction,
            String content,
            Func<Object, String, SecureString, ValidCredsFunctionResult> validCredsFunction,
            DisplayOptions displayOptions,
            PersistenceStore persistenceStore,
            String storageTarget)
        {
            Window ownerWindow = owner as Window;

            var result = new Result();

            String userName = null;
            SecureString password = null;
            try
            {
                LoadCredentialsFromPersistence(persistenceStore, storageTarget, result, ref userName, ref password);

                if (!result.CredentialsLoadedFromPersistence || (result.CredentialsLoadedFromPersistence && displayOptions.ShowUIForRetrievedCredentials))
                {
                    using (var dialog = new CredentialDialog())
                    {
                        dialog.WindowTitle = windowTitle;
                        dialog.MainInstruction = mainInstruction;
                        dialog.Content = content;
                        dialog.ShowSaveCheckBox = displayOptions.ShowSaveCheckBox;

                        if (result.CredentialsLoadedFromPersistence)
                        {
                            dialog.UserName = userName;
                            dialog.Password = password.Copy();
                        }

                        result.UIDisplayed = true;

                        if (displayOptions.ShowSaveCheckBox)
                        {
                            dialog.IsSaveChecked = displayOptions.PrefillSaveCheckboxValue.HasValue ? displayOptions.PrefillSaveCheckboxValue.Value : false;
                        }

                        DoPrompt(ownerWindow, displayOptions, persistenceStore, storageTarget, validCredsFunction, result, dialog);
                    }
                }
                else
                {
                    result.Credentials = new SecureCredentials() { UserName = userName, Password = password.Copy() };
                }
            }
            finally
            {
                if (password != null)
                {
                    password.Dispose();
                    password = null;
                }
            }

            return result;
        }

        public static Result PromptForStoredCredentialsWithoutValidation(
            Object owner,
            String windowTitle,
            String mainInstruction,
            String content,
            DisplayOptions displayOptions,
            PersistenceStore persistenceStore,
            String storageTarget)
        {
            Window ownerWindow = owner as Window;

            var result = new Result();

            String userName = null;
            SecureString password = null;
            try
            {
                LoadCredentialsFromPersistence(persistenceStore, storageTarget, result, ref userName, ref password);

                if (!result.CredentialsLoadedFromPersistence || (result.CredentialsLoadedFromPersistence && displayOptions.ShowUIForRetrievedCredentials))
                {
                    using (var dialog = new CredentialDialog())
                    {
                        dialog.WindowTitle = windowTitle;
                        dialog.MainInstruction = mainInstruction;
                        dialog.Content = content;
                        dialog.ShowSaveCheckBox = displayOptions.ShowSaveCheckBox;

                        if (result.CredentialsLoadedFromPersistence)
                        {
                            dialog.UserName = userName;
                            dialog.Password = password.Copy();
                        }

                        result.UIDisplayed = true;

                        if (displayOptions.ShowSaveCheckBox)
                        {
                            dialog.IsSaveChecked = displayOptions.PrefillSaveCheckboxValue.HasValue ? displayOptions.PrefillSaveCheckboxValue.Value : false;
                        }

                        DoPromptWithoutValidation(ownerWindow, displayOptions, persistenceStore, storageTarget, result, dialog);
                    }
                }
                else
                {
                    result.Credentials = new SecureCredentials() { UserName = userName, Password = password.Copy() };
                }
            }
            finally
            {
                if (password != null)
                {
                    password.Dispose();
                    password = null;
                }
            }

            return result;
        }

        public static void ProcessValidCredentials(Boolean showSaveCheckBox, PersistenceStore persistenceStore, String storageTarget, Boolean isSaveChecked, SecureCredentials result)
        {
            // if we are not displaying the save checkbox, then assume we want to persist anyway
            // if we are displaying the save checkbox, then persist if it is checked
            if (!showSaveCheckBox || isSaveChecked)
            {
                SaveCredentialsToPersistence(persistenceStore, storageTarget, result);
            }

            // if we are displaying the save checkbox, and it is not checked, then delete from the persistence
            if (showSaveCheckBox && !isSaveChecked)
            {
                DeleteCredentialsFromPersistence(persistenceStore, storageTarget);
            }
        }


        private static void DoPrompt(Window owner, DisplayOptions displayOptions, PersistenceStore persistenceStore, String storageTarget, Func<Object, String, SecureString, ValidCredsFunctionResult> validCredsFunction, Result result, CredentialDialog dialog)
        {
            result.UserCancelled = false;
            do
            {
                result.CredsValidated = false;
                if (dialog.ShowDialog(owner))
                {
                    var validCredsFunctionResult = validCredsFunction(owner, dialog.UserName, dialog.Password);
                    if (validCredsFunctionResult.IsValid)
                    {
                        // credentials are valid
                        result.CredsValidated = true;

                        result.IsSaveChecked = dialog.IsSaveChecked;

                        result.Credentials = new SecureCredentials() { UserName = dialog.UserName, Password = dialog.Password.Copy() };

                        ProcessValidCredentials(displayOptions.ShowSaveCheckBox, persistenceStore, storageTarget, result.IsSaveChecked, result.Credentials);
                    }
                    else
                    {
                        if (!validCredsFunctionResult.SkipInvalidMessageDisplay)
                        {
                            String message = "Incorrect user name or password.";
                            if (!String.IsNullOrEmpty(validCredsFunctionResult.InvalidMessageToDisplay))
                            {
                                message = validCredsFunctionResult.InvalidMessageToDisplay;
                            }
                            MessageBox.Show(owner, message, dialog.WindowTitle, MessageBoxButton.OK, MessageBoxImage.Error);
                        }

                        if (validCredsFunctionResult.SkipRepromptOnInvalid)
                        {
                            result.UserCancelled = true;
                        }
                    }
                }
                else
                {
                    result.UserCancelled = true;
                }
            } while (!result.UserCancelled && !result.CredsValidated);
        }

        private static void DoPromptWithoutValidation(Window owner, DisplayOptions displayOptions, PersistenceStore persistenceStore, String storageTarget, Result result, CredentialDialog dialog)
        {
            result.UserCancelled = false;
            result.CredsValidated = false;
            if (dialog.ShowDialog(owner))
            {
                result.IsSaveChecked = dialog.IsSaveChecked;
                result.Credentials = new SecureCredentials() { UserName = dialog.UserName, Password = dialog.Password.Copy() };
            }
            else
            {
                result.UserCancelled = true;
            }
        }


        private static void DeleteCredentialsFromPersistence(PersistenceStore persistenceStore, String storageTarget)
        {
            if (!String.IsNullOrEmpty(storageTarget))
            {
                if (persistenceStore == PersistenceStore.ApplicationInstanceCache)
                {
                    CredentialApplicationInstanceCacheManager.DeleteCredential(storageTarget);
                }
                else if (persistenceStore == PersistenceStore.CredentialStore)
                {
                    CredentialStoreManager.DeleteCredential(storageTarget);
                }
            }
        }

        private static void SaveCredentialsToPersistence(PersistenceStore persistenceStore, String storageTarget, SecureCredentials result)
        {
            if (!String.IsNullOrEmpty(storageTarget))
            {
                if (persistenceStore == PersistenceStore.ApplicationInstanceCache)
                {
                    CredentialApplicationInstanceCacheManager.StoreCredential(storageTarget, result);
                }
                else if (persistenceStore == PersistenceStore.CredentialStore)
                {
                    CredentialStoreManager.StoreCredential(storageTarget, result);
                }
            }
        }

        private static void LoadCredentialsFromPersistence(PersistenceStore persistenceStore, String storageTarget, Result result, ref String userName, ref SecureString password)
        {
            if (persistenceStore == PersistenceStore.ApplicationInstanceCache)
            {
                using (var storedCreds = CredentialApplicationInstanceCacheManager.RetrieveCredential(storageTarget))
                {
                    if (storedCreds != null)
                    {
                        result.CredentialsLoadedFromPersistence = true;
                        userName = storedCreds.UserName;
                        password = storedCreds.Password.Copy();
                    }
                }
            }
            else if (persistenceStore == PersistenceStore.CredentialStore)
            {
                using (var storedCreds = CredentialStoreManager.RetrieveCredential(storageTarget))
                {
                    if (storedCreds != null)
                    {
                        result.CredentialsLoadedFromPersistence = true;
                        userName = storedCreds.UserName;
                        password = storedCreds.Password.Copy();
                    }
                }
            }
        }
    }
}
