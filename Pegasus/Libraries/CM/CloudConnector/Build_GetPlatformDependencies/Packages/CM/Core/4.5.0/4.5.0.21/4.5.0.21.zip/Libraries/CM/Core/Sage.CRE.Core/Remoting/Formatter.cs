using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Sage.Remoting
{
    /// <summary>
    /// pass the uri thru unchanged
    /// </summary>
    public class NullFormatter : IFormatter
    {
        /// <summary>
        /// Pass thru unchanged - used by default in UrlReader
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public string Format(string input)
        {
            return input;
        }
    }


    /// <summary>
    /// Munge the input with a given id
    /// </summary>
    public class StringInputIdFormatter : IFormatter
    {
        private string _id = String.Empty;

        // Hide the sucker
        private StringInputIdFormatter() {}
        
        /// <summary>
        /// Cache the Id and use it in the format call
        /// </summary>
        /// <param name="id"></param>
        public StringInputIdFormatter(string id)
        {
            _id = id;
        }

        /// <summary>
        /// Munge the input uri with the given id
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public string Format(string input)
        {
            return string.Format(input, _id);
        }
    }

}