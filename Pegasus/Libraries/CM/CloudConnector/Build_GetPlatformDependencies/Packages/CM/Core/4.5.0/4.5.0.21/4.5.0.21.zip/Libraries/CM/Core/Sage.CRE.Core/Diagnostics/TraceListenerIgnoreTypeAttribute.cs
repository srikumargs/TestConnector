using System;
using System.Runtime.InteropServices;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Indicates that a class should be ignored by the custom trace listener's stack trace traversal.
    /// </summary>
    /// <remarks>
    /// This custom listeners (in Sage.CRE.Core.TraceListeners) use the stack trace to figure out the calling
    /// method name, argument list, and object type.  The custom trace listeners walk backward up
    /// the stack trace until they find a type that is NOT in their ignore list.  This is important
    /// behavior since the function that actually calls System.Diagnostics.Trace.WriteLine() could
    /// be wrapped by potentially multiple layers of helper functions.  Once a non-ignored type is
    /// found in the stack trace, the custom listeners use the information in that stack frame as
    /// the calling object type, method name, and argument list.
    /// 
    /// Normally, ignoreable types that would otherwise wind up in the WriteLine() stack trace
    /// should use the Sage.Diagnostics.TraceListenerIgnoreTypeAttribute to proactively declare
    /// themselves as types that should be ignored by the custom trace listeners.  However, you
    /// can also explicitly use the &lt;StackTraceIgnoreTypes&gt; element of the custom trace listener's
    /// config section to declare additional types that you want ignored by that trace listener.
    /// </remarks>
    [AttributeUsage(AttributeTargets.Class)]
    [ComVisible(false)]
    public sealed class TraceListenerIgnoreTypeAttribute : System.Attribute
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the TraceListenerIgnoreTypeAttribute class.
        /// </summary>
        public TraceListenerIgnoreTypeAttribute()
        {}
        #endregion
    }
}
