#if DEBUG

using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.IO;

using NUnit.Framework;

namespace Sage.Configuration.Tests
{
    /// <summary>
    /// Class used to test the LibraryManager
    /// </summary>
    [TestFixture]
    public class LibraryManagerTests
    {
        /// <summary>
        /// Test resolving the MyDocuments Location
        /// </summary>
        [Test]
        [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requires an instance method")]
        public void TestMyDocumentsLocation()
        {
            String myDocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            myDocuments = Path.Combine(Environment.GetEnvironmentVariable("SAGE_SANDBOX"), Path.Combine("Runtime Files", myDocuments.Substring(myDocuments.IndexOf('\\') + 1)));
            Assert.AreEqual(LibraryManager.MyDocumentsLocation, myDocuments);
        }
    }
}

#endif