using System;
using System.Runtime.InteropServices;

namespace Sage.Activation
{
	/// <summary>
	/// Iterface used to retrieve published objects from a remote source.
	/// </summary>
    [ ComVisible( false ) ]
    public interface IActiveObjectRetriever
	{
        /// <summary>
        /// Retrieve an object from a named pipe channel
        /// </summary>
        /// <param name="uri">The uri of the object</param>
        /// <param name="targetAssembly">The assembly containing type information for the target object</param>
        /// <param name="targetType">The fully qualified type of the target object</param>
        /// <returns>The requested object or null if the resource can not be found</returns>
	    [ return : MarshalAs(UnmanagedType.IUnknown) ]
        object GetActiveObject( string uri, string targetAssembly, string targetType );	
	}
}
