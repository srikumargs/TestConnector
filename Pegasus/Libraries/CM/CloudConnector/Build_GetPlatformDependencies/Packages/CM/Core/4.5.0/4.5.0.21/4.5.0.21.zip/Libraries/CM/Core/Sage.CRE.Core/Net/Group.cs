using System;

namespace Sage.Net
{
    /// <summary>
    /// Summary description for Group.
    /// </summary>
    internal class Group
      : NameBase
      , IGroup
    {
        public Group(string name)
            : base(name)
        {
        }

    }
}
