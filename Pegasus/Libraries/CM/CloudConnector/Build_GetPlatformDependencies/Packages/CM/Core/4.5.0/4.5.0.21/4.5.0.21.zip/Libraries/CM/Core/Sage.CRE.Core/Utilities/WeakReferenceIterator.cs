﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Sage.Utilities
{
  /// <summary>Enumeration of the possible actions for the WeakReferenceIterator to take upon completion of each callback invocation</summary>
  public enum WeakReferenceIteratorAction
  {
    /// <value>Continue will allow iteration to continue</value>
    Continue,
    /// <value>Stop will stop iteration.  WeakReferenceIterator.LastValue will be set to the last value the callback was invoked with</value>
    Stop,
    /// <value>DeleteAndContinue will add the current invocation value to the list of items to be deleted after iteration is complete and allow iteration to continue</value>    
    DeleteAndContinue,
    /// <value>DeleteAndStop will add the current invocation value to the list of items to be deleted after iteration is complete and stop iteration. WeakReferenceIterator.LastValue will be set to the last value the callback was invoked with</value>        
    DeleteAndStop,
  }

  /// <summary> WeakReferenceIterator is a generic class for performing iterations on a IList based collection of WeakReferences to another type of object.</summary>  
  public class WeakReferenceIterator< TYP >
  {
    public delegate WeakReferenceIteratorAction IterationCallback( TYP val );

    private IterationCallback     _pfn;
    private IList                 _vCollection;
    private System.Collections.Generic.List< WeakReference > _vDeleteList;
    private TYP                   _oLast;

    /// <summary> Construct a WeakReferenceIterator from a callback and an IList of WeakReference objects </summary>
    /// <param name="pfn">the <see cref="WeakReferenceIterator.IterationCallback"/> to be performed on each member of the collection </param>
    /// <param name="vCollection"> the collection of weak referenced objects to iterate over</param>
    public WeakReferenceIterator( IterationCallback pfn, IList vCollection )
    {
      _pfn = pfn;
      _vCollection = vCollection;
      _vDeleteList = new List< WeakReference >( );
      _oLast = default( TYP );
    }
    
    /// <summary>Start the iteration</summary>
    /// <returns>true if the iteration completed for all items, false if iteration was stopped</returns>
    public bool Iterate( )
    {
      bool bResult = true;
      foreach( WeakReference oRef in _vCollection )
      {
        if( oRef.Target != null )
        {
          _oLast = ( TYP )oRef.Target;
          if( bResult )
          {
            switch( _pfn( _oLast ))
            {
              case WeakReferenceIteratorAction.Continue:
                break;
              case WeakReferenceIteratorAction.Stop:
                bResult = false;
                break;
              case WeakReferenceIteratorAction.DeleteAndContinue:
                _vDeleteList.Add( oRef );
                break;              
              case WeakReferenceIteratorAction.DeleteAndStop:
                _vDeleteList.Add( oRef );
                bResult = false;
                break;              
            }
          }
        }
        else
        {
          _vDeleteList.Add( oRef );
        }
      }
      // remove all the WeakReferences marked for deletion after our iteration is complete
      foreach( WeakReference oRef in _vDeleteList )
      {
        _vCollection.Remove( oRef );
      }
      // clear our delete list for the next run
      _vDeleteList.Clear( );
      // return whether iteration was stopped or completed successfully
      return bResult;
    }

    /// <summary>stores the last object that the <see cref="M:WeakReferenceIterator.IterationCallback"/> was performed on</summary>
    /// <remarks>this value is cleared ONLY at object construction time</remarks>
    /// <value>the last value from the collection that the <see cref="WeakReferenceIterator.IterationCallback"/> was performed on</summary>    
    public TYP LastValue
    {
      get { return _oLast; }
    }
    
    /// <summary> Creates an internal <see cref="T:WeakReferenceIterator"/> and calls <see cref="M:WeakReferenceIterator.Iterate"/></summary>
    public static bool Iterate( IterationCallback pfn, IList vCollection )
    {
      WeakReferenceIterator< TYP > it = new WeakReferenceIterator< TYP >( pfn, vCollection );
      return it.Iterate( );
    }
    
    /// <summary> Creates an internal <see cref="T:WeakReferenceIterator"/> and calls <see cref="M:WeakReferenceIterator.Iterate"/>, then returns <see cref="WeakReferenceIterator.LastValue"/> if successful</summary>    
    /// <param name="pfn">the <see cref="WeakReferenceIterator.IterationCallback"/> to be performed on each member of the collection </param>
    /// <param name="vCollection"> the collection of weak referenced objects to iterate over</param>    
    /// <returns> <see cref="P:WeakReferenceIterator.LastValue"/> if the Find was successful, otherwise returns the default value for (T) on failure</returns>
    public static TYP Find( IterationCallback pfn, IList vCollection )
    {
      WeakReferenceIterator< TYP > it = new WeakReferenceIterator< TYP >( pfn, vCollection );
      if ( it.Iterate( ))
      {
        return default( TYP );
      }
      else
      {
        return it.LastValue;
      }
    }    

    /// <summary> Adds a weak reference to the list of items to be removed from the collection at the conclusion of the <see cref="M:WeakReferenceIterator.Iterate"/> method</summary>
    /// <param name="oRef">the <see cref="WeakReference"/> object to be removed.  if this value is not in the collection no error will result</param>
    public void MarkForRemoval( WeakReference oRef )
    {
      _vDeleteList.Add( oRef );
    }
  }
}
