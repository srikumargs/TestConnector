using System;
using System.Runtime.InteropServices;

namespace Sage.Remoting
{

    /// <summary>
    /// Iterface used to retrieve published objects from a remote source.
    /// </summary>
    [ComVisible(false)]
    public interface IUrlReader
    {
        /// <summary>
        /// This support persistent stores which are file or handle
        /// based
        /// </summary>
        /// <param name="contextInfo"></param>
        void Open(string contextInfo);

        /// <summary>
        /// Used to set a policy for munging/formatting the input Uri in the
        /// GetUrl call.
        /// </summary>
        IFormatter Formatter { set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="urlKey"></param>
        /// <returns></returns>
        string GetUrl(string urlKey);

        /// <summary>
        /// This support persistent stores which are file or handle
        /// based
        /// </summary>
        void Close();
    }

    /// <summary>
    /// Iterface used to retrieve published objects from a remote source.
    /// </summary>
    [ComVisible(false)]
    public interface IUrlWriter
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="contextInfo"></param>
        void Open(string contextInfo);

        /// <summary>
        /// Used to set a policy for munging/formatting the input Uri in the
        /// GetUrl call.
        /// </summary>
        IFormatter Formatter { set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="urlKey"></param>
        /// <param name="urlValue"></param>
        void SaveUrl(string urlKey, string urlValue);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="urlKey"></param>
        void RemoveUrl(string urlKey);

        /// <summary>
        /// 
        /// </summary>
        void Close();
    }


    /// <summary>
    /// Interface which encapsulates Uri string creation
    /// </summary>
    [ComVisible(false)]
    public interface IFormatter
    {
        /// <summary>
        /// Interface 
        /// </summary>
        string Format(string inputString);
    }
}