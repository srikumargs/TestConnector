using System;
using System.Collections.Generic;
using System.Text;
using Sage.IO;

namespace Sage.Configuration.Internal
{
    /// <summary>
    /// This path class contains the information needed to resolve registered paths
    /// </summary>
    internal sealed class RegisteredPathUrlResolver : IUrlResolver
    {
        #region private fields
        /// <summary>
        /// Prefix for encoded registered paths
        /// </summary>
        private const string RegisteredPathUrlPrefix = "registeredpath://";
        #endregion 

        #region IUrlResolver Members

        /// <summary>
        /// Determine if this is a regisered url
        /// </summary>
        /// <param name="url">Url to examine</param>
        /// <returns>True if the url is a registered url, otherwise false</returns>
        bool IUrlResolver.CanResolveUrl(string url)
        {
            string temp = url.ToLower();
            if (temp.StartsWith(RegisteredPathUrlPrefix))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Resolves an URL that uses the registered path protocol to a file system reference.
        /// No guarantees are provided that the resolved path is valid in the file system.
        /// </summary>
        /// <remarks>
        /// A Paths URL has the form registeredpath://context/path where path is a path relative 
        /// to one of the context folders and context is a key to a specific folder. 
        /// </remarks>
        /// <param name="url">Url to resolve.</param>
        /// <returns>A resolved path if a known registered path is provided otherwise the path unchanged</returns>
        string IUrlResolver.ResolveUrl(string url)
        {
            string retval = url;

            int prefixSize = RegisteredPathUrlPrefix.Length;
            string[] parts = url.Substring(prefixSize).Split(new char[] { '/', '\\' }, 2);
            
            string spec = null;
            if (parts.Length == 2)
            {
                spec = parts[1];
            }

            string registeredPath = PathRegistrarHelper.GetRegisteredPath(parts[0]);
            if (registeredPath != null && registeredPath.Length > 0)
            {
                retval = PathUtils.Combine(registeredPath, PathUtils.Normalize(spec));
            }
            else
            {
                throw new ArgumentException(Strings.SpecifiedPathKeyNotRegistered, parts[0]);
            }
            return PathUtils.StripTrailingSlash(retval);
        }

        /// <summary>
        /// This property equals true if the object can encode urls
        /// </summary>
        public Boolean CanEncodeUrl
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Generate an encoded url (i.e. registrypath://context/path) from an url
        /// </summary>
        /// <param name="url">A url to encode</param>
        /// <returns>The encoded url if the method is able to encode it, otherwise the original url is returned</returns>
        public string EncodeUrl(string url)
        {
            string retval = url;
            if (url != null && url.Length > 0)
            {
                string temp = url.ToLower();
                IKeyValueSet[] paths = PathRegistrarHelper.GetRegisteredPaths();
                if (paths.Length > 0)
                {
                    int depth = 0;
                    string encodedPath = string.Empty;
                    foreach (IKeyValueSet valueSet in paths)
                    {
                        if (temp.StartsWith(valueSet.Value.ToLower()))
                        {
                            int levels = valueSet.Value.LastIndexOf(@"\");
                            if (levels > depth)
                            {
                                encodedPath = string.Format(@"{0}{1}\{2}", RegisteredPathUrlPrefix, valueSet.Key, url.Substring(valueSet.Value.Length));
                            }
                        }
                    }
                    if (encodedPath.Length > 0)
                    {
                        retval = encodedPath;
                    }
                }
            }

            return retval;
        }
        #endregion
    }
}
