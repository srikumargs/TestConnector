﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace Sage.CRE.Core.UI.Wpf.Controls
{
    /// <summary>
    /// Provides a basic mechanism to associate a label with a radio button ... and check the button when the label is clicked
    /// </summary>
    /// <remarks>
    /// Simply bind this label's Target property to radio button in question
    /// </remarks>
    public class RadioButtonLabel : Label
    {
        public RadioButtonLabel() : base() { }

        protected override void OnMouseDown(System.Windows.Input.MouseButtonEventArgs e)
        {
            if (Target != null)
            {
                (Target as RadioButton).IsChecked = true;
            }
            base.OnMouseDown(e);
        }
    }

}
