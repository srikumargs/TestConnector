/*=====================================================================

  File:        PipeChannel.cs

=====================================================================*/

using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Channels;
using System.Runtime.InteropServices;
using System.IO;
using System.Collections;
using System.Threading;

namespace Sage.Remoting
{
    internal sealed class PipeChannel : IChannelReceiver,
                               IChannelSender
    {
        private PipeClientChannel _clientChannel = null;
        private PipeServerChannel _serverChannel = null;

        public PipeChannel()
        {
            _clientChannel = new PipeClientChannel();
        }

        public PipeChannel(String pipeName)
            : this()
        {
            _serverChannel = new PipeServerChannel(pipeName);
        }

        public PipeChannel(String machineName, String pipeName)
        {
            Hashtable dict = new Hashtable();
            dict.Add("machine", machineName);

            _clientChannel = new PipeClientChannel(dict, null);
            _serverChannel = new PipeServerChannel(pipeName);
        }

        public PipeChannel(IDictionary properties,
                           IClientChannelSinkProvider clientProviderChain,
                           IServerChannelSinkProvider serverProviderChain)
        {
            _clientChannel = new PipeClientChannel(properties, clientProviderChain);
            _serverChannel = new PipeServerChannel(properties, serverProviderChain);
        }

        // IChannel
        public String ChannelName
        {
            get
            {
                return (_clientChannel.ChannelName);
            }
        }

        public int ChannelPriority
        {
            get
            {
                return (_clientChannel.ChannelPriority);
            }
        }

        public String Parse(String url, out string uri)
        {
            string machineName;
            string pipeName = PipeConnection.Parse(url, out machineName, out uri);
            uri = PipeConnection.BuildObjectUri(machineName, uri);
            return pipeName;
        }

        // IChannelSender
        public IMessageSink CreateMessageSink(String url, Object data, out String uri)
        {
            return _clientChannel.CreateMessageSink(url, data, out uri);
        }

        // IChannelReciever
        public Object ChannelData
        {
            get
            {
                return (_serverChannel == null) ? null : _serverChannel.ChannelData;
            }
        }

        public String[] GetUrlsForUri(String objectURI)
        {
            if(_serverChannel != null)
            {
                return _serverChannel.GetUrlsForUri(objectURI);
            }
            else
            {
                return null;
            }
        }

        public void StartListening(Object data)
        {
            if(_serverChannel != null)
                _serverChannel.StartListening(data);
        }

        public void StopListening(Object data)
        {
            if(_serverChannel != null)
                _serverChannel.StopListening(data);
        }

        public void Dispose()
        {
            if(!_disposed)
            {
                Cleanup(true);
                _disposed = true;

                // Take yourself off the finalization queue to prevent
                // finalization from executing a second time.
                GC.SuppressFinalize(this);
            }
        }

        private void Cleanup(bool disposeManagedResources)
        {
            if(disposeManagedResources)
            {
                // dispose any managed resources here

                if(_serverChannel != null)
                {
                    _serverChannel.Dispose();
                    _serverChannel = null;
                }

                if(_clientChannel != null)
                {
                    _clientChannel.Dispose();
                    _clientChannel = null;
                }
            }

            // dispose any unmanaged resources here
        }

        // Destructor will run only if Dispose() is never called.
        ~PipeChannel()
        {
            Cleanup(false);
        }

        private bool _disposed;
    }
}
