using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyCompany("Sage Software, Inc.")]
[assembly: AssemblyCopyright("� 2010 Sage Software, Inc. All rights reserved.")]
[assembly: AssemblyTrademark("� 2010 Sage Software, Inc. All rights reserved.")]
[assembly: AssemblyConfiguration("CM\\Core")]

// AssemblyVersion changes only by release
[assembly: AssemblyVersion("4.5.0.0")]

// AssemblyFileVersion and AssemblyInformationalVersion change with each build
[assembly: AssemblyFileVersion("4.5.0.21")]
[assembly: AssemblyInformationalVersion("4.5.0.21")]
