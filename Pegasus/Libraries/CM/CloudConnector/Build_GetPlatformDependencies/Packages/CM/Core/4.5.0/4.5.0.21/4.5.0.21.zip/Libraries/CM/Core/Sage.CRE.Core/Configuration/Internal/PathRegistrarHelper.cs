using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Sage.Diagnostics;

namespace Sage.Configuration.Internal
{
    /// <summary>
    /// This internal class contains static methods for maintaining registered paths
    /// </summary>
    internal static class PathRegistrarHelper
    {
        /// <summary>
        /// Register a path with the path registrar helper
        /// </summary>
        /// <param name="key">A key used to identify the path</param>
        /// <param name="path">The path to register</param>
        public static void RegisterPath(string key, string path)
        {
            ArgumentValidator.ValidateNonEmptyString(key, "key", "PathRegistrar");
            ArgumentValidator.ValidateNonEmptyString(path, "path", "PathRegistrar");
            if (!Directory.Exists(path))
            {
                string errorMessage = string.Format(Strings.PathDoesNotExistFormat, path);
                EventLogger.WriteMessage("PathRegistrar", errorMessage, MessageType.Error);
                throw new ArgumentException(errorMessage, "path");
            }
            if (key.IndexOfAny(new char[] { '/', '\\' }) >= 0)
            {
                string errorMessage = Strings.InvalidKeyBadChars;
                EventLogger.WriteMessage("PathRegistrar", errorMessage, MessageType.Error);
                throw new ArgumentException(errorMessage, "key");
            }
            DataRegistry.CreateKeyedValueSet(DataScope.AllUsers, "General", "Locations").SetValue("Paths", key, path);
        }

        /// <summary>
        /// Unregister a path with the path registrar
        /// </summary>
        /// <param name="key">The key of the path to unregister</param>
        public static void UnRegisterPath(string key)
        {
            IKeyedValues table = DataRegistry.OpenKeyedValueSet(DataScope.AllUsers, "General", "Locations");
            if (table != null && table.Contains("Paths", key))
            {
                table.RemoveKey("Paths", key);
            }
        }

        /// <summary>
        /// Determine if a particular path is registered
        /// </summary>
        /// <param name="key">A key for the path</param>
        /// <returns>True if the path is registered, false if not</returns>
        public static bool IsRegistered(string key)
        {
            bool retval = false;

            IKeyedValues table = DataRegistry.OpenKeyedValueSet(DataScope.AllUsers, "General", "Locations");
            if (table != null && table.Contains("Paths", key))
            {
                retval = true;
            }

            return retval;
        }

        /// <summary>
        /// Retrieve a registered path
        /// </summary>
        /// <param name="key">Key of a registered path</param>
        /// <returns>The registered path</returns>
        public static string GetRegisteredPath(string key)
        {
            string retval = null;

            IKeyedValues table = DataRegistry.OpenKeyedValueSet(DataScope.AllUsers, "General", "Locations");
            if (table != null && table.Contains("Paths", key))
            {
                retval = table.GetValue("Paths", key);
            }

            return retval;
        }

        /// <summary>
        /// Retrieve a collection of all registered paths
        /// </summary>
        public static IKeyValueSet[] GetRegisteredPaths()
        {
            IKeyValueSet[] retval = null;
            IKeyedValues table = DataRegistry.OpenKeyedValueSet(DataScope.AllUsers, "General", "Locations");
            if (table != null)
            {
                retval = table.GetAllKeyValueSets("Paths");
            }
            else
            {
                retval = new DataStoreKeyValueSet[0];
            }
            return retval;
        }
    }
}
