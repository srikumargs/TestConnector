﻿using System;

namespace Sage.CRE.Core.SQL
{
    /// <summary>Creates a database using the reverible action pattern.
    /// The construction of a CreateDatabase object will create the database specified.
    /// If the object is disposed without calling the Commit() method, then the newly created database will be deleted.
    /// </summary>
    public class CreateDatabase : Sage.IO.ReversibleAction.ReversibleActionBase
    {



        /// <summary>
        /// Creates a database.
        /// </summary>
        /// <param name="context">The context of the database to create.</param>
        /// <param name="sql">A sql files to run against the new database</param>
        public static void Create(SqlConnectionContext context, string sql)
        {
            string dataLocation; string logLocation;
            SqlCommands.GetDefaultFileLocations(context, out dataLocation, out logLocation);

            SqlConnectionContext tempContext = (SqlConnectionContext)context.Clone();
            tempContext.InitialCatalog = String.Format(System.Globalization.CultureInfo.CurrentUICulture, @"{0} - {1}", context.InitialCatalog, DateTime.Now.ToFileTimeUtc());

            using (CreateDatabase create = new CreateDatabase(tempContext, dataLocation, logLocation))
            {
                create.Forward();

                SqlCommands.ExecuteScriptNoTransaction(tempContext, sql, null);


                using (RenameDatabase renameOriginal = new RenameDatabase(context, context.InitialCatalog))
                {
                    renameOriginal.Forward();

                    using (RenameDatabase renameNew = new RenameDatabase(tempContext, context.InitialCatalog))
                    {
                        renameNew.Forward();

                        System.Data.SqlClient.SqlConnection.ClearAllPools();
                        while (!SqlCommands.DatabaseExists(context)) System.Threading.Thread.Sleep(1000);
                        

                        renameNew.Commit();
                    }

                    renameOriginal.Commit();
                }

                create.Commit();
            }
        }



        /// <summary>Creates a database using the reverible action pattern.
        /// The construction of a CreateDatabase object will create the database specified.
        /// If the object is disposed without calling the Commit() method, then the newly created database will be deleted.
        /// </summary>
        /// <param name="context">The context of the database to create.</param>
        /// <param name="dataPath">The file system path where the MDF file will be stored.</param>
        /// <param name="logPath">The file system path where the LDF file will be stored.</param>
        public CreateDatabase(SqlConnectionContext context, string dataPath, string logPath)
        {
            _context = context;
            _dataPath = dataPath;
            _logPath = logPath;
        }

        /// <summary>Creates the database.
        /// </summary>
        public override void Forward()
        {
            base.Forward();

            DateTime now = DateTime.Now;
            string datafile = System.IO.Path.Combine(_dataPath, String.Format(System.Globalization.CultureInfo.InvariantCulture, @"{0}{1}", _context.InitialCatalog, now.ToFileTimeUtc()));
            string logfile = System.IO.Path.Combine(_logPath, String.Format(System.Globalization.CultureInfo.InvariantCulture, @"{0}{1}", _context.InitialCatalog, now.ToFileTimeUtc()));

            SqlCommands.CreateDatabase(_context, datafile, logfile);
            _created = true;
            SqlCommands.SimpleModeRecovery(_context);

        }

        /// <summary>Drops the newly created database
        /// </summary>
        public override void Reverse()
        {
            if (_created)
            {
                SqlCommands.DropDatabase(_context, true);
            }

            base.Reverse();
        }

        #region Private members
        private SqlConnectionContext _context = new SqlConnectionContext();
        private string _dataPath;
        private string _logPath;
        private bool _created = false;
        #endregion


    }
}
