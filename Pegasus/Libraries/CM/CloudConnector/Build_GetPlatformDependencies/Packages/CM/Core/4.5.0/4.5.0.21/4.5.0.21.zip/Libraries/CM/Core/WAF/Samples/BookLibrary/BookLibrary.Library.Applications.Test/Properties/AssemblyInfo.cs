﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("Waf.BookLibrary.Library.Applications.Test")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Waf Book Library")]


[assembly: Guid("d71381be-f385-4d81-86b6-b559e0b2472b")]
