using System;
using System.Diagnostics;
using System.Collections;
using System.Runtime.InteropServices;
using System.Windows.Forms;


namespace Sage.Diagnostics
{

    /// <summary>
    /// Use this to sprinkle some process "attach" opportunities.  This
    /// is courtesy of my good pal Chad.
    /// </summary>
    [ComVisible(false)]
    public class DebugProcess
    {
#if DEBUG
        private static readonly int VK_CONTROL = 0x11;

        [DllImport("User32.dll")]
        static extern short GetKeyState(int nVirtKey);
#endif
        
        /// <summary>
        /// Use this to sprinkle some debug "attach" points in a process.
        /// </summary>
        [Conditional("DEBUG")] // clients shouldn't bother including a call to this function if they don't have DEBUG defined
        static public void BreakOnControlKey()
        {
#if DEBUG // we don't need to bother including the code for the implementation of this method if we don't have DEBUG defined
            if (GetKeyState(VK_CONTROL) < 0)
            {
                MessageBox.Show(Strings.AttachToDebuggerMessage);
            }
#endif
        }
    }
}