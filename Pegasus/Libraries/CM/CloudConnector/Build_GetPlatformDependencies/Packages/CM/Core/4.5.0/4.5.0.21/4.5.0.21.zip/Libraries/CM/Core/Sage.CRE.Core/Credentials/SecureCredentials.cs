﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security;

namespace Sage.Credentials
{
    public class SecureCredentials : IDisposable
    {
        public String UserName { get; set; }
        public SecureString Password { get; set; }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(true);
        }

        private void Dispose(Boolean disposing)
        {
            if (disposing)
            {
                Password.Dispose();
                Password = null;
            }
        }
    }

}
