using System;
using System.Runtime.InteropServices;

namespace Sage.IO
{
    /// <summary>
    /// Summary description for IPathUtils.
    /// </summary>
    [ComVisible(false)]
    public interface IPathUtils
    {
        /// <summary>
        /// Determine if the specified path is a drive root directory.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if the path is a drive root directory; otherwise, false.</returns>
        bool IsRoot(string path);

        /// <summary>
        /// Get a flag indicating if the path ends with a trailing directory separator character.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if the path has a trailing directory separator character; otherwise, false.</returns>
        bool HasTrailingSeparator(string path);

        /// <summary>
        /// Add a trailing separator if one doesn't already exist.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if a trailing separator was added; otherwise, false.</returns>
        bool AddTrailingSeparator(ref string path);

        /// <summary>
        /// Remove any trailing '\' from the end of s path if it is not a root path.
        /// </summary>
        /// <param name="path">The path to examine\modify.</param>
        /// <returns>Returns true if the path was stripped of a trailing '\'; otherwise, false.</returns>
        bool StripTrailingSlashIfNotRoot(ref string path);

        /// <summary>
        /// Use to clean up a path retrieved from user input or the registry.
        /// Also ensures that if there are multiple paths seperated by ';', only
        /// the first will be used.
        /// </summary>
        /// <param name="path">Path to normalize. A null path is handled by
        /// causing the empty string to be returned.</param>
        /// <returns>Normalized path or empty string if path is null.</returns>
        string Normalize(string path);

        /// <summary>
        /// Use to clean up a path retrieved from user input or the registry.
        /// Also ensures that if there are multiple paths seperated by ';', only
        /// the first will be used.
        /// </summary>
        /// <param name="path">Path to normalize. A null path is handled by
        /// causing the empty string to be returned.</param>
        /// <param name="addTrailingSeparator">Specify whether to add a trailing slash.</param>
        /// <returns>Normalized path or empty string if path is null.</returns>
        string Normalize(string path, bool addTrailingSeparator);

        /// <summary>
        /// Combines two path strings.
        /// </summary>
        /// <param name="path1">First path string: absolute or relative.</param>
        /// <param name="path2">Second path string: relative paths only.</param>
        /// <returns>Combined path string.</returns>
        string Combine(string path1, string path2);

        /// <summary>
        /// Determines if a directory is accessible (e.g. exists and is online).
        /// </summary>
        /// <param name="path">Path to test</param>
        /// <returns>Returns true if path exists and is online, false otherwise.
        /// Guaranteed not to throw exceptions.</returns>
        bool IsAccessibleDirectory(string path);

        /// <summary>
        /// Get the server name from the mapped folder path.
        /// </summary>
        /// <param name="mappedFolderPath">the mapped path to derive a server name from</param>
        /// <returns>The server name or empty string</returns>
        string ServerNameFromMappedFolder(string mappedFolderPath);

        /// <summary>
        /// Get the UNC path from the mapped folder path.
        /// </summary>
        /// <param name="mappedFolderPath">The mapped path to retrieve the UNC path from</param>
        /// <returns>The UNC path or empty string</returns>
        string UNCPathFromMappedFolder(string mappedFolderPath);

        /// <summary>
        /// Determine if a string value appears to be some type of path.
        /// </summary>
        /// <param name="value">The string value to test.</param>
        /// <returns>Returns true if the path</returns>
        bool IsPath(string value);

        /// <summary>
        /// Is the path part of a mapped drive.
        /// </summary>
        /// <param name="path">The path that needs to be tested if it is part of a mapped drive.</param>
        /// <returns>True if the path is part of a mapped drive, false otherwise.</returns>
        bool IsPathMappedDrive(string path);

        /// <summary>
        /// Is the path part of a UNC path.
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        bool IsPathUNC(string path);
        
        /// <summary>
        /// Determine whether the specified path is contained within the list of known substituted drives.
        /// </summary>
        /// <param name="path">The path to test.</param>
        /// <returns>Returns true if the path is substituted; otherwise false</returns>
        bool IsPathToSubstDrive(string path);

        /// <summary>
        /// Remove any trailing '\' from the end of a path
        /// </summary>
        /// <param name="path">The path to examine\modify</param>
        /// <returns>The path without a trailing '\'</returns>
        /// <remarks>If the path does not have a trailing '\' the orginal path will be returned</remarks>
        string StripTrailingSlash(string path);

        /// <summary>
        /// Determines if a path can potentially be virtualized in Windows Vista.
        /// </summary>
        /// <param name="path">The path to examine for potential virtualization.</param>
        /// <returns>True if the path can potentially be virtualized.  False, otherwise.</returns>
        bool PathCanPotentiallyBeVirtualized(string path);

        /// <summary>
        /// Determines if a non-Vista OS path is valid. This will run some of the same tests as done for Vista, but will also check Program Files as well.        
        /// </summary>
        /// <param name="path">The path to examine for potential virtualization.</param>
        /// <returns>Returns true if the path is valid; otherwise, false.</returns>
        bool IsValidNonVistaUACPath(string path);

        /// <summary>
        /// Get the directory name from the path. If the path is a file, the directory is returned; otherwise, the path's sub-directory is returned.
        /// </summary>
        /// <param name="path">The directory or file path.</param>
        /// <returns>Returns the directory name.</returns>
        string GetDirectoryName(string path);

        /// <summary>
        /// Get the filename for the specified path.
        /// </summary>
        /// <param name="path">The path used to extract the filename.</param>
        /// <returns>Returns the filename.</returns>
        string GetFileName(string path);

        /// <summary>
        /// Get the folder name from the specified path.
        /// </summary>
        /// <param name="path">The directory or file path.</param>
        /// <returns>Returns the folder name.</returns>
        string GetFolderName(string path);

        /// <summary>
        /// Checks the path to determine if a file extension exists.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if the path has a file extension; otherwise, false.</returns>
        bool HasExtension(string path);

        /// <summary>
        /// Determines if the character is a directory separator or not.
        /// </summary>
        /// <param name="ch">The character to test.</param>
        /// <returns>Returns true if the character is a directory separator; otherwise, false.</returns>
        bool IsDirectorySeparator(char c);

        /// <summary>
        /// Get the maximum path length (= 260).
        /// </summary>
        /// <remarks>
        /// This value is not yet contained in any .NET class library. There exists a lot of debate and confusion on this value, whether NTFS supports much
        /// larger values than the MAX_PATH value defined in a Windows header.
        /// </remarks>
        int MaxPath { get; }

        /// <summary>
        /// Get the maximum filename length (= 255).
        /// </summary>
        int MaxFilename { get; }
    }
}
