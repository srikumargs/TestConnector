#if DEBUG
using System;
using System.IO;
using System.Text;
using NUnit.Framework;

namespace Sage.IO.Tests
{

    /// <summary>
    /// Test the Storage
    /// </summary>
    [TestFixture]
    public class TestNamedPropertyStorage
    {
        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestAuto()
        {
            NamedPropertyStorage store = new NamedPropertyStorage("Sage\\Test\\NUnitTest.Dat");

            store.WriteProperty("foo1", "bar1");
            store.WriteProperty("foo2", "bar2");

            Assert.AreEqual(store.ReadProperty("foo1"), "bar1"); 
            Assert.AreEqual(store.ReadProperty("foo2"), "bar2"); 

            store.WriteProperty("foo1", "bar3");
            store.WriteProperty("foo2", "bar4");

            Assert.AreEqual(store.ReadProperty("foo1"), "bar3"); 
            Assert.AreEqual(store.ReadProperty("foo2"), "bar4"); 

            store.RemoveProperty("foo1");
            store.RemoveProperty("foo2");

            Assert.AreEqual(store.ReadProperty("foo1"), string.Empty); 
            Assert.AreEqual(store.ReadProperty("foo2"), string.Empty); 

            store.DeleteFile();
            store.Dispose();
        }


        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestAutoPersist()
        {
            NamedPropertyStorage store = new NamedPropertyStorage("NUnitTest.Dat");

            store.WriteProperty("foo1", "bar1");
            store.WriteProperty("foo2", "bar2");

            Assert.AreEqual(store.ReadProperty("foo1"), "bar1"); 
            Assert.AreEqual(store.ReadProperty("foo2"), "bar2"); 

            store.Dispose();

            store = new NamedPropertyStorage("NUnitTest.Dat");

            Assert.AreEqual(store.ReadProperty("foo1"), "bar1"); 
            Assert.AreEqual(store.ReadProperty("foo2"), "bar2"); 

            store.DeleteFile();
            store.Dispose();
        }


        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestManual()
        {
            NamedPropertyStorage store = new NamedPropertyStorage("NUnitTest.Dat", SavePolicy.ManualSave);

            store.WriteProperty("foo1", "bar1");
            store.WriteProperty("foo2", "bar2");

            Assert.AreEqual(store.ReadProperty("foo1"), "bar1"); 
            Assert.AreEqual(store.ReadProperty("foo2"), "bar2"); 

            store.WriteProperty("foo1", "bar3");
            store.WriteProperty("foo2", "bar4");

            Assert.AreEqual(store.ReadProperty("foo1"), "bar3"); 
            Assert.AreEqual(store.ReadProperty("foo2"), "bar4"); 

            store.RemoveProperty("foo1");
            store.RemoveProperty("foo2");

            store.Save();

            Assert.AreEqual(store.ReadProperty("foo1"), string.Empty); 
            Assert.AreEqual(store.ReadProperty("foo2"), string.Empty); 

            store.DeleteFile();
            store.Dispose();
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestManualPersist()
        {
            NamedPropertyStorage store = new NamedPropertyStorage("NUnitTest.Dat", SavePolicy.ManualSave);

            store.WriteProperty("foo1", "bar1");
            store.WriteProperty("foo2", "bar2");

            Assert.AreEqual(store.ReadProperty("foo1"), "bar1"); 
            Assert.AreEqual(store.ReadProperty("foo2"), "bar2"); 

            store.Save();
            store.Dispose();

            store = new NamedPropertyStorage("NUnitTest.Dat", SavePolicy.ManualSave);

            Assert.AreEqual(store.ReadProperty("foo1"), "bar1"); 
            Assert.AreEqual(store.ReadProperty("foo2"), "bar2"); 

            store.DeleteFile();
            store.Dispose();
        }
    }
}

#endif