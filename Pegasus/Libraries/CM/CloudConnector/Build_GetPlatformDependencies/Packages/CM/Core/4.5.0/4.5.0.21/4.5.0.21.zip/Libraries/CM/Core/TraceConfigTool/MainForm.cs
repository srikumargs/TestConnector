using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TraceConfigTool
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            _traceConfigControl.FileNew();
        }

        private void _traceConfigControl_DataStateChanged(object sender, EventArgs e)
        {
            DataStateChangedEventArgs dataStateChangedEventArgs = (e as DataStateChangedEventArgs);

            if(!string.IsNullOrEmpty(dataStateChangedEventArgs.FileName))
            {
                this.Text = string.Format("{0}{1} - Trace Configuration Tool", dataStateChangedEventArgs.FileName, dataStateChangedEventArgs.Dirty ? "*" : "");
            }
            else
            {
                this.Text = string.Format("Untitled{0} - Trace Configuration Tool", dataStateChangedEventArgs.Dirty ? "*" : "");
            }
        }

    }
}