using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.Text;
using Sage.Diagnostics;

namespace Sage.Configuration
{
    /// <summary>
    /// This class is used to help support registry settings
    /// </summary>
    public class RegistryHelper : IDisposable
    {
        #region .NET/Registry Type Conversion Static Methods

        /// <summary>
        /// Converts the Registry data type to a .NET data type.
        /// </summary>
        /// <param name="valueKind">The Registry value kind.</param>
        /// <returns>Returns the equivalent .NET data type.</returns>
        public static Type GetTypeFromValueKind(RegistryValueKind valueKind)
        {
            Type valueType = typeof(string);

            switch (valueKind)
            {
                case RegistryValueKind.Binary:
                    valueType = typeof(byte[]);
                    break;

                case RegistryValueKind.DWord:
                    valueType = typeof(int);
                    break;

                case RegistryValueKind.ExpandString:
                case RegistryValueKind.MultiString:
                case RegistryValueKind.String:
                    valueType = typeof(string);
                    break;

                case RegistryValueKind.QWord:
                    valueType = typeof(long);
                    break;

                case RegistryValueKind.Unknown:
                    valueType = typeof(object);
                    break;

                default:
                    System.Diagnostics.Debug.Assert(false);
                    break;
            }

            return valueType;
        }

        /// <summary>
        /// Gets the .NET data type based on the specified Registry value name.
        /// </summary>
        /// <param name="valueName">The Registry value name.</param>
        /// <returns>Returns the equivalent .NET data type.</returns>
        public Type GetTypeFromValueKind(string valueName)
        {
            RegistryKey key = _hiveRegistryKey.OpenSubKey(_subKey);
            return GetTypeFromValueKind(key.GetValueKind(valueName));
        }

        /// <summary>
        /// Converts the Registry data type to a .NET data type.
        /// </summary>
        /// <param name="obj">The object from which to get the type.</param>
        /// <returns>Returns the equivalent .NET data type.</returns>
        public static RegistryValueKind GetValueKindFromType(object obj)
        {
            Type t = obj.GetType();

            // The big catch all will be the string.
            if (t == typeof(System.Byte) ||
                t == typeof(System.SByte) ||
                t == typeof(System.Int16) ||
                t == typeof(System.UInt16) ||
                t == typeof(System.Int32) ||
                t == typeof(System.UInt32))
            {
                return RegistryValueKind.DWord;
            }
            else if (obj == typeof(System.Int64) ||
                obj == typeof(System.UInt64))
            {
                return RegistryValueKind.QWord;
            }
            else if (obj == typeof(byte[]))
            {
                return RegistryValueKind.Binary;
            }
            else
            {
                return RegistryValueKind.String;
            }
        }

        #endregion

        // subkey e.g.  "Software\Sage"
        private string _subKey;

        // Should be a legal static registry hive.
        private RegistryKey _hiveRegistryKey;

        // Store the initial registry hive.
        private RegistryHive _registryHive;

        // hidden
        private RegistryHelper() {}

        /// <summary>
        /// Constructor. This should be called if you only want to specify the hive but not a sub key.
        /// </summary>
        public RegistryHelper(RegistryHive hive)
            : this(hive, null)
        { }

        /// <summary>
        /// Specify the subkey in the ctor - default hive is CurrentUser
        /// </summary>
        /// <param name="subKey">The sub key.</param>
        public RegistryHelper(string subKey) 
            : this(RegistryHive.CurrentUser, subKey)
        { }

        /// <summary>
        /// Specify the subkey and the hive in the ctor 
        /// </summary>
        /// <param name="hive">Specify the Registry hive.</param>
        /// <param name="subKey">Specify the Registry sub key.</param>
        public RegistryHelper(RegistryHive hive, string subKey)
        {
            this._registryHive = hive;
            this._subKey = subKey;
            this._hiveRegistryKey = KeyFromRegistryHive(hive);
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~RegistryHelper()
        {
            Dispose(false);
        }

        /// <summary>
        /// Close the current key if currently opened.
        /// </summary>
        public void Close()
        {
            if (this._hiveRegistryKey != null)
            {
                this._hiveRegistryKey.Close();
                this._hiveRegistryKey = null;
            }
        }

        /// <summary>
        /// Determine if the the specified sub key exists.
        /// </summary>
        /// <param name="subKeyToFind">The sub key to check.</param>
        /// <returns>Returns true if the sub key is found; otherwise, false.</returns>
        public bool Exists(string subKeyToFind)
        {
            return (_hiveRegistryKey.OpenSubKey(subKeyToFind) != null);
        }

        /// <summary>
        /// Set a new sub key. The sub key can either be an absolute sub key or relative to the current one.
        /// </summary>
        /// <param name="subKey">Specify the Registry sub key.</param>
        /// <param name="isRelativeSubKey">Specify whether the sub key is relative to the current sub key or absolute. 
        /// If the key is relative, the name is appended to the current sub key.</param>
        public void SetSubKey(string subKey, bool isRelativeSubKey)
        {
            if (!isRelativeSubKey ||
                string.IsNullOrEmpty(this.SubKey))
            {
                _subKey = subKey;
            }
            else
            {
                // Append it.
                _subKey = string.Format("{0}\\{1}", this._subKey, subKey);
            }

            // Create a new Registry key.
            this._hiveRegistryKey = KeyFromRegistryHive(this._registryHive);
        }

        /// <summary>
        /// Get the current sub key.
        /// </summary>
        public string SubKey
        {
            get { return this._subKey; }
        }

        /// <summary>
        /// Get the current Registry hive.
        /// </summary>
        public RegistryHive Hive
        {
            get { return this._registryHive; }
        }        

        /// <summary>
        /// Get all the value names for the current hive/key.
        /// </summary>
        /// <returns>Returns an array of strings.</returns>
        public string[] GetValueNames()
        {
            RegistryKey key = _hiveRegistryKey.OpenSubKey(_subKey);

            if (key != null)
            {
                return key.GetValueNames();
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Perform a check to see if the specified value name exists within the current subkey.
        /// </summary>
        /// <param name="valueName">The value name to check.</param>
        /// <returns>Returns true if the value name is found; otherwise, false.</returns>
        public bool ContainsValueName(string valueName)
        {
            string[] valueNamesArr = this.GetValueNames();

            if (valueNamesArr != null)
            {
                foreach (string thisValueName in valueNamesArr)
                {
                    if (string.Compare(thisValueName, valueName, true, System.Globalization.CultureInfo.CurrentCulture) == 0)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Get all the sub key names for the current hive/key.
        /// </summary>
        /// <returns>Returns an array of strings.</returns>
        public string[] GetSubKeyNames()
        {
            return this.GetSubKeyNames(_subKey);
        }

        /// <summary>
        /// Get all the sub key names for the specified sub key.
        /// </summary>
        /// <param name="subKey">The sub key.</param>
        /// <returns>Returns an array of strings.</returns>
        public string[] GetSubKeyNames(string subKey)
        {
            RegistryKey key = _hiveRegistryKey.OpenSubKey(subKey);

            if (key != null)
            {
                return key.GetSubKeyNames();
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Get the full key name.
        /// </summary>
        /// <returns>Returns the key name string.</returns>
        public string GetFullKeyName()
        {
            RegistryKey key = _hiveRegistryKey.OpenSubKey(_subKey);

            if (key != null)
            {
                return key.Name;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Obtains the key value if it exists.
        /// </summary>
        /// <param name="keyStr">The key value to read.</param>
        /// <returns>key value otherwise null</returns>
        public string GetKeyValue(string keyStr)
        {
            string retval = null;
            RegistryKey key = _hiveRegistryKey.OpenSubKey(_subKey);

            if (key != null)
            {
                object objValue = null;

                if ((objValue = key.GetValue(keyStr)) != null)
                {
                    // Handle multi-sz strings correctly.
                    if (objValue is System.Array)
                    {                        
                        System.Array arrData = (System.Array)objValue;

                        if (arrData.Length > 0 &&
                            arrData.GetValue(0) is string)
                        {
                            StringBuilder sb = new StringBuilder();

                            foreach (object obj in arrData)
                            {
                                // Put spaces after each item.
                                if (sb.Length > 0)
                                    sb.Append(" ");

                                sb.Append(obj.ToString());
                            }

                            retval = sb.ToString();
                        }

                        // Handle binary data correctly.
                        else
                        {
                            byte[] binaryData = new byte[arrData.Length];
                            arrData.CopyTo(binaryData, 0);
                            retval = System.Convert.ToBase64String(binaryData);
                        }                        
                    }
                    else
                    {
                        retval = objValue.ToString();
                    }
                } 
                key.Close();
            }
            return retval;
        }

        #region SetKeyValue Overloads

        // Note: The main reason these methods are here is because the original code would always create string
        // types in the Registry. This created a big problem with a particular component because it expected the
        // value to be a DWord.

        /// <summary>
        /// Set the registry key and value.
        /// </summary>
        /// <param name="keyStr">The Registry key value name.</param>
        /// <param name="valueStr">The string value.</param>
        public void SetKeyValue(string keyStr, string valueStr)
        {
            this.SetKeyValue(keyStr, valueStr, RegistryValueKind.String);
        }

        /// <summary>
        /// Set the registry key and value (for DWord types).
        /// </summary>
        /// <param name="keyStr">The Registry key value name.</param>
        /// <param name="value">The integer value.</param>
        public void SetKeyValue(string keyStr, int value)
        {
            this.SetKeyValue(keyStr, value, RegistryValueKind.DWord);
        }

        /// <summary>
        /// Set the registry key and value (for QWord types).
        /// </summary>
        /// <param name="keyStr">The Registry key value name.</param>
        /// <param name="value">The long value.</param>
        public void SetKeyValue(string keyStr, long value)
        {
            this.SetKeyValue(keyStr, value, RegistryValueKind.QWord);
        }

        /// <summary>
        /// Set the registry key and value (for Binary types).
        /// </summary>
        /// <param name="keyStr">The Registry key value name.</param>
        /// <param name="value">The byte array value.</param>
        public void SetKeyValue(string keyStr, byte[] value)
        {
            this.SetKeyValue(keyStr, value, RegistryValueKind.Binary);
        }

        /// <summary>
        /// Set the registry key and value. The Registry value type is based on the specified object type.
        /// </summary>
        /// <param name="keyStr">The Registry key value name.</param>
        /// <param name="value">The object value.</param>
        public void SetKeyValue(string keyStr, object value)
        {
            this.SetKeyValue(keyStr, value, GetValueKindFromType(value));
        }

        /// <summary>
        /// Set the registry key and value. The Registry value type is based on the specified object type.
        /// </summary>
        /// <param name="keyStr">The Registry key value name.</param>
        /// <param name="value">The string value.</param>
        /// <param name="kind">The kind or type.</param>
        public void SetKeyValue(string keyStr, object value, RegistryValueKind kind)
        {
            RegistryKey key = _hiveRegistryKey.CreateSubKey(_subKey);

            if (key != null)
            {
                key.SetValue(keyStr, value, kind);
                key.Close();
            }
            else
            {
                OnFailedToCreateKey(keyStr);
            }
        }

        #endregion

        /// <summary>
        /// Remove the subkey
        /// </summary>
        /// <param name="valueName"></param>
        public void DeleteKeyValue(string valueName)
        {
            RegistryKey key = _hiveRegistryKey.CreateSubKey( _subKey );
            if( key != null )
            {
                key.DeleteValue(valueName, false);
                key.Close();
            }
        }

        /// <summary>
        /// Remove the subkey tree
        /// </summary>
        public void DeleteKeyTree()
        {
            try
            {
                _hiveRegistryKey.DeleteSubKeyTree(_subKey);
            }
            catch (ArgumentException) {}
        }

        /// <summary>
        /// Map the enum to the approriate static key
        /// </summary>
        /// <param name="hive"></param>
        /// <returns></returns>
        private RegistryKey KeyFromRegistryHive(RegistryHive hive)
        {
            RegistryKey key = null;
            if (hive == RegistryHive.ClassesRoot)
            {
                key = Registry.ClassesRoot;
            }
            else if (hive == RegistryHive.CurrentConfig)
            {
                key = Registry.CurrentConfig;
            }
            else if (hive == RegistryHive.CurrentUser)
            {
                key = Registry.CurrentUser;
            }
            else if (hive == RegistryHive.DynData)
            {
                key = Registry.DynData;
            }
            else if (hive == RegistryHive.LocalMachine)
            {
                key = Registry.LocalMachine;
            }
            else if (hive == RegistryHive.PerformanceData)
            {
                key = Registry.PerformanceData;
            }
            else if (hive == RegistryHive.Users)
            {
                key = Registry.Users;
            }
            return key;
        }

        /// <summary>
        /// Handle the failed to create key error
        /// </summary>
        /// <param name="keyName">The name of the key</param>
        private void OnFailedToCreateKey( string keyName )
        {            
            string errorMessage = string.Format( Strings.FailedToCreateRegistryKeyFormat, keyName );
            EventLogger.WriteMessage( "DesktopRegistry", errorMessage, MessageType.Error );
            Assertions.Assert( false, errorMessage );
        }

        #region Implementation of IDisposable

        private bool _disposed = false;

        /// <summary>
        /// Cleanup unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Clean up resources.
        /// </summary>
        /// <param name="disposing">Specify whether this object is being disposed.</param>
        protected virtual void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!_disposed)
            {
                this.Close();
            }
            _disposed = true;
        }

        #endregion
    }    

    /// <summary>
    /// Defines an object that holds information about an item in the Windows Registry, as well as the actual type/value.
    /// </summary>
    public struct RegistryNameValue
    {
        private string m_fullKeyName;
        private Type m_valueType;
        private string m_valueName;
        private object m_value;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="fullKeyName">The full Registry key name.</param>
        /// <param name="valueType">The Registry value type.</param>
        /// <param name="valueName">The Registry value name.</param>
        /// <param name="value">The Registry value.</param>
        public RegistryNameValue(string fullKeyName, Type valueType, string valueName, object value)
        {
            this.m_fullKeyName = fullKeyName;
            this.m_valueType = valueType;
            this.m_valueName = valueName;
            this.m_value = value;
        }

        /// <summary>
        /// Get the full Registry key name (IE hive name + sub key).
        /// </summary>
        public string FullKeyName
        {
            get { return this.m_fullKeyName; }
        }

        /// <summary>
        /// Get the Registry value type.
        /// </summary>
        public Type ValueType
        {
            get { return this.m_valueType; }
        }

        /// <summary>
        /// Get the Registry value name.
        /// </summary>
        public string ValueName
        {
            get { return this.m_valueName; }
        }

        /// <summary>
        /// Get the Registry value.
        /// </summary>
        public object Value
        {
            get { return this.m_value; }
        }

        /// <summary>
        /// Get the converted value. This will specifically convert binary data properly.
        /// </summary>
        /// <returns>Returns the object value to a proper string value.</returns>
        public string ConvertValue()
        {
            if (this.Value == null)
                return "";

            if (this.ValueType == typeof(byte[]))
                return System.Convert.ToBase64String((byte[])this.Value);
            else
                return this.Value.ToString();
        }
    }

    /// <summary>
    /// Defines a structure that holds essential information on an item found in the Registry.
    /// </summary>
    public struct RegistryInfo
    {
        /// <summary>
        /// Get/Set the Registry hive.
        /// </summary>
        public Microsoft.Win32.RegistryHive Hive;

        /// <summary>
        /// Get/Set the Registry Sub Key.
        /// </summary>
        public string SubKey;

        /// <summary>
        /// Get/Set the Registry value name.
        /// </summary>
        public string ValueName;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hive">The Registry hive.</param>
        /// <param name="subKey">The Registry sub key.</param>
        /// <param name="valueName">The Registry value name.</param>
        public RegistryInfo(Microsoft.Win32.RegistryHive hive, string subKey, string valueName)
        {
            this.Hive = hive;
            this.SubKey = subKey;
            this.ValueName = valueName;
        }
    };

    /// <summary>
    /// Defines a structure that holds Registry info to be used when converting to the Data Registry.
    /// </summary>
    public struct DataRegistryInfo
    {
        /// <summary>
        /// Get/Set the Registry hive.
        /// </summary>
        public Microsoft.Win32.RegistryHive Hive;

        /// <summary>
        /// Get/Set the Registry Sub Key.
        /// </summary>
        public string SubKey;

        /// <summary>
        /// Get/Set the Data Registry key value set name.
        /// </summary>
        public string KeyValueSetName;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hive">The Registry hive.</param>
        /// <param name="subKey">The Registry sub key.</param>
        /// <param name="keyValueSetName">The data registry key value set name.</param>
        public DataRegistryInfo(Microsoft.Win32.RegistryHive hive, string subKey, string keyValueSetName)
        {
            this.Hive = hive;
            this.SubKey = subKey;
            this.KeyValueSetName = keyValueSetName;
        }

        /// <summary>
        /// Constructor. This should be called to make a copy.
        /// </summary>
        /// <param name="info">The existing data registry info object.</param>
        public DataRegistryInfo(DataRegistryInfo info)
        {
            this.Hive = info.Hive;
            this.SubKey = info.SubKey;
            this.KeyValueSetName = info.KeyValueSetName;
        }
    }
}
