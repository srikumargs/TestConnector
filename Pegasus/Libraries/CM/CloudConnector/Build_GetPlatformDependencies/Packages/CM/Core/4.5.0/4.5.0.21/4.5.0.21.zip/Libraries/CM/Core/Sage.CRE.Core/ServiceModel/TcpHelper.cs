﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Threading;

namespace Sage.ServiceModel
{
    public static class TcpHelper
    {
        private enum SocketErrorCodes
        {
            InterruptedFunctionCall = 10004,
            PermissionDenied = 10013,
            BadAddress = 10014,
            InvalidArgument = 10022,
            TooManyOpenFiles = 10024,
            ResourceTemporarilyUnavailable = 10035,
            OperationNowInProgress = 10036,
            OperationAlreadyInProgress = 10037,
            SocketOperationOnNonSocket = 10038,
            DestinationAddressRequired = 10039,
            MessgeTooLong = 10040,
            WrongProtocolType = 10041,
            BadProtocolOption = 10042,
            ProtocolNotSupported = 10043,
            SocketTypeNotSupported = 10044,
            OperationNotSupported = 10045,
            ProtocolFamilyNotSupported = 10046,
            AddressFamilyNotSupported = 10047,
            AddressInUse = 10048,
            AddressNotAvailable = 10049,
            NetworkIsDown = 10050,
            NetworkIsUnreachable = 10051,
            NetworkReset = 10052,
            ConnectionAborted = 10053,
            ConnectionResetByPeer = 10054,
            NoBufferSpaceAvailable = 10055,
            AlreadyConnected = 10056,
            NotConnected = 10057,
            CannotSendAfterShutdown = 10058,
            ConnectionTimedOut = 10060,
            ConnectionRefused = 10061,
            HostIsDown = 10064,
            HostUnreachable = 10065,
            TooManyProcesses = 10067,
            NetworkSubsystemIsUnavailable = 10091,
            UnsupportedVersion = 10092,
            NotInitialized = 10093,
            ShutdownInProgress = 10101,
            ClassTypeNotFound = 10109,
            HostNotFound = 11001,
            HostNotFoundTryAgain = 11002,
            NonRecoverableError = 11003,
            NoDataOfRequestedType = 11004
        }


        public static void TestConnect(Uri uri, Int32 timeout)
        {
            Boolean successfulInvocation = false;
            TimeSpan timeoutTimeSpan = TimeSpan.FromMilliseconds(timeout);
            ProgressiveBackoffHelper progressiveBackoffHelper = new ServiceModel.ProgressiveBackoffHelper();

            // Test the connection
            do
            {
                try
                {
                    progressiveBackoffHelper.DelayIfNeeded(timeout);
                    TestConnect(uri);
                    successfulInvocation = true;
                }
                catch (Exception ex)
                {
                    if (ex is CommunicationFailureException &&
                        ex.InnerException != null &&
                        ex.InnerException is SocketException &&
                        ((ex.InnerException as SocketException).ErrorCode != (Int32)SocketErrorCodes.HostNotFound ||
                         (ex.InnerException as SocketException).ErrorCode != (Int32)SocketErrorCodes.ConnectionRefused))
                    {
                        // If the ErrorCode looks like it is indicative of the host being wrong (or off) ... or because the listening port is not
                        // open, then don't retry anymore ... just return now

                        // CAREFUL: ConnectionRefused _can_ occur if the server is at its limit in its listen connection backlog; this
                        // situation can be mitigated to some degree by increasing the listenBacklog attribute on the server's
                        // binding ... we are going to assume that it has been set properly and that we are getting ConnectionRefused
                        // ... not because the server is busy, but because we have the wrong port number (or firewalled port, etc.) ...
                        // neither of which problem will be fixed with retry logic.  Unfortunately, if the problem _was_ due to server
                        // overload, then it likely could have been worked around by client-side retry logic, but we are going to give
                        // up now.
                        throw;
                    }
                }

                if (!successfulInvocation && (progressiveBackoffHelper.ElapsedTime >= timeoutTimeSpan))
                {
                    throw new CommunicationFailureException(String.Format("Failed to establish TCP connection to {0}:{1}.\r\n\r\n{2}.", uri.Host, uri.Port, String.Format("Timeout waiting {0} milliseconds to establish TCP connection.", timeout)), null);
                }
            } while (!successfulInvocation);
        }

        private static void TestConnect(Uri uri)
        {
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            ConnectAsyncState connectAsyncState = new ConnectAsyncState { Socket = socket, Event = new ManualResetEvent(false) };
            try
            {
                IAsyncResult asyncResult = socket.BeginConnect(uri.Host, uri.Port, new AsyncCallback(ConnectCallback), connectAsyncState);
                if (!connectAsyncState.Event.WaitOne(TEST_CONNECT_RESULT_TIMEOUT))
                {
                    throw new CommunicationFailureException(String.Format("Failed to establish TCP connection to {0}:{1}.\r\n\r\n{2}.", uri.Host, uri.Port, String.Format("Timeout waiting {0} milliseconds to establish TCP connection.", TEST_CONNECT_RESULT_TIMEOUT)), null);
                }
            }
            finally
            {
                socket.Close();
                if (connectAsyncState.Error != null)
                {
                    throw new CommunicationFailureException(String.Format("Failed to establish TCP connection to {0}:{1}.\r\n\r\n{2}.", uri.Host, uri.Port, connectAsyncState.Error.Message), connectAsyncState.Error);
                }
            }
        }

        private sealed class ConnectAsyncState
        {
            public Socket Socket { get; set; }
            public ManualResetEvent Event { get; set; }
            public Exception Error { get; set; }
        }

        private static void ConnectCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the socket from the state object.
                Socket client = ((ConnectAsyncState)ar.AsyncState).Socket;

                // Complete the connection.
                client.EndConnect(ar);
            }
            catch (Exception e)
            {
                // store any error that may have occurred
                ((ConnectAsyncState)ar.AsyncState).Error = e;
            }
            finally
            {
                // notify that we have finished
                ((ConnectAsyncState)ar.AsyncState).Event.Set();
            }
        }

        private const Int32 MAX_RETRY_POWER_OF_TWO = 12;
        private const Int32 TEST_CONNECT_RESULT_TIMEOUT = 30 * 1000;
    }
}
