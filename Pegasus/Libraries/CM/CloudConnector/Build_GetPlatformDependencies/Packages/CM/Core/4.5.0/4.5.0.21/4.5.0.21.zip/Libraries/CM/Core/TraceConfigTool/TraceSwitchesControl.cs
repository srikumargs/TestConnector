using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Xml;

using Sage.Activation;
using Sage.Diagnostics;

namespace TraceConfigTool
{
    public partial class TraceSwitchesControl : UserControl
    {
        #region Constructors
        public TraceSwitchesControl()
        {
            InitializeComponent();

            _setAllAssemblySwitchLevelsToolStripDropDownButton.DropDownDirection = ToolStripDropDownDirection.BelowRight;
        }
        #endregion

        public void Reset()
        {
            if(!AssemblyUtils.IsCurrentlyShowingInDesigner)
            {
                string traceSwitchesTypeName = GenerateTraceSwitchesType();

                _propertyGrid.SelectedObject = TypeBuilder.CreateObject(traceSwitchesTypeName);
            }
        }

        public void Reset(XmlDocument document)
        {
            Reset();

            XmlNodeList switches = document.SelectNodes("//configuration/system.diagnostics/switches/*");

            List<string> switchNames = new List<string>();
            foreach(XmlNode switchNode in switches)
            {
                string switchName = string.Empty;
                if(XmlNodeHelper.GetOptionalStringAttributeValue(switchNode, "name", ref switchName) && !string.IsNullOrEmpty(switchName))
                {
                    switchNames.Add(switchName);
                }
            }

            if(!switchNames.Contains("GlobalDefault"))
            {
                switchNames.Add("GlobalDefault");
            }

            string traceSwitchesTypeName = GenerateTraceSwitchesType(switchNames.ToArray());
            object traceOptions = TypeBuilder.CreateObject(traceSwitchesTypeName);

            foreach(string switchName in switchNames)
            {
                XmlNode switchNode = document.SelectSingleNode(string.Format("//configuration/system.diagnostics/switches/add[@name='{0}']", switchName));
                if(switchNode != null)
                {
                    int traceLevelAsInt = 0;
                    if(XmlNodeHelper.GetOptionalInt32AttributeValue(switchNode, "value", ref traceLevelAsInt))
                    {
                        traceOptions.GetType().InvokeMember(switchName, BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.Public, null, traceOptions, new object[] { (System.Diagnostics.TraceLevel) traceLevelAsInt });
                    }
                }
            }

            _propertyGrid.SelectedObject = traceOptions;
        }

        public void WriteSwitchElements(XmlTextWriter xmlTextWriter)
        {
            GridItem rootGridItem = FindRootGridItem(_propertyGrid.SelectedGridItem.Label);
            foreach(GridItem gridItem in rootGridItem.GridItems)
            {
                string switchName = gridItem.Label;
                if(switchName == "[Global Default]")
                {
                    switchName = "GlobalDefault";
                }

                System.Diagnostics.TraceLevel traceLevel = (System.Diagnostics.TraceLevel) gridItem.Value;
                xmlTextWriter.WriteStartElement("add");
                {
                    xmlTextWriter.WriteAttributeString("name", switchName);
                    xmlTextWriter.WriteAttributeString("value", Convert.ToInt32(traceLevel).ToString());
                }
                xmlTextWriter.WriteEndElement(); // add
            }
        }

        private string GenerateTraceSwitchesType()
        {
            return GenerateTraceSwitchesType(new string[] { "GlobalDefault" });
        }


        private string GenerateTraceSwitchesType(string[] switchNames)
        {
            string result = Guid.NewGuid().ToString();

            TypeBuilder typeBuilder = new TypeBuilder();
            typeBuilder.DefinePublicClassType(result);
            typeBuilder.DefinePublicInstanceConstructor();

            foreach(string switchName in switchNames)
            {
                typeBuilder.DefinePropertyAndInstanceField(switchName, "_" + switchName, typeof(System.Diagnostics.TraceLevel));
                if(switchName == "GlobalDefault")
                {
                    typeBuilder.ApplyAttributeToProperty(switchName, typeof(DisplayNameAttribute), new Type[] { typeof(string) }, new object[] { "[Global Default]" });
                    typeBuilder.ApplyAttributeToProperty(switchName, typeof(DescriptionAttribute), new Type[] { typeof(string) }, new object[] { string.Format("Controls the default level of tracing output for any assemblies which are not explicitly configured.", switchName) });
                }
                else
                {
                    typeBuilder.ApplyAttributeToProperty(switchName, typeof(DisplayNameAttribute), new Type[] { typeof(string) }, new object[] { switchName });
                    typeBuilder.ApplyAttributeToProperty(switchName, typeof(DescriptionAttribute), new Type[] { typeof(string) }, new object[] { string.Format("Controls the level of tracing output for the '{0}' assembly.", switchName) });
                }
            }

            typeBuilder.CreateType();

            return result;
        }

        private void _addToolStripButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Assembly Files (*.dll;*.exe)|*.dll;*.exe|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 0;
            openFileDialog.Title = "Add Trace Switches for Select Assemblies";
            openFileDialog.AddExtension = false;
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;
            openFileDialog.Multiselect = true;
            openFileDialog.ShowReadOnly = false;
            openFileDialog.ValidateNames = true;
            if(openFileDialog.ShowDialog(this.ParentForm) == DialogResult.OK)
            {
                ArrayList switchNamesToAdd = new ArrayList();
                foreach(string fileName in openFileDialog.FileNames)
                {
                    switchNamesToAdd.Add(Path.GetFileNameWithoutExtension(fileName));
                }

                AddSwitches((string[]) switchNamesToAdd.ToArray(typeof(string)));
            }
        }

        private delegate void AddSwitchesDelegate(string[] switchNamesToAdd);
        private void AddSwitches(string[] switchNamesToAdd)
        {
            if(this.InvokeRequired)
            {
                this.Invoke(new AddSwitchesDelegate(AddSwitches), new object[] { switchNamesToAdd });
            }
            else
            {
                // save away the old trace options
                object oldTraceOptions = _propertyGrid.SelectedObject;

                // save away the property names for all properties except the currently selected one
                PropertyInfo[] propertyInfos = oldTraceOptions.GetType().GetProperties();

                List<string> oldPropertyNames = new List<string>();
                List<string> newPropertyNames = new List<string>();
                List<string> initializeToErrorPropertyNames = new List<string>();
                foreach(PropertyInfo propertyInfo in propertyInfos)
                {
                    oldPropertyNames.Add(propertyInfo.Name);
                    newPropertyNames.Add(propertyInfo.Name);
                }

                foreach(string switchNameToAdd in switchNamesToAdd)
                {
                    CaseInsensitiveStringPredicateEvaluator evaluator = new CaseInsensitiveStringPredicateEvaluator(switchNameToAdd);
                    if(string.IsNullOrEmpty(newPropertyNames.Find(new Predicate<string>(evaluator.Matches))))
                    {
                        newPropertyNames.Add(switchNameToAdd);
                        initializeToErrorPropertyNames.Add(switchNameToAdd);
                    }
                }

                // generate up a new type which contains all the of old properties except the one that was to be deleted
                string newTypeName = GenerateTraceSwitchesType(newPropertyNames.ToArray());
                object newTraceOptions = TypeBuilder.CreateObject(newTypeName);

                // populate the new object with the values from the old object
                foreach(string propertyName in oldPropertyNames)
                {
                    object propertyValue = oldTraceOptions.GetType().InvokeMember(propertyName, BindingFlags.GetProperty | BindingFlags.Instance | BindingFlags.Public, null, oldTraceOptions, null);
                    newTraceOptions.GetType().InvokeMember(propertyName, BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.Public, null, newTraceOptions, new object[] { propertyValue });
                }

                // populate the new values to 'Error'
                foreach(string propertyName in initializeToErrorPropertyNames)
                {
                    newTraceOptions.GetType().InvokeMember(propertyName, BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.Public, null, newTraceOptions, new object[] { System.Diagnostics.TraceLevel.Error });
                }

                // save the name of the currently selected grid item
                string selectedObjectLabel = _propertyGrid.SelectedGridItem.Label;

                // set the property grid to use the new object
                _propertyGrid.SelectedObject = newTraceOptions;

                // restore the previously selected grid item
                _propertyGrid.SelectedGridItem = FindGridItem(selectedObjectLabel);

                FireDataChanged();
            }
        }

        private void _deleteToolStripButton_Click(object sender, EventArgs e)
        {
            if(_propertyGrid.SelectedGridItem.Label == "[Global Default]")
            {
                MessageBox.Show(this.ParentForm, "Cannot remove 'Global Default' trace switch.", "Delete Trace Switch", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // save away the old trace options
            object oldTraceOptions = _propertyGrid.SelectedObject;

            // save away the property names for all properties except the currently selected one
            PropertyInfo[] propertyInfos = oldTraceOptions.GetType().GetProperties();

            List<string> newPropertyNames = new List<string>();
            foreach(PropertyInfo propertyInfo in propertyInfos)
            {
                if(propertyInfo.Name != _propertyGrid.SelectedGridItem.Label)
                {
                    newPropertyNames.Add(propertyInfo.Name);
                }
            }

            // generate up a new type which contains all the of old properties except the one that was to be deleted
            string newTypeName = GenerateTraceSwitchesType(newPropertyNames.ToArray());
            object newTraceOptions = TypeBuilder.CreateObject(newTypeName);

            // populate the new object with the values from the old object
            foreach(string propertyName in newPropertyNames)
            {
                object propertyValue = oldTraceOptions.GetType().InvokeMember(propertyName, BindingFlags.GetProperty | BindingFlags.Instance | BindingFlags.Public, null, oldTraceOptions, null);
                newTraceOptions.GetType().InvokeMember(propertyName, BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.Public, null, newTraceOptions, new object[] { propertyValue });
            }

            // save the name of the closest sibling grid item
            string newSelectedGridItemLabel = FindClosestSibilingGridItem(_propertyGrid.SelectedGridItem).Label;

            // set the property grid to use the new object
            _propertyGrid.SelectedObject = newTraceOptions;

            // select the closest sibling grid item identified previously
            _propertyGrid.SelectedGridItem = FindGridItem(newSelectedGridItemLabel);

            FireDataChanged();
        }

        private void _propertyGrid_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            FireDataChanged();
        }

        private GridItem FindRootGridItem(string label)
        {
            object root = _propertyGrid.SelectedGridItem;
            while((root as GridItem).Parent != null)
            {
                root = (root as GridItem).Parent;
            }

            return (root as GridItem);
        }

        private GridItem FindGridItem(string label)
        {
            GridItem rootGridItem = FindRootGridItem(label);
            return FindGridItem(label, rootGridItem);
        }

        private GridItem FindGridItem(string label, GridItem rootGridItem)
        {
            GridItem result = null;

            if(rootGridItem.Label == label)
            {
                result = rootGridItem;
            }
            else
            {
                foreach(GridItem gridItem in rootGridItem.GridItems)
                {
                    result = FindGridItem(label, gridItem);
                    if(result != null)
                    {
                        break;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Finds the closest sibling grid item to the one provided.  Prefers the one after this one.  If not available, picks the one just
        /// prior.
        /// </summary>
        /// <remarks>
        /// This method is not suitable for general-purpose use.  It works for our scenario because a) we always have at least one item in the grid and
        /// b) the items are in a flat list
        /// </remarks>
        /// <param name="referenceGridItem"></param>
        /// <returns></returns>
        private GridItem FindClosestSibilingGridItem(GridItem referenceGridItem)
        {
            GridItem result = null;

            GridItem parentGridItem = referenceGridItem.Parent;

            for(int i = 0 ; i < parentGridItem.GridItems.Count - 1 ; i++)
            {
                if(parentGridItem.GridItems[i] == referenceGridItem)
                {
                    result = parentGridItem.GridItems[i + 1];
                    break;
                }
            }

            if(result == null) // if null, then it must be the last GridItem in the list
            {
                if(parentGridItem.GridItems.Count >= 2) // if there are at least two, then we can return the one before the last one in the list
                {
                    result = parentGridItem.GridItems[parentGridItem.GridItems.Count - 2];
                }
            }

            return result;
        }

        public event EventHandler DataChanged;

        private void FireDataChanged()
        {
            if(DataChanged != null)
            {
                DataChanged(this, new EventArgs());
            }
        }

        private void _importReferencesToolStripButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Assembly Files (*.dll;*.exe)|*.dll;*.exe|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 0;
            openFileDialog.Title = "Import Reference Information from Selected Assembly";
            openFileDialog.AddExtension = false;
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;
            openFileDialog.Multiselect = false;
            openFileDialog.ShowReadOnly = false;
            openFileDialog.ValidateNames = true;
            if(openFileDialog.ShowDialog(this.ParentForm) == DialogResult.OK)
            {
                _pleaseWaitForm = new PleaseWaitForm();
                _pleaseWaitForm.LabelText = string.Format("Scanning all assembly references of '{0}' ... please wait.", Path.GetFileName(openFileDialog.FileName));
                _importReferencesBackgroundWorker.RunWorkerAsync(openFileDialog.FileName);
                _pleaseWaitForm.ShowDialog(this.ParentForm);
            }
        }

        PleaseWaitForm _pleaseWaitForm;

        private void _offToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetAllLevels(System.Diagnostics.TraceLevel.Off);
        }

        private void _errorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetAllLevels(System.Diagnostics.TraceLevel.Error);
        }

        private void _warningToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetAllLevels(System.Diagnostics.TraceLevel.Warning);
        }

        private void _infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetAllLevels(System.Diagnostics.TraceLevel.Info);
        }

        private void _verboseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetAllLevels(System.Diagnostics.TraceLevel.Verbose);
        }

        private void SetAllLevels(System.Diagnostics.TraceLevel traceLevel)
        {
            PropertyInfo[] propertyInfos = _propertyGrid.SelectedObject.GetType().GetProperties();

            foreach(PropertyInfo propertyInfo in propertyInfos)
            {
                if(propertyInfo.Name != "GlobalDefault")
                {

                    _propertyGrid.SelectedObject.GetType().InvokeMember(propertyInfo.Name, BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.Public, null, _propertyGrid.SelectedObject, new object[] { traceLevel });
                }
            }

            _propertyGrid.Refresh();

            FireDataChanged();
        }

        private void _importReferencesBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            string fileName = (string) e.Argument;

            ArrayList assemblyReferencesInfo = TimberlineAssemblyReferenceScanner.ScanInIsolatedAppDomain(fileName);

            ArrayList switchNamesToAdd = new ArrayList();
            foreach(AssemblyReferenceInfo assemblyReferenceInfo in assemblyReferencesInfo)
            {
                switchNamesToAdd.Add(assemblyReferenceInfo.AssemblyName.Name);
            }

            AddSwitches((string[]) switchNamesToAdd.ToArray(typeof(string)));
        }

        private void _importReferencesBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            _pleaseWaitForm.Dispose();
            _pleaseWaitForm = null;
        }

        private void _resetButton_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void TraceSwitchesControl_Load(object sender, EventArgs e)
        {
            AssemblyUtils.PostMessage(this.Handle, AssemblyUtils.WM_RESIZE_HELP_AREA, 0, 0);
        }

        protected override void WndProc(ref Message m)
        {
            if(m.Msg == AssemblyUtils.WM_RESIZE_HELP_AREA)
            {
                AssemblyUtils.ResizePropertyGridHelpArea(_propertyGrid, 0.80);
            }

            base.WndProc(ref m);
        }
    }
}
