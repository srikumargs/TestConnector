using System;
using System.IO;
using System.Globalization;

namespace Sage.Activation
{
	/// <summary>
	/// A helper class to facilitate building an application config string
	/// </summary>
	public static class ActivationConfigBuilder
	{
        /// <summary>
        /// Generate a component activation string for the givin component
        /// </summary>
        /// <param name="component">Reference to a component</param>
        /// <returns>A component activation string for the givin componen</returns>
        public static string ComponentXml( object component )
        {
            String result;

            if (component.GetType().Assembly.GlobalAssemblyCache)
            {
                result = string.Format(CultureInfo.InvariantCulture, "<Component ActivationType='DOT_NET' Assembly='{0}' Type='{1}' />", component.GetType().Assembly.GetName().FullName, component.GetType().FullName);
            }
            else
            {
                result = string.Format(CultureInfo.InvariantCulture, "<Component ActivationType='DOT_NET' Assembly='{0}' Type='{1}' Codebase='[{2}]' />", component.GetType().Assembly.GetName().Name, component.GetType().FullName, Path.GetDirectoryName(component.GetType().Assembly.Location));
            }

            return result;
        }
	}
}
