using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Reflection;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Configures custom debug tracing behavior.
    /// </summary>
    [TraceListenerIgnoreType]
    [ComVisible(false)]
    public static class TracingConfiguration
    {
        #region Public methods
        /// <summary>
        /// Creates (if necessary) and returns an AutoUpdatingTraceSwitch initialized with the specified name.
        /// </summary>
        /// <param name="traceSwitchName">The name of the desired trace switch.</param>
        /// <returns>the AutoUpdatingTraceSwitch</returns>
        public static AutoUpdatingTraceSwitch GetTraceSwitch(string traceSwitchName)
        {
            AutoUpdatingTraceSwitch result = GetTraceSwitchOverride(traceSwitchName);

#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            VerifyAuthorizedCaller();

            if(result == null)
            {
                lock(_traceSwitches.SyncRoot)
                {
                    if(!_traceSwitches.Contains(traceSwitchName))
                    {
                        result = new AutoUpdatingTraceSwitch(traceSwitchName, Strings.AssemblyTraceLevelSwitch);
                        _traceSwitches[traceSwitchName] = result;
                    }
                    else
                    {
                        result = (AutoUpdatingTraceSwitch) _traceSwitches[traceSwitchName];
                    }
                }
            }
#endif
            return result;
        }

        /// <summary>
        /// Overrides current tracing configuration (usually specified in app.config).
        /// </summary>
        /// <param name="traceSwitchName">The switch name to override (typically the assembly name)</param>
        /// <param name="traceLevel">The new value that the trace switch should be set to</param>
        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        public static void OverrideAssemblyLevelTraceSwitch(String traceSwitchName, TraceLevel traceLevel)
        {
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            VerifyAuthorizedCaller();

            lock(_traceSwitchOverrides.SyncRoot)
            {
                _traceSwitchOverrides[traceSwitchName] = new AutoUpdatingTraceSwitch(traceSwitchName, Strings.AssemblyTraceLevelSwitch, traceLevel);
            }
#endif
        }

        /// <summary>
        /// Removes previous override of current tracing configuration.
        /// </summary>
        /// <param name="traceSwitchName">The switch name to override (typically the assembly name)</param>
        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        public static void ClearAssemblyLevelTraceSwitchOverride(String traceSwitchName)
        {
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            VerifyAuthorizedCaller();

            lock(_traceSwitchOverrides.SyncRoot)
            {
                if(_traceSwitchOverrides.Contains(traceSwitchName))
                {
                    _traceSwitchOverrides.Remove(traceSwitchName);
                }
            }
#endif
        }

        /// <summary>
        /// Programmatically enable/disable trace logging to a text file
        /// </summary>
        /// <param name="enable">Whether to turn text file logging on or off</param>
        /// <param name="logFilePath">The name of the file that should be written to</param>
        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        public static void EnableTraceLogging(Boolean enable, String logFilePath)
        {
            VerifyAuthorizedCaller();

            TraceUtils.EnableTraceLogging(enable, logFilePath);
        }
        #endregion

        #region Private methods
        private static AutoUpdatingTraceSwitch GetTraceSwitchOverride(string traceSwitchName)
        {
            AutoUpdatingTraceSwitch result = null;

#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            lock(_traceSwitchOverrides.SyncRoot)
            {
                if(_traceSwitchOverrides.Contains(traceSwitchName))
                {
                    result = (AutoUpdatingTraceSwitch) _traceSwitchOverrides[traceSwitchName];
                }
            }
#endif
            return result;
        }

        [Conditional("TRACE")] // clients shouldn't bother including a call to this function if they don't have TRACE defined
        private static void VerifyAuthorizedCaller()
        {
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
            try
            {
                // As a security measure, we only are going to write trace output if the Sage.CRE.Core.TraceListeners
                // assembly exists, has the same version as our version, and has the same public key as our
                // public key.

                System.Reflection.Assembly callingAssembly = Assembly.GetCallingAssembly();

                Byte[] callingAssemblyPublicKeyToken = callingAssembly.GetName().GetPublicKeyToken();
                Byte[] myAssemblyPublicKeyToken = Assembly.GetExecutingAssembly().GetName().GetPublicKeyToken();

                if(Convert.ToBase64String(callingAssemblyPublicKeyToken, 0, callingAssemblyPublicKeyToken.Length) != Convert.ToBase64String(myAssemblyPublicKeyToken, 0, myAssemblyPublicKeyToken.Length))
                {
                    throw new InvalidOperationException(Strings.CallerNotAuthorized);
                }
            }
            catch(Exception ex)
            {
                throw new InvalidOperationException(Strings.CallerNotAuthorized, ex);
            }
#endif
        }
        #endregion

        #region Private fields
#if(TRACE) // we don't need to bother including the code for the implementation of this method if we don't have TRACE defined
        private static Hashtable _traceSwitches = new Hashtable(StringComparer.InvariantCultureIgnoreCase);
        private static Hashtable _traceSwitchOverrides = new Hashtable(StringComparer.InvariantCultureIgnoreCase);
#endif
        #endregion
    }
}
