using System;
using System.Runtime.InteropServices;
using Sage.Configuration;
using System.Xml;
using System.IO;

namespace Sage.Remoting
{
	
    /// <summary>
    /// Use to read remote or local url values
    /// </summary>
    public class DataStoreUrlWriter : DataStoreUrlReaderWriterBase, IUrlWriter
    {
        /// <summary>
        /// Use the null factory
        /// </summary>
        public DataStoreUrlWriter() : base() {}

        /// <summary>
        /// Set the factory in the ctor
        /// </summary>
        /// <param name="formatter"></param>
        public DataStoreUrlWriter(IFormatter formatter) : base(formatter) {}

        /// <summary>
        /// Path to the URL file
        /// </summary>
        private string UrlFilePath
        {
            get 
            {
                return Path.Combine(
                    LibraryManager.SharedConfigLocation,
                    "Remoting\\URLs.xds" );
            }
        }

    
        #region Implementation of IUrlWriter
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inUri"></param>
        /// <param name="urlValue"></param>
        public void SaveUrl(string inUri, string urlValue)
        {
            string uri = inUri;
            if (this.Formatter != null)
            {
                uri = this.Formatter.Format(inUri);
            }

            try
            {
                Sage.Configuration.DataRegistry.CreateKeyedValueSet( DataScope.AllUsers, DataStoreApplication, DataStoreTable ).SetValue( DataStorePath, uri, urlValue);
            }
            catch ( XmlException )
            {
                // This is a fix for the Tracker: 512777 Desktop:  Message Host failed to load error message when opening Desktop  
                //
                // This file is becoming corrupted.  We walked through the DataRegistry and can't determine what is causing this issue. 
                // Since we could not fix the real problem we put this fix in to prevent the client from having to deal with this.

                if ( File.Exists( UrlFilePath ) )
                {
                    File.Delete( UrlFilePath );
                }
                DataRegistry.CreateKeyedValueSet( DataScope.AllUsers, DataStoreApplication, DataStoreTable ).SetValue( DataStorePath, uri, urlValue);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inUri"></param>
        public void RemoveUrl(string inUri)
        {
            string uri = inUri;
            if (this.Formatter != null)
            {
                uri = this.Formatter.Format(inUri);
            }

            DataRegistry.CreateKeyedValueSet( DataScope.AllUsers, DataStoreApplication, DataStoreTable ).RemoveKey( DataStorePath, uri );
        }
        #endregion // IUrlWriter
    }
}
