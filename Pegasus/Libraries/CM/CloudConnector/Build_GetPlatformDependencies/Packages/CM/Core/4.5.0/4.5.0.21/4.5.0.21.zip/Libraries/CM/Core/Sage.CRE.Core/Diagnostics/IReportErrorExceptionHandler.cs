using System;
using System.Collections.Generic;
using System.Text;

namespace Sage.Diagnostics
{
    /// <summary>
    /// This class contains error strings. The strings in this class can be used in error messages or logs.
    /// </summary>
    public class ExceptionErrorInfo
    {
        #region private fields
        String _errorCaption;
        String _errorSummary;
        String _errorDetails;
        String _errorFootnote;
        #endregion
        
        /// <summary>
        /// Constructor
        /// </summary>
        public ExceptionErrorInfo()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="errorCaption">Error caption</param>
        public ExceptionErrorInfo(String errorCaption)
        {
            _errorCaption = errorCaption;
        }

        /// <summary>
        /// Get/Set the caption for the error
        /// </summary>
        public String ErrorCaption
        {
            get
            {
                return _errorCaption;
            }
            set
            {
                _errorCaption = value;
            }
        }

        /// <summary>
        /// Get/Set the error summary phrase
        /// </summary>
        public String ErrorSummary
        {
            get
            {
                return _errorSummary;
            }
            set
            {
                _errorSummary = value;
            }
        }

        /// <summary>
        /// Get/Set the error details
        /// </summary>
        public String ErrorDetails
        {
            get
            {
                return _errorDetails;
            }
            set
            {
                _errorDetails = value;
            }
        }

        /// <summary>
        /// Get/Set any additional information about the error
        /// </summary>
        public String ErrorFootnote
        {
            get
            {
                return _errorFootnote;
            }
            set
            {
                _errorFootnote = value;
            }
        }
    }

    /// <summary>
    /// The signature of the callback provided by UI clients.  This callback is used to report expected errors to end-users.
    /// </summary>
    /// <param name="errorInfo">An object with the information needed to display the error to the end-user.</param>
    public delegate void ReportError(ExceptionErrorInfo errorInfo);

    /// <summary>
    /// IReportErrorExceptionHandler is implemented by exception handlers designed to report errors to the end-user.
    /// </summary>
    /// <remarks>
    /// To create a report error exception handler do the following:
    /// 1) Implement a class derived from ReportErrorExceptionHandler,
    /// 2) Create a default construction, in the constructor call AddHandledException for each exception type your
    /// handler, handles.  For exceptions that should be reported to the end user, set the action equal to Delegate
    /// and pass ReportException as the CustomHandler
    /// 3) Override TranslateExceptionToErrorInfo. In this method, populate the passed in ErrorInfo object
    /// with user consumable strings.
    /// 4) If you want your exception handler to handle some instances of a particular type of exception (e.g.,
    /// SqlExceptions with error codes equal to 1, 2, and 4) override CanHandleException and return true when
    /// you encounter an exception you want to handle.  If you want the exception reported to the end user set
    /// Action equal to Delegate and set CustomHandler equal to ReportException.
    /// 
    /// Note: If the report exception handler, is a data access exception handler designed to handle exceptions throw
    /// by a particular data provider, add an &lt;ExceptionHandler&gt; element to the &lt;Provider&gt; element in the appropriate
    /// provider xml files.  This will enable the DataAccessor to get the exception handler and add it to exception's
    /// Data collection when exceptions occur.
    /// </remarks>
    public interface IReportErrorExceptionHandler
    {
        /// <summary>
        /// This method evaluates the provided exception.  If the exception is expected (i.e., the handler
        /// knows how to handle it, it will handle the exception.
        /// </summary>
        /// <remarks>Handling an exception typically involves using the ReportErrorHandler to report the error
        /// to clients, and logging or tracing the error for diagnostic purposes.</remarks>
        /// <param name="e">The exception to handle</param>
        /// <param name="errorCaption">Provide a caption for the error. Used in the error message's title bar.</param>
        /// <param name="displayError">The custom handler report expected errors to end-users</param>
        /// <returns>True if the exception was handled.</returns>
        bool HandleException(Exception e, String errorCaption, ReportError displayError);
    }
}
