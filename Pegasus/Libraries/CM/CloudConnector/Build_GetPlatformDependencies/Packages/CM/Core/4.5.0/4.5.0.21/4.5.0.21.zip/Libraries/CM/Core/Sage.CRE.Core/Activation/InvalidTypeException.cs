using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using System.Runtime.InteropServices;

using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Exception class thrown when one are more invalid license strings are encountered
    /// </summary>
    [ComVisible(false)]
    [Serializable]
    public sealed class InvalidTypeException : LoggingBaseException
    {

        /// <summary>
        /// Serialization Constructor
        /// </summary>
        /// <param name="si">Serialization Info</param>
        /// <param name="sc">Streaming Context</param>
        private InvalidTypeException(SerializationInfo si, StreamingContext sc)
            : base(si, sc)
        {
        }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public InvalidTypeException()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="errorMessage">Error Message</param>
        public InvalidTypeException(string errorMessage)
            : base(StringTable.TYPE_FACTORY_COMPONENT, errorMessage)
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="errorMessage">ErrorMessage</param>
        /// <param name="innerException">An inner exception</param>
        public InvalidTypeException(string errorMessage, Exception innerException)
            : base(StringTable.TYPE_FACTORY_COMPONENT, errorMessage, innerException)
        {

        }
    }
}
