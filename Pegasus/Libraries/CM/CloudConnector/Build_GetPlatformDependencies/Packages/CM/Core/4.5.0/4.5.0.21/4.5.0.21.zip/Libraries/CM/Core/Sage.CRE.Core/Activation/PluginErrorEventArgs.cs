using System;
using System.Runtime.InteropServices;

namespace Sage.Activation
{
	/// <summary>
	/// Event arguments for plugin loading error events
	/// </summary>
	/// 
    [ComVisible(false)]
	public class PluginErrorEventArgs
	{
        // The exception generated while trying to load a plugin
        Exception _exceptionThrown; //= null; (automatically initialized by runtime)

        // Additional data about the plugin that failed to load
        string _additionalData; //= null; (automatically initialized by runtime)

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="exceptionThrown">The exception generated while trying to load a plugin</param>
        /// <param name="additionalData">Additional data about the plugin that failed to load</param>
        public PluginErrorEventArgs( Exception exceptionThrown, string additionalData )
        {
            _exceptionThrown = exceptionThrown;
            _additionalData = additionalData;
        }

        /// <summary>
        /// Retrieve the exception generated while trying to load a plugin
        /// </summary>
        public Exception ExceptionThrown
        {
            get{ return _exceptionThrown; }
        }

        /// <summary>
        /// Retrieve additional data about the plugin that failed to load
        /// </summary>
        public string AdditionalData
        {
            get{ return _additionalData; }
        }
	}

    /// <summary>
    /// Event handler for plugin error events
    /// </summary>
    [ComVisible(false)]
    public delegate void PluginErrorEventHandler( object sender, PluginErrorEventArgs args );
}
