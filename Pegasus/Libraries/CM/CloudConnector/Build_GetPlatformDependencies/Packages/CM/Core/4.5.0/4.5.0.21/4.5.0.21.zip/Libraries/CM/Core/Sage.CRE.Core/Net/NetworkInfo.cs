using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Sage.Net
{
    /// <summary>
    /// Summary description for NetworkInfo.
    /// </summary>
    public class NetworkInfo
      : INetworkInfo
    {
        /// <summary>
        /// ctor
        /// </summary>
        public NetworkInfo()
        {
        }

        private ServerCollection m_Servers;
        private DomainCollection m_Domains;
        private GroupCollection m_Groups;
        private UserCollection m_Users;

        private ServerValidation m_ServerValidation = null;


        /// <summary>
        /// Accessor to the Servers collection
        /// </summary>
        public IServerCollection Servers
        {
            get
            {
                _CreateServerCollection();
                return (IServerCollection)m_Servers;
            }
        }

        /// <summary>
        /// Accessor to the Domains collection
        /// </summary>
        public IDomainCollection Domains
        {
            get
            {
                _CreateDomainCollection();
                return (IDomainCollection)m_Domains;
            }
        }

        /// <summary>
        /// Accessor to the groups collection
        /// </summary>
        public IGroupCollection Groups
        {
            get
            {
                _CreateGroupCollection();
                return (IGroupCollection)m_Groups;
            }
        }

        /// <summary>
        /// Accessor to the Users collection
        /// </summary>
        public IUserCollection Users
        {
            get
            {
                _CreateUserCollection();
                return (IUserCollection)m_Users;
            }
        }

        /// <summary>
        /// Accessor to the ServerValidation
        /// </summary>
        public IServerValidation ServerValidation
        {
            get
            {
                _CreateServerValidation();
                return m_ServerValidation;
            }
        }

        void _CreateServerValidation()
        {
            if (m_ServerValidation == null)
            {
                m_ServerValidation = new ServerValidation();
            }
        }

        private void _CreateServerCollection()
        {
            if (m_Servers == null)
            {
                m_Servers = new ServerCollection();
            }
        }

        private void _CreateUserCollection()
        {
            if (m_Users == null)
            {
                m_Users = new UserCollection();
            }
        }

        private void _CreateDomainCollection()
        {
            if (m_Domains == null)
            {
                m_Domains = new DomainCollection();
            }
        }

        private void _CreateGroupCollection()
        {
            if (m_Groups == null)
            {
                m_Groups = new GroupCollection();
            }
        }

    }
}
