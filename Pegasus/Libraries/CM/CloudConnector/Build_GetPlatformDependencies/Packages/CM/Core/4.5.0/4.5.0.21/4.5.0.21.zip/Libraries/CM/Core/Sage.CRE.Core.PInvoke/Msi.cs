﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace Sage.PInvoke
{
    /// <summary>
    /// This class encapsulates calls to unmanaged code in msi.dll
    /// </summary>
    public static class Msi
    {
        public const String INSTALLPROPERTY_INSTALLEDPRODUCTNAME = "InstalledProductName";
        public const String INSTALLPROPERTY_VERSIONSTRING = "VersionString";
        public const String INSTALLPROPERTY_PRODUCTID = "ProductID";

        public const UInt32 ERROR_MORE_DATA = 234U;          // More data is available.

        public enum INSTALLSTATE
        {
            INSTALLSTATE_NOTUSED = -7,  // component disabled
            INSTALLSTATE_BADCONFIG = -6,  // configuration data corrupt
            INSTALLSTATE_INCOMPLETE = -5,  // installation suspended or in progress
            INSTALLSTATE_SOURCEABSENT = -4,  // run from source, source is unavailable
            INSTALLSTATE_MOREDATA = -3,  // return buffer overflow
            INSTALLSTATE_INVALIDARG = -2,  // invalid function argument
            INSTALLSTATE_UNKNOWN = -1,  // unrecognized product or feature
            INSTALLSTATE_BROKEN = 0,  // broken
            INSTALLSTATE_ADVERTISED = 1,  // advertised feature
            INSTALLSTATE_REMOVED = 1,  // component being removed (action state, not settable)
            INSTALLSTATE_ABSENT = 2,  // uninstalled (or action state absent but clients remain)
            INSTALLSTATE_LOCAL = 3,  // installed on local drive
            INSTALLSTATE_SOURCE = 4,  // run from source, CD or net
            INSTALLSTATE_DEFAULT = 5,  // use default, local or source
        }

        public static INSTALLSTATE MsiQueryProductState(String productCode)
        {
            return NativeMethods.MsiQueryProductState(productCode);
        }

        public static Int32 MsiGetProductInfo(String productCode, String propertyName, [Out] System.Text.StringBuilder valueBuffer, [MarshalAs(UnmanagedType.U4)] ref Int32 bufferLength)
        {
            return NativeMethods.MsiGetProductInfo(productCode, propertyName, valueBuffer, ref bufferLength);
        }

    }
}
