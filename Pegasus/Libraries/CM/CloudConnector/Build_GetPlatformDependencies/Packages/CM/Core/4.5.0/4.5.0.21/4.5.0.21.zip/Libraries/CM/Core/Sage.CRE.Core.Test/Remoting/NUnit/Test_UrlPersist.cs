#if DEBUG
using System;
using System.Runtime.InteropServices;
using NUnit.Framework;

using Sage.Remoting;

namespace Sage.Remoting.NUnit
{
    /// <summary>
    /// Test the registry persistence of urls
    /// </summary>
    [ComVisible(false)]
    [TestFixture]
    public class Test_RegistryUrlPersist
    {
//        /// <summary>
//        /// yeah, a test.
//        /// </summary>
//        [Test]
//        public void RegUrlReadWriteTest()
//        {
//            string key = "ChadTheRat";
//            string val = "Here is a pointer to some cheese, ratboy";
//            IUrlPersist p = new RegistryProcIdUrlPersist();
//            p.UrlWriter.SaveUrl(key, val);
//            Assertion.AssertEquals(p.UrlReader.GetUrl(key), val);
//            p.UrlWriter.RemoveUrl(key);
//        }
    }
}

#endif // DEBUG