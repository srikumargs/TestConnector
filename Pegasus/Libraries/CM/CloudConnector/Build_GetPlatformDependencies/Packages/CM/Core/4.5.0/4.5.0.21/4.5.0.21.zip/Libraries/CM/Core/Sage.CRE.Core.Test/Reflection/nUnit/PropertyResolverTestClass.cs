#if DEBUG
using System;

namespace Sage.Reflection.nUnit
{
	/// <summary>
	/// Class used by tests for the PropertyResolver
	/// </summary>
	internal class PropertyResolverTestClass
	{
        // A numberic field
        private int _numberVal = 7;

        // A string field
        private string _stringVal = "TheJoker";

        /// <summary>
        /// Constructor
        /// </summary>
		public PropertyResolverTestClass()
		{
			
		}

        /// <summary>
        /// Public NumberVal property
        /// </summary>
        public int NumberVal
        {
            get{ return _numberVal; }
            set{ _numberVal = value; }
        }

        /// <summary>
        /// Public string value
        /// </summary>
        public string StringVal
        {
            get{ return _stringVal; }
            set{ _stringVal = value; }
        }

        /// <summary>
        /// Private NumberVal property
        /// </summary>
        private int PrivateNumberVal
        {
            get{ return _numberVal; }
            set{ _numberVal = value; }
        }

        /// <summary>
        /// Private string value
        /// </summary>
        private string PrivateStringVal
        {
            get{ return _stringVal; }
            set{ _stringVal = value; }
        }
	}
}

#endif // DEBUG