﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sage.CRE.Core.SQL
{
    /// <summary>
    /// A class which displays a progess bar that needs to be updated while the database is being created
    /// should implement this interface. After each script is processed PerformStep will be called.
    /// </summary>
    public interface IExecuteScriptProgress
    {
        /// <summary>
        /// Call this method once a 'step' in the process has been completed.
        /// </summary>
        void PerformStep();
    }
}
