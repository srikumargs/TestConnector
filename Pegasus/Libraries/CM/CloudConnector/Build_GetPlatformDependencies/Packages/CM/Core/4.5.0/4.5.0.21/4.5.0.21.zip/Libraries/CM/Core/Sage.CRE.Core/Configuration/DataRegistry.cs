using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Runtime.InteropServices;
using System.Text;
#if !CORE_INSTALL
using Sage.Diagnostics;
#endif
using Sage.Configuration.Internal;

namespace Sage.Configuration
{
	/// <summary>
	/// A class used to locate, create and manage data repositories
	/// </summary>
    [ComVisible(false)]
    public class DataRegistry : IDataRegistry
    {
        #region Constants
        
        // Default xml data to write to a file
        private const string DefaultFileData = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Root></Root>";

        /// <summary>
        /// Standard Xml Data Store file extension
        /// </summary>
        public const string FileExtension = @".xds";

        /// <summary>
        /// Encrypted Xml Data Store file extension
        /// </summary>
        public const string EncryptedFileExtension = @".exds";

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        public DataRegistry()
        {
			
        }

        #region IDataRegistry

        /// <summary>
        /// Create or open a keyed value set
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>Interface to the keyed value set</returns>
        /// <remarks>If the keyed value set already exists this method will simply return an interface to it. If it does not exist it will create it</remarks>
        IKeyedValues IDataRegistry.CreateKeyedValueSet( DataScope scope, string location, string name )
        {
            return DataRegistry.CreateKeyedValueSet(scope, location, name );
        }

        /// <summary>
        /// Create a open an encrypted keyed value set 
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>Interface to the keyed value set</returns>
        /// <remarks>If the keyed value set already exists this method will simply return an interface to it. If it does not exist it will create it</remarks>
        IKeyedValues IDataRegistry.CreateEncryptedKeyedValueSet( DataScope scope, string location, string name )
        {
            return DataRegistry.CreateEncryptedKeyedValueSet( scope, location, name );
        }

        /// <summary>
        /// Open an existing keyed value set
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>Interface to the keyed value set</returns>
        /// <remarks>An error is throw if you attemtp to open a keyed value set that doesn't exist</remarks>
        IKeyedValues IDataRegistry.OpenKeyedValueSet( DataScope scope, string location, string name )
        {
            return DataRegistry.OpenKeyedValueSet( scope, location, name );
        }

        /// <summary>
        /// Remove a keyed value set 
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        void IDataRegistry.RemoveKeyedValueSet( DataScope scope, string location, string name )
        { 
            DataRegistry.RemoveKeyedValueSet( scope, location, name );
        }

        /// <summary>
        /// Determine if the data registry contains a particular keyed value set.
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>True if the keyed value set exists, false if not</returns>
        bool IDataRegistry.ContainsKeyedValueSet( DataScope scope, string location, string name )
        { 
            return DataRegistry.ContainsKeyedValueSet( scope, location, name );
        }

        /// <summary>
        /// Remove all data sets from a particular location within the data registry
        /// </summary>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        void IDataRegistry.RemoveAllData( string location )
        {
            DataRegistry.RemoveAllData( location );            
        }

        #endregion

        /// <summary>
        /// Create or open a keyed value set
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>Interface to the keyed value set</returns>
        /// <remarks>If the keyed value set already exists this method will simply return an interface to it. If it does not exist it will create it</remarks>
        public static IKeyedValues CreateKeyedValueSet( DataScope scope, string location, string name )
        {
            InsureLocationFolderExists( scope, location );
            string path = string.Format( "{0}\\{1}{2}", GetDataPath( scope, location ), name, FileExtension );
            if( !KeyedValueSetExists( scope, path ) )
            {
                CreateKeyedValueSet( scope, path );   
            }
            return new KeyedValueSet( path, scope );
        }

        /// <summary>
        /// Create a open an encrypted keyed value set 
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>Interface to the keyed value set</returns>
        /// <remarks>If the keyed value set already exists this method will simply return an interface to it. If it does not exist it will create it</remarks>
        public static IKeyedValues CreateEncryptedKeyedValueSet( DataScope scope, string location, string name )
        {
            InsureLocationFolderExists( scope, location );
            string path = string.Format( "{0}\\{1}{2}", GetDataPath( scope, location ), name, EncryptedFileExtension );
            if( !KeyedValueSetExists( scope, path ) )
            {
                 CreateKeyedValueSet( scope, path );  
            }
            return new KeyedValueSet( path, scope );
        }

        /// <summary>
        /// Open an existing keyed value set
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>Interface to the keyed value set</returns>
        /// <remarks>An error is throw if you attemtp to open a keyed value set that doesn't exist</remarks>
        public static IKeyedValues OpenKeyedValueSet( DataScope scope, string location, string name )
        {
            string path = string.Format( "{0}\\{1}{2}", GetDataPath( scope, location ), name, FileExtension );
            if( !KeyedValueSetExists( scope, path ) )
            {
                path = string.Format( "{0}\\{1}{2}", GetDataPath( scope, location ), name, EncryptedFileExtension );  
                if( !KeyedValueSetExists( scope, path ) )
                {
                    return null;                    
                }
            }
            return new KeyedValueSet( path, scope );
        }

        /// <summary>
        /// Remove a keyed value set 
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        public static void RemoveKeyedValueSet( DataScope scope, string location, string name )
        { 
            string path = string.Format( "{0}\\{1}{2}", GetDataPath( scope, location ), name, FileExtension );
            if( !KeyedValueSetExists( scope, path ) )
            {
                path = string.Format( "{0}\\{1}{2}", GetDataPath( scope, location ), name, EncryptedFileExtension );
            }
            if( KeyedValueSetExists( scope, path ) )
            {
                RemoveKeyedValueSet( scope, path );
            }
        }

        /// <summary>
        /// Determine if the data registry contains a particular keyed value set.
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <param name="name">The name of the keyed value set</param>
        /// <returns>True if the keyed value set exists, false if not</returns>
        public static bool ContainsKeyedValueSet( DataScope scope, string location, string name )
        { 
            bool retval = false;
            string path = string.Format( "{0}\\{1}{2}", GetDataPath( scope, location ), name, FileExtension );
            if( !KeyedValueSetExists( scope, path ) )
            {
                path = string.Format( "{0}\\{1}{2}", GetDataPath( scope, location ), name, EncryptedFileExtension );
            }
            if( KeyedValueSetExists( scope, path ) )
            {
                retval = true;
            }
            return retval;
        }

        /// <summary>
        /// Remove all data sets from a particular location within the data registry
        /// </summary>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        public static void RemoveAllData( string location )
        {
            RemoveFolderAndFiles( DataScope.AllUsers, GetDataPath( DataScope.AllUsers, location ) );
            RemoveFolderAndFiles( DataScope.CurrentUser, GetDataPath( DataScope.CurrentUser, location ) );
            RemoveFolderAndFiles( DataScope.RoamingUser, GetDataPath( DataScope.RoamingUser, location ) );
        }

        /// <summary>
        /// Remove a folder and all it's files
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="path">The path to the folder to remove</param>
        private static void RemoveFolderAndFiles( DataScope scope, string path )
        {
            if( scope == DataScope.AllUsers || scope == DataScope.FileSystem )
            {
                DirectoryInfo directory = new DirectoryInfo(path);
                if( directory.Exists )
                {
                    directory.Delete(true);
                }
            }
            else
            {
                IsolatedStorageFile iso = GetStorageFile( scope );
                if( iso.GetDirectoryNames( path ).Length == 1 )
                {
                    foreach( string file in iso.GetFileNames( string.Format( "{0}\\*", path ) ) )
                    {
                        iso.DeleteFile( string.Format( "{0}\\{1}", path, file ) );
                    }
                    iso.DeleteDirectory( path );
                }
                iso.Close();
            }
        }

        /// <summary>
        /// Make sure the root location folder exists
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        private static void InsureLocationFolderExists( DataScope scope, string location )
        {
            string path = GetDataPath( scope, location );
            if( scope == DataScope.AllUsers || scope == DataScope.FileSystem )
            {
                InsureFileFoldersExist( path );
            }
            else
            {
                InsureIsolatedStorageDirectoriesExist( scope, path );
            }
        }

        /// <summary>
        /// Retrieve a formated data path to the root location folder
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="location">The location of the keyed value set within the data registry</param>
        /// <returns>A formated data path to the root location folder</returns>
        private static string GetDataPath( DataScope scope, string location )
        {
            string retval = null;
            if( scope == DataScope.AllUsers )
            {
#if !CORE_INSTALL
                retval = string.Format( "{0}\\{1}", LibraryManager.SharedConfigLocation, location );
#else
                retval = Path.Combine(Path.Combine(System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Sage"), location);
#endif
            }
            else
            {
                retval =  location;
            }
           return retval;
        
        }

        /// <summary>
        /// Make sure the directory structure exists
        /// </summary>
        /// <param name="path">The path to validate</param>
        private static void InsureFileFoldersExist( string path )
        {
            if( !Directory.Exists( path ) )
            {
                Directory.CreateDirectory( path );
            }
        }

        /// <summary>
        /// Make sure an isolated storage path exists
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="path">The path validate</param>
        private static void InsureIsolatedStorageDirectoriesExist( DataScope scope, string path )
        {
            IsolatedStorageFile iso = GetStorageFile( scope );
            iso.CreateDirectory( path );
            iso.Close();
        }

        /// <summary>
        /// Retrieve the default content for a new file
        /// </summary>
        /// <returns>The file bytes containing the default content</returns>
        private static byte[] GetDefaultFileBytes()
        {
            byte [] bytes = new Byte[ DefaultFileData.Length ];
            int size = Encoding.ASCII.GetBytes( DefaultFileData.ToCharArray(), 0, DefaultFileData.Length, bytes, 0);
            return bytes;
        }

        /// <summary>
        /// Retrieve the encrypted default content for a new file
        /// </summary>
        /// <returns>The encrypted file bytes containing the default content</returns>
        private static byte[] GetEncryptedDefaultFileBytes()
        {
            return CryptoHelper.TransformBytes( GetDefaultFileBytes(), CryptoHelper.EncryptionAction.Encrypt );
        }

        /// <summary>
        /// Retrieve an isolated storage file object
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <returns>an isolated storage file object</returns>
        internal static IsolatedStorageFile GetStorageFile( DataScope scope )
        {
            IsolatedStorageScope storageScope = IsolatedStorageScope.User | IsolatedStorageScope.Assembly;
            if( scope == DataScope.RoamingUser )
            {
                storageScope = storageScope | IsolatedStorageScope.Roaming;
            }
            return IsolatedStorageFile.GetStore( storageScope, null, null);
        }

        /// <summary>
        /// Determine if a keyed value set exists
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="path">The path of the data table</param>
        /// <returns>True if the keyed value set already exists, false if not</returns>
        private static bool KeyedValueSetExists( DataScope scope, string path )
        {
            bool retval = false;
            if( scope == DataScope.AllUsers || scope == DataScope.FileSystem )
            {
                retval = File.Exists( path );
            }
            else
            {
                IsolatedStorageFile iso = GetStorageFile( scope );
                retval = iso.GetFileNames( path ).Length == 1;
                iso.Close();
            }
            return retval;
        }

        /// <summary>
        /// Create a new keyed value set
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="path">The path of the file to create</param>
        private static void CreateKeyedValueSet( DataScope scope, string path )
        {
            bool encrypt = Path.GetExtension( path ) == EncryptedFileExtension;
            Stream stream = GetPersistenceStream( scope, path );
            BinaryWriter writer = new BinaryWriter(stream);
            byte[] defaultFileBytes = (encrypt)? GetEncryptedDefaultFileBytes() : GetDefaultFileBytes();
            writer.Write( defaultFileBytes, 0, defaultFileBytes.Length );
            writer.Close();
            stream.Close();
        }

        /// <summary>
        /// Delete a keyed value set's file
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="path">the path of the data table file</param>
        private static void RemoveKeyedValueSet( DataScope scope, string path )
        {
            if( scope == DataScope.AllUsers || scope == DataScope.FileSystem )
            {
                File.Delete( path );
            }
            else
            {
                IsolatedStorageFile iso = GetStorageFile( scope );
                iso.DeleteFile( path );
                iso.Close();
            }
        
        }

        /// <summary>
        /// Get the persistence stream to write the keyed value set to
        /// </summary>
        /// <param name="scope">The scope of the keyed value set</param>
        /// <param name="path">A path to a file</param>
        /// <returns>A persistence stream to write the data table to </returns>
        internal static Stream GetPersistenceStream( DataScope scope, string path )
        {
            Stream retval = null;
            if( scope == DataScope.AllUsers || scope == DataScope.FileSystem )
            {
                int attempts = 0;
                while( attempts < 60 && ( retval == null ) )
                {
                    attempts++;
                    try
                    {
                        retval = new FileStream( path, FileMode.OpenOrCreate, FileAccess.ReadWrite ); 
                    }
                    catch( Exception error )
                    {
                        if( attempts == 60 )
                        {
#if !CORE_INSTALL
                            EventLogger.WriteMessage( "DataRegistry", error.Message, MessageType.Error ); 
#endif
                            throw error;
                        }
                        System.Threading.Thread.Sleep( 50 );
                    }
                }
            }
            else
            {
                retval = new IsolatedStorageFileStream( path, FileMode.OpenOrCreate, GetStorageFile(scope));
            }
            return retval;
        }
    }
}
