﻿using System;

namespace Sage.CRE.Core.SQL
{
    /// <summary>Deletes a database using the reverible action pattern.
    /// The construction of a DeleteDatabase object will rename the database specified.
    /// If the object is disposed without calling the Commit() method, then the database will have it's orginal name.
    /// </summary>
    public class DeleteDatabase : Sage.IO.ReversibleAction.ReversibleActionBase
    {
        #region Private members
        private SqlConnectionContext _context = new SqlConnectionContext();
        private string _proposedName;
        private bool _DatabaseRenamed = false;
        private RenameDatabase _renamer;
        #endregion

        /// <summary>Deletes a database using the reverible action pattern.
        /// The construction of a DeleteDatabase object will create the database specified.
        /// If the object is disposed without calling the Commit() method, then the newly created database will be deleted.
        /// </summary>
        /// <param name="context">The database context</param>
        public DeleteDatabase(SqlConnectionContext context)
        {
            _context = context;
            
            _proposedName = String.Format(@"{0}-{1}", context.InitialCatalog, System.Guid.NewGuid().ToString());

            _renamer = new RenameDatabase(_context, _proposedName);
        }

        /// <summary>Creates the database.
        /// </summary>
        public override void Forward()
        {
            base.Forward();

            _renamer.Forward();
            _DatabaseRenamed = true;

            System.Data.SqlClient.SqlConnection.ClearAllPools();
        }

        /// <summary>Drops the newly created database
        /// </summary>
        public override void Reverse()
        {
            if (_DatabaseRenamed)
            {
                _renamer.Reverse();
            }

            System.Data.SqlClient.SqlConnection.ClearAllPools();

            base.Reverse();
        }

        /// <summary>
        /// Completes the deletion on the database.
        /// </summary>
        public override void Commit()
        {
            _renamer.Commit();
            SqlConnectionContext newContext = (SqlConnectionContext)_context.Clone();
            newContext.InitialCatalog = _proposedName;
            if (SqlCommands.DatabaseExists(newContext))
            {
                SqlCommands.DropDatabase(newContext, true);
            }
            base.Commit();
            System.Data.SqlClient.SqlConnection.ClearAllPools();
        }

    }
}
