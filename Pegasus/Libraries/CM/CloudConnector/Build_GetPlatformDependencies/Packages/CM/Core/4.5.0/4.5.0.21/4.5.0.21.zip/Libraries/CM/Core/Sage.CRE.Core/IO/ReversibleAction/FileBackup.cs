using System;
using System.Collections.Generic;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Backs up one or more files using the ReversibleAction pattern.
    /// The construction of a FileBackup object backups the specified files.
    /// If the object is disposed without calling the Commit() method, then the original files are restored.
    /// 
    /// Typical usage:
    /// 
    /// using (FileBackup fileBackup = new FileBackup(@"C:\srcFile.txt"))
    /// {
    ///     fileBackup.Forward();
    ///     
    ///     // execute some code that might throw. If the code throws, we need to restore the original file
    /// 
    ///     fileBackup.Commit();
    /// }
    /// </summary>
    public class FileBackup : ReversibleActionBase
    {

        /// <summary>
        /// Backs up a file.
        /// </summary>
        /// <param name="fileName">The file to backup.</param>
        public FileBackup(string fileName)
        {
            string dest = System.IO.Path.Combine(System.IO.Path.GetTempPath(), String.Format(System.Globalization.CultureInfo.InvariantCulture, StringsNoTran.ReversibleFileSystemAction_TempObjectCatenationFormat_Internal, fileName, _actionID));
            _filesToBackup.Add(fileName, dest);
        }

        /// <summary>
        /// Backs up a set of files.
        /// </summary>
        /// <param name="fileNames">A list of files to backup.</param>
        public FileBackup(System.Collections.ObjectModel.ReadOnlyCollection<string> fileNames)
        {
            foreach (string fileName in fileNames)
            {
                string dest = System.IO.Path.Combine(System.IO.Path.GetTempPath(), String.Format(System.Globalization.CultureInfo.InvariantCulture,StringsNoTran.ReversibleFileSystemAction_TempObjectCatenationFormat_Internal, fileName, _actionID));
                _filesToBackup.Add(fileName, dest);
            }

        }

        #region Protected methods
        /// <summary>
        /// Backs up the previously specified files.
        /// </summary>
        public override void Forward()
        {
            base.Forward();
            _filesBackedup.Clear();
            using (FileCopy fileCopy = new FileCopy(_filesToBackup))
            {
                fileCopy.Forward();
                fileCopy.Commit();
            }
            _filesBackedup = _filesToBackup;
        }

        /// <summary>
        /// Removes the backup files.
        /// </summary>
        public override void Commit()
        {
            base.Commit();
            foreach (KeyValuePair<string, string> kvp in _filesBackedup)
            {
                string dest = kvp.Value;
                if (System.IO.File.Exists(dest)) System.IO.File.Delete(dest);
            }
        }

        /// <summary>
        /// Restores the original state of the files that were backed up.
        /// </summary>
        public override void Reverse()
        {
            base.Reverse();
            foreach (KeyValuePair<string, string> kvp in _filesBackedup)
            {
                string src = kvp.Key;
                string dest = kvp.Value;

                if (System.IO.File.Exists(src)) System.IO.File.Delete(src);
                System.IO.FileInfo fileInfo = new System.IO.FileInfo(dest);
                fileInfo.MoveTo(src);
            }
            _filesBackedup.Clear();
        }
        #endregion

        #region Private memvers
        private Dictionary<string, string> _filesToBackup = new Dictionary<string, string>();
        private Dictionary<string, string> _filesBackedup = new Dictionary<string, string>();
        private string _actionID = System.DateTime.Now.ToFileTimeUtc().ToString(System.Globalization.CultureInfo.InvariantCulture);
        #endregion




    }
}
