using System;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace Sage.PInvoke
{
    /// <summary>
    /// Summary description for Native.
    /// </summary>
    public static class Kernel32
    {
        internal const int FORMAT_MESSAGE_ALLOCATE_BUFFER       = 0x00000100;
        internal const int FORMAT_MESSAGE_IGNORE_INSERTS        = 0x00000200;
        internal const int FORMAT_MESSAGE_FROM_SYSTEM           = 0x00001000;

        public static uint GetLongPathName(string lpszShortPath, [Out] StringBuilder lpszLongPath, uint cchBuffer)
        {
            return SafeNativeMethods.GetLongPathName(lpszShortPath, lpszLongPath, cchBuffer);
        }

        public static string GetShortPathName(string lpszLongPath)
        {
            StringBuilder shortNameBuffer = new StringBuilder(256);
            GetShortPathName(lpszLongPath, shortNameBuffer, (uint)shortNameBuffer.Capacity);
            return shortNameBuffer.ToString();
        }
        
        public static int GetShortPathName(string lpszLongPath, StringBuilder lpszShortPath, uint cchBuffer)
        {
            return SafeNativeMethods.GetShortPathName(lpszLongPath, lpszShortPath, cchBuffer);
        }

        public static uint GetCurrentProcessId()
        {
            return SafeNativeMethods.GetCurrentProcessId();
        }

        /// <summary>
        /// Get a handle to the current process.
        /// </summary>
        /// <returns>Returns the current process handle.</returns>
        public static IntPtr GetCurrentProcess()
        {
            return SafeNativeMethods.GetCurrentProcess();
        }

        public static UInt32 QueryDosDevice(string lpDeviceName, [Out] StringBuilder lpTargetPath, UInt32 ucchMax)
        {
            return SafeNativeMethods.QueryDosDevice(lpDeviceName, lpTargetPath, ucchMax);
        }

        public static bool DeviceIoControl(SafeFileHandle hDevice,
            UInt32 dwIoControlCode,
            IntPtr lpInBuffer,
            UInt32 nInBufferSize,
            [Out] IntPtr lpOutBuffer,
            UInt32 nOutBufferSize,
            ref UInt32 lpBytesReturned,
            IntPtr lpOverlapped)
        {
            return SafeNativeMethods.DeviceIoControl(hDevice,
            dwIoControlCode,
            lpInBuffer,
            nInBufferSize,
            lpOutBuffer,
            nOutBufferSize,
            ref lpBytesReturned,
             lpOverlapped);
        }


        public static bool GetDiskFreeSpaceEx(string lpDirectoryName,
                                                    out ulong lpFreeBytesAvailable,
                                                    out ulong lpTotalNumberOfBytes,
                                                    out ulong lpTotalNumberOfFreeBytes)
        {
            return SafeNativeMethods.GetDiskFreeSpaceEx(lpDirectoryName, out lpFreeBytesAvailable,
                                                                out lpTotalNumberOfBytes,
                                                                out lpTotalNumberOfFreeBytes);
        }

        public static IntPtr LoadLibrary(string lpFileName)
        {
            return NativeMethods.LoadLibrary(lpFileName);
        }

        public static bool FreeLibrary(IntPtr hModule)
        {
            return NativeMethods.FreeLibrary(hModule);
        }

        public static IntPtr GetModuleHandle(string lpModuleName)
        {
            return NativeMethods.GetModuleHandle(lpModuleName);
        }

        public static bool CloseHandle(IntPtr handle)
        {
            return NativeMethods.CloseHandle(handle);
        }

        /// <summary>
        /// Formats a Win32 error message.
        /// </summary>
        /// <param name="dwFlags">The message flags.</param>
        /// <param name="lpSource">A pointer message definition location.</param>
        /// <param name="dwMessageId">The message Id.</param>
        /// <param name="dwLanguageId">The language Id (specify zero for default).</param>
        /// <param name="lpBuffer">A reference to the string that stores the message.</param>
        /// <param name="nSize">Specify the size of lpBuffer.</param>
        /// <param name="Arguments">A pointer to an array of arguments for string formatting.</param>
        /// <returns>Returns the number of characters stored in the output buffer.</returns>
        public static int FormatMessage(
            int dwFlags, ref IntPtr lpSource, int dwMessageId,
            int dwLanguageId, ref String lpBuffer, int nSize,
            IntPtr Arguments)
        {
            return NativeMethods.FormatMessage(
            dwFlags, ref lpSource, dwMessageId,
            dwLanguageId, ref lpBuffer, nSize,
            Arguments);
        }

        /// <summary>
        /// Get a formatted error message for the specified Win32 error code.
        /// </summary>
        /// <param name="errorCode">The Win32 error code.</param>
        /// <returns>Returns the formatted error message.</returns>
        public static string GetErrorMessage(int errorCode)
        {
            int messageSize = 255;
            String lpMsgBuf = "";
            int dwFlags = FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS;
            IntPtr ptrlpSource = IntPtr.Zero;
            IntPtr prtArguments = IntPtr.Zero;
            
            if (FormatMessage(dwFlags, ref ptrlpSource, errorCode, 0, ref lpMsgBuf, messageSize, prtArguments) == 0)
            {
                System.Diagnostics.Debug.WriteLine(string.Format("Failed to format the error code '{0}.'", errorCode));
            }

            return lpMsgBuf;
        }

        public static int GetPrivateProfileString(string section,
            string key, string strDefault, StringBuilder returnedString, int size,
            string filePath)
        {
            return NativeMethods.GetPrivateProfileString(section,
            key, strDefault, returnedString, size,
            filePath);
        }

        public static int GetPrivateProfileInt(string lpAppName,
            string lpKeyName, int iDefault, string lpFileName)
        {
            return NativeMethods.GetPrivateProfileInt(lpAppName,
            lpKeyName, iDefault, lpFileName);
        }

        public static bool WritePrivateProfileString(string lpAppName,
            string lpKeyName, string lpString, string lpFileName)
        {
            return NativeMethods.WritePrivateProfileString(lpAppName,
            lpKeyName, lpString, lpFileName);
        }

        public static int GetPrivateProfileSection(string lpAppName,
            byte[] lpReturnedString, int nSize, string lpFileName)
        {
            return NativeMethods.GetPrivateProfileSection(lpAppName,
            lpReturnedString, nSize, lpFileName);
        }

        public static bool WritePrivateProfileSection(string lpAppName,
            byte[] data, string lpFileName)
        {
            return NativeMethods.WritePrivateProfileSection(lpAppName,
            data, lpFileName);
        }

        public static int GetPrivateProfileSectionNames(
            byte[] lpReturnedString, int nSize, string lpFileName)
        {
            return NativeMethods.GetPrivateProfileSectionNames(lpReturnedString, nSize, lpFileName);
        }

        public static IntPtr CreateMailslot(string name,
            uint maxMsgSize, uint readTimeout, IntPtr securityAttrs)
        {
            return NativeMethods.CreateMailslot(name, maxMsgSize, readTimeout, securityAttrs);
        }

        public static bool GetMailslotInfo(IntPtr hSlot,
            IntPtr maxMsgSize, ref uint nextSize, ref uint msgCount, IntPtr readTimeout)
        {
            return NativeMethods.GetMailslotInfo(hSlot, maxMsgSize, ref nextSize, ref msgCount, readTimeout);
        }

        public static bool ReadFile(IntPtr hSlot,
            [Out] byte[] lpBuffer, uint numBytesToRead,
            IntPtr lpNumBytesRead, [In] ref OVERLAPPED lpOverlapped)
        {
            return NativeMethods.ReadFile(hSlot,
            lpBuffer, numBytesToRead,
            lpNumBytesRead, ref lpOverlapped);
        }

        public static SafeFileHandle CreateFile(string fileName,
            FileAccess desiredAccess,
            FileShare shareMode,
            IntPtr securityAttributes,
            CreationDisposition creationDisposition,
            uint flagsAndAttributes,
            IntPtr templateFile)
        {
            return NativeMethods.CreateFile(fileName,
                                                    desiredAccess,
                                                    shareMode,
                                                    securityAttributes,
                                                    creationDisposition,
                                                    flagsAndAttributes,
                                                    templateFile);
        }

        public static bool WriteFile(IntPtr hFile,
            byte[] lpBuffer,
            uint numBytesToWrite,
            out int numBytesWritten,
            [In] ref OVERLAPPED lpOverlapped)
        {
            return NativeMethods.WriteFile(hFile,
                                                    lpBuffer,
                                                    numBytesToWrite,
                                                    out numBytesWritten,
                                                    ref lpOverlapped);
        }


        public static IntPtr GetProcessWindowStation()
        {
            return NativeMethods.GetProcessWindowStation();

        }

        [return: MarshalAs(UnmanagedType.Bool)]
        public static bool GetUserObjectInformation
            (
            IntPtr hObj,
            int nIndex,
            IntPtr pvInfo,
            int nLength,
            out int lpnLengthNeeded
            )
        {
            return NativeMethods.GetUserObjectInformation(hObj, nIndex, pvInfo, nLength, out lpnLengthNeeded);
        }

        public static bool GetOverlappedResult
            (
            IntPtr hFile,
            IntPtr lpOverlapped,
            out uint nNumberOfBytesTransferred,
            Boolean bWait
            )
        {
            return NativeMethods.GetOverlappedResult(hFile, lpOverlapped, out nNumberOfBytesTransferred, bWait);
        }

        public static IntPtr CreateNamedPipe
            (
            String lpName,                     // pipe name
            uint dwOpenMode,                 // pipe open mode
            uint dwPipeMode,                 // pipe-specific modes
            uint nMaxInstances,              // maximum number of instances
            uint nOutBufferSize,             // output buffer size
            uint nInBufferSize,              // input buffer size
            uint nDefaultTimeOut,            // time-out interval
            IntPtr lpSecurityAttributes
            )
        {
            return NativeMethods.CreateNamedPipe(lpName, dwOpenMode, dwPipeMode, nMaxInstances, nOutBufferSize, nInBufferSize, nDefaultTimeOut, lpSecurityAttributes);
        }

        public static bool ConnectNamedPipe
            (
            IntPtr hNamedPipe,             // handle to named pipe
            IntPtr lpOverlapped            // overlapped structure
            )
        {
            return NativeMethods.ConnectNamedPipe(hNamedPipe, lpOverlapped);
        }

        public static bool WaitNamedPipe
            (
            String lpNamedPipeName,
            uint nTimeOut
            )
        {
            return NativeMethods.WaitNamedPipe(lpNamedPipeName, nTimeOut);
        }

        public static bool FlushFileBuffers(IntPtr hFile)
        {
            return NativeMethods.FlushFileBuffers(hFile);
        }

        public static bool DisconnectNamedPipe(IntPtr hNamedPipe)
        {
            return NativeMethods.DisconnectNamedPipe(hNamedPipe);
        }

        public static bool SetNamedPipeHandleState
            (
            IntPtr hNamedPipe,
            ref int lpMode,
            IntPtr lpMaxCollectionCount,
            IntPtr lpCollectDataTimeout
            )
        {
            return NativeMethods.SetNamedPipeHandleState(hNamedPipe, ref lpMode, lpMaxCollectionCount, lpCollectDataTimeout);
        }

        public static bool CancelIo(IntPtr hFile)
        {
            return NativeMethods.CancelIo(hFile);
        }

        public static void ZeroMemory(IntPtr Destination, int Length)
        {
            NativeMethods.ZeroMemory(Destination, Length);
        }

        public static int QueryPerformanceFrequency(out Int64 lpFrequency)
        {
            return SafeNativeMethods.QueryPerformanceFrequency(out lpFrequency);
        }

        public static int QueryPerformanceCounter(out Int64 lpPerformanceCount)
        {
            return SafeNativeMethods.QueryPerformanceCounter(out lpPerformanceCount);
        }

        [Obsolete("Use System.IO.DriveInfo.DriveType instead!")]
        public static int GetDriveType(string drv)
        {
            return SafeNativeMethods.GetDriveType(drv);
        }

        public static UInt32 WTSGetActiveConsoleSessionId()
        {
            return NativeMethods.WTSGetActiveConsoleSessionId();
        }

        public static bool GetVersion(ref OSVersionInfo osVersionInfo)
        {
            return NativeMethods.GetVersion(ref osVersionInfo);
        }

        public static bool GetVersionEx(ref OSVersionInfoEx osVersionInfo)
        {
            return NativeMethods.GetVersionEx(ref osVersionInfo);
        }

        public static ulong VerSetConditionMask(ulong dwlConditionMask,
           TestTypeMask dwTypeBitMask, VersionConditionMask dwConditionMask)
        {
            return SafeNativeMethods.VerSetConditionMask(dwlConditionMask, dwTypeBitMask, dwConditionMask);
        }

        public static bool VerifyVersionInfo(ref OSVersionInfoEx lpVersionInfo,
            uint dwTypeMask, ulong dwlConditionMask)
        {
            return SafeNativeMethods.VerifyVersionInfo(ref lpVersionInfo, dwTypeMask, dwlConditionMask);
        }

        public static IntPtr CreateFileMapping(IntPtr hFile,
            IntPtr lpFileMappingAttributes, 
            PageProtection flProtect,
            uint dwMaximumSizeHigh,
            uint dwMaximumSizeLow, 
            string lpName)
        {
            return NativeMethods.CreateFileMapping(hFile, lpFileMappingAttributes, flProtect, dwMaximumSizeHigh, dwMaximumSizeLow, lpName);
        }


        public static IntPtr MapViewOfFile(IntPtr hFileMappingObject,
            FileMapAccess dwDesiredAccess,
            uint dwFileOffsetHigh,
            uint dwFileOffsetLow,
            uint dwNumberOfBytesToMap)
        {
            return NativeMethods.MapViewOfFile(hFileMappingObject, dwDesiredAccess, dwFileOffsetHigh, dwFileOffsetLow, dwNumberOfBytesToMap);
        }
    }
}
