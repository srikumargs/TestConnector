using System;
using System.Diagnostics;
using System.Collections;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Proxies;
using System.Runtime.Remoting.Messaging;

namespace Sage.Diagnostics
{

    /// <summary>
    /// 
    /// </summary>
    [ComVisible(false)]
    public class RemotingIDHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static String GetURLForObject(MarshalByRefObject obj)
        {
            String URL = null;

            // trying for CAOs
            ObjRef o = RemotingServices.GetObjRefForProxy(obj);
            if (o != null) 
            {
                foreach (object data in o.ChannelInfo.ChannelData) 
                {
                    ChannelDataStore ds = data as ChannelDataStore;
                    if (ds != null) 
                    {
                        URL = ds.ChannelUris[0] + o.URI;
                        break;
                    }
                }
            } 
            else 
            {
                // either SAO or not remote!
                URL = RemotingServices.GetObjectUri(obj);
            }
            return URL;
        }
    }

    /// <summary>
    /// Factory for client to use the trace proxy for debugging ivocations.
    /// </summary>
    [ComVisible(false)]
    public class TraceProxyFactory
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="url"></param>
        /// <returns></returns>
        public static object CreateProxy(object obj, string url)
        {
            return new TraceProxy(obj, url).GetTransparentProxy();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="t"></param>
        /// <param name="url"></param>
        /// <returns></returns>
        public static object CreateProxy(Type t, string url)
        {
            return new TraceProxy(t, url).GetTransparentProxy();
        }
    }


    /// <summary>
    /// 
    /// </summary>
	[ComVisible(false)]
	public class TraceProxy : RealProxy
	{
		private string _url;
		private string _uri;
        //private object _target;
		private IMessageSink _sinkChain;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="url"></param>
		public TraceProxy(object obj, string url) : base(obj.GetType())
		{
            //_target = obj;
			_url = url;

            BuildUri();
		}


        /// <summary>
        /// 
        /// </summary>
        /// <param name="t"></param>
        /// <param name="url"></param>
        public TraceProxy(Type t, string url) : base(t)
        {
            //_target = obj;
            _url = url;

            BuildUri();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
		public override IMessage Invoke(IMessage msg)
		{
			DumpMessageContents(msg);
			msg.Properties["__Uri"] = _url;

            //DumpSinkChain();
			IMessage retMsg = _sinkChain.SyncProcessMessage(msg);
			DumpMessageContents(retMsg);

			return retMsg;
		}


        private void BuildUri()
        {
            // check each registered channel if it accepts the
            // given URL
            IChannel[] registeredChannels = ChannelServices.RegisteredChannels;
            foreach (IChannel channel in registeredChannels )
            {
                if (channel is IChannelSender)
                {
                    IChannelSender channelSender = (IChannelSender)channel;
                    Trace.WriteLine("Channel Name: " + channelSender.ChannelName);

                    // try to create the sink
                    _sinkChain = channelSender.CreateMessageSink(_url, null, out _uri);
					
                    // if the channel returned a sink chain, exit the loop
                    if (_sinkChain != null)
                    {
                        break;
                    }
                }
            }

            // no registered channel accepted the URL
            if (_sinkChain == null)
            {
                throw new Exception("No channel has been found for " + _url);
            }
        }

		private String GetPaddedString(String str) 
		{
			String ret = str + "                  ";
			return ret.Substring(0,17);
		}

//        private void DumpSinkChain()
//        {
//            IMessageSink sink = this._sinkChain;
//            IClientFormatterSink cfs = (IClientFormatterSink) sink;
//            while (sink != null)
//            {
//                Trace.WriteLine("Sink type in chain: " + sink.ToString());
//                sink = sink.NextSink;
//            }
//        }

		private void DumpMessageContents(IMessage msg) 
		{
			Trace.WriteLine("========================================");
			Trace.WriteLine("============ Message Dump ==============");
			Trace.WriteLine("========================================");

			Trace.WriteLine(string.Format("Type: {0}", msg.GetType().ToString()));

			Trace.WriteLine("--- Properties ---");
			IDictionary dict = msg.Properties;
			IDictionaryEnumerator enm = (IDictionaryEnumerator) dict.GetEnumerator();

			while (enm.MoveNext())
			{
				Object key = enm.Key;
				String keyName = key.ToString();
				Object val = enm.Value;

                //Trace.WriteLine(string.Format("{0}: {1}", GetPaddedString(keyName), val));
                //Trace.WriteLine(string.Format("{0}: {1}", GetPaddedString(keyName), (val == null) ? "null" : val));
                Trace.WriteLine(string.Format("{0}: {1}", GetPaddedString(keyName), (val == null) ? "null" : val.ToString()));

                if (val != null)
                {
                    if (val is System.Array)
                    {
                        // check if it's an object array
                        Object[] objval = val as Object[];
                        if (objval != null)
                        {
                            DumpObjectArray(objval);
                        }
                    }
                }
			}
			Trace.WriteLine("");
			Trace.WriteLine("");
		}

		private void DumpObjectArray(object[] data) 
		{
			// if empty -> return
			if (data.Length == 0) return;
			
			Trace.WriteLine("\t --- Array Contents ---");
			for (int i = 0; i < data.Length; i++) 
			{
				Trace.WriteLine(string.Format("\t{0}: {1}", i, data[i]));
			}
		}
	}
}
