using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;


namespace Sage.Diagnostics
{

    /// <summary>
    /// Exception base class that automatically logs to the event log
    /// Use this class as a base class passing in the source into
    /// the ctor.
    /// </summary>
    /// <remarks>
    /// Great care should be exercised before deciding to use this class, because
    /// it is not necessarily appropriate to write to the System Event Log just
    /// because you are throwing an exception.  Components in particular should
    /// usually not do this because the exceptions they throw could be caught and
    /// handled by the calling client.  If that is the case, then it is likely
    /// inappropriate to use an end-user visible communication channel to report
    /// that an exception was thrown.  Note that every "red X" in the System
    /// Event Log potentially represents a customer support call.
    /// 
    /// Instead, consider using the TracingBaseException.
    /// </remarks>
    [ComVisible(false)]
    [Serializable]
    [TraceListenerIgnoreTypeAttribute]
    public class LoggingBaseException : ApplicationException
    {
        /// <summary>
        /// Required for serialization
        /// </summary>
        /// <param name="si"></param>
        /// <param name="sc"></param>
        protected LoggingBaseException(SerializationInfo si, StreamingContext sc)
            : base(si, sc)
        {}

        /// <summary>
        /// Default ctor
        /// </summary>
        protected LoggingBaseException()
        {}

        /// <summary>
        /// ctor takes source and error message string
        /// </summary>
        protected LoggingBaseException(string source, string errorMsg)
            : base(errorMsg) 
        {
            Source = source;
            try
            {
                EventLogger.LogException(this);
            }
            catch
            {}
        }

        /// <summary>
        /// ctor takes source, error message string and inner exception
        /// </summary>
        protected LoggingBaseException(string source, string errorMsg, Exception inner)
            : base(errorMsg, inner)
        {
            Source = source;
            try
            {
                EventLogger.LogException(this);
            }
            catch
            {}
        }

        /// <summary>
        /// Delegates to the EventLogger
        /// </summary>
        /// <param name="source"></param>
        /// <param name="errorMsg"></param>
        public static void LogError(string source, string errorMsg)
        {
            try
            {
                EventLogger.WriteMessage(source, errorMsg, MessageType.Error);
            }
            catch
            {}
        }

		/// <summary>
		/// Delegates to the EventLogger
		/// </summary>
		/// <param name="source"></param>
		/// <param name="errorMsg"></param>
		public static void LogWarning( string source, string errorMsg )
		{
			try
			{
				EventLogger.WriteMessage( source, errorMsg, MessageType.Warning );
			}
			catch
			{
			}
		}

    }
}
