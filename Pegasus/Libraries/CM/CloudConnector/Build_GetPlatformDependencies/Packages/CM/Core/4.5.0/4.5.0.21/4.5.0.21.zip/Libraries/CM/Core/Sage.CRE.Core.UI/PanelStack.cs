using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace Sage.CRE.Core.UI
{
    /// <summary>
    /// This control behaves like a tab-less tab control.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix", Justification="I don't think the usage of the term Stack is going to generate confusion."), Designer(typeof(PanelStackDesigner))]
    public partial class PanelStack : UserControl
    {
        #region Constructors
        /// <summary>
        /// Constructor
        /// </summary>
        public PanelStack()
        {
            _panelStackCollection = new PanelStackPanelCollection(this);

            InitializeComponent();
        }
        #endregion

        #region Public properties
        /// <summary>
        /// The collection of items for this control
        /// </summary>
        [
        Category("Data"),
        Description("The collection of items for this control."),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Content)
            //Editor(typeof(System.ComponentModel.Design.CollectionEditor), typeof(System.Drawing.Design.UITypeEditor))
        ]
        public PanelStackPanelCollection Panels
        {
            get
            {
                return _panelStackCollection;
            }
        }

        /// <summary>
        /// Gets/Sets the active panel
        /// </summary>
        [
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
        Browsable(false)
        ]
        public int ActivePanelIndex
        {
            get
            {
                return _panelStackCollection.IndexOf(_activePanel);
            }
            set
            {
                // Do I have any panels?
                if (_panelStackCollection.Count == 0)
                {
                    // No then show nothing
                    ActivatePanel(-1);
                    return;
                }

                if (value != _panelStackCollection.IndexOf(_activePanel))
                {
                    // Validate the panel asked for
                    if (value < -1 || value >= _panelStackCollection.Count)
                    {
                        throw new ArgumentOutOfRangeException(Strings.PANEL_INDEX, value, Strings.PANEL_INDEX_EXCEPTION + Convert.ToString(_panelStackCollection.Count - 1, CultureInfo.CurrentCulture));
                    }

                    // Select the new panel
                    ActivatePanel(value);
                }
            }
        }

        /// <summary>
        /// Alternative way of getting/setting the current panel by using PanelStackPanel objects
        /// </summary>
        public PanelStackPanel ActivePanel
        {
            get
            {
                return _activePanel;
            }
            set
            {
                ActivatePanel(value);
            }
        }
        #endregion

        #region Public events
        /// <summary>
        /// This event is fired when the activate panel is changed.
        /// </summary>
        public event EventHandler ActivePanelChanged
        {
            add
            {
                _activePanelChangedEventHandler += value;
            }
            remove
            {
                _activePanelChangedEventHandler -= value;
            }
        }
        #endregion

        #region Private methods
        private void ActivatePanel(int index)
        {
            // If the new panel is invalid
            if (index < 0 || index >= _panelStackCollection.Count)
            {
                return;
            }

            // Change to the new panel
            PanelStackPanel panel = ((PanelStackPanel)_panelStackCollection[index]);

            // Really activate the panel
            ActivatePanel(panel);
        }

        internal void ActivatePanel(PanelStackPanel panel)
        {
            // don't short-circuit the panel activation if we haven't activated anything
            // before.
            if (_initialPanelActivated)
            {
                // we have already activated something before so if we are already at the
                // requested panel, then just do nothing
                if (_activePanel == panel)
                {
                    return;
                }
            }

            // Deactivate the current
            if (_activePanel != null)
            {
                _activePanel.Visible = false;
            }


            // Activate the new panel
            _activePanel = panel;

            if (_activePanel != null)
            {
                // Ensure that this panel displays inside the PanelStack
                _activePanel.Parent = this;
                if (this.Contains(_activePanel) == false)
                {
                    this.Container.Add(_activePanel);
                }

                // Make it fill the space
                _activePanel.Dock = DockStyle.Fill;
                _activePanel.Visible = true;
                _activePanel.BringToFront();
                _activePanel.FocusFirstTabIndex();

                if (_activePanelChangedEventHandler != null)
                {
                    _activePanelChangedEventHandler(this, null);
                }
            }


            // Cause a refresh
            if (_activePanel != null)
            {
                _activePanel.Invalidate();
            }
            else
            {
                this.Invalidate();
            }
        }

        private void PanelStack_Load(object sender, EventArgs e)
        {
            ActivatePanel(ActivePanel);
            _initialPanelActivated = true;
        }
        #endregion

        #region Private fields
        private PanelStackPanelCollection _panelStackCollection;    //= null; (automatically initialized by runtime)
        private PanelStackPanel _activePanel;                       //= null; (automatically initialized by runtime)
        private event EventHandler _activePanelChangedEventHandler; //= null; (automatically initialized by runtime)
        private bool _initialPanelActivated;                        //= false; (automatically initialized by runtime)
        #endregion
    }




    
    //[DesignTimeVisible(false), TypeConverter("PanelStackPanelConverter")]
    /// <summary>
    /// An individual panel that is part of the panel stack
    /// </summary>
    public class PanelStackPanel : System.Windows.Forms.Panel
    {
        #region Public methods
        /// <summary>
        /// Set the focus to the contained control with a lowest tabIndex
        /// </summary>
        public void FocusFirstTabIndex()
        {
            // Activate the first control in the Panel
            Control found = null;

            // find the control with the lowest
            foreach (Control control in this.Controls)
            {
                if (control.CanFocus && (found == null || control.TabIndex < found.TabIndex))
                {
                    found = control;
                }
            }

            // Have we actually found anything
            if (found != null)
            {
                // Focus the found control
                found.Focus();
            }
            else
            {
                // Just focus the panel
                this.Focus();
            }
        }
        #endregion
    }



    /// <summary>
    /// A collection of PanelStack panels.
    /// </summary>
    public class PanelStackPanelCollection : CollectionBase
    {
        #region Constructors
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="stack">the PanelStack</param>
        public PanelStackPanelCollection(PanelStack stack)
            : base()
        {
            this._panelStack = stack;
        }
        #endregion

        #region Public properties
        /// <summary>
        /// The PanelStack
        /// </summary>
        public PanelStack Stack
        {
            get
            {
                return _panelStack;
            }
        }

        /// <summary>
        /// a basic indexer of the type of your collection
        /// </summary>
        /// <param name="index">The index of the panel you want</param>
        /// <returns></returns>
        public PanelStackPanel this[int index]
        {
            get
            {
                return List[index] as PanelStackPanel;
            }
            set
            {
                List[index] = value;
            }
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Add a panel to the collection
        /// </summary>
        /// <param name="item">the PanelStack panel to add</param>
        /// <returns></returns>
        public int Add(PanelStackPanel item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            item.Visible = false;
            return List.Add(item);
        }

        /// <summary>
        /// Adds an array of panels into the collection. Used by the Studio Designer generated coed
        /// </summary>
        /// <param name="panels">Array of panels to add</param>
        public void AddRange(PanelStackPanel[] panels)
        {
            // Use external to validate and add each entry
            foreach (PanelStackPanel panel in panels)
            {
                this.Add(panel);
            }
        }

        /// <summary>
        /// Finds the position of the panel in the colleciton
        /// </summary>
        /// <param name="value">Panel to find position of</param>
        /// <returns>Index of Panel in collection</returns>
        public int IndexOf(PanelStackPanel value)
        {
            return (List.IndexOf(value));
        }

        /// <summary>
        /// Adds a new panel at a particular position in the Collection
        /// </summary>
        /// <param name="index">Position</param>
        /// <param name="value">Panel to be added</param>
        public void Insert(int index, PanelStackPanel value)
        {
            List.Insert(index, value);
        }

        /// <summary>
        /// Removes the given panel from the collection
        /// </summary>
        /// <param name="value">Panel to remove</param>
        public void Remove(PanelStackPanel value)
        {
            List.Remove(value);
        }

        /// <summary>
        /// Detects if a given Panel is in the Collection
        /// </summary>
        /// <param name="value">Panel to find</param>
        /// <returns></returns>
        public bool Contains(PanelStackPanel value)
        {
            // If value is not of type Int16, this will return false.
            return (List.Contains(value));
        }
        #endregion

        #region Protected methods
        /// <summary>
        /// Propgate when a external designer modifies the panels
        /// </summary>
        /// <param name="index"></param>
        /// <param name="value"></param>
        protected override void OnInsertComplete(int index, object value)
        {
            base.OnInsertComplete(index, value);
            // Show the panel added
            // stack.PanelIndex = index;
        }

        /// <summary>
        /// Propogates when external designers remove items from panel
        /// </summary>
        /// <param name="index"></param>
        /// <param name="value"></param>
        protected override void OnRemoveComplete(int index, object value)
        {
            base.OnRemoveComplete(index, value);

            // If the panel that was added was the one that was visible
            if (_panelStack.ActivePanelIndex == index)
            {
                // Can I show the one after
                if (index < InnerList.Count)
                {
                    _panelStack.ActivePanelIndex = index;
                }
                else
                {
                    // Can I show the end one (if not -1 makes everything disappear)
                    _panelStack.ActivePanelIndex = InnerList.Count - 1;
                }
            }
        }
        #endregion

        #region Private methods
        private PanelStack _panelStack; //= null; (automatically initialized by runtime)
        #endregion
    }

    /// <summary>
    /// This class exists so that the PanelStack control can be utilized in
    /// the designer.
    /// </summary>
    public class PanelStackDesigner : System.Windows.Forms.Design.ParentControlDesigner
    {
        #region Public properties
        /// <summary>
        /// Verbs that show up at the bottom of the properties pane
        /// </summary>
        public override System.ComponentModel.Design.DesignerVerbCollection Verbs
        {
            get
            {
                if (!_customVerbsAdded)
                {
                    base.Verbs.Add(new System.ComponentModel.Design.DesignerVerb(Strings.PREVIOUS_PANEL, new EventHandler(OnVerbPreviousPanel)));
                    base.Verbs.Add(new System.ComponentModel.Design.DesignerVerb(Strings.NEXT_PANEL, new EventHandler(OnVerbNextPanel)));
                    base.Verbs.Add(new System.ComponentModel.Design.DesignerVerb(Strings.ADD_PANEL, new EventHandler(OnVerbAddPanel)));
                    _customVerbsAdded = true;
                }
                return base.Verbs;
            }
        }
        #endregion

        #region Private methods
        private void OnVerbPreviousPanel(object sender, EventArgs e)
        {
            PanelStack panelStack = (Control as PanelStack);
            if (panelStack.ActivePanelIndex == 0)
            {
                panelStack.ActivePanelIndex = panelStack.Panels.Count - 1;
            }
            else
            {
                panelStack.ActivePanelIndex = panelStack.ActivePanelIndex - 1;
            }
        }

        private void OnVerbNextPanel(object sender, EventArgs e)
        {
            PanelStack panelStack = (Control as PanelStack);
            if (panelStack.ActivePanelIndex == panelStack.Panels.Count - 1)
            {
                panelStack.ActivePanelIndex = 0;
            }
            else
            {
                panelStack.ActivePanelIndex = panelStack.ActivePanelIndex + 1;
            }
        }

        private void OnVerbAddPanel(object sender, EventArgs e)
        {
            PanelStack panelStack = (Control as PanelStack);
            panelStack.ActivatePanel(new PanelStackPanel());
        }
        #endregion

        #region Private fields
        private bool _customVerbsAdded; //= null; (automatically initialized by runtime)
        #endregion
    }

}
