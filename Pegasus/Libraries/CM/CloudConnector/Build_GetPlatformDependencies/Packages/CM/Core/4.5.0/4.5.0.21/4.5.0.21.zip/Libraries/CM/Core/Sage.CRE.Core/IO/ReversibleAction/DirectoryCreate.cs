using System;
using System.Collections.Generic;
using System.Security.AccessControl;

namespace Sage.IO.ReversibleAction
{
    /// <summary>
    /// Creates one or more directories using the ReversibleAction pattern.
    /// The construction of a DirectoryCreate object creates the specified directory.
    /// If the object is disposed without calling the Commit() method, then the directory create is reversed.
    /// 
    /// Typical usage:
    /// 
    /// using (DirectoryCrate dirCreate = new DirectoryCreate(@"C:\sourceDirectory"))
    ///     {
    ///         dirCreate.Forward();
    ///         
    ///         // do some code that might throw. If this code throws, we need to reverse the directory create
    /// 
    ///         dirCreate.Commit();
    ///     }
    /// </summary>
    public class DirectoryCreate : ReversibleActionBase
    {
        /// <summary>
        /// Create a single directory.
        /// </summary>
        /// <param name="directoryName">The name of the directory to create.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1805:DoNotInitializeUnnecessarily")]
        public DirectoryCreate(string directoryName)
        {
            _directoriesToCreate.Add(directoryName);
            _security = null;

        }

        /// <summary>
        /// Create a single directory with the specified security.
        /// </summary>
        /// <param name="directoryName">The name of the directory to create.</param>
        /// <param name="security">The security attributes to apply to the created directory.</param>
        public DirectoryCreate(string directoryName, DirectorySecurity security)
        {
            _directoriesToCreate.Add(directoryName);
            _security = security;

        }

        /// <summary>
        /// Create a set of directories.
        /// </summary>
        /// <param name="directories">A list of directories to create.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1805:DoNotInitializeUnnecessarily")]
        public DirectoryCreate(System.Collections.ObjectModel.Collection<string> directories)
        {
            _directoriesToCreate = directories;
            _security = null;

        }

        /// <summary>
        /// Create a set of directories with the specified security attributes.
        /// </summary>
        /// <param name="directories">A list of directories to create.</param>
        /// <param name="security">The security attributes to apply to the created directories.</param>
        public DirectoryCreate(System.Collections.ObjectModel.Collection<string> directories, DirectorySecurity security)
        {
            _directoriesToCreate = directories;
            _security = security;

        }

        #region Protected Methods
        /// <summary>
        /// Create the previously specified directories.
        /// </summary>
        public override void Forward()
        {
            base.Forward();
            _directoriesCreated.Clear();
            foreach (string directoryName in _directoriesToCreate)
            {

                if (_security == null)
                {
                    System.IO.Directory.CreateDirectory(directoryName);
                }
                else
                {
                    System.IO.Directory.CreateDirectory(directoryName, _security);
                }

                _directoriesCreated.Add(directoryName);
            }
        }

        /// <summary>
        /// Remove any created directories and their contents.
        /// </summary>
        public override void Reverse()
        {
            base.Reverse();
            foreach (string directoryName in _directoriesCreated)
            {
                if (System.IO.Directory.Exists(directoryName)) System.IO.Directory.Delete(directoryName, true);
            }
            _directoriesCreated.Clear();
        }
        #endregion

        #region Private members
        private System.Collections.ObjectModel.Collection<string> _directoriesToCreate = new System.Collections.ObjectModel.Collection<string>();
        private List<string> _directoriesCreated = new List<string>();
        private DirectorySecurity _security;
        #endregion
    }
}
