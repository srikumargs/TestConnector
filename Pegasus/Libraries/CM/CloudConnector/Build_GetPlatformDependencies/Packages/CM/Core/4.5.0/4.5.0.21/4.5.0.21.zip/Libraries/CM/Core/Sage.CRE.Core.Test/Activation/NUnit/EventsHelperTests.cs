#if DEBUG
using System;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections.ObjectModel;
using System.Threading;
using NUnit.Framework;

using Sage.Activation; 

namespace Sage.Activation.NUnit.Tests
{
    /// <summary>
    /// Invokes various members of the EventsHelper class.
    /// </summary>
    [TestFixture]
    public class EventsHelperTests
    {
        #region Public methods
        /// <summary>
        /// Tests EventsHelper.Notify
        /// </summary>
        [Test]
        public void NotifyStringEventHappened()
        {
            EventPublisher publisher = new EventPublisher();

            EventSubscriber sub1 = new EventSubscriber(true);
            publisher.StringEventHappened += new EventHandler<StringEventArgs>(sub1.OnStringEventHappened);
            EventSubscriber sub2 = new EventSubscriber(false);
            publisher.StringEventHappened += new EventHandler<StringEventArgs>(sub2.OnStringEventHappened);

            sub1.Reset();
            sub2.Reset();
            publisher.RaiseStringEventHappened();

            Assertion.AssertEquals("Unexpected EventSubscriber.EventCount value", 2, sub1.EventCount + sub2.EventCount);
            Assertion.AssertEquals("Unexpected EventSubscriber.SuccededEventCount value", 1, sub1.SuccededEventCount + sub2.SuccededEventCount);

            sub1.Reset();
            sub2.Reset();
            publisher.RaiseStringEventHappened();

            Assertion.AssertEquals("Unexpected EventSubscriber.EventCount value", 1, sub1.EventCount + sub2.EventCount);
            Assertion.AssertEquals("Unexpected EventSubscriber.SuccededEventCount value", 1, sub1.SuccededEventCount + sub2.SuccededEventCount);
        }

        [Test]
        public void NotifyStringEventHappenedAsync()
        {
            EventPublisher publisher = new EventPublisher();

            EventSubscriber sub1 = new EventSubscriber(true);
            publisher.StringEventHappened += new EventHandler<StringEventArgs>(sub1.OnStringEventHappened);
            EventSubscriber sub2 = new EventSubscriber(false);
            publisher.StringEventHappened += new EventHandler<StringEventArgs>(sub2.OnStringEventHappened);

            sub1.Reset();
            sub2.Reset();
            publisher.RaiseStringEventHappenedAsync();
            WaitHandle.WaitAll(new WaitHandle[] { publisher._event, sub1._event, sub2._event });

            Assertion.AssertEquals("Unexpected EventSubscriber.EventCount value", 2, sub1.EventCount + sub2.EventCount);
            Assertion.AssertEquals("Unexpected EventSubscriber.SuccededEventCount value", 1, sub1.SuccededEventCount + sub2.SuccededEventCount);

            sub1.Reset();
            sub2.Reset();
            publisher.RaiseStringEventHappenedAsync();
            WaitHandle.WaitAll(new WaitHandle[] { sub2._event });

            Assertion.AssertEquals("Unexpected EventSubscriber.EventCount value", 1, sub1.EventCount + sub2.EventCount);
            Assertion.AssertEquals("Unexpected EventSubscriber.SuccededEventCount value", 1, sub1.SuccededEventCount + sub2.SuccededEventCount);
        }

        [Test]
        public void NotifyEventHappened()
        {
            EventPublisher publisher = new EventPublisher();

            EventSubscriber sub1 = new EventSubscriber(true);
            publisher.EventHappened += new EventHandler(sub1.OnEventHappened);
            EventSubscriber sub2 = new EventSubscriber(false);
            publisher.EventHappened += new EventHandler(sub2.OnEventHappened);

            sub1.Reset();
            sub2.Reset();
            publisher.RaiseEventHappened();

            Assertion.AssertEquals("Unexpected EventSubscriber.EventCount value", 2, sub1.EventCount + sub2.EventCount);
            Assertion.AssertEquals("Unexpected EventSubscriber.SuccededEventCount value", 1, sub1.SuccededEventCount + sub2.SuccededEventCount);

            sub1.Reset();
            sub2.Reset();
            publisher.RaiseEventHappened();

            Assertion.AssertEquals("Unexpected EventSubscriber.EventCount value", 1, sub1.EventCount + sub2.EventCount);
            Assertion.AssertEquals("Unexpected EventSubscriber.SuccededEventCount value", 1, sub1.SuccededEventCount + sub2.SuccededEventCount);
        }

        [Test]
        public void NotifyEventHappenedAsync()
        {
            EventPublisher publisher = new EventPublisher();

            EventSubscriber sub1 = new EventSubscriber(true);
            publisher.EventHappened +=new EventHandler(sub1.OnEventHappened);
            EventSubscriber sub2 = new EventSubscriber(false);
            publisher.EventHappened += new EventHandler(sub2.OnEventHappened);

            sub1.Reset();
            sub2.Reset();
            publisher.RaiseEventHappenedAsync();
            WaitHandle.WaitAll(new WaitHandle[] { publisher._event, sub1._event, sub2._event });

            Assertion.AssertEquals("Unexpected EventSubscriber.EventCount value", 2, sub1.EventCount + sub2.EventCount);
            Assertion.AssertEquals("Unexpected EventSubscriber.SuccededEventCount value", 1, sub1.SuccededEventCount + sub2.SuccededEventCount);

            sub1.Reset();
            sub2.Reset();
            publisher.RaiseEventHappenedAsync();
            WaitHandle.WaitAll(new WaitHandle[] { sub2._event });

            Assertion.AssertEquals("Unexpected EventSubscriber.EventCount value", 1, sub1.EventCount + sub2.EventCount);
            Assertion.AssertEquals("Unexpected EventSubscriber.SuccededEventCount value", 1, sub1.SuccededEventCount + sub2.SuccededEventCount);
        }
        #endregion
    }

    internal class EventPublisher
    {
        public event EventHandler<StringEventArgs> StringEventHappened;
        public event EventHandler EventHappened;

        public void RaiseStringEventHappened()
        {
            ReadOnlyCollection<Delegate> misbehavingDelegates;
            EventsHelper.Notify(StringEventHappened, this, new StringEventArgs("the event happened"), out misbehavingDelegates);
            EventsHelper.RemoveDelegatesFromEventHandler(ref StringEventHappened, misbehavingDelegates);
        }

        public void RaiseStringEventHappenedAsync()
        {
            lock (this)
            {
                _event.Reset();
                EventsHelper.AsynchronousNotify(StringEventHappened, this, new StringEventArgs("the event happened"), new MisbehavingDelegatesCallback(this.OnMisbehavingStringEventHappenedDelegates));
            }
        }

        public void RaiseEventHappened()
        {
            ReadOnlyCollection<Delegate> misbehavingDelegates;
            EventsHelper.Notify(EventHappened, this, new EventArgs(), out misbehavingDelegates);
            EventsHelper.RemoveDelegatesFromEventHandler(ref EventHappened, misbehavingDelegates);
        }

        public void RaiseEventHappenedAsync()
        {
            lock (this)
            {
                _event.Reset();
                EventsHelper.AsynchronousNotify(EventHappened, this, new EventArgs(), new MisbehavingDelegatesCallback(this.OnMisbehavingEventHappenedDelegates));
            }
        }

        private void OnMisbehavingStringEventHappenedDelegates(ReadOnlyCollection<Delegate> delegates)
        {
            lock (this)
            {
                EventsHelper.RemoveDelegatesFromEventHandler(ref StringEventHappened, delegates);
                _event.Set();
            }
        }

        private void OnMisbehavingEventHappenedDelegates(ReadOnlyCollection<Delegate> delegates)
        {
            lock (this)
            {
                EventsHelper.RemoveDelegatesFromEventHandler(ref EventHappened, delegates);
                _event.Set();
            }
        }

        public ManualResetEvent _event = new ManualResetEvent(false);
    }

    internal class EventSubscriber
    {
        public EventSubscriber(bool throwException)
        {
            _throwException = throwException;
        }

        public void OnStringEventHappened(object sender, StringEventArgs args)
        {
            try
            {
                _eventCount++;
                if (_throwException)
                {
                    throw new Exception();
                }
                _succeededEventCount++;
            }
            finally
            {
                _event.Set();
            }
        }

        public void OnEventHappened(object sender, EventArgs args)
        {
            try
            {
                _eventCount++;
                if (_throwException)
                {
                    throw new Exception();
                }
                _succeededEventCount++;
            }
            finally
            {
                _event.Set();
            }
        }

        public UInt32 EventCount
        {
            get
            {
                return _eventCount;
            }
        }

        public UInt32 SuccededEventCount
        {
            get
            {
                return _succeededEventCount;
            }
        }

        public void Reset()
        {
            _eventCount = 0;
            _succeededEventCount = 0;
            _event.Reset();
        }

        private Boolean _throwException;                //= false; (automatically initialized by runtime)
        private UInt32 _eventCount;              //= 0; (automatically initialized by runtime)
        private UInt32 _succeededEventCount;     //= 0; (automatically initialized by runtime)
        public ManualResetEvent _event = new ManualResetEvent(false);
    }
}
#endif