using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Sage.PInvoke
{
    /// <summary>
    /// Defines Common Dialog P/Invoke API declarations.
    /// </summary>
    public class COMDLG32
    {
        /// <summary>
        /// Get the save filename.
        /// </summary>
        /// <param name="lpofn">A reference to the OPENFILENAME structure.</param>
        /// <returns>Returns true if the method is successfully executed; otherwise, false.</returns>
        public static bool GetSaveFileName(ref OPENFILENAME lpofn)
        {
            return SafeNativeMethods.GetSaveFileName(ref lpofn);
        }

        /// <summary>
        /// Get the open filename.
        /// </summary>
        /// <param name="lpofn">A reference to the OPENFILENAME structure.</param>
        /// <returns>Returns true if the method is successfully executed; otherwise, false.</returns>
        public static bool GetOpenFileName(ref OPENFILENAME lpofn)
        {
            return SafeNativeMethods.GetOpenFileName(ref lpofn);
        }

        /// <summary>
        /// Get the common dialog extended error value.
        /// </summary>
        /// <returns>Returns the error value.</returns>
        public static int CommDlgExtendedError()
        {
            return SafeNativeMethods.CommDlgExtendedError();
        }
    }
}
