﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security;
using System.Runtime.InteropServices;

namespace Sage.Utilities
{
    public static class SecureStringUtils
    {
        public static SecureString PtrToSecureString(IntPtr p)
        {
            SecureString s = new SecureString();
            Int32 i = 0;
            while (true)
            {
                Char c = (Char)Marshal.ReadInt16(p, ((i++) * sizeof(Int16)));
                if (c == '\u0000')
                    break;
                s.AppendChar(c);
            }
            s.MakeReadOnly();
            return s;
        }

        public static SecureString PtrToSecureString(IntPtr p, Int32 length)
        {
            SecureString s = new SecureString();
            for (var i = 0; i < length; i++)
            {
                s.AppendChar((Char)Marshal.ReadInt16(p, i * sizeof(Int16)));
            }
            s.MakeReadOnly();
            return s;
        }

        /// <summary>
        /// Convert a SecureString to a String
        /// Eventually will involve encryption and decryption
        /// </summary>
        /// <param name="sString"></param>
        /// <returns></returns>
        public static String ToNonSecureString(SecureString sString)
        {
            if (null == sString)
            {
                return String.Empty;
            }

            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(sString);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

        /// <summary>
        /// Convert a String to a SecureString
        /// </summary>
        /// <param name="stringToSecure"></param>
        /// <returns></returns>
        public static SecureString ToSecureString(String stringToSecure)
        {
            SecureString result = null;
            try
            {
                result = new SecureString();
                if (!String.IsNullOrEmpty(stringToSecure))
                {
                    char[] charArray = stringToSecure.ToCharArray();
                    foreach (char c in charArray)
                    {
                        result.AppendChar(c);
                    }
                }
                result.MakeReadOnly();
            }
            catch
            {
                if (result != null)
                {
                    result.Dispose();
                    result = null;
                }
            }
            return result;
        }
    }

}
