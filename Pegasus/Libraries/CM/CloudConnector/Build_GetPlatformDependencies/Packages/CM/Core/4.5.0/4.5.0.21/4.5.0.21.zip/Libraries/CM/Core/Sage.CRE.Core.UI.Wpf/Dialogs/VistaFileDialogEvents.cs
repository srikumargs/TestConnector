using System;
using System.Collections.Generic;
using System.Text;

namespace Sage.CRE.Core.UI.Wpf.Dialogs
{
    class VistaFileDialogEvents : Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialogEvents, Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialogControlEvents
    {
        const uint S_OK = 0;
        const uint S_FALSE = 1;
        const uint E_NOTIMPL = 0x80004001;

        private VistaFileDialog _dialog;

        public VistaFileDialogEvents(VistaFileDialog dialog)
        {
            if( dialog == null )
                throw new ArgumentNullException("dialog");

            _dialog = dialog;
        }

        #region IFileDialogEvents Members

        public Sage.CRE.Core.UI.Wpf.Dialogs.Interop.HRESULT OnFileOk(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialog pfd)
        {
            if( _dialog.DoFileOk(pfd) )
                return Sage.CRE.Core.UI.Wpf.Dialogs.Interop.HRESULT.S_OK;
            else
                return Sage.CRE.Core.UI.Wpf.Dialogs.Interop.HRESULT.S_FALSE;
        }

        public Sage.CRE.Core.UI.Wpf.Dialogs.Interop.HRESULT OnFolderChanging(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialog pfd, Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IShellItem psiFolder)
        {
            return Sage.CRE.Core.UI.Wpf.Dialogs.Interop.HRESULT.S_OK;
        }

        public void OnFolderChange(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialog pfd)
        {
        }

        public void OnSelectionChange(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialog pfd)
        {
        }

        public void OnShareViolation(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialog pfd, Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IShellItem psi, out NativeMethods.FDE_SHAREVIOLATION_RESPONSE pResponse)
        {
            pResponse = NativeMethods.FDE_SHAREVIOLATION_RESPONSE.FDESVR_DEFAULT;
        }

        public void OnTypeChange(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialog pfd)
        {
        }

        public void OnOverwrite(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialog pfd, Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IShellItem psi, out NativeMethods.FDE_OVERWRITE_RESPONSE pResponse)
        {
            pResponse = NativeMethods.FDE_OVERWRITE_RESPONSE.FDEOR_DEFAULT;
        }

        #endregion

        #region IFileDialogControlEvents Members

        public void OnItemSelected(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialogCustomize pfdc, int dwIDCtl, int dwIDItem)
        {
        }

        public void OnButtonClicked(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialogCustomize pfdc, int dwIDCtl)
        {
        }

        public void OnCheckButtonToggled(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialogCustomize pfdc, int dwIDCtl, bool bChecked)
        {
        }

        public void OnControlActivating(Sage.CRE.Core.UI.Wpf.Dialogs.Interop.IFileDialogCustomize pfdc, int dwIDCtl)
        {
        }

        #endregion


    }
}
