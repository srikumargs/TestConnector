using System;
using System.Runtime.InteropServices;

using Sage.Xml;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Reads and parses trace message data encoded by <see cref="Sage.Diagnostics.TraceMessageDataWriter"/>.
    /// </summary>
    /// <remarks>
    /// Should be used in conjunction with <see cref="Sage.Diagnostics.TraceMessageDataWriter"/>.
    /// </remarks>
    [ComVisible(false)]
    public class TraceMessageDataReader
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the TraceMessageDataReader class.
        /// </summary>
        /// <param name="messageData">A string representation of the encoded message data.</param>
        public TraceMessageDataReader(string messageData)
        {
            _rawMessageData = messageData;
        }
        #endregion

        #region Public properties
        /// <summary>
        /// The encoded trace message content.
        /// </summary>
        public string Message
        {
            get
            {
                if (null == _message || 0 == _message.Length)
                {
                    ParseRawMessageData();
                }
                return _message;
            }
        }
        #endregion

        #region Public members
        /// <summary>
        /// Determines whether the trace message data contains the specified named data.
        /// </summary>
        /// <param name="name">The name of the data to locate in the trace message data.</param>
        /// <returns>true if the trace message data contains an element with the specified name; otherwise, false.</returns>
        public bool ContainsData(string name)
        {
            if (null == _message || 0 == _message.Length)
            {
                ParseRawMessageData();
            }
            return _messageData.ContainsKey(name);
        }

        /// <summary>
        /// Gets the value associated with the specified name.
        /// </summary>
        /// <param name="name">The name of the data to locate in the trace message data.</param>
        /// <returns>A string representation of the data specified by the name parameter; otherwise sting.Empty</returns>
        public string GetData(string name)
        {
            string result = string.Empty;

            if (ContainsData(name))
            {
                result = (string)_messageData[name];
            }

            return result;
        }
        #endregion

        #region Private members
        private void ParseRawMessageData()
        {
            // keeping the XML tags very terse in order to minimize the overhead
            //   TM - TraceMessage
            //   M  - Message
            //   MD - MessageData
            //   D  - Data
            //   n  - name

            System.Xml.XmlDocument document = new System.Xml.XmlDocument();
            try
            {
                document.LoadXml(_rawMessageData);
                _message = XmlStringEscape.UnEscape(document.SelectSingleNode("//TM/M").InnerText);

                System.Xml.XmlNodeList nodeList = document.SelectNodes("//TM/MD/D");
                if (null != nodeList && 0 < nodeList.Count)
                {
                    foreach (System.Xml.XmlNode node in nodeList)
                    {
                        _messageData.Add(XmlStringEscape.UnEscape(node.Attributes["n"].Value), XmlStringEscape.UnEscape(node.InnerText));
                    }
                }
            }
            catch (System.Xml.XmlException /*e*/)
            {
                // Something is wrong with the message.  It may not even be valid XML. Just save the raw message as-is without parsing it.
                _message = _rawMessageData;

                // TODO:  assess if/how we should let the user know that this happened without being too annoying
            }
            catch (NullReferenceException /*e*/)
            {
                // Something is wrong with the message.  It may be valid XML, but may not be the schema we are expecting (i.e., it is XML
                // but wasn't written by the TraceMessageDataWriter). Just save the raw message as-is without parsing it.
                _message = _rawMessageData;

                // TODO:  assess if/how we should let the user know that this happened without being too annoying
            }
        }
        #endregion

        #region Private fields
        private string _rawMessageData;    // = null; (automatically initialized by runtime)
        private string _message;           // = null; (automatically initialized by runtime)
        private System.Collections.Hashtable _messageData = new System.Collections.Hashtable();
        #endregion
    }
}
