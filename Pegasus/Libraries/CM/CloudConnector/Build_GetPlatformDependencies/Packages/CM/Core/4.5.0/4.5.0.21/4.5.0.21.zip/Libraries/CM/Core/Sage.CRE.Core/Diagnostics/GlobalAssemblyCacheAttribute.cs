using System;

namespace Sage.Diagnostics
{
	/// <summary>
	/// Summary description for GlobalAssemblyCacheAttribute.
	/// </summary>
	[AttributeUsage(AttributeTargets.Assembly)]
	public class GlobalAssemblyCacheAttribute : System.Attribute
	{
        /// <summary>
        /// 
        /// </summary>
		public GlobalAssemblyCacheAttribute()
		{
		}
	}
}
