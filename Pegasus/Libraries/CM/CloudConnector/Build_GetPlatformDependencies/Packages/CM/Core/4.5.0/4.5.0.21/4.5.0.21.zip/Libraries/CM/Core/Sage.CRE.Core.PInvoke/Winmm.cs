using System;
using System.Collections.Generic;
using System.Text;

namespace Sage.PInvoke
{
    /// <summary>
    /// Defines Windows Multimedia P/Invoke API declarations.
    /// </summary>
    public class Winmm
    {
        /// <summary>
        /// Play a sound specified by the given filename, resource, or system event.
        /// </summary>
        /// <param name="pszSound">Specify the sound to play (max 255 characters). This value is used in combination of the flags to determine where to find the sound file.</param>
        /// <param name="hMod">The handle to the executable file that contains the resource to be loaded. This must be NULL unless SND_RESOURCE is specified in the flags.</param>
        /// <param name="fdwSound">The sound flags.</param>
        public static bool PlaySound(string pszSound, IntPtr hMod, SoundFlags fdwSound)
        {
            return SafeNativeMethods.PlaySound(pszSound, hMod, fdwSound);
        }
    }
}
