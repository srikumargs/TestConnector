#if DEBUG
using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;

namespace Sage.Diagnostics.NUnit
{
    /// <summary>
    /// Test
    /// </summary>
    [TestFixture]
    public class ExceptionMessageTests
    {
        static ExceptionMessageTests()
        {
            //Sage.Configuration.LibraryManager.InitializeLibraries(
            //    System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory,
            //        Sage.Configuration.LibraryManager.LibraryManifestFolderName ) );
        }


        /// <summary>SetUp</summary>
        [SetUp]
        [SuppressMessage( "Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "NUnit requires method be an instance method." )]
        public void SetUp()
        {
        }

        private String TestMessageString
        {
            get { return "an application exception"; }
        }

        private String TestMessageString2
        {
            get { return "an argument exception"; }
        }

        /// <summary>
        /// </summary>
        [Test]
        [SuppressMessage( "Microsoft.Performance", "CA1822:MarkMembersAsStatic" )]
        public void NoInnerException()
        {
            String msg = TestMessageString;

            ApplicationException ex = new ApplicationException( msg );
            string ret = ExceptionMessage.Create( ex );
            Assert.IsTrue( String.Compare( msg, ret, false, CultureInfo.InvariantCulture ) == 0 );
            Console.WriteLine( typeof(ExceptionMessageTests).Name );
            Console.WriteLine( ret );
        }

        /// <summary>
        /// </summary>
        [Test]
        [SuppressMessage( "Microsoft.Performance", "CA1822:MarkMembersAsStatic" )]
        public void WithInnerException()
        {
            String msg = TestMessageString;

            ApplicationException ex = new ApplicationException( msg );
            ApplicationException ex2 = new ApplicationException( msg, ex );

            String ret = ExceptionMessage.Create( ex2 );
            String expectedMsg = String.Format( CultureInfo.InvariantCulture, "{0}:{1}{0}", msg, Environment.NewLine );
            Assert.IsTrue( String.Compare( expectedMsg, ret, false, CultureInfo.InvariantCulture ) == 0 );
            Console.WriteLine( typeof( ExceptionMessageTests ).Name );
            Console.WriteLine( ret );
        }

        /// <summary>
        /// </summary>
        [Test]
        public void WithInnerExceptionCustomFormatting()
        {
            String msg = TestMessageString;

            ApplicationException ex = new ApplicationException( msg );
            ApplicationException ex2 = new ApplicationException( msg, ex );

            String separator = String.Format( "{0}---my neato separator---{0}", Environment.NewLine );
            String ret = ExceptionMessage.Create( ex2, "Exception message: {0}", separator );
            Console.WriteLine( typeof( ExceptionMessageTests ).Name );
            Console.WriteLine( ret );
        }
        /// <summary>
        /// </summary>
        [Test]
        [SuppressMessage( "Microsoft.Performance", "CA1822:MarkMembersAsStatic" )]
        public void TestEventLogger()
        {
            String msg = TestMessageString;
            String msg2 = TestMessageString2;

            ArgumentException ex = new ArgumentException(msg2);
            ApplicationException ex2 = new ApplicationException( msg, ex );

            EventLogger.LogException( ex2 );
        }


    }   // class
}   // namespace


#endif