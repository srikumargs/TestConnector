using System;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Sage.PInvoke
{
    /// <summary>
    /// Summary description for CShell32.
    /// </summary>
    public static class Shell32
    {
		/// <summary>Icon.</summary>
		public const uint SHGFI_ICON = 0x100;

		/// <summary>Large icon.</summary>
		public const uint SHGFI_LARGEICON = 0x0;

		/// <summary>Small icon.</summary>
		public const uint SHGFI_SMALLICON = 0x1;

        public static int ExtractIconEx([MarshalAs(UnmanagedType.LPTStr)]	string lpszFile, int nIconIndex,
           IntPtr[] phIconLarge, IntPtr[] phIconSmall, int nIcons)
        {
            return PInvoke.SafeNativeMethods.ExtractIconEx(lpszFile, nIconIndex,
                phIconLarge, phIconSmall, nIcons);
        }
        public static System.IntPtr ShellExecute(System.IntPtr hwnd, string lpOperation, string lpFile,
            string lpParameter, string lpDirectory, int nShowCmd)
        {
            return PInvoke.NativeMethods.ShellExecute(hwnd, lpOperation, lpFile, lpParameter, lpDirectory, nShowCmd);
        }

        public static IntPtr SHAppBarMessage(int message, ref APPBARDATA TaskbarInfo)
        {
            return PInvoke.NativeMethods.SHAppBarMessage(message, ref TaskbarInfo);
        }

        public static int FindExecutable(string fileAndPath, string dir, StringBuilder strExe)
        {
            return PInvoke.NativeMethods.FindExecutable(fileAndPath, dir, strExe);
        }

        public static IntPtr SHGetFileInfo(string pszPath, int dwFileAttributes, ref SHFILEINFO psfi, int cbFileInfo, uint uFlags)
        {
            return PInvoke.NativeMethods.SHGetFileInfo(pszPath, dwFileAttributes, ref psfi, cbFileInfo, uFlags);
        }

        public static System.IntPtr SHBrowseForFolder(ref BrowseInfo bi)
        {
            return PInvoke.NativeMethods.SHBrowseForFolder(ref bi);
        }

        [return: MarshalAs(UnmanagedType.Bool)]
        public static bool SHGetPathFromIDList(IntPtr pidl, [MarshalAs(UnmanagedType.LPTStr)] System.Text.StringBuilder pszPath)
        {
            return PInvoke.NativeMethods.SHGetPathFromIDList(pidl, pszPath);
        }

        public static int SHGetMalloc([MarshalAs(UnmanagedType.IUnknown)]out object shmalloc)
        {
            return PInvoke.NativeMethods.SHGetMalloc(out shmalloc);
        }
		
		public static int SHGetDesktopFolder(
			ref IShellFolder ppshf )
		{
			return PInvoke.NativeMethods.SHGetDesktopFolder( ref ppshf );
		}
    }
}
