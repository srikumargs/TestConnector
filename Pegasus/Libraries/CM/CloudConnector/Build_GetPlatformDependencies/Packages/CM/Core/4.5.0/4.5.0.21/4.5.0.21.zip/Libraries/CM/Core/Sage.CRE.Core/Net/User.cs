using System;

namespace Sage.Net
{
    /// <summary>
    /// Summary description for User.
    /// </summary>
    internal class User
      : NameBase
      , IUser
    {
        public User(string name)
            : base(name)
        {
        }

    }
}
