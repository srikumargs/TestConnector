#if DEBUG
using Microsoft.Win32;
using System;
using NUnit.Framework;
using Sage.Configuration.Internal;

namespace Sage.Configuration.Tests
{
	
    /// <summary>
    /// Unit tests for the Path Registrar
    /// </summary>
    [TestFixture]
    public class Test_PathRegistrar
    {

        // Name of a key to use for testing
        private const string _testKeyName = "TestKey";

        // Name of a second key to use for testing
        private const string _testKeyName2 = "TestKey2";

        // A path to use for testing
        private const string _testPath1 = @"C:\TestPath";

        // A second path to test with
        private const string _testPath2 = @"C:\TestPath\DeeperPath";

        /// <summary>
        /// Constructor
        /// </summary>
        public Test_PathRegistrar()
        {
			
        }

        /// <summary>
        /// SetUp for all test's
        /// </summary>
        [SetUp]       
        public void Init()
        {
            
        }

        /// <summary>
        /// Test registering and unregistering a path
        /// </summary>
        [Test]
        public void TestRegisteringUnRegisteringAPath()
        {
            // Make sure the key is not already in the Repository
            Assert.IsTrue(!PathRegistrarHelper.IsRegistered(_testKeyName), "The TestKey is already in the repository");
            
            // Register the test path
            PathRegistrarHelper.RegisterPath(_testKeyName, _testPath1);

            // Make sure the key is in the Repository
            Assert.IsTrue(PathRegistrarHelper.IsRegistered(_testKeyName), "The TestKey is not in the repository");

            // UnRegister the path
            PathRegistrarHelper.UnRegisterPath(_testKeyName);

            // The TestKey was not removed from the repository
            Assert.IsTrue(!PathRegistrarHelper.IsRegistered(_testKeyName), "The TestKey is already in the repository");
        }

        /// <summary>
        /// Test trying to register a path with a null key
        /// </summary>
        [Test]
        [ExpectedException( typeof(ArgumentNullException) )]
        public void Test_RegisteringAFolderWithANullKey()
        {
            PathRegistrarHelper.RegisterPath(null, _testPath1);
        }

        /// <summary>
        /// Test trying to register a path with an empty key
        /// </summary>
        [Test]
        [ExpectedException( typeof(ArgumentException) )]
        public void Test_RegisteringAFolderWithAnEmptyKey()
        {
            PathRegistrarHelper.RegisterPath(string.Empty, _testPath1);
        }

        /// <summary>
        /// Test trying to register a path with a null key
        /// </summary>
        [Test]
        [ExpectedException( typeof(ArgumentNullException) )]
        public void Test_RegisteringAFolderWithANullPath()
        {
            PathRegistrarHelper.RegisterPath(_testKeyName, null);
        }

        /// <summary>
        /// Test trying to register a path with an empty key
        /// </summary>
        [Test]
        [ExpectedException( typeof(ArgumentException) )]
        public void Test_RegisteringAFolderWithAnEmptyPath()
        {
            PathRegistrarHelper.RegisterPath(_testKeyName, string.Empty);
        }

        /// <summary>
        /// Test the Resolve URl method
        /// </summary>
        [Test]
        public void Test_ResolveUrl()
        {
            
            // Test a registered path 
            Assert.IsTrue(!PathRegistrarHelper.IsRegistered(_testKeyName), "The TestKey is already in the repository");
            PathRegistrarHelper.RegisterPath(_testKeyName, _testPath1);
            string resolvedPath = PathRegistrar.ResolveUrl( @"registeredpath://TestKey\MyFile.txt" ); 
            Assert.IsTrue( resolvedPath == string.Format( "{0}\\MyFile.txt", _testPath1 ), "The Resolved path is not correct" );
            PathRegistrarHelper.UnRegisterPath(_testKeyName);
            Assert.IsTrue(!PathRegistrarHelper.IsRegistered(_testKeyName), "The TestKey was not removed from the repository");
        
            //Test a special path
            resolvedPath = PathRegistrar.ResolveUrl( "specialpath://system.CommonApplicationData\\MyFile.txt" );
            string targetPath = string.Format( "{0}\\MyFile.txt", Environment.GetFolderPath( Environment.SpecialFolder.CommonApplicationData ) );
            Assert.IsTrue( resolvedPath == targetPath, "The resolved special path is not correct" );

            //Test a registry path
            resolvedPath = PathRegistrar.ResolveUrl( @"registrypath://registry.localmachine\Software\Timberline\General:Shared Directory" );
            Assert.IsTrue( resolvedPath == GetTimberlineSharedFolderFromTheRegistry(), "The resolved Registry path is not correct" );

            //Test a tsPath
            string tsPath = PathRegistrar.ResolveUrl(@"tspath://shared\myFile.txt");
            Assert.IsTrue(tsPath == string.Format("{0}\\myFile.txt", GetTimberlineSharedFolderFromTheRegistry()), "The resolved tspath is not correct.");
        }

        /// <summary>
        /// Test retrieving a registered path from a Url
        /// </summary>
        [Test]
        public void Test_RegisteredPathFromUrl()
        {

            Assert.IsTrue(!PathRegistrarHelper.IsRegistered(_testKeyName), "The TestKey is already in the repository");
            Assert.IsTrue(!PathRegistrarHelper.IsRegistered(_testKeyName2), "The TestKey 2 is already in the repository");

            PathRegistrarHelper.RegisterPath(_testKeyName, _testPath1);
            PathRegistrarHelper.RegisterPath(_testKeyName2, _testPath2);

            string registeredPath = PathRegistrar.RegisteredPathFromUrl( string.Format("{0}\\MyFile.txt", _testPath1 ) ); 
            Assert.IsTrue( registeredPath == "registeredpath://TestKey\\\\MyFile.txt", "The Registered path is not correct" );

            registeredPath = PathRegistrar.RegisteredPathFromUrl( string.Format("{0}\\MyFile.txt", _testPath2 ) ); 
            Assert.IsTrue( registeredPath == "registeredpath://TestKey2\\\\MyFile.txt", "The deeper Registered path is not correct" );

            PathRegistrarHelper.UnRegisterPath(_testKeyName);
            PathRegistrarHelper.UnRegisterPath(_testKeyName2);
            Assert.IsTrue(!PathRegistrarHelper.IsRegistered(_testKeyName), "The TestKey was not removed from the repository");
            Assert.IsTrue(!PathRegistrarHelper.IsRegistered(_testKeyName2), "The TestKey2 was not removed from the repository");

            string tsPath = PathRegistrar.RegisteredPathFromUrl(string.Format("{0}\\myFile.txt", GetTimberlineSharedFolderFromTheRegistry()));
            Assert.IsTrue(tsPath == "tsPath://shared\\myfile.txt", "the tspath is not correct.");
        }

        /// <summary>
        /// Retrieve the location of the Timberline shared folder from the Registry
        /// </summary>
        /// <returns>Path to the Timberline Shared folder</returns>
        private string GetTimberlineSharedFolderFromTheRegistry()
        {
            string retval = null;

            RegistryKey key = Registry.LocalMachine.OpenSubKey( @"Software\Timberline\General" );
            if( key != null )
            {
                retval = (string)key.GetValue( "Shared Directory" );
            }

            return retval;
        }
        
    }
}
#endif