using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Runtime.Remoting;
using System.Runtime.InteropServices;
using System.Globalization;

using Sage.Diagnostics;

namespace Sage.Remoting
{
    /// <summary>
    /// class which wraps a given xml definition for a remotable object
    /// </summary>
    [ComVisible(false)]
    public class RemotableObject : IDisposable
    {
        // the host id
        private string _hostId;

        // for uri/url persistence
        private IUrlWriter _urlWriter;

        // use to format urls/uri's
        private IFormatter _formatter;

        // url after IFormatter applied
        private string _formattedUrl;

        // the root node of the remotable object host def
        private XPathNavigator _remotableObjectHostNav;

        /// <summary>
        /// The node for a particular object instance
        /// </summary>
        protected XPathNavigator _objNav;

        /// <summary>
        /// The uri after formatting applied
        /// </summary>
        protected string _formattedUri;

        /// <summary>
        /// Whether this object should be lifetime managed by the lease-based object lifetime infrastructure.  When true, the object
        /// lifetime is not managed by the Remoting framework.  When false (default), the object lifetime is managed by the Remoting
        /// framework.
        /// </summary>
        private bool _manualLifetimeManagement; //= false; (automatically initialized by runtime)

        /// <summary>
        /// The object that was manually marshaled (if not using leasing)
        /// </summary>
        private MarshalByRefObject _manuallyMarshaledObject; //= null; (automatically initialized by runtime)

        /// <summary>
        /// initialize the cachjed data members
        /// </summary>
        /// <param name="objNav"></param>
        /// <param name="remotableObjectHostNav"></param>
        /// <param name="hostId"></param>
        /// <param name="urlWriter"></param>
        public RemotableObject(XPathNavigator objNav, XPathNavigator remotableObjectHostNav, string hostId, IUrlWriter urlWriter)
        {
            _objNav = objNav;
            _remotableObjectHostNav = remotableObjectHostNav;
            _hostId = hostId;
            _urlWriter = urlWriter;

            Initialize();
        }

        /// <summary>
        /// Standard IDisposable implementation
        /// </summary>
        public void Dispose()
        {
            Dispose(true);

            // This object will be cleaned up by the Dispose method.  Therefore, you should call GC.SupressFinalize to
            // take this object off the finalization queue and prevent finalization code for this object from executing
            // a second time.
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// C# destructor syntax for finalization code.  This destructor will run only if the Dispose method 
        /// does not get called.
        /// </summary>
        ~RemotableObject()
        {
            // Do not re-create Dispose clean-up code here.
            // Calling Dispose(false) is optimal in terms of readability and maintainability.

            Dispose(false);
        }

        /// <summary>
        /// Standard IDisposable implementation
        /// </summary>
        /// <param name="disposing">true if this object is being disposed; false if it is being finalized</param>
        private void Dispose(bool disposing)
        {
            lock (_syncRoot)
            {
                // Check to see if Dispose has already been called.
                if(!_disposed)
                {
                    // If disposing equals true, dispose all managed and unmanaged resources ... the
                    // method has been called directly (or indirectly) by user's code.
                    //
                    // If disposing equals false, then the method has been called by the runtime from
                    // inside the finalizer and so, no other managed objects should be referenced.  Only
                    // unmanaged resources can be disposed.
                    if(disposing)
                    {
                        // Dispose managed resources here.
                        if(_manuallyMarshaledObject != null)
                        {
                            if(_manuallyMarshaledObject is IDisposable)
                            {
                                (_manuallyMarshaledObject as IDisposable).Dispose();
                            }
                            _manuallyMarshaledObject = null;
                        }
                    }

                    // Clean up unmanaged resources here.
                }

                _disposed = true;
            }
        }

        /// <summary>
        /// Makes certain that this object instance hasn't already been disposed
        /// </summary>
        private void VerifyNotDisposed()
        {
            lock (_syncRoot)
            {
                if(_disposed)
                {
                    throw new ObjectDisposedException(_myTypeName);
                }
            }
        }

        private bool _disposed; //= false; (automatically initialized by runtime)

        /// <summary>
        /// Gets the URL.
        /// </summary>
        /// <value>The URL.</value>
        public string Url
        {
            get
            {
                VerifyNotDisposed();
                return _formattedUrl;
            }
        }

        /// <summary>
        /// Register the well-known type
        /// </summary>
        public virtual void Connect()
        {
            VerifyNotDisposed();

            string type = XmlNodeHelper.GetStringAttributeValue(_objNav.UnderlyingObject as XmlNode, "Type");
            string mode = XmlNodeHelper.GetStringAttributeValue(_objNav.UnderlyingObject as XmlNode, "Mode");
            XmlNodeHelper.GetOptionalBoolAttributeValue(_objNav.UnderlyingObject as XmlNode, "ManualLifetimeManagement", ref _manualLifetimeManagement);

            Type t = Type.GetType(type, false);
            if(t != null)
            {
                if(!_manualLifetimeManagement)
                {
                    RemotingConfiguration.RegisterWellKnownServiceType(t, _formattedUri,
                        (mode == "Singleton") ? WellKnownObjectMode.Singleton : WellKnownObjectMode.SingleCall);
                }
                else
                {
                    if(_manuallyMarshaledObject == null)
                    {
                        object manuallyCreatedObject = Activator.CreateInstance(t);

                        // Now check to see if the object implements IRemotableObjectPublisher.  If so,
                        // then the object is really a factory for the real object that should be published.
                        // If not, then just publish this object.
                        object objectToMarshal = manuallyCreatedObject;
                        if(objectToMarshal is IRemotableObjectPublisher)
                        {
                            objectToMarshal = (objectToMarshal as IRemotableObjectPublisher).GetObject(_hostId, _formattedUri);
                        }

                        ArgumentValidator.ValidateNonNullReference(objectToMarshal, "objectToMarshal", _myTypeName + ".Connect");
                        ArgumentValidator.ValidateIsSubclassOfType(objectToMarshal.GetType(), "objectToMarshal", _myTypeName + ".Connect", typeof(MarshalByRefObject));

                        Assertions.Assert((objectToMarshal as MarshalByRefObject).InitializeLifetimeService() == null, string.Format(CultureInfo.InvariantCulture, Strings.ManuallyMarshaledObjectIsExpectedToImplementLifetimeManagementFormat, _formattedUri));

                        _manuallyMarshaledObject = objectToMarshal as MarshalByRefObject;
                    }
                    RemotingServices.Marshal(_manuallyMarshaledObject, _formattedUri);
                }

                VerboseTrace.WriteLine(this, "Registered Wellknown Service Type={0}, uri={1}", t.FullName, _formattedUri);
            }
        }

        /// <summary>
        /// Nothing to do besides break down the channels
        /// </summary>
        public virtual void Disconnect()
        {
            VerifyNotDisposed();

            if(!_manualLifetimeManagement)
            {
                // nothing to do because the object's lifetime is being managed by the lease-based object lifetime infrastructure
            }
            else
            {
                if(_manuallyMarshaledObject != null)
                {
                    RemotingServices.Disconnect(_manuallyMarshaledObject);
                }
            }
        }

        /// <summary>
        /// Write the uri/url pair to the persistence store of choice
        /// </summary>
        public virtual void Publish()
        {
            VerifyNotDisposed();
            _urlWriter.SaveUrl(_formattedUri, _formattedUrl);
        }

        /// <summary>
        /// Remove the uri/url pair from the persistence store of choice.
        /// </summary>
        public virtual void UnPublish()
        {
            VerifyNotDisposed();
            _urlWriter.RemoveUrl(_formattedUri);
        }


        /// <summary>
        /// Helper to get the correct channel
        /// </summary>
        /// <param name="channelName"></param>
        /// <returns></returns>
        private XPathNavigator GetChannelNav(string channelName)
        {
            VerifyNotDisposed();

            XPathNavigator nav = null;
            //string channelExpr = string.Format(CHANNEL_QUERY, channelName);
            XPathNodeIterator iter = _remotableObjectHostNav.SelectDescendants("Channel", "", false);
            while(iter.MoveNext())
            {
                if(iter.Current.GetAttribute("Name", "") == channelName)
                {
                    nav = iter.Current;
                    break;
                }
            }
            return nav;
        }

        /// <summary>
        /// set up the object state for later operations
        /// </summary>
        private void Initialize()
        {
            VerifyNotDisposed();

            if(_objNav.GetAttribute("UseHostId", "") == "true")
            {
                _formatter = new StringInputIdFormatter(_hostId);
            }
            else
            {
                _formatter = new NullFormatter();
            }
            //
            // Create the formatted Uri
            //
            string objectUri = _objNav.GetAttribute("ObjectUri", "");
            _formattedUri = _formatter.Format(objectUri);
            //
            // Create the formatted Url
            //
            XPathNavigator channelNav = this.GetChannelNav(_objNav.GetAttribute("ChannelName", ""));
            if(channelNav != null)
            {
                string chanRef = channelNav.GetAttribute("Ref", "");
                string port = channelNav.GetAttribute("Port", "");
                string pipeName = channelNav.GetAttribute("Pipe", "");

                StringBuilder b = new StringBuilder();
                if(chanRef == "tcp" && port.Length > 0)
                {
                    b.AppendFormat(@"tcp://localhost:{0}/{1}", port, _formattedUri);
                }
                else if(chanRef == "pipe")
                {
                    pipeName = _formatter.Format(pipeName);
                    b.AppendFormat(@"pipe://{0}/{1}", pipeName, _formattedUri);
                }

                _formattedUrl = b.ToString();
            }
        }

        private static String _myTypeName = typeof(RemotableObject).FullName;
        private readonly Object _syncRoot = new Object();
    }
}
