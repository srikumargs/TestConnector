using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security;
using System.Threading;
using System.Text;

namespace Sage.Remoting
{
    /// <summary>
    /// This base class is used to contain the actual handle and to
    /// implement the common dispose pattern to close the handle
    /// </summary>
    [ComVisible(false)]
    public class MailSlotBase : IDisposable
    {
        /// <summary>
        /// Only usable from derived
        /// </summary>
        protected MailSlotBase() {}
        
        /// <summary>
        /// Used by I/O api's
        /// </summary>
        static protected readonly IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);

        /// <summary>
        /// PInvoke for closing a handle
        /// </summary>
        [DllImport("kernel32.dll", SetLastError=true), SuppressUnmanagedCodeSecurityAttribute]
        protected static extern bool CloseHandle(IntPtr hSlot);

        /// <summary>
        /// The underlying mailsot server handle or client file handle
        /// </summary>
        protected IntPtr _handle;

        /// <summary>
        /// Close the handle
        /// </summary>
        public void Dispose()
        {
            if (_handle != IntPtr.Zero && _handle != INVALID_HANDLE_VALUE)
            {
                CloseHandle(_handle);
                _handle = IntPtr.Zero;
            }
        }
        
        /// <summary>
        /// Common error checking method
        /// </summary>
        protected void CheckValidHandle(string msg)
        {
            if (_handle == INVALID_HANDLE_VALUE)
            {
                throw new InvalidOperationException(msg);
            }
        }
        /// <summary>
        /// The OVERLAPPED structure contains information used in asynchronous I/O.
        /// </summary>
        [StructLayout( LayoutKind.Sequential )]
            protected internal struct OVERLAPPED 
        {
            internal UIntPtr internalLow;
            internal UIntPtr internalHigh;
            internal UInt32 offset;
            internal UInt32 offsetHigh;
            internal IntPtr hEvent;
        }
    }
    
    /// <summary>
    /// A mailslot server is a managed wrapper around the server side
    /// of the mailslot api.  
    /// </summary>
    [ComVisible(false)]
    public class MailSlotServer : MailSlotBase
    {
        static readonly uint MAILSLOT_WAIT_FOREVER  = unchecked ((uint) -1); 
        static readonly uint MAILSLOT_NO_MESSAGE    = unchecked ((uint) -1); 

        [DllImport("kernel32.dll", SetLastError=true), SuppressUnmanagedCodeSecurityAttribute]
        static extern IntPtr CreateMailslot(string name, 
            uint maxMsgSize, 
            uint readTimeout, 
            IntPtr securityAttrs);

        [DllImport("kernel32.dll", SetLastError=true), SuppressUnmanagedCodeSecurityAttribute]
        static extern bool GetMailslotInfo(IntPtr hSlot, 
            IntPtr maxMsgSize, 
            ref uint nextSize, 
            ref uint msgCount, 
            IntPtr readTimeout);

        [DllImport("kernel32.dll", SetLastError=true), SuppressUnmanagedCodeSecurityAttribute]
        static extern bool ReadFile(IntPtr hSlot, 
            [Out] byte[] lpBuffer, 
            uint numBytesToRead, 
            IntPtr lpNumBytesRead, 
            [In] ref OVERLAPPED lpOverlapped);


        /// <summary>
        /// Create a mailslot - just pass in the name you want -
        /// we create the approriate format for the name. 
        /// </summary>
        /// <param name="name"></param>
        public void CreateMailslot(string name)
        {
            string mslotName = string.Format(@"\\.\mailslot\{0}", name);

            //_handle = CreateMailslot(mslotName, 0, MAILSLOT_WAIT_FOREVER, IntPtr.Zero);
            _handle = CreateMailslot(mslotName, 0, MAILSLOT_WAIT_FOREVER, SecurityAttributesBuilder.NullDacl);

            CheckValidHandle(Strings.CreateMailslotApiFailure);
        }

        
        /// <summary>
        /// Has a client written to the slot?
        /// </summary>
        /// <param name="nextMsgSize"></param>
        /// <param name="msgCount"></param>
        /// <returns></returns>
        public bool IsMessagePending(out int nextMsgSize, out int msgCount)
        {
            CheckValidHandle(Strings.MailslotHandleIsBadInIsMessagePending);
            nextMsgSize = msgCount = 0;

            uint next = 0, count = 0;
            if (!GetMailslotInfo(_handle, IntPtr.Zero, ref next, ref count, IntPtr.Zero))
            {
                nextMsgSize = (int) MAILSLOT_NO_MESSAGE;
            }
            else
            {
                nextMsgSize = (int) next;
                msgCount    = (int) count;
            }
            return next != MAILSLOT_NO_MESSAGE;
        }

        /// <summary>
        /// Get the pending message
        /// </summary>
        /// <param name="nextMsgSize"></param>
        /// <returns></returns>
        public string GetMessage(int nextMsgSize)
        {
            CheckValidHandle(Strings.MailslotHandleIsBadInGetMessage);
            IntPtr bytesRead = new IntPtr(0);
            OVERLAPPED ov = new OVERLAPPED();
            string msg = string.Empty;
            byte[] buf = new byte[nextMsgSize];

            if (ReadFile(_handle, buf, (uint) nextMsgSize, bytesRead, ref ov) == true)
            {
                msg = Encoding.ASCII.GetString(buf, 0, nextMsgSize);
            }
            return msg;
        }
    }

    
    /// <summary>
    /// The mailslot client
    /// </summary>
    [ComVisible(false)]
    public class MailSlotClient : MailSlotBase
    {
        static readonly uint GENERIC_READ  = 0x80000000;
        static readonly uint GENERIC_WRITE = 0x40000000;

        static readonly uint FILE_SHARE_READ  = 0x00000001;
        static readonly uint FILE_SHARE_WRITE = 0x00000002;

        static readonly uint OPEN_EXISTING = 3;

        static readonly uint FILE_ATTRIBUTE_NORMAL = 0x00000080;


        [DllImport("kernel32.dll", SetLastError=true), SuppressUnmanagedCodeSecurityAttribute]
        static extern IntPtr CreateFile(string fname, 
            uint desiredAccess, 
            uint shareMode, 
            IntPtr securityAttrs, 
            uint creationDisposition, 
            uint flagsAndAttrs, 
            IntPtr hTemplate);

        [DllImport("kernel32.dll", SetLastError=true), SuppressUnmanagedCodeSecurityAttribute]
        static extern bool WriteFile(IntPtr hFile,
            byte[] lpBuffer,
            uint numBytesToWrite,
            out int numBytesWritten,
            [In] ref OVERLAPPED lpOverlapped);


        /// <summary>
        /// Create the file handle for the mailslot
        /// </summary>
        /// <param name="name"></param>
        public bool CreateLocal(string name)
        {
            string mslotName = string.Format(@"\\.\mailslot\{0}", name);
            _handle = CreateFile(mslotName,
                GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                //IntPtr.Zero,
                SecurityAttributesBuilder.NullDacl,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                IntPtr.Zero);

            return (_handle != INVALID_HANDLE_VALUE);
        }

        /// <summary>
        /// Create the file handle for the remote mailslot
        /// </summary>
        /// <param name="server"></param>
        /// <param name="name"></param>
        public bool CreateRemote(string server, string name)
        {
            string mslotName = string.Format(@"\\(0)\mailslot\{1}", server, name);
            
            _handle = CreateFile(mslotName,
                GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                //IntPtr.Zero,
                SecurityAttributesBuilder.NullDacl,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                IntPtr.Zero);

            return (_handle != INVALID_HANDLE_VALUE);
        }

        /// <summary>
        /// Create the file handle for the remote mailslot
        /// </summary>
        /// <param name="name"></param>
        public bool CreateBroadcast(string name)
        {
            string mslotName = string.Format(@"\\*\mailslot\{0}", name);
            
            _handle = CreateFile(mslotName,
                GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                //IntPtr.Zero,
                SecurityAttributesBuilder.NullDacl,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                IntPtr.Zero);

            return (_handle != INVALID_HANDLE_VALUE);
        }
        

        /// <summary>
        /// write a string message to the slot
        /// </summary>
        /// <param name="msg"></param>
        public bool WriteSlot(string msg)
        {
            CheckValidHandle(Strings.CreateFileFailedForMailslotClient);
            
            OVERLAPPED ov = new OVERLAPPED();

            int bytesWritten;
            char[] cArray = msg.ToCharArray();
            byte[] btArray = new byte[cArray.Length];
            for (int i = 0; i < cArray.Length; i++)
            {
                btArray[i] = Convert.ToByte(cArray[i]);
            }
            return WriteFile(_handle, btArray, (uint)btArray.Length, out bytesWritten, ref ov);
        }
    }
}
