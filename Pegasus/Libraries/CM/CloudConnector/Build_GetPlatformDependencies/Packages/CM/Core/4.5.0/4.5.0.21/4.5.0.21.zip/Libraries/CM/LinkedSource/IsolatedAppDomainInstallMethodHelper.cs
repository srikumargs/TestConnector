using System;
using System.Collections;
using System.Collections.Specialized;
using System.Reflection;
using System.IO;
using System.Configuration.Install;
using System.Text;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;

// This source file resides in the "LinkedSource" source code folder in order to prevent the introduction
// of a new dependency on a custom assembly which may not be present at install time.
//
// Requires:
//  - %SAGE_SANDBOX%\Libraries\Sage\CRE\LinkedSourceCodeFiles\IsolatedAppDomainHelper.cs
namespace Sage.CRE.LinkedSource
{
    /// <summary>
    /// A static helper class that can be used to facilitate the calling of custom installer code
    /// within an isolated AppDomain.
    /// </summary>
    internal static class IsolatedAppDomainInstallMethodHelper
    {
        #region Public types
        /// <summary>
        /// A delegate for one of the Installer methods:  Install, Commit, Rollback, Uninstall
        /// </summary>
        public delegate void InstallerMethodCallback(IDictionary state);
        #endregion

        #region Public methods
        /// <summary>
        /// Creates a subordinate AppDomain, creates an instance of the installerImplType in the new AppDomain, and
        /// invokes the "before" and/or "after" methods on the installerImplType in the new AppDomain.  Also calls
        /// the supplied InstallerMethod in the context of the main AppDomain between the "before" and "after" calls.
        /// </summary>
        /// <param name="installContext">The InstallContext provided by the framework to the base Installer class.</param>
        /// <param name="state">The state IDictionary passed by the framework to and Installer method.</param>
        /// <param name="installerImplType">The type of the class that implements.</param>
        /// <param name="beforeMethodName">The name of the public instance member method to invoke on an instance of the installerImplType prior to calling the Installer method.</param>
        /// <param name="afterMethodName">The name of the public instance member method to invoke on an instance of the installerImplType after calling the Installer method.</param>
        /// <param name="installerMethodCallback">A delegate for the real Installer method that should be called.</param>
        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String)")]
        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentException.#ctor(System.String,System.String)")]
        [SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.ArgumentNullException.#ctor(System.String)")]
        public static void ExecuteInstallerMethod(InstallContext installContext, IDictionary state, Type installerImplType, string beforeMethodName, string afterMethodName, InstallerMethodCallback installerMethodCallback)
        {
            if(installContext == null)
            {
                throw new ArgumentNullException("installContext");
            }

            // Don't check "state" for null.  It shouldn't be null, but can be if the user does something invalid like try
            // to uninstall something that is not installed.  But in scenarios like that, the base Installer.Uninstall() 
            // provides a more helpful error message than we can.

            if(installerImplType == null)
            {
                throw new ArgumentNullException("installerImplType");
            }

            if(!installerImplType.IsSubclassOf(typeof(MarshalByRefObject)))
            {
                throw new ArgumentException("Must be a subclass of MarshalByRefObject since it will be invoked across AppDomain boundaries", "installerImplType");
            }

            if((beforeMethodName == null || beforeMethodName.Length == 0) &&
                (afterMethodName == null || afterMethodName.Length == 0))
            {
                throw new ArgumentException("At least one of 'beforeMethodName' or 'afterMethodName' must be specified.");
            }

            if(installerMethodCallback == null)
            {
                throw new ArgumentNullException("installerMethod");
            }


            // create the AppDomain
            IsolatedAppDomainHelper appDomainHelper;
            using(appDomainHelper = new IsolatedAppDomainHelper("AppDomainIsolationHelper.ExecuteInstallerMethod"))
            {
                object installerImpl = appDomainHelper.CreateInstanceAndUnwrap(installerImplType);


                // InstallContext.Parameters is a StringDictionary ... which is not Serializable.  However, ListDictionary is Serializable.
                // Copy all entries into a ListDictionary.  The parameters to method calls made across AppDomains must be serializable.
                ListDictionary parameterList = new ListDictionary();
                foreach(DictionaryEntry dictionaryEntry in installContext.Parameters)
                {
                    parameterList.Add(dictionaryEntry.Key, dictionaryEntry.Value);
                }


                // Create a InstallContextLogWriter.  The InstallContext implements a LogMessage method that we would like to use
                // but we cannot pass the InstallContext directly to another AppDomain because it is not serializable.  The
                // InstallContextLogWriter gets around this limitation by implementing an appropriate "well-known" interface
                // (i.e., System.IO.TextWriter) that is a MarshalByRefObject.
                InstallContextLogWriter installContextLogWriter = new InstallContextLogWriter(installContext, CultureInfo.InvariantCulture);


                // invoke the before method, the Installer method, and the after method
                if(beforeMethodName != null && beforeMethodName.Length > 0)
                {
                    // invoke the "before" method in the created AppDomain
                    appDomainHelper.InvokeMethod(installerImpl, installerImplType, beforeMethodName, installContextLogWriter, parameterList, state);
                }

                // invoke the real Installer method (this happens in the main AppDomain)
                installerMethodCallback(state);

                if(afterMethodName != null && afterMethodName.Length > 0)
                {
                    appDomainHelper.InvokeMethod(installerImpl, installerImplType, afterMethodName, installContextLogWriter, parameterList, state);
                }


                // Copy entries from the local ListDictionary back to the InstallContext.Parameters StringDictionary (in case they were changed).
                foreach(DictionaryEntry dictionaryEntry in parameterList)
                {
                    // invoke the "after" method in the created AppDomain
                    installContext.Parameters[(string) dictionaryEntry.Key] = (string) dictionaryEntry.Value;
                }
            }
        }
        #endregion

        #region Private types
        /// <summary>
        /// A TextWriter that reimplements Write to perform an InstallContext.LogMessage
        /// </summary>
        /// <remarks>
        /// There are two important design elements to this class:
        ///     1) it is inherited from a MarshalByRefObject so it can be marshalled across AppDomain boundaries
        ///     2) it implements a standard interface (i.e., TextWriter) which is NOT defined in this assembly
        /// </remarks>
        private sealed class InstallContextLogWriter : TextWriter
        {
            #region Constructors
            /// <summary>
            /// Creates a new instance of the InstallContextLogWriter class.
            /// </summary>
            public InstallContextLogWriter(InstallContext installContext, IFormatProvider formatProvider)
                : base(formatProvider)
            {
                _installContext = installContext;
            }
            #endregion

            #region Public properties
            /// <summary>
            /// Returns the Encoding in which the output is written.
            /// </summary>
            public override Encoding Encoding
            {
                get
                {
                    return Encoding.Default;
                }
            }
            #endregion

            #region Public methods
            /// <summary>
            /// Writes a character to the text stream.
            /// </summary>
            /// <param name="value">The character to write to the text stream. </param>
            /// <remarks>
            /// Overriding this method allows us to change the behavior of all TextWriter Write*() overloads
            /// </remarks>
            public override void Write(char value)
            {
                if(value == '\n')
                {
                    _installContext.LogMessage(_line.ToString());
                    _line = new StringBuilder();
                }
                else
                {
                    if (value != '\r')
                    {
                        _line.Append(value);
                    }
                }
            }
            #endregion

            #region Private fields
            private InstallContext _installContext; //= null; (automatically initialized by runtime)
            private StringBuilder _line = new StringBuilder();
            #endregion
        }
        #endregion
    }
}