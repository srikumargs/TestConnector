/*=====================================================================

  File:        PipeServerChannel.cs

=====================================================================*/

using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Diagnostics;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Channels;
using System.Runtime.InteropServices;
using System.Threading;

using Sage.Diagnostics;
using Sage.CRE.LinkedSource;

namespace Sage.Remoting
{
    internal sealed class PipeServerChannel : IChannelReceiver
    {
        private const String _channelScheme = "pipe";
        private const int _defaultChannelPriority = 1;
        private const String _defaultMachineName = ".";

        private int _channelPriority;
        private String _channelName;

        private String _pipeName;
        private String _machineName;
        private Thread _listener;
        private AutoResetEvent _serverMainThreadInitializedEvent;
        private AutoResetEvent _pipeCreatedEvent;
        private ManualResetEvent _listenerMainThreadReadyForConnectionsEvent;
        private ManualResetEvent _stopListeningEvent;

        private IntPtr _pipeSecurityDescriptor = IntPtr.Zero;

        private IServerChannelSinkProvider _serverSinkProvider = null; // server sink chain provider
        private PipeServerTransportSink _transportSink;

        private PipeConnection _pipeConnection;
        private ChannelDataStore _data;
        private Version _clrVersion;

        // Internal accessors:
        internal String PipeName
        {
            get
            {
                return (_pipeName);
            }
        }

        // Internal mutators
        internal String MachineName
        {
            set
            {
                _machineName = value;
            }
        }

        public PipeServerChannel(String pipeName)
        {
            InitDefaults();
            _pipeName = pipeName;
            InitProviders(null);
            VerboseTrace.WriteLine(this, "_channelName={0}, _channelPriority={1}, _pipeName={2}, _pipeSecurityDescriptor={3}, _machineName={4}", _channelName, _channelPriority, _pipeName, _pipeSecurityDescriptor, _machineName);
        }

        public PipeServerChannel(String machineName, String pipeName)
        {
            InitDefaults();
            MachineName = machineName;
            _pipeName = pipeName;
            InitProviders(null);
            VerboseTrace.WriteLine(this, "_channelName={0}, _channelPriority={1}, _pipeName={2}, _pipeSecurityDescriptor={3}, _machineName={4}", _channelName, _channelPriority, _pipeName, _pipeSecurityDescriptor, _machineName);
        }


        // CTOR used via the configuration file
        public PipeServerChannel(IDictionary properties,
            IServerChannelSinkProvider serverProviderChain)
        {
            InitDefaults();
            InitProperties(properties);
            InitProviders(serverProviderChain);
            VerboseTrace.WriteLine(this, "_channelName={0}, _channelPriority={1}, _pipeName={2}, _pipeSecurityDescriptor={3}, _machineName={4}", _channelName, _channelPriority, _pipeName, _pipeSecurityDescriptor, _machineName);
        }

        internal void InitDefaults()
        {
            _clrVersion = AssemblyVersionInfo.ClrVersion;
            _channelPriority = _defaultChannelPriority;
            _channelName = Guid.NewGuid().ToString();
            _machineName = _defaultMachineName;
            _pipeCreatedEvent = new AutoResetEvent(false);
            _stopListeningEvent = new ManualResetEvent(false);
        }

        internal void InitProperties(IDictionary properties)
        {

            if(properties != null)
            {
                foreach(DictionaryEntry entry in properties)
                {
                    switch((String) entry.Key)
                    {
                        case "name":
                            _channelName = (String) entry.Value;
                            break;

                        case "priority":
                            _channelPriority = Convert.ToInt32(entry.Value);
                            break;

                        case "pipe":
                            _pipeName = (String) entry.Value;

                            if(String.Compare(_pipeName, "Auto", true) == 0)
                            {
                                _pipeName = Guid.NewGuid().ToString();
                            }
                            break;

                        case "securityDescriptor":
                            _pipeSecurityDescriptor = (IntPtr) entry.Value;
                            break;

                        case "machine":

                            // If the machine name specified is our machine name, then use the domain-qualified
                            // machine name instead.  This helps assure that clients on different machine
                            // domains can still connect to our server pipe.
                            String machineName = (string)entry.Value;
                            if(!PipeConnection.IsRemoteMachine(machineName))
                            {
                                machineName = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).HostName;
                            }

                            VerboseTrace.WriteLine(this, "MachineName={0}", machineName);
                            MachineName = machineName;
                            break;
                    }
                }
            }
        }

        internal void InitProviders(IServerChannelSinkProvider serverProviderChain)
        {
            _listener = null;
            _serverMainThreadInitializedEvent = new AutoResetEvent(false);
            _listenerMainThreadReadyForConnectionsEvent = new ManualResetEvent(false);

            _data = new ChannelDataStore(null);
            _data.ChannelUris = new String[1];
            _data.ChannelUris[0] = string.Format("{0}://{1}/{2}/dummyplaceholdername.rem", _channelScheme, _machineName, _pipeName);

            VerboseTrace.WriteLine(this, "*** Channel Uris: " + _data.ChannelUris[0]);
            _serverSinkProvider = serverProviderChain;

            // Create the default sink chain if one was not passed in
            if(_serverSinkProvider == null)
            {
                _serverSinkProvider = CreateDefaultServerProviderChain();
            }

            // Collect the rest of the channel data:
            IServerChannelSinkProvider provider = _serverSinkProvider;
            while(provider != null)
            {
                provider.GetChannelData(_data);
                provider = provider.Next;
            }

            IServerChannelSink next = ChannelServices.CreateServerChannelSinkChain(_serverSinkProvider, this);
            _transportSink = new PipeServerTransportSink(next);

            StartListening(null);
        }

        private IServerChannelSinkProvider CreateDefaultServerProviderChain()
        {
            BinaryServerFormatterSinkProvider formatterProvider;
            if(_clrVersion > AssemblyVersionInfo.ClrOneDotZero || (_clrVersion == AssemblyVersionInfo.ClrOneDotZero && AssemblyVersionInfo.ClrServicePack >= ServicePack.SP3))
            {
                //VerboseTrace.WriteLine(this, "*** greater than 1.0");
                //VerboseTrace.WriteLine(this, "*** {0}.{1}.{2}.{3}", _clrVersion.Major, _clrVersion.Minor, _clrVersion.Revision, _clrVersion.Build);
                IDictionary props = new Hashtable();
                props["typeFilterLevel"] = "Full";
                formatterProvider = new BinaryServerFormatterSinkProvider(props, null);
            }
            else
            {
                //VerboseTrace.WriteLine(this, "*** equal to 1.0");
                //VerboseTrace.WriteLine(this, "*** {0}.{1}.{2}.{3}", _clrVersion.Major, _clrVersion.Minor, _clrVersion.Revision, _clrVersion.Build);
                formatterProvider = new BinaryServerFormatterSinkProvider();
            }
            return formatterProvider;
        } // CreateDefaultServerProviderChain

        #region IChannel
        public String ChannelName
        {
            get
            {
                return _channelName;
            }
        }

        public int ChannelPriority
        {
            get
            {
                return 1;
            }
        }

        public String Parse(String url, out string uri)
        {
            string machineName;
            string pipeName = PipeConnection.Parse(url, out machineName, out uri);
            uri = PipeConnection.BuildObjectUri(machineName, uri);
            VerboseTrace.WriteLine(this, "Channel Uris: " + _data.ChannelUris[0]);

            VerboseTrace.WriteLine(this, "*** ServerChannel Parse: pipeName={0}, machineName={1}, objUri={2}", pipeName, machineName, uri);

            return pipeName;
        }
        #endregion

        #region IChannelReceiver
        public String[] GetUrlsForUri(String objuri)
        {
            VerboseTrace.WriteLine(null, "GetUrlsForUri: Looking up URL for uri = " + objuri);
            String[] arr = new String[1];

            if(!objuri.StartsWith("/"))
                objuri = "/" + objuri;

            if(_machineName == ".")
            {
                arr[0] = _channelScheme + "://" + _pipeName + objuri;
            }
            else
            {
                arr[0] = string.Format("{0}://{1}/{2}", _channelScheme, _machineName, _pipeName);
            }
            VerboseTrace.WriteLine(this, "*** ServerChannel GetUrlsForUri: {0}", arr[0]);

            return (arr);
        }

        public void StartListening(Object data)
        {
            VerboseTrace.WriteLine(this, "MT: Starting to listen...");

            _listener = new Thread(new ThreadStart(this.ListenerMain));
            _listener.Name = "NPipeListener";
            _listener.IsBackground = true;
            _listener.Start();
            _listenerMainThreadReadyForConnectionsEvent.WaitOne();
        }

        public void StopListening(Object data)
        {
            if(_listener != null)
            {
                VerboseTrace.WriteLine(this, "MT: Stop the listening thread...");
                _pipeCreatedEvent.WaitOne();
                _stopListeningEvent.Set();
#if(BLOCKING)
                _pipeConnection.Connect();
                _listener.Abort();
#endif
                _listener.Join();
                _listener = null;
            }
        }

        public Object ChannelData
        {
            get
            {
                VerboseTrace.WriteLine(null, "ChannelData");
                // Return a blob that can be use to reconnect:
                return (_data);
            }
        }
        #endregion

        private void ListenerMain()
        {
            VerboseTrace.WriteLine(this, "=> ListenerMain (thread:  {0})", System.Threading.Thread.CurrentThread.ManagedThreadId);

            try
            {
                while(true)
                {
                    VerboseTrace.WriteLine(this, "LT: In Listener....");
                    _pipeConnection = new PipeConnection(".", _pipeName, true, _pipeSecurityDescriptor);
                    _pipeCreatedEvent.Set();

                    _listenerMainThreadReadyForConnectionsEvent.Set();

                    //TODO switch to use completion ports

                    // Wait for a client to connect
                    bool connected = _pipeConnection.WaitForConnect(_stopListeningEvent);
                    if(_stopListeningEvent.WaitOne(0, false))
                    {
                        VerboseTrace.WriteLine(this, "_stopListeningEvent signalled in ListenerMain().  Exiting.");
                        break;
                    }

                    if(!connected)
                    {
                        throw new PipeIOException("Could not connect to the pipe - os returned " + Marshal.GetLastWin32Error());
                    }

                    VerboseTrace.WriteLine(this, "starting the server thread...");
                    ThreadPool.QueueUserWorkItem(new WaitCallback(this.ServerMain));

                    _serverMainThreadInitializedEvent.WaitOne();
                }
            }
            catch(Exception /*e*/)
            {
                //e=e;
            }
            finally
            {
                if(null != _pipeConnection)
                {
                    _pipeConnection.Dispose();
                    _pipeConnection = null;
                }
            }

            VerboseTrace.WriteLine(this, "<= ListenerMain (thread:  {0})", System.Threading.Thread.CurrentThread.ManagedThreadId);
        }

        private void ServerMain(object o)
        {
            VerboseTrace.WriteLine(this, "=> ServerMain (thread:  {0})", System.Threading.Thread.CurrentThread.ManagedThreadId);

            VerboseTrace.WriteLine(this, "AppDomain Friendly Name: " + AppDomain.CurrentDomain.FriendlyName);
            PipeConnection pipe = _pipeConnection;
            _pipeConnection = null;

            // Signal the ListenerMain thread that it is now ok to start waiting again... (w/ new event and endpoint)
            _serverMainThreadInitializedEvent.Set();

            try
            {
                //TODO close the connection on a timeout 
                //TODO if no activity for Nnnn milliseconds

                while(true)
                {
                    VerboseTrace.WriteLine(null, "Before BeginReadMessage in ServerMain");
                    pipe.BeginReadMessage(_stopListeningEvent);
                    if(_stopListeningEvent.WaitOne(0, false))
                    {
                        VerboseTrace.WriteLine(this, "_stopListeningEvent signalled in ServerMain().  Exiting.");
                        break;
                    }
                    VerboseTrace.WriteLine(null, "After BeginReadMessage in ServerMain");
                    ITransportHeaders requestHeaders = pipe.ReadHeaders();

                    // For 1.1 problems with the "Server encountered an
                    // internal error...." message.
                    if(_clrVersion > AssemblyVersionInfo.ClrOneDotZero)
                    {
                        requestHeaders["__CustomErrorsEnabled"] = false;
                    }
                    VerboseTrace.WriteLine(null, "Before ReadStream");
                    Stream requestStream = pipe.ReadStream();
                    pipe.EndReadMessage();
                    VerboseTrace.WriteLine(null, "After EndReadMessage");

                    VerboseTrace.WriteLine(this, "ST:  End Read");

                    requestStream = PreProcess(requestStream);

                    ServerChannelSinkStack stack = new ServerChannelSinkStack();
                    stack.Push(_transportSink, null);

                    IMessage responseMsg;
                    ITransportHeaders responseHeaders;
                    Stream responseStream;

                    ServerProcessing processing = _transportSink.NextChannelSink.ProcessMessage(
                        stack,
                        null,
                        requestHeaders,
                        requestStream,
                        out responseMsg,
                        out responseHeaders,
                        out responseStream);

                    responseStream = PostProcess(responseStream);

                    // handle response
                    switch(processing)
                    {
                        case ServerProcessing.Complete:
                            // Send the response. Call completed synchronously.
                            stack.Pop(_transportSink);
                            WriteClientResponse(pipe, responseHeaders, responseStream);
                            break;

                        case ServerProcessing.OneWay:
                            break;

                        case ServerProcessing.Async:
                            stack.StoreAndDispatch(_transportSink, null);
                            break;
                    }
                }
            }
            catch(Exception e)
            {
                VerboseTrace.WriteLine(this, "Terminating client connection: " + e.Message);
            }
            finally
            {
                pipe.Dispose();
                pipe = null;
                VerboseTrace.WriteLine(this, "<= ServerMain (thread:  {0})", System.Threading.Thread.CurrentThread.ManagedThreadId);
            }
        }

        private void WriteClientResponse(PipeConnection pipe,
            ITransportHeaders headers,
            Stream responseStream)
        {
            String uri;
            Object oUri = headers[CommonTransportKeys.RequestUri];
            if(oUri != null)
            {
                uri = oUri.ToString();
            }
            else
            {
                uri = "";
            }

            VerboseTrace.WriteLine(null, "Before BeginWriteMessage");
            pipe.BeginWriteMessage();
            VerboseTrace.WriteLine(null, "Before WriteHeaders");
            pipe.WriteHeaders(uri, headers);
            VerboseTrace.WriteLine(null, "Before Write on Response Stream");
            pipe.Write(responseStream);
            VerboseTrace.WriteLine(null, "Before EndWriteMessage");
            pipe.EndWriteMessage(_stopListeningEvent);
            if(_stopListeningEvent.WaitOne(0, false))
            {
                VerboseTrace.WriteLine(this, "_stopListeningEvent signalled in WriteClientResponse().  Exiting.");
                return;
            }
            VerboseTrace.WriteLine(null, "After EndWriteMessage");
        }

        private Stream PreProcess(Stream stream)
        {
            return Cryptography.DecryptStream(stream, CryptoAlgorithm.DES, CryptoConstants.Key, CryptoConstants.IV);
        }

        private Stream PostProcess(Stream stream)
        {
            return Cryptography.EncryptStream(stream, CryptoAlgorithm.DES, CryptoConstants.Key, CryptoConstants.IV);
        }

        public void Dispose()
        {
            StopListening(null);

            if(_pipeConnection != null)
            {
                _pipeConnection.Dispose();
                _pipeConnection = null;
            }

            //TODO: Cancel listeners.
        }
    }

    internal sealed class PipeServerTransportSink : IServerChannelSink
    {
        private IServerChannelSink _nextSink;

        public PipeServerTransportSink(IServerChannelSink nextSink)
        {
            _nextSink = nextSink;
        }

        public ServerProcessing ProcessMessage(IServerChannelSinkStack sinkStack,
            IMessage requestMsg,
            ITransportHeaders requestHeaders,
            Stream requestStream,
            out IMessage msg,
            out ITransportHeaders responseHeaders,
            out Stream responseStream)
        {
            // NOTE: This doesn't have to be implemented because the server transport
            //   sink is always first.
            throw new NotSupportedException();
        }

        public void AsyncProcessResponse(IServerResponseChannelSinkStack sinkStack, Object state,
            IMessage msg, ITransportHeaders headers, Stream stream)
        {
            throw new NotSupportedException();
        }

        public Stream GetResponseStream(IServerResponseChannelSinkStack sinkStack, Object state,
            IMessage msg, ITransportHeaders headers)
        {
            // We always want a stream to read from.
            return null;
        }

        public IServerChannelSink NextChannelSink
        {
            get
            {
                return _nextSink;
            }
        }

        public IDictionary Properties
        {
            get
            {
                return null;
            }
        }
    }
}