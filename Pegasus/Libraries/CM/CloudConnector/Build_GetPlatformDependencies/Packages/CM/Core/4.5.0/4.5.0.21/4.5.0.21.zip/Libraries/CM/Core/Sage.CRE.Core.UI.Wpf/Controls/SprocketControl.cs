﻿using System;
using System.Collections.Generic;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Sage.CRE.Core;
using System.Linq.Expressions;
using Sage.ExtensionMethods;

namespace Sage.CRE.Core.UI.Wpf.Controls
{
    /// <summary>
    /// Interaction logic for SprocketControl.xaml
    /// </summary>
    public class SprocketControl : Control, IDisposable
    {
        #region Enums

        /// <summary>
        /// Defines the Direction of Rotation
        /// </summary>
        public enum Direction
        {
            Clockwise,
            CounterClockwise
        }

        #endregion

        #region Construction

        /// <summary>
        /// Ctor
        /// </summary>
        public SprocketControl()
        {
            _renderTimer = new System.Timers.Timer(this.Interval);
            _renderTimer.Elapsed += new ElapsedEventHandler(OnRenderTimerElapsed);

            // Set the minimum size of the SprocketControl
            this.MinWidth = MINIMUM_CONTROL_SIZE.Width;
            this.MinWidth = MINIMUM_CONTROL_SIZE.Height;

            // Calculate the spoke poInt32s based on the current size
            CalculateSpokesPoints();

            RoutedEventHandler handler = null;
            handler = delegate
            {
                this.Loaded -= handler;
                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    if ((IsIndeterminate) && (IsVisible))
                        Start();
                }));
            };

            this.Loaded += handler;

            // Event handler added to stop the timer if the control is no longer visible
            this.IsVisibleChanged += new DependencyPropertyChangedEventHandler(OnVisibilityChanged);
        }

        #endregion

        #region IDisposable Implementation

        /// <summary>
        /// Releases all resources used by an instance of the SprocketControl class.
        /// </summary>
        /// <remarks>
        /// This method calls the virtual Dispose(Boolean) method, passing in 'true', and then suppresses 
        /// finalization of the instance.
        /// </remarks>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged resources before an instance of the SprocketControl class is reclaimed by garbage collection.
        /// </summary>
        /// <remarks>
        /// NOTE: Leave out the finalizer altogether if this class doesn't own unmanaged resources itself, 
        /// but leave the other methods exactly as they are.
        /// This method releases unmanaged resources by calling the virtual Dispose(Boolean), passing in 'false'.
        /// </remarks>
        ~SprocketControl()
        {
            Dispose(false);
        }

        /// <summary>
        /// Releases the unmanaged resources used by an instance of the SprocketControl class and optionally releases the managed resources.
        /// </summary>
        /// <param name="disposing">'true' to release both managed and unmanaged resources; 'false' to release only unmanaged resources.</param>
        protected virtual void Dispose(Boolean disposing)
        {
            if (disposing)
            {
                if (_renderTimer != null)
                {
                    _renderTimer.Elapsed -= OnRenderTimerElapsed;
                    _renderTimer.Dispose();
                }
                this.IsVisibleChanged -= OnVisibilityChanged;
            }

            // free native resources if there are any.			
        }

        #endregion

        #region Structs

        /// <summary>
        /// Stores the details of each spoke
        /// </summary>
        private struct Spoke
        {
            public Point StartPoint;
            public Point EndPoint;

            public Spoke(Point pt1, Point pt2)
            {
                StartPoint = pt1;
                EndPoint = pt2;
            }
        }

        #endregion       

        #region Dependency Properties

        #region Interval

        /// <summary>
        /// Interval Dependency Property
        /// </summary>
        public static readonly DependencyProperty IntervalProperty =
            DependencyProperty.Register("Interval", typeof(Double), typeof(SprocketControl),
                new FrameworkPropertyMetadata(DEFAULT_INTERVAL,
                                              new PropertyChangedCallback(OnIntervalChanged)));

        /// <summary>
        /// Gets or sets the Interval property. This dependency property 
        /// indicates duration at which the timer for rotation should fire.
        /// </summary>
        public Double Interval
        {
            get { return (Double)GetValue(IntervalProperty); }
            set { SetValue(IntervalProperty, value); }
        }

        /// <summary>
        /// Handles changes to the Interval property.
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="e">DependencyProperty changed event arguments</param>
        private static void OnIntervalChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl sprocket = (SprocketControl)d;
            Double oldInterval = (Double)e.OldValue;
            Double newInterval = sprocket.Interval;
            sprocket.OnIntervalChanged(oldInterval, newInterval);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the Interval property.
        /// </summary>
        /// <param name="oldInterval">Old Value</param>
        /// <param name="newInterval">New Value</param>
        protected virtual void OnIntervalChanged(Double oldInterval, Double newInterval)
        {
            if (_renderTimer != null)
            {
                Boolean isEnabled = _renderTimer.Enabled;
                _renderTimer.Enabled = false;
                _renderTimer.Interval = newInterval;
                _renderTimer.Enabled = isEnabled;
            }
        }

        #endregion

        #region IsIndeterminate

        /// <summary>
        /// IsIndeterminate Dependency Property
        /// </summary>
        public static readonly DependencyProperty IsIndeterminateProperty =
            DependencyProperty.Register("IsIndeterminate", typeof(Boolean), typeof(SprocketControl),
                new FrameworkPropertyMetadata(true,
                                              (new PropertyChangedCallback(OnIsIndeterminateChanged))));

        /// <summary>
        /// Gets or sets the IsIndeterminate property. This dependency property 
        /// indicates whether the SprocketControl's progress is indeterminate or not.
        /// </summary>
        public Boolean IsIndeterminate
        {
            get { return (Boolean)GetValue(IsIndeterminateProperty); }
            set { SetValue(IsIndeterminateProperty, value); }
        }

        /// <summary>
        /// Handles changes to the IsIndeterminate property.
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="e">DependencyProperty changed event arguments</param>
        private static void OnIsIndeterminateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl target = (SprocketControl)d;
            Boolean oldIsIndeterminate = (Boolean)e.OldValue;
            Boolean newIsIndeterminate = target.IsIndeterminate;
            target.OnIsIndeterminateChanged(oldIsIndeterminate, newIsIndeterminate);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the IsIndeterminate property.
        /// </summary>
        /// <param name="oldIsIndeterminate">Old Value</param>
        /// <param name="newIsIndeterminate">New Value</param>
        protected virtual void OnIsIndeterminateChanged(Boolean oldIsIndeterminate, Boolean newIsIndeterminate)
        {
            if (oldIsIndeterminate != newIsIndeterminate)
            {
                if ((newIsIndeterminate) && (IsVisible))
                {
                    // Start the renderTimer
                    Start();
                }
                else
                {
                    // Stop the renderTimer
                    Stop();
                    InvalidateVisual();
                }
            }
        }

        #endregion

        #region Progress

        /// <summary>
        /// Progress Dependency Property
        /// </summary>
        public static readonly DependencyProperty ProgressProperty =
            DependencyProperty.Register("Progress", typeof(Double), typeof(SprocketControl),
                new FrameworkPropertyMetadata(DEFAULT_PROGRESS,
                                              new PropertyChangedCallback(OnProgressChanged),
                                              new CoerceValueCallback(CoerceProgress)));

        /// <summary>
        /// Gets or sets the Progress property. This dependency property 
        /// indicates the progress percentage.
        /// </summary>
        public Double Progress
        {
            get { return (Double)GetValue(ProgressProperty); }
            set { SetValue(ProgressProperty, value); }
        }

        /// <summary>
        /// Coerces the Progress value so that it stays in the range 0-100
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="value">New Value</param>
        /// <returns>Coerced Value</returns>
        private static Object CoerceProgress(DependencyObject d, Object value)
        {
            Double progress = (Double)value;

            if (progress < 0.0)
            {
                return 0.0;
            }
            else if (progress > 100.0)
            {
                return 100.0;
            }

            return value;
        }

        /// <summary>
        /// Handles changes to the Progress property.
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="e">DependencyProperty changed event arguments</param>
        private static void OnProgressChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl sprocket = (SprocketControl)d;
            Double oldProgress = (Double)e.OldValue;
            Double newProgress = sprocket.Progress;
            sprocket.OnProgressChanged(oldProgress, newProgress);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the Progress property.
        /// </summary>
        /// <param name="oldProgress">Old Value</param>
        /// <param name="newProgress">New Value</param>
        protected virtual void OnProgressChanged(Double oldProgress, Double newProgress)
        {
            InvalidateVisual();
        }

        #endregion

        #region Rotation

        /// <summary>
        /// Rotation Dependency Property
        /// </summary>
        public static readonly DependencyProperty RotationProperty =
            DependencyProperty.Register("Rotation", typeof(Direction), typeof(SprocketControl),
                new FrameworkPropertyMetadata(Direction.Clockwise,
                                              new PropertyChangedCallback(OnRotationChanged)));

        /// <summary>
        /// Gets or sets the Rotation property. This dependency property 
        /// indicates the direction of Rotation of the SprocketControl.
        /// </summary>
        public Direction Rotation
        {
            get { return (Direction)GetValue(RotationProperty); }
            set { SetValue(RotationProperty, value); }
        }

        /// <summary>
        /// Handles changes to the Rotation property.
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="e">DependencyProperty changed event arguments</param>
        private static void OnRotationChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl sprocket = (SprocketControl)d;
            Direction oldRotation = (Direction)e.OldValue;
            Direction newRotation = sprocket.Rotation;
            sprocket.OnRotationChanged(oldRotation, newRotation);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the Rotation property.
        /// </summary>
        /// <param name="oldRotation">Old Value</param>
        /// <param name="newRotation">New Value</param>
        protected virtual void OnRotationChanged(Direction oldRotation, Direction newRotation)
        {
            // Recalculate the spoke poInt32s
            CalculateSpokesPoints();
        }

        #endregion

        #region StartAngle

        /// <summary>
        /// StartAngle Dependency Property
        /// </summary>
        public static readonly DependencyProperty StartAngleProperty =
            DependencyProperty.Register("StartAngle", typeof(Double), typeof(SprocketControl),
                new FrameworkPropertyMetadata(DEFAULT_START_ANGLE,
                                              new PropertyChangedCallback(OnStartAngleChanged)));

        /// <summary>
        /// Gets or sets the StartAngle property. This dependency property 
        /// indicates the angle at which the first spoke (with max opacity) is drawn.
        /// </summary>
        public Double StartAngle
        {
            get { return (Double)GetValue(StartAngleProperty); }
            set { SetValue(StartAngleProperty, value); }
        }

        /// <summary>
        /// Handles changes to the StartAngle property.
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="e">DependencyProperty changed event arguments</param>
        private static void OnStartAngleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl sprocket = (SprocketControl)d;
            Double oldStartAngle = (Double)e.OldValue;
            Double newStartAngle = sprocket.StartAngle;
            sprocket.OnStartAngleChanged(oldStartAngle, newStartAngle);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the StartAngle property.
        /// </summary>
        /// <param name="oldStartAngle">Old Value</param>
        /// <param name="newStartAngle">New Value</param>
        protected virtual void OnStartAngleChanged(Double oldStartAngle, Double newStartAngle)
        {
            // Recalculate the spoke poInt32s
            CalculateSpokesPoints();
        }

        #endregion

        #region TickColor

        /// <summary>
        /// TickColor Dependency Property
        /// </summary>
        public static readonly DependencyProperty TickColorProperty =
            DependencyProperty.Register("TickColor", typeof(Color), typeof(SprocketControl),
                new FrameworkPropertyMetadata(DEFAULT_TICK_COLOR,
                                              new PropertyChangedCallback(OnTickColorChanged)));

        /// <summary>
        /// Gets or sets the TickColor property. This dependency property 
        /// indicates the color of the Spokes in the SprocketControl.
        /// </summary>
        public Color TickColor
        {
            get { return (Color)GetValue(TickColorProperty); }
            set { SetValue(TickColorProperty, value); }
        }

        /// <summary>
        /// Handles changes to the TickColor property.
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="e">DependencyProperty changed event arguments</param>
        private static void OnTickColorChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl sprocket = (SprocketControl)d;
            Color oldTickColor = (Color)e.OldValue;
            Color newTickColor = sprocket.TickColor;
            sprocket.OnTickColorChanged(oldTickColor, newTickColor);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the TickColor property.
        /// </summary>
        /// <param name="oldTickColor">Old Value</param>
        /// <param name="newTickColor">New Value</param>
        protected virtual void OnTickColorChanged(Color oldTickColor, Color newTickColor)
        {
            InvalidateVisual();
        }

        #endregion

        #region TickCount

        /// <summary>
        /// TickCount Dependency Property
        /// </summary>
        public static readonly DependencyProperty TickCountProperty =
            DependencyProperty.Register("TickCount", typeof(Int32), typeof(SprocketControl),
                new FrameworkPropertyMetadata(DEFAULT_TICK_COUNT,
                                              new PropertyChangedCallback(OnTickCountChanged),
                                              new CoerceValueCallback(CoerceTickCount)));

        /// <summary>
        /// Gets or sets the TickCount property. This dependency property 
        /// indicates the number of spokes of the SprocketControl.
        /// </summary>
        public Int32 TickCount
        {
            get { return (Int32)GetValue(TickCountProperty); }
            set { SetValue(TickCountProperty, value); }
        }

        /// <summary>
        /// Coerces the TickCount value to an acceptable value
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="value">New Value</param>
        /// <returns>Coerced Value</returns>
        private static Object CoerceTickCount(DependencyObject d, Object value)
        {
            Int32 count = (Int32)value;

            if (count <= 0)
            {
                return DEFAULT_TICK_COUNT;
            }

            return value;
        }

        /// <summary>
        /// Handles changes to the TickCount property.
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="e">DependencyProperty changed event arguments</param>
        private static void OnTickCountChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl sprocket = (SprocketControl)d;
            Int32 oldTickCount = (Int32)e.OldValue;
            Int32 newTickCount = sprocket.TickCount;
            sprocket.OnTickCountChanged(oldTickCount, newTickCount);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the TickCount property.
        /// </summary>
        /// <param name="oldTickCount">Old Value</param>
        /// <param name="newTickCount">New Value</param>
        protected virtual void OnTickCountChanged(Int32 oldTickCount, Int32 newTickCount)
        {
            // Recalculate the spoke poInt32s
            CalculateSpokesPoints();
        }

        #endregion

        #region TickStyle

        /// <summary>
        /// TickStyle Dependency Property
        /// </summary>
        public static readonly DependencyProperty TickStyleProperty =
            DependencyProperty.Register("TickStyle", typeof(PenLineCap), typeof(SprocketControl),
                new FrameworkPropertyMetadata(PenLineCap.Round, (new PropertyChangedCallback(OnTickStyleChanged))));

        /// <summary>
        /// Gets or sets the TickStyle property. This dependency property 
        /// indicates the style of the ends of each tick.
        /// </summary>
        public PenLineCap TickStyle
        {
            get { return (PenLineCap)GetValue(TickStyleProperty); }
            set { SetValue(TickStyleProperty, value); }
        }

        /// <summary>
        /// Handles changes to the TickStyle property.
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="e">DependencyProperty changed event arguments</param>
        private static void OnTickStyleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl sprocket = (SprocketControl)d;
            PenLineCap oldTickStyle = (PenLineCap)e.OldValue;
            PenLineCap newTickStyle = sprocket.TickStyle;
            sprocket.OnTickStyleChanged(oldTickStyle, newTickStyle);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the TickStyle property.
        /// </summary>
        /// <param name="oldTickStyle">Old Value</param>
        /// <param name="newTickStyle">New Value</param>
        protected virtual void OnTickStyleChanged(PenLineCap oldTickStyle, PenLineCap newTickStyle)
        {
            InvalidateVisual();
        }

        #endregion

        #region TickWidth

        /// <summary>
        /// TickWidth Dependency Property
        /// </summary>
        public static readonly DependencyProperty TickWidthProperty =
            DependencyProperty.Register("TickWidth", typeof(Double), typeof(SprocketControl),
                new FrameworkPropertyMetadata(DEFAULT_TICK_WIDTH,
                                              new PropertyChangedCallback(OnTickWidthChanged),
                                              new CoerceValueCallback(CoerceTickWidth)));

        /// <summary>
        /// Gets or sets the TickWidth property. This dependency property 
        /// indicates the width of each spoke in the SprocketControl.
        /// </summary>
        public Double TickWidth
        {
            get { return (Double)GetValue(TickWidthProperty); }
            set { SetValue(TickWidthProperty, value); }
        }

        /// <summary>
        /// Coerces the TickWidth value so that it stays above 0.
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="value">New Value</param>
        /// <returns>Coerced Value</returns>
        private static Object CoerceTickWidth(DependencyObject d, Object value)
        {
            Double progress = (Double)value;

            if (progress < 0.0)
            {
                return DEFAULT_TICK_WIDTH;
            }

            return value;
        }
        /// <summary>
        /// Handles changes to the TickWidth property.
        /// </summary>
        /// <param name="d">SprocketControl</param>
        /// <param name="e">DependencyProperty changed event arguments</param>
        private static void OnTickWidthChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl target = (SprocketControl)d;
            Double oldTickWidth = (Double)e.OldValue;
            Double newTickWidth = target.TickWidth;
            target.OnTickWidthChanged(oldTickWidth, newTickWidth);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the TickWidth property.
        /// </summary>
        /// <param name="oldTickWidth">Old Value</param>
        /// <param name="newTickWidth">New Value</param>
        protected virtual void OnTickWidthChanged(Double oldTickWidth, Double newTickWidth)
        {
            InvalidateVisual();
        }

        #endregion

        #region LowestAlpha

        /// <summary>
        /// LowestAlpha Dependency Property
        /// </summary>
        public static readonly DependencyProperty LowestAlphaProperty =
            DependencyProperty.Register("LowestAlpha", typeof(Int32), typeof(SprocketControl),
                new FrameworkPropertyMetadata(ALPHA_LOWER_LIMIT,
                    new PropertyChangedCallback(OnLowestAlphaChanged),
                    new CoerceValueCallback(CoerceLowestAlpha)));

        /// <summary>
        /// Gets or sets the LowestAlpha property. This dependency property 
        /// indicates the lowest Opacity value that must be used while rendering the SprocketControl's spokes.
        /// </summary>
        public Int32 LowestAlpha
        {
            get { return (Int32)GetValue(LowestAlphaProperty); }
            set { SetValue(LowestAlphaProperty, value); }
        }

        /// <summary>
        /// Handles changes to the LowestAlpha property.
        /// </summary>
        private static void OnLowestAlphaChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl sprocket = (SprocketControl)d;
            Int32 oldLowestAlpha = (Int32)e.OldValue;
            Int32 newLowestAlpha = sprocket.LowestAlpha;
            sprocket.OnLowestAlphaChanged(oldLowestAlpha, newLowestAlpha);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the LowestAlpha property.
        /// </summary>
        protected virtual void OnLowestAlphaChanged(Int32 oldLowestAlpha, Int32 newLowestAlpha)
        {
        }

        /// <summary>
        /// Coerces the LowestAlpha value.
        /// </summary>
        private static Object CoerceLowestAlpha(DependencyObject d, Object value)
        {
            SprocketControl sprocket = (SprocketControl)d;
            Int32 desiredLowestAlpha = (Int32)value;

            if (desiredLowestAlpha < ALPHA_LOWER_LIMIT)
                return ALPHA_LOWER_LIMIT;
            else if (desiredLowestAlpha > ALPHA_UPPER_LIMIT)
                return ALPHA_UPPER_LIMIT;

            return desiredLowestAlpha;
        }

        #endregion

        #region AlphaTicksPercentage

        /// <summary>
        /// AlphaTicksPercentage Dependency Property
        /// </summary>
        public static readonly DependencyProperty AlphaTicksPercentageProperty =
            DependencyProperty.Register("AlphaTicksPercentage", typeof(Double), typeof(SprocketControl),
                new FrameworkPropertyMetadata(100.0,
                    new PropertyChangedCallback(OnAlphaTicksPercentageChanged),
                    new CoerceValueCallback(CoerceAlphaTicksPercentage)));

        /// <summary>
        /// Gets or sets the AlphaTicksPercentage property. This dependency property 
        /// indicates the percentage of total ticks which must be considered for step by step reduction
        /// of the alpha value. The remaining ticks remain at the LowestAlpha value.
        /// </summary>
        public Double AlphaTicksPercentage
        {
            get { return (Double)GetValue(AlphaTicksPercentageProperty); }
            set { SetValue(AlphaTicksPercentageProperty, value); }
        }

        /// <summary>
        /// Handles changes to the AlphaTicksPercentage property.
        /// </summary>
        private static void OnAlphaTicksPercentageChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            SprocketControl sprocket = (SprocketControl)d;
            Double oldAlphaTicksPercentage = (Double)e.OldValue;
            Double newAlphaTicksPercentage = sprocket.AlphaTicksPercentage;
            sprocket.OnAlphaTicksPercentageChanged(oldAlphaTicksPercentage, newAlphaTicksPercentage);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the AlphaTicksPercentage property.
        /// </summary>
        protected virtual void OnAlphaTicksPercentageChanged(Double oldAlphaTicksPercentage, Double newAlphaTicksPercentage)
        {
        }

        /// <summary>
        /// Coerces the AlphaTicksPercentage value.
        /// </summary>
        private static Object CoerceAlphaTicksPercentage(DependencyObject d, Object value)
        {
            SprocketControl target = (SprocketControl)d;
            Double desiredAlphaTicksPercentage = (Double)value;

            if (desiredAlphaTicksPercentage > 100.0)
                return 100.0;
            if (desiredAlphaTicksPercentage < ALPHA_TICK_PERCENTAGE_LOWER_LIMIT)
                return ALPHA_TICK_PERCENTAGE_LOWER_LIMIT;

            return desiredAlphaTicksPercentage;
        }

        #endregion

        #endregion

        #region Helpers

        /// <summary>
        /// Start the Tick Control rotation
        /// </summary>
        private void Start()
        {
            if ((_renderTimer != null) && (!_renderTimer.Enabled))
            {
                _renderTimer.Interval = this.Interval;
                _renderTimer.Enabled = true;
            }
        }

        /// <summary>
        /// Stop the Tick Control rotation
        /// </summary>
        private void Stop()
        {
            if (_renderTimer != null)
            {
                _renderTimer.Enabled = false;
            }
        }

        /// <summary>
        /// Converts Degrees to Radians
        /// </summary>
        /// <param name="degrees">Degrees</param>
        /// <returns>Radians</returns>
        private Double ConvertDegreesToRadians(Double degrees)
        {
            return ((Math.PI / (Double)180) * degrees);
        }

        /// <summary>
        /// Calculate the Spoke Points and store them
        /// </summary>
        private void CalculateSpokesPoints()
        {
            _spokes = new List<Spoke>();

            // Calculate the angle between adjacent spokes
            _angleIncrement = (360 / (Double)TickCount);
            // Calculate the change in alpha between adjacent spokes
            _alphaChange = (Int32)((Double)(255 - LowestAlpha) / (Double)((AlphaTicksPercentage / 100.0) * TickCount));

            // Set the start angle for rendering
            _renderStartAngle = StartAngle;

            // Calculate the location around which the spokes will be drawn
            Double width = (this.Width < this.Height) ? this.Width : this.Height;
            _centerPoint = new Point(this.Width / 2, this.Height / 2);
            // Calculate the inner and outer radii of the control. The radii should not be less than the
            // Minimum values
            _innerRadius = (Int32)(width * INNER_RADIUS_FACTOR);
            if (_innerRadius < MINIMUM_INNER_RADIUS)
                _innerRadius = MINIMUM_INNER_RADIUS;
            _outerRadius = (Int32)(width * OUTER_RADIUS_FACTOR);
            if (_outerRadius < MINIMUM_OUTER_RADIUS)
                _outerRadius = MINIMUM_OUTER_RADIUS;

            Double angle = 0;

            for (Int32 i = 0; i < TickCount; i++)
            {
                Point pt1 = new Point(_innerRadius * (float)Math.Cos(ConvertDegreesToRadians(angle)), _innerRadius * (float)Math.Sin(ConvertDegreesToRadians(angle)));
                Point pt2 = new Point(_outerRadius * (float)Math.Cos(ConvertDegreesToRadians(angle)), _outerRadius * (float)Math.Sin(ConvertDegreesToRadians(angle)));

                // Create a spoke based on the poInt32s generated
                Spoke spoke = new Spoke(pt1, pt2);
                // Add the spoke to the List
                _spokes.Add(spoke);

                // If it is not it Indeterminate state, 
                // ensure that the spokes are drawn in clockwise manner
                if (!IsIndeterminate)
                {
                    angle += _angleIncrement;
                }
                else
                {
                    if (Rotation == Direction.Clockwise)
                    {
                        angle -= _angleIncrement;
                    }
                    else if (Rotation == Direction.CounterClockwise)
                    {
                        angle += _angleIncrement;
                    }
                }
            }
        }

        #endregion

        #region Overrides

        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
        {
            base.OnRenderSizeChanged(sizeInfo);

            // Calculate the spoke poInt32s based on the new size
            CalculateSpokesPoints();
        }

        protected override void OnRender(DrawingContext dc)
        {
            if (_spokes == null)
                return;

            TranslateTransform translate = new TranslateTransform(_centerPoint.X, _centerPoint.Y);
            dc.PushTransform(translate);
            RotateTransform rotate = new RotateTransform(_renderStartAngle);
            dc.PushTransform(rotate);

            byte alpha = (byte)255;

            // Get the number of spokes that can be drawn with zero transparency
            Int32 progressSpokes = (Int32)Math.Floor((Progress * TickCount) / 100.0);

            // Render the spokes
            for (Int32 i = 0; i < TickCount; i++)
            {
                if (!IsIndeterminate)
                {
                    if (progressSpokes > 0)
                        alpha = (byte)(i < progressSpokes ? 255 : DEFAULT_PROGRESS_ALPHA);
                    else
                        alpha = (byte)DEFAULT_PROGRESS_ALPHA;
                }

                Pen p = new Pen(new SolidColorBrush(Color.FromArgb(alpha, this.TickColor.R, this.TickColor.G, this.TickColor.B)), TickWidth);
                p.StartLineCap = p.EndLineCap = TickStyle;
                dc.DrawLine(p, _spokes[i].StartPoint, _spokes[i].EndPoint);

                if (IsIndeterminate)
                {
                    alpha -= (byte)_alphaChange;
                    if (alpha < LowestAlpha)
                        alpha = (byte)LowestAlpha;
                }
            }

            // Perform a reverse Rotation and Translation to obtain the original Transformation
            dc.Pop();
            dc.Pop();
        }

        #endregion

        #region Event Handlers

        /// <summary>
        /// Handles the Elapsed event of the renderTimer
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">EventArgs</param>
        private void OnRenderTimerElapsed(Object sender, ElapsedEventArgs e)
        {
            this.Dispatcher.BeginInvoke(new Action(() =>
            {
                if (Rotation == Direction.Clockwise)
                {
                    _renderStartAngle += _angleIncrement;

                    if (_renderStartAngle >= 360)
                        _renderStartAngle -= 360;
                }
                else if (Rotation == Direction.CounterClockwise)
                {
                    _renderStartAngle -= _angleIncrement;

                    if (_renderStartAngle <= -360)
                        _renderStartAngle += 360;
                }

                // Force re-rendering of control
                InvalidateVisual();
            }));
        }

        /// <summary>
        /// Event handler to stop the timer if the control is no longer visible
        /// and start it when it is visible
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnVisibilityChanged(Object sender, DependencyPropertyChangedEventArgs e)
        {
            // Needs to be handled only if the state of the progress bar is indeterminate
            if (IsIndeterminate)
            {
                if ((Boolean)e.NewValue)
                {
                    this.Start();
                }
                else
                {
                    this.Stop();
                }
            }
        }

        #endregion

        #region Constants

        private const Double DEFAULT_INTERVAL = 60;
        private static readonly Color DEFAULT_TICK_COLOR = Color.FromArgb((byte)255, (byte)58, (byte)58, (byte)58);
        private const Double DEFAULT_TICK_WIDTH = 3;
        private const Int32 DEFAULT_TICK_COUNT = 12;
        private const Double MINIMUM_INNER_RADIUS = 5;
        private const Double MINIMUM_OUTER_RADIUS = 8;
        private readonly Size MINIMUM_CONTROL_SIZE = new Size(28, 28);
        private const Double MINIMUM_PEN_WIDTH = 2;
        private const Double DEFAULT_START_ANGLE = 270;
        private const Double INNER_RADIUS_FACTOR = 0.175;
        private const Double OUTER_RADIUS_FACTOR = 0.3125;
        // The Lower limit of the Alpha value (The spokes will be shown in 
        // alpha values ranging from 255 to m_AlphaLowerLimit)
        private const Int32 ALPHA_UPPER_LIMIT = 250;
        private const Int32 ALPHA_LOWER_LIMIT = 0;
        private const Double ALPHA_TICK_PERCENTAGE_LOWER_LIMIT = 10;
        private const Double DEFAULT_PROGRESS_ALPHA = 10;
        private const Double DEFAULT_PROGRESS = 0.0;
        #endregion

        #region Fields

        private Point _centerPoint = new Point();
        private Double _innerRadius = 0;
        private Double _outerRadius = 0;
        private Double _alphaChange = 0;
        private Double _angleIncrement = 0;
        private Double _renderStartAngle = 0;
        private System.Timers.Timer _renderTimer = null;
        private List<Spoke> _spokes = null;

        #endregion
    }
}

