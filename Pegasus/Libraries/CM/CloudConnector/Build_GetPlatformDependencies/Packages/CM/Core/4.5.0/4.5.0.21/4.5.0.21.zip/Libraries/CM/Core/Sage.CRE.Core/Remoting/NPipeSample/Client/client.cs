using System;
using System.Collections;
using System.Collections.Specialized;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Threading;

using Sage.Remoting;

using TestLibrary;

public class Client
{
    static readonly string _clientUrl = "pipe://MyPipe/TestObject.rem";

    private static TestObject RemoteSetup()
    {
        // Create client channel
        ChannelRegistrar client = new ChannelRegistrar();
        client.RegisterClient(ChannelType.NamedPipe);

        // Create Server channel for callbacks
        ListDictionary props = new ListDictionary();
        props.Add("machine", Environment.MachineName);
        props.Add("pipe", "Auto");
        ChannelRegistrar server = new ChannelRegistrar();
        server.RegisterServer(ChannelType.NamedPipe, props);

        /*
        ChannelRegistrar server = new ChannelRegistrar();
        server.RegisterServer(ChannelType.NamedPipe);
        */

        return (TestObject) Activator.GetObject(typeof(TestObject), _clientUrl);
    }


    public static void Main(string[] args)
    {
        bool batch = false;
        int batchSize = 5000;

        if (args.Length > 0)
        {
            foreach(String arg in args)
            {
                if (String.Compare(arg, "-batch", true) == 0)
                {
                    batch = true;
                }
            }
        }

        try
        {
            //TestObject obj = LocalSetup();
            TestObject obj = RemoteSetup();


			if (obj != null)
			{
                Console.WriteLine("Regular Request Response methods");
                Console.WriteLine(obj.Ping());
                Console.WriteLine(obj.Ping());

                Console.WriteLine("Method with Callback from Server");
                Console.WriteLine(obj.CallMe(new CallbackObject()));

                Console.WriteLine("OneWay Methods");
                obj.OneWayMethod("Andre");
                obj.OneWayMethod("Frank");
                obj.OneWayMethod("Dan");

                Console.WriteLine("Async Methods");
                Console.WriteLine(obj.AsyncMethod("Fred"));

                AsyncStringStringDelegate asyncD = new AsyncStringStringDelegate(obj.AsyncMethod);
                IAsyncResult ar1 = asyncD.BeginInvoke("Chad",null,null);
                //
                //Wait for the call to complete
                //
                ar1.AsyncWaitHandle.WaitOne();
                Console.WriteLine(asyncD.EndInvoke(ar1));

                Console.WriteLine("done with sanity tests!");

                if (batch)
                {
                    int start;

                    //
                    start = Environment.TickCount;

                    for(int item=0;item<batchSize;item++)
                    {
                        obj.RegularMethod("Batch"+item);
                    }

                    Console.WriteLine("done with RegularMethod batch! {0}", Environment.TickCount - start);
                    obj.RegularMethod("BatchEnd");
                    //

                    //
                    start = Environment.TickCount;

                    for(int item=0;item<batchSize;item++)
                    {
                        obj.OneWayMethod("Batch"+item);
                    }

                    Console.WriteLine("done with OneWay batch! {0}", Environment.TickCount - start);
                    obj.OneWayMethod("BatchEnd");
                    //


                    //
                    String ret;

                    start = Environment.TickCount;

                    for(int item=0;item<batchSize;item++)
                    {
                        ar1 = asyncD.BeginInvoke("Bob"+item,null,null);
                        //
                        //Wait for the call to complete
                        //
                        ar1.AsyncWaitHandle.WaitOne();
                        ret = asyncD.EndInvoke(ar1);
                    }

                    Console.WriteLine("done with AsyncMethod batch! {0}", Environment.TickCount - start);
                    obj.OneWayMethod("BatchEnd");

                    ar1 = asyncD.BeginInvoke("BatchEnd",null,null);

                    //Wait for the call to complete
                    ar1.AsyncWaitHandle.WaitOne();
                    ret = asyncD.EndInvoke(ar1);
                    //
                }

                Console.WriteLine("done with test suite!");
			}
			else
				Console.WriteLine("No Object created");
        }
        catch(Exception e)
        {
            Console.WriteLine("Exception = " + e);
        }
    }
}

public delegate String AsyncStringStringDelegate(String s);


