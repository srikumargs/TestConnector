#if DEBUG
using System;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Activation;
using System.Globalization;
using NUnit.Framework;

using Sage.Diagnostics;

namespace Sage.Activation.NUnit
{
    [AttributeUsage(AttributeTargets.Class)]
    internal sealed class TestContextAttribute : ContextAttribute
    {
        #region Constructors
        public TestContextAttribute() : base("TestContextAttribute")
        {}
        #endregion

        #region ContextAttribute
        /// <summary>
        /// The runtime calls this method after an attribute has indicated that the current context isn't OK for activation of the attributed type.
        /// </summary>
        /// <param name="ctor"></param>
        /// <remarks>
        /// Called when a brand new context is created.  Allows the context attribute to add new
        /// properties to the brand new context.
        /// </remarks>
        public override void GetPropertiesForNewContext(IConstructionCallMessage ctor)
        {
            ctor.ContextProperties.Add(new TestContextProperty());
        }
        
        /// <summary>
        /// The runtime calls this method to determine whether the current context is OK for activation of the attributed type. 
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="ctorMsg"></param>
        /// <returns></returns>
        /// <remarks>
        /// The IsContextOK method lets the context attribute examine the creating client's
        /// context provided in the ctx parameter. Every context has an object of the Context
        /// type associated with it. The Context object provides easy access to the context
        /// properties. If the client's context is adequate, then no further action is required
        /// and the runtime activates the new object in the creating client's context. If the
        /// context attribute returns false from IsContextOK, then a new context is created and
        /// GetPropertiesForNewContext is called, allowing the context attribute to add new
        /// properties to the new context.
        /// </remarks>
        public override bool IsContextOK(Context ctx, IConstructionCallMessage ctorMsg)
        {
            // normally, figure out if the creating context already has the requisite property, and if not reject it

            return false; // in this case, we want to force every object to have its own context
        }
        #endregion
    }

    internal class TestContextProperty : IContextProperty, IContributeServerContextSink
    {
        #region Constructors
        public TestContextProperty()
        {}
        #endregion

        #region IContextProperty
        /// <summary>
        /// The name of the property. Used as a key in the property collection for the context.
        /// </summary>
        /// <remarks>
        /// Each context property is identified by name through the Name property of IContextProperty 
        /// </remarks>
        string IContextProperty.Name
        {
            get
            {
                return "TestContextProperty";
            }
        }

        /// <summary>
        /// The .NET Remoting infrastructure calls this method after allowing all attributes to add
        /// properties to the context. After freezing the context, the .NET Remoting infrastructure
        /// disallows the addition of more context properties.
        /// </summary>
        /// <param name="ctx"></param>
        /// <remarks>
        /// The Freeze method lets a context property know that the final location of the
        /// context is established, and is available for advanced use only.
        /// </remarks>
        void IContextProperty.Freeze(Context ctx)
        {}

        /// <summary>
        /// The runtime calls this method after freezing the context to give each context property a
        /// chance to abort creation of the context.
        /// </summary>
        /// <param name="ctx"></param>
        /// <returns></returns>
        /// <remarks>
        /// Because a single context-bound object can have multiple context attributes, it is possible
        /// that some of them conflict. To handle this, IsNewContextOK is called on each property after
        /// all the properties are added to the new context. If any one of the properties returns false,
        /// then the instantiation of the new object is aborted and an exception of the RemotingException
        /// type is thrown.
        /// </remarks>
        bool IContextProperty.IsNewContextOK(Context ctx)
        {
            // Find out if the new context has a TestContextProperty property. If not, reject it
            if((ctx.GetProperty("TestContextProperty") as TestContextProperty) == null)
            {
                return false;
            }

            return true;
        }
        #endregion

        #region IContributeServerContextSink
        /// <summary>
        /// </summary>
        /// <param name="nextSink"></param>
        /// <returns></returns>
        /// <remarks>
        /// In its implementation of GetServerContextSink, the context property creates a sink object and
        /// concatenates it with the next sink in the chain provided as the method parameter.
        /// GetServerContextSink should return the new sink it created so that it will be added to the
        /// interception chain.
        /// 
        /// The server context sink intercepts all calls coming into the context. GetServerContextSink is
        /// called after its call to IContextProperty.IsNewContextOK but before creating the object,
        /// allowing the context property to provide the sink. A server context sink can intercept
        /// construction calls.
        /// </remarks>
        IMessageSink IContributeServerContextSink.GetServerContextSink(IMessageSink nextSink)
        {
            return new TestServerContextSink(nextSink);
        }
        #endregion
    }

    internal class TestServerContextSink : IMessageSink
    {
        private IMessageSink _nextSink;

        #region Constructors
        public TestServerContextSink(IMessageSink nextSink)
        {
            _nextSink = nextSink;
        }
        #endregion

        #region IMessageSink
        /// <summary>
        /// Gets the next message sink in the sink chain.
        /// </summary>
        IMessageSink IMessageSink.NextSink
        {
            get {return _nextSink;}
        }

        /// <summary>
        /// Synchronously processes the given message.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        IMessage IMessageSink.SyncProcessMessage(IMessage msg)
        {
            return (IMethodReturnMessage) _nextSink.SyncProcessMessage(msg);
        }

        /// <summary>
        /// Asynchronously processes the given message.
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="replySink"></param>
        /// <returns></returns>
        IMessageCtrl IMessageSink.AsyncProcessMessage(IMessage msg, IMessageSink replySink)
        {
            return _nextSink.AsyncProcessMessage(msg, replySink);
        } 
        #endregion

    }

    internal class Work
    {
        public static int DoNoWork(int param)
        {
            return param;
        }

        public static int SleepForOneMillisecond(int param)
        {
            System.Threading.Thread.Sleep(1);
            return param;
        }
    }

    internal class ClassWithoutInterception
    {
        public ClassWithoutInterception()
        {}

        public int DoNoWork(int param)
        {
            return Work.DoNoWork(param);
        }

        public int SleepForOneMillisecond(int param)
        {
            return Work.SleepForOneMillisecond(param);
        }
    }

    [TestContext]
    internal class ClassWithInterception : ContextBoundObject
    {
        public ClassWithInterception()
        {}

        public int DoNoWork(int param)
        {
            return Work.DoNoWork(param);
        }

        public int SleepForOneMillisecond(int param)
        {
            return Work.SleepForOneMillisecond(param);
        }
    }

    /// <summary>
    /// Test the interception framework
    /// </summary>
    [TestFixture]
    public class Test_Interception
    {
        /// <summary>
        /// Performance test which compares overhead of interception framework
        /// </summary>
        [Test]
        public void CallPerformanceComparisonTest()
        {
            QueryPerfTimer timer = new QueryPerfTimer();
            const int NUMBER_OF_REPETITIONS = 10;
            const int SAMPLE_SIZE = 100;
            const int MULTIPLIER = 10;
            double [] _withoutInterceptionNoWorkTimes = new double[SAMPLE_SIZE];
            double [] _withInterceptionNoWorkTimes = new double[SAMPLE_SIZE];
            double [] _withoutInterceptionSleep1Times = new double[SAMPLE_SIZE];
            double [] _withInterceptionSleep1Times = new double[SAMPLE_SIZE];

            ClassWithoutInterception baselineWorker = new ClassWithoutInterception();
            for(int repetition = 0 ; repetition < NUMBER_OF_REPETITIONS ; repetition++)
            {
                for(int sample = 1 ; sample < SAMPLE_SIZE ; sample++)
                {
                    timer.Reset();
                    int numberOfCalls = MULTIPLIER * sample;
                    for(int i = 0 ; i < numberOfCalls ; i++)
                    {
                        baselineWorker.DoNoWork(i);
                    }
                    _withoutInterceptionNoWorkTimes[sample] += timer.Interval_us;
                    System.Diagnostics.Trace.WriteLine(string.Format(CultureInfo.InvariantCulture, "(nowork) repetition={0} numberOfCalls={1}", repetition, numberOfCalls));

                    timer.Reset();
                    for(int i = 0 ; i < numberOfCalls ; i++)
                    {
                        baselineWorker.SleepForOneMillisecond(i);
                    }
                    _withoutInterceptionSleep1Times[sample] += timer.Interval_us;
                    System.Diagnostics.Trace.WriteLine(string.Format(CultureInfo.InvariantCulture, "(sleep1) repetition={0} numberOfCalls={1}", repetition, numberOfCalls));
                }
            }

            ClassWithInterception interceptionWorker = new ClassWithInterception();
            for(int repetition = 0 ; repetition < NUMBER_OF_REPETITIONS ; repetition++)
            {
                for(int sample = 0 ; sample < SAMPLE_SIZE ; sample++)
                {
                    timer.Reset();
                    int numberOfCalls = MULTIPLIER * sample;
                    for(int i = 0 ; i < numberOfCalls ; i++)
                    {
                        interceptionWorker.DoNoWork(i);
                    }
                    _withInterceptionNoWorkTimes[sample] += timer.Interval_us;
                    System.Diagnostics.Trace.WriteLine(string.Format(CultureInfo.InvariantCulture, "(nowork) repetition={0} numberOfCalls={1}", repetition, numberOfCalls));

                    timer.Reset();
                    for(int i = 0 ; i < numberOfCalls ; i++)
                    {
                        interceptionWorker.SleepForOneMillisecond(i);
                    }
                    _withInterceptionSleep1Times[sample] += timer.Interval_us;
                    System.Diagnostics.Trace.WriteLine(string.Format(CultureInfo.InvariantCulture, "(sleep1) repetition={0} numberOfCalls={1}", repetition, numberOfCalls));
                }
            }

            // compute average
            System.IO.StreamWriter sw = new  System.IO.StreamWriter(@"C:\PerformanceTest.html", false);
            sw.WriteLine("<html><head/><body><table><tr><th># calls</th><th>w/o Intercept; no work</th><th>w/ Intercept; no work</th><th>w/o Intercept; sleep 1 ms</th><th>w/ Intercept; sleep 1 ms</th></tr>");
            for(int i = 1 ; i < SAMPLE_SIZE ; i++)
            {
                // compuete average
                _withoutInterceptionNoWorkTimes[i] = _withoutInterceptionNoWorkTimes[i] / NUMBER_OF_REPETITIONS;
                _withInterceptionNoWorkTimes[i] = _withInterceptionNoWorkTimes[i] / NUMBER_OF_REPETITIONS;
                _withoutInterceptionSleep1Times[i] = _withoutInterceptionSleep1Times[i] / NUMBER_OF_REPETITIONS;
                _withInterceptionSleep1Times[i] = _withInterceptionSleep1Times[i] / NUMBER_OF_REPETITIONS;

                sw.WriteLine("<tr><td>{0}</td><td>{1:F3}</td><td>{2:F3}</td><td>{3:F3}</td><td>{4:F3}</td></tr>", MULTIPLIER * i, _withoutInterceptionNoWorkTimes[i] * 0.001, _withInterceptionNoWorkTimes[i] * 0.001, _withoutInterceptionSleep1Times[i] * 0.001, _withInterceptionSleep1Times[i] * 0.001);
            }
            sw.WriteLine("</table></body></html>");
            sw.Flush();
            sw.Close();
        }
    }

}
#endif