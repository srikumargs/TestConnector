using System;

namespace Sage.Net
{
    /// <summary>
    /// Summary description for Domain
    /// </summary>
    internal class Domain
      : NameBase
      , IDomain
    {
        public Domain(string name)
            : base(name)
        {
        }

    }
}
