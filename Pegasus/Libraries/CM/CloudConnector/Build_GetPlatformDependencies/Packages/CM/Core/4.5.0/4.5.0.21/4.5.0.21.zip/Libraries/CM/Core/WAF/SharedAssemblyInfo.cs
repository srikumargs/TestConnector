﻿using System.Reflection;
using System;
using System.Runtime.InteropServices;
using System.Resources;


[assembly: AssemblyCulture("")]


[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]

[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.MainAssembly)]