using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Specifies the possible types of component activation
    /// </summary>
    [Serializable]
    public enum ComponentActivationType 
    {
        /// <summary>
        /// No component specified (I.E. Null object pattern)
        /// </summary>
        None,

        /// <summary>
        /// Construct the compoennt locally via assembly and type information
        /// </summary>
        Local,

        /// <summary>
        /// Construct the object remotly via a Url
        /// </summary>
        Remote,

        /// <summary>
        /// Construct the object via COM
        /// </summary>
        Com
    }

    /// <summary>
    /// A class that conatins activation information for some particular component
    /// </summary>
    [Serializable]
    public sealed class ComponentActivationInfo
    {
        #region Fields

        /// <summary>
        /// The type of activation to use for creating the componenet
        /// </summary>
        private readonly ComponentActivationType _activationType;

        /// <summary>
        /// The name of the component's assembly
        /// </summary>
        private readonly string _assemblyName; // = null; Initialized by the runtime

        /// <summary>
        /// The fully qualified name of the component's type
        /// </summary>
        private readonly string _fullyQualifiedTypeName; // = null; Initialized by the runtime

        /// <summary>
        /// The location of the component's assembly
        /// </summary>
        private readonly string _assemblyCodebase; // = null; Initialized by the runtime

        /// <summary>
        /// A Url for remote activating the component
        /// </summary>
        private readonly Uri _activationUrl; // = null; Initialized by the runtime

        /// <summary>
        /// The ProgID for a COM component
        /// </summary>
        private readonly string _progId; // = null; Initialized by the runtime

        #endregion

        #region Construction/Destruction

        /// <summary>
        /// Constructor
        /// </summary>
        /// <remarks>Use this constructor for specifing ComponentActivationType.None</remarks>
        public ComponentActivationInfo() 
        {
            _activationType = ComponentActivationType.None;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="assemblyName">The name of a assmebly that contains the type to activate</param>
        /// <param name="fullyQualifiedType">The fully qualified name of the type to activate</param>
        /// <param name="codebase">The location of the assembly. May ne null if deafult assembly probing should be used</param>
        /// <remarks>Use this constructor for specifiing ComponentActivationType.Local</remarks>
        public ComponentActivationInfo(string assemblyName, string fullyQualifiedType, string codebase)
        {
            ArgumentValidator.ValidateNonEmptyString(assemblyName, "assemblyName", StringTable.COMPONENT_ACTIVATION_INFO_COMPONENT);
            ArgumentValidator.ValidateNonEmptyString(fullyQualifiedType, "fullyQualifiedType", StringTable.COMPONENT_ACTIVATION_INFO_COMPONENT);
            
            _assemblyName = assemblyName;
            _fullyQualifiedTypeName = fullyQualifiedType;

            if (codebase != null && codebase.Length == 0) 
            {
                codebase = null;
            }
            _assemblyCodebase = codebase;
            _activationType = ComponentActivationType.Local;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="activationUrl">A url to use for remote activation of the component</param>
        /// <remarks>Use this constructor for specifing ComponentActivationType.Remote</remarks>
        public ComponentActivationInfo( Uri activationUrl )
        {
            ArgumentValidator.ValidateNonNullReference(activationUrl, "activationUrl", StringTable.COMPONENT_ACTIVATION_INFO_COMPONENT);

            _activationUrl = activationUrl;
            _activationType = ComponentActivationType.Remote;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="progId">The ProgID of a COM component</param>
        /// <remarks>Use this constructor for specifing ComponentActivationType.COM</remarks>
        public ComponentActivationInfo(string progId) 
        {
            ArgumentValidator.ValidateNonEmptyString(progId, "ProgId", StringTable.COMPONENT_ACTIVATION_INFO_COMPONENT);
            _progId = progId;
            _activationType = ComponentActivationType.Com;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Retrieve the type of activation to use for creating the componenet
        /// </summary>
        public ComponentActivationType ActivationType 
        {
            get { return _activationType; }
        }

        /// <summary>
        /// Retrieve the name of the component's assembly
        /// </summary>
        /// <remarks>Should only be called in ActivationType == ComponentActivationType.Local</remarks>
        public string AssemblyName 
        {
            get 
            {
                Assertions.Assert(_activationType == ComponentActivationType.Local);
                return _assemblyName; 
            }
        }

        /// <summary>
        /// Retrieve the fully qualified name of the component's type
        /// </summary>
        /// <remarks>Should only be called in ActivationType == ComponentActivationType.Local</remarks>
        public string FullyQualifiedTypeName 
        {
            get 
            {
                Assertions.Assert(_activationType == ComponentActivationType.Local);
                return _fullyQualifiedTypeName;
            }
        }

        /// <summary>
        /// Retrieve the location of the component's assembly
        /// </summary>
        /// <remarks>Should only be called in ActivationType == ComponentActivationType.Local. 
        /// Also this value may be null if default assembly probing should be used</remarks>
        public string CodeBase 
        {
            get 
            {
                Assertions.Assert(_activationType == ComponentActivationType.Local);
                return _assemblyCodebase;
            }
        }

        /// <summary>
        /// Retrieve a Url for remote activating the component
        /// </summary>
        /// <remarks>Should only be called in ActivationType == ComponentActivationType.Remote</remarks>
        public Uri Url 
        {
            get 
            {
                Assertions.Assert(_activationType == ComponentActivationType.Remote);
                return _activationUrl;
            }
        }

        /// <summary>
        /// Retrieve the ProgId for activating a COM component
        /// </summary>
        /// <remarks>Should only be called in ActivationType == ComponentActivationType.COM</remarks>
        public string ProgId 
        {
            get 
            {
                Assertions.Assert(_activationType == ComponentActivationType.Com);
                return _progId;
            }
        }

        #endregion
    }
}
