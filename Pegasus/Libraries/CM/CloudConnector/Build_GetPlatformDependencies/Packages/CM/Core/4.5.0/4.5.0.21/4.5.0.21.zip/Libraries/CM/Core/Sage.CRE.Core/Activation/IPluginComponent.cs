using System;

namespace Sage.Activation
{
	/// <summary>
	/// Interface that should be implemented by all plugin components
	/// </summary>
	public interface IPluginComponent
	{
        /// <summary>
        /// Get the name of the component
        /// </summary>
        string Name{ get; }

        /// <summary>
        /// Initialize the componenet from an XML string
        /// </summary>
        /// <param name="xml"></param>
		void InitializeFromXml( string xml );

        /// <summary>
        /// Retrieve an xml fragment defining the component
        /// </summary>
        string Xml{ get; }

	}
}
