#if DEBUG

using System;
using System.IO;
using NUnit.Framework;

using Sage.Configuration;

namespace Sage.Configuration.Tests
{
	/// <summary>
	/// Class used for testing the xml data store
	/// </summary>
	[TestFixture]
	public class TestDataStore
	{
        /// <summary>
        /// Constructor
        /// </summary>
		public TestDataStore()
		{
			
		}

		private string FileSystemLocation
		{
			get { return string.Format(@"{0}\DataStoreFileSystemTest\", LibraryManager.SharedConfigLocation, DataRegistry.FileExtension ); }
		}

		private string FileSystemDataFile
		{
			get { return string.Format(@"{0}NUnit{1}", FileSystemLocation, DataRegistry.FileExtension ); }
		}

        /// <summary>
        /// Test creating an removing an unencrypted All Users data store
        /// </summary>
        [Test]
        public void TestCreatingAndRemovingDataTables()
        {
            DataRegistry.CreateKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUnit" );
            Assert.IsTrue( File.Exists( string.Format( @"{0}\DataStoreTest\NUnit{1}", LibraryManager.SharedConfigLocation, DataRegistry.FileExtension ) ) );

            DataRegistry.RemoveKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUNit" );
            Assert.IsTrue( !File.Exists( string.Format(@"{0}\DataStoreTest\NUnit{1}", LibraryManager.SharedConfigLocation, DataRegistry.FileExtension ) ) );

            DataRegistry.CreateKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUnit" );
            Assert.IsTrue( File.Exists( string.Format(@"{0}\DataStoreTest\NUnit{1}", LibraryManager.SharedConfigLocation, DataRegistry.FileExtension ) ) );

            DataRegistry.CreateKeyedValueSet( DataScope.CurrentUser, "DataStoreTest", "NUnit" );
            //Assert.IsTrue( File.Exists( string.Format(@"{0}\Sage\DataStoreTest\NUnit{1}", System.Environment.GetFolderPath( System.Environment.SpecialFolder.LocalApplicationData ), DataStore.FILE_EXTENSION ) ) );

            DataRegistry.CreateKeyedValueSet( DataScope.RoamingUser, "DataStoreTest", "NUnit" );
            //Assert.IsTrue( File.Exists( string.Format(@"{0}\Sage\DataStoreTest\NUnit{1}", System.Environment.GetFolderPath( System.Environment.SpecialFolder.LocalApplicationData ), DataStore.FILE_EXTENSION ) ) );
			
			DataRegistry.CreateKeyedValueSet( DataScope.FileSystem, FileSystemLocation , "NUnit" );
			Assert.IsTrue( File.Exists( FileSystemDataFile ) );

            Cleanup();
        }

        /// <summary>
        /// Test Setting and retrieving values in a data table
        /// </summary>
        [Test]
        public void TestSettingAndRetrievingValues()
        {
            // Test all users
            DataRegistry.CreateKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUnit" ).SetValue( "General", "MyKey", "TestValue" );
            string keyValue = DataRegistry.OpenKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUnit" ).GetValue( "General", "MyKey" );
            Assert.IsTrue( keyValue == "TestValue" );

            IKeyedValues table = DataRegistry.OpenKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUnit" );
            table.SetValue( @"General\Settings", "SettingsKey", "SomeData" );
            keyValue = table.GetValue( @"General\Settings", "SettingsKey" );
            Assert.IsTrue( keyValue == "SomeData" );

            // Test current user
            DataRegistry.CreateKeyedValueSet( DataScope.CurrentUser, "DataStoreTest", "NUnit" ).SetValue( "General", "MyKey", "TestValue" );
            keyValue = DataRegistry.OpenKeyedValueSet( DataScope.CurrentUser, "DataStoreTest", "NUnit" ).GetValue( "General", "MyKey" );
            Assert.IsTrue( keyValue == "TestValue" );

            table = DataRegistry.OpenKeyedValueSet( DataScope.CurrentUser, "DataStoreTest", "NUnit" );
            table.SetValue( @"General\Settings", "SettingsKey", "SomeData" );
            keyValue = table.GetValue( @"General\Settings", "SettingsKey" );
            Assert.IsTrue( keyValue == "SomeData" );

            // Test roaming user
            DataRegistry.CreateKeyedValueSet( DataScope.RoamingUser, "DataStoreTest", "NUnit" ).SetValue( "General", "MyKey", "TestValue" );
            keyValue = DataRegistry.OpenKeyedValueSet( DataScope.RoamingUser, "DataStoreTest", "NUnit" ).GetValue( "General", "MyKey" );
            Assert.IsTrue( keyValue == "TestValue" );

            table = DataRegistry.OpenKeyedValueSet( DataScope.RoamingUser, "DataStoreTest", "NUnit" );
            table.SetValue( @"General\Settings", "SettingsKey", "SomeData" );
            keyValue = table.GetValue( @"General\Settings", "SettingsKey" );
            Assert.IsTrue( keyValue == "SomeData" );

			// Test file system
			DataRegistry.CreateKeyedValueSet( DataScope.FileSystem, FileSystemLocation, "NUnit" ).SetValue( "General", "MyKey", "TestValue" );
			keyValue = DataRegistry.OpenKeyedValueSet( DataScope.FileSystem, FileSystemLocation, "NUnit" ).GetValue( "General", "MyKey" );
			Assert.IsTrue( keyValue == "TestValue" );

			table = DataRegistry.OpenKeyedValueSet( DataScope.FileSystem, FileSystemLocation, "NUnit" );
			table.SetValue( @"General\Settings", "SettingsKey", "SomeData" );
			keyValue = table.GetValue( @"General\Settings", "SettingsKey" );
			Assert.IsTrue( keyValue == "SomeData" );

            Cleanup();
        }

        /// <summary>
        /// test setting and retrieving values through Key Value Sets
        /// </summary>
        [Test]
        public void TestSetAndGetKeyValueSets()
        {
            // Test all users
            IKeyedValues table = DataRegistry.CreateKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUnit" );

            DataStoreKeyValueSet[] keyValueSet = new DataStoreKeyValueSet[3];
            keyValueSet[0] = new DataStoreKeyValueSet( "One", "�" );
            keyValueSet[1] = new DataStoreKeyValueSet( "Two", "2" );
            keyValueSet[2] = new DataStoreKeyValueSet( "Three", "3" );

            table.SetKeyValues( @"General\Settings", keyValueSet );

            IKeyValueSet[] retrievedSets = table.GetAllKeyValueSets( @"General\Settings" );
            Assert.IsTrue( retrievedSets.Length == 3 );

            // Test current user
            table = DataRegistry.CreateKeyedValueSet( DataScope.CurrentUser, "DataStoreTest", "NUnit" );

            keyValueSet = new DataStoreKeyValueSet[3];
            keyValueSet[0] = new DataStoreKeyValueSet( "One", "1" );
            keyValueSet[1] = new DataStoreKeyValueSet( "Two", "2" );
            keyValueSet[2] = new DataStoreKeyValueSet( "Three", "3" );

            table.SetKeyValues( @"General\Settings", keyValueSet );

            retrievedSets = table.GetAllKeyValueSets( @"General\Settings" );
            Assert.IsTrue( retrievedSets.Length == 3 );

            // Test roaming user
            table = DataRegistry.CreateKeyedValueSet( DataScope.RoamingUser, "DataStoreTest", "NUnit" );

            keyValueSet = new DataStoreKeyValueSet[3];
            keyValueSet[0] = new DataStoreKeyValueSet( "One", "1" );
            keyValueSet[1] = new DataStoreKeyValueSet( "Two", "2" );
            keyValueSet[2] = new DataStoreKeyValueSet( "Three", "3" );

            table.SetKeyValues( @"General\Settings", keyValueSet );

            retrievedSets = table.GetAllKeyValueSets( @"General\Settings" );
            Assert.IsTrue( retrievedSets.Length == 3 );

			// Test file system
			table = DataRegistry.CreateKeyedValueSet( DataScope.FileSystem, FileSystemLocation, "NUnit" );

			keyValueSet = new DataStoreKeyValueSet[3];
			keyValueSet[0] = new DataStoreKeyValueSet( "One", "1" );
			keyValueSet[1] = new DataStoreKeyValueSet( "Two", "2" );
			keyValueSet[2] = new DataStoreKeyValueSet( "Three", "3" );

			table.SetKeyValues( @"General\Settings", keyValueSet );

			retrievedSets = table.GetAllKeyValueSets( @"General\Settings" );
			Assert.IsTrue( retrievedSets.Length == 3 );

            Cleanup();
        }

        /// <summary>
        /// Test the Create, Remove and contains key method on a data table
        /// </summary>
        [Test]
        public void TestCreateRemoveAndContainsKey()
        {
            // Test all users
            IKeyedValues table = DataRegistry.CreateKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUnit" );
            bool contains = table.Contains( @"General\Settings\Temp", "NewKey" );
            Assert.IsTrue( contains == false );
            table.CreateKey( @"General\Settings\Temp", "NewKey" );
            contains = table.Contains( @"General\Settings\Temp", "NewKey" );
            Assert.IsTrue( contains == true );

            table.RemoveKey( @"General\Settings\Temp", "NewKey" );
            contains = table.Contains( @"General\Settings\Temp", "NewKey" );
            Assert.IsTrue( contains == false );

            // Test current user
            table = DataRegistry.CreateKeyedValueSet( DataScope.CurrentUser, "DataStoreTest", "NUnit" );
            contains = table.Contains( @"General\Settings\Temp", "NewKey" );
            Assert.IsTrue( contains == false );
            table.CreateKey( @"General\Settings\Temp", "NewKey" );
            contains = table.Contains( @"General\Settings\Temp", "NewKey" );
            Assert.IsTrue( contains == true );

            table.RemoveKey( @"General\Settings\Temp", "NewKey" );
            contains = table.Contains( @"General\Settings\Temp", "NewKey" );
            Assert.IsTrue( contains == false );

            // Test roaming user
            table = DataRegistry.CreateKeyedValueSet( DataScope.RoamingUser, "DataStoreTest", "NUnit" );
            contains = table.Contains( @"General\Settings\Temp", "NewKey" );
            Assert.IsTrue( contains == false );
            table.CreateKey( @"General\Settings\Temp", "NewKey" );
            contains = table.Contains( @"General\Settings\Temp", "NewKey" );
            Assert.IsTrue( contains == true );

            table.RemoveKey( @"General\Settings\Temp", "NewKey" );
            contains = table.Contains( @"General\Settings\Temp", "NewKey" );
            Assert.IsTrue( contains == false );

			// Test file system
			table = DataRegistry.CreateKeyedValueSet( DataScope.FileSystem, FileSystemLocation, "NUnit" );
			contains = table.Contains( @"General\Settings\Temp", "NewKey" );
			Assert.IsTrue( contains == false );
			table.CreateKey( @"General\Settings\Temp", "NewKey" );
			contains = table.Contains( @"General\Settings\Temp", "NewKey" );
			Assert.IsTrue( contains == true );

			table.RemoveKey( @"General\Settings\Temp", "NewKey" );
			contains = table.Contains( @"General\Settings\Temp", "NewKey" );
			Assert.IsTrue( contains == false );

            Cleanup();
        }

        /// <summary>
        /// Test creating and accessing an encrypted data store
        /// </summary>
        [Test]
        public void TestEncryptedDataTable()
        {
            DataRegistry.CreateEncryptedKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUnit" ).SetValue( "General", "MyKey", "TestValue" );
            string keyValue = DataRegistry.OpenKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUnit" ).GetValue( "General", "MyKey" );
            Assert.IsTrue( keyValue == "TestValue" );

            IKeyedValues table = DataRegistry.OpenKeyedValueSet( DataScope.AllUsers, "DataStoreTest", "NUnit" );
            table.SetValue( @"General\Settings", "SettingsKey", "SomeData" );
            keyValue = table.GetValue( @"General\Settings", "SettingsKey" );
            Assert.IsTrue( keyValue == "SomeData" );

            Cleanup();
        }

        /// <summary>
        /// Cleanup test data
        /// </summary>
        private void Cleanup()
        {
            DataRegistry.RemoveAllData( "DataStoreTest" );
            Assert.IsTrue( !Directory.Exists( string.Format(@"{0}\DataStoreTest", LibraryManager.SharedConfigLocation ) ) );

			if ( Directory.Exists( FileSystemLocation ) )
				Directory.Delete( FileSystemLocation, true );

			Assert.IsTrue( !Directory.Exists( FileSystemLocation ) );
        }
	}
}
#endif
