/*=====================================================================

  File:        PipeConnection.cs

=====================================================================*/

using System;
using System.Diagnostics;
using System.Security;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Serialization;
using System.IO;
using System.Text;
using System.Collections;
using System.Threading;
using System.Globalization;
using System.Net;
using System.Configuration;

using Sage.Diagnostics;

namespace Sage.Remoting
{
    internal sealed class PipeConnection : IDisposable
    {
        private IntPtr _handle;
        private String _pipeName;

        private int _lastTimeAccessed = -1;
        private static int _defaultAgeLastTimeAccessed = 30000; // 30 seconds
        private static Hashtable _remoteMachineMap;

        private const String _channelScheme = @"pipe://";
        private const String    _serverMachineRemappingPrefix = "Sage.Remoting.PipeConnection.ServerMachineRemapping:";


		// Default max. retries is 30...based on emprical testing.  Overridable via "MaxRetries" setting in .config file.
		private static int _maxRetries = 30;

        // Output information...
        private int _read;
        private int _written;
        private BinaryWriter _writer;
        private BinaryReader _reader;
        private bool _disposed;
#if(!BLOCKING)
        ManualResetEvent _overlappedEvent;
        PipeNative.OVERLAPPED _overlapped;
        IntPtr _unmanagedOverlappedPointer;
#endif
        static PipeConnection()
        {
            _remoteMachineMap = new Hashtable();
            foreach(string key in ConfigurationSettings.AppSettings.AllKeys)
            { 
                if(key.StartsWith(_serverMachineRemappingPrefix, StringComparison.InvariantCultureIgnoreCase))
                {
                    VerboseTrace.WriteLine(null, "Adding server machine remapping to '{0}' from configuration setting '{1}'", ConfigurationSettings.AppSettings[key], key);
                    _remoteMachineMap.Add(key.ToLowerInvariant(), ConfigurationSettings.AppSettings[key].ToLowerInvariant());
                }
            }
        }

        public PipeConnection(String machineName, String pipeName, bool create, IntPtr pipeSecurityDescriptor)
        {
            _disposed = false;

            _pipeName = String.Format("\\\\{0}\\pipe\\{1}", machineName, pipeName);


#if(!BLOCKING)
            _overlappedEvent = new ManualResetEvent(false);
            _overlapped = new PipeNative.OVERLAPPED();
            _overlapped.hEvent = _overlappedEvent.Handle;
            _unmanagedOverlappedPointer = Marshal.AllocHGlobal(Marshal.SizeOf(_overlapped));
            PipeNative.ZeroMemory(_unmanagedOverlappedPointer, Marshal.SizeOf(_overlapped));
            Marshal.StructureToPtr(_overlapped, _unmanagedOverlappedPointer, true);
#endif

			CheckForMaxRetriesOverride();

            // Try to open the named pipe:
            if(create)
            {
                Create(pipeSecurityDescriptor);
            }
            else
            {
                Connect();
            }

            _read = _written = 0;

            GC.KeepAlive(this); // prevent any possibility of "this" being finalized (and unmanaged handles being closed) until after PInvoke call(s) complete
        }

		private void CheckForMaxRetriesOverride()
		{
			try
			{
				string maxRetriesOverride = ConfigurationSettings.AppSettings[ "MaxRetries" ];
				if( maxRetriesOverride != null &&
					maxRetriesOverride.Length > 0 )
				{
					_maxRetries = Convert.ToInt32( maxRetriesOverride, CultureInfo.InvariantCulture );
				}
			}
			catch( Exception exc )
			{
				string errMsg = string.Format(
					Thread.CurrentThread.CurrentCulture,
					"Caught exception while retrieving MaxRetries override:  {0}",
					exc.Message );
				VerboseTrace.WriteLine( null, errMsg );
			}
		}

        public void UpdateLastTimeAccessed()
        {
            VerifyNotDisposed();

            _lastTimeAccessed = Environment.TickCount;
        }

        public bool IsConnectionStale()
        {
            VerifyNotDisposed();

            long now = Environment.TickCount;
            long result = now - _lastTimeAccessed;

            // Did we wrap 24.9 days ?
            if(result < 0)
            {
                result = (Int32.MaxValue - _lastTimeAccessed) + now;
            }

            // is stale connection
            return result > _defaultAgeLastTimeAccessed;
        }

#if(BLOCKING)        
        // FC:  Changed this so I could stop blocking in
        // WaitForConnect() called from server listening thread.
        // Otherwise I get an CannotUnloadAppDomainException because
        // the pipe thread is still waiting.

        public void Connect()
#else
        private void Connect()
#endif
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(this, "=> Connect");
            try
            {
				for( int i = 0; i < _maxRetries; i++ )
                {
					VerboseTrace.WriteLine( this, "WaitNamedPipe({0}) attempt {1} of {2}", _pipeName, i + 1, _maxRetries );

                    // There are multiple reasons why we may not be able to connect to the server pipe:
                    //   1) the server machine is not accessible (it is off or the network is disabled)
                    //   2) the server machine is accessible, but there is no server pipe instance created
                    //   3) the server machine is accessible, and at least one server pipe instance has been created, but it is in use
                    //
                    // WaitNamedPipe can block the first time it attempts to connect with a server.  Empirical
                    // data shows that, if the server is currently down (but it was valid at some point, then
                    // the amount of time this block takes may be non-trivial (e.g., 25 seconds).  After failing
                    // to connect to a down server (i.e., ERROR_BAD_NETPATH).  Then future attempts to wait seem
                    // to take substantially less time.
                    if(PipeNative.WaitNamedPipe(_pipeName, PipeNative.NMPWAIT_USE_DEFAULT_WAIT)) // use timeout value specified by server in call to CreateNamedPipe
                    {
                        VerboseTrace.WriteLine(this, "WaitNamedPipe({0}) succeeded;  attempt to CreateFile", _pipeName);

                        _handle = PipeNative.CreateFile(_pipeName,
                            PipeNative.GENERIC_READ | PipeNative.GENERIC_WRITE,
                            0,
                            IntPtr.Zero,
                            PipeNative.OPEN_EXISTING,
#if(BLOCKING)
                            0,
#else
 PipeNative.FILE_FLAG_OVERLAPPED,
#endif
 0);

                        VerboseTrace.WriteLine(this, "   {1} = CreateFile({0})", _pipeName, _handle);

                        if(_handle != (IntPtr) PipeNative.INVALID_HANDLE_VALUE)
                        {
                            return;
                        }

                        VerboseTrace.WriteLine(this, "CreateFile({0}) failed;  GetLastWin32Error()={1}", _pipeName, Marshal.GetLastWin32Error());
                    }
                    else
                    {
                        VerboseTrace.WriteLine(this, "WaitNamedPipe({0}) attempt failed;  GetLastWin32Error()={1}", _pipeName, Marshal.GetLastWin32Error());
                    }
                }

				VerboseTrace.WriteLine( this, "WaitNamedPipe({0}) retry limit {1} exceeded", _pipeName, _maxRetries );

                throw new PipeIOException(string.Format(CultureInfo.InvariantCulture, Strings.FailedToConnectToServerPipeFormat, _pipeName));
            }
            finally
            {
                VerboseTrace.WriteLine(this, "<= Connect");
            }
        }

        private void Create(IntPtr securityAttributes)
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(this, "=> CreateNamedPipe");
            try
            {

                if (securityAttributes == IntPtr.Zero)
                {
                    securityAttributes = SecurityAttributesBuilder.AllowAnonymousReadWriteAccessSecurityAttributes;
                }

                uint DEFAULT_WAIT_NAMED_PIPE_TIMEOUT = 10000;  // the amount of time (ms) a client-side call to WaitNamedPipe should wait for a server pipe to open up
                _handle = PipeNative.CreateNamedPipe(_pipeName,
#if(BLOCKING)
                PipeNative.PIPE_ACCESS_DUPLEX,
#else
 PipeNative.PIPE_ACCESS_DUPLEX | PipeNative.FILE_FLAG_OVERLAPPED,
#endif
 PipeNative.PIPE_TYPE_BYTE | PipeNative.PIPE_READMODE_BYTE | PipeNative.PIPE_WAIT,
                    PipeNative.PIPE_UNLIMITED_INSTANCES,
                    8192,
                    8192,
                    DEFAULT_WAIT_NAMED_PIPE_TIMEOUT,
                    securityAttributes);
                VerboseTrace.WriteLine(this, "   {1} = CreateNamedPipe({0})", _pipeName, _handle);

                if(_handle == (IntPtr) PipeNative.INVALID_HANDLE_VALUE)
                {
                    throw new PipeIOException(string.Format(CultureInfo.InvariantCulture, Strings.CreateNamedPipeFailedFormat, _pipeName, Marshal.GetLastWin32Error()));
                }
            }
            finally
            {
                VerboseTrace.WriteLine(this, "<= CreateNamedPipe");
            }
        }



        //
        // Sending (writing) functions
        //
        public void BeginWriteMessage()
        {
            VerifyNotDisposed();

            _writer = new BinaryWriter(new MemoryStream(128), Encoding.UTF8);
        }

        public void Write(byte[] buffer)
        {
            VerifyNotDisposed();

            Write(buffer, buffer.Length);
        }

        public void Write(byte[] buffer, int length)
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(null, _handle + "> Write buffer " + length);

            _writer.Write(length);
            _writer.Write(buffer);

            _written += length;

            VerboseTrace.WriteLine(null, _handle + ">\t\twritten = " + _written);
            VerboseTrace.WriteLine(null, _handle + "> Write finished.");
        }

        public void Write(ushort val)
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(null, _handle + "> Write ushort " + val);
            _writer.Write(val);
        }

        public void Write(int val)
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(null, _handle + "> Write int " + val);
            _writer.Write(val);
        }

        public void Write(String str)
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(null, _handle + "> Write string " + str);

            if(str == null)
            {
                str = "";
            }

            _writer.Write(str); // Length prefixed string
        }

        public void Write(Stream str)
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(null, _handle + "> Write stream " + str.Length);

            int chunk = 128;
            long len = chunk;
            byte[] buffer = new byte[chunk];

            _writer.Write((int) (str.Length));

            while(len != 0)
            {
                len = str.Read(buffer, 0, chunk);
                if(len > 0)
                {
                    _writer.Write(buffer);
                }
            }
            VerboseTrace.WriteLine(null, _handle + "> Leaving Write stream ");

        }

        private static uint MESSAGE_BYTES_SIZE = 4;
        private static uint MAX_CHUNK_SIZE = UInt16.MaxValue;

        public void EndWriteMessage(WaitHandle stopWritingEvent)
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(this, "=> EndWriteMessage");

#if(BLOCKING)
            const int MaxChunkSize = UInt16.MaxValue;
            const uint MESSAGE_BYTES_SIZE  = 4;

            _writer.Flush();
            
            // how many total bytes to write
            long messageLength = _stream.Length;

            // return from WriteFile
            uint numBytesWritten = 0;

            // write the length first
            bool fOk = PipeNative.WriteFile(_handle,
                BitConverter.GetBytes(messageLength), 
                MESSAGE_BYTES_SIZE,
                out numBytesWritten,
                IntPtr.Zero);           
            if(fOk)
            {
                uint totalWritten = 0;
                long chunkSize = (messageLength > MaxChunkSize)? MaxChunkSize : messageLength;
                byte[] bytesToWrite = new byte[chunkSize];

                // set position to be safe
                _stream.Seek(0, SeekOrigin.Begin);

                while(fOk && totalWritten < messageLength)
                {
                    uint numBytesRead = (uint) _stream.Read(bytesToWrite, 0, (int) chunkSize);

                    fOk = PipeNative.WriteFile(_handle, 
                        bytesToWrite,
                        numBytesRead,
                        out numBytesWritten,
                        IntPtr.Zero);

                    totalWritten += numBytesWritten;
                }
            }

            if(!fOk)
            {
                throw new PipeIOException("Error writing to pipe " + _handle + ": error " + Marshal.GetLastWin32Error());
            }

            Flush();

            _stream = null;
            _writer = null;
#else
            _writer.Flush();

            // how many total bytes to write
            uint messageLength = Convert.ToUInt32(_writer.BaseStream.Length);
            VerboseTrace.WriteLine(this, "   messageLength={0}", messageLength);

            IntPtr unmanagedMessageLengthBytes = Marshal.AllocHGlobal((int) MESSAGE_BYTES_SIZE);
            PipeNative.ZeroMemory(unmanagedMessageLengthBytes, (int) MESSAGE_BYTES_SIZE);
            IntPtr unmanagedBytesToWrite = IntPtr.Zero;

            // return from WriteFile
            uint numBytesWritten = 0;


            WaitHandle[] waitHandles = null;
            bool expectedBytesWritten = false;
            try
            {
                waitHandles = new WaitHandle[2];
                waitHandles[0] = _overlappedEvent;
                waitHandles[1] = stopWritingEvent;

                // Write the size of the message
                VerboseTrace.WriteLine(this, "   1:WriteFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE);
                Marshal.Copy(BitConverter.GetBytes(messageLength), 0, unmanagedMessageLengthBytes, (int) MESSAGE_BYTES_SIZE);
                if(!PipeNative.WriteFile(_handle, unmanagedMessageLengthBytes, MESSAGE_BYTES_SIZE, out numBytesWritten, _unmanagedOverlappedPointer))
                {
                    VerboseTrace.WriteLine(this, "   1:WriteFile({0}, {1} bytes) returned false", _handle, MESSAGE_BYTES_SIZE);

                    int lastError = 0;
                    switch(lastError = Marshal.GetLastWin32Error())
                    {
                        case PipeNative.ERROR_IO_PENDING:
                            {
                                int waitAnyResult = WaitHandle.WaitAny(waitHandles, Timeout.Infinite, false);
                                switch(waitAnyResult)
                                {
                                    case 0: // _overlappedEvent
                                        if(!PipeNative.GetOverlappedResult(_handle, _unmanagedOverlappedPointer, out numBytesWritten, false))
                                        {
                                            lastError = Marshal.GetLastWin32Error();
                                            switch(lastError)
                                            {
                                                case PipeNative.ERROR_BROKEN_PIPE:
                                                    VerboseTrace.WriteLine(this, "   Broken pipe occurred during overlapped 1:WriteFile({0}, {1} bytes).  Exiting.", _handle, MESSAGE_BYTES_SIZE);
                                                    break;

                                                default:
                                                    VerboseTrace.WriteLine(this, "   Unhandled result '{2}' from GetOverlappedResult() for 1:WriteFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE, lastError);
                                                    break;
                                            }
                                        }
                                        else
                                        {
                                            if(MESSAGE_BYTES_SIZE == numBytesWritten)
                                            {
                                                VerboseTrace.WriteLine(this, "   Completed pending 1:WriteFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE);
                                                expectedBytesWritten = true;
                                            }
                                            else
                                            {
                                                VerboseTrace.WriteLine(this, "   Overlapped & pending 1:WriteFile({0}, {1} bytes) completed, but did not write expected number of bytes (expected={2}, written={3}).", _handle, MESSAGE_BYTES_SIZE, 4, numBytesWritten);
                                            }
                                        }
                                        break;

                                    case 1: // stopWritingEvent
                                        VerboseTrace.WriteLine(this, "   Received stopWritingEvent during pending 1:WriteFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE);
                                        PipeNative.CancelIo(_handle);
                                        break;

                                    default:
                                        VerboseTrace.WriteLine(this, "   Unhandled result '{0}' from 1:WaitHandle.WaitAny()", waitAnyResult);
                                        break;
                                }
                            }
                            break;

                        default:
                            VerboseTrace.WriteLine(this, "   Overlapped 1:WriteFile({0}, {1} bytes) failed with lastError={2}\n{3}", _handle, MESSAGE_BYTES_SIZE, lastError, (new System.Diagnostics.StackTrace()).ToString());
                            break;
                    }
                }
                else
                {
                    VerboseTrace.WriteLine(this, "   1:WriteFile({0}, {1} bytes) returned true", _handle, MESSAGE_BYTES_SIZE);

                    if(MESSAGE_BYTES_SIZE == numBytesWritten)
                    {
                        // Woohoo!  We got what we needed immediately!
                        VerboseTrace.WriteLine(this, "   Completed immediately 1:WriteFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE);
                        expectedBytesWritten = true;
                    }
                    else
                    {
                        VerboseTrace.WriteLine(this, "   Overlapped 1:WriteFile(2) returned true.  messageLength={0}, numBytesWritten={1}", MESSAGE_BYTES_SIZE, numBytesWritten);
                    }
                }

                if (!expectedBytesWritten)
                {
                    VerboseTrace.WriteLine(this, "   expected bytes not written!!! 1:WriteFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE);
                }

                if(expectedBytesWritten)
                {
                    uint totalWritten = 0;

                    // set position to be safe
                    _writer.BaseStream.Seek(0, SeekOrigin.Begin);


                    int unmanagedBytesToWriteAllocSize = 0;
                    while(expectedBytesWritten && totalWritten < messageLength)
                    {
                        if((messageLength - totalWritten) > MAX_CHUNK_SIZE)
                        {
                            VerboseTrace.WriteLine(this, "   remaining unwritten bytes (count={0}) of large message (messageLength={1}) will be written in {2} byte chunks", (messageLength - totalWritten), messageLength, MAX_CHUNK_SIZE);
                        }
                        uint chunkSize = ((messageLength - totalWritten) > MAX_CHUNK_SIZE) ? MAX_CHUNK_SIZE : (messageLength - totalWritten);
                        if(unmanagedBytesToWriteAllocSize != chunkSize)
                        {
                            if(unmanagedBytesToWrite != IntPtr.Zero)
                            {
                                Marshal.FreeHGlobal(unmanagedBytesToWrite);
                                unmanagedBytesToWrite = IntPtr.Zero;
                            }

                            unmanagedBytesToWrite = Marshal.AllocHGlobal((int) chunkSize);
                            PipeNative.ZeroMemory(unmanagedBytesToWrite, (int) chunkSize);
                            unmanagedBytesToWriteAllocSize = (int) chunkSize;
                        }

                        expectedBytesWritten = false;
                        numBytesWritten = 0;


                        byte[] bytesToWrite = new byte[chunkSize];
                        uint numBytesReadFromStream = (uint) _writer.BaseStream.Read(bytesToWrite, 0, (int) chunkSize);
                        Marshal.Copy(bytesToWrite, 0, unmanagedBytesToWrite, (int) numBytesReadFromStream);



                        // Write the size of the message
                        VerboseTrace.WriteLine(this, "   2:WriteFile({0}, {1} bytes)", _handle, numBytesReadFromStream);
                        if(!PipeNative.WriteFile(_handle, unmanagedBytesToWrite, numBytesReadFromStream, out numBytesWritten, _unmanagedOverlappedPointer))
                        {
                            VerboseTrace.WriteLine(this, "   2:WriteFile({0}, {1} bytes) returned false", _handle, numBytesReadFromStream);

                            int lastError = 0;
                            switch(lastError = Marshal.GetLastWin32Error())
                            {
                                case PipeNative.ERROR_IO_PENDING:
                                    {
                                        int waitAnyResult = WaitHandle.WaitAny(waitHandles, Timeout.Infinite, false);
                                        switch(waitAnyResult)
                                        {
                                            case 0: // _overlappedEvent
                                                if(!PipeNative.GetOverlappedResult(_handle, _unmanagedOverlappedPointer, out numBytesWritten, false))
                                                {
                                                    lastError = Marshal.GetLastWin32Error();
                                                    switch(lastError)
                                                    {
                                                        case PipeNative.ERROR_BROKEN_PIPE:
                                                            VerboseTrace.WriteLine(this, "   Broken pipe occurred during overlapped 2:WriteFile({0}, {1} bytes).  Exiting.", _handle, numBytesReadFromStream);
                                                            break;

                                                        default:
                                                            VerboseTrace.WriteLine(this, "   Unhandled result '{2}' from GetOverlappedResult() for 2:WriteFile(({0}, {1} bytes)", _handle, numBytesReadFromStream, lastError);
                                                            break;
                                                    }
                                                }
                                                else
                                                {
                                                    if(numBytesReadFromStream == numBytesWritten)
                                                    {
                                                        VerboseTrace.WriteLine(this, "   Completed pending 2:WriteFile({0}, {1} bytes)", _handle, numBytesReadFromStream);
                                                        expectedBytesWritten = true;
                                                    }
                                                    else
                                                    {
                                                        VerboseTrace.WriteLine(this, "   Overlapped & pending 2:WriteFile({0}, {1} bytes) completed, but did not write expected number of bytes (expected={2}, written={3}).", _handle, numBytesReadFromStream, messageLength, numBytesWritten);
                                                    }
                                                }
                                                break;

                                            case 1: // stopWritingEvent
                                                VerboseTrace.WriteLine(this, "   Received stopWritingEvent during pending 2:WriteFile({0}, {1} bytes)", _handle, numBytesReadFromStream);
                                                PipeNative.CancelIo(_handle);
                                                break;

                                            default:
                                                VerboseTrace.WriteLine(this, "   Unhandled result '{0}' from 2:WaitHandle.WaitAny()", waitAnyResult);
                                                break;
                                        }
                                    }
                                    break;

                                default:
                                    VerboseTrace.WriteLine(this, "   Overlapped 2:WriteFile({0}, {1} bytes) failed with lastError={2}\n{3}", _handle, numBytesReadFromStream, lastError, (new System.Diagnostics.StackTrace()).ToString());
                                    break;
                            }
                        }
                        else
                        {
                            VerboseTrace.WriteLine(this, "   2:WriteFile({0}, {1} bytes) returned true", _handle, numBytesReadFromStream);

                            if (numBytesReadFromStream == numBytesWritten)
                            {
                                // Woohoo!  We got what we needed immediately!
                                VerboseTrace.WriteLine(this, "   Completed immediately 2:WriteFile({0}, {1} bytes)", _handle, numBytesReadFromStream);
                                expectedBytesWritten = true;
                            }
                            else
                            {
                                VerboseTrace.WriteLine(this, "   Overlapped 2:WriteFile({0}, {1} bytes) returned true.  chunkSize={1}, numBytesWritten={2}", _handle, numBytesReadFromStream, numBytesReadFromStream, numBytesWritten);
                            }
                        }


                        if (numBytesReadFromStream >= numBytesWritten && numBytesWritten > 0)
                        {
                            expectedBytesWritten = true;
                        }

                        if(expectedBytesWritten)
                        {
                            totalWritten += numBytesWritten;
                        }
                    }
                }
            }
            finally
            {
                Marshal.FreeHGlobal(unmanagedMessageLengthBytes);
                unmanagedMessageLengthBytes = IntPtr.Zero;

                Marshal.FreeHGlobal(unmanagedBytesToWrite);
                unmanagedBytesToWrite = IntPtr.Zero;

                waitHandles = null;

                if(!expectedBytesWritten)
                {
                    throw new PipeIOException("Error writing to pipe " + _handle + ": error " + Marshal.GetLastWin32Error());
                }

                Flush();

                if (_writer != null)
                {
                    _writer.Close();
                    _writer = null;
                }
            }
#endif

            GC.KeepAlive(this); // prevent any possibility of "this" being finalized (and unmanaged handles being closed) until after PInvoke call(s) complete

            VerboseTrace.WriteLine(this, "<= EndWriteMessage");
        }

        public void BeginReadMessage(WaitHandle stopReadingEvent)
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(this, "=> BeginReadMessage");

#if(BLOCKING)

            uint numBytesRead = 0;
            byte[] messageLengthBytes = new byte[4];

            byte[] messageBytes = null;
            
            int messageLength = 0;
            int totalRead = 0;

            // Get the size of the message
            bool fOk = PipeNative.ReadFile(_handle,
                messageLengthBytes,
                4,
                out numBytesRead,
                IntPtr.Zero);

            if(fOk)
            {
                messageLength  = BitConverter.ToInt32(messageLengthBytes, 0);
                messageBytes = new byte[messageLength];

                while(fOk == true && totalRead < messageLength)
                {
                    byte[] tmpBytes = new byte[messageLength];
                    
                    fOk = PipeNative.ReadFile(_handle,
                        tmpBytes,
                        (uint) messageLength,
                        out numBytesRead,
                        IntPtr.Zero);
                    
                    int numRead = (int)numBytesRead; //ASH:BitConverter.ToInt32(numBytesRead, 0);
                    
                    for (int i = 0; i < numRead; i++)
                    {
                        messageBytes[totalRead + i] = tmpBytes[i];
                    }
                    totalRead += numRead;
                }
            }
            
            if(!fOk)
            {
                throw new PipeIOException("Error reading from pipe " + _handle + ": error " + Marshal.GetLastWin32Error());
            }

            _stream = new MemoryStream(messageBytes, false);
            _reader = new BinaryReader(_stream, Encoding.UTF8);
#else

            uint numBytesRead;
            IntPtr unmanagedMessageLengthBytes = Marshal.AllocHGlobal((int) MESSAGE_BYTES_SIZE);
            PipeNative.ZeroMemory(unmanagedMessageLengthBytes, (int) MESSAGE_BYTES_SIZE);
            IntPtr unmanagedBytesToRead = IntPtr.Zero;

            byte[] messageBytes = null;

            uint messageLength = 0;


            WaitHandle[] waitHandles = null;
            bool expectedBytesRead = false;
            try
            {
                waitHandles = new WaitHandle[2];
                waitHandles[0] = _overlappedEvent;
                waitHandles[1] = stopReadingEvent;

                // Get the size of the message
                VerboseTrace.WriteLine(this, "   1:ReadFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE);
                if(!PipeNative.ReadFile(_handle, unmanagedMessageLengthBytes, MESSAGE_BYTES_SIZE, out numBytesRead, _unmanagedOverlappedPointer))
                {
                    VerboseTrace.WriteLine(this, "   1:ReadFile({0}, {1} bytes) returned false", _handle, MESSAGE_BYTES_SIZE);

                    int lastError = 0;
                    switch(lastError = Marshal.GetLastWin32Error())
                    {
                        case PipeNative.ERROR_IO_PENDING:
                            {
                                int waitAnyResult = WaitHandle.WaitAny(waitHandles, Timeout.Infinite, false);
                                switch(waitAnyResult)
                                {
                                    case 0: // _overlappedEvent
                                        if(!PipeNative.GetOverlappedResult(_handle, _unmanagedOverlappedPointer, out numBytesRead, false))
                                        {
                                            lastError = Marshal.GetLastWin32Error();
                                            switch(lastError)
                                            {
                                                case PipeNative.ERROR_BROKEN_PIPE:
                                                    VerboseTrace.WriteLine(this, "   Broken pipe occurred during overlapped 1:ReadFile({0}, {1} bytes).  Exiting.", _handle, MESSAGE_BYTES_SIZE);
                                                    break;

                                                default:
                                                    VerboseTrace.WriteLine(this, "   Unhandled result '{2}' from GetOverlappedResult() for 1:ReadFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE, lastError);
                                                    break;
                                            }
                                        }
                                        else
                                        {
                                            if(MESSAGE_BYTES_SIZE == numBytesRead)
                                            {
                                                VerboseTrace.WriteLine(this, "   Completed pending 1:ReadFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE);
                                                expectedBytesRead = true;
                                            }
                                            else
                                            {
                                                VerboseTrace.WriteLine(this, "   Overlapped & pending 1:ReadFile({0}, {1} bytes) completed, but did not read expected number of bytes (expected={2}, read={3}).", _handle, MESSAGE_BYTES_SIZE, MESSAGE_BYTES_SIZE, numBytesRead);
                                            }
                                        }
                                        break;

                                    case 1: // stopReadingEvent
                                        VerboseTrace.WriteLine(this, "   Received stopReadingEvent during pending 1:ReadFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE);
                                        PipeNative.CancelIo(_handle);
                                        break;

                                    default:
                                        VerboseTrace.WriteLine(this, "   Unhandled result '{0}' from 1:WaitHandle.WaitAny()", waitAnyResult);
                                        break;
                                }
                            }
                            break;

                        default:
                            VerboseTrace.WriteLine(this, "   Overlapped 1:ReadFile({0}, {1} bytes) failed with lastError={2}\n{3}", _handle, MESSAGE_BYTES_SIZE, lastError, (new System.Diagnostics.StackTrace()).ToString());
                            break;
                    }
                }
                else
                {
                    VerboseTrace.WriteLine(this, "   1:ReadFile({0}, {1} bytes) returned true", _handle, MESSAGE_BYTES_SIZE);

                    if(MESSAGE_BYTES_SIZE == numBytesRead)
                    {
                        // Woohoo!  We got what we needed immediately!
                        VerboseTrace.WriteLine(this, "   Completed immediately 1:ReadFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE);
                        expectedBytesRead = true;
                    }
                    else
                    {
                        VerboseTrace.WriteLine(this, "   Overlapped 1:ReadFile({0}, {1} bytes) returned true.  messageLength={0}, numBytesRead={1}", _handle, MESSAGE_BYTES_SIZE, MESSAGE_BYTES_SIZE, numBytesRead);
                    }
                }


                if(!expectedBytesRead)
                {
                    VerboseTrace.WriteLine(this, "   expected bytes not read!!! 1:ReadFile({0}, {1} bytes)", _handle, MESSAGE_BYTES_SIZE);
                }


                if(expectedBytesRead)
                {
                    byte[] messageLengthBytes = new byte[MESSAGE_BYTES_SIZE];
                    Marshal.Copy(unmanagedMessageLengthBytes, messageLengthBytes, 0, (int) MESSAGE_BYTES_SIZE);

                    uint totalRead = 0;
                    messageLength = BitConverter.ToUInt32(messageLengthBytes, 0);
                    VerboseTrace.WriteLine(this, "   messageLength={0}", messageLength);
                    messageBytes = new byte[messageLength];

                    int unmanagedBytesToReadAllocSize = 0;
                    while(expectedBytesRead && totalRead < messageLength)
                    {
                        if((messageLength - totalRead) > MAX_CHUNK_SIZE)
                        {
                            VerboseTrace.WriteLine(this, "   remaining unread bytes (count={0}) of large message (messageLength={1}) will be read in {2} byte chunks", (messageLength - totalRead), messageLength, MAX_CHUNK_SIZE);
                        }
                        uint chunkSize = ((messageLength - totalRead) > MAX_CHUNK_SIZE) ? MAX_CHUNK_SIZE : (messageLength - totalRead);
                        if(unmanagedBytesToReadAllocSize != chunkSize)
                        {
                            if(unmanagedBytesToRead != IntPtr.Zero)
                            {
                                Marshal.FreeHGlobal(unmanagedBytesToRead);
                                unmanagedBytesToRead = IntPtr.Zero;
                            }

                            unmanagedBytesToRead = Marshal.AllocHGlobal((int) chunkSize);
                            PipeNative.ZeroMemory(unmanagedBytesToRead, (int) chunkSize);
                            unmanagedBytesToReadAllocSize = (int) chunkSize;
                        }

                        expectedBytesRead = false;
                        numBytesRead = 0;

                        // Get the the message itself
                        VerboseTrace.WriteLine(this, "   2:ReadFile({0}, {1} bytes)", _handle, chunkSize);
                        if(!PipeNative.ReadFile(_handle, unmanagedBytesToRead, (uint) chunkSize, out numBytesRead, _unmanagedOverlappedPointer))
                        {
                            VerboseTrace.WriteLine(this, "   2:ReadFile({0}, {1} bytes) returned false", _handle, chunkSize);

                            int lastError = 0;
                            switch(lastError = Marshal.GetLastWin32Error())
                            {
                                case PipeNative.ERROR_IO_PENDING:
                                    {
                                        int waitAnyResult = WaitHandle.WaitAny(waitHandles, Timeout.Infinite, false);
                                        switch(waitAnyResult)
                                        {
                                            case 0: // _overlappedEvent
                                                if(!PipeNative.GetOverlappedResult(_handle, _unmanagedOverlappedPointer, out numBytesRead, false))
                                                {
                                                    lastError = Marshal.GetLastWin32Error();
                                                    switch(lastError)
                                                    {
                                                        case PipeNative.ERROR_BROKEN_PIPE:
                                                            VerboseTrace.WriteLine(this, "   Broken pipe occurred during overlapped 2:ReadFile({0}, {1} bytes).  Exiting.", _handle, chunkSize);
                                                            break;

                                                        default:
                                                            VerboseTrace.WriteLine(this, "   Unhandled result '{2}' from GetOverlappedResult() for 2:ReadFile(({0}, {1} bytes)", _handle, chunkSize, lastError);
                                                            break;
                                                    }
                                                }
                                                else
                                                {
                                                    if(chunkSize == numBytesRead)
                                                    {
                                                        VerboseTrace.WriteLine(this, "   Completed pending 2:ReadFile({0}, {1} bytes)", _handle, chunkSize);
                                                        expectedBytesRead = true;
                                                    }
                                                    else
                                                    {
                                                        VerboseTrace.WriteLine(this, "   Overlapped & pending 2:ReadFile({0}, {1} bytes) completed, but did not read expected number of bytes (expected={2}, read={3}).", _handle, chunkSize, messageLength, numBytesRead);
                                                    }
                                                }
                                                break;

                                            case 1: // stopReadingEvent
                                                VerboseTrace.WriteLine(this, "   Received stopReadingEvent during pending 2:ReadFile({0}, {1} bytes)", _handle, chunkSize);
                                                PipeNative.CancelIo(_handle);
                                                break;

                                            default:
                                                VerboseTrace.WriteLine(this, "   Unhandled result '{0}' from 2:WaitHandle.WaitAny()", waitAnyResult);
                                                break;
                                        }
                                    }
                                    break;

                                default:
                                    VerboseTrace.WriteLine(this, "   Overlapped 2:ReadFile({0}, {1} bytes) failed with lastError={2}\n{3}", _handle, chunkSize, lastError, (new System.Diagnostics.StackTrace()).ToString());
                                    break;
                            }
                        }
                        else
                        {
                            VerboseTrace.WriteLine(this, "   2:ReadFile({0}, {1} bytes) returned true", _handle, chunkSize);

                            if(chunkSize == numBytesRead)
                            {
                                // Woohoo!  We got what we needed immediately!
                                VerboseTrace.WriteLine(this, "   Completed immediately 2:ReadFile({0}, {1} bytes)", _handle, chunkSize);
                                expectedBytesRead = true;
                            }
                            else
                            {
                                VerboseTrace.WriteLine(this, "   Overlapped 2:ReadFile({0}, {1} bytes) returned true.  chunkSize={1}, numBytesRead={2}", _handle, chunkSize, chunkSize, numBytesRead);
                            }
                        }


                        if(chunkSize >= numBytesRead && numBytesRead > 0)
                        {
                            expectedBytesRead = true;
                        }

                        if(expectedBytesRead)
                        {
                            Marshal.Copy(unmanagedBytesToRead, messageBytes, (int) totalRead, (int) numBytesRead);
                            totalRead += numBytesRead;
                        }
                    }
                }
            }
            finally
            {
                Marshal.FreeHGlobal(unmanagedMessageLengthBytes);
                unmanagedMessageLengthBytes = IntPtr.Zero;

                Marshal.FreeHGlobal(unmanagedBytesToRead);
                unmanagedBytesToRead = IntPtr.Zero;

                waitHandles = null;

                if(!expectedBytesRead)
                {
                    throw new PipeIOException("Error reading from pipe " + _handle + ": error " + Marshal.GetLastWin32Error());
                }

                if (_reader != null)
                {
                    _reader.Close();
                    _reader = null;
                }
                _reader = new BinaryReader(new MemoryStream(messageBytes, false), Encoding.UTF8);
            }
#endif
            GC.KeepAlive(this); // prevent any possibility of "this" being finalized (and unmanaged handles being closed) until after PInvoke call(s) complete

            VerboseTrace.WriteLine(this, "<= BeginReadMessage");
        }

        public Stream ReadStream()
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(null, _handle + "> Read stream...");

            int length = _reader.ReadInt32();
            VerboseTrace.WriteLine(null, _handle + "> Read stream len " + length);

            byte[] buffer = _reader.ReadBytes(length);

            MemoryStream ms = new MemoryStream(buffer, false);
            return (ms);
        }

        public byte[] ReadBytes(int cb)
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(null, _handle + "> Reading bytes len " + cb);
            return _reader.ReadBytes(cb);
        }

        public ushort ReadUShort()
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(null, _handle + "> Reading ushort...");
            return _reader.ReadUInt16();
        }

        public int ReadInt()
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(null, _handle + "> Reading int...");
            return _reader.ReadInt32();
        }

        public String ReadString()
        {
            VerifyNotDisposed();

            VerboseTrace.WriteLine(null, _handle + "> Reading string...");
            return _reader.ReadString();
        }

        public void EndReadMessage()
        {
            VerifyNotDisposed();

            if (_reader != null)
            {
                _reader.Close();
                _reader = null;
            }
        }

        private const ushort HeaderMarker = 0xFFA1;
        private const ushort HeaderEndMarker = 0xFFA2;

        internal static bool IsRemoteMachine(string machineName)
        {
            VerboseTrace.WriteLine(null, "IsRemoteMachine({0})", machineName);

            bool result = true;

            // Environment.MachineName is the same as the NetBIOS name of local computer (the COMPUTERNAME environment
            // variable) not the DNS host name.  This value is always truncated to 15 characters.  Consequently, we
            // cannot compare this against our DNS host name.  Dns.GetHostName() give us what we want.

            // We use "Dns.GetHostEntry(Dns.GetHostName()).HostName" to get the fully-qualified domain name (a.k.a. FQDN)

            if (String.IsNullOrEmpty(machineName) ||
                (string.Compare(machineName, ".", true) == 0) ||
                (string.Compare(machineName, "localhost", true) == 0) ||
                (string.Compare(machineName, Environment.MachineName, true) == 0) ||
                (string.Compare(machineName, Dns.GetHostName(), true) == 0) ||
                (string.Compare(machineName, Dns.GetHostEntry(Dns.GetHostName()).HostName, true) == 0) ||
                IsLocalMachineIpAddress(machineName))
            {
                result = false;
            }

            return result;
        }

        private static bool IsLocalMachineIpAddress(string address)
        {
            bool result = false;

            if(string.Compare(address, IPAddress.Loopback.ToString(), true) == 0 ||
               string.Compare(address, IPAddress.IPv6Loopback.ToString(), true) == 0)
            {
                result = true;
            }

            if(!result)
            {
                IPAddress ipAddress = null;
                if(IPAddress.TryParse(address, out ipAddress))
                {
                    IPHostEntry hostInfo = Dns.GetHostEntry(Dns.GetHostName());
                    IPAddress[] ipAddresses = hostInfo.AddressList;
                    for(int i = 0 ; i < ipAddresses.Length && !result ; i++)
                    {
                        if(string.Compare(address, ipAddresses[i].ToString(), true) == 0)
                        {
                            result = true;
                        }
                    }
                }
            }

            return result;
        }


        internal static string BuildObjectUri(string machineName, string objUri)
        {
            string uri = objUri;
            if(IsRemoteMachine(machineName) == true)
            {
                uri = string.Format(@"{0}/{1}", machineName, objUri);
            }
            return uri;
        }

        internal static string Parse(string inUrl, out string machineName, out string objUri)
        {
            string pipeName = null;
            objUri = null;
            machineName = null;

            VerboseTrace.WriteLine(null, "Parse: IN: url = " + inUrl);

            if(inUrl.StartsWith(_channelScheme) == true)
            {
                string url = inUrl.Substring(_channelScheme.Length);
                string[] toks = url.Split('/');
                if(toks.Length == 1)
                {
                    machineName = ".";
                    pipeName = toks[0];
                }
                else if(toks.Length == 2)
                {
                    if(toks[1].ToUpper() == "AUTO")
                    {
                        machineName = toks[0];
                        pipeName = toks[1];
                    }
                    else
                    {
                        machineName = ".";
                        pipeName = toks[0];
                        objUri = toks[1];
                    }
                }
                else if(toks.Length == 3)
                {
                    machineName = toks[0];
                    pipeName = toks[1];
                    objUri = toks[2];
                }
            }

            if (!IsRemoteMachine(machineName))
            {
                machineName = ".";
            }
            else
            {
                string remappingKey = string.Format("{0}{1}", _serverMachineRemappingPrefix, machineName).ToLowerInvariant();
                if(_remoteMachineMap.Contains(remappingKey))
                {
                    VerboseTrace.WriteLine(null, "machineName '{0}' has been remapped via configuration to '{1}'", machineName, _remoteMachineMap[remappingKey]);
                    machineName = (string) _remoteMachineMap[remappingKey];
                }
            }

            VerboseTrace.WriteLine(null, "Parse: OUT: pipeName = " + pipeName + ", objuri = " + objUri);

            return pipeName;
        }

        public void WriteHeaders(String uri, ITransportHeaders head)
        {
            VerifyNotDisposed();

            // Write the URI
            Write(uri);

            // Since we cannot count the headers, just begin writing counted strings.
            // We'll write a terminator marker at the end.        

            foreach(DictionaryEntry header in head)
            {
                String headerName = (String) header.Key;

                //if(!headerName.StartsWith("__")) // exclude special headers
                if((headerName.Length < 2) || ((headerName[0] != '_') && (headerName[1] != '_')))
                {
                    Write(PipeConnection.HeaderMarker);

                    Write(headerName);
                    Write(header.Value.ToString());
                }
            }

            Write(PipeConnection.HeaderEndMarker);
        }

        public ITransportHeaders ReadHeaders()
        {
            if(_disposed)
            {
                throw new ObjectDisposedException("PipeConnection");
            }

            TransportHeaders headers = new TransportHeaders();

            // read uri (and make sure that no channel specific data is present)
            String uri = ReadString();

            if(uri != null && uri.Length > 0)
            {
                String chanuri, objuri, machineName;
                chanuri = PipeConnection.Parse(uri, out machineName, out objuri);
                if(chanuri == null)
                {
                    objuri = uri;
                }
                headers[CommonTransportKeys.RequestUri] = objuri;
            }

            // read to end of headers  
            ushort marker = ReadUShort();
            while(marker == HeaderMarker)
            {
                String hname = ReadString();
                String hvalue = ReadString();

                headers[hname] = hvalue;

                marker = ReadUShort();
            }

            return headers;
        }

        //////////////////////////////////////////////////////////////

        public bool WaitForConnect(WaitHandle stopConnectEvent)
        {
            VerifyNotDisposed();

#if(BLOCKING)
            bool fRet = PipeNative.ConnectNamedPipe(_handle, IntPtr.Zero);
            VerboseTrace.WriteLine(this, "ConnectNamedPipe({0})", _handle);

            GC.KeepAlive(this); // prevent any possibility of "this" being finalized (and unmanaged handles being closed) until after PInvoke call(s) complete

            return fRet ? true : (Marshal.GetLastWin32Error() == PipeNative.ERROR_PIPE_CONNECTED);
#else

            bool result = false;

            ManualResetEvent overlappedConnectEvent = null;
            PipeNative.OVERLAPPED overlappedConnect = new PipeNative.OVERLAPPED();
            IntPtr unmanagedOverlappedConnectPointer = IntPtr.Zero;
            WaitHandle[] waitHandles = null;
            try
            {
                overlappedConnectEvent = new ManualResetEvent(false);
                overlappedConnect.hEvent = overlappedConnectEvent.Handle;
                unmanagedOverlappedConnectPointer = Marshal.AllocHGlobal(Marshal.SizeOf(overlappedConnect));
                PipeNative.ZeroMemory(unmanagedOverlappedConnectPointer, (Marshal.SizeOf(overlappedConnect)));
                Marshal.StructureToPtr(overlappedConnect, unmanagedOverlappedConnectPointer, true);

                waitHandles = new WaitHandle[2];
                waitHandles[0] = overlappedConnectEvent;
                waitHandles[1] = stopConnectEvent;

                // overlapped ConnectNamedPipe should return zero
                if(!PipeNative.ConnectNamedPipe(_handle, unmanagedOverlappedConnectPointer))
                {
                    int lastError = 0;
                    switch(lastError = Marshal.GetLastWin32Error())
                    {
                        case PipeNative.ERROR_IO_PENDING:
                            {
                                int waitAnyResult = WaitHandle.WaitAny(waitHandles, Timeout.Infinite, false);
                                switch(waitAnyResult)
                                {
                                    case 0: // overlappedConnectEvent
                                        uint dummy = 0;
                                        if(!PipeNative.GetOverlappedResult(_handle, unmanagedOverlappedConnectPointer, out dummy, false))
                                        {
                                            lastError = Marshal.GetLastWin32Error();
                                            switch(lastError)
                                            {
                                                case PipeNative.ERROR_BROKEN_PIPE:
                                                    VerboseTrace.WriteLine(this, "Broken pipe occurred during overlapped ConnectNamedPipe().  Exiting.", Marshal.GetLastWin32Error());
                                                    break;

                                                default:
                                                    VerboseTrace.WriteLine(this, "Unhandled result '{0}' from GetOverlappedResult() for ConnectNamedPipe()", Marshal.GetLastWin32Error());
                                                    break;
                                            }
                                        }
                                        else
                                        {
                                            result = true;
                                        }
                                        break;

                                    case 1: // stopConnectEvent
                                        PipeNative.CancelIo(_handle);
                                        break;

                                    default:
                                        VerboseTrace.WriteLine(this, "Unhandled result '{0}' from WaitHandle.WaitAny()", waitAnyResult);
                                        break;
                                }
                            }
                            break;

                        case PipeNative.ERROR_PIPE_CONNECTED:
                            // If a client connects before the function is called, the function returns zero
                            // and GetLastError returns ERROR_PIPE_CONNECTED. This can happen if a client
                            // connects in the interval between the call to CreateNamedPipe and the call to
                            // ConnectNamedPipe. In this situation, there is a good connection between client
                            // and server, even though the function returns zero.
                            result = true;
                            break;

                        default:
                            VerboseTrace.WriteLine(this, "Overlapped ConnectNamedPipe() failed with lastError={0}", lastError);
                            break;
                    }
                }
                else
                {
                    // Overlapped ConnectNamedPipe should return zero. 
                    VerboseTrace.WriteLine(this, "Overlapped ConnectNamedPipe() failed with lastError={0}", Marshal.GetLastWin32Error());
                }
            }
            finally
            {
                if(IntPtr.Zero != unmanagedOverlappedConnectPointer)
                {
                    Marshal.FreeHGlobal(unmanagedOverlappedConnectPointer);
                    unmanagedOverlappedConnectPointer = IntPtr.Zero;
                }

                waitHandles = null;
            }

            GC.KeepAlive(this); // prevent any possibility of "this" being finalized (and unmanaged handles being closed) until after PInvoke call(s) complete

            return result;
#endif
        }

        public void Flush()
        {
            VerifyNotDisposed();

            PipeNative.FlushFileBuffers(_handle);

            GC.KeepAlive(this); // prevent any possibility of "this" being finalized (and unmanaged handles being closed) until after PInvoke call(s) complete
        }

        // Destructor will run only if Dispose() is never called.
        ~PipeConnection()
        {
            Cleanup(false);
        }

        public void Dispose()
        {
            if(!_disposed)
            {
                Cleanup(true);
                _disposed = true;

                // Take yourself off the finalization queue to prevent
                // finalization from executing a second time.
                GC.SuppressFinalize(this);
            }
        }

        private void Cleanup(bool disposeManagedResources)
        {
            VerboseTrace.WriteLine(this, "=> Dispose");

            if(disposeManagedResources)
            {
                // dispose any managed resources here
                if(null != _reader)
                {
                    (_reader as IDisposable).Dispose();
                    _reader = null;
                }
                if(null != _writer)
                {
                    (_writer as IDisposable).Dispose();
                    _writer = null;
                }
            }

            // dispose any unmanaged resources here

            if(_handle != IntPtr.Zero)
            {
                Flush();
                VerboseTrace.WriteLine(this, "   DisconnectNamedPipe({0})", _handle);
                PipeNative.DisconnectNamedPipe(_handle);
                VerboseTrace.WriteLine(this, "   CloseHandle({0})", _handle);
                PipeNative.CloseHandle(_handle);

                _handle = IntPtr.Zero;
            }

#if(!BLOCKING)
            if(IntPtr.Zero != _unmanagedOverlappedPointer)
            {
                Marshal.FreeHGlobal(_unmanagedOverlappedPointer);
                _unmanagedOverlappedPointer = IntPtr.Zero;
            }
#endif
            VerboseTrace.WriteLine(this, "<= Dispose");
        }

        private void VerifyNotDisposed()
        {
            if(_disposed)
            {
                throw new ObjectDisposedException("PipeConnection");
            }
        }

    } // PipeConnection


    //////////////////////////////////////////////////////////////////////
    // Pool for PipeConnections
    //////////////////////////////////////////////////////////////////////

    internal sealed class PipeConnectionPoolManager
    {
        static bool s_initialized = false;
        static Timer s_timer;
        static int s_timerDueTime = 30000;

        static TimerCallback s_timerDelegate;
        static Hashtable s_poolInstances = new Hashtable();

        private PipeConnectionPoolManager()
        {
            // declare constuctor for static class as private so that instances cannot be created
        }

        private static void Init()
        {
            lock(s_poolInstances.SyncRoot)
            {
                if(s_initialized == false)
                {
                    // Setup timer
                    s_timerDelegate = new TimerCallback(PipeConnectionPoolManagerCallback);
                    s_timer = new Timer(s_timerDelegate, null, s_timerDueTime, 0);
                    s_initialized = true;
                    //VerboseTrace.WriteLine(this, "*** Pool Timer initialized.");
                }
            }
        }

        public static void Cleanup()
        {
            lock(s_poolInstances.SyncRoot)
            {
                if(s_initialized)
                {
                    // Cleanout cache items
                    foreach(DictionaryEntry entry in s_poolInstances)
                    {
                        PipeConnectionPool pool = (PipeConnectionPool) entry.Value;

                        lock(pool)
                        {
                            (pool as IDisposable).Dispose();
                        }
                    }
                    s_poolInstances.Clear();

                    // Stop timer
                    s_timer.Dispose();
                }
            }
        }

        private static void PipeConnectionPoolManagerCallback(Object state)
        {
            VerboseTrace.WriteLine(null, "PipeConnectionPoolManagerCallback");
            lock(s_poolInstances.SyncRoot)
            {
                foreach(DictionaryEntry entry in s_poolInstances)
                {
                    PipeConnectionPool pool = (PipeConnectionPool) entry.Value;

                    lock(pool)
                    {
                        pool.CloseStaleConnections();
                    }
                }
            }

            // Requeue timer

            s_timer = new Timer(s_timerDelegate, null, s_timerDueTime, 0);
        }

        //////////////////////////////////////////////////////////////

        public static PipeConnectionPool LookupPool(String key)
        {
            PipeConnectionPool pool;

            if(s_initialized == false)
            {
                Init();
            }

            lock(s_poolInstances.SyncRoot)
            {
                pool = (PipeConnectionPool) s_poolInstances[key];

                //VerboseTrace.WriteLine(this, "***{0} pool key: {1}", pool == null ? "Creating" : "Retrieving", key );

                if(pool == null)
                {
                    pool = new PipeConnectionPool(key);
                    s_poolInstances[key] = pool;
                }
            }

            return pool;
        }
    }

    internal sealed class PipeConnectionPool : IDisposable
    {
        String _key;
        public ArrayList _list;

        public PipeConnectionPool(String key)
        {
            _key = key;
            _list = new ArrayList();
        }

        private bool _disposed = false;

        // Destructor will run only if Dispose() is never called.
        ~PipeConnectionPool()
        {
            Cleanup(false);
        }

        public void Dispose()
        {
            if(!_disposed)
            {
                Cleanup(true);
                _disposed = true;

                // Take yourself off the finalization queue to prevent
                // finalization from executing a second time.
                GC.SuppressFinalize(this);
            }
        }

        private void Cleanup(bool disposeManagedResources)
        {
            if(disposeManagedResources)
            {
                // dispose any managed resources here
                lock(_list.SyncRoot)
                {
                    foreach(Object obj in _list)
                    {
                        (obj as IDisposable).Dispose();
                    }
                    _list.Clear();
                    _list = null;
                    _key = string.Empty;
                }
            }

            // dispose any unmanaged resources here
        }

        ////////////////////////////////////////////////////////////

        public void CloseStaleConnections()
        {
            VerifyNotDisposed();

            ArrayList activeConnections = new ArrayList();
            lock(_list.SyncRoot)
            {
                foreach(Object obj in _list)
                {
                    PipeConnection _pipe = (PipeConnection) obj;

                    if(_pipe.IsConnectionStale() == true)
                    {
                        //VerboseTrace.WriteLine(null, "Disposing of stale connection");

                        //VerboseTrace.WriteLine(null, "*** key: {0} - Disposing of stale connection", _key);
                        _pipe.Dispose();
                        _pipe = null;
                    }
                    else
                    {
                        activeConnections.Add(_pipe);
                    }

                }
                _list = activeConnections;
            }
            //VerboseTrace.WriteLine(null, "*** There are {0} pipe connections in pool for key {1}", _list.Count, _key);
        }


        public Object Obtain()
        {
            VerifyNotDisposed();

            Object obj = null;

            lock(_list.SyncRoot)
            {
                int count = _list.Count;
                if(count > 0)
                {
                    obj = _list[count - 1];
                    _list.RemoveAt(count - 1);
                }
            }
            return obj;
        }

        public void ReturnToPool(Object obj)
        {
            VerifyNotDisposed();

            lock(_list.SyncRoot)
            {
                PipeConnection _pipe = (PipeConnection) obj;
                _pipe.UpdateLastTimeAccessed();
                _list.Add(obj);
            }
        }
        private void VerifyNotDisposed()
        {
            if(_disposed)
            {
                throw new ObjectDisposedException("PipeConnectionPool");
            }
        }

    }

    //
    // Imported namedpipe entry points for p/invoke into native code.
    //

    [SuppressUnmanagedCodeSecurity]
    internal sealed class PipeNative
    {
        private const string KERNEL32 = "kernel32.dll";

        public const uint PIPE_ACCESS_OUTBOUND = 0x00000002;
        public const uint PIPE_ACCESS_DUPLEX = 0x00000003;
        public const uint PIPE_ACCESS_INBOUND = 0x00000001;

        public const uint FILE_FLAG_FIRST_PIPE_INSTANCE = 0x00080000;
        public const uint FILE_FLAG_WRITE_THROUGH = 0x80000000;
        public const uint FILE_FLAG_OVERLAPPED = 0x40000000;

        public const uint PIPE_WAIT = 0x00000000;
        public const uint PIPE_NOWAIT = 0x00000001;
        public const uint PIPE_READMODE_BYTE = 0x00000000;
        public const uint PIPE_READMODE_MESSAGE = 0x00000002;
        public const uint PIPE_TYPE_BYTE = 0x00000000;
        public const uint PIPE_TYPE_MESSAGE = 0x00000004;

        public const uint PIPE_CLIENT_END = 0x00000000;
        public const uint PIPE_SERVER_END = 0x00000001;

        public const uint PIPE_UNLIMITED_INSTANCES = 255;

        public const uint NMPWAIT_WAIT_FOREVER = 0xFFFFFFFF;
        public const uint NMPWAIT_NOWAIT = 0x00000001;
        public const uint NMPWAIT_USE_DEFAULT_WAIT = 0x00000000;

        public const uint GENERIC_READ = (0x80000000);
        public const uint GENERIC_WRITE = (0x40000000);
        public const uint GENERIC_EXECUTE = (0x20000000);
        public const uint GENERIC_ALL = (0x10000000);

        public const uint CREATE_NEW = 1;
        public const uint CREATE_ALWAYS = 2;
        public const uint OPEN_EXISTING = 3;
        public const uint OPEN_ALWAYS = 4;
        public const uint TRUNCATE_EXISTING = 5;

        public const int INVALID_HANDLE_VALUE = -1;

        public const int ERROR_FILE_NOT_FOUND = 2;
        public const int ERROR_BAD_NETPATH = 53;
        public const int ERROR_BROKEN_PIPE = 109;
        public const int ERROR_PIPE_BUSY = 231;
        public const int ERROR_NO_DATA = 232;
        public const int ERROR_PIPE_NOT_CONNECTED = 233;
        public const int ERROR_PIPE_CONNECTED = 535;
        public const int ERROR_PIPE_LISTENING = 536;
        public const int ERROR_IO_PENDING = 997;

        [DllImport(KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetOverlappedResult
            (
            IntPtr hFile,
            IntPtr lpOverlapped,
            out uint nNumberOfBytesTransferred,
            Boolean bWait
            );

        [DllImport(KERNEL32, SetLastError = true)]
        public static extern IntPtr CreateNamedPipe
            (
            String lpName,                     // pipe name
            uint dwOpenMode,                 // pipe open mode
            uint dwPipeMode,                 // pipe-specific modes
            uint nMaxInstances,              // maximum number of instances
            uint nOutBufferSize,             // output buffer size
            uint nInBufferSize,              // input buffer size
            uint nDefaultTimeOut,            // time-out interval
            IntPtr lpSecurityAttributes
            );

        [DllImport(KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool ConnectNamedPipe
            (
            IntPtr hNamedPipe,             // handle to named pipe
            IntPtr lpOverlapped            // overlapped structure
            );

        [DllImport(KERNEL32, SetLastError = true)]
        public static extern IntPtr CreateFile
            (
            String lpFileName,                  // file name
            uint dwDesiredAccess,             // access mode
            uint dwShareMode,                 // share mode
            IntPtr lpSecurityAttributes,        // SD
            uint dwCreationDisposition,       // how to create
            uint dwFlagsAndAttributes,        // file attributes
            uint hTemplateFile                // handle to template file
            );

        [DllImport(KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool ReadFile
            (
            IntPtr hFile,                      // handle to file
#if(BLOCKING)
            byte[] lpBuffer,
#else
            IntPtr lpBuffer,                   // data buffer
#endif
            uint nNumberOfBytesToRead,       // number of bytes to read
            out uint lpNumberOfBytesRead,        // number of bytes read
            IntPtr lpOverlapped                // overlapped buffer
            );


        [DllImport(KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool WriteFile
            (
            IntPtr hFile,                      // handle to file
#if(BLOCKING)
            byte[] lpBuffer,
#else
            IntPtr lpBuffer,                   // data buffer
#endif
            uint nNumberOfBytesToWrite,      // number of bytes to write
            out uint lpNumberOfBytesWritten,     // number of bytes written
            IntPtr lpOverlapped                // overlapped buffer
            );

        [DllImport(KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool WaitNamedPipe
            (
            String lpNamedPipeName,
            uint nTimeOut
            );

        [DllImport(KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool FlushFileBuffers(IntPtr hFile);

        [DllImport(KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool DisconnectNamedPipe(IntPtr hNamedPipe);

        [DllImport(KERNEL32, SetLastError = true)]
        public static extern bool SetNamedPipeHandleState
            (
            IntPtr hNamedPipe,
            ref int lpMode,
            IntPtr lpMaxCollectionCount,
            IntPtr lpCollectDataTimeout
            );

        [DllImport(KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool CloseHandle(IntPtr hObject);

        // TODO: should be using System.Threading.NativeOverlapped rather than declaring our own
        [StructLayout(LayoutKind.Sequential)]
        internal struct OVERLAPPED
        {
            internal UIntPtr Internal;
            internal UIntPtr InternalHigh;
            internal UInt32 Offset;
            internal UInt32 OffsetHigh;
            internal IntPtr hEvent;
        }

        [DllImport(KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool CancelIo(IntPtr hFile);

        [DllImport(KERNEL32, EntryPoint = "RtlZeroMemory", SetLastError = false)]
        internal static extern void ZeroMemory(IntPtr Destination, int Length);
    }

    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [TraceListenerIgnoreType]
    public class PipeIOException : RemotingException
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public PipeIOException(String message)
            : base(message)
        {
            VerboseTrace.WriteLine(this, string.Format(CultureInfo.InvariantCulture, "{0}:  {1}", this.GetType().FullName, message));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        protected PipeIOException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            VerboseTrace.WriteLine(this, string.Format(CultureInfo.InvariantCulture, "info={0}; context={1}", info.ToString(), context.ToString()));
        }
    }
}
