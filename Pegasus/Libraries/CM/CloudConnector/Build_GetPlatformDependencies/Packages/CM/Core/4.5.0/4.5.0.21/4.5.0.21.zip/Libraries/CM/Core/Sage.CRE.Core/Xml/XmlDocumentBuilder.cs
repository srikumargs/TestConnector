
// .Net References
using System;
using System.Xml;

namespace Sage.Xml
{
    /// ***************************************************
	/// <summary>
	/// A utillity class to help build Xml documents
	/// </summary>
	/// ***************************************************
	public class XmlDocumentBuilder
	{
        #region Fields

            /// <summary>
            /// The document to build
            /// </summary>
            public XmlDocument _document = null;

        #endregion

        #region Construction/Destruction

            /// ***************************************************
            /// <summary>
            /// Constructor
            /// </summary>
            /// ***************************************************
		    public XmlDocumentBuilder()
		    {
			    _document = new XmlDocument();
		    }

            /// ***************************************************
            /// <summary>
            /// Constructor
            /// </summary>
            /// <param name="document">A initial document</param>
            /// ***************************************************
            public XmlDocumentBuilder( XmlDocument document )
            {
                _document = document;
            }

        #endregion

        #region Properties

            /// ***************************************************
            /// <summary>
            /// Retrieve the inter Xml document
            /// </summary>
            /// ***************************************************
            public XmlDocument Document
            {
                get{ return _document; }
            }

        #endregion

        #region Public Methods

            /// ***************************************************
            /// <summary>
            /// Create a new element
            /// </summary>
            /// <param name="parent">The parent node for the new element</param>
            /// <param name="elementName">TThe name of the new element</param>
            /// <returns>The newly creeated node</returns>
            /// ***************************************************
            public XmlNode CreateElement( XmlNode parent, string elementName )
            {
                XmlNode newNode = _document.CreateElement( elementName, "" );
                if( parent != null )
                {
                    parent.AppendChild( newNode );
                }
                else
                {
                    _document.AppendChild( newNode );
                }
                return newNode;
            }

            /// ***************************************************
            /// <summary>
            /// Add a new attribute to an Xml node
            /// </summary>
            /// <param name="node">The node to add the attribute to</param>
            /// <param name="attributeName">The new attribute name</param>
            /// <param name="attributeValue">The new attribute value</param>
            /// ***************************************************
            public void AddAttribute( XmlNode node, string attributeName, string attributeValue )
            {
                XmlAttribute newAttribute = _document.CreateAttribute( attributeName, "" );
                newAttribute.Value = attributeValue;
                node.Attributes.Append( newAttribute );
            }

            /// ***************************************************
            /// <summary>
            /// Add elements defined in an Xml string
            /// </summary>
            /// <param name="parent">The parent for the new elements</param>
            /// <param name="Xml">An Xml string</param>
            /// ***************************************************
            public void AddElementsFromXml( XmlNode parent, string Xml )
            {
                XmlDocument sourceDocument = new XmlDocument();
                sourceDocument.LoadXml( Xml );
                XmlNode newNode = _document.ImportNode( sourceDocument.FirstChild, true );
                parent.AppendChild( newNode );
            }

        #endregion
	}
}
