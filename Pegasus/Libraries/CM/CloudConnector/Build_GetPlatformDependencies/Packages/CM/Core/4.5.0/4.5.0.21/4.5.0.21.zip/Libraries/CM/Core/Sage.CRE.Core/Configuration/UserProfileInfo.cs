using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Security.Principal;
using System.Runtime.InteropServices;
using Sage.Configuration;

namespace Sage.Configuration
{
    /// <summary>
    /// Defines various user profile state masks.
    /// </summary>
    [Flags]
    public enum ProfileStateMask
    {
        /// <summary>The profile is mandatory.</summary>
        MandatoryProfile                        = 0x001,
        /// <summary>Update the locally cached profile.</summary>        
        UpdateLocallyCachedProfile              = 0x0002,
        /// <summary>A new local profile.</summary>
        NewLocalProfile                         = 0x0004,
        /// <summary>A new central profile.</summary>
        NewCentralProfile                       = 0x0008,
        /// <summary>Update the central profile.</summary>
        UpdateCentralProfile                    = 0x0010,
        /// <summary>Delete the cached profile.</summary>
        DeleteCachedProfile                     = 0x0020,
        /// <summary>Upgrade the profile.</summary>
        UpgradeProfile                          = 0x0040,
        /// <summary>Using a guest profile.</summary>
        UsingGuestProfile                       = 0x0080,
        /// <summary>Using an Administrator profile.</summary>
        UsingAdministratorProfile               = 0x0100,
        /// <summary>Default net profile is available and ready.</summary>
        DefaultNetProfileAvailAndReady          = 0x0200,
        /// <summary>Slow network link identified.</summary>
        SlowNetworkLinkIdentified               = 0x0400,
        /// <summary>A temporary profile is loaded.</summary>
        TempProfileLoaded                       = 0x0800,
    };

    /// <summary>
    /// Defines a user profile structure.
    /// </summary>
    [ComVisible(false)]
    public struct UserProfile
    {
        private string m_sid;
        private int m_stateMaskValue;
        private string m_fullPathToProfileFolder;
        private string m_name;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="sid">The user SID.</param>
        /// <param name="stateMaskValue">The state mask value.</param>
        /// <param name="fullPathToProfileFolder">The full path to the profile folder.</param>
        public UserProfile(string sid, int stateMaskValue, string fullPathToProfileFolder)
        {
            this.m_sid = sid;
            this.m_stateMaskValue = stateMaskValue;
            this.m_fullPathToProfileFolder = fullPathToProfileFolder;
            this.m_name = null;
        }

        /// <summary>
        /// Checks to see if the specified mask value is valid for this profile.
        /// </summary>
        /// <param name="maskValue">The mask value to test.</param>
        /// <returns>Returns true if the mask value is true; otherwise, false.</returns>
        public bool CheckProfileStateMask(ProfileStateMask maskValue)
        {
            return ((this.m_stateMaskValue & (int)maskValue) == (int)maskValue);
        }

        /// <summary>
        /// Get the common name for this user profile.
        /// </summary>
        public string Name
        {
            get
            {
                if (string.IsNullOrEmpty(this.m_name))
                {
                    try
                    {
                        // Get the name from the account.
                        this.m_name = BuildNTAccount().Value;
                    }
                    catch 
                    {
                        // If all else fails, use the SID.
                        this.m_name = this.Sid;

                        // As a last resort, the name can usually be found by looking at the profile directory.
                        if (string.IsNullOrEmpty(this.FullPathToProfileFolder))
                        {
                            int index = this.FullPathToProfileFolder.LastIndexOf("\\");

                            if (index > 0)
                                this.m_name = this.FullPathToProfileFolder.Substring(index + 1);
                        }
                    }
                }

                return this.m_name;
            }
        }

        /// <summary>
        /// Get the user's SID.
        /// </summary>
        public string Sid
        {
            get { return this.m_sid; }
        }

        /// <summary>
        /// Get the full path to the profile folder.
        /// </summary>
        public string FullPathToProfileFolder
        {
            get { return this.m_fullPathToProfileFolder; }
        }

        /// <summary>
        /// Builds a security Id object for this user profile.
        /// </summary>
        /// <returns>Returns a security Id object.</returns>
        public SecurityIdentifier BuildSecurityIdentifier()
        {
            return new System.Security.Principal.SecurityIdentifier(this.Sid);
        }

        /// <summary>
        /// Builds an NT account object from this user profile.
        /// </summary>
        /// <returns>Returns an NT account object.</returns>
        public NTAccount BuildNTAccount()
        {
            SecurityIdentifier id = this.BuildSecurityIdentifier();

            if (id != null &&
                id.IsValidTargetType(typeof(System.Security.Principal.NTAccount)))
            {
                return id.Translate(typeof(System.Security.Principal.NTAccount)) as NTAccount;
            }
            else
                return null;
        }

        /// <summary>
        /// Get a flag indicating whether this is a Windows user or not.
        /// </summary>        
        /// <returns>Returns true if this is a Windows user; otherwise, false.</returns>
        public bool IsWindowsUser()
        {
            return IsWindowsUser(this.Sid);
        }

        /// <summary>
        /// Get a flag indicating whether the specified SID represents a Windows user or not.
        /// </summary>
        /// <param name="sid">The SID.</param>
        /// <returns>Returns true if the SID is a Windows user; otherwise, false.</returns>
        public static bool IsWindowsUser(string sid)
        {
            try
            {
                SecurityIdentifier securityId = new System.Security.Principal.SecurityIdentifier(sid);
                return securityId.IsAccountSid();
            }
            catch
            {
                return false;
            }
        }

        #region Load/Unload Profile

        /// <summary>
        /// Get a flag indicating whether this profile is currently loaded within the Registry.
        /// </summary>
        /// <returns>Returns true if loaded; otherwise, false.</returns>
        public bool IsLoaded()
        {
            // Make an assumption that the current user will always be loaded.
            if (System.Security.Principal.WindowsIdentity.GetCurrent().User.Value == this.Sid)
                return true;

            Microsoft.Win32.RegistryKey key = null;

            try
            {
                key = Microsoft.Win32.Registry.Users.OpenSubKey(this.Sid);
                return (key != null);
            }
            catch
            {
                return false;
            }
            finally
            {
                if (key != null)
                    key.Close();
            }
        }

        /// <summary>
        /// Loads the current user profile into the HKEY_USERS hive.
        /// </summary>
        /// <returns>Returns true if already loaded or if successfully loaded; otherwise, false.</returns>
        public bool Load()
        {
            // Do nothing if this profile is already loaded.
            if (this.IsLoaded())
                return true;

            // Perform a safe load.
            return RegistryLoadUnload.TryLoadRegistryHive(this);
        }

        /// <summary>
        /// Unloads the current user profile from the HKEY_USERS hive. This method will only unload a profile if it
        /// has already been loaded, unless this is the current user profile.
        /// </summary>
        /// <returns>Returns true if successully unloaded.</returns>
        public bool Unload()
        {
            // Do nothing if not already loaded or if this is the current profile.
            if (!this.IsLoaded() ||
                System.Security.Principal.WindowsIdentity.GetCurrent().User.Value == this.Sid)
            {
                return true;
            }
            
            // Perform a safe unload.
            return RegistryLoadUnload.TryUnloadRegistryHive(this);
        }

        #endregion

        /// <summary>
        /// Provides a friendly string.
        /// </summary>
        /// <returns>Returns the string.</returns>
        public override string ToString()
        {
            return string.Format("Sid = {0}, Path = {1}", this.Sid, this.FullPathToProfileFolder);
        }
    };

    /// <summary>
    /// Provides the ability to pull a list of all profiles defined on the current PC.
    /// </summary>
    /// <remarks>
    /// Note: this is not intended to be a robust class to get things like roaming profiles from AD, etc. This is very simple: read the Registry
    /// and get basic information on certain types of users.
    /// </remarks>
    public static class UserProfileReader
    {
        private static string m_profileListKey = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList";

        /// <summary>
        /// Get the current user profile.
        /// </summary>
        /// <returns>Returns the user profile.</returns>
        public static UserProfile GetCurrentUserProfile()
        {
            return (UserProfile)FindProfileBySid(System.Security.Principal.WindowsIdentity.GetCurrent().User);
        }

        /// <summary>
        /// Find the profile by SID.
        /// </summary>
        /// <param name="sid">The user SID.</param>
        /// <returns>Returns the user profile.</returns>
        public static UserProfile? FindProfileBySid(SecurityIdentifier sid)
        {
            if (sid != null)
                return FindProfileBySid(sid.Value);
            else
                return null;
        }

        /// <summary>
        /// Find the profile by SID string.
        /// </summary>
        /// <param name="sid">The user SID string.</param>
        /// <returns>Returns the user profile.</returns>
        public static UserProfile? FindProfileBySid(string sid)
        {
            foreach (UserProfile profile in GetUserProfiles(false))
            {
                if (string.Compare(profile.Sid, sid, true, System.Globalization.CultureInfo.CurrentCulture) == 0)
                    return profile;
            }

            return null;
        }
        
        /// <summary>
        /// Get all the user profiles defined on the current workstation.
        /// </summary>
        /// <param name="includeNonWindowsUsers">Specify whether to include the non-Windows user accounts (IE BUILTIN\Network Service, etc.)</param>
        /// <returns>Returns the list of user profiles.</returns>
        public static ReadOnlyCollection<UserProfile> GetUserProfiles(bool includeNonWindowsUsers)
        {
            List<UserProfile> profiles = new List<UserProfile>();
            RegistryHelper regHelper = new RegistryHelper(Microsoft.Win32.RegistryHive.LocalMachine, m_profileListKey);

            foreach (string sidName in regHelper.GetSubKeyNames())
            {
                if (!UserProfile.IsWindowsUser(sidName)  &&
                    !includeNonWindowsUsers)
                {
                    continue;
                }

                regHelper.SetSubKey(m_profileListKey + "\\" + sidName, false);
                UserProfile userProfile = new UserProfile(sidName, Convert.ToInt32(regHelper.GetKeyValue("State")), regHelper.GetKeyValue("ProfileImagePath"));
                profiles.Add(userProfile);
            }

            return profiles.AsReadOnly();
        }

        /// <summary>
        /// Get all the user profiles defined on the current workstation.
        /// </summary>
        /// <returns>Returns the list of user profiles.</returns>
        public static ReadOnlyCollection<UserProfile> GetAllUserProfiles()
        {
            return GetUserProfiles(false);
        }
    }
}
