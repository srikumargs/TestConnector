#if DEBUG
using System;
using System.Runtime.InteropServices;
using NUnit.Framework;

namespace Sage.Xml.NUnit
{
	/// <summary>
	/// Summary description for Test_XmlAsNamedProperties.
	/// </summary>
	[TestFixture]
	[ComVisible(false)]
	public class Test_XmlAsNamedProperties
	{

		/// <summary>
		/// 
		/// </summary>
		[Test]
		public void TestCreation()
		{
			XmlAsNamedProperties xmlAsProps = new XmlAsNamedProperties();
			Assert.IsFalse(xmlAsProps.HasProperty("prop1"));
			Assert.IsFalse(xmlAsProps.HasProperty("prop2"));
			Assert.IsFalse(xmlAsProps.HasProperty("prop3"));

			xmlAsProps.SetPropertyValue("prop1", "val1");
			xmlAsProps.SetPropertyValue("prop2", "val2");
			xmlAsProps.SetPropertyValue("prop3", "val3");

			Assert.AreEqual("val1", xmlAsProps.GetPropertyValue("prop1"));
			Assert.AreEqual("val2", xmlAsProps.GetPropertyValue("prop2"));
			Assert.AreEqual("val3", xmlAsProps.GetPropertyValue("prop3"));
		}

		/// <summary>
		/// 
		/// </summary>
		[Test]
		public void TestSetXML()
		{
			XmlAsNamedProperties xmlAsProps = new XmlAsNamedProperties("SomeXML");
			xmlAsProps.Xml = @"<SomeXML test='foo'/>";
			Assert.IsTrue(xmlAsProps.HasProperty("test"));
			string val = (string)xmlAsProps.GetPropertyValue("test");
			Assert.AreEqual("foo", val);
			
		}



		/// <summary>
		/// 
		/// </summary>
		[Test]
		[ExpectedException(typeof(System.ArgumentException))]
		public void ErrorWithXML()
		{
			XmlAsNamedProperties xmlAsProps = new XmlAsNamedProperties();
			xmlAsProps.Xml = @"<SomeXML test='foo'/>";
			xmlAsProps.SetPropertyValue("prop1", "val1");
		}

		/// <summary>
		/// 
		/// </summary>
		[Test]
		[ExpectedException(typeof(System.ArgumentNullException))]
		public void ErrorGetNullPropValue()
		{
			XmlAsNamedProperties xmlAsProps= new XmlAsNamedProperties();
			xmlAsProps.GetPropertyValue(null);
		}

		/// <summary>
		/// 
		/// </summary>
		[Test]
		[ExpectedException(typeof(System.ArgumentException))]
		public void ErrorGetEmptyStringPropValue()
		{
			XmlAsNamedProperties xmlAsProps= new XmlAsNamedProperties();
			xmlAsProps.GetPropertyValue(string.Empty);
		}

		/// <summary>
		/// 
		/// </summary>
		[Test]
		[ExpectedException(typeof(System.ArgumentException))]
		public void ErrorGetNonPropValue()
		{
			XmlAsNamedProperties xmlAsProps= new XmlAsNamedProperties();
			xmlAsProps.GetPropertyValue("nada");
		}


	}
}

#endif // DEBUG