using System;
using System.Collections;


namespace Sage.Net
{
    /// <summary>
    /// Summary description for ServerCollection.
    /// </summary>
    public class ServerCollection
      : CollectionBase
      , IServerCollection
    {

        /// <summary>
        /// ctor
        /// </summary>
        public ServerCollection()
        {
        }

        /// <summary>
        /// Indexer into the server collection
        /// </summary>
        public IServer this[int index]
        {
            get
            {
                return (IServer)_collection[index];
            }
        }


        /// <summary>
        /// Populates the server collection
        /// </summary>
        public override void PopulateCollection()
        {
            _collection.Clear();
            IDomainValidation v = new DomainValidation();
            string domain = Domain;
            if (null != domain && domain.Length > 0 && !v.Validate(Domain))
            {
                throw new NetworkException("Domain " + Domain + " was not found on the network.");
            }

            try
            {
                ServerEnumeration.PopulateList(Domain, _collection);
            }
            catch (Exception ex)
            {
                throw new NetworkException("Error retrieving server list.", ex);
            }
        }


    }
}
