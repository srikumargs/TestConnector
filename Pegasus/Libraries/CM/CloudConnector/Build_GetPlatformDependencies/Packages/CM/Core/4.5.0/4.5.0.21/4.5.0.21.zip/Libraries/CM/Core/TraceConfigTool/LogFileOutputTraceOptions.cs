using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Xml;

using Sage.Diagnostics;

namespace TraceConfigTool
{
    public class LogFileOutputTraceOptions : TraceOptions
    {
        public LogFileOutputTraceOptions(XmlNode customConfigSection, XmlNode addListenerElement)
            : base(customConfigSection)
        {
            _logFileName = @"c:\SageTraceLog.txt";
            if(addListenerElement != null)
            {
                XmlNodeHelper.GetOptionalStringAttributeValue(addListenerElement, "initializeData", ref _logFileName);
            }
        }

        public override void WriteAddListnerElementAttributes(XmlTextWriter xmlTextWriter)
        {
            xmlTextWriter.WriteAttributeString("initializeData", LogFileName);
        }

        [Category("General")]
        [DisplayName("Log File Name")]
        [Description("Controls where the log file should be output.")]
        [Editor(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string LogFileName
        {
            get
            {
                return _logFileName;
            }
            set
            {
                _logFileName = value;
            }
        }

        #region Private fields
        private string _logFileName;
        #endregion
    }
}
