using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace Sage.Diagnostics
{
    /// <summary>
    /// Used to return Service Pack installed
    /// </summary>
    public enum ServicePack
    {
        /// <summary></summary>
        None,
        /// <summary></summary>
        SP1,
        /// <summary></summary>
        SP2,
        /// <summary></summary>
        SP3,
        /// <summary></summary>
        SP4,
        /// <summary></summary>
        SP5,
        /// <summary></summary>
        SP6,
        /// <summary></summary>
        SP7,
        /// <summary></summary>
        SP8,
        /// <summary></summary>
        SP9,
        /// <summary></summary>
        SP10
    }
    /// <summary>
    /// Use this class to get version info from a referenced assembly.
    /// It uses the current executing assembly as the context.
    /// </summary>
    public sealed class AssemblyVersionInfo
    {
        private static readonly Version _v1;
        private static readonly Version _v11;
        private static readonly Version _v2;

        static AssemblyVersionInfo()
        {
            _v1  = new Version(1, 0, 3300, 0);
            _v11 = new Version(1, 0, 5000, 0);
            _v2  = new Version(2, 0, 0, 0);
        }

        /// <summary>
        /// Constant for clr version  1.0
        /// </summary>
        public static Version ClrOneDotZero
        {
            get { return _v1; }
        }

        /// <summary>
        /// Constant for clr version 1.1
        /// </summary>
        public static Version ClrOneDotOne
        {
            get { return _v11; }
        }

        /// <summary>
        /// Constant for clr version 2.0
        /// </summary>
        public static Version ClrTwoDotZero
        {
            get { return _v2; }
        }

        /// <summary>
        /// get the currently loaded system version
        /// </summary>
        public static Version ClrVersion
        {
            get
            {
                return GetReferencedAssemblyVersion("System");
            }
        }

        /// <summary>
        /// Get any installed service packs
        /// </summary>
        public static ServicePack ClrServicePack
        {
            get
            {
                string fileName = GetMsCorLibPath();

                FileVersionInfo fileInfo = FileVersionInfo.GetVersionInfo(fileName);
                return LookupFileVersionInfo(fileInfo);
            }
        }

        /// <summary>
        /// Pass in an assembly name by string minus the extension get back a 
        /// Version type that has operators overloaded
        /// </summary>
        /// <param name="assemblyName"></param>
        /// <returns></returns>
        public static Version GetReferencedAssemblyVersion(string assemblyName)
        {
            Version v = new Version();
            Assembly a = Assembly.GetExecutingAssembly();
            AssemblyName[] names = a.GetReferencedAssemblies();
            foreach (AssemblyName name in names)
            {
                if (name.Name == assemblyName)
                {
                    v = name.Version;
                    break;
                }
            }
            return v;
        }

        /// <summary>
        /// Helper to get the MsCorLib path
        /// </summary>
        /// <returns></returns>
        private static string GetMsCorLibPath()
        {
            string returnPath = string.Empty;
            RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\.NETFramework");
            string installPath = (string) key.GetValue("InstallRoot");
            key.Close();

            if (ClrVersion == ClrOneDotZero)
            {
                returnPath = installPath + @"v1.0.3705\mscorlib.dll";
            }
            else if (ClrVersion == ClrOneDotOne)
            {
                returnPath = installPath + @"v1.1.4322\mscorlib.dll";
            }
            else if (ClrVersion == ClrTwoDotZero)
            {
                returnPath = installPath + @"v2.0.50727\mscorlib.dll";
            }
            else
            {
                throw new FileNotFoundException(Strings.CanNotFindMscorelibError );
            }
            if (File.Exists(returnPath) == false)
            {
                throw new FileNotFoundException(Strings.CanNotFindMscorelibError);
            }

            return returnPath;
        }

        /// <summary>
        /// Lookup the file version info in the lookup table
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        private static ServicePack LookupFileVersionInfo(FileVersionInfo info)
        {
            foreach (TableEntry t in _lookupTable)
            {
                if (t.FileVersion == info.FileVersion)
                {
                    return t.ServicePack;
                }
            }
            return ServicePack.None;
        }

        /// <summary>
        /// Internal struct for table lookup
        /// </summary>
        private struct TableEntry
        {
            internal TableEntry(string fileVersion, ServicePack servicePack)
            {
                FileVersion = fileVersion;
                ServicePack = servicePack;
            }
            internal string FileVersion;
            internal ServicePack ServicePack;
        }

        /// <summary>
        /// Internal lookup table - maybe move out of code?
        /// </summary>
        /// <remarks>
        /// "How to determine which versions of the .NET Framework are installed and whether service packs have been applied" 
        /// http://support.microsoft.com/kb/318785/
        /// </remarks>
        private static TableEntry[] _lookupTable = new TableEntry[] 
        {
            new TableEntry("1.0.3705.000",  ServicePack.None), // v1.0 Original RTM
            new TableEntry("1.0.3705.209",  ServicePack.SP1),  // v1.0 Service Pack 1
            new TableEntry("1.0.3705.288",  ServicePack.SP2),  // v1.0 Service Pack 2
            new TableEntry("1.0.3705.6018", ServicePack.SP3),  // v1.0 Service Pack 3
            new TableEntry("1.1.4322.573",  ServicePack.None), // v1.1 Original RTM
            new TableEntry("1.1.4322.2032", ServicePack.SP1),  // v1.1 Service Pack 1
            new TableEntry("1.1.4322.2300", ServicePack.SP1),  // v1.1 Service Pack 1 Post-SP1 (Windows Server 2003 SP1)
            new TableEntry("2.0.50727.42",  ServicePack.None)  // v2.0 Original RTM
        };
    }
}

