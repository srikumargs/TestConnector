using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Messaging;
using System.IO;

using Sage.CRE.LinkedSource;

namespace Sage.Remoting
{
    internal sealed class EncryptionClientSink : BaseChannelSinkWithProperties, IClientChannelSink
    {
        public EncryptionClientSink(IClientChannelSink nextChannelSink, CryptoAlgorithm cryptoAlgorithm, Byte[] encryptionKey)
        {
            _nextChannelSink = nextChannelSink;
            _cryptography = new Cryptography(cryptoAlgorithm);
            _encryptionKey = encryptionKey;
        }

        #region IClientChannelSink Members
        public void AsyncProcessRequest(IClientChannelSinkStack sinkStack, IMessage msg, ITransportHeaders headers, Stream stream)
        {
            stream = Encrypt(headers, stream);

            sinkStack.Push(this, null);
            _nextChannelSink.AsyncProcessRequest(sinkStack, msg, headers, stream);
        }

        public void AsyncProcessResponse(IClientResponseChannelSinkStack sinkStack, Object state, ITransportHeaders headers, Stream stream)
        {
            stream = Decrypt(headers, stream);

            sinkStack.AsyncProcessResponse(headers, stream);
        }

        public Stream GetRequestStream(IMessage msg, ITransportHeaders headers)
        { return null; }

        public IClientChannelSink NextChannelSink
        { get { return _nextChannelSink; } }

        public void ProcessMessage(IMessage msg, ITransportHeaders requestHeaders, Stream requestStream, out ITransportHeaders responseHeaders, out Stream responseStream)
        {
            requestStream = Encrypt(requestHeaders, requestStream);

            _nextChannelSink.ProcessMessage(msg, requestHeaders, requestStream, out responseHeaders, out responseStream);

            responseStream = Decrypt(responseHeaders, responseStream);
        }
        #endregion

        #region Private methods
        private Stream Encrypt(ITransportHeaders headers, Stream stream)
        {
            Stream result = stream;

            Byte[] iv;

            result = _cryptography.EncryptStream(stream, _encryptionKey, out iv);

            headers["X-Encrypt"] = Boolean.TrueString;
            headers["X-EncryptIV"] = Convert.ToBase64String(iv);

            return result;
        }

        private Stream Decrypt(ITransportHeaders headers, Stream stream)
        {
            Stream result = stream;

            if (headers["X-Encrypt"] != null && Boolean.Parse((String)headers["X-Encrypt"]))
            {
                Byte[] iv = Convert.FromBase64String((String)headers["X-EncryptIV"]);
                result = _cryptography.DecryptStream(stream, _encryptionKey, iv);
            }

            return result;
        }
        #endregion

        #region Private fields
        private readonly IClientChannelSink _nextChannelSink;
        private readonly Byte[] _encryptionKey;
        private readonly Cryptography _cryptography;
        #endregion
    }
}
