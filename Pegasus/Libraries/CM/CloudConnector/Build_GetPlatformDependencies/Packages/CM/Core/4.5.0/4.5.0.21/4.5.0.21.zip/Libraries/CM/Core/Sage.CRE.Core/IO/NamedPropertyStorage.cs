using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Xml;
using System.Xml.XPath;


namespace Sage.IO
{
    /// <summary>
    /// Use this enum to specify the write to disk policy
    /// </summary>
    public enum SavePolicy
    {
        /// <summary>Save to disk on each property mutator method call e.g WriteProperty, RemoveProperty</summary>
        AutoSave,

        /// <summary>Save to disk on explicit Save call.  Good for mutiple property (batch) writing</summary>
        ManualSave
    }

    /// <summary>
    /// This class is used to support simple named/value property persistence.
    /// </summary>
    public class NamedPropertyStorage : IDisposable
    {
        #region private data

        private XmlDocument _doc;
        private string      _filename;
        private IsolatedStorageFile _isoStore = 
            IsolatedStorageFile.GetStore(IsolatedStorageScope.User | IsolatedStorageScope.Assembly, null, null);
        private SavePolicy _savePolicy = SavePolicy.AutoSave;

        #endregion // private data

        // Hide the def ctor
        private NamedPropertyStorage() {}

        /// <summary>
        /// specify an isolated storage filename.  e.g.
        /// "appshellremoting.dat"
        /// </summary>
        public NamedPropertyStorage(string fileName)
        {
            _filename = fileName;
        }

        /// <summary>
        /// specify an isolated storage filename.  e.g.
        /// "appshellremoting.dat" and a SavePolicy
        /// </summary>
        public NamedPropertyStorage(string fileName, SavePolicy policy)
        {
            _filename = fileName;
            _savePolicy = policy;
        }

        /// <summary>
        /// Write a named property value.  Updates any existing prop with the 
        /// same name. 
        /// </summary>
        /// <param name="prop"></param>
        /// <param name="val"></param>
        public void WriteProperty(string prop, string val)
        {
            XmlNode propNode = XmlDoc.SelectSingleNode(string.Format("//property[@name='{0}']", prop));

            if (propNode != null)
            {
                XmlAttribute attr = XmlDoc.CreateAttribute("value");
                attr.Value = val;
                propNode.Attributes.RemoveNamedItem(val, "");
                propNode.Attributes.SetNamedItem(attr);
            }
            else
            {
                XmlElement element = XmlDoc.CreateElement("property");
                element.SetAttribute("name", prop);
                element.SetAttribute("value", val);
                XmlDoc.DocumentElement.AppendChild(element);
            }
            writeXmlFileIfAutoSave();
        }

        /// <summary>
        /// Remove the property if it exists
        /// </summary>
        /// <param name="prop"></param>
        public void RemoveProperty(string prop)
        {
            XmlNode propNode = XmlDoc.SelectSingleNode(string.Format("//property[@name='{0}']", prop));

            if (propNode != null)
            {
                XmlDoc.DocumentElement.RemoveChild(propNode);
            }
            writeXmlFileIfAutoSave();
        }

        /// <summary>
        /// Read a property name and return the value
        /// </summary>
        /// <param name="prop">the named property</param>
        /// <returns>the property value or empty string</returns>
        public string ReadProperty(string prop)
        {
            string retval = string.Empty;
            XPathNavigator nav = XmlDoc.CreateNavigator();
            XPathNodeIterator iter = nav.Select(string.Format("//property[@name='{0}']/@value", prop));
            if (iter.MoveNext())
            {
                retval = iter.Current.Value;
            }
            return retval;
        }

        /// <summary>
        /// Remove the file store
        /// </summary>
        public void DeleteFile()
        {
            if (_isoStore.GetFileNames(_filename).Length > 0)
            {
                _isoStore.DeleteFile(_filename);
                _doc = null;
            }
        }

        /// <summary>
        /// Need to call this explicitly if in Manual Save mode,
        /// otherwise this is redundant.
        /// </summary>
        public void Save()
        {
            writeXmlFile();
        }

        /// <summary>
        /// Close the Isolated storage file
        /// </summary>
        public void Dispose()
        {
            _isoStore.Close();
            _doc = null;
        }

        /// <summary>
        /// Helper returns a valid xml file contents as a string
        /// </summary>
        /// <returns>file contents or empty string</returns>
        private string readFile()
        {
            StreamReader reader = new StreamReader(new IsolatedStorageFileStream(_filename, FileMode.OpenOrCreate, _isoStore));
            string retval = reader.ReadToEnd();
            reader.Close();
            if (retval == string.Empty)
            {
                retval = "<properties/>";
            }
            return retval;
        }

        /// <summary>
        /// Cache the document on first access
        /// </summary>
        /// <returns></returns>
        private XmlDocument XmlDoc
        {
            get
            {
                if (_doc == null)
                {
                    _doc = new XmlDocument();
                    _doc.LoadXml(readFile());
                }
                return _doc;
            }
        }
        
        /// <summary>
        /// remove code dupe
        /// </summary>
        private void writeXmlFileIfAutoSave()
        {
            if (_savePolicy == SavePolicy.AutoSave)
            {
                writeXmlFile();
            }
        }
        /// <summary>
        /// helper to write out the string contents
        /// </summary>
        private void writeXmlFile()
        {
            StreamWriter writer = new StreamWriter(new IsolatedStorageFileStream(_filename, FileMode.Create, _isoStore));
            writer.Write(XmlDoc.OuterXml);
            writer.Close();
        }
    }
}