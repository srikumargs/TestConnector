using System;
using System.Globalization;
using System.Reflection;

namespace Sage.Remoting
{
    /// <summary>
    /// Internal string constants 
    /// </summary>
    internal static class CryptoConstants
    {
        #region Public properties
        public static Byte[] IV
        {
            get
            {
                if (_iv == null)
                {
                    _iv = new byte[] { 0x5C, 0x10, 0x6F, 0xB4, 0x18, 0x40, 0xD8, 0xEE };
                }

                return _iv;
            }
        }

        /// <summary>
        /// Retrieve the encryption key for the pipe communication
        /// </summary>
        public static byte[] Key
        {
            get
            {
                if(_key == null)
                {
                    _key = new byte[] { 0x77, 0xAD, 0x97, 0xF7, 0xC8, 0x2E, 0x47, 0x1A };

                    // mix it up a little;  this way, even if someone does reflect on the assembly
                    // they will have to do a little IL math to figure out the real value of the key
                    //
                    // there is no significance to this algorithm ... it can be changed, but if it is
                    // then the config files must be reencrypted with the new key
                    for(int i = 1 ; i < _key.Length ; i++)
                    {
                        _key[i] = (byte) ((_key[i] * _key[i - 1]) % 0x7F);
                    }
                    _key[0] = (byte) ((_key[0] * _key[7]) % 0x7F);
                }

                return _key;
            }
        }
        #endregion

        #region Private fields
        private static byte[] _iv; //= null; (automatically initialized by runtime)
        private static byte[] _key; //= null; (automatically initialized by runtime)
        #endregion
    }
}
