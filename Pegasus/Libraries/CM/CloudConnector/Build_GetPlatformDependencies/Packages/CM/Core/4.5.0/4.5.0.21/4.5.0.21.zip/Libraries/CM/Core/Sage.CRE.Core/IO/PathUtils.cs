using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Globalization;

using Sage.Diagnostics;
using Sage.PInvoke;

namespace Sage.IO
{
    /// <summary>
    /// Class providing path utility methods
    /// </summary>
    [ComVisible(false)]
    public class PathUtils : IPathUtils
    {
        #region PInvoke decls
        private const int DRIVE_UNKNOWN     = 0;
        private const int DRIVE_NO_ROOT_DIR = 1;
        private const int DRIVE_REMOVABLE   = 2;
        private const int DRIVE_FIXED       = 3;
        private const int DRIVE_REMOTE      = 4;
        private const int DRIVE_CDROM       = 5;
        private const int DRIVE_RAMDISK     = 6;

        private const int UNIVERSAL_NAME_INFO_LEVEL = 0x00000001;
        private const int REMOTE_NAME_INFO_LEVEL = 0x00000002;

        private const int ERROR_MORE_DATA = 234;
        private const int NOERROR = 0;

        private const int WINDOWS_XP = 5;

        [DllImport("Kernel32.dll")]
        private static extern int GetDriveType(string drv);

        [DllImport("Kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern int QueryDosDevice(string lpDeviceName, [Out] StringBuilder lpTargetPath, int ucchMax);

        [DllImport("Mpr.dll")]
        private static extern int WNetGetConnection(string locName, StringBuilder remName, ref int length);

        #endregion // PInvoke

        private const int m_maxPath = 260;
        private const int m_maxFilename = 255;
        private static string m_substPrefix = @"\??\";

        /// <summary>
        /// Constructor
        /// </summary>
        public PathUtils()
        {

        }

        /// <summary>
        /// Determine if the specified path is a drive root directory.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if the path is a drive root directory; otherwise, false.</returns>
        public static bool IsRoot(string path)
        {            
            if (string.IsNullOrEmpty(path))
                return false;

            // Strip out the trailing slash when the path is more than just "\"
            if (path.Length > 1)
            {
                path = StripTrailingSlash(path);
            }

            // Examples include:
            //      "\"
            //      "<d>:" where <d> is the drive letter (or <d>:\ with the trailing slash)
            if (path.Length == 1 && path[0] == Path.DirectorySeparatorChar ||
                path.Length == 2 && path[1] == Path.VolumeSeparatorChar)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Get a flag indicating if the path starts with a '/' or '\' character.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if the path starts with a '/' or '\' character; otherwise, false.</returns>
        public static bool HasLeadingSeparator(string path)
        {
            if (string.IsNullOrEmpty(path))
                return false;

            // Let's be smart about this. Check for either one...
            return (path[0] == Path.DirectorySeparatorChar || path[0] == Path.AltDirectorySeparatorChar);
        }

        /// <summary>
        /// Add a trailing separator at the start of the path if one doesn't already exist.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if a trailing directory separator character was added; otherwise, false.</returns>
        public static bool AddLeadingSeparator(ref string path)
        {
            if (!HasLeadingSeparator(path))
            {
                path = Path.DirectorySeparatorChar.ToString() + path;
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Get a flag indicating if the path ends with a trailing directory separator character (either '/' or '\').
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if the path has a trailing directory separator character; otherwise, false.</returns>
        public static bool HasTrailingSeparator(string path)
        {
            if (string.IsNullOrEmpty(path))
                return false;

            // Check for either case.
            return (path.EndsWith(Path.DirectorySeparatorChar.ToString()) || path.EndsWith(Path.AltDirectorySeparatorChar.ToString()));
        }

        /// <summary>
        /// Add a trailing separator if one doesn't already exist.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if a trailing separator was added; otherwise, false.</returns>
        public static bool AddTrailingSeparator(ref string path)
        {
            if (!HasTrailingSeparator(path))
            {
                path += Path.DirectorySeparatorChar.ToString();
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Remove any trailing '\' from the end of s path if it is not a root path.
        /// </summary>
        /// <param name="path">The path to examine\modify.</param>
        /// <returns>Returns true if the path was stripped of a trailing '\'; otherwise, false.</returns>
        public static bool StripTrailingSlashIfNotRoot(ref string path)
        {
            if (!IsRoot(path))
            {
                path = StripTrailingSlash(path);
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Use to clean up a path retrieved from user input or the registry.
        /// Also ensures that if there are multiple paths seperated by ';', only
        /// the first will be used.
        /// </summary>
        /// <param name="path">Path to normalize. A null path is handled by
        /// causing the empty string to be returned.</param>
        /// <returns>Normalized path or empty string if path is null.</returns>
        public static string Normalize(string path)
        {
            return Normalize(path, false);
        }

        /// <summary>
        /// Use to clean up a path retrieved from user input or the registry.
        /// Also ensures that if there are multiple paths seperated by ';', only
        /// the first will be used.
        /// </summary>
        /// <param name="path">Path to normalize. A null path is handled by
        /// causing the empty string to be returned.</param>
        /// <param name="addTrailingSeparator">Specify whether to add a trailing slash.</param>
        /// <returns>Normalized path or empty string if path is null.</returns>
        public static string Normalize(string path, bool addTrailingSeparator)
        {
            string retval = string.Empty;
            if (path != null)
            {
                path = path.Trim();
                if (path.Length > 0)
                {
                    path = path.Split(new char[] { ';' }, 2)[0];
                    string[] parts = path.Split(new char[] { '/' });
                    retval = string.Join(Path.DirectorySeparatorChar.ToString(), parts);
                }
            }

            if (addTrailingSeparator)
                AddTrailingSeparator(ref retval);

            return retval;
        }

        /// <summary>
        /// Combines two path strings.
        /// </summary>
        /// <param name="path1">First path string: absolute or relative.</param>
        /// <param name="path2">Second path string: relative paths only.</param>
        /// <returns>Combined path string.</returns>
        public static string Combine(string path1, string path2)
        {
            ArgumentValidator.ValidateNonNullReference(path2, "path2", "Paths");

            if (path1 != null && path1.Length > 0)
            {
                if (path2.IndexOf(Path.VolumeSeparatorChar, 0) >= 0)
                {
                    path2 = path2.Substring(path2.IndexOf(Path.VolumeSeparatorChar, 0) + 1);
                }

                if (path2.Length > 0 && path2[0] == '\\')
                {
                    path2 = path2.Remove(0, 1);
                }

                if (!path1.EndsWith("\\") && path2.Length > 0)
                {
                    path1 += "\\";
                }
            }
            else if (path1 == null)
            {
                path1 = String.Empty;
            }
            return Path.Combine(path1, path2);
        }

        /// <summary>
        /// Determines if a directory is accessible (e.g. exists and is online).
        /// </summary>
        /// <param name="path">Path to test</param>
        /// <returns>Returns true if path exists and is online, false otherwise.
        /// Guaranteed not to throw exceptions.</returns>
        public static bool IsAccessibleDirectory(string path)
        {
            bool retval = false;
            try
            {
                retval = Directory.Exists(path);
            }
            catch
            {
                // Just return false;
            }
            return retval;
        }


        /// <summary>
        /// Get the server name from the mapped folder path.
        /// </summary>
        /// <param name="mappedFolderPath">the mapped path to derive a server name from</param>
        /// <returns>The server name or empty string</returns>
        public static string ServerNameFromMappedFolder(string mappedFolderPath)
        {
            ArgumentValidator.ValidateNonEmptyString(mappedFolderPath, "mappedFolderPath", "Paths");

            string retval = String.Empty;

            // Do not assume the path has a trailing slash. Let's add one in if it doesn't...
            AddTrailingSeparator(ref mappedFolderPath);
            string drvWithSlash = mappedFolderPath.Substring(0, 3);

            // Sanity check that the drive is actually mapped
            if (Array.BinarySearch(Environment.GetLogicalDrives(), drvWithSlash.ToUpper()) >= 0)
            {
                int drvType = GetDriveType(drvWithSlash);
                if (drvType == DRIVE_REMOTE)
                {
                    int length = 255;
                    string drvWithoutSlash = drvWithSlash.Substring(0, 2);
                    StringBuilder unc = new StringBuilder(length);
                    int res = WNetGetConnection(drvWithoutSlash, unc, ref length);
                    if (res == 0)
                    {
                        string[] tokens = unc.ToString().Split(new char[] { '\\' });
                        foreach (string s in tokens)
                        {
                            if (s != @"\" && s.Length != 0)
                            {
                                retval = s;
                                break;
                            }
                        }
                    }
                }
                else if (drvType == DRIVE_FIXED)
                {
                    retval = Environment.MachineName;
                }
            }
            return retval;
        }

        /// <summary>
        /// Get the server name from any path, including mapped drive, logical drive, UNC path, etc.
        /// Note:  This will not work on a subst drive.
        /// </summary>
        /// <param name="folderPath">The path to retrieve the server from.</param>
        /// <returns>Returns the server name or an empty string.</returns>
        public static string ServerNameFromPath(string folderPath)
        {
            ArgumentValidator.ValidateNonEmptyString(folderPath, "folderPath", "ServerNameFromMappedFolder");
            string retval = String.Empty;

            string result = ServerNameFromMappedFolder(folderPath);
            if (result == String.Empty)
            {
                //We could not retrieve the server name so it's either a mapped drive or UNC path
                //We will make sure that it is a UNC path.
                result = UNCPathFromMappedFolder(folderPath);

                //now that we should have a UNC path, let's see if the first two characters are actually '\\'
                //if so, we'll retrieve the server name
                if (result.Length >= 2 &&
                    result[0] == '\\' &&
                    result[1] == '\\')
                {
                    //the first two items in the array are empty because of the double backslash '\\'
                    //grab the 3rd item in the array.  This will be the server name.
                    string[] strArray = result.Split(new char[] { '/', '\\' });
                    foreach (string strElement in strArray)
                    {
                        if (strElement != String.Empty)
                        {
                            retval = strElement;
                            break;
                        }
                    }
                }
            }
            else
            {
                retval = result;
            }

            return retval.ToUpper();
        }

        /// <summary>
        /// Returns a UNC path from a mapped drive.  If an error occurs, the orig path is returned.
        /// </summary>
        /// <param name="mappedFolderPath">The path containing a mapped drive.</param>
        /// <returns>UNC path or original passed in path.</returns>
        public static string UNCPathFromMappedFolder(string mappedFolderPath)
        {
            int returnCode;
            return UNCPathFromMappedFolder(
                mappedFolderPath,
                out returnCode);
        }

        /// <summary>
        /// Returns a UNC path for a mapped drive.  If an error occurs, the orig path is returned.
        /// </summary>
        /// <param name="mappedFolderPath">The path containing a mapped drive.</param>
        /// <param name="returnCode">Return code from Win32 calls.</param>
        /// <returns>UNC path or original passed in path.</returns>
        public static string UNCPathFromMappedFolder(
            string mappedFolderPath,
            out int returnCode)
        {
            string retval = mappedFolderPath;

            UNIVERSAL_NAME_INFO uni = new UNIVERSAL_NAME_INFO();
            int bufferSize = 0;

            //If the file is saved to a local drive then it will return an error so use the original name
            returnCode = PInvoke.Mpr.WNetGetUniversalName(
                mappedFolderPath,
                UNIVERSAL_NAME_INFO_LEVEL,
                ref uni,
                ref bufferSize);
            if (ERROR_MORE_DATA == returnCode)
            {
                // Tracker 511784 alloc the buffer size returned by the first call to WNetGetUniversalName()
                IntPtr pBuffer = Marshal.AllocHGlobal(bufferSize);

                try
                {
                    returnCode = PInvoke.Mpr.WNetGetUniversalName(
                        mappedFolderPath,
                        UNIVERSAL_NAME_INFO_LEVEL,
                        pBuffer,
                        ref bufferSize);
                    if (NOERROR == returnCode)
                    {
                        uni = (UNIVERSAL_NAME_INFO)Marshal.PtrToStructure(pBuffer, typeof(UNIVERSAL_NAME_INFO));
                        retval = uni.lpUniversalName;
                    }
                }
                finally
                {
                    Marshal.FreeHGlobal(pBuffer);
                }
            }
            return retval;
        }

        /// <summary>
        /// Retrieves the UNC path for a given file path.  File path can be local or remote.
        /// </summary>
        /// <param name="fullFilePath">Full path to file.  Can be local or remote (e.g., c:\share\file.txt, or Z:\share\file1.txt.</param>		
        /// <returns>Full UNC path (path and file name) for supplied input file.</returns>
        public static string GetUNCPathForFilePath(
            string fullFilePath)
        {
            return ShareInfoCollection.PathToUNC(fullFilePath);
        }

        /// <summary>
        /// Determine if a string value appears to be some type of path.
        /// </summary>
        /// <param name="value">The string value to test.</param>
        /// <returns>Returns true if the path</returns>
        public static bool IsPath(string value)
        {
            ArgumentValidator.ValidateNonEmptyString(value, "value", "PathUtils.IsFilePath");

            // Real simple: if it starts with a letter and is followed by a colon, then it looks like a path!
            if (value.Length >= 2 &&
                Char.IsLetter(value[0]) &&
                value[1] == ':')
            {
                return true;
            }

            // We don't care if it's mapped/etc., just that it appears to be UNC.
            else if (IsPathUNC(value))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Is the path part of a mapped drive.
        /// </summary>
        /// <param name="path">The path that needs to be tested if it is part of a mapped drive.</param>
        /// <returns>True if the path is part of a mapped drive, false otherwise.</returns>
        public static bool IsPathMappedDrive(string path)
        {
            bool returnVal = false;

            try
            {
                string drive = path.Substring(0, 2);
                drive += @"\";

                if (Array.BinarySearch(Environment.GetLogicalDrives(), drive.ToUpper()) >= 0)
                {
                    int drvType = GetDriveType(drive);
                    if (drvType == DRIVE_REMOTE)
                    {
                        returnVal = true;
                    }
                }
            }
            catch
            {
                Trace.WriteLine("threw exception in IsPathMappedDrive");
                throw;
            }

            return returnVal;
        }

        /// <summary>
        /// Is the path part of a UNC path.
        /// </summary>
        /// <param name="path">The path that needs to be tested if it is part of a UNC path.</param>
        /// <returns>True if the path is UNC, false otherwise.</returns>
        public static bool IsPathUNC(string path)
        {
            bool returnVal = false;

            //we're only checking to make sure the path starts w/ a double backslash.
            //if so, it's UNC.
            if (path.Length >= 2 &&
                path[0] == '\\' &&
                path[1] == '\\')
            {
                returnVal = true;
            }

            return returnVal;
        }

        /// <summary>
        /// Remove any leading '/' or '\' from the start of a path
        /// </summary>
        /// <param name="path">The path to examine\modify</param>
        /// <returns>The path without a leading '\'</returns>
        /// <remarks>If the path does not have a leading '\' the orginal path will be returned</remarks>
        public static string StripLeadingSlash(string path)
        {
            if (HasLeadingSeparator(path))
            {
                path = path.Substring(1);
            }

            return path;
        }

        /// <summary>
        /// Remove any trailing '\' from the end of a path
        /// </summary>
        /// <param name="path">The path to examine\modify</param>
        /// <returns>The path without a trailing '\'</returns>
        /// <remarks>If the path does not have a trailing '\' the orginal path will be returned</remarks>
        public static string StripTrailingSlash(string path)
        {
            // Make sure we check for either directory character.
            if (!string.IsNullOrEmpty(path) &&
                 (path.EndsWith(System.IO.Path.DirectorySeparatorChar.ToString()) || 
                  path.EndsWith(System.IO.Path.AltDirectorySeparatorChar.ToString())))
            {
                path = path.Substring(0, path.Length - 1);
            }
            return path;
        }

        /// <summary>
        /// Returns whether the specified path is a path to a local drive letter that is not mapped or subst'ed 
        /// </summary>
        /// <param name="path">the path to test</param>
        /// <returns>true if the path is a path to a local drive letter that is not mapped or subst'ed; otherwise false</returns>
        public static bool PathIsToNonSubstAndNonMappedDrive(string path)
        {
            ArgumentValidator.ValidateNonEmptyString(path, "path", "PathUtils.PathIsToNonSubstAndNonMappedDrive");

            bool result = false;

            if (path != null && path.Length >= 3 && path[1] == ':')
            {
                string driveWithoutTrailingSlash = path.Substring(0, 2);
                string driveWithTrailingSlash = path.Substring(0, 3);

                StringBuilder buffer = new StringBuilder(260);
                switch (GetDriveType(driveWithTrailingSlash))
                {
                    case DRIVE_FIXED:
                        if (QueryDosDevice(driveWithoutTrailingSlash, buffer, buffer.Capacity) > 0)
                        {
                            // substituted drives will report back with a string beginning with \??\
                            if (!buffer.ToString().StartsWith(m_substPrefix))
                            {
                                result = true;
                            }
                        }
                        else
                        {
                            Assertions.Assert(false, string.Format(CultureInfo.InvariantCulture, Strings.QueryDosDeviceFailedFormat, Marshal.GetLastWin32Error()));
                        }
                        break;
                }
            }

            return result;
        }

        /// <summary>
        /// Determine whether the specified path is contained within the list of known substituted drives.
        /// </summary>
        /// <param name="path">The path to test.</param>
        /// <returns>Returns true if the path is substituted; otherwise false</returns>
        public static bool IsPathToSubstDrive(string path)
        {
            string mappedPath = null;
            bool isRemote = false;
            return IsPathToSubstDrive(path, out mappedPath, out isRemote);
        }

        /// <summary>
        /// Returns whether the specified path is contained within the list of known substituted drives.
        /// </summary>
        /// <param name="path">the path to tes.t</param>
        /// <param name="mappedPath">Sets the substituted mapped path.</param>
        /// <param name="isRemote">The flag that's set when the mapped path is remote (IE UNC).</param>
        /// <returns>Returns true if the path is substituted; otherwise false</returns>
        public static bool IsPathToSubstDrive(string path, out string mappedPath, out bool isRemote)
        {
            ArgumentValidator.ValidateNonEmptyString(path, "path", "PathUtils.PathIsToNonSubstAndNonMappedDrive");
            bool result = false;
            mappedPath = null;
            isRemote = false;

            // We need to ensure that a trailing separator exists.
            AddTrailingSeparator(ref path);

            if (!string.IsNullOrEmpty(path) &&
                path.Length >= 3 &&
                path[1] == ':')
            {
                string driveWithoutTrailingSlash = path.Substring(0, 2);
                string driveWithTrailingSlash = path.Substring(0, 3);
                StringBuilder buffer = new StringBuilder(MaxPath);

                // Now get the drive type.
                int driveType = GetDriveType(driveWithTrailingSlash);

                if (driveType == DRIVE_REMOTE ||
                    driveType == DRIVE_FIXED)
                {
                    if (QueryDosDevice(driveWithoutTrailingSlash, buffer, buffer.Capacity) > 0)
                    {
                        isRemote = (driveType == DRIVE_REMOTE);
                        string bufferResult = buffer.ToString();

                        // substituted drives will report back with a string beginning with \??\
                        result = bufferResult.StartsWith(m_substPrefix);

                        if (result)
                        {
                            // Get the string after the '\??\'
                            mappedPath = bufferResult.Substring(4);

                            // If we find 'UNC' in the string, just replace it. We could use the isRemote flag but this will do the trick as well.
                            mappedPath = mappedPath.Replace("UNC", "\\");
                        }
                    }
                    else
                    {
                        Assertions.Assert(false, string.Format(CultureInfo.InvariantCulture, Strings.QueryDosDeviceFailedFormat, Marshal.GetLastWin32Error()));
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Get the path mapped to the subst value.
        /// </summary>
        /// <param name="substValue">The subst. value. This can be either just a drive letter or the drive letter + path.</param>
        /// <returns>Returns the path mapped to the specified value.</returns>
        public static string GetPathFromSubstDrive(string substValue)
        {
            bool isRemote = false;
            return GetPathFromSubstDrive(substValue, out isRemote);
        }

        /// <summary>
        /// Get the path mapped to the subst value.
        /// </summary>
        /// <param name="substValue">The subst. value. This can be either just a drive letter or the drive letter + path.</param>
        /// <param name="isRemote">The flag set when the mapped path is to a remote/UNC path.</param>
        /// <returns>Returns the path mapped to the specified value.</returns>
        public static string GetPathFromSubstDrive(string substValue, out bool isRemote)
        {
            string mappedPath = null;
            isRemote = false;

            if (IsPathToSubstDrive(substValue, out mappedPath, out isRemote))
            {
                return mappedPath;
            }
            else
            {
                return string.Empty;
            }
        }

        #region Directory/File Methods

        /// <summary>
        /// Get the directory name from the path. If the path is a file, the directory is returned; otherwise, the path's sub-directory is returned.
        /// </summary>
        /// <param name="path">The directory or file path.</param>
        /// <returns>Returns the directory name.</returns>
        /// <remarks>This function will never throw an exception for path too long, illegal chars, etc.</remarks>
        public static string GetDirectoryName(string path)
        {
            return GetDirectoryFromPath(path, false);
        }


        /// <summary>
        /// Get the absolute directory for the specified path. If the path is a file, the directory is returned; otherwise, the path is returned.
        /// </summary>
        /// <param name="path">The directory or file path.</param>
        /// <returns>Returns the directory name.</returns>
        /// <remarks>This function will never throw an exception for path too long, illegal chars, etc.</remarks>
        public static string GetAbsoluteDirectoryName(string path)
        {
            return GetDirectoryFromPath(path, true);
        }

        private static string GetDirectoryFromPath(string path, bool isAbsolute)
        {
            if (string.IsNullOrEmpty(path))
                return null;

            if (isAbsolute)
            {
                // Make sure we strip out all existing slashes first.
                path = StripTrailingSlash(path);

                // Is this a file?
                if (System.IO.File.Exists(path))
                {
                    // Do nothing since the string has already been stripped.
                }

                // Is this a directory?
                else if (System.IO.Directory.Exists(path))
                {
                    // Append a slash so that the loop below stops at the correct point.
                    AddTrailingSeparator(ref path);
                }

                // When the path does not exist, make an educated guess...
                else if (!HasExtension(path))
                {
                    // The lack of a file extension normally means it's a directory.
                    AddTrailingSeparator(ref path);
                }
            }

            path = Normalize(path);
            int rootLength = GetRootLength(path);

            if (path.Length > rootLength)
            {
                int length = path.Length;

                if (length == rootLength)
                {
                    return null;
                }
                while (((length > rootLength) &&
                       (path[--length] != System.IO.Path.DirectorySeparatorChar)) &&
                       (path[length] != System.IO.Path.AltDirectorySeparatorChar))
                {
                }
                return path.Substring(0, length);
            }

            return null;
        }

        private static int GetRootLength(string path)
        {
            int num = 0;
            int length = path.Length;
            if ((length >= 1) && IsDirectorySeparator(path[0]))
            {
                num = 1;
                if ((length >= 2) && IsDirectorySeparator(path[1]))
                {
                    num = 2;
                    int num3 = 2;
                    while ((num < length) && (((path[num] != System.IO.Path.DirectorySeparatorChar) && (path[num] != System.IO.Path.AltDirectorySeparatorChar)) || (--num3 > 0)))
                    {
                        num++;
                    }
                }
                return num;
            }
            if ((length >= 2) && (path[1] == System.IO.Path.VolumeSeparatorChar))
            {
                num = 2;
                if ((length >= 3) && IsDirectorySeparator(path[2]))
                {
                    num++;
                }
            }
            return num;
        }

        /// <summary>
        /// Determines if the character is a directory separator or not.
        /// </summary>
        /// <param name="ch">The character to test.</param>
        /// <returns>Returns true if the character is a directory separator; otherwise, false.</returns>
        public static bool IsDirectorySeparator(char ch)
        {
            if (ch != System.IO.Path.DirectorySeparatorChar)
            {
                return (ch == System.IO.Path.AltDirectorySeparatorChar);
            }
            return true;
        }

        /// <summary>
        /// Get the filename for the specified path.
        /// </summary>
        /// <param name="path">The path used to extract the filename.</param>
        /// <returns>Returns the filename.</returns>
        /// <remarks>This function will never throw an exception for path too long, illegal chars, etc.</remarks>
        public static string GetFileName(string path)
        {
            if (path != null)
            {
                int length = path.Length;
                int num2 = length;
                while (--num2 >= 0)
                {
                    char ch = path[num2];
                    if (((ch == Path.DirectorySeparatorChar) || (ch == Path.AltDirectorySeparatorChar)) || (ch == Path.VolumeSeparatorChar))
                    {
                        return path.Substring(num2 + 1, (length - num2) - 1);
                    }
                }
            }
            return path;
        }

        /// <summary>
        /// Get the folder name from the specified path.
        /// </summary>
        /// <param name="path">The directory or file path.</param>
        /// <returns>Returns the folder name.</returns>
        public static string GetFolderName(string path)
        {
            // A rooted path should be excluded.
            if (string.IsNullOrEmpty(path) ||
                IsRoot(path))
            {
                return string.Empty;
            }

            // Make sure we start out with a directory.
            path = GetAbsoluteDirectoryName(path);

            // Make sure we kill the trailing slash.
            path = StripTrailingSlash(path);

            string folderName = "";

            for (int i = path.Length - 1; i >= 0; i--)
            {
                if (path[i] == System.IO.Path.DirectorySeparatorChar ||
                    path[i] == System.IO.Path.AltDirectorySeparatorChar)
                {
                    // Sanity check.
                    if (i + 1 < path.Length)
                    {
                        folderName = path.Substring(i + 1);
                    }
                    break;
                }
            }

            return folderName;
        }

        /// <summary>
        /// Checks the path to determine if a file extension exists.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if the path has a file extension; otherwise, false.</returns>
        public static bool HasExtension(string path)
        {
            if (path != null)
            {
                int length = path.Length;

                while (--length >= 0)
                {
                    char ch = path[length];
                    if (ch == '.')
                    {
                        return (length != (path.Length - 1));
                    }
                    if (((ch == System.IO.Path.DirectorySeparatorChar) || (ch == System.IO.Path.AltDirectorySeparatorChar)) || (ch == System.IO.Path.VolumeSeparatorChar))
                    {
                        break;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Perform a complete directory copy from source to destination, overwriting files if specified.
        /// </summary>
        /// <param name="sourceDirectory">The source directory.</param>
        /// <param name="destDirectory">The destination directory.</param>
        /// <param name="overwrite">Specify whether to overwrite files or not.</param>
        public static void CopyDirectory(string sourceDirectory, string destDirectory, bool overwrite)
        {
            // Create the destination directory if it doesn't already exist.
            if (!Directory.Exists(destDirectory))
            {
                Directory.CreateDirectory(destDirectory);
            }

            DirectoryInfo sourceDirInfo = new DirectoryInfo(sourceDirectory);

            if (!sourceDirInfo.Exists)
            {
                throw new ArgumentException(string.Format(Strings.SourceDirNotExist, sourceDirectory));
            }

            string temp;

            // Copy all of the files.
            foreach (FileInfo fi in sourceDirInfo.GetFiles())
            {
                temp = Path.Combine(destDirectory, fi.Name);
                fi.CopyTo(temp, overwrite);
            }

            // Recurse all directories.
            foreach (DirectoryInfo di in sourceDirInfo.GetDirectories())
            {
                temp = Path.Combine(destDirectory, di.Name);
                CopyDirectory(di.FullName, temp, overwrite);
            }
        }

        #endregion

        #region Path/File Length Constants

        /// <summary>
        /// Get the maximum path length (= 260).
        /// </summary>
        public static int MaxPath
        {
            get { return m_maxPath; }
        }

        /// <summary>
        /// Get the maximum filename length (= 255).
        /// </summary>
        public static int MaxFilename 
        {
            get { return m_maxFilename; }
        }

        #endregion

        #region UAC Methods

        /// <summary>
        /// Determines if a non-Vista OS path is valid. This will run some of the same tests as done for Vista, but will also check Program Files as well.        
        /// </summary>
        /// <param name="path">The path to examine for potential virtualization.</param>
        /// <returns>Returns true if the path is valid; otherwise, false.</returns>
        public static bool IsValidNonVistaUACPath(string path)
        {
            ArgumentValidator.ValidateNonEmptyString(path, "path", "PathUtils.IsValidNonVistaUACPath");

            // Get the directory name, create a path with/without a slash.
            path = GetAbsoluteDirectoryName(path);            
            string pathNoTrailingSlash = PathUtils.StripTrailingSlash(path);
            AddTrailingSeparator(ref path);

            // Check the rights on the path as long as the path actually exists.
            if (Directory.Exists(path) &&
                !IsPathMappedDrive(path) &&
                !IsPathUNC(path))
            {
                DirectoryAccessRights rights = new DirectoryAccessRights(path);
                
                if (!rights.HasWriteRights)
                    return false;
            }

            // Get the string...
            string sep = System.IO.Path.DirectorySeparatorChar.ToString();

            // Get the current drive letter...
            string currentDriveLetter = Environment.GetEnvironmentVariable("SystemDrive");

            // Overall, we want to make sure:
            // 1. The path excludes the Program Files folder (add separator so we don't disallow similar looking paths).
            // 2. The path excludes the Program Files (x86) folder (add separator so we don't disallow similar looking paths).
            // 3. The path excludes the Windows folder (add separator so we don't disallow similar looking paths).
            // 4. The path excludes the root of the system drive.
            if (path.StartsWith(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + sep, true, System.Globalization.CultureInfo.CurrentCulture) ||
                path.StartsWith(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + " (x86)" + sep, true, System.Globalization.CultureInfo.CurrentCulture) ||
                path.StartsWith(Environment.GetEnvironmentVariable("windir") + sep, true, System.Globalization.CultureInfo.CurrentCulture) ||
                string.Compare(pathNoTrailingSlash, currentDriveLetter, true, System.Globalization.CultureInfo.CurrentCulture) == 0)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Determines if a path can potentially be virtualized in Windows Vista.
        /// </summary>
        /// <param name="path">The path to examine for potential virtualization.</param>
        /// <returns>True if the path can potentially be virtualized.  False, otherwise.</returns>
        public static bool PathCanPotentiallyBeVirtualized(string path)
        {
            ArgumentValidator.ValidateNonEmptyString(path, "path", "PathUtils.PathCanPotentiallyBeVirtualized");
            bool returnVal = false;

            //Only check for potential virtualization if it a Vista machine.
            //we cannot retrieve permissions on a mapped drive or a UNC path.
            //Besides, a mapped drive and UNC path cannot be virtualized anyway.
            if (Environment.OSVersion.Version.Major > WINDOWS_XP &&
                Directory.Exists(path) &&
                !IsPathMappedDrive(path) &&
                !IsPathUNC(path))
            {
                DirectoryAccessRights rights = new DirectoryAccessRights(path);
                if (!rights.HasWriteRights)
                {
                    returnVal = true;
                }
                else if (VirtualizedFolderExists(path))
                {
                    returnVal = true;
                }
            }

            return returnVal;
        }

        /// <summary>
        /// Determines if a virtualized folder already exists on the machine for the
        /// passed in path.
        /// </summary>
        /// <param name="path">The path to check.  Include a drive and directory</param>
        /// <returns>True, if a virtualized folder exists.  Otherwise, false.</returns>
        private static bool VirtualizedFolderExists(string path)
        {
            ArgumentValidator.ValidateNonEmptyString(path, "path", "PathUtils.VirtualizedFolderExists");
            bool returnVal = false;

            //Only check for potential virtualization if it a Vista machine.
            //Mapped drives and UNC paths will not get virtualized.
            if (Environment.OSVersion.Version.Major > WINDOWS_XP &&
                Directory.Exists(path) &&
                !IsPathMappedDrive(path) &&
                !IsPathUNC(path))
            {
                string localAppDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string virtualStorePath = Path.Combine(localAppDataPath, @"VirtualStore");
                string pathWithoutDriveLetter = path.Split(new char[] { ':' })[1].Trim(new char[] { '\\' });
                string completeVirtualStorePath = Path.Combine(virtualStorePath, pathWithoutDriveLetter);
                if (Directory.Exists(completeVirtualStorePath))
                {
                    returnVal = true;
                }
            }

            return returnVal;
        }

        #endregion

        #region IPathUtils

        /// <summary>
        /// Determine if the specified path is a drive root directory.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if the path is a drive root directory; otherwise, false.</returns>
        bool IPathUtils.IsRoot(string path)
        {
            return IsRoot(path);
        }

        /// <summary>
        /// Get a flag indicating if the path ends with a trailing directory separator character.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if the path has a trailing directory separator character; otherwise, false.</returns>
        bool IPathUtils.HasTrailingSeparator(string path)
        {
            return HasTrailingSeparator(path);
        }

        /// <summary>
        /// Add a trailing separator if one doesn't already exist.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if a trailing separator was added; otherwise, false.</returns>
        bool IPathUtils.AddTrailingSeparator(ref string path)
        {
            return AddTrailingSeparator(ref path);
        }        

        /// <summary>
        /// Remove any trailing '\' from the end of s path if it is not a root path.
        /// </summary>
        /// <param name="path">The path to examine\modify.</param>
        /// <returns>Returns true if the path was stripped of a trailing '\'; otherwise, false.</returns>
        bool IPathUtils.StripTrailingSlashIfNotRoot(ref string path)
        {
            return StripTrailingSlashIfNotRoot(ref path);
        }

        /// <summary>
        /// Use to clean up a path retrieved from user input or the registry.
        /// Also ensures that if there are multiple paths seperated by ';', only
        /// the first will be used.
        /// </summary>
        /// <param name="path">Path to normalize. A null path is handled by
        /// causing the empty string to be returned.</param>
        /// <returns>Normalized path or empty string if path is null.</returns>
        string IPathUtils.Normalize(string path)
        {
            return Normalize(path);
        }

        /// <summary>
        /// Use to clean up a path retrieved from user input or the registry.
        /// Also ensures that if there are multiple paths seperated by ';', only
        /// the first will be used.
        /// </summary>
        /// <param name="path">Path to normalize. A null path is handled by
        /// causing the empty string to be returned.</param>
        /// <param name="addTrailingSeparator">Specify whether to add a trailing slash.</param>
        /// <returns>Normalized path or empty string if path is null.</returns>
        string IPathUtils.Normalize(string path, bool addTrailingSeparator)
        {
            return Normalize(path, addTrailingSeparator);
        }

        /// <summary>
        /// Combines two path strings.
        /// </summary>
        /// <param name="path1">First path string: absolute or relative.</param>
        /// <param name="path2">Second path string: relative paths only.</param>
        /// <returns>Combined path string.</returns>
        string IPathUtils.Combine(string path1, string path2)
        {
            return Combine(path1, path2);
        }

        /// <summary>
        /// Determines if a directory is accessible (e.g. exists and is online).
        /// </summary>
        /// <param name="path">Path to test</param>
        /// <returns>Returns true if path exists and is online, false otherwise.
        /// Guaranteed not to throw exceptions.</returns>
        bool IPathUtils.IsAccessibleDirectory(string path)
        {
            return IsAccessibleDirectory(path);
        }

        /// <summary>
        /// Get the server name from the mapped folder path.
        /// </summary>
        /// <param name="mappedFolderPath">the mapped path to derive a server name from</param>
        /// <returns>The server name or empty string</returns>
        string IPathUtils.ServerNameFromMappedFolder(string mappedFolderPath)
        {
            return ServerNameFromMappedFolder(mappedFolderPath);
        }

        /// <summary>
        /// Get the UNC path from the mapped folder path.
        /// </summary>
        /// <param name="mappedFolderPath">the mapped path to derive a UNC path from</param>
        /// <returns>The UNC path or empty string</returns>
        string IPathUtils.UNCPathFromMappedFolder(string mappedFolderPath)
        {
            return UNCPathFromMappedFolder(mappedFolderPath);
        }

        /// <summary>
        /// Determine if a string value appears to be some type of path.
        /// </summary>
        /// <param name="value">The string value to test.</param>
        /// <returns>Returns true if the path</returns>
        bool IPathUtils.IsPath(string value)
        {
            return IsPath(value);
        }

        /// <summary>
        /// Is the path part of a mapped drive.
        /// </summary>
        /// <param name="path">The path that needs to be tested if it is part of a mapped drive.</param>
        /// <returns>True if the path is part of a mapped drive, false otherwise.</returns>
        bool IPathUtils.IsPathMappedDrive(string path)
        {
            return IsPathMappedDrive(path);
        }

        /// <summary>
        /// Is the path part of a UNC path.
        /// </summary>
        /// <param name="path">The path that needs to be tested if it is part of a UNC path.</param>
        /// <returns>True if the path is UNC, false otherwise.</returns>
        bool IPathUtils.IsPathUNC(string path)
        {
            return IsPathUNC(path);
        }

        /// <summary>
        /// Determine whether the specified path is contained within the list of known substituted drives.
        /// </summary>
        /// <param name="path">The path to test.</param>
        /// <returns>Returns true if the path is substituted; otherwise false</returns>
        bool IPathUtils.IsPathToSubstDrive(string path)
        {
            return IsPathToSubstDrive(path);
        }

        /// <summary>
        /// Remove any trailing '\' from the end of a path
        /// </summary>
        /// <param name="path">The path to examine\modify</param>
        /// <returns>The path without a trailing '\'</returns>
        /// <remarks>If the path does not have a trailing '\' the orginal path will be returned</remarks>
        string IPathUtils.StripTrailingSlash(string path)
        {
            return StripTrailingSlash(path);
        }

        /// <summary>
        /// Determines if a path can potentially be virtualized in Windows Vista.
        /// </summary>
        /// <param name="path">The path to examine for potential virtualization.</param>
        /// <returns>True if the path can potentially be virtualized.  False, otherwise.</returns>
        bool IPathUtils.PathCanPotentiallyBeVirtualized(string path)
        {
            return PathCanPotentiallyBeVirtualized(path);
        }

        /// <summary>
        /// Determines if a non-Vista OS path is valid. This will run some of the same tests as done for Vista, but will also check Program Files as well.        
        /// </summary>
        /// <param name="path">The path to examine for potential virtualization.</param>
        /// <returns>Returns true if the path is valid; otherwise, false.</returns>
        bool IPathUtils.IsValidNonVistaUACPath(string path)
        {
            return IsValidNonVistaUACPath(path);
        }

        /// <summary>
        /// Get the directory name from the path. If the path is a file, the directory is returned; otherwise, the path's sub-directory is returned.
        /// </summary>
        /// <param name="path">The directory or file path.</param>
        /// <returns>Returns the directory name.</returns>
        string IPathUtils.GetDirectoryName(string path)
        {
            return GetDirectoryName(path);
        }

        /// <summary>
        /// Get the filename for the specified path.
        /// </summary>
        /// <param name="path">The path used to extract the filename.</param>
        /// <returns>Returns the filename.</returns>
        string IPathUtils.GetFileName(string path)
        {
            return GetFileName(path);
        }

        /// <summary>
        /// Get the folder name from the specified path.
        /// </summary>
        /// <param name="path">The directory or file path.</param>
        /// <returns>Returns the folder name.</returns>
        string IPathUtils.GetFolderName(string path)
        {
            return GetFolderName(path);
        }

        /// <summary>
        /// Checks the path to determine if a file extension exists.
        /// </summary>
        /// <param name="path">The path to check.</param>
        /// <returns>Returns true if the path has a file extension; otherwise, false.</returns>
        bool IPathUtils.HasExtension(string path)
        {
            return HasExtension(path);
        }

        /// <summary>
        /// Determines if the character is a directory separator or not.
        /// </summary>
        /// <param name="ch">The character to test.</param>
        /// <returns>Returns true if the character is a directory separator; otherwise, false.</returns>
        bool IPathUtils.IsDirectorySeparator(char ch)
        {
            return IsDirectorySeparator(ch);
        }

        /// <summary>
        /// Get the maximum path length (= 260).
        /// </summary>
        int IPathUtils.MaxPath 
        {
            get { return MaxPath; }
        }

        /// <summary>
        /// Get the maximum filename length (= 255).
        /// </summary>
        int IPathUtils.MaxFilename
        {
            get { return MaxFilename; }
        }

        #endregion
    }
}
