﻿using System;
using System.Collections.Generic;

namespace Sage.CRE.Core.SQL
{
    /// <summary>
    /// Copies a database using the reversible action pattern.
    /// </summary>
    public class CopyDatabase : Sage.IO.ReversibleAction.ReversibleActionBase
    {

        #region Private members
        private SqlConnectionContext _context = new SqlConnectionContext();

        private string _destinationDatabase;
        private string _targetMDF;
        private string _targetLDF;
        private bool _filesCopied;
        private bool _targetAttached;
        #endregion

        /// <summary>
        /// Copies a database within a SQL Server.
        /// </summary>
        /// <param name="context">The source database context.</param>
        /// <param name="destinationDatabase">The name of the destination database.</param>
        public CopyDatabase(SqlConnectionContext context, string destinationDatabase)
        {
            _context = context;
            _destinationDatabase = destinationDatabase;
            
        }

        /// <summary>
        /// Copies the database.
        /// </summary>
        public override void Forward()
        {
            base.Forward();

            // first detach the source database
            using (DetachDatabase detachSource = new DetachDatabase(_context))
            {
                detachSource.Forward();
                // then make copies of the source MDF and LDF files
                Dictionary<string,string> filesToCopy = new Dictionary<string,string>();
                
                string MDFDirectory = String.Empty;
                string LDFDirectory = String.Empty;
                SqlCommands.GetDefaultFileLocations(_context,out MDFDirectory, out LDFDirectory);

                string now =  System.DateTime.Now.ToFileTimeUtc().ToString();
                _targetMDF = System.IO.Path.Combine(MDFDirectory,String.Format(@"{0} - {1}.MDF",_destinationDatabase,now));
                _targetLDF = System.IO.Path.Combine(LDFDirectory,String.Format(@"{0} - {1}.LDF",_destinationDatabase,now));
                filesToCopy.Add(detachSource.MDF,_targetMDF);
                filesToCopy.Add(detachSource.LDF,_targetLDF);

                using (Sage.IO.ReversibleAction.FileCopy sourceMDFLDFCopy = new Sage.IO.ReversibleAction.FileCopy(filesToCopy))
                {
                    sourceMDFLDFCopy.Forward();
                    _filesCopied = true;

                    // now attach the copied MDF and LDF files
                    SqlConnectionContext destinationContext = (SqlConnectionContext)_context.Clone();
                    destinationContext.InitialCatalog = _destinationDatabase;
                    using (AttachDatabase attachDatabase = new AttachDatabase(destinationContext, _targetMDF, _targetLDF))
                    {
                        attachDatabase.Forward();

                        // we're good to go
                        System.Data.SqlClient.SqlConnection.ClearAllPools();
                        SqlConnectionContext newContext = (SqlConnectionContext)_context.Clone();
                        newContext.InitialCatalog = _destinationDatabase;

                        while (!SqlCommands.DatabaseExists(newContext)) System.Threading.Thread.Sleep(1000);
                        _targetAttached = true;

                        attachDatabase.Commit();

                    }

                    sourceMDFLDFCopy.Commit();

                }

                // don't commit the detachSource so it will be reversed.
                //detachSource.Commit(); 
            }
            System.Data.SqlClient.SqlConnection.ClearAllPools();
        }

        /// <summary>
        /// Un-copies the database.
        /// </summary>
        public override void Reverse()
        {
            if (_targetAttached)
            {
                SqlConnectionContext destinationContext = (SqlConnectionContext)_context.Clone();
                destinationContext.InitialCatalog = _destinationDatabase;
                SqlCommands.DropDatabase(destinationContext, true);
            }
            if (_filesCopied)
            {
                System.IO.File.Delete(_targetMDF);
                System.IO.File.Delete(_targetLDF);
            }
            base.Reverse();
        }
    }
}
