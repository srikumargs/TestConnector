using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Globalization;

using Sage.Diagnostics;

namespace Sage.Activation
{
    /// <summary>
    /// Generally we throw our own exceptions from the TypeFactory
    /// </summary>
    [ ComVisible( false ) ]
    [Serializable]
    public sealed class TypeFactoryException : LoggingBaseException
    {
        /// <summary>
        /// Serialization Constructor
        /// </summary>
        /// <param name="si">Serialization Info</param>
        /// <param name="sc">Streaming Context</param>
        private TypeFactoryException(SerializationInfo si, StreamingContext sc)
            : base(si, sc)
        { }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public TypeFactoryException()
        { }

        /// <summary>
        /// Constructor (exception takes a typeLookup)
        /// </summary>
        /// <param name="typeLookup">type lookup</param>
        public TypeFactoryException(string typeLookup)
            : base(StringTable.TYPE_FACTORY_COMPONENT, string.Format(CultureInfo.InvariantCulture, StringTable.CANNOT_ACTIVATE_TYPE_FORMAT, typeLookup))
        {

        }

        /// <summary>
        /// Constructor (exception takes a typeLookup and inner exception)
        /// </summary>
        /// <param name="typeLookup">type lookup</param>
        /// <param name="innerException">An inner exception</param>
        public TypeFactoryException(string typeLookup, Exception innerException)
            : base(StringTable.TYPE_FACTORY_COMPONENT, string.Format(CultureInfo.InvariantCulture, StringTable.CANNOT_ACTIVATE_TYPE_FORMAT2, typeLookup, innerException.GetType().Name, innerException.Message, innerException.StackTrace), innerException)
        {

        }

        /// <summary>
        /// Constructor (exception takes an inner exception)
        /// </summary>
        /// <param name="innerException">An inner exception</param>
        public TypeFactoryException(Exception innerException)
            : base(StringTable.TYPE_FACTORY_COMPONENT, string.Format(CultureInfo.InvariantCulture, StringTable.CANNOT_ACTIVATE_TYPE_FORMAT3, innerException.GetType().Name, innerException.Message, innerException.StackTrace), innerException)
        {

        }
    }
}